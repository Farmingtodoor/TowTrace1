import { ReactNode, useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';

type RequiredRole = 'admin' | 'operator';

interface ProtectedRouteProps {
  children: ReactNode;
  requiredRole: RequiredRole;
}

export function ProtectedRoute({ children, requiredRole }: ProtectedRouteProps) {
  const { user, loading: authLoading } = useAuth();
  const [hasAccess, setHasAccess] = useState<boolean | null>(null);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    const checkAccess = async () => {
      if (authLoading) return;
      
      if (!user) {
        setHasAccess(false);
        setChecking(false);
        return;
      }

      if (requiredRole === 'admin') {
        const [{ data: isAdmin }, { data: isSuperAdmin }] = await Promise.all([
          supabase.rpc('has_role', { _user_id: user.id, _role: 'admin' }),
          supabase.rpc('has_role', { _user_id: user.id, _role: 'super_admin' as any }),
        ]);
        setHasAccess(isAdmin === true || isSuperAdmin === true);
      } else if (requiredRole === 'operator') {
        // Check for admin role first (admins can access operator pages)
        const [{ data: isAdmin }, { data: isSuperAdmin }] = await Promise.all([
          supabase.rpc('has_role', { _user_id: user.id, _role: 'admin' }),
          supabase.rpc('has_role', { _user_id: user.id, _role: 'super_admin' as any }),
        ]);

        if (isAdmin === true || isSuperAdmin === true) {
          setHasAccess(true);
        } else {
          // Check if user is assigned to any tow yard
          const { data: operatorData } = await supabase
            .from('tow_yard_operators')
            .select('id')
            .eq('operator_user_id', user.id)
            .limit(1);

          setHasAccess(!!operatorData && operatorData.length > 0);
        }
      }

      setChecking(false);
    };

    checkAccess();
  }, [user, authLoading, requiredRole]);

  if (authLoading || checking) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-accent" />
      </div>
    );
  }

  if (!hasAccess) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}
