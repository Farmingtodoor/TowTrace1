import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Search, DollarSign, FileCheck, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';

const slides = [
  {
    title: 'Instant Vehicle Lookup',
    description: 'Find your towed car in seconds with just your plate or VIN number.',
    gradient: 'from-accent/20 via-accent/10 to-info/20',
    icon: Search,
    iconColor: 'text-accent',
    bgAccent: 'bg-accent/10',
  },
  {
    title: 'Transparent Pricing',
    description: 'See all fees upfront. No hidden charges, no surprises.',
    gradient: 'from-success/20 via-success/10 to-accent/20',
    icon: DollarSign,
    iconColor: 'text-success',
    bgAccent: 'bg-success/10',
  },
  {
    title: 'Easy Documentation',
    description: 'Upload your ID and registration digitally for faster release.',
    gradient: 'from-info/20 via-info/10 to-primary/20',
    icon: FileCheck,
    iconColor: 'text-info',
    bgAccent: 'bg-info/10',
  },
  {
    title: 'US & Canada Coverage',
    description: 'Partner tow yards across North America at your fingertips.',
    gradient: 'from-primary/20 via-primary/10 to-accent/20',
    icon: Globe,
    iconColor: 'text-primary',
    bgAccent: 'bg-primary/10',
  },
];

export function ImageCarousel() {
  const [current, setCurrent] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  useEffect(() => {
    if (!isAutoPlaying) return;
    
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % slides.length);
    }, 5000);

    return () => clearInterval(timer);
  }, [isAutoPlaying]);

  const goTo = (index: number) => {
    setCurrent(index);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 10000);
  };

  const prev = () => goTo((current - 1 + slides.length) % slides.length);
  const next = () => goTo((current + 1) % slides.length);

  const currentSlide = slides[current];
  const Icon = currentSlide.icon;

  return (
    <div className="relative w-full max-w-3xl mx-auto">
      {/* Slides */}
      <div className="overflow-hidden rounded-3xl shadow-card-lg border border-border/50">
        <div 
          className="flex transition-transform duration-500 ease-out"
          style={{ transform: `translateX(-${current * 100}%)` }}
        >
          {slides.map((slide, index) => {
            const SlideIcon = slide.icon;
            return (
              <div
                key={index}
                className={`flex-shrink-0 w-full p-10 md:p-14 bg-gradient-to-br ${slide.gradient} relative overflow-hidden`}
              >
                {/* Background decoration */}
                <div className="absolute -top-20 -right-20 w-64 h-64 bg-gradient-to-br from-white/10 to-transparent rounded-full blur-2xl" />
                <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-gradient-to-tr from-white/10 to-transparent rounded-full blur-2xl" />
                
                <div className="text-center space-y-6 relative z-10">
                  <div className={`w-20 h-20 ${slide.bgAccent} rounded-2xl flex items-center justify-center mx-auto shadow-lg`}>
                    <SlideIcon className={`w-10 h-10 ${slide.iconColor}`} />
                  </div>
                  <h3 className="font-display text-2xl md:text-3xl font-bold text-foreground">
                    {slide.title}
                  </h3>
                  <p className="text-muted-foreground text-lg max-w-md mx-auto leading-relaxed">
                    {slide.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Navigation Arrows */}
      <Button
        variant="secondary"
        size="icon"
        onClick={prev}
        className="absolute left-4 top-1/2 -translate-y-1/2 shadow-lg hover:scale-110 transition-transform"
      >
        <ChevronLeft className="w-5 h-5" />
      </Button>
      <Button
        variant="secondary"
        size="icon"
        onClick={next}
        className="absolute right-4 top-1/2 -translate-y-1/2 shadow-lg hover:scale-110 transition-transform"
      >
        <ChevronRight className="w-5 h-5" />
      </Button>

      {/* Dots */}
      <div className="flex justify-center gap-3 mt-6">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => goTo(index)}
            className={`h-2.5 rounded-full transition-all duration-300 ${
              index === current 
                ? 'bg-accent w-8' 
                : 'bg-muted-foreground/30 hover:bg-muted-foreground/50 w-2.5'
            }`}
          />
        ))}
      </div>
    </div>
  );
}
