import { useState } from 'react';
import { cn } from '@/lib/utils';
import { Car, Hash } from 'lucide-react';

interface LookupTabsProps {
  activeTab: 'plate' | 'vin';
  onTabChange: (tab: 'plate' | 'vin') => void;
}

export function LookupTabs({ activeTab, onTabChange }: LookupTabsProps) {
  return (
    <div className="flex bg-muted p-1 rounded-xl gap-1">
      <button
        onClick={() => onTabChange('plate')}
        className={cn(
          'flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-lg font-semibold transition-all duration-200',
          activeTab === 'plate'
            ? 'bg-card text-foreground shadow-sm'
            : 'text-muted-foreground hover:text-foreground'
        )}
      >
        <Car className="w-5 h-5" />
        <span>License Plate</span>
      </button>
      <button
        onClick={() => onTabChange('vin')}
        className={cn(
          'flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-lg font-semibold transition-all duration-200',
          activeTab === 'vin'
            ? 'bg-card text-foreground shadow-sm'
            : 'text-muted-foreground hover:text-foreground'
        )}
      >
        <Hash className="w-5 h-5" />
        <span>VIN</span>
      </button>
    </div>
  );
}
