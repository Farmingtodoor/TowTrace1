import { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, AlertCircle } from 'lucide-react';
import { US_STATES, CA_PROVINCES, type Region } from '@/data/regions';
import { validatePlate, formatPlate } from '@/lib/validation';

interface PlateFormProps {
  onSearch: (plate: string, region: string, country: 'US' | 'CA') => void;
  isLoading?: boolean;
}

export function PlateForm({ onSearch, isLoading }: PlateFormProps) {
  const [plate, setPlate] = useState('');
  const [country, setCountry] = useState<'US' | 'CA'>('US');
  const [region, setRegion] = useState('');
  const [error, setError] = useState<string | null>(null);

  const regions = country === 'US' ? US_STATES : CA_PROVINCES;

  const handleCountryChange = (newCountry: 'US' | 'CA') => {
    setCountry(newCountry);
    setRegion(''); // Reset region when country changes
  };

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const validation = validatePlate(plate);
    if (!validation.valid) {
      setError(validation.message || 'Invalid plate');
      return;
    }

    if (!region) {
      setError('Please select a state/province');
      return;
    }

    onSearch(formatPlate(plate), region, country);
  }, [plate, region, country, onSearch]);

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {/* Country Toggle */}
      <div className="flex bg-muted/50 p-1 rounded-lg gap-1">
        <button
          type="button"
          onClick={() => handleCountryChange('US')}
          className={`flex-1 py-2.5 px-4 rounded-md font-medium transition-all duration-200 ${
            country === 'US'
              ? 'bg-card text-foreground shadow-sm'
              : 'text-muted-foreground hover:text-foreground'
          }`}
        >
          🇺🇸 United States
        </button>
        <button
          type="button"
          onClick={() => handleCountryChange('CA')}
          className={`flex-1 py-2.5 px-4 rounded-md font-medium transition-all duration-200 ${
            country === 'CA'
              ? 'bg-card text-foreground shadow-sm'
              : 'text-muted-foreground hover:text-foreground'
          }`}
        >
          🇨🇦 Canada
        </button>
      </div>

      {/* Plate Input */}
      <div className="space-y-2">
        <label htmlFor="plate" className="text-sm font-medium text-foreground">
          License Plate Number
        </label>
        <Input
          id="plate"
          type="text"
          placeholder="ABC-1234"
          value={plate}
          onChange={(e) => {
            setPlate(e.target.value.toUpperCase());
            setError(null);
          }}
          className="text-lg font-mono tracking-wider uppercase"
          maxLength={10}
        />
      </div>

      {/* State/Province Select */}
      <div className="space-y-2">
        <label className="text-sm font-medium text-foreground">
          {country === 'US' ? 'State' : 'Province'}
        </label>
        <Select value={region} onValueChange={(value) => {
          setRegion(value);
          setError(null);
        }}>
          <SelectTrigger className="h-12">
            <SelectValue placeholder={`Select ${country === 'US' ? 'state' : 'province'}`} />
          </SelectTrigger>
          <SelectContent>
            {regions.map((r) => (
              <SelectItem key={r.code} value={r.code}>
                {r.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Error Message */}
      {error && (
        <div className="flex items-center gap-2 text-destructive text-sm animate-fade-in">
          <AlertCircle className="w-4 h-4" />
          <span>{error}</span>
        </div>
      )}

      {/* Submit Button */}
      <Button
        type="submit"
        variant="hero"
        size="lg"
        className="w-full"
        disabled={isLoading}
      >
        {isLoading ? (
          <span className="flex items-center gap-2">
            <span className="w-5 h-5 border-2 border-accent-foreground/30 border-t-accent-foreground rounded-full animate-spin" />
            Searching...
          </span>
        ) : (
          <span className="flex items-center gap-2">
            <Search className="w-5 h-5" />
            Find My Vehicle
          </span>
        )}
      </Button>
    </form>
  );
}
