import { useState } from 'react';
import { LookupTabs } from './LookupTabs';
import { PlateForm } from './PlateForm';
import { VINForm } from './VINForm';

interface LookupCardProps {
  onPlateSearch: (plate: string, region: string, country: 'US' | 'CA') => void;
  onVINSearch: (vin: string) => void;
  isLoading?: boolean;
}

export function LookupCard({ onPlateSearch, onVINSearch, isLoading }: LookupCardProps) {
  const [activeTab, setActiveTab] = useState<'plate' | 'vin'>('plate');

  return (
    <div className="w-full max-w-md mx-auto bg-card rounded-2xl shadow-card-lg p-6 space-y-6 animate-scale-in">
      <LookupTabs activeTab={activeTab} onTabChange={setActiveTab} />
      
      {activeTab === 'plate' ? (
        <PlateForm onSearch={onPlateSearch} isLoading={isLoading} />
      ) : (
        <VINForm onSearch={onVINSearch} isLoading={isLoading} />
      )}
    </div>
  );
}
