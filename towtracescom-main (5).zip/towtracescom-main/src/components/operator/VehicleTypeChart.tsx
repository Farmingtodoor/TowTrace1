import { useState, useEffect } from 'react';
import { Car } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { supabase } from '@/integrations/supabase/client';
import { VEHICLE_TYPES, type VehicleType } from '@/lib/feeCalculator';

interface VehicleTypeChartProps {
  towYardId: string | null;
}

interface ChartData {
  name: string;
  value: number;
  type: string;
}

const COLORS = [
  'hsl(var(--primary))',
  'hsl(var(--accent))',
  'hsl(var(--success))',
  'hsl(var(--warning))',
  'hsl(var(--info))',
  'hsl(var(--destructive))',
  'hsl(var(--muted-foreground))',
];

export function VehicleTypeChart({ towYardId }: VehicleTypeChartProps) {
  const [data, setData] = useState<ChartData[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalVehicles, setTotalVehicles] = useState(0);

  useEffect(() => {
    if (!towYardId) return;

    const fetchVehicleTypes = async () => {
      setLoading(true);

      const { data: records, error } = await supabase
        .from('tow_records')
        .select('vehicle_type')
        .eq('tow_yard_id', towYardId);

      if (error) {
        console.error('Error fetching vehicle types:', error);
        setLoading(false);
        return;
      }

      // Count by vehicle type
      const counts: Record<string, number> = {};
      records?.forEach((record) => {
        const type = record.vehicle_type || 'standard';
        counts[type] = (counts[type] || 0) + 1;
      });

      // Convert to chart data
      const chartData: ChartData[] = Object.entries(counts)
        .map(([type, count]) => ({
          name: VEHICLE_TYPES[type as VehicleType]?.label || type,
          value: count,
          type,
        }))
        .sort((a, b) => b.value - a.value);

      setData(chartData);
      setTotalVehicles(records?.length || 0);
      setLoading(false);
    };

    fetchVehicleTypes();
  }, [towYardId]);

  if (loading) {
    return (
      <div className="bg-card rounded-xl p-6 shadow-card animate-pulse">
        <div className="h-64 bg-muted rounded" />
      </div>
    );
  }

  if (data.length === 0) {
    return (
      <div className="bg-card rounded-xl p-6 shadow-card">
        <div className="flex items-center gap-2 mb-4">
          <Car className="w-5 h-5 text-primary" />
          <h3 className="font-display text-lg font-semibold">Vehicle Type Distribution</h3>
        </div>
        <div className="h-64 flex items-center justify-center text-muted-foreground">
          No vehicle data available
        </div>
      </div>
    );
  }

  const renderCustomLabel = ({
    cx,
    cy,
    midAngle,
    innerRadius,
    outerRadius,
    percent,
  }: {
    cx: number;
    cy: number;
    midAngle: number;
    innerRadius: number;
    outerRadius: number;
    percent: number;
  }) => {
    if (percent < 0.05) return null; // Don't show labels for small slices
    
    const RADIAN = Math.PI / 180;
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
      <text
        x={x}
        y={y}
        fill="white"
        textAnchor="middle"
        dominantBaseline="central"
        className="text-xs font-medium"
      >
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };

  return (
    <div className="bg-card rounded-xl p-6 shadow-card">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Car className="w-5 h-5 text-primary" />
          <h3 className="font-display text-lg font-semibold">Vehicle Type Distribution</h3>
        </div>
        <span className="text-sm text-muted-foreground">
          {totalVehicles} total vehicles
        </span>
      </div>

      <div className="h-72">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={renderCustomLabel}
              outerRadius={100}
              fill="#8884d8"
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={COLORS[index % COLORS.length]}
                  className="stroke-background"
                  strokeWidth={2}
                />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                backgroundColor: 'hsl(var(--card))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '8px',
              }}
              formatter={(value: number, name: string) => [
                `${value} vehicles (${((value / totalVehicles) * 100).toFixed(1)}%)`,
                name,
              ]}
            />
            <Legend
              verticalAlign="bottom"
              height={36}
              formatter={(value) => (
                <span className="text-sm text-foreground">{value}</span>
              )}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>

      {/* Stats breakdown */}
      <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 gap-2">
        {data.slice(0, 6).map((item, index) => (
          <div
            key={item.type}
            className="flex items-center gap-2 text-sm"
          >
            <div
              className="w-3 h-3 rounded-full shrink-0"
              style={{ backgroundColor: COLORS[index % COLORS.length] }}
            />
            <span className="text-muted-foreground truncate">{item.name}</span>
            <span className="font-medium ml-auto">{item.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
