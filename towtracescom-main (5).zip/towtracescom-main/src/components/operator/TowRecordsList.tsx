import { useState, useEffect } from 'react';
import { Car, MoreVertical, Eye, Edit, CheckCircle, Truck, Bike, Download, RefreshCw, FileText, AlertCircle, User, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Checkbox } from '@/components/ui/checkbox';
import { supabase } from '@/integrations/supabase/client';
import { EditRecordDialog } from './EditRecordDialog';
import { RecordDetailsDialog } from './RecordDetailsDialog';
import { logStatusChanged, logRecordReleased } from '@/lib/activityLog';
import { VEHICLE_TYPES, type VehicleType } from '@/lib/feeCalculator';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/useAuth';

interface ClaimInfo {
  id: string;
  claim_status: string;
  pending_docs_count: number;
}

interface TowRecord {
  id: string;
  plate_number: string | null;
  vin: string | null;
  make: string | null;
  model: string | null;
  color: string | null;
  status: string;
  tow_datetime: string;
  tow_fee: number;
  daily_storage_fee: number;
  admin_fee: number;
  gate_fee: number;
  vehicle_type: string | null;
  driver_name: string | null;
  driver_user_id: string | null;
  tow_reason?: string | null;
  tow_from_address?: string | null;
  storage_start_datetime?: string | null;
  locked_by_user_id?: string | null;
  locked_by_name?: string | null;
  locked_at?: string | null;
  claim?: ClaimInfo | null;
}

type EmployeePermission = 'viewer' | 'editor' | 'admin';
type TowStatus = 'towed' | 'docs_pending' | 'docs_approved' | 'paid' | 'released';

interface TowRecordsListProps {
  towYardId: string;
  searchQuery: string;
  userPermission?: EmployeePermission;
  vehicleTypeFilter?: string;
  statusFilter?: string;
  driverFilter?: string;
}

const STATUS_OPTIONS: { value: TowStatus; label: string }[] = [
  { value: 'towed', label: 'Towed' },
  { value: 'docs_pending', label: 'Docs Pending' },
  { value: 'docs_approved', label: 'Docs Approved' },
  { value: 'paid', label: 'Paid' },
  { value: 'released', label: 'Released' },
];

export function TowRecordsList({ 
  towYardId, 
  searchQuery, 
  userPermission = 'viewer',
  vehicleTypeFilter,
  statusFilter,
  driverFilter,
}: TowRecordsListProps) {
  const { user } = useAuth();
  const [records, setRecords] = useState<TowRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingRecord, setEditingRecord] = useState<TowRecord | null>(null);
  const [viewingRecord, setViewingRecord] = useState<TowRecord | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [bulkUpdating, setBulkUpdating] = useState(false);

  const canEdit = userPermission === 'editor' || userPermission === 'admin';

  // Check if a record is locked by someone else
  const isLockedByOther = (record: TowRecord): boolean => {
    if (!record.locked_by_user_id) return false;
    if (record.locked_by_user_id === user?.id) return false;
    // Check if lock has expired (30 minutes)
    if (record.locked_at) {
      const lockTime = new Date(record.locked_at).getTime();
      const now = Date.now();
      if (now - lockTime > 30 * 60 * 1000) return false; // Lock expired
    }
    return true;
  };

  const fetchRecords = async () => {
    setLoading(true);
    let query = supabase
      .from('tow_records')
      .select(`
        *,
        claims (
          id,
          claim_status,
          documents (
            id,
            status
          )
        )
      `)
      .eq('tow_yard_id', towYardId)
      .order('tow_datetime', { ascending: false });

    if (searchQuery) {
      query = query.or(
        `plate_number.ilike.%${searchQuery}%,vin.ilike.%${searchQuery}%,make.ilike.%${searchQuery}%,model.ilike.%${searchQuery}%`
      );
    }

    if (vehicleTypeFilter) {
      query = query.eq('vehicle_type', vehicleTypeFilter);
    }

    if (statusFilter) {
      query = query.eq('status', statusFilter as TowStatus);
    }

    if (driverFilter) {
      if (driverFilter === 'unassigned') {
        query = query.is('driver_user_id', null);
      } else {
        query = query.eq('driver_user_id', driverFilter);
      }
    }

    const { data, error } = await query;

    if (error) {
      console.error('Error fetching records:', error);
    } else {
      // Transform data to include claim info
      const transformedData = (data || []).map((record: any) => {
        const claim = record.claims?.[0];
        return {
          ...record,
          claims: undefined, // Remove the raw claims array
          claim: claim ? {
            id: claim.id,
            claim_status: claim.claim_status,
            pending_docs_count: claim.documents?.filter((d: any) => d.status === 'pending').length || 0,
          } : null,
        };
      });
      setRecords(transformedData);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchRecords();
    setSelectedIds(new Set());

    // Subscribe to realtime changes
    const channel = supabase
      .channel(`tow_records_${towYardId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'tow_records',
          filter: `tow_yard_id=eq.${towYardId}`,
        },
        (payload) => {
          if (payload.eventType === 'INSERT') {
            const newRecord = payload.new as TowRecord;
            setRecords((prev) => [newRecord, ...prev]);
            toast.success('New record added');
          } else if (payload.eventType === 'UPDATE') {
            const updatedRecord = payload.new as TowRecord;
            setRecords((prev) =>
              prev.map((r) => (r.id === updatedRecord.id ? updatedRecord : r))
            );
          } else if (payload.eventType === 'DELETE') {
            const deletedId = payload.old.id as string;
            setRecords((prev) => prev.filter((r) => r.id !== deletedId));
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [towYardId, searchQuery, vehicleTypeFilter, statusFilter, driverFilter]);

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedIds(new Set(records.map((r) => r.id)));
    } else {
      setSelectedIds(new Set());
    }
  };

  const handleSelectOne = (id: string, checked: boolean) => {
    const newSet = new Set(selectedIds);
    if (checked) {
      newSet.add(id);
    } else {
      newSet.delete(id);
    }
    setSelectedIds(newSet);
  };

  const handleBulkStatusUpdate = async (newStatus: TowStatus) => {
    if (selectedIds.size === 0) return;
    
    setBulkUpdating(true);
    const ids = Array.from(selectedIds);
    
    const { error } = await supabase
      .from('tow_records')
      .update({ status: newStatus })
      .in('id', ids);

    if (error) {
      console.error('Error updating statuses:', error);
      toast.error('Failed to update records');
    } else {
      // Log activities
      for (const id of ids) {
        const record = records.find((r) => r.id === id);
        if (record) {
          if (newStatus === 'released') {
            await logRecordReleased(id);
          } else {
            await logStatusChanged(id, record.status, newStatus);
          }
        }
      }
      
      toast.success(`Updated ${ids.length} records to ${newStatus.replace('_', ' ')}`);
      setSelectedIds(new Set());
      fetchRecords();
    }
    setBulkUpdating(false);
  };

  const handleExportCSV = () => {
    const recordsToExport = selectedIds.size > 0 
      ? records.filter((r) => selectedIds.has(r.id))
      : records;

    const headers = ['Plate Number', 'VIN', 'Make', 'Model', 'Color', 'Vehicle Type', 'Driver', 'Status', 'Tow Date', 'Tow Fee', 'Storage Fee', 'Admin Fee', 'Gate Fee', 'Total'];
    
    const csvRows = [
      headers.join(','),
      ...recordsToExport.map((r) => {
        const total = r.tow_fee + r.daily_storage_fee + r.admin_fee + r.gate_fee;
        return [
          r.plate_number || '',
          r.vin || '',
          r.make || '',
          r.model || '',
          r.color || '',
          r.vehicle_type || '',
          r.driver_name || '',
          r.status,
          new Date(r.tow_datetime).toLocaleDateString(),
          r.tow_fee.toFixed(2),
          r.daily_storage_fee.toFixed(2),
          r.admin_fee.toFixed(2),
          r.gate_fee.toFixed(2),
          total.toFixed(2),
        ].map((v) => `"${v}"`).join(',');
      }),
    ];

    const blob = new Blob([csvRows.join('\n')], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tow-records-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    
    toast.success(`Exported ${recordsToExport.length} records`);
  };

  const handleStatusChange = async (recordId: string, oldStatus: string, newStatus: TowStatus) => {
    const { error } = await supabase
      .from('tow_records')
      .update({ status: newStatus })
      .eq('id', recordId);

    if (error) {
      console.error('Error updating status:', error);
    } else {
      setRecords((prev) =>
        prev.map((r) => (r.id === recordId ? { ...r, status: newStatus } : r))
      );
      
      if (newStatus === 'released') {
        await logRecordReleased(recordId);
      } else {
        await logStatusChanged(recordId, oldStatus, newStatus);
      }
    }
  };

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      towed: 'bg-warning/10 text-warning',
      docs_pending: 'bg-info/10 text-info',
      docs_approved: 'bg-accent/10 text-accent',
      paid: 'bg-success/10 text-success',
      released: 'bg-muted text-muted-foreground',
    };

    return (
      <span className={`text-xs px-2 py-1 rounded-full ${styles[status] || styles.towed}`}>
        {status.replace('_', ' ')}
      </span>
    );
  };

  const getVehicleTypeIcon = (type: string | null) => {
    switch (type) {
      case 'motorcycle':
        return <Bike className="w-5 h-5 text-primary" />;
      case 'truck':
      case 'commercial':
      case 'heavy_duty':
        return <Truck className="w-5 h-5 text-primary" />;
      default:
        return <Car className="w-5 h-5 text-primary" />;
    }
  };

  const getVehicleTypeLabel = (type: string | null): string => {
    if (!type) return '';
    return VEHICLE_TYPES[type as VehicleType]?.label || type;
  };

  if (loading) {
    return (
      <div className="bg-card rounded-xl p-8 text-center">
        <div className="animate-pulse text-muted-foreground">Loading records...</div>
      </div>
    );
  }

  if (records.length === 0) {
    return (
      <div className="bg-card rounded-xl p-8 text-center space-y-4">
        <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto">
          <Car className="w-8 h-8 text-muted-foreground" />
        </div>
        <div>
          <p className="font-semibold text-lg">No Records Found</p>
          <p className="text-muted-foreground">
            {searchQuery
              ? 'No vehicles match your search criteria.'
              : 'Add your first tow record to get started.'}
          </p>
        </div>
      </div>
    );
  }

  const allSelected = records.length > 0 && selectedIds.size === records.length;
  const someSelected = selectedIds.size > 0 && selectedIds.size < records.length;

  return (
    <>
      {/* Batch Operations Toolbar */}
      <div className="flex items-center justify-between gap-4 mb-4 flex-wrap">
        <div className="flex items-center gap-2">
          {selectedIds.size > 0 && (
            <span className="text-sm font-medium text-primary">
              {selectedIds.size} selected
            </span>
          )}
        </div>
        
        <div className="flex items-center gap-2 flex-wrap">
          {canEdit && selectedIds.size > 0 && (
            <>
              <Button
                variant="default"
                size="sm"
                onClick={() => handleBulkStatusUpdate('released')}
                disabled={bulkUpdating}
              >
                <CheckCircle className={`w-4 h-4 mr-2 ${bulkUpdating ? 'animate-spin' : ''}`} />
                Mark as Released
              </Button>
              <Select
                onValueChange={(value) => handleBulkStatusUpdate(value as TowStatus)}
                disabled={bulkUpdating}
              >
                <SelectTrigger className="w-[160px]">
                  <RefreshCw className={`w-4 h-4 mr-2 ${bulkUpdating ? 'animate-spin' : ''}`} />
                  <SelectValue placeholder="Change Status" />
                </SelectTrigger>
                <SelectContent>
                  {STATUS_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </>
          )}
          
          <Button variant="outline" size="sm" onClick={handleExportCSV}>
            <Download className="w-4 h-4 mr-2" />
            Export {selectedIds.size > 0 ? `(${selectedIds.size})` : 'All'}
          </Button>
        </div>
      </div>

      <div className="bg-card rounded-xl shadow-card overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-10">
                <Checkbox
                  checked={allSelected}
                  ref={(el) => {
                    if (el) (el as HTMLButtonElement).dataset.state = someSelected ? 'indeterminate' : allSelected ? 'checked' : 'unchecked';
                  }}
                  onCheckedChange={handleSelectAll}
                />
              </TableHead>
              <TableHead>Vehicle</TableHead>
              <TableHead>Plate/VIN</TableHead>
              <TableHead>Driver</TableHead>
              <TableHead>Tow Date</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Claim</TableHead>
              <TableHead className="text-right">Total Fees</TableHead>
              <TableHead className="w-10"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {records.map((record) => {
              const totalFees =
                record.tow_fee +
                record.daily_storage_fee +
                record.admin_fee +
                record.gate_fee;

              return (
                <TableRow 
                  key={record.id} 
                  data-state={selectedIds.has(record.id) ? 'selected' : undefined}
                  className="cursor-pointer hover:bg-muted/50"
                  onClick={() => setViewingRecord(record)}
                >
                  <TableCell onClick={(e) => e.stopPropagation()}>
                    <Checkbox
                      checked={selectedIds.has(record.id)}
                      onCheckedChange={(checked) => handleSelectOne(record.id, !!checked)}
                    />
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                        {getVehicleTypeIcon(record.vehicle_type)}
                      </div>
                      <div>
                        <p className="font-medium">
                          {record.make} {record.model}
                        </p>
                        <div className="flex items-center gap-2">
                          {record.color && (
                            <span className="text-xs text-muted-foreground">{record.color}</span>
                          )}
                          {record.vehicle_type && (
                            <span className="text-xs bg-muted px-1.5 py-0.5 rounded">
                              {getVehicleTypeLabel(record.vehicle_type)}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <p className="font-mono text-sm">
                      {record.plate_number || record.vin?.slice(0, 11) + '...'}
                    </p>
                  </TableCell>
                  <TableCell>
                    {record.driver_name ? (
                      <div className="flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-muted-foreground" />
                        <span className="text-sm">{record.driver_name}</span>
                      </div>
                    ) : (
                      <span className="text-xs text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell>
                    {new Date(record.tow_datetime).toLocaleDateString()}
                  </TableCell>
                  <TableCell>{getStatusBadge(record.status)}</TableCell>
                  <TableCell>
                    {record.claim ? (
                      <div className="flex items-center gap-2">
                        {record.claim.claim_status === 'docs_submitted' && record.claim.pending_docs_count > 0 ? (
                          <a 
                            href="/operator/documents" 
                            className="inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full bg-warning/10 text-warning hover:bg-warning/20 transition-colors"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <AlertCircle className="w-3 h-3" />
                            {record.claim.pending_docs_count} docs to review
                          </a>
                        ) : record.claim.claim_status === 'docs_approved' ? (
                          <span className="inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full bg-success/10 text-success">
                            <CheckCircle className="w-3 h-3" />
                            Approved
                          </span>
                        ) : record.claim.claim_status === 'payment_pending' ? (
                          <span className="inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full bg-info/10 text-info">
                            <FileText className="w-3 h-3" />
                            Payment Pending
                          </span>
                        ) : record.claim.claim_status === 'complete' ? (
                          <span className="inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full bg-muted text-muted-foreground">
                            <CheckCircle className="w-3 h-3" />
                            Complete
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full bg-muted text-muted-foreground">
                            <FileText className="w-3 h-3" />
                            {record.claim.claim_status.replace('_', ' ')}
                          </span>
                        )}
                      </div>
                    ) : (
                      <span className="text-xs text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell className="text-right font-medium">
                    ${totalFees.toFixed(2)}
                  </TableCell>
                  <TableCell onClick={(e) => e.stopPropagation()}>
                    <div className="flex items-center gap-2">
                      {/* Lock indicator */}
                      {isLockedByOther(record) && (
                        <Tooltip>
                          <TooltipTrigger>
                            <div className="flex items-center gap-1 text-amber-600 dark:text-amber-400">
                              <Lock className="w-3.5 h-3.5" />
                            </div>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>{record.locked_by_name} is working on this</p>
                          </TooltipContent>
                        </Tooltip>
                      )}
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreVertical className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => setViewingRecord(record)}>
                            <Eye className="w-4 h-4 mr-2" />
                            View Details
                          </DropdownMenuItem>
                          {canEdit && !isLockedByOther(record) && (
                            <DropdownMenuItem onClick={() => setEditingRecord(record)}>
                              <Edit className="w-4 h-4 mr-2" />
                              Edit Record
                            </DropdownMenuItem>
                          )}
                          {canEdit && isLockedByOther(record) && (
                            <DropdownMenuItem disabled className="text-muted-foreground">
                              <Lock className="w-4 h-4 mr-2" />
                              Locked by {record.locked_by_name}
                            </DropdownMenuItem>
                          )}
                          {canEdit && record.status !== 'released' && !isLockedByOther(record) && (
                            <DropdownMenuItem
                              onClick={() => handleStatusChange(record.id, record.status, 'released')}
                            >
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Mark as Released
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      {editingRecord && (
        <EditRecordDialog
          isOpen={!!editingRecord}
          onClose={() => setEditingRecord(null)}
          record={editingRecord}
          onSuccess={() => {
            setEditingRecord(null);
            fetchRecords();
          }}
        />
      )}

      {viewingRecord && (
        <RecordDetailsDialog
          isOpen={!!viewingRecord}
          onClose={() => setViewingRecord(null)}
          record={viewingRecord}
          onLockChange={fetchRecords}
        />
      )}
    </>
  );
}
