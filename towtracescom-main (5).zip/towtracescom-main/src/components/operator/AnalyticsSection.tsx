import { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  DollarSign, 
  Car, 
  Calendar,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar
} from 'recharts';
import { supabase } from '@/integrations/supabase/client';
import { VehicleTypeChart } from './VehicleTypeChart';
import { DisputeStatsChart } from './DisputeStatsChart';
import { DriverStatsChart } from './DriverStatsChart';

interface AnalyticsSectionProps {
  towYardId: string | null;
}

interface RevenueData {
  date: string;
  revenue: number;
  payments: number;
}

interface Stats {
  totalRevenue: number;
  totalPayments: number;
  averagePayment: number;
  revenueChange: number;
}

export function AnalyticsSection({ towYardId }: AnalyticsSectionProps) {
  const [revenueData, setRevenueData] = useState<RevenueData[]>([]);
  const [stats, setStats] = useState<Stats>({
    totalRevenue: 0,
    totalPayments: 0,
    averagePayment: 0,
    revenueChange: 0,
  });
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d'>('30d');

  useEffect(() => {
    if (!towYardId) return;

    const fetchAnalytics = async () => {
      setLoading(true);

      const daysAgo = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 90;
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - daysAgo);

      const previousStartDate = new Date(startDate);
      previousStartDate.setDate(previousStartDate.getDate() - daysAgo);

      // Fetch payments for the selected yard
      const { data: payments, error } = await supabase
        .from('payments')
        .select('amount, created_at, status')
        .eq('status', 'succeeded')
        .gte('created_at', startDate.toISOString());

      if (error) {
        console.error('Error fetching payments:', error);
        setLoading(false);
        return;
      }

      // Fetch previous period payments for comparison
      const { data: previousPayments } = await supabase
        .from('payments')
        .select('amount')
        .eq('status', 'succeeded')
        .gte('created_at', previousStartDate.toISOString())
        .lt('created_at', startDate.toISOString());

      const currentRevenue = payments?.reduce((sum, p) => sum + Number(p.amount), 0) || 0;
      const previousRevenue = previousPayments?.reduce((sum, p) => sum + Number(p.amount), 0) || 0;
      const revenueChange = previousRevenue > 0 
        ? ((currentRevenue - previousRevenue) / previousRevenue) * 100 
        : 0;

      setStats({
        totalRevenue: currentRevenue,
        totalPayments: payments?.length || 0,
        averagePayment: payments?.length ? currentRevenue / payments.length : 0,
        revenueChange,
      });

      // Group by date for chart
      const groupedData: Record<string, { revenue: number; payments: number }> = {};
      
      for (let i = 0; i < daysAgo; i++) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dateStr = date.toISOString().split('T')[0];
        groupedData[dateStr] = { revenue: 0, payments: 0 };
      }

      payments?.forEach((payment) => {
        const dateStr = payment.created_at.split('T')[0];
        if (groupedData[dateStr]) {
          groupedData[dateStr].revenue += Number(payment.amount);
          groupedData[dateStr].payments += 1;
        }
      });

      const chartData = Object.entries(groupedData)
        .map(([date, data]) => ({
          date: new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
          revenue: data.revenue,
          payments: data.payments,
        }))
        .reverse();

      setRevenueData(chartData);
      setLoading(false);
    };

    fetchAnalytics();
  }, [towYardId, timeRange]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="bg-card rounded-xl p-5 shadow-card animate-pulse">
              <div className="h-16 bg-muted rounded" />
            </div>
          ))}
        </div>
        <div className="bg-card rounded-xl p-6 shadow-card animate-pulse">
          <div className="h-64 bg-muted rounded" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Time Range Selector */}
      <div className="flex gap-2">
        {(['7d', '30d', '90d'] as const).map((range) => (
          <button
            key={range}
            onClick={() => setTimeRange(range)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              timeRange === range
                ? 'bg-accent text-accent-foreground'
                : 'bg-muted text-muted-foreground hover:bg-muted/80'
            }`}
          >
            {range === '7d' ? 'Last 7 Days' : range === '30d' ? 'Last 30 Days' : 'Last 90 Days'}
          </button>
        ))}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-card rounded-xl p-5 shadow-card">
          <div className="flex items-center justify-between">
            <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-success" />
            </div>
            <div className={`flex items-center gap-1 text-sm ${
              stats.revenueChange >= 0 ? 'text-success' : 'text-destructive'
            }`}>
              {stats.revenueChange >= 0 ? (
                <ArrowUpRight className="w-4 h-4" />
              ) : (
                <ArrowDownRight className="w-4 h-4" />
              )}
              {Math.abs(stats.revenueChange).toFixed(1)}%
            </div>
          </div>
          <p className="text-2xl font-bold mt-3">{formatCurrency(stats.totalRevenue)}</p>
          <p className="text-sm text-muted-foreground">Total Revenue</p>
        </div>

        <div className="bg-card rounded-xl p-5 shadow-card">
          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
            <TrendingUp className="w-6 h-6 text-primary" />
          </div>
          <p className="text-2xl font-bold mt-3">{stats.totalPayments}</p>
          <p className="text-sm text-muted-foreground">Total Payments</p>
        </div>

        <div className="bg-card rounded-xl p-5 shadow-card">
          <div className="w-12 h-12 bg-info/10 rounded-lg flex items-center justify-center">
            <DollarSign className="w-6 h-6 text-info" />
          </div>
          <p className="text-2xl font-bold mt-3">{formatCurrency(stats.averagePayment)}</p>
          <p className="text-sm text-muted-foreground">Average Payment</p>
        </div>

        <div className="bg-card rounded-xl p-5 shadow-card">
          <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center">
            <Calendar className="w-6 h-6 text-warning" />
          </div>
          <p className="text-2xl font-bold mt-3">
            {revenueData.length > 0 
              ? formatCurrency(stats.totalRevenue / revenueData.length) 
              : '$0'}
          </p>
          <p className="text-sm text-muted-foreground">Daily Average</p>
        </div>
      </div>

      {/* Revenue Chart */}
      <div className="bg-card rounded-xl p-6 shadow-card">
        <h3 className="font-display text-lg font-semibold mb-4">Revenue Trend</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis 
                dataKey="date" 
                className="text-xs fill-muted-foreground"
                tick={{ fontSize: 12 }}
              />
              <YAxis 
                className="text-xs fill-muted-foreground"
                tick={{ fontSize: 12 }}
                tickFormatter={(value) => `$${value}`}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px',
                }}
                formatter={(value: number) => [formatCurrency(value), 'Revenue']}
              />
              <Line 
                type="monotone" 
                dataKey="revenue" 
                stroke="hsl(var(--accent))" 
                strokeWidth={2}
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Payments Chart and Vehicle Type Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-card rounded-xl p-6 shadow-card">
          <h3 className="font-display text-lg font-semibold mb-4">Payments by Day</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis 
                  dataKey="date" 
                  className="text-xs fill-muted-foreground"
                  tick={{ fontSize: 12 }}
                />
                <YAxis 
                  className="text-xs fill-muted-foreground"
                  tick={{ fontSize: 12 }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                  }}
                  formatter={(value: number) => [value, 'Payments']}
                />
                <Bar 
                  dataKey="payments" 
                  fill="hsl(var(--primary))" 
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <VehicleTypeChart towYardId={towYardId} />
      </div>

      {/* Driver Statistics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <DriverStatsChart towYardId={towYardId} timeRange={timeRange} />
        
        <div className="bg-card rounded-xl p-6 shadow-card">
          <h3 className="font-display text-lg font-semibold mb-4">Performance Insights</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
              <div>
                <p className="text-sm text-muted-foreground">Avg. Tows per Driver</p>
                <p className="text-xl font-bold">
                  {stats.totalPayments > 0 
                    ? Math.round(stats.totalPayments / Math.max(1, stats.totalPayments))
                    : 0}
                </p>
              </div>
            </div>
            <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
              <div>
                <p className="text-sm text-muted-foreground">Revenue per Payment</p>
                <p className="text-xl font-bold">{formatCurrency(stats.averagePayment)}</p>
              </div>
            </div>
            <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg">
              <div>
                <p className="text-sm text-muted-foreground">Daily Average Revenue</p>
                <p className="text-xl font-bold">
                  {revenueData.length > 0 
                    ? formatCurrency(stats.totalRevenue / revenueData.length) 
                    : '$0'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Dispute Statistics */}
      <div className="mt-8">
        <h3 className="font-display text-xl font-semibold mb-4">Dispute Analytics</h3>
        <DisputeStatsChart towYardId={towYardId} timeRange={timeRange} />
      </div>
    </div>
  );
}
