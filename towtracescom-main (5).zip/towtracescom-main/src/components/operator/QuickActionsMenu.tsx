import { useState, useRef, useCallback } from 'react';
import { Plus, FileText, Calculator, AlertTriangle, Activity, Search, ChevronUp, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerDescription,
} from '@/components/ui/drawer';
import { useIsMobile } from '@/hooks/use-mobile';
import { cn } from '@/lib/utils';

interface QuickAction {
  icon: React.ReactNode;
  label: string;
  description: string;
  onClick: () => void;
  variant?: 'default' | 'accent' | 'warning';
}

interface QuickActionsMenuProps {
  onAddRecord: () => void;
  onOpenFeeCalculator: () => void;
  onNavigateToDisputes: () => void;
  onNavigateToActivity: () => void;
  onNavigateToRecords: () => void;
}

const SWIPE_THRESHOLD = 50; // Minimum swipe distance in pixels

export function QuickActionsMenu({
  onAddRecord,
  onOpenFeeCalculator,
  onNavigateToDisputes,
  onNavigateToActivity,
  onNavigateToRecords,
}: QuickActionsMenuProps) {
  const touchStartY = useRef<number | null>(null);
  const touchStartTime = useRef<number | null>(null);
  const [isOpen, setIsOpen] = useState(false);
  const [isHinting, setIsHinting] = useState(false);
  const isMobile = useIsMobile();

  // Handle touch start
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
    touchStartTime.current = Date.now();
    setIsHinting(true);
  }, []);

  // Handle touch move for visual feedback
  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (touchStartY.current === null) return;
    
    const currentY = e.touches[0].clientY;
    const deltaY = touchStartY.current - currentY;
    
    // If swiping up significantly, show hint
    if (deltaY > 20) {
      setIsHinting(true);
    }
  }, []);

  // Handle touch end - detect swipe up
  const handleTouchEnd = useCallback((e: React.TouchEvent) => {
    setIsHinting(false);
    
    if (touchStartY.current === null || touchStartTime.current === null) return;

    const touchEndY = e.changedTouches[0].clientY;
    const deltaY = touchStartY.current - touchEndY;
    const deltaTime = Date.now() - touchStartTime.current;
    
    // Detect swipe up: moved up enough and was quick enough (under 300ms)
    if (deltaY > SWIPE_THRESHOLD && deltaTime < 300) {
      setIsOpen(true);
    }
    
    touchStartY.current = null;
    touchStartTime.current = null;
  }, []);

  // Only render on mobile
  if (!isMobile) return null;

  const quickActions: QuickAction[] = [
    {
      icon: <FileText className="w-5 h-5" />,
      label: 'Add Tow Record',
      description: 'Create a new tow record entry',
      onClick: () => {
        setIsOpen(false);
        onAddRecord();
      },
      variant: 'accent',
    },
    {
      icon: <Search className="w-5 h-5" />,
      label: 'View Records',
      description: 'Browse all tow records',
      onClick: () => {
        setIsOpen(false);
        onNavigateToRecords();
      },
    },
    {
      icon: <Calculator className="w-5 h-5" />,
      label: 'Fee Calculator',
      description: 'Calculate total fees due',
      onClick: () => {
        setIsOpen(false);
        onOpenFeeCalculator();
      },
    },
    {
      icon: <AlertTriangle className="w-5 h-5" />,
      label: 'View Disputes',
      description: 'Check pending disputes',
      onClick: () => {
        setIsOpen(false);
        onNavigateToDisputes();
      },
      variant: 'warning',
    },
    {
      icon: <Activity className="w-5 h-5" />,
      label: 'Activity Log',
      description: 'View recent activity',
      onClick: () => {
        setIsOpen(false);
        onNavigateToActivity();
      },
    },
  ];

  const getVariantStyles = (variant?: string) => {
    switch (variant) {
      case 'accent':
        return 'bg-accent/10 border-accent/20 hover:bg-accent/20';
      case 'warning':
        return 'bg-orange-500/10 border-orange-500/20 hover:bg-orange-500/20';
      default:
        return 'bg-muted/50 border-border hover:bg-muted';
    }
  };

  const getIconStyles = (variant?: string) => {
    switch (variant) {
      case 'accent':
        return 'text-accent';
      case 'warning':
        return 'text-orange-500';
      default:
        return 'text-foreground';
    }
  };

  return (
    <>
      {/* Swipe Zone + Floating Action Button */}
      <div
        className="fixed bottom-0 right-0 z-50 p-4"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* Swipe hint indicator */}
        <div
          className={cn(
            'absolute -top-8 left-1/2 -translate-x-1/2 flex flex-col items-center transition-all duration-200',
            isHinting ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'
          )}
        >
          <ChevronUp className="w-5 h-5 text-accent animate-bounce" />
          <span className="text-xs text-muted-foreground whitespace-nowrap">Swipe up</span>
        </div>

        {/* FAB Button */}
        <Button
          onClick={() => setIsOpen(true)}
          className={cn(
            'h-14 w-14 rounded-full shadow-lg',
            'bg-accent hover:bg-accent/90 text-accent-foreground',
            'transition-all duration-200 hover:scale-105 active:scale-95',
            isOpen && 'rotate-45',
            isHinting && 'scale-110'
          )}
          size="icon"
        >
          <Plus className="w-6 h-6" />
          <span className="sr-only">Quick Actions (tap or swipe up)</span>
        </Button>
      </div>

      {/* Actions Drawer */}
      <Drawer open={isOpen} onOpenChange={setIsOpen}>
        <DrawerContent className="focus:outline-none">
          {/* Enhanced drag handle with pull-down hint */}
          <div className="flex flex-col items-center pt-2 pb-1">
            <div className="w-12 h-1.5 rounded-full bg-muted-foreground/30" />
            <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
              <ChevronDown className="w-3 h-3" />
              <span>Pull down to close</span>
            </div>
          </div>

          <DrawerHeader className="text-left pt-2">
            <DrawerTitle className="flex items-center gap-2">
              <Plus className="w-5 h-5 text-accent" />
              Quick Actions
            </DrawerTitle>
            <DrawerDescription>
              Common operator tasks at your fingertips
            </DrawerDescription>
          </DrawerHeader>
          
          <div className="px-4 pb-8 space-y-3">
            {quickActions.map((action, index) => (
              <button
                key={index}
                onClick={action.onClick}
                className={cn(
                  'w-full flex items-center gap-4 p-4 rounded-xl border transition-all',
                  'active:scale-[0.98]',
                  getVariantStyles(action.variant)
                )}
              >
                <div className={cn(
                  'flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center',
                  action.variant === 'accent' && 'bg-accent/20',
                  action.variant === 'warning' && 'bg-orange-500/20',
                  !action.variant && 'bg-background'
                )}>
                  <span className={getIconStyles(action.variant)}>
                    {action.icon}
                  </span>
                </div>
                <div className="flex-1 text-left">
                  <p className="font-medium text-foreground">{action.label}</p>
                  <p className="text-sm text-muted-foreground">{action.description}</p>
                </div>
              </button>
            ))}
          </div>
        </DrawerContent>
      </Drawer>
    </>
  );
}
