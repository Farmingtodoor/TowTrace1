import { format } from 'date-fns';
import { Building2, CheckCircle, XCircle, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { TowYard } from './TowYardManagementTable';

interface PendingApprovalsCardProps {
  yards: TowYard[];
  onApprove: (yardId: string, approve: boolean) => void;
  onViewDetails: (yard: TowYard) => void;
}

export function PendingApprovalsCard({ yards, onApprove, onViewDetails }: PendingApprovalsCardProps) {
  const pendingYards = yards.filter((y) => !y.is_approved);

  if (pendingYards.length === 0) {
    return (
      <div className="bg-card rounded-xl border shadow-card p-6">
        <div className="flex items-center gap-2 mb-4">
          <Clock className="w-5 h-5 text-muted-foreground" />
          <h3 className="font-semibold">Pending Approvals</h3>
        </div>
        <div className="text-center py-8 text-muted-foreground">
          <CheckCircle className="w-12 h-12 mx-auto mb-3 text-success/50" />
          <p className="font-medium">All caught up!</p>
          <p className="text-sm">No pending approvals at this time.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-xl border shadow-card">
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center gap-2">
          <Clock className="w-5 h-5 text-warning" />
          <h3 className="font-semibold">Pending Approvals</h3>
        </div>
        <Badge variant="outline" className="text-warning border-warning/30">
          {pendingYards.length} pending
        </Badge>
      </div>
      <ScrollArea className="h-[300px]">
        <div className="p-4 space-y-3">
          {pendingYards.map((yard) => (
            <div
              key={yard.id}
              className="p-4 rounded-lg border bg-muted/30 hover:bg-muted/50 transition-colors"
            >
              <div className="flex items-start justify-between gap-3">
                <div
                  className="flex items-start gap-3 flex-1 cursor-pointer"
                  onClick={() => onViewDetails(yard)}
                >
                  <div className="h-10 w-10 rounded-lg bg-warning/10 flex items-center justify-center shrink-0">
                    <Building2 className="w-5 h-5 text-warning" />
                  </div>
                  <div className="min-w-0">
                    <p className="font-semibold truncate">{yard.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {yard.city}, {yard.state_province}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Applied {format(new Date(yard.created_at), 'MMM d, yyyy')}
                    </p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-8 text-destructive border-destructive/30 hover:bg-destructive/10"
                    onClick={() => onApprove(yard.id, false)}
                  >
                    <XCircle className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    className="h-8 bg-success hover:bg-success/90"
                    onClick={() => onApprove(yard.id, true)}
                  >
                    <CheckCircle className="w-4 h-4 mr-1" />
                    Approve
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
