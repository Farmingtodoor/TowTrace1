import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { FileDown, Loader2 } from 'lucide-react';
import { downloadReceipt, generateReceiptNumber, type ReceiptData } from '@/lib/receiptGenerator';
import { toast } from 'sonner';

interface DownloadReceiptButtonProps {
  claimId: string;
  paymentDate: Date;
  vehicleInfo: {
    make?: string;
    model?: string;
    year?: string;
    plateNumber?: string;
    vin?: string;
    color?: string;
  };
  towYard: {
    name: string;
    address: string;
    city: string;
    state: string;
    phone: string;
  };
  fees: {
    towFee: number;
    dailyStorageFee: number;
    daysStored: number;
    storageFee: number;
    adminFee: number;
    gateFee: number;
    subtotal: number;
    serviceFee: number;
    total: number;
  };
  variant?: 'default' | 'outline' | 'secondary' | 'ghost';
  size?: 'default' | 'sm' | 'lg' | 'icon';
  className?: string;
}

export function DownloadReceiptButton({
  claimId,
  paymentDate,
  vehicleInfo,
  towYard,
  fees,
  variant = 'outline',
  size = 'default',
  className,
}: DownloadReceiptButtonProps) {
  const [isGenerating, setIsGenerating] = useState(false);

  const handleDownload = async () => {
    setIsGenerating(true);
    
    try {
      const receiptData: ReceiptData = {
        receiptNumber: generateReceiptNumber(claimId, paymentDate),
        paymentDate,
        vehicleInfo,
        towYard,
        fees,
      };

      // Small delay for UX
      await new Promise((resolve) => setTimeout(resolve, 300));
      
      downloadReceipt(receiptData);
      
      toast.success('Receipt downloaded!', {
        description: `Saved as TowTrace-Receipt-${receiptData.receiptNumber}.pdf`,
      });
    } catch (error) {
      console.error('Error generating receipt:', error);
      toast.error('Failed to generate receipt', {
        description: 'Please try again',
      });
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <Button
      variant={variant}
      size={size}
      onClick={handleDownload}
      disabled={isGenerating}
      className={className}
    >
      {isGenerating ? (
        <>
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          Generating...
        </>
      ) : (
        <>
          <FileDown className="w-4 h-4 mr-2" />
          Download Receipt
        </>
      )}
    </Button>
  );
}
