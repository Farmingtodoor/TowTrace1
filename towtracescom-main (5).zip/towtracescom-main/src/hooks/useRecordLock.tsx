import { useState, useCallback, useEffect, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';

interface LockStatus {
  locked: boolean;
  lockedByUserId?: string;
  lockedByName?: string;
  lockedAt?: string;
  isOwnLock: boolean;
}

interface UseRecordLockOptions {
  autoRefresh?: boolean;
  refreshInterval?: number; // in milliseconds
  lockTimeoutMinutes?: number;
}

export function useRecordLock(
  recordId: string | null,
  options: UseRecordLockOptions = {}
) {
  const { autoRefresh = true, refreshInterval = 30000, lockTimeoutMinutes = 30 } = options;
  const { user } = useAuth();
  const { toast } = useToast();
  const [lockStatus, setLockStatus] = useState<LockStatus>({
    locked: false,
    isOwnLock: false,
  });
  const [isLoading, setIsLoading] = useState(false);
  const refreshIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const [userName, setUserName] = useState<string>('Unknown User');

  // Fetch current user's name for lock display
  useEffect(() => {
    const fetchUserName = async () => {
      if (!user) return;
      
      const { data } = await supabase
        .from('profiles')
        .select('first_name, full_name')
        .eq('user_id', user.id)
        .single();
      
      if (data) {
        setUserName(data.first_name || data.full_name?.split(' ')[0] || user.email?.split('@')[0] || 'Unknown User');
      }
    };
    
    fetchUserName();
  }, [user]);

  // Check lock status
  const checkLock = useCallback(async () => {
    if (!recordId) return;
    
    try {
      const { data, error } = await supabase.rpc('check_record_lock', {
        _record_id: recordId,
        _lock_timeout_minutes: lockTimeoutMinutes,
      });
      
      if (error) throw error;
      
      const result = data as any;
      setLockStatus({
        locked: result.locked,
        lockedByUserId: result.locked_by_user_id,
        lockedByName: result.locked_by_name,
        lockedAt: result.locked_at,
        isOwnLock: result.locked && result.locked_by_user_id === user?.id,
      });
    } catch (error) {
      console.error('Error checking lock status:', error);
    }
  }, [recordId, user?.id, lockTimeoutMinutes]);

  // Acquire lock
  const acquireLock = useCallback(async (): Promise<boolean> => {
    if (!recordId || !user) return false;
    
    setIsLoading(true);
    try {
      const { data, error } = await supabase.rpc('acquire_record_lock', {
        _record_id: recordId,
        _user_id: user.id,
        _user_name: userName,
        _lock_timeout_minutes: lockTimeoutMinutes,
      });
      
      if (error) throw error;
      
      const result = data as any;
      
      if (result.success) {
        setLockStatus({
          locked: true,
          lockedByUserId: user.id,
          lockedByName: userName,
          lockedAt: new Date().toISOString(),
          isOwnLock: true,
        });
        toast({
          title: 'Record locked',
          description: 'You now have exclusive access to this record.',
        });
        return true;
      } else {
        toast({
          title: 'Cannot lock record',
          description: `${result.locked_by} is currently working on this record.`,
          variant: 'destructive',
        });
        await checkLock();
        return false;
      }
    } catch (error) {
      console.error('Error acquiring lock:', error);
      toast({
        title: 'Error',
        description: 'Failed to lock the record. Please try again.',
        variant: 'destructive',
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  }, [recordId, user, userName, lockTimeoutMinutes, toast, checkLock]);

  // Release lock
  const releaseLock = useCallback(async (force = false): Promise<boolean> => {
    if (!recordId || !user) return false;
    
    setIsLoading(true);
    try {
      const { data, error } = await supabase.rpc('release_record_lock', {
        _record_id: recordId,
        _user_id: user.id,
        _force: force,
      });
      
      if (error) throw error;
      
      const result = data as any;
      
      if (result.success) {
        setLockStatus({
          locked: false,
          isOwnLock: false,
        });
        toast({
          title: 'Record unlocked',
          description: 'Other team members can now work on this record.',
        });
        return true;
      } else {
        toast({
          title: 'Cannot unlock record',
          description: result.error,
          variant: 'destructive',
        });
        return false;
      }
    } catch (error) {
      console.error('Error releasing lock:', error);
      toast({
        title: 'Error',
        description: 'Failed to unlock the record. Please try again.',
        variant: 'destructive',
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  }, [recordId, user, toast]);

  // Refresh lock (extend timeout)
  const refreshLock = useCallback(async () => {
    if (!lockStatus.isOwnLock || !recordId || !user) return;
    
    try {
      await supabase.rpc('acquire_record_lock', {
        _record_id: recordId,
        _user_id: user.id,
        _user_name: userName,
        _lock_timeout_minutes: lockTimeoutMinutes,
      });
    } catch (error) {
      console.error('Error refreshing lock:', error);
    }
  }, [lockStatus.isOwnLock, recordId, user, userName, lockTimeoutMinutes]);

  // Initial check and auto-refresh setup
  useEffect(() => {
    if (!recordId) return;
    
    checkLock();
    
    if (autoRefresh) {
      refreshIntervalRef.current = setInterval(() => {
        if (lockStatus.isOwnLock) {
          refreshLock();
        } else {
          checkLock();
        }
      }, refreshInterval);
    }
    
    return () => {
      if (refreshIntervalRef.current) {
        clearInterval(refreshIntervalRef.current);
      }
    };
  }, [recordId, autoRefresh, refreshInterval, checkLock, refreshLock, lockStatus.isOwnLock]);

  // Release lock on unmount if we own it
  useEffect(() => {
    const currentRecordId = recordId;
    const currentUserId = user?.id;
    const hasOwnLock = lockStatus.isOwnLock;
    
    return () => {
      if (hasOwnLock && currentRecordId && currentUserId) {
        // Fire and forget - release lock when component unmounts
        const releasePromise = supabase.rpc('release_record_lock', {
          _record_id: currentRecordId,
          _user_id: currentUserId,
          _force: false,
        });
        Promise.resolve(releasePromise).catch(console.error);
      }
    };
  }, [lockStatus.isOwnLock, recordId, user?.id]);

  return {
    lockStatus,
    isLoading,
    acquireLock,
    releaseLock,
    refreshLock,
    checkLock,
    canEdit: !lockStatus.locked || lockStatus.isOwnLock,
  };
}
