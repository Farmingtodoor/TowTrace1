import { useState, useCallback } from 'react';
import { decodeVIN, mapBodyClassToVehicleType, type DecodedVehicle } from '@/lib/vinDecoder';
import { toast } from 'sonner';

interface UseVINDecoderResult {
  decode: (vin: string) => Promise<DecodedVehicle | null>;
  isDecoding: boolean;
  decodedData: DecodedVehicle | null;
  error: string | null;
  reset: () => void;
}

export function useVINDecoder(): UseVINDecoderResult {
  const [isDecoding, setIsDecoding] = useState(false);
  const [decodedData, setDecodedData] = useState<DecodedVehicle | null>(null);
  const [error, setError] = useState<string | null>(null);

  const decode = useCallback(async (vin: string): Promise<DecodedVehicle | null> => {
    if (!vin || vin.length !== 17) {
      setError('VIN must be exactly 17 characters');
      return null;
    }

    setIsDecoding(true);
    setError(null);

    try {
      const result = await decodeVIN(vin);
      
      if (result) {
        setDecodedData(result);
        toast.success('Vehicle info decoded!', {
          description: `${result.year || ''} ${result.make || ''} ${result.model || ''}`.trim(),
        });
        return result;
      } else {
        setError('Could not decode VIN. Please verify it is correct.');
        toast.error('VIN decode failed', {
          description: 'Unable to retrieve vehicle information',
        });
        return null;
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      setError(message);
      toast.error('VIN decode error', { description: message });
      return null;
    } finally {
      setIsDecoding(false);
    }
  }, []);

  const reset = useCallback(() => {
    setDecodedData(null);
    setError(null);
  }, []);

  return {
    decode,
    isDecoding,
    decodedData,
    error,
    reset,
  };
}

export { mapBodyClassToVehicleType };
