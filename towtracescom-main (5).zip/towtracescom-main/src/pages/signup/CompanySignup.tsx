import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  Building2,
  MapPin,
  Loader2,
  CheckCircle,
  TrendingUp,
  Shield,
  Clock,
  CreditCard,
  Users,
  BarChart3,
  Settings,
} from 'lucide-react';
import { PageHeader } from '@/components/layout/PageHeader';
import { PageFooter } from '@/components/layout/PageFooter';
import { AuthModal } from '@/components/auth/AuthModal';
import { EnterpriseContactModal } from '@/components/EnterpriseContactModal';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { US_STATES, CA_PROVINCES } from '@/data/regions';

const baseSchema = z.object({
  // Account fields (only validated for new users - will check at runtime)
  accountEmail: z.string().optional(),
  password: z.string().optional(),
  confirmPassword: z.string().optional(),
  // Company fields
  companyName: z.string().min(2, 'Company name is required'),
  address: z.string().min(5, 'Address is required'),
  city: z.string().min(2, 'City is required'),
  stateProvince: z.string().min(2, 'State/Province is required'),
  postalCode: z.string().min(3, 'Postal code is required'),
  country: z.enum(['US', 'CA']),
  phone: z.string().min(10, 'Valid phone number required'),
  companyEmail: z.string().email('Valid company email required'),
  acceptsCards: z.boolean(),
  acceptsCash: z.boolean(),
  acceptsInApp: z.boolean(),
});

type FormData = z.infer<typeof baseSchema>;

export default function CompanySignup() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const { toast } = useToast();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showEnterpriseModal, setShowEnterpriseModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isAnnual, setIsAnnual] = useState(false);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    trigger,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(baseSchema),
    defaultValues: {
      country: 'US',
      stateProvince: '',
      acceptsCards: true,
      acceptsCash: true,
      acceptsInApp: false,
      accountEmail: '',
      password: '',
      confirmPassword: '',
      companyEmail: '',
    },
  });

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const isValid = await trigger();
    if (!isValid) {
      toast({
        title: 'Validation Error',
        description: 'Please fill in all required fields.',
        variant: 'destructive',
      });
      return;
    }
    handleSubmit(onSubmit)();
  };

  const country = watch('country');
  const regions = country === 'US' ? US_STATES : CA_PROVINCES;

  const onSubmit = async (data: FormData) => {
    setIsSubmitting(true);

    let userId = user?.id;

    // If user is not logged in, validate and create account first
    if (!user) {
      // Validate account fields
      if (!data.accountEmail || !data.accountEmail.includes('@')) {
        toast({
          title: 'Validation Error',
          description: 'Please enter a valid email address.',
          variant: 'destructive',
        });
        setIsSubmitting(false);
        return;
      }

      if (!data.password || data.password.length < 8) {
        toast({
          title: 'Validation Error',
          description: 'Password must be at least 8 characters.',
          variant: 'destructive',
        });
        setIsSubmitting(false);
        return;
      }

      if (data.password !== data.confirmPassword) {
        toast({
          title: 'Validation Error',
          description: "Passwords don't match.",
          variant: 'destructive',
        });
        setIsSubmitting(false);
        return;
      }

      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: data.accountEmail,
        password: data.password,
        options: {
          emailRedirectTo: window.location.origin,
        },
      });

      if (authError) {
        console.error('Error creating account:', authError);
        toast({
          title: 'Account Creation Failed',
          description: authError.message,
          variant: 'destructive',
        });
        setIsSubmitting(false);
        return;
      }

      if (!authData.user) {
        toast({
          title: 'Error',
          description: 'Failed to create account. Please try again.',
          variant: 'destructive',
        });
        setIsSubmitting(false);
        return;
      }

      userId = authData.user.id;

      // Wait briefly for session to be fully established
      await new Promise(resolve => setTimeout(resolve, 500));
    }

    if (!userId) {
      toast({
        title: 'Error',
        description: 'Unable to create account. Please try again.',
        variant: 'destructive',
      });
      setIsSubmitting(false);
      return;
    }

    // Build payment methods array
    const paymentMethods: string[] = [];
    if (data.acceptsCash) paymentMethods.push('Cash');
    if (data.acceptsCards) paymentMethods.push('Credit Card');

    // Use edge function to register company (bypasses RLS timing issues)
    const { data: result, error: fnError } = await supabase.functions.invoke('register-tow-company', {
      body: {
        userId,
        companyName: data.companyName,
        address: data.address,
        city: data.city,
        stateProvince: data.stateProvince,
        postalCode: data.postalCode,
        country: data.country,
        phone: data.phone,
        email: data.companyEmail,
        paymentMethods,
        allowsInAppPayment: data.acceptsInApp,
      },
    });

    if (fnError || (result && result.error)) {
      console.error('Error registering company:', fnError || result?.error);
      toast({
        title: 'Error',
        description: result?.error || fnError?.message || 'Failed to register company. Please try again.',
        variant: 'destructive',
      });
      setIsSubmitting(false);
      return;
    }

    setIsSubmitting(false);
    setIsSuccess(true);

    toast({
      title: 'Application Submitted!',
      description: 'Your company registration is pending approval.',
    });
  };

  if (isSuccess) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <PageHeader onSignInClick={() => setShowAuthModal(true)} />
        <main className="flex-1 flex items-center justify-center px-4 py-16">
          <div className="max-w-lg text-center">
            <div className="w-20 h-20 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-success" />
            </div>
            <h1 className="font-display text-3xl font-bold mb-4">
              Application Submitted!
            </h1>
            <p className="text-muted-foreground mb-6">
              Thank you for registering your company. Your application is pending
              review. We'll notify you once approved.
            </p>
            
            {/* Fee Setup Prompt */}
            <div className="bg-accent/10 border border-accent/20 rounded-xl p-6 mb-6 text-left">
              <h3 className="font-semibold text-lg mb-2 flex items-center gap-2">
                <Settings className="w-5 h-5 text-accent" />
                Set Up Your Fees
              </h3>
              <p className="text-sm text-muted-foreground mb-4">
                Configure your tow fees, storage rates, and admin charges. These will automatically 
                apply to all tow records created by your team.
              </p>
              <ul className="text-sm text-muted-foreground space-y-2 mb-4">
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-accent" />
                  Set fees per vehicle type (motorcycle, SUV, truck, etc.)
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-accent" />
                  Configure daily storage rates
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-accent" />
                  Add admin and gate fees
                </li>
              </ul>
            </div>

            <div className="space-y-3">
              <Button onClick={() => navigate('/operator?tab=settings')} className="w-full">
                Configure Fees Now
              </Button>
              <Button variant="outline" onClick={() => navigate('/operator')} className="w-full">
                Go to Dashboard
              </Button>
            </div>
          </div>
        </main>
        <PageFooter />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <PageHeader onSignInClick={() => setShowAuthModal(true)} />

      <main className="flex-1 px-4 py-8">
        <div className="max-w-2xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center">
            <div className="w-16 h-16 bg-accent/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Building2 className="w-8 h-8 text-accent" />
            </div>
            <h1 className="font-display text-3xl font-bold">
              Partner With TowTrace
            </h1>
            <p className="text-muted-foreground mt-2 max-w-lg mx-auto">
              Join the leading platform connecting tow companies with vehicle owners. 
              Streamline operations, reduce phone calls, and get paid faster.
            </p>
          </div>

          {/* Benefits Section */}
          <div className="bg-gradient-to-br from-primary/5 via-accent/5 to-primary/5 rounded-3xl p-8 border border-primary/10">
            <h2 className="font-display text-2xl font-bold text-center mb-2">
              Why Tow Companies Choose TowTrace
            </h2>
            <p className="text-muted-foreground text-center mb-8">
              Over 500+ tow yards trust us to modernize their operations
            </p>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center shrink-0">
                  <TrendingUp className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Increase Revenue</h3>
                  <p className="text-sm text-muted-foreground">
                    Reduce unclaimed vehicles. Our platform helps owners find and pay for their vehicles faster, improving your cash flow.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center shrink-0">
                  <Clock className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Save Time</h3>
                  <p className="text-sm text-muted-foreground">
                    Cut down on phone inquiries by 70%. Owners can check vehicle status, fees, and requirements online 24/7.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center shrink-0">
                  <CreditCard className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Easy Payments</h3>
                  <p className="text-sm text-muted-foreground">
                    Accept online payments securely. Get paid before the customer arrives—no more payment disputes at pickup.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center shrink-0">
                  <Shield className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Verified Documents</h3>
                  <p className="text-sm text-muted-foreground">
                    Digital document submission and verification. Ensure proper ownership before release with our secure system.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center shrink-0">
                  <BarChart3 className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Analytics Dashboard</h3>
                  <p className="text-sm text-muted-foreground">
                    Track tow volume, revenue, and turnaround times. Make data-driven decisions with real-time insights.
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center shrink-0">
                  <Users className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Team Management</h3>
                  <p className="text-sm text-muted-foreground">
                    Add employees with role-based access. Drivers can log tows on-the-go while admins manage everything.
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-primary/10 text-center">
              <p className="text-sm text-muted-foreground mb-3">Trusted by industry leaders</p>
              <div className="flex justify-center gap-8 text-muted-foreground/50 text-sm font-medium">
                <span>⭐ 4.9 Average Rating</span>
                <span>🚗 50,000+ Vehicles Processed</span>
                <span>📍 200+ Cities</span>
              </div>
            </div>
          </div>

          {/* Pricing Section */}
          <div className="space-y-6">
            <div className="text-center">
              <h2 className="font-display text-2xl font-bold mb-2">
                Simple, Transparent Pricing
              </h2>
              <p className="text-muted-foreground mb-6">
                Choose the plan that fits your business. Upgrade anytime as you grow.
              </p>
              
              {/* Billing Toggle */}
              <div className="inline-flex items-center gap-4 bg-muted/50 rounded-full p-1.5">
                <button
                  onClick={() => setIsAnnual(false)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                    !isAnnual 
                      ? 'bg-background shadow-sm text-foreground' 
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  Monthly
                </button>
                <button
                  onClick={() => setIsAnnual(true)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all flex items-center gap-2 ${
                    isAnnual 
                      ? 'bg-background shadow-sm text-foreground' 
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  Annual
                   <span className="bg-accent text-accent-foreground text-xs px-2 py-0.5 rounded-full">
                    2 months free
                  </span>
                </button>
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              {/* Starter Plan */}
              <div className="bg-card rounded-2xl p-6 shadow-card border border-border relative">
                <div className="mb-4">
                  <h3 className="font-display text-lg font-semibold">Starter</h3>
                  <p className="text-sm text-muted-foreground">For small operations</p>
                </div>
                <div className="mb-6">
                  <span className="font-display text-4xl font-bold">
                    ${isAnnual ? '249' : '299'}
                  </span>
                  <span className="text-muted-foreground">/month</span>
                  {isAnnual && (
                    <p className="text-xs text-muted-foreground mt-1">
                      Billed annually ($2,990/year)
                    </p>
                  )}
                </div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-accent shrink-0" />
                    Up to 200 vehicles/month
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-accent shrink-0" />
                    5 team members
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-accent shrink-0" />
                    Advanced analytics & reports
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-accent shrink-0" />
                    Email support
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-accent shrink-0" />
                    Online payments (2% fee)
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-accent shrink-0" />
                    Document verification
                  </li>
                </ul>
                <Button variant="outline" className="w-full">
                  Get Started
                </Button>
              </div>

              {/* Professional Plan */}
              <div className="bg-gradient-to-b from-accent/10 to-accent/5 rounded-2xl p-6 shadow-card border-2 border-accent relative">
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="bg-accent text-accent-foreground text-xs font-semibold px-3 py-1 rounded-full">
                    Most Popular
                  </span>
                </div>
                <div className="mb-4">
                  <h3 className="font-display text-lg font-semibold">Professional</h3>
                  <p className="text-sm text-muted-foreground">For growing yards</p>
                </div>
                <div className="mb-6">
                  <span className="font-display text-4xl font-bold">
                    ${isAnnual ? '499' : '599'}
                  </span>
                  <span className="text-muted-foreground">/month</span>
                  {isAnnual && (
                    <p className="text-xs text-muted-foreground mt-1">
                      Billed annually ($5,990/year)
                    </p>
                  )}
                </div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-accent shrink-0" />
                    Up to 500 vehicles/month
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-accent shrink-0" />
                    5 team members
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-accent shrink-0" />
                    Advanced analytics & reports
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-accent shrink-0" />
                    Priority email & chat support
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-accent shrink-0" />
                    Online payments (2% fee)
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-accent shrink-0" />
                    Document verification
                  </li>
                </ul>
                <Button className="w-full">
                  Get Started
                </Button>
              </div>

              {/* Enterprise Plan */}
              <div className="bg-card rounded-2xl p-6 shadow-card border border-border relative">
                <div className="mb-4">
                  <h3 className="font-display text-lg font-semibold">Enterprise</h3>
                  <p className="text-sm text-muted-foreground">For large operations</p>
                </div>
                <div className="mb-6">
                  <span className="font-display text-4xl font-bold">
                    ${isAnnual ? '833' : '1,000'}
                  </span>
                  <span className="text-muted-foreground">/month</span>
                  {isAnnual && (
                    <p className="text-xs text-muted-foreground mt-1">
                      Billed annually ($10,000/year)
                    </p>
                  )}
                </div>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-accent shrink-0" />
                    1,000+ vehicles/month
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-accent shrink-0" />
                    Unlimited team members
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-accent shrink-0" />
                    Custom reports & API access
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-accent shrink-0" />
                    Dedicated account manager
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-accent shrink-0" />
                    Online payments (1.5% fee)
                  </li>
                  <li className="flex items-center gap-2 text-sm">
                    <CheckCircle className="w-4 h-4 text-accent shrink-0" />
                    Multi-location support
                  </li>
                </ul>
                <Button className="w-full">
                  Get Started
                </Button>
              </div>
            </div>

            <p className="text-center text-sm text-muted-foreground">
              All plans include a 7-day free trial. No credit card required to start.
            </p>
          </div>

          {/* FAQ Section */}
          <div className="space-y-6">
            <div className="text-center">
              <h2 className="font-display text-2xl font-bold mb-2">
                Frequently Asked Questions
              </h2>
              <p className="text-muted-foreground">
                Have questions? We've got answers.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-card rounded-xl p-5 shadow-card">
                <h3 className="font-semibold mb-2">How long does approval take?</h3>
                <p className="text-sm text-muted-foreground">
                  Most applications are reviewed within 24-48 hours. You'll receive an email notification once your account is approved and ready to use.
                </p>
              </div>

              <div className="bg-card rounded-xl p-5 shadow-card">
                <h3 className="font-semibold mb-2">Can I upgrade or downgrade my plan?</h3>
                <p className="text-sm text-muted-foreground">
                  Yes! You can change your plan at any time. Upgrades take effect immediately, and downgrades apply at the next billing cycle.
                </p>
              </div>

              <div className="bg-card rounded-xl p-5 shadow-card">
                <h3 className="font-semibold mb-2">How do vehicle owners find their cars?</h3>
                <p className="text-sm text-muted-foreground">
                  Owners search by license plate or VIN on TowTrace. When they find their vehicle, they see your yard's contact info, fees, and can submit documents online.
                </p>
              </div>

              <div className="bg-card rounded-xl p-5 shadow-card">
                <h3 className="font-semibold mb-2">What payment methods are supported?</h3>
                <p className="text-sm text-muted-foreground">
                  We support credit/debit cards, ACH bank transfers, and Apple Pay. Funds are deposited directly to your bank account within 2-3 business days.
                </p>
              </div>

              <div className="bg-card rounded-xl p-5 shadow-card">
                <h3 className="font-semibold mb-2">Is there a contract or commitment?</h3>
                <p className="text-sm text-muted-foreground">
                  No long-term contracts. Monthly plans can be canceled anytime. Annual plans are billed upfront but save you 20% compared to monthly pricing.
                </p>
              </div>

              <div className="bg-card rounded-xl p-5 shadow-card">
                <h3 className="font-semibold mb-2">Do you offer training and support?</h3>
                <p className="text-sm text-muted-foreground">
                  Absolutely! All plans include onboarding support. Professional and Enterprise plans get priority support and dedicated account management.
                </p>
              </div>
            </div>
          </div>

          <form onSubmit={handleFormSubmit} className="space-y-6">
            {/* Account Creation - only show if not logged in */}
            {!user && (
              <section className="bg-card rounded-2xl p-6 shadow-card space-y-4 border-2 border-accent/20">
                <h2 className="font-display text-xl font-semibold flex items-center gap-2">
                  <Users className="w-5 h-5 text-accent" />
                  Create Your Account
                </h2>
                <p className="text-sm text-muted-foreground">
                  First, create an account to manage your company on TowTrace.
                </p>

                <div className="space-y-2">
                  <Label htmlFor="accountEmail">Email Address *</Label>
                  <Input
                    id="accountEmail"
                    type="email"
                    {...register('accountEmail')}
                    placeholder="you@company.com"
                  />
                  {errors.accountEmail && (
                    <p className="text-xs text-destructive">{errors.accountEmail.message}</p>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="password">Password *</Label>
                    <Input
                      id="password"
                      type="password"
                      {...register('password')}
                      placeholder="Min. 8 characters"
                    />
                    {errors.password && (
                      <p className="text-xs text-destructive">{errors.password.message}</p>
                    )}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirm Password *</Label>
                    <Input
                      id="confirmPassword"
                      type="password"
                      {...register('confirmPassword')}
                      placeholder="Confirm password"
                    />
                    {errors.confirmPassword && (
                      <p className="text-xs text-destructive">{errors.confirmPassword.message}</p>
                    )}
                  </div>
                </div>
              </section>
            )}

            {user && (
              <div className="bg-success/10 border border-success/20 rounded-xl p-4 text-center">
                <p className="text-sm text-success-foreground">
                  ✓ Signed in as <span className="font-medium">{user.email}</span>
                </p>
              </div>
            )}
            {/* Company Info */}
            <section className="bg-card rounded-2xl p-6 shadow-card space-y-4">
              <h2 className="font-display text-xl font-semibold flex items-center gap-2">
                <Building2 className="w-5 h-5 text-accent" />
                Company Information
              </h2>

              <div className="space-y-2">
                <Label htmlFor="companyName">Company Name *</Label>
                <Input
                  id="companyName"
                  {...register('companyName')}
                  placeholder="ABC Towing Services"
                />
                {errors.companyName && (
                  <p className="text-xs text-destructive">{errors.companyName.message}</p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone *</Label>
                  <Input
                    id="phone"
                    {...register('phone')}
                    placeholder="(555) 123-4567"
                  />
                  {errors.phone && (
                    <p className="text-xs text-destructive">{errors.phone.message}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="companyEmail">Company Email *</Label>
                  <Input
                    id="companyEmail"
                    type="email"
                    {...register('companyEmail')}
                    placeholder="contact@company.com"
                  />
                  {errors.companyEmail && (
                    <p className="text-xs text-destructive">{errors.companyEmail.message}</p>
                  )}
                </div>
              </div>
            </section>

            {/* Address */}
            <section className="bg-card rounded-2xl p-6 shadow-card space-y-4">
              <h2 className="font-display text-xl font-semibold flex items-center gap-2">
                <MapPin className="w-5 h-5 text-accent" />
                Tow Yard Location
              </h2>

              <div className="space-y-2">
                <Label htmlFor="address">Street Address *</Label>
                <Input
                  id="address"
                  {...register('address')}
                  placeholder="123 Main Street"
                />
                {errors.address && (
                  <p className="text-xs text-destructive">{errors.address.message}</p>
                )}
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="city">City *</Label>
                  <Input id="city" {...register('city')} placeholder="Los Angeles" />
                  {errors.city && (
                    <p className="text-xs text-destructive">{errors.city.message}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label>Country *</Label>
                  <Select
                    value={country}
                    onValueChange={(v) => setValue('country', v as 'US' | 'CA')}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="US">United States</SelectItem>
                      <SelectItem value="CA">Canada</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>{country === 'US' ? 'State' : 'Province'} *</Label>
                  <Select onValueChange={(v) => setValue('stateProvince', v)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select..." />
                    </SelectTrigger>
                    <SelectContent>
                      {regions.map((r) => (
                        <SelectItem key={r.code} value={r.code}>
                          {r.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {errors.stateProvince && (
                    <p className="text-xs text-destructive">
                      {errors.stateProvince.message}
                    </p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="postalCode">
                    {country === 'US' ? 'ZIP Code' : 'Postal Code'} *
                  </Label>
                  <Input
                    id="postalCode"
                    {...register('postalCode')}
                    placeholder={country === 'US' ? '90001' : 'A1A 1A1'}
                  />
                  {errors.postalCode && (
                    <p className="text-xs text-destructive">{errors.postalCode.message}</p>
                  )}
                </div>
              </div>
            </section>

            {/* Payment Methods */}
            <section className="bg-card rounded-2xl p-6 shadow-card space-y-4">
              <h2 className="font-display text-xl font-semibold">
                Accepted Payment Methods
              </h2>

              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="acceptsCash"
                    checked={watch('acceptsCash')}
                    onCheckedChange={(c) => setValue('acceptsCash', c === true)}
                  />
                  <Label htmlFor="acceptsCash" className="font-normal">
                    Cash
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="acceptsCards"
                    checked={watch('acceptsCards')}
                    onCheckedChange={(c) => setValue('acceptsCards', c === true)}
                  />
                  <Label htmlFor="acceptsCards" className="font-normal">
                    Credit/Debit Cards
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="acceptsInApp"
                    checked={watch('acceptsInApp')}
                    onCheckedChange={(c) => setValue('acceptsInApp', c === true)}
                  />
                  <Label htmlFor="acceptsInApp" className="font-normal">
                    In-App Payments (Coming Soon)
                  </Label>
                </div>
              </div>
            </section>

            <Button
              type="submit"
              size="lg"
              className="w-full"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  {user ? 'Submitting...' : 'Creating Account & Submitting...'}
                </>
              ) : (
                user ? 'Submit Application' : 'Create Account & Submit Application'
              )}
            </Button>
          </form>
        </div>
      </main>

      <PageFooter />

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onSuccess={() => setShowAuthModal(false)}
      />

      <EnterpriseContactModal
        isOpen={showEnterpriseModal}
        onClose={() => setShowEnterpriseModal(false)}
      />
    </div>
  );
}