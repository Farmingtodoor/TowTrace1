import { PageHeader } from '@/components/layout/PageHeader';
import { PageFooter } from '@/components/layout/PageFooter';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

const faqs = [
  {
    category: "Finding Your Vehicle",
    items: [
      {
        q: "How do I find my towed vehicle?",
        a: "Enter your license plate number or VIN on the TowTrace homepage. We'll instantly search our network of tow yards and show you the location, fees, and next steps for recovering your vehicle."
      },
      {
        q: "What information do I need to search?",
        a: "You can search using either your license plate number (with state/province) or your Vehicle Identification Number (VIN). Both are equally effective."
      },
      {
        q: "Why can't I find my vehicle?",
        a: "If your vehicle doesn't appear, the tow yard may not yet be in our network, or the record may not have been entered. Try searching again later, or contact your local police department for a tow report."
      },
    ],
  },
  {
    category: "Fees & Payments",
    items: [
      {
        q: "Can I pay towing fees online?",
        a: "Yes! TowTrace allows you to pay towing and storage fees securely online for participating tow yards. You'll receive a digital receipt via email after payment."
      },
      {
        q: "How are towing fees calculated?",
        a: "Fees typically include a base tow fee, daily storage charges, an administrative fee, and a gate fee. The exact amounts vary by tow yard and vehicle type. All fees are displayed transparently before payment."
      },
      {
        q: "Does paying online guarantee my vehicle release?",
        a: "Payment is a required step, but you'll also need to present valid identification and vehicle ownership documents at the tow yard for release."
      },
    ],
  },
  {
    category: "Documents & Claims",
    items: [
      {
        q: "What documents do I need to retrieve my towed car?",
        a: "Typically you need a valid government-issued ID, vehicle registration or title, proof of insurance, and payment in full. TowTrace lets you submit these documents digitally to speed up the process."
      },
      {
        q: "How long does document review take?",
        a: "Most documents are reviewed within 24–48 hours. You'll receive a notification once your documents are approved or if additional information is needed."
      },
      {
        q: "Can someone else pick up my vehicle?",
        a: "Yes, but they'll need a signed authorization letter from the registered owner, along with both parties' identification documents. You can upload the authorization through TowTrace."
      },
    ],
  },
  {
    category: "Disputes",
    items: [
      {
        q: "How do I dispute a tow or fees?",
        a: "After starting a claim, you can file a dispute through TowTrace. Select the dispute type, provide a description and any supporting evidence, and the tow yard will review your case."
      },
      {
        q: "How long does dispute resolution take?",
        a: "Most disputes are resolved within 5–10 business days. You'll receive updates via notifications as the review progresses."
      },
    ],
  },
  {
    category: "For Tow Yard Operators",
    items: [
      {
        q: "How do I register my tow yard on TowTrace?",
        a: "Visit our Join page and complete the registration form. After review and approval, you'll get access to the operator dashboard to manage tow records, documents, and payments."
      },
      {
        q: "Is there a cost for tow yards to use TowTrace?",
        a: "TowTrace offers subscription plans for tow yard operators. Visit our Join page or contact us for pricing details."
      },
    ],
  },
];

export default function FAQ() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      <PageHeader />
      <main className="flex-1 py-16 px-4">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-4xl font-display font-bold text-foreground mb-2">Frequently Asked Questions</h1>
          <p className="text-muted-foreground mb-10">
            Everything you need to know about finding and recovering your towed vehicle.
          </p>

          {faqs.map((section) => (
            <div key={section.category} className="mb-8">
              <h2 className="text-xl font-semibold text-foreground mb-3">{section.category}</h2>
              <Accordion type="multiple" className="space-y-2">
                {section.items.map((item, i) => (
                  <AccordionItem key={i} value={`${section.category}-${i}`} className="border rounded-lg px-4">
                    <AccordionTrigger className="text-left font-medium">{item.q}</AccordionTrigger>
                    <AccordionContent className="text-muted-foreground">{item.a}</AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          ))}
        </div>
      </main>
      <PageFooter />
    </div>
  );
}
