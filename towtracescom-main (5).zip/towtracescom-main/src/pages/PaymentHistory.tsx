import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { CreditCard, Receipt, Calendar, ArrowRight, CheckCircle, XCircle, Clock, RefreshCw } from 'lucide-react';
import { PageHeader } from '@/components/layout/PageHeader';
import { PageFooter } from '@/components/layout/PageFooter';
import { AuthModal } from '@/components/auth/AuthModal';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { format } from 'date-fns';

interface Payment {
  id: string;
  amount: number;
  status: string;
  currency: string;
  provider: string;
  provider_ref: string | null;
  receipt_url: string | null;
  created_at: string;
  claim: {
    id: string;
    tow_record: {
      make: string | null;
      model: string | null;
      plate_number: string | null;
    };
  };
}

export default function PaymentHistory() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [isOperator, setIsOperator] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) {
      setShowAuthModal(true);
    }
  }, [authLoading, user]);

  useEffect(() => {
    if (!user) return;

    const fetchData = async () => {
      setLoading(true);

      // Check if user is an operator
      const { data: roleData } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id)
        .in('role', ['operator', 'admin']);

      setIsOperator(roleData && roleData.length > 0);

      // Fetch payments based on role
      let query = supabase
        .from('payments')
        .select(`
          id,
          amount,
          status,
          currency,
          provider,
          provider_ref,
          receipt_url,
          created_at,
          claim:claims (
            id,
            tow_record:tow_records (
              make,
              model,
              plate_number
            )
          )
        `)
        .order('created_at', { ascending: false });

      const { data, error } = await query;

      if (error) {
        console.error('Error fetching payments:', error);
      } else {
        setPayments(data as unknown as Payment[]);
      }
      setLoading(false);
    };

    fetchData();
  }, [user]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'succeeded':
        return <CheckCircle className="w-4 h-4 text-success" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-destructive" />;
      case 'refunded':
        return <RefreshCw className="w-4 h-4 text-warning" />;
      default:
        return <Clock className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, string> = {
      succeeded: 'bg-success/10 text-success',
      failed: 'bg-destructive/10 text-destructive',
      refunded: 'bg-warning/10 text-warning',
      initiated: 'bg-muted text-muted-foreground',
    };

    return (
      <Badge variant="outline" className={variants[status] || variants.initiated}>
        {getStatusIcon(status)}
        <span className="ml-1 capitalize">{status}</span>
      </Badge>
    );
  };

  const filterPayments = (status?: string) => {
    if (!status || status === 'all') return payments;
    return payments.filter((p) => p.status === status);
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <PageHeader onSignInClick={() => setShowAuthModal(true)} />

      <main className="flex-1 px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="font-display text-3xl font-bold">Payment History</h1>
              <p className="text-muted-foreground mt-2">
                {isOperator
                  ? 'View all payment transactions for your tow yards'
                  : 'View your payment history and receipts'}
              </p>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <CreditCard className="w-4 h-4" />
              <span>{payments.length} transactions</span>
            </div>
          </div>

          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="succeeded">Completed</TabsTrigger>
              <TabsTrigger value="initiated">Pending</TabsTrigger>
              <TabsTrigger value="refunded">Refunded</TabsTrigger>
            </TabsList>

            {['all', 'succeeded', 'initiated', 'refunded'].map((tab) => (
              <TabsContent key={tab} value={tab} className="mt-6">
                {loading ? (
                  <div className="bg-card rounded-xl p-8 text-center">
                    <div className="animate-pulse text-muted-foreground">Loading payments...</div>
                  </div>
                ) : filterPayments(tab === 'all' ? undefined : tab).length === 0 ? (
                  <div className="bg-card rounded-xl p-8 text-center space-y-4">
                    <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto">
                      <Receipt className="w-8 h-8 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="font-semibold text-lg">No Payments Found</p>
                      <p className="text-muted-foreground">
                        {tab === 'all'
                          ? "You haven't made any payments yet."
                          : `No ${tab} payments found.`}
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {filterPayments(tab === 'all' ? undefined : tab).map((payment) => (
                      <div
                        key={payment.id}
                        className="bg-card rounded-xl p-5 hover:shadow-card transition-shadow"
                      >
                        <div className="flex items-center justify-between gap-4">
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                              <CreditCard className="w-6 h-6 text-primary" />
                            </div>
                            <div>
                              <p className="font-semibold">
                                {payment.claim?.tow_record?.make} {payment.claim?.tow_record?.model}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                {payment.claim?.tow_record?.plate_number || 'N/A'}
                              </p>
                              <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                                <Calendar className="w-3 h-3" />
                                {format(new Date(payment.created_at), 'MMM d, yyyy • h:mm a')}
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="text-right">
                              <p className="font-bold text-lg">
                                ${payment.amount.toFixed(2)}
                              </p>
                              <p className="text-xs text-muted-foreground uppercase">
                                {payment.currency}
                              </p>
                            </div>
                            {getStatusBadge(payment.status)}
                            {payment.receipt_url && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => window.open(payment.receipt_url!, '_blank')}
                              >
                                <Receipt className="w-4 h-4" />
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </main>

      <PageFooter />

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => {
          setShowAuthModal(false);
          if (!user) navigate('/');
        }}
        onSuccess={() => setShowAuthModal(false)}
      />
    </div>
  );
}
