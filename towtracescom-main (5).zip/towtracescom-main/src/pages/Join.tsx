import { PageHeader } from '@/components/layout/PageHeader';
import { PageFooter } from '@/components/layout/PageFooter';
import { AuthModal } from '@/components/auth/AuthModal';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Building2, 
  Globe, 
  CheckCircle, 
  ArrowRight,
  Truck,
  MapPin,
  Users,
  Shield,
  DollarSign,
  BarChart3,
  Clock,
  Zap
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

export default function Join() {
  const [showAuthModal, setShowAuthModal] = useState(false);

  const towCompanyBenefits = [
    { icon: DollarSign, text: 'Accept online payments and reduce collection time' },
    { icon: BarChart3, text: 'Real-time analytics and reporting dashboard' },
    { icon: Clock, text: 'Reduce phone calls by 70% with digital claims' },
    { icon: Shield, text: 'Verified digital document processing' },
    { icon: Users, text: 'Multi-user access with role-based permissions' },
    { icon: Zap, text: 'Automated notifications to vehicle owners' },
  ];

  const cityBenefits = [
    { icon: Users, text: 'Improve citizen satisfaction with transparent processes' },
    { icon: MapPin, text: 'Centralized tracking for all municipal towing' },
    { icon: BarChart3, text: 'Comprehensive analytics and compliance reporting' },
    { icon: Shield, text: 'Ensure all tow operators meet city standards' },
    { icon: Clock, text: 'Reduce complaint calls to city offices' },
    { icon: DollarSign, text: 'Streamline fee collection and auditing' },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <PageHeader onSignInClick={() => setShowAuthModal(true)} />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="hero-gradient text-primary-foreground py-20 px-4">
          <div className="max-w-4xl mx-auto text-center space-y-6">
            <div className="inline-flex items-center gap-2 bg-primary-foreground/10 backdrop-blur-sm px-4 py-2 rounded-full text-sm">
              <Users className="w-4 h-4" />
              Join Our Growing Network
            </div>
            <h1 className="font-display text-4xl md:text-5xl font-bold text-balance">
              Partner with TowTrace
            </h1>
            <p className="text-xl text-primary-foreground/80 max-w-2xl mx-auto">
              Whether you're a tow company looking to modernize your operations or a city seeking 
              to improve municipal towing services, we have solutions for you.
            </p>
          </div>
        </section>

        {/* Partner Options */}
        <section className="py-20 px-4">
          <div className="max-w-6xl mx-auto">
            <div className="grid md:grid-cols-2 gap-8">
              {/* Tow Companies Card */}
              <Card className="relative overflow-hidden border-2 hover:border-accent transition-colors group">
                <div className="absolute top-0 right-0 w-32 h-32 bg-accent/10 rounded-full -translate-y-1/2 translate-x-1/2" />
                <CardHeader className="space-y-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-accent/20 to-accent/10 rounded-2xl flex items-center justify-center">
                    <Truck className="w-8 h-8 text-accent" />
                  </div>
                  <div>
                    <CardTitle className="font-display text-2xl">For Tow Companies</CardTitle>
                    <CardDescription className="text-base mt-2">
                      Streamline your operations, reduce paperwork, and get paid faster with our 
                      digital platform built specifically for tow operators.
                    </CardDescription>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  <ul className="space-y-3">
                    {towCompanyBenefits.map((benefit, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <div className="w-6 h-6 rounded-full bg-accent/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <benefit.icon className="w-3.5 h-3.5 text-accent" />
                        </div>
                        <span className="text-muted-foreground">{benefit.text}</span>
                      </li>
                    ))}
                  </ul>
                  <Button asChild size="lg" className="w-full group-hover:shadow-lg transition-shadow">
                    <Link to="/signup/company">
                      Get Started
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>

              {/* Cities Card */}
              <Card className="relative overflow-hidden border-2 hover:border-info transition-colors group">
                <div className="absolute top-0 right-0 w-32 h-32 bg-info/10 rounded-full -translate-y-1/2 translate-x-1/2" />
                <CardHeader className="space-y-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-info/20 to-info/10 rounded-2xl flex items-center justify-center">
                    <Globe className="w-8 h-8 text-info" />
                  </div>
                  <div>
                    <CardTitle className="font-display text-2xl">For Cities & Municipalities</CardTitle>
                    <CardDescription className="text-base mt-2">
                      Modernize your municipal towing oversight with a transparent, citizen-friendly 
                      platform that ensures compliance and accountability.
                    </CardDescription>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  <ul className="space-y-3">
                    {cityBenefits.map((benefit, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <div className="w-6 h-6 rounded-full bg-info/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <benefit.icon className="w-3.5 h-3.5 text-info" />
                        </div>
                        <span className="text-muted-foreground">{benefit.text}</span>
                      </li>
                    ))}
                  </ul>
                  <Button asChild size="lg" variant="outline" className="w-full group-hover:shadow-lg transition-shadow border-info text-info hover:bg-info/10">
                    <Link to="/signup/city">
                      Contact Us
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Trust Section */}
        <section className="py-16 px-4 bg-muted/30">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h2 className="font-display text-3xl font-bold">Trusted Across North America</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <div className="text-center">
                <p className="font-display text-4xl font-bold text-accent">500+</p>
                <p className="text-muted-foreground mt-1">Partner Tow Yards</p>
              </div>
              <div className="text-center">
                <p className="font-display text-4xl font-bold text-accent">50+</p>
                <p className="text-muted-foreground mt-1">Cities Served</p>
              </div>
              <div className="text-center">
                <p className="font-display text-4xl font-bold text-accent">50K+</p>
                <p className="text-muted-foreground mt-1">Vehicles Located</p>
              </div>
              <div className="text-center">
                <p className="font-display text-4xl font-bold text-accent">98%</p>
                <p className="text-muted-foreground mt-1">Satisfaction Rate</p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 px-4">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <h2 className="font-display text-3xl font-bold">Ready to Get Started?</h2>
            <p className="text-muted-foreground text-lg">
              Join the growing network of tow companies and cities modernizing vehicle recovery.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg">
                <Link to="/signup/company">
                  <Truck className="w-5 h-5 mr-2" />
                  Tow Company Signup
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline">
                <Link to="/signup/city">
                  <Globe className="w-5 h-5 mr-2" />
                  City Partnership
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <PageFooter />

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onSuccess={() => setShowAuthModal(false)}
      />
    </div>
  );
}
