export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      audit_logs: {
        Row: {
          action: string
          actor_user_id: string | null
          created_at: string
          entity_id: string | null
          entity_type: string
          id: string
          metadata_json: Json | null
        }
        Insert: {
          action: string
          actor_user_id?: string | null
          created_at?: string
          entity_id?: string | null
          entity_type: string
          id?: string
          metadata_json?: Json | null
        }
        Update: {
          action?: string
          actor_user_id?: string | null
          created_at?: string
          entity_id?: string | null
          entity_type?: string
          id?: string
          metadata_json?: Json | null
        }
        Relationships: []
      }
      claims: {
        Row: {
          claim_status: Database["public"]["Enums"]["claim_status"]
          consumer_user_id: string
          created_at: string
          id: string
          tow_record_id: string
          updated_at: string
        }
        Insert: {
          claim_status?: Database["public"]["Enums"]["claim_status"]
          consumer_user_id: string
          created_at?: string
          id?: string
          tow_record_id: string
          updated_at?: string
        }
        Update: {
          claim_status?: Database["public"]["Enums"]["claim_status"]
          consumer_user_id?: string
          created_at?: string
          id?: string
          tow_record_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "claims_tow_record_id_fkey"
            columns: ["tow_record_id"]
            isOneToOne: true
            referencedRelation: "public_tow_records"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "claims_tow_record_id_fkey"
            columns: ["tow_record_id"]
            isOneToOne: true
            referencedRelation: "tow_records"
            referencedColumns: ["id"]
          },
        ]
      }
      disputes: {
        Row: {
          claim_id: string
          consumer_user_id: string
          created_at: string
          description: string
          dispute_type: Database["public"]["Enums"]["dispute_type"]
          evidence_request_notes: string | null
          evidence_requested: boolean | null
          evidence_requested_at: string | null
          evidence_submitted_at: string | null
          evidence_urls: string[] | null
          id: string
          resolution_notes: string | null
          resolved_by_user_id: string | null
          status: Database["public"]["Enums"]["dispute_status"]
          tow_record_id: string
          tow_yard_id: string
          updated_at: string
        }
        Insert: {
          claim_id: string
          consumer_user_id: string
          created_at?: string
          description: string
          dispute_type: Database["public"]["Enums"]["dispute_type"]
          evidence_request_notes?: string | null
          evidence_requested?: boolean | null
          evidence_requested_at?: string | null
          evidence_submitted_at?: string | null
          evidence_urls?: string[] | null
          id?: string
          resolution_notes?: string | null
          resolved_by_user_id?: string | null
          status?: Database["public"]["Enums"]["dispute_status"]
          tow_record_id: string
          tow_yard_id: string
          updated_at?: string
        }
        Update: {
          claim_id?: string
          consumer_user_id?: string
          created_at?: string
          description?: string
          dispute_type?: Database["public"]["Enums"]["dispute_type"]
          evidence_request_notes?: string | null
          evidence_requested?: boolean | null
          evidence_requested_at?: string | null
          evidence_submitted_at?: string | null
          evidence_urls?: string[] | null
          id?: string
          resolution_notes?: string | null
          resolved_by_user_id?: string | null
          status?: Database["public"]["Enums"]["dispute_status"]
          tow_record_id?: string
          tow_yard_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "disputes_claim_id_fkey"
            columns: ["claim_id"]
            isOneToOne: false
            referencedRelation: "claims"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "disputes_tow_record_id_fkey"
            columns: ["tow_record_id"]
            isOneToOne: false
            referencedRelation: "public_tow_records"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "disputes_tow_record_id_fkey"
            columns: ["tow_record_id"]
            isOneToOne: false
            referencedRelation: "tow_records"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "disputes_tow_yard_id_fkey"
            columns: ["tow_yard_id"]
            isOneToOne: false
            referencedRelation: "public_tow_yards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "disputes_tow_yard_id_fkey"
            columns: ["tow_yard_id"]
            isOneToOne: false
            referencedRelation: "tow_yards"
            referencedColumns: ["id"]
          },
        ]
      }
      documents: {
        Row: {
          claim_id: string
          created_at: string
          doc_type: Database["public"]["Enums"]["doc_type"]
          file_name: string | null
          file_url: string
          id: string
          rejection_reason: string | null
          reviewer_user_id: string | null
          status: Database["public"]["Enums"]["doc_status"]
          updated_at: string
        }
        Insert: {
          claim_id: string
          created_at?: string
          doc_type: Database["public"]["Enums"]["doc_type"]
          file_name?: string | null
          file_url: string
          id?: string
          rejection_reason?: string | null
          reviewer_user_id?: string | null
          status?: Database["public"]["Enums"]["doc_status"]
          updated_at?: string
        }
        Update: {
          claim_id?: string
          created_at?: string
          doc_type?: Database["public"]["Enums"]["doc_type"]
          file_name?: string | null
          file_url?: string
          id?: string
          rejection_reason?: string | null
          reviewer_user_id?: string | null
          status?: Database["public"]["Enums"]["doc_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "documents_claim_id_fkey"
            columns: ["claim_id"]
            isOneToOne: false
            referencedRelation: "claims"
            referencedColumns: ["id"]
          },
        ]
      }
      email_templates: {
        Row: {
          created_at: string
          description: string | null
          html_body: string
          id: string
          name: string
          subject: string
          template_key: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          html_body: string
          id?: string
          name: string
          subject: string
          template_key: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          html_body?: string
          id?: string
          name?: string
          subject?: string
          template_key?: string
          updated_at?: string
        }
        Relationships: []
      }
      fee_configurations: {
        Row: {
          admin_fee: number
          created_at: string
          daily_storage_fee: number
          gate_fee: number
          id: string
          tow_fee: number
          tow_yard_id: string
          updated_at: string
          vehicle_type: string
        }
        Insert: {
          admin_fee?: number
          created_at?: string
          daily_storage_fee?: number
          gate_fee?: number
          id?: string
          tow_fee?: number
          tow_yard_id: string
          updated_at?: string
          vehicle_type: string
        }
        Update: {
          admin_fee?: number
          created_at?: string
          daily_storage_fee?: number
          gate_fee?: number
          id?: string
          tow_fee?: number
          tow_yard_id?: string
          updated_at?: string
          vehicle_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "fee_configurations_tow_yard_id_fkey"
            columns: ["tow_yard_id"]
            isOneToOne: false
            referencedRelation: "public_tow_yards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fee_configurations_tow_yard_id_fkey"
            columns: ["tow_yard_id"]
            isOneToOne: false
            referencedRelation: "tow_yards"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          created_at: string
          entity_id: string | null
          entity_type: string | null
          id: string
          is_read: boolean
          message: string
          title: string
          type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          entity_id?: string | null
          entity_type?: string | null
          id?: string
          is_read?: boolean
          message: string
          title: string
          type?: string
          user_id: string
        }
        Update: {
          created_at?: string
          entity_id?: string | null
          entity_type?: string | null
          id?: string
          is_read?: boolean
          message?: string
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      payments: {
        Row: {
          amount: number
          claim_id: string
          created_at: string
          currency: string | null
          id: string
          provider: string | null
          provider_ref: string | null
          receipt_url: string | null
          service_fee: number | null
          status: Database["public"]["Enums"]["payment_status"]
          tow_record_id: string
          updated_at: string
        }
        Insert: {
          amount: number
          claim_id: string
          created_at?: string
          currency?: string | null
          id?: string
          provider?: string | null
          provider_ref?: string | null
          receipt_url?: string | null
          service_fee?: number | null
          status?: Database["public"]["Enums"]["payment_status"]
          tow_record_id: string
          updated_at?: string
        }
        Update: {
          amount?: number
          claim_id?: string
          created_at?: string
          currency?: string | null
          id?: string
          provider?: string | null
          provider_ref?: string | null
          receipt_url?: string | null
          service_fee?: number | null
          status?: Database["public"]["Enums"]["payment_status"]
          tow_record_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "payments_claim_id_fkey"
            columns: ["claim_id"]
            isOneToOne: false
            referencedRelation: "claims"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payments_tow_record_id_fkey"
            columns: ["tow_record_id"]
            isOneToOne: false
            referencedRelation: "public_tow_records"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payments_tow_record_id_fkey"
            columns: ["tow_record_id"]
            isOneToOne: false
            referencedRelation: "tow_records"
            referencedColumns: ["id"]
          },
        ]
      }
      payout_requests: {
        Row: {
          amount: number
          completed_at: string | null
          created_at: string
          id: string
          notes: string | null
          payout_method: string
          requested_by_user_id: string
          reviewed_at: string | null
          reviewed_by_user_id: string | null
          status: string
          tow_yard_id: string
          updated_at: string
        }
        Insert: {
          amount: number
          completed_at?: string | null
          created_at?: string
          id?: string
          notes?: string | null
          payout_method: string
          requested_by_user_id: string
          reviewed_at?: string | null
          reviewed_by_user_id?: string | null
          status?: string
          tow_yard_id: string
          updated_at?: string
        }
        Update: {
          amount?: number
          completed_at?: string | null
          created_at?: string
          id?: string
          notes?: string | null
          payout_method?: string
          requested_by_user_id?: string
          reviewed_at?: string | null
          reviewed_by_user_id?: string | null
          status?: string
          tow_yard_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "payout_requests_tow_yard_id_fkey"
            columns: ["tow_yard_id"]
            isOneToOne: false
            referencedRelation: "public_tow_yards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payout_requests_tow_yard_id_fkey"
            columns: ["tow_yard_id"]
            isOneToOne: false
            referencedRelation: "tow_yards"
            referencedColumns: ["id"]
          },
        ]
      }
      payout_settings: {
        Row: {
          apple_pay_merchant_id: string | null
          bank_account_holder_name: string | null
          bank_account_number: string | null
          bank_name: string | null
          bank_routing_number: string | null
          created_at: string
          id: string
          is_verified: boolean | null
          minimum_payout_amount: number | null
          payout_frequency: string | null
          payout_method: string
          paypal_email: string | null
          stripe_account_id: string | null
          stripe_connected: boolean | null
          tow_yard_id: string
          updated_at: string
        }
        Insert: {
          apple_pay_merchant_id?: string | null
          bank_account_holder_name?: string | null
          bank_account_number?: string | null
          bank_name?: string | null
          bank_routing_number?: string | null
          created_at?: string
          id?: string
          is_verified?: boolean | null
          minimum_payout_amount?: number | null
          payout_frequency?: string | null
          payout_method?: string
          paypal_email?: string | null
          stripe_account_id?: string | null
          stripe_connected?: boolean | null
          tow_yard_id: string
          updated_at?: string
        }
        Update: {
          apple_pay_merchant_id?: string | null
          bank_account_holder_name?: string | null
          bank_account_number?: string | null
          bank_name?: string | null
          bank_routing_number?: string | null
          created_at?: string
          id?: string
          is_verified?: boolean | null
          minimum_payout_amount?: number | null
          payout_frequency?: string | null
          payout_method?: string
          paypal_email?: string | null
          stripe_account_id?: string | null
          stripe_connected?: boolean | null
          tow_yard_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "payout_settings_tow_yard_id_fkey"
            columns: ["tow_yard_id"]
            isOneToOne: true
            referencedRelation: "public_tow_yards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payout_settings_tow_yard_id_fkey"
            columns: ["tow_yard_id"]
            isOneToOne: true
            referencedRelation: "tow_yards"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string | null
          first_name: string | null
          full_name: string | null
          id: string
          last_name: string | null
          phone: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          first_name?: string | null
          full_name?: string | null
          id?: string
          last_name?: string | null
          phone?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          first_name?: string | null
          full_name?: string | null
          id?: string
          last_name?: string | null
          phone?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      push_subscriptions: {
        Row: {
          auth_key: string
          created_at: string
          endpoint: string
          id: string
          p256dh_key: string
          updated_at: string
          user_id: string
        }
        Insert: {
          auth_key: string
          created_at?: string
          endpoint: string
          id?: string
          p256dh_key: string
          updated_at?: string
          user_id: string
        }
        Update: {
          auth_key?: string
          created_at?: string
          endpoint?: string
          id?: string
          p256dh_key?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      search_reminders: {
        Row: {
          created_at: string
          email: string
          id: string
          remind_at: string
          reminder_minutes: number
          search_type: string
          search_value: string
          sent: boolean
          user_id: string | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          remind_at: string
          reminder_minutes?: number
          search_type: string
          search_value: string
          sent?: boolean
          user_id?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          remind_at?: string
          reminder_minutes?: number
          search_type?: string
          search_value?: string
          sent?: boolean
          user_id?: string | null
        }
        Relationships: []
      }
      tow_records: {
        Row: {
          admin_fee: number
          color: string | null
          country: string | null
          created_at: string
          currency: string | null
          daily_storage_fee: number
          driver_name: string | null
          driver_user_id: string | null
          gate_fee: number
          id: string
          locked_at: string | null
          locked_by_name: string | null
          locked_by_user_id: string | null
          make: string | null
          model: string | null
          plate_number: string | null
          plate_state_province: string | null
          release_requirements: string[] | null
          status: Database["public"]["Enums"]["tow_status"]
          storage_start_datetime: string | null
          tow_datetime: string
          tow_fee: number
          tow_from_address: string | null
          tow_reason: string | null
          tow_yard_id: string
          updated_at: string
          vehicle_photos: string[] | null
          vehicle_type: string | null
          vin: string | null
        }
        Insert: {
          admin_fee?: number
          color?: string | null
          country?: string | null
          created_at?: string
          currency?: string | null
          daily_storage_fee?: number
          driver_name?: string | null
          driver_user_id?: string | null
          gate_fee?: number
          id?: string
          locked_at?: string | null
          locked_by_name?: string | null
          locked_by_user_id?: string | null
          make?: string | null
          model?: string | null
          plate_number?: string | null
          plate_state_province?: string | null
          release_requirements?: string[] | null
          status?: Database["public"]["Enums"]["tow_status"]
          storage_start_datetime?: string | null
          tow_datetime?: string
          tow_fee?: number
          tow_from_address?: string | null
          tow_reason?: string | null
          tow_yard_id: string
          updated_at?: string
          vehicle_photos?: string[] | null
          vehicle_type?: string | null
          vin?: string | null
        }
        Update: {
          admin_fee?: number
          color?: string | null
          country?: string | null
          created_at?: string
          currency?: string | null
          daily_storage_fee?: number
          driver_name?: string | null
          driver_user_id?: string | null
          gate_fee?: number
          id?: string
          locked_at?: string | null
          locked_by_name?: string | null
          locked_by_user_id?: string | null
          make?: string | null
          model?: string | null
          plate_number?: string | null
          plate_state_province?: string | null
          release_requirements?: string[] | null
          status?: Database["public"]["Enums"]["tow_status"]
          storage_start_datetime?: string | null
          tow_datetime?: string
          tow_fee?: number
          tow_from_address?: string | null
          tow_reason?: string | null
          tow_yard_id?: string
          updated_at?: string
          vehicle_photos?: string[] | null
          vehicle_type?: string | null
          vin?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "tow_records_tow_yard_id_fkey"
            columns: ["tow_yard_id"]
            isOneToOne: false
            referencedRelation: "public_tow_yards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tow_records_tow_yard_id_fkey"
            columns: ["tow_yard_id"]
            isOneToOne: false
            referencedRelation: "tow_yards"
            referencedColumns: ["id"]
          },
        ]
      }
      tow_yard_operators: {
        Row: {
          created_at: string
          id: string
          operator_user_id: string
          permission_level: Database["public"]["Enums"]["employee_role"]
          tow_yard_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          operator_user_id: string
          permission_level?: Database["public"]["Enums"]["employee_role"]
          tow_yard_id: string
        }
        Update: {
          created_at?: string
          id?: string
          operator_user_id?: string
          permission_level?: Database["public"]["Enums"]["employee_role"]
          tow_yard_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "tow_yard_operators_tow_yard_id_fkey"
            columns: ["tow_yard_id"]
            isOneToOne: false
            referencedRelation: "public_tow_yards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tow_yard_operators_tow_yard_id_fkey"
            columns: ["tow_yard_id"]
            isOneToOne: false
            referencedRelation: "tow_yards"
            referencedColumns: ["id"]
          },
        ]
      }
      tow_yards: {
        Row: {
          accepted_payment_methods: string[] | null
          address: string
          allows_in_app_payment: boolean | null
          city: string
          country: string
          created_at: string
          email: string | null
          hours_json: Json | null
          id: string
          is_approved: boolean | null
          name: string
          phone: string
          postal_code: string | null
          state_province: string
          updated_at: string
        }
        Insert: {
          accepted_payment_methods?: string[] | null
          address: string
          allows_in_app_payment?: boolean | null
          city: string
          country: string
          created_at?: string
          email?: string | null
          hours_json?: Json | null
          id?: string
          is_approved?: boolean | null
          name: string
          phone: string
          postal_code?: string | null
          state_province: string
          updated_at?: string
        }
        Update: {
          accepted_payment_methods?: string[] | null
          address?: string
          allows_in_app_payment?: boolean | null
          city?: string
          country?: string
          created_at?: string
          email?: string | null
          hours_json?: Json | null
          id?: string
          is_approved?: boolean | null
          name?: string
          phone?: string
          postal_code?: string | null
          state_province?: string
          updated_at?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      public_tow_records: {
        Row: {
          admin_fee: number | null
          color: string | null
          country: string | null
          created_at: string | null
          currency: string | null
          daily_storage_fee: number | null
          gate_fee: number | null
          id: string | null
          make: string | null
          model: string | null
          plate_number: string | null
          plate_state_province: string | null
          release_requirements: string[] | null
          status: Database["public"]["Enums"]["tow_status"] | null
          storage_start_datetime: string | null
          tow_datetime: string | null
          tow_fee: number | null
          tow_from_address: string | null
          tow_reason: string | null
          tow_yard_id: string | null
          updated_at: string | null
          vehicle_photos: string[] | null
          vehicle_type: string | null
          vin: string | null
        }
        Insert: {
          admin_fee?: number | null
          color?: string | null
          country?: string | null
          created_at?: string | null
          currency?: string | null
          daily_storage_fee?: number | null
          gate_fee?: number | null
          id?: string | null
          make?: string | null
          model?: string | null
          plate_number?: string | null
          plate_state_province?: string | null
          release_requirements?: string[] | null
          status?: Database["public"]["Enums"]["tow_status"] | null
          storage_start_datetime?: string | null
          tow_datetime?: string | null
          tow_fee?: number | null
          tow_from_address?: string | null
          tow_reason?: string | null
          tow_yard_id?: string | null
          updated_at?: string | null
          vehicle_photos?: string[] | null
          vehicle_type?: string | null
          vin?: string | null
        }
        Update: {
          admin_fee?: number | null
          color?: string | null
          country?: string | null
          created_at?: string | null
          currency?: string | null
          daily_storage_fee?: number | null
          gate_fee?: number | null
          id?: string | null
          make?: string | null
          model?: string | null
          plate_number?: string | null
          plate_state_province?: string | null
          release_requirements?: string[] | null
          status?: Database["public"]["Enums"]["tow_status"] | null
          storage_start_datetime?: string | null
          tow_datetime?: string | null
          tow_fee?: number | null
          tow_from_address?: string | null
          tow_reason?: string | null
          tow_yard_id?: string | null
          updated_at?: string | null
          vehicle_photos?: string[] | null
          vehicle_type?: string | null
          vin?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "tow_records_tow_yard_id_fkey"
            columns: ["tow_yard_id"]
            isOneToOne: false
            referencedRelation: "public_tow_yards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tow_records_tow_yard_id_fkey"
            columns: ["tow_yard_id"]
            isOneToOne: false
            referencedRelation: "tow_yards"
            referencedColumns: ["id"]
          },
        ]
      }
      public_tow_yards: {
        Row: {
          accepted_payment_methods: string[] | null
          address: string | null
          allows_in_app_payment: boolean | null
          city: string | null
          country: string | null
          created_at: string | null
          hours_json: Json | null
          id: string | null
          is_approved: boolean | null
          name: string | null
          postal_code: string | null
          state_province: string | null
          updated_at: string | null
        }
        Insert: {
          accepted_payment_methods?: string[] | null
          address?: string | null
          allows_in_app_payment?: boolean | null
          city?: string | null
          country?: string | null
          created_at?: string | null
          hours_json?: Json | null
          id?: string | null
          is_approved?: boolean | null
          name?: string | null
          postal_code?: string | null
          state_province?: string | null
          updated_at?: string | null
        }
        Update: {
          accepted_payment_methods?: string[] | null
          address?: string | null
          allows_in_app_payment?: boolean | null
          city?: string | null
          country?: string | null
          created_at?: string | null
          hours_json?: Json | null
          id?: string | null
          is_approved?: boolean | null
          name?: string | null
          postal_code?: string | null
          state_province?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      acquire_record_lock: {
        Args: {
          _lock_timeout_minutes?: number
          _record_id: string
          _user_id: string
          _user_name: string
        }
        Returns: Json
      }
      calculate_total_due: { Args: { record_id: string }; Returns: number }
      check_record_lock: {
        Args: { _lock_timeout_minutes?: number; _record_id: string }
        Returns: Json
      }
      has_claim_on_record: {
        Args: { _record_id: string; _user_id: string }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_super_admin: { Args: { _user_id: string }; Returns: boolean }
      is_tow_yard_admin: {
        Args: { _tow_yard_id: string; _user_id: string }
        Returns: boolean
      }
      is_tow_yard_operator: {
        Args: { _tow_yard_id: string; _user_id: string }
        Returns: boolean
      }
      release_record_lock: {
        Args: { _force?: boolean; _record_id: string; _user_id: string }
        Returns: Json
      }
    }
    Enums: {
      app_role:
        | "consumer"
        | "operator"
        | "admin"
        | "super_admin"
        | "reviewer"
        | "analyst"
      claim_status:
        | "started"
        | "docs_submitted"
        | "docs_approved"
        | "payment_pending"
        | "complete"
      dispute_status: "open" | "under_review" | "resolved" | "rejected"
      dispute_type:
        | "vehicle_damage"
        | "property_damage"
        | "missing_items"
        | "overcharge"
        | "other"
      doc_status: "pending" | "approved" | "rejected"
      doc_type:
        | "gov_id"
        | "registration"
        | "title"
        | "insurance"
        | "authorization"
      employee_role: "viewer" | "operator" | "editor" | "admin"
      payment_status: "initiated" | "succeeded" | "failed" | "refunded"
      tow_status:
        | "towed"
        | "docs_pending"
        | "docs_approved"
        | "paid"
        | "released"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "consumer",
        "operator",
        "admin",
        "super_admin",
        "reviewer",
        "analyst",
      ],
      claim_status: [
        "started",
        "docs_submitted",
        "docs_approved",
        "payment_pending",
        "complete",
      ],
      dispute_status: ["open", "under_review", "resolved", "rejected"],
      dispute_type: [
        "vehicle_damage",
        "property_damage",
        "missing_items",
        "overcharge",
        "other",
      ],
      doc_status: ["pending", "approved", "rejected"],
      doc_type: [
        "gov_id",
        "registration",
        "title",
        "insurance",
        "authorization",
      ],
      employee_role: ["viewer", "operator", "editor", "admin"],
      payment_status: ["initiated", "succeeded", "failed", "refunded"],
      tow_status: [
        "towed",
        "docs_pending",
        "docs_approved",
        "paid",
        "released",
      ],
    },
  },
} as const
