-- ============================================
-- TowTrace Database Schema Export
-- Generated: 2026-02-03
-- 
-- This file contains the complete database schema
-- for recreating the TowTrace backend.
-- ============================================

-- ============================================
-- PART 1: ENUMS
-- ============================================

CREATE TYPE public.app_role AS ENUM (
  'consumer',
  'operator',
  'admin',
  'super_admin',
  'reviewer',
  'analyst'
);

CREATE TYPE public.claim_status AS ENUM (
  'started',
  'docs_submitted',
  'docs_approved',
  'payment_pending',
  'complete'
);

CREATE TYPE public.dispute_status AS ENUM (
  'open',
  'under_review',
  'resolved',
  'rejected'
);

CREATE TYPE public.dispute_type AS ENUM (
  'vehicle_damage',
  'property_damage',
  'missing_items',
  'overcharge',
  'other'
);

CREATE TYPE public.doc_status AS ENUM (
  'pending',
  'approved',
  'rejected'
);

CREATE TYPE public.doc_type AS ENUM (
  'gov_id',
  'registration',
  'title',
  'insurance',
  'authorization'
);

CREATE TYPE public.employee_role AS ENUM (
  'viewer',
  'operator',
  'editor',
  'admin'
);

CREATE TYPE public.payment_status AS ENUM (
  'initiated',
  'succeeded',
  'failed',
  'refunded'
);

CREATE TYPE public.tow_status AS ENUM (
  'towed',
  'docs_pending',
  'docs_approved',
  'paid',
  'released'
);

-- ============================================
-- PART 2: TABLES
-- ============================================

-- Tow Yards (Tow Companies)
CREATE TABLE public.tow_yards (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  address TEXT NOT NULL,
  city TEXT NOT NULL,
  state_province TEXT NOT NULL,
  country TEXT NOT NULL,
  postal_code TEXT,
  phone TEXT NOT NULL,
  email TEXT,
  hours_json JSONB DEFAULT '{}'::jsonb,
  allows_in_app_payment BOOLEAN DEFAULT false,
  is_approved BOOLEAN DEFAULT false,
  accepted_payment_methods TEXT[] DEFAULT ARRAY['Cash'::text, 'Credit Card'::text],
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tow Yard Operators (Employee Assignments)
CREATE TABLE public.tow_yard_operators (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tow_yard_id UUID NOT NULL REFERENCES public.tow_yards(id) ON DELETE CASCADE,
  operator_user_id UUID NOT NULL,
  permission_level public.employee_role NOT NULL DEFAULT 'editor'::employee_role,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (tow_yard_id, operator_user_id)
);

-- Tow Records (Vehicles)
CREATE TABLE public.tow_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tow_yard_id UUID NOT NULL REFERENCES public.tow_yards(id) ON DELETE CASCADE,
  plate_number TEXT,
  plate_state_province TEXT,
  country TEXT,
  vin TEXT,
  make TEXT,
  model TEXT,
  color TEXT,
  vehicle_type TEXT DEFAULT 'standard'::text,
  tow_datetime TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  tow_reason TEXT,
  tow_from_address TEXT,
  status public.tow_status NOT NULL DEFAULT 'towed'::tow_status,
  tow_fee NUMERIC NOT NULL DEFAULT 0,
  daily_storage_fee NUMERIC NOT NULL DEFAULT 0,
  admin_fee NUMERIC NOT NULL DEFAULT 0,
  gate_fee NUMERIC NOT NULL DEFAULT 0,
  currency TEXT DEFAULT 'USD'::text,
  storage_start_datetime TIMESTAMP WITH TIME ZONE DEFAULT now(),
  driver_name TEXT,
  driver_user_id UUID,
  locked_by_user_id UUID,
  locked_by_name TEXT,
  locked_at TIMESTAMP WITH TIME ZONE,
  release_requirements TEXT[] DEFAULT ARRAY[
    'Valid government-issued photo ID'::text,
    'Vehicle registration or title'::text,
    'Proof of insurance'::text,
    'Payment in full'::text
  ],
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Claims (Consumer Claims on Vehicles)
CREATE TABLE public.claims (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tow_record_id UUID NOT NULL REFERENCES public.tow_records(id) ON DELETE CASCADE UNIQUE,
  consumer_user_id UUID NOT NULL,
  claim_status public.claim_status NOT NULL DEFAULT 'started'::claim_status,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Documents (Claim Documents)
CREATE TABLE public.documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id UUID NOT NULL REFERENCES public.claims(id) ON DELETE CASCADE,
  doc_type public.doc_type NOT NULL,
  file_url TEXT NOT NULL,
  file_name TEXT,
  status public.doc_status NOT NULL DEFAULT 'pending'::doc_status,
  rejection_reason TEXT,
  reviewer_user_id UUID,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Payments
CREATE TABLE public.payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id UUID NOT NULL REFERENCES public.claims(id) ON DELETE CASCADE,
  tow_record_id UUID NOT NULL REFERENCES public.tow_records(id) ON DELETE CASCADE,
  amount NUMERIC NOT NULL,
  currency TEXT DEFAULT 'USD'::text,
  status public.payment_status NOT NULL DEFAULT 'initiated'::payment_status,
  provider TEXT DEFAULT 'stripe'::text,
  provider_ref TEXT,
  receipt_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Disputes
CREATE TABLE public.disputes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id UUID NOT NULL REFERENCES public.claims(id) ON DELETE CASCADE,
  tow_record_id UUID NOT NULL REFERENCES public.tow_records(id) ON DELETE CASCADE,
  tow_yard_id UUID NOT NULL REFERENCES public.tow_yards(id) ON DELETE CASCADE,
  consumer_user_id UUID NOT NULL,
  dispute_type public.dispute_type NOT NULL,
  description TEXT NOT NULL,
  status public.dispute_status NOT NULL DEFAULT 'open'::dispute_status,
  evidence_urls TEXT[] DEFAULT '{}'::text[],
  evidence_requested BOOLEAN DEFAULT false,
  evidence_requested_at TIMESTAMP WITH TIME ZONE,
  evidence_request_notes TEXT,
  evidence_submitted_at TIMESTAMP WITH TIME ZONE,
  resolution_notes TEXT,
  resolved_by_user_id UUID,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Fee Configurations (Per Yard, Per Vehicle Type)
CREATE TABLE public.fee_configurations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tow_yard_id UUID NOT NULL REFERENCES public.tow_yards(id) ON DELETE CASCADE,
  vehicle_type TEXT NOT NULL,
  tow_fee NUMERIC NOT NULL DEFAULT 0,
  daily_storage_fee NUMERIC NOT NULL DEFAULT 0,
  admin_fee NUMERIC NOT NULL DEFAULT 0,
  gate_fee NUMERIC NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (tow_yard_id, vehicle_type)
);

-- Payout Settings (One Per Yard)
CREATE TABLE public.payout_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tow_yard_id UUID NOT NULL REFERENCES public.tow_yards(id) ON DELETE CASCADE UNIQUE,
  payout_method TEXT NOT NULL DEFAULT 'bank_account'::text,
  bank_name TEXT,
  bank_account_number TEXT,
  bank_routing_number TEXT,
  bank_account_holder_name TEXT,
  stripe_account_id TEXT,
  stripe_connected BOOLEAN DEFAULT false,
  paypal_email TEXT,
  apple_pay_merchant_id TEXT,
  payout_frequency TEXT DEFAULT 'weekly'::text,
  minimum_payout_amount NUMERIC DEFAULT 50,
  is_verified BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- User Profiles
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE,
  email TEXT,
  phone TEXT,
  full_name TEXT,
  first_name TEXT,
  last_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- User Roles
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  role public.app_role NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

-- Push Subscriptions
CREATE TABLE public.push_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  endpoint TEXT NOT NULL,
  p256dh_key TEXT NOT NULL,
  auth_key TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (user_id, endpoint)
);

-- Search Reminders
CREATE TABLE public.search_reminders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID,
  email TEXT NOT NULL,
  search_type TEXT NOT NULL,
  search_value TEXT NOT NULL,
  reminder_minutes INTEGER NOT NULL DEFAULT 30,
  remind_at TIMESTAMP WITH TIME ZONE NOT NULL,
  sent BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Audit Logs
CREATE TABLE public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_user_id UUID,
  entity_type TEXT NOT NULL,
  entity_id UUID,
  action TEXT NOT NULL,
  metadata_json JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Email Templates
CREATE TABLE public.email_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  template_key TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  subject TEXT NOT NULL,
  html_body TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- ============================================
-- PART 3: INDEXES
-- ============================================

CREATE INDEX idx_tow_records_plate ON public.tow_records(plate_number, plate_state_province);
CREATE INDEX idx_tow_records_vin ON public.tow_records(vin);
CREATE INDEX idx_tow_records_tow_yard ON public.tow_records(tow_yard_id);
CREATE INDEX idx_tow_records_status ON public.tow_records(status);
CREATE INDEX idx_claims_consumer ON public.claims(consumer_user_id);
CREATE INDEX idx_claims_tow_record ON public.claims(tow_record_id);
CREATE INDEX idx_disputes_tow_yard ON public.disputes(tow_yard_id);
CREATE INDEX idx_disputes_consumer ON public.disputes(consumer_user_id);
CREATE INDEX idx_user_roles_user ON public.user_roles(user_id);
CREATE INDEX idx_tow_yard_operators_yard ON public.tow_yard_operators(tow_yard_id);
CREATE INDEX idx_tow_yard_operators_user ON public.tow_yard_operators(operator_user_id);

-- ============================================
-- PART 4: FUNCTIONS
-- ============================================

-- Check if user has a specific role
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- Check if user is an operator for a tow yard
CREATE OR REPLACE FUNCTION public.is_tow_yard_operator(_user_id UUID, _tow_yard_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.tow_yard_operators tyo
    WHERE tyo.tow_yard_id = _tow_yard_id
      AND tyo.operator_user_id = _user_id
  );
$$;

-- Check if user is an admin for a tow yard
CREATE OR REPLACE FUNCTION public.is_tow_yard_admin(_user_id UUID, _tow_yard_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.tow_yard_operators tyo
    WHERE tyo.tow_yard_id = _tow_yard_id
      AND tyo.operator_user_id = _user_id
      AND tyo.permission_level = 'admin'::public.employee_role
  );
$$;

-- Check if user has a claim on a record
CREATE OR REPLACE FUNCTION public.has_claim_on_record(_user_id UUID, _record_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.claims
    WHERE consumer_user_id = _user_id
      AND tow_record_id = _record_id
  )
$$;

-- Check if user is super admin
CREATE OR REPLACE FUNCTION public.is_super_admin(_user_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM auth.users
    WHERE id = _user_id
      AND email = 'support@eventboomer.com'
  )
$$;

-- Calculate total due for a tow record
CREATE OR REPLACE FUNCTION public.calculate_total_due(record_id UUID)
RETURNS NUMERIC
LANGUAGE plpgsql
STABLE
SET search_path = public
AS $$
DECLARE
  total DECIMAL(10,2);
  days_stored INTEGER;
  rec RECORD;
BEGIN
  SELECT * INTO rec FROM public.tow_records WHERE id = record_id;
  IF NOT FOUND THEN RETURN 0; END IF;
  days_stored := GREATEST(1, CEIL(EXTRACT(EPOCH FROM (now() - rec.storage_start_datetime)) / 86400));
  total := rec.tow_fee + (rec.daily_storage_fee * days_stored) + rec.admin_fee + rec.gate_fee;
  RETURN total;
END;
$$;

-- Acquire record lock
CREATE OR REPLACE FUNCTION public.acquire_record_lock(
  _record_id UUID,
  _user_id UUID,
  _user_name TEXT,
  _lock_timeout_minutes INTEGER DEFAULT 30
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  current_lock record;
  result jsonb;
BEGIN
  SELECT locked_by_user_id, locked_at, locked_by_name
  INTO current_lock
  FROM public.tow_records
  WHERE id = _record_id;
  
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Record not found');
  END IF;
  
  IF current_lock.locked_by_user_id IS NOT NULL 
     AND current_lock.locked_by_user_id != _user_id
     AND current_lock.locked_at > (now() - (_lock_timeout_minutes || ' minutes')::interval) THEN
    RETURN jsonb_build_object(
      'success', false, 
      'error', 'Record is locked by another user',
      'locked_by', current_lock.locked_by_name,
      'locked_at', current_lock.locked_at
    );
  END IF;
  
  UPDATE public.tow_records
  SET 
    locked_by_user_id = _user_id,
    locked_at = now(),
    locked_by_name = _user_name
  WHERE id = _record_id;
  
  RETURN jsonb_build_object('success', true, 'message', 'Lock acquired');
END;
$$;

-- Release record lock
CREATE OR REPLACE FUNCTION public.release_record_lock(
  _record_id UUID,
  _user_id UUID,
  _force BOOLEAN DEFAULT false
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  current_lock record;
BEGIN
  SELECT locked_by_user_id, locked_by_name
  INTO current_lock
  FROM public.tow_records
  WHERE id = _record_id;
  
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Record not found');
  END IF;
  
  IF current_lock.locked_by_user_id IS NULL THEN
    RETURN jsonb_build_object('success', true, 'message', 'Record was not locked');
  END IF;
  
  IF current_lock.locked_by_user_id != _user_id AND NOT _force THEN
    RETURN jsonb_build_object(
      'success', false, 
      'error', 'Cannot release lock owned by another user',
      'locked_by', current_lock.locked_by_name
    );
  END IF;
  
  UPDATE public.tow_records
  SET 
    locked_by_user_id = NULL,
    locked_at = NULL,
    locked_by_name = NULL
  WHERE id = _record_id;
  
  RETURN jsonb_build_object('success', true, 'message', 'Lock released');
END;
$$;

-- Check record lock status
CREATE OR REPLACE FUNCTION public.check_record_lock(
  _record_id UUID,
  _lock_timeout_minutes INTEGER DEFAULT 30
)
RETURNS JSONB
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  current_lock record;
BEGIN
  SELECT locked_by_user_id, locked_at, locked_by_name
  INTO current_lock
  FROM public.tow_records
  WHERE id = _record_id;
  
  IF NOT FOUND THEN
    RETURN jsonb_build_object('locked', false, 'error', 'Record not found');
  END IF;
  
  IF current_lock.locked_by_user_id IS NOT NULL 
     AND current_lock.locked_at > (now() - (_lock_timeout_minutes || ' minutes')::interval) THEN
    RETURN jsonb_build_object(
      'locked', true,
      'locked_by_user_id', current_lock.locked_by_user_id,
      'locked_by_name', current_lock.locked_by_name,
      'locked_at', current_lock.locked_at
    );
  END IF;
  
  RETURN jsonb_build_object('locked', false);
END;
$$;

-- Update timestamp trigger function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (user_id, email, phone)
  VALUES (NEW.id, NEW.email, NEW.phone);
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'consumer');
  RETURN NEW;
END;
$$;

-- Check super admin on signup
CREATE OR REPLACE FUNCTION public.check_super_admin_on_signup()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.email = 'support@eventboomer.com' THEN
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;

-- ============================================
-- PART 5: TRIGGERS
-- ============================================

-- Updated_at triggers
CREATE TRIGGER update_tow_yards_updated_at
  BEFORE UPDATE ON public.tow_yards
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_tow_records_updated_at
  BEFORE UPDATE ON public.tow_records
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_claims_updated_at
  BEFORE UPDATE ON public.claims
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_documents_updated_at
  BEFORE UPDATE ON public.documents
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_payments_updated_at
  BEFORE UPDATE ON public.payments
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_disputes_updated_at
  BEFORE UPDATE ON public.disputes
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_fee_configurations_updated_at
  BEFORE UPDATE ON public.fee_configurations
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_payout_settings_updated_at
  BEFORE UPDATE ON public.payout_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_email_templates_updated_at
  BEFORE UPDATE ON public.email_templates
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Auth triggers (attach to auth.users)
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE TRIGGER on_auth_user_created_super_admin_check
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.check_super_admin_on_signup();

-- ============================================
-- PART 6: ROW LEVEL SECURITY (RLS)
-- ============================================

-- Enable RLS on all tables
ALTER TABLE public.tow_yards ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tow_yard_operators ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tow_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.claims ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.disputes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fee_configurations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payout_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.push_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.search_reminders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.email_templates ENABLE ROW LEVEL SECURITY;

-- ============================================
-- TOW_YARDS POLICIES
-- ============================================

CREATE POLICY "Admins can manage all tow yards"
ON public.tow_yards FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Authenticated users can submit tow yard applications"
ON public.tow_yards FOR INSERT
WITH CHECK (is_approved = false);

CREATE POLICY "Authenticated users can view approved tow yards"
ON public.tow_yards FOR SELECT
USING ((auth.uid() IS NOT NULL) AND (is_approved = true));

CREATE POLICY "Operators can update assigned yards"
ON public.tow_yards FOR UPDATE
USING (EXISTS (
  SELECT 1 FROM tow_yard_operators
  WHERE tow_yard_operators.tow_yard_id = tow_yards.id
    AND tow_yard_operators.operator_user_id = auth.uid()
));

CREATE POLICY "Operators can view assigned yards"
ON public.tow_yards FOR SELECT
USING (EXISTS (
  SELECT 1 FROM tow_yard_operators
  WHERE tow_yard_operators.tow_yard_id = tow_yards.id
    AND tow_yard_operators.operator_user_id = auth.uid()
));

-- ============================================
-- TOW_YARD_OPERATORS POLICIES
-- ============================================

CREATE POLICY "Admins can manage operator assignments"
ON public.tow_yard_operators FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Operators can view their assignments"
ON public.tow_yard_operators FOR SELECT
USING (operator_user_id = auth.uid());

CREATE POLICY "Users can self-assign as yard admin"
ON public.tow_yard_operators FOR INSERT
WITH CHECK ((operator_user_id = auth.uid()) AND (permission_level = 'admin'::employee_role));

CREATE POLICY "Yard admins can delete operator assignments"
ON public.tow_yard_operators FOR DELETE
USING (is_tow_yard_admin(auth.uid(), tow_yard_id) OR has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Yard admins can update operator assignments"
ON public.tow_yard_operators FOR UPDATE
USING (is_tow_yard_admin(auth.uid(), tow_yard_id) OR has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (is_tow_yard_admin(auth.uid(), tow_yard_id) OR has_role(auth.uid(), 'admin'::app_role));

-- ============================================
-- TOW_RECORDS POLICIES
-- ============================================

CREATE POLICY "Admins can manage all tow records"
ON public.tow_records FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Consumers can view records with their claims"
ON public.tow_records FOR SELECT
USING (has_claim_on_record(auth.uid(), id));

CREATE POLICY "Operators can insert records for their yards"
ON public.tow_records FOR INSERT
WITH CHECK (EXISTS (
  SELECT 1 FROM tow_yard_operators
  WHERE tow_yard_operators.tow_yard_id = tow_records.tow_yard_id
    AND tow_yard_operators.operator_user_id = auth.uid()
));

CREATE POLICY "Operators can update records for their yards"
ON public.tow_records FOR UPDATE
USING (EXISTS (
  SELECT 1 FROM tow_yard_operators
  WHERE tow_yard_operators.tow_yard_id = tow_records.tow_yard_id
    AND tow_yard_operators.operator_user_id = auth.uid()
));

CREATE POLICY "Operators can view records for their yards"
ON public.tow_records FOR SELECT
USING (EXISTS (
  SELECT 1 FROM tow_yard_operators
  WHERE tow_yard_operators.tow_yard_id = tow_records.tow_yard_id
    AND tow_yard_operators.operator_user_id = auth.uid()
));

-- ============================================
-- CLAIMS POLICIES
-- ============================================

CREATE POLICY "Admins can manage all claims"
ON public.claims FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Consumers can create claims"
ON public.claims FOR INSERT
WITH CHECK (consumer_user_id = auth.uid());

CREATE POLICY "Consumers can update their own claims"
ON public.claims FOR UPDATE
USING (consumer_user_id = auth.uid());

CREATE POLICY "Consumers can view their own claims"
ON public.claims FOR SELECT
USING (consumer_user_id = auth.uid());

CREATE POLICY "Operators can update claims for their yards"
ON public.claims FOR UPDATE
USING (EXISTS (
  SELECT 1 FROM tow_records tr
  JOIN tow_yard_operators tyo ON tr.tow_yard_id = tyo.tow_yard_id
  WHERE tr.id = claims.tow_record_id AND tyo.operator_user_id = auth.uid()
));

CREATE POLICY "Operators can view claims for their yards"
ON public.claims FOR SELECT
USING (EXISTS (
  SELECT 1 FROM tow_records tr
  JOIN tow_yard_operators tyo ON tr.tow_yard_id = tyo.tow_yard_id
  WHERE tr.id = claims.tow_record_id AND tyo.operator_user_id = auth.uid()
));

-- ============================================
-- DOCUMENTS POLICIES
-- ============================================

CREATE POLICY "Admins can manage all documents"
ON public.documents FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Consumers can upload documents"
ON public.documents FOR INSERT
WITH CHECK (EXISTS (
  SELECT 1 FROM claims WHERE claims.id = documents.claim_id AND claims.consumer_user_id = auth.uid()
));

CREATE POLICY "Consumers can view their own documents"
ON public.documents FOR SELECT
USING (EXISTS (
  SELECT 1 FROM claims WHERE claims.id = documents.claim_id AND claims.consumer_user_id = auth.uid()
));

CREATE POLICY "Operators can update documents for their yards"
ON public.documents FOR UPDATE
USING (EXISTS (
  SELECT 1 FROM claims c
  JOIN tow_records tr ON c.tow_record_id = tr.id
  JOIN tow_yard_operators tyo ON tr.tow_yard_id = tyo.tow_yard_id
  WHERE c.id = documents.claim_id AND tyo.operator_user_id = auth.uid()
));

CREATE POLICY "Operators can view documents for their yards"
ON public.documents FOR SELECT
USING (EXISTS (
  SELECT 1 FROM claims c
  JOIN tow_records tr ON c.tow_record_id = tr.id
  JOIN tow_yard_operators tyo ON tr.tow_yard_id = tyo.tow_yard_id
  WHERE c.id = documents.claim_id AND tyo.operator_user_id = auth.uid()
));

-- ============================================
-- PAYMENTS POLICIES
-- ============================================

CREATE POLICY "Admins can manage all payments"
ON public.payments FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Consumers can view their own payments"
ON public.payments FOR SELECT
USING (EXISTS (
  SELECT 1 FROM claims WHERE claims.id = payments.claim_id AND claims.consumer_user_id = auth.uid()
));

CREATE POLICY "Operators can view payments for their yards"
ON public.payments FOR SELECT
USING (EXISTS (
  SELECT 1 FROM tow_records tr
  JOIN tow_yard_operators tyo ON tr.tow_yard_id = tyo.tow_yard_id
  WHERE tr.id = payments.tow_record_id AND tyo.operator_user_id = auth.uid()
));

-- ============================================
-- DISPUTES POLICIES
-- ============================================

CREATE POLICY "Admins can manage all disputes"
ON public.disputes FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Consumers can create disputes for their claims"
ON public.disputes FOR INSERT
WITH CHECK (
  (consumer_user_id = auth.uid()) AND 
  (EXISTS (
    SELECT 1 FROM claims c
    JOIN tow_records tr ON c.tow_record_id = tr.id
    WHERE c.id = disputes.claim_id 
      AND c.consumer_user_id = auth.uid() 
      AND tr.status = 'released'::tow_status
  ))
);

CREATE POLICY "Consumers can view their own disputes"
ON public.disputes FOR SELECT
USING (consumer_user_id = auth.uid());

CREATE POLICY "Operators can update disputes for their yards"
ON public.disputes FOR UPDATE
USING (EXISTS (
  SELECT 1 FROM tow_yard_operators tyo
  WHERE tyo.tow_yard_id = disputes.tow_yard_id AND tyo.operator_user_id = auth.uid()
));

CREATE POLICY "Operators can view disputes for their yards"
ON public.disputes FOR SELECT
USING (EXISTS (
  SELECT 1 FROM tow_yard_operators tyo
  WHERE tyo.tow_yard_id = disputes.tow_yard_id AND tyo.operator_user_id = auth.uid()
));

-- ============================================
-- FEE_CONFIGURATIONS POLICIES
-- ============================================

CREATE POLICY "Admins can manage all fee configs"
ON public.fee_configurations FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Operators can delete fee configs for their yards"
ON public.fee_configurations FOR DELETE
USING (EXISTS (
  SELECT 1 FROM tow_yard_operators
  WHERE tow_yard_operators.tow_yard_id = fee_configurations.tow_yard_id
    AND tow_yard_operators.operator_user_id = auth.uid()
));

CREATE POLICY "Operators can insert fee configs for their yards"
ON public.fee_configurations FOR INSERT
WITH CHECK (EXISTS (
  SELECT 1 FROM tow_yard_operators
  WHERE tow_yard_operators.tow_yard_id = fee_configurations.tow_yard_id
    AND tow_yard_operators.operator_user_id = auth.uid()
));

CREATE POLICY "Operators can update fee configs for their yards"
ON public.fee_configurations FOR UPDATE
USING (EXISTS (
  SELECT 1 FROM tow_yard_operators
  WHERE tow_yard_operators.tow_yard_id = fee_configurations.tow_yard_id
    AND tow_yard_operators.operator_user_id = auth.uid()
));

CREATE POLICY "Operators can view fee configs for their yards"
ON public.fee_configurations FOR SELECT
USING (EXISTS (
  SELECT 1 FROM tow_yard_operators
  WHERE tow_yard_operators.tow_yard_id = fee_configurations.tow_yard_id
    AND tow_yard_operators.operator_user_id = auth.uid()
));

-- ============================================
-- PAYOUT_SETTINGS POLICIES
-- ============================================

CREATE POLICY "Admins can manage all payout settings"
ON public.payout_settings FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Yard admins can insert payout settings"
ON public.payout_settings FOR INSERT
WITH CHECK (EXISTS (
  SELECT 1 FROM tow_yard_operators
  WHERE tow_yard_operators.tow_yard_id = payout_settings.tow_yard_id
    AND tow_yard_operators.operator_user_id = auth.uid()
    AND tow_yard_operators.permission_level = 'admin'::employee_role
));

CREATE POLICY "Yard admins can update payout settings"
ON public.payout_settings FOR UPDATE
USING (EXISTS (
  SELECT 1 FROM tow_yard_operators
  WHERE tow_yard_operators.tow_yard_id = payout_settings.tow_yard_id
    AND tow_yard_operators.operator_user_id = auth.uid()
    AND tow_yard_operators.permission_level = 'admin'::employee_role
));

CREATE POLICY "Yard admins can view payout settings"
ON public.payout_settings FOR SELECT
USING (EXISTS (
  SELECT 1 FROM tow_yard_operators
  WHERE tow_yard_operators.tow_yard_id = payout_settings.tow_yard_id
    AND tow_yard_operators.operator_user_id = auth.uid()
    AND tow_yard_operators.permission_level = 'admin'::employee_role
));

-- ============================================
-- PROFILES POLICIES
-- ============================================

CREATE POLICY "Admins can manage all profiles"
ON public.profiles FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can view all profiles"
ON public.profiles FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can insert their own profile"
ON public.profiles FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own profile"
ON public.profiles FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can view their own profile"
ON public.profiles FOR SELECT
USING (auth.uid() = user_id);

-- ============================================
-- USER_ROLES POLICIES
-- ============================================

CREATE POLICY "Admins can manage all roles"
ON public.user_roles FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can self-assign operator or consumer role"
ON public.user_roles FOR INSERT
WITH CHECK ((user_id = auth.uid()) AND (role = ANY (ARRAY['operator'::app_role, 'consumer'::app_role])));

CREATE POLICY "Users can view their own roles"
ON public.user_roles FOR SELECT
USING (auth.uid() = user_id);

-- ============================================
-- PUSH_SUBSCRIPTIONS POLICIES
-- ============================================

CREATE POLICY "Users can delete their own subscriptions"
ON public.push_subscriptions FOR DELETE
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own subscriptions"
ON public.push_subscriptions FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own subscriptions"
ON public.push_subscriptions FOR SELECT
USING (auth.uid() = user_id);

-- ============================================
-- SEARCH_REMINDERS POLICIES
-- ============================================

CREATE POLICY "Anyone can create reminders"
ON public.search_reminders FOR INSERT
WITH CHECK (true);

CREATE POLICY "Service role can update reminders"
ON public.search_reminders FOR UPDATE
USING (true)
WITH CHECK (true);

CREATE POLICY "Users can view their own reminders"
ON public.search_reminders FOR SELECT
USING (((auth.uid() IS NOT NULL) AND (user_id = auth.uid())) OR ((auth.uid() IS NULL) AND (user_id IS NULL)));

-- ============================================
-- AUDIT_LOGS POLICIES
-- ============================================

CREATE POLICY "Admins can view all audit logs"
ON public.audit_logs FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Authenticated users can insert audit logs"
ON public.audit_logs FOR INSERT
WITH CHECK (true);

CREATE POLICY "No one can delete audit logs"
ON public.audit_logs FOR DELETE
USING (false);

CREATE POLICY "No one can update audit logs"
ON public.audit_logs FOR UPDATE
USING (false);

-- ============================================
-- EMAIL_TEMPLATES POLICIES
-- ============================================

CREATE POLICY "Admins can manage email templates"
ON public.email_templates FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Only admins can view email templates"
ON public.email_templates FOR SELECT
USING (EXISTS (
  SELECT 1 FROM user_roles WHERE user_roles.user_id = auth.uid() AND user_roles.role = 'admin'::app_role
));

-- ============================================
-- PART 7: STORAGE BUCKETS
-- ============================================

-- Create storage buckets
INSERT INTO storage.buckets (id, name, public) VALUES ('claim-documents', 'claim-documents', false);
INSERT INTO storage.buckets (id, name, public) VALUES ('avatars', 'avatars', true);

-- Storage policies for claim-documents (private)
CREATE POLICY "Users can upload claim documents"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'claim-documents' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can view their own claim documents"
ON storage.objects FOR SELECT
USING (
  bucket_id = 'claim-documents' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

-- Storage policies for avatars (public)
CREATE POLICY "Avatar images are publicly accessible"
ON storage.objects FOR SELECT
USING (bucket_id = 'avatars');

CREATE POLICY "Users can upload their own avatar"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'avatars' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can update their own avatar"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'avatars' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

-- ============================================
-- PART 8: REALTIME (Optional)
-- ============================================

-- Enable realtime for specific tables if needed
-- ALTER PUBLICATION supabase_realtime ADD TABLE public.claims;
-- ALTER PUBLICATION supabase_realtime ADD TABLE public.tow_records;

-- ============================================
-- END OF SCHEMA EXPORT
-- ============================================
