import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// In-memory rate limiting store (resets on function cold start)
const rateLimitStore = new Map<string, { count: number; windowStart: number }>();
const RATE_LIMIT_WINDOW_MS = 60000; // 1 minute
const MAX_REQUESTS_AUTHENTICATED = 20; // 20 requests per minute for authenticated users
const MAX_REQUESTS_ANONYMOUS = 5; // 5 requests per minute for anonymous users

function checkRateLimit(identifier: string, isAuthenticated: boolean): { allowed: boolean; remaining: number } {
  const now = Date.now();
  const maxRequests = isAuthenticated ? MAX_REQUESTS_AUTHENTICATED : MAX_REQUESTS_ANONYMOUS;
  const entry = rateLimitStore.get(identifier);

  // Clean up old entries periodically
  if (rateLimitStore.size > 1000) {
    for (const [key, value] of rateLimitStore.entries()) {
      if (now - value.windowStart > RATE_LIMIT_WINDOW_MS) {
        rateLimitStore.delete(key);
      }
    }
  }

  if (!entry || now - entry.windowStart > RATE_LIMIT_WINDOW_MS) {
    // New window
    rateLimitStore.set(identifier, { count: 1, windowStart: now });
    return { allowed: true, remaining: maxRequests - 1 };
  }

  if (entry.count >= maxRequests) {
    return { allowed: false, remaining: 0 };
  }

  entry.count++;
  return { allowed: true, remaining: maxRequests - entry.count };
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages, userId } = await req.json();
    
    // Rate limiting check
    const clientIp = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
    const identifier = userId || clientIp;
    const isAuthenticated = !!userId;
    
    const { allowed, remaining } = checkRateLimit(identifier, isAuthenticated);
    
    if (!allowed) {
      return new Response(
        JSON.stringify({ error: "Rate limit exceeded. Please try again in a minute." }),
        {
          status: 429,
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
            "X-RateLimit-Remaining": "0",
            "Retry-After": "60",
          },
        }
      );
    }
    
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    // Initialize Supabase client to fetch user claims if authenticated
    let claimsContext = "";
    if (userId) {
      const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
      const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
      const supabase = createClient(supabaseUrl, supabaseKey);

      // Fetch user's claims with tow record details
      const { data: claims, error } = await supabase
        .from("claims")
        .select(`
          id,
          claim_status,
          created_at,
          updated_at,
          tow_record:tow_records (
            id,
            make,
            model,
            plate_number,
            vin,
            color,
            tow_fee,
            daily_storage_fee,
            admin_fee,
            gate_fee,
            tow_datetime,
            status,
            tow_yard:tow_yards (
              name,
              address,
              city,
              state_province,
              phone
            )
          )
        `)
        .eq("consumer_user_id", userId)
        .order("created_at", { ascending: false });

      if (!error && claims && claims.length > 0) {
        claimsContext = `

USER'S CLAIMS DATA (CONFIDENTIAL - Only share with this user):
${claims.map((claim: any, index: number) => `
Claim ${index + 1}:
- Claim ID: ${claim.id}
- Status: ${claim.claim_status}
- Created: ${new Date(claim.created_at).toLocaleDateString()}
- Last Updated: ${new Date(claim.updated_at).toLocaleDateString()}
- Vehicle: ${claim.tow_record?.make || 'Unknown'} ${claim.tow_record?.model || ''} (${claim.tow_record?.color || 'Unknown color'})
- Plate: ${claim.tow_record?.plate_number || 'N/A'}
- VIN: ${claim.tow_record?.vin || 'N/A'}
- Tow Date: ${claim.tow_record?.tow_datetime ? new Date(claim.tow_record.tow_datetime).toLocaleDateString() : 'N/A'}
- Tow Yard: ${claim.tow_record?.tow_yard?.name || 'N/A'}
- Tow Yard Address: ${claim.tow_record?.tow_yard?.address || ''}, ${claim.tow_record?.tow_yard?.city || ''}, ${claim.tow_record?.tow_yard?.state_province || ''}
- Tow Yard Phone: ${claim.tow_record?.tow_yard?.phone || 'N/A'}
- Fees: Tow $${claim.tow_record?.tow_fee || 0}, Storage $${claim.tow_record?.daily_storage_fee || 0}/day, Admin $${claim.tow_record?.admin_fee || 0}, Gate $${claim.tow_record?.gate_fee || 0}
`).join('\n')}

When the user asks about their claims, provide accurate information from the data above. Explain status meanings:
- "started" = Claim has been initiated, documents need to be uploaded
- "docs_submitted" = Documents uploaded and awaiting review
- "docs_approved" = Documents verified, ready for payment
- "payment_pending" = Payment is being processed
- "complete" = Vehicle is ready for pickup
`;
      }
    }

    const systemPrompt = `You are Jack, a friendly and helpful customer support assistant for TowTrace - a platform that helps people find and claim their towed vehicles.

Your personality:
- Warm, professional, and empathetic (getting your car towed is stressful!)
- Clear and concise in explanations
- Proactive in offering next steps
- Always maintain a helpful, upbeat tone

You can help with:
1. Explaining how TowTrace works (search by plate or VIN, claim process, payment)
2. Answering questions about the claim process and document requirements
3. Providing status updates on claims (ONLY for authenticated users who own the claims)
4. Explaining fees and payment options
5. General questions about towing regulations and what to expect
6. Helping users understand what documents they need (government ID, registration, insurance)

Important rules:
- NEVER share claim details unless you have the user's claims data in context
- If someone asks about claim status but isn't logged in, politely ask them to log in first
- Be honest if you don't have access to specific information
- For complex issues, suggest contacting the tow yard directly or our support team
- Keep responses concise but thorough
${claimsContext}

If the user is logged in and asks about their claims, you have their data above - use it to give specific, helpful answers.`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Service temporarily unavailable. Please try again later." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      return new Response(JSON.stringify({ error: "Failed to get response. Please try again." }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("Jack chat error:", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
