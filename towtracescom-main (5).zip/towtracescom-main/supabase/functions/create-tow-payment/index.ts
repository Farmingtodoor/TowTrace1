import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";
import { checkRateLimit, getRateLimitIdentifier, rateLimitExceededResponse } from "../_shared/rate-limit.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const SERVICE_FEE_PERCENTAGE = 0.10; // 10% service fee

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseClient = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_ANON_KEY") ?? ""
  );

  try {
    const authHeader = req.headers.get("Authorization")!;
    const token = authHeader.replace("Bearer ", "");
    const { data } = await supabaseClient.auth.getUser(token);
    const user = data.user;
    if (!user?.email) throw new Error("User not authenticated");

    // Rate limiting check
    const identifier = getRateLimitIdentifier(req, user.id);
    const { allowed, retryAfter } = checkRateLimit(identifier, "payment");
    
    if (!allowed) {
      return rateLimitExceededResponse(retryAfter, corsHeaders);
    }

    const { claimId, towRecordId, totalDue } = await req.json();
    if (!claimId || !towRecordId || !totalDue) {
      throw new Error("Missing required fields: claimId, towRecordId, totalDue");
    }

    // Calculate service fee (5% of total)
    const serviceFee = Math.round(totalDue * SERVICE_FEE_PERCENTAGE * 100) / 100;
    const grandTotal = totalDue + serviceFee;

    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
      apiVersion: "2025-08-27.basil",
    });

    // Look up the tow record to get the tow_yard_id
    const supabaseAdmin = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    const { data: towRecord } = await supabaseAdmin
      .from("tow_records")
      .select("tow_yard_id")
      .eq("id", towRecordId)
      .single();

    if (!towRecord) throw new Error("Tow record not found");

    // Check if the tow yard has a connected Stripe account
    const { data: payoutSettings } = await supabaseAdmin
      .from("payout_settings")
      .select("stripe_account_id, stripe_connected")
      .eq("tow_yard_id", towRecord.tow_yard_id)
      .maybeSingle();

    const connectedAccountId = payoutSettings?.stripe_connected ? payoutSettings.stripe_account_id : null;

    // Check for existing customer
    const customers = await stripe.customers.list({ email: user.email, limit: 1 });
    let customerId;
    if (customers.data.length > 0) {
      customerId = customers.data[0].id;
    }

    const grandTotalCents = Math.round(grandTotal * 100);
    const serviceFeeCents = Math.round(serviceFee * 100);

    // Build checkout session options
    const sessionOptions: Stripe.Checkout.SessionCreateParams = {
      customer: customerId,
      customer_email: customerId ? undefined : user.email,
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: "Tow & Storage Fees",
              description: `Vehicle release payment for claim ${claimId}`,
            },
            unit_amount: Math.round(totalDue * 100),
          },
          quantity: 1,
        },
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: "Service Fee",
              description: "Platform service fee (10%)",
            },
            unit_amount: serviceFeeCents,
          },
          quantity: 1,
        },
      ],
      mode: "payment",
      success_url: `${req.headers.get("origin") || "https://towtracescom.lovable.app"}/my-claims?payment=success&claim=${claimId}`,
      cancel_url: `${req.headers.get("origin") || "https://towtracescom.lovable.app"}/my-claims?payment=cancelled&claim=${claimId}`,
      metadata: {
        claimId,
        towRecordId,
        totalDue: totalDue.toString(),
        serviceFee: serviceFee.toString(),
        userId: user.id,
        connectedAccountId: connectedAccountId || "",
      },
    };

    // If the tow yard has a connected Stripe account, use Connect to separate fees
    if (connectedAccountId) {
      sessionOptions.payment_intent_data = {
        application_fee_amount: serviceFeeCents,
        transfer_data: {
          destination: connectedAccountId,
        },
      };
      console.log(`Using Stripe Connect: ${serviceFeeCents} cents fee, destination: ${connectedAccountId}`);
    } else {
      console.log("No connected account — full payment goes to platform account");
    }

    const session = await stripe.checkout.sessions.create(sessionOptions);

    return new Response(JSON.stringify({ 
      url: session.url,
      serviceFee,
      grandTotal,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error: unknown) {
    // Log detailed payment gateway errors for debugging
    let errorMessage = "Unknown payment error";
    let errorCode = "";
    let errorType = "";
    
    if (error instanceof Error) {
      errorMessage = error.message;
      
      // Check if it's a Stripe error with additional details
      const stripeError = error as { type?: string; code?: string; decline_code?: string; param?: string };
      if (stripeError.type) {
        errorType = stripeError.type;
      }
      if (stripeError.code) {
        errorCode = stripeError.code;
      }
      if (stripeError.decline_code) {
        errorCode = stripeError.decline_code;
      }
    }
    
    // Log comprehensive error details
    console.error("Payment Error Details:", JSON.stringify({
      message: errorMessage,
      type: errorType,
      code: errorCode,
      timestamp: new Date().toISOString(),
    }));
    
    // Return user-friendly error with details for debugging
    return new Response(JSON.stringify({ 
      error: errorMessage,
      errorCode: errorCode || undefined,
      errorType: errorType || undefined,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
