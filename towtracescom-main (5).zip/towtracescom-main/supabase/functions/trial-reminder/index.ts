import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey) throw new Error("STRIPE_SECRET_KEY is not set");
    if (!RESEND_API_KEY) throw new Error("RESEND_API_KEY is not set");

    const stripe = new Stripe(stripeKey, { apiVersion: "2025-08-27.basil" });

    // Find subscriptions trialing that end in ~2 days (between 1.5 and 2.5 days from now)
    const now = Math.floor(Date.now() / 1000);
    const twoDaysFromNow = now + 2 * 24 * 60 * 60;
    const windowStart = twoDaysFromNow - 12 * 60 * 60; // 1.5 days
    const windowEnd = twoDaysFromNow + 12 * 60 * 60;   // 2.5 days

    const subscriptions = await stripe.subscriptions.list({
      status: "trialing",
      limit: 100,
    });

    let sentCount = 0;

    for (const sub of subscriptions.data) {
      if (!sub.trial_end) continue;
      if (sub.trial_end < windowStart || sub.trial_end > windowEnd) continue;

      // Get customer email
      const customer = await stripe.customers.retrieve(sub.customer as string);
      if (!customer || (customer as any).deleted || !(customer as any).email) continue;

      const customerEmail = (customer as any).email;
      const customerName = (customer as any).name || "Valued Customer";
      const trialEndDate = new Date(sub.trial_end * 1000).toLocaleDateString("en-US", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      });

      const planAmount = sub.items.data[0]?.price?.unit_amount;
      const planPrice = planAmount ? `$${(planAmount / 100).toFixed(2)}` : "your plan rate";

      const emailHtml = `
        <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #1a1a1a;">Your Free Trial Ends Soon</h1>
          <p>Hi ${customerName},</p>
          <p>This is a friendly reminder that your <strong>TowTrace free trial</strong> ends on <strong>${trialEndDate}</strong>.</p>
          <p>After your trial, your subscription will automatically renew at <strong>${planPrice}/month</strong> using the payment method on file.</p>
          <div style="background-color: #f5f5f5; padding: 16px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 0; font-weight: 600;">Want to cancel?</p>
            <p style="margin: 8px 0 0 0;">You can manage or cancel your subscription anytime from the Subscription section in your Operator Dashboard before the trial ends.</p>
          </div>
          <p>If you have any questions, don't hesitate to reach out to our support team.</p>
          <p>Best regards,<br>The TowTrace Team</p>
        </div>
      `;

      const emailRes = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${RESEND_API_KEY}`,
        },
        body: JSON.stringify({
          from: "TowTrace <notifications@resend.dev>",
          to: [customerEmail],
          subject: "Your TowTrace Free Trial Ends in 2 Days",
          html: emailHtml,
        }),
      });

      if (emailRes.ok) {
        sentCount++;
        console.log(`Trial reminder sent to ${customerEmail}`);
      } else {
        const err = await emailRes.text();
        console.error(`Failed to send to ${customerEmail}:`, err);
      }
    }

    return new Response(JSON.stringify({ success: true, remindersSent: sentCount }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("trial-reminder Error:", errorMessage);
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
