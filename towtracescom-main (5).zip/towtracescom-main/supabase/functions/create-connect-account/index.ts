import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseClient = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
  );

  try {
    const authHeader = req.headers.get("Authorization")!;
    const token = authHeader.replace("Bearer ", "");
    const { data } = await supabaseClient.auth.getUser(token);
    const user = data.user;
    if (!user?.email) throw new Error("User not authenticated");

    const { towYardId, action } = await req.json();
    if (!towYardId) throw new Error("Missing towYardId");

    // Verify user is an admin of this tow yard
    const { data: operator } = await supabaseClient
      .from("tow_yard_operators")
      .select("permission_level")
      .eq("tow_yard_id", towYardId)
      .eq("operator_user_id", user.id)
      .single();

    if (!operator || operator.permission_level !== "admin") {
      throw new Error("Unauthorized: must be a yard admin");
    }

    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
      apiVersion: "2025-08-27.basil",
    });

    // Get tow yard details
    const { data: yard } = await supabaseClient
      .from("tow_yards")
      .select("name, email")
      .eq("id", towYardId)
      .single();

    // Check if connected account already exists
    const { data: payoutSettings } = await supabaseClient
      .from("payout_settings")
      .select("stripe_account_id, stripe_connected")
      .eq("tow_yard_id", towYardId)
      .maybeSingle();

    let accountId = payoutSettings?.stripe_account_id;

    if (action === "check_status" && accountId) {
      // Check the account status on Stripe
      const account = await stripe.accounts.retrieve(accountId);
      const isFullyOnboarded = account.charges_enabled && account.payouts_enabled;

      if (isFullyOnboarded && !payoutSettings?.stripe_connected) {
        // Update our DB
        await supabaseClient
          .from("payout_settings")
          .update({ stripe_connected: true, is_verified: true })
          .eq("tow_yard_id", towYardId);
      }

      return new Response(JSON.stringify({
        accountId,
        chargesEnabled: account.charges_enabled,
        payoutsEnabled: account.payouts_enabled,
        detailsSubmitted: account.details_submitted,
        isFullyOnboarded,
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      });
    }

    // Create or re-use connected account
    if (!accountId) {
      const account = await stripe.accounts.create({
        type: "express",
        email: yard?.email || user.email,
        business_type: "company",
        company: {
          name: yard?.name || undefined,
        },
        capabilities: {
          card_payments: { requested: true },
          transfers: { requested: true },
        },
      });
      accountId = account.id;

      // Save the account ID
      if (payoutSettings) {
        await supabaseClient
          .from("payout_settings")
          .update({ stripe_account_id: accountId, payout_method: "stripe" })
          .eq("tow_yard_id", towYardId);
      } else {
        await supabaseClient
          .from("payout_settings")
          .insert({
            tow_yard_id: towYardId,
            stripe_account_id: accountId,
            payout_method: "stripe",
          });
      }
    }

    // Create onboarding link
    const origin = req.headers.get("origin") || "https://towtracescom.lovable.app";
    const accountLink = await stripe.accountLinks.create({
      account: accountId,
      refresh_url: `${origin}/operator?tab=payouts&connect=refresh`,
      return_url: `${origin}/operator?tab=payouts&connect=complete`,
      type: "account_onboarding",
    });

    return new Response(JSON.stringify({
      url: accountLink.url,
      accountId,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Connect account error:", errorMessage);
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
