-- Add driver_user_id to tow_records to track who towed the car
ALTER TABLE public.tow_records 
ADD COLUMN IF NOT EXISTS driver_user_id uuid REFERENCES auth.users(id);

-- Add driver_name for display purposes (in case driver is not a user)
ALTER TABLE public.tow_records 
ADD COLUMN IF NOT EXISTS driver_name text;

-- Create index for driver lookups
CREATE INDEX IF NOT EXISTS idx_tow_records_driver_user_id ON public.tow_records(driver_user_id);

-- Function to check if user is super admin (by email)
CREATE OR REPLACE FUNCTION public.is_super_admin(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM auth.users
    WHERE id = _user_id
      AND email = 'support@eventboomer.com'
  )
$$;

-- Insert admin role for the super admin email if they exist
-- This will be handled by a trigger when they sign up
CREATE OR REPLACE FUNCTION public.check_super_admin_on_signup()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.email = 'support@eventboomer.com' THEN
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;

-- Drop trigger if exists and recreate
DROP TRIGGER IF EXISTS on_auth_user_super_admin ON auth.users;
CREATE TRIGGER on_auth_user_super_admin
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.check_super_admin_on_signup();

-- Also check existing user and add admin role if needed
DO $$
DECLARE
  admin_user_id uuid;
BEGIN
  SELECT id INTO admin_user_id FROM auth.users WHERE email = 'support@eventboomer.com';
  IF admin_user_id IS NOT NULL THEN
    INSERT INTO public.user_roles (user_id, role)
    VALUES (admin_user_id, 'admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;
END $$;