-- Fix audit_logs INSERT policy to prevent log poisoning
-- Drop the overly permissive policy
DROP POLICY IF EXISTS "Anyone can insert audit logs" ON public.audit_logs;

-- Create a secure policy that ensures:
-- 1. Only authenticated users can insert audit logs
-- 2. Users can only log actions as themselves (actor_user_id must match auth.uid())
-- 3. NULL actor_user_id is allowed for system events
CREATE POLICY "Authenticated users can insert their own audit logs"
  ON public.audit_logs FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() IS NOT NULL AND
    (actor_user_id = auth.uid() OR actor_user_id IS NULL)
  );