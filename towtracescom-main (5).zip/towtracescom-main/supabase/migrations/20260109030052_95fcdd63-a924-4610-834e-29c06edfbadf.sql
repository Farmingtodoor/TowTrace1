-- Add more email templates for claim status updates and payment confirmations
INSERT INTO public.email_templates (template_key, name, subject, html_body, description) VALUES
(
  'claim_docs_submitted',
  'Documents Submitted',
  'Documents received for your vehicle claim',
  '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
    <div style="background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%); padding: 30px; border-radius: 12px 12px 0 0; text-align: center;">
      <h1 style="color: white; margin: 0; font-size: 24px;">📄 Documents Received</h1>
    </div>
    <div style="background: #f8fafc; padding: 30px; border-radius: 0 0 12px 12px;">
      <p style="font-size: 16px; color: #334155; margin-bottom: 20px;">
        We have received the documents for your vehicle claim at <strong>{{company_name}}</strong>.
      </p>
      <p style="font-size: 16px; color: #334155; margin-bottom: 20px;">
        Our team is reviewing your documents and will notify you once they are approved.
      </p>
      <div style="background: #e0f2fe; padding: 15px; border-radius: 8px; margin: 20px 0;">
        <p style="margin: 0; font-size: 14px; color: #0369a1;"><strong>Vehicle:</strong> {{vehicle_info}}</p>
        <p style="margin: 5px 0 0 0; font-size: 14px; color: #0369a1;"><strong>Status:</strong> Under Review</p>
      </div>
      <p style="font-size: 14px; color: #64748b; margin-top: 30px;">
        You will receive another notification once your documents have been reviewed.
      </p>
    </div>
  </div>',
  'Sent when a consumer submits documents for their vehicle claim.'
),
(
  'claim_docs_approved',
  'Documents Approved',
  'Your documents have been approved - {{vehicle_info}}',
  '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
    <div style="background: linear-gradient(135deg, #047857 0%, #10b981 100%); padding: 30px; border-radius: 12px 12px 0 0; text-align: center;">
      <h1 style="color: white; margin: 0; font-size: 24px;">✅ Documents Approved</h1>
    </div>
    <div style="background: #f8fafc; padding: 30px; border-radius: 0 0 12px 12px;">
      <p style="font-size: 16px; color: #334155; margin-bottom: 20px;">
        Great news! Your documents for the vehicle at <strong>{{company_name}}</strong> have been approved.
      </p>
      <div style="background: #d1fae5; padding: 15px; border-radius: 8px; margin: 20px 0;">
        <p style="margin: 0; font-size: 14px; color: #065f46;"><strong>Vehicle:</strong> {{vehicle_info}}</p>
        <p style="margin: 5px 0 0 0; font-size: 14px; color: #065f46;"><strong>Total Due:</strong> {{total_amount}}</p>
      </div>
      <p style="font-size: 16px; color: #334155; margin-bottom: 20px;">
        You can now proceed with payment to release your vehicle.
      </p>
      <div style="text-align: center; margin: 30px 0;">
        <a href="{{payment_url}}" style="background: #0d9488; color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: 600;">
          Pay Now
        </a>
      </div>
    </div>
  </div>',
  'Sent when documents for a claim are approved and payment is pending.'
),
(
  'claim_payment_pending',
  'Payment Pending',
  'Payment required for your vehicle release',
  '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
    <div style="background: linear-gradient(135deg, #d97706 0%, #f59e0b 100%); padding: 30px; border-radius: 12px 12px 0 0; text-align: center;">
      <h1 style="color: white; margin: 0; font-size: 24px;">💳 Payment Required</h1>
    </div>
    <div style="background: #f8fafc; padding: 30px; border-radius: 0 0 12px 12px;">
      <p style="font-size: 16px; color: #334155; margin-bottom: 20px;">
        Your vehicle at <strong>{{company_name}}</strong> is ready for release once payment is complete.
      </p>
      <div style="background: #fef3c7; padding: 15px; border-radius: 8px; margin: 20px 0;">
        <p style="margin: 0; font-size: 14px; color: #92400e;"><strong>Vehicle:</strong> {{vehicle_info}}</p>
        <p style="margin: 5px 0 0 0; font-size: 14px; color: #92400e;"><strong>Total Due:</strong> {{total_amount}}</p>
        <p style="margin: 5px 0 0 0; font-size: 14px; color: #92400e;"><strong>Daily Storage:</strong> {{daily_storage}} per day</p>
      </div>
      <p style="font-size: 14px; color: #b45309; margin-bottom: 20px;">
        ⚠️ Storage fees continue to accrue daily until payment is received.
      </p>
      <div style="text-align: center; margin: 30px 0;">
        <a href="{{payment_url}}" style="background: #d97706; color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: 600;">
          Complete Payment
        </a>
      </div>
    </div>
  </div>',
  'Reminder sent when payment is pending for a vehicle release.'
),
(
  'claim_complete',
  'Claim Complete',
  'Your vehicle has been released - Thank you!',
  '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
    <div style="background: linear-gradient(135deg, #059669 0%, #34d399 100%); padding: 30px; border-radius: 12px 12px 0 0; text-align: center;">
      <h1 style="color: white; margin: 0; font-size: 24px;">🚗 Vehicle Released!</h1>
    </div>
    <div style="background: #f8fafc; padding: 30px; border-radius: 0 0 12px 12px;">
      <p style="font-size: 16px; color: #334155; margin-bottom: 20px;">
        Your vehicle has been successfully released from <strong>{{company_name}}</strong>.
      </p>
      <div style="background: #d1fae5; padding: 15px; border-radius: 8px; margin: 20px 0;">
        <p style="margin: 0; font-size: 14px; color: #065f46;"><strong>Vehicle:</strong> {{vehicle_info}}</p>
        <p style="margin: 5px 0 0 0; font-size: 14px; color: #065f46;"><strong>Amount Paid:</strong> {{total_amount}}</p>
        <p style="margin: 5px 0 0 0; font-size: 14px; color: #065f46;"><strong>Release Date:</strong> {{release_date}}</p>
      </div>
      <p style="font-size: 16px; color: #334155; margin-bottom: 20px;">
        Thank you for using TowTrace. We hope you have a safe journey!
      </p>
      <div style="text-align: center; margin: 30px 0;">
        <a href="{{receipt_url}}" style="background: #0d9488; color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: 600;">
          View Receipt
        </a>
      </div>
    </div>
  </div>',
  'Sent when a claim is complete and vehicle has been released.'
),
(
  'payment_confirmation',
  'Payment Confirmation',
  'Payment received - Receipt #{{receipt_number}}',
  '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
    <div style="background: linear-gradient(135deg, #0d9488 0%, #14b8a6 100%); padding: 30px; border-radius: 12px 12px 0 0; text-align: center;">
      <h1 style="color: white; margin: 0; font-size: 24px;">💰 Payment Received</h1>
    </div>
    <div style="background: #f8fafc; padding: 30px; border-radius: 0 0 12px 12px;">
      <p style="font-size: 16px; color: #334155; margin-bottom: 20px;">
        We have received your payment for the vehicle at <strong>{{company_name}}</strong>.
      </p>
      <div style="background: #f1f5f9; padding: 20px; border-radius: 8px; margin: 20px 0; border: 1px solid #e2e8f0;">
        <h3 style="margin: 0 0 15px 0; color: #1e293b; font-size: 16px;">Receipt Details</h3>
        <table style="width: 100%; font-size: 14px; color: #475569;">
          <tr><td style="padding: 5px 0;">Receipt #:</td><td style="text-align: right; font-weight: 600;">{{receipt_number}}</td></tr>
          <tr><td style="padding: 5px 0;">Vehicle:</td><td style="text-align: right;">{{vehicle_info}}</td></tr>
          <tr><td style="padding: 5px 0;">Tow Fee:</td><td style="text-align: right;">{{tow_fee}}</td></tr>
          <tr><td style="padding: 5px 0;">Storage Fee:</td><td style="text-align: right;">{{storage_fee}}</td></tr>
          <tr><td style="padding: 5px 0;">Admin Fee:</td><td style="text-align: right;">{{admin_fee}}</td></tr>
          <tr><td style="padding: 5px 0; border-top: 1px solid #e2e8f0; font-weight: 600;">Total Paid:</td><td style="text-align: right; border-top: 1px solid #e2e8f0; font-weight: 600; color: #0d9488;">{{total_amount}}</td></tr>
        </table>
      </div>
      <p style="font-size: 14px; color: #64748b; margin-top: 30px;">
        Please present this receipt when picking up your vehicle.
      </p>
      <div style="text-align: center; margin: 30px 0;">
        <a href="{{receipt_url}}" style="background: #0d9488; color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: 600;">
          Download Receipt
        </a>
      </div>
    </div>
  </div>',
  'Sent when a payment is successfully processed.'
),
(
  'payment_failed',
  'Payment Failed',
  'Payment unsuccessful - Please try again',
  '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
    <div style="background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%); padding: 30px; border-radius: 12px 12px 0 0; text-align: center;">
      <h1 style="color: white; margin: 0; font-size: 24px;">❌ Payment Failed</h1>
    </div>
    <div style="background: #f8fafc; padding: 30px; border-radius: 0 0 12px 12px;">
      <p style="font-size: 16px; color: #334155; margin-bottom: 20px;">
        Unfortunately, your payment for the vehicle at <strong>{{company_name}}</strong> was unsuccessful.
      </p>
      <div style="background: #fee2e2; padding: 15px; border-radius: 8px; margin: 20px 0;">
        <p style="margin: 0; font-size: 14px; color: #991b1b;"><strong>Vehicle:</strong> {{vehicle_info}}</p>
        <p style="margin: 5px 0 0 0; font-size: 14px; color: #991b1b;"><strong>Amount:</strong> {{total_amount}}</p>
        <p style="margin: 5px 0 0 0; font-size: 14px; color: #991b1b;"><strong>Reason:</strong> {{failure_reason}}</p>
      </div>
      <p style="font-size: 16px; color: #334155; margin-bottom: 20px;">
        Please try again with a different payment method or contact your bank.
      </p>
      <div style="text-align: center; margin: 30px 0;">
        <a href="{{payment_url}}" style="background: #dc2626; color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: 600;">
          Try Again
        </a>
      </div>
    </div>
  </div>',
  'Sent when a payment attempt fails.'
);

-- Create payout_settings table for company withdrawal preferences
CREATE TABLE public.payout_settings (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tow_yard_id uuid NOT NULL REFERENCES public.tow_yards(id) ON DELETE CASCADE,
  payout_method text NOT NULL DEFAULT 'bank_account',
  -- Bank account details
  bank_name text,
  bank_account_number text,
  bank_routing_number text,
  bank_account_holder_name text,
  -- Stripe Connect
  stripe_account_id text,
  stripe_connected boolean DEFAULT false,
  -- PayPal
  paypal_email text,
  -- Apple Pay
  apple_pay_merchant_id text,
  -- General settings
  minimum_payout_amount numeric DEFAULT 50,
  payout_frequency text DEFAULT 'weekly',
  is_verified boolean DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(tow_yard_id)
);

-- Enable RLS
ALTER TABLE public.payout_settings ENABLE ROW LEVEL SECURITY;

-- Admins can manage all payout settings
CREATE POLICY "Admins can manage all payout settings"
ON public.payout_settings
FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

-- Operators can view their own payout settings
CREATE POLICY "Operators can view their payout settings"
ON public.payout_settings
FOR SELECT
TO authenticated
USING (EXISTS (
  SELECT 1 FROM tow_yard_operators
  WHERE tow_yard_operators.tow_yard_id = payout_settings.tow_yard_id
  AND tow_yard_operators.operator_user_id = auth.uid()
));

-- Yard admins can manage their payout settings
CREATE POLICY "Yard admins can insert payout settings"
ON public.payout_settings
FOR INSERT
TO authenticated
WITH CHECK (EXISTS (
  SELECT 1 FROM tow_yard_operators
  WHERE tow_yard_operators.tow_yard_id = payout_settings.tow_yard_id
  AND tow_yard_operators.operator_user_id = auth.uid()
  AND tow_yard_operators.permission_level = 'admin'
));

CREATE POLICY "Yard admins can update payout settings"
ON public.payout_settings
FOR UPDATE
TO authenticated
USING (EXISTS (
  SELECT 1 FROM tow_yard_operators
  WHERE tow_yard_operators.tow_yard_id = payout_settings.tow_yard_id
  AND tow_yard_operators.operator_user_id = auth.uid()
  AND tow_yard_operators.permission_level = 'admin'
));

-- Add trigger for updated_at
CREATE TRIGGER update_payout_settings_updated_at
BEFORE UPDATE ON public.payout_settings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();