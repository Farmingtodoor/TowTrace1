
-- Allow anonymous/public users to search tow_records (non-released only, matching the search logic)
CREATE POLICY "Public can search tow records"
ON public.tow_records
FOR SELECT
USING (status != 'released');

-- Allow anonymous/public users to view approved tow yards (needed for the join)
CREATE POLICY "Public can view approved tow yards"
ON public.tow_yards
FOR SELECT
USING (is_approved = true);
