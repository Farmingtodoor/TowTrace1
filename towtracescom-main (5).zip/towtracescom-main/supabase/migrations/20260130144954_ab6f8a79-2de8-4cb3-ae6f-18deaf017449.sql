-- Allow authenticated users to self-assign operator or consumer roles during signup
CREATE POLICY "Users can self-assign operator or consumer role" 
ON public.user_roles 
FOR INSERT 
TO authenticated
WITH CHECK (
  user_id = auth.uid() 
  AND role IN ('operator'::app_role, 'consumer'::app_role)
);