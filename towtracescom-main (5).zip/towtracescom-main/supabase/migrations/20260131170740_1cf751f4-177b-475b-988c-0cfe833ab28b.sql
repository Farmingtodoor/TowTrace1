-- Add locking fields to tow_records table
ALTER TABLE public.tow_records 
ADD COLUMN locked_by_user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
ADD COLUMN locked_at timestamp with time zone,
ADD COLUMN locked_by_name text;

-- Create index for efficient lock queries
CREATE INDEX idx_tow_records_locked_by ON public.tow_records(locked_by_user_id) WHERE locked_by_user_id IS NOT NULL;

-- Create function to acquire a lock on a record
CREATE OR REPLACE FUNCTION public.acquire_record_lock(
  _record_id uuid,
  _user_id uuid,
  _user_name text,
  _lock_timeout_minutes integer DEFAULT 30
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  current_lock record;
  result jsonb;
BEGIN
  -- Get current lock status
  SELECT locked_by_user_id, locked_at, locked_by_name
  INTO current_lock
  FROM public.tow_records
  WHERE id = _record_id;
  
  -- Check if record exists
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Record not found');
  END IF;
  
  -- Check if already locked by someone else and lock hasn't expired
  IF current_lock.locked_by_user_id IS NOT NULL 
     AND current_lock.locked_by_user_id != _user_id
     AND current_lock.locked_at > (now() - (_lock_timeout_minutes || ' minutes')::interval) THEN
    RETURN jsonb_build_object(
      'success', false, 
      'error', 'Record is locked by another user',
      'locked_by', current_lock.locked_by_name,
      'locked_at', current_lock.locked_at
    );
  END IF;
  
  -- Acquire the lock (or refresh if already owned)
  UPDATE public.tow_records
  SET 
    locked_by_user_id = _user_id,
    locked_at = now(),
    locked_by_name = _user_name
  WHERE id = _record_id;
  
  RETURN jsonb_build_object('success', true, 'message', 'Lock acquired');
END;
$$;

-- Create function to release a lock
CREATE OR REPLACE FUNCTION public.release_record_lock(
  _record_id uuid,
  _user_id uuid,
  _force boolean DEFAULT false
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  current_lock record;
BEGIN
  -- Get current lock status
  SELECT locked_by_user_id, locked_by_name
  INTO current_lock
  FROM public.tow_records
  WHERE id = _record_id;
  
  -- Check if record exists
  IF NOT FOUND THEN
    RETURN jsonb_build_object('success', false, 'error', 'Record not found');
  END IF;
  
  -- Check if locked by the requesting user or force release
  IF current_lock.locked_by_user_id IS NULL THEN
    RETURN jsonb_build_object('success', true, 'message', 'Record was not locked');
  END IF;
  
  IF current_lock.locked_by_user_id != _user_id AND NOT _force THEN
    RETURN jsonb_build_object(
      'success', false, 
      'error', 'Cannot release lock owned by another user',
      'locked_by', current_lock.locked_by_name
    );
  END IF;
  
  -- Release the lock
  UPDATE public.tow_records
  SET 
    locked_by_user_id = NULL,
    locked_at = NULL,
    locked_by_name = NULL
  WHERE id = _record_id;
  
  RETURN jsonb_build_object('success', true, 'message', 'Lock released');
END;
$$;

-- Create function to check lock status
CREATE OR REPLACE FUNCTION public.check_record_lock(
  _record_id uuid,
  _lock_timeout_minutes integer DEFAULT 30
)
RETURNS jsonb
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  current_lock record;
BEGIN
  SELECT locked_by_user_id, locked_at, locked_by_name
  INTO current_lock
  FROM public.tow_records
  WHERE id = _record_id;
  
  IF NOT FOUND THEN
    RETURN jsonb_build_object('locked', false, 'error', 'Record not found');
  END IF;
  
  -- Check if lock exists and hasn't expired
  IF current_lock.locked_by_user_id IS NOT NULL 
     AND current_lock.locked_at > (now() - (_lock_timeout_minutes || ' minutes')::interval) THEN
    RETURN jsonb_build_object(
      'locked', true,
      'locked_by_user_id', current_lock.locked_by_user_id,
      'locked_by_name', current_lock.locked_by_name,
      'locked_at', current_lock.locked_at
    );
  END IF;
  
  -- Lock expired or doesn't exist
  RETURN jsonb_build_object('locked', false);
END;
$$;