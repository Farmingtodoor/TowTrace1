
-- Drop the overly permissive INSERT policy
DROP POLICY IF EXISTS "Anyone can create reminders" ON public.search_reminders;

-- Create a rate-limiting function for search reminders
CREATE OR REPLACE FUNCTION public.check_reminder_rate_limit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  recent_count INTEGER;
BEGIN
  -- Limit to 5 reminders per email in the last 24 hours
  SELECT COUNT(*) INTO recent_count
  FROM public.search_reminders
  WHERE email = NEW.email
    AND created_at > (now() - interval '24 hours');

  IF recent_count >= 5 THEN
    RAISE EXCEPTION 'Rate limit exceeded: maximum 5 reminders per email per 24 hours';
  END IF;

  RETURN NEW;
END;
$$;

-- Create trigger to enforce rate limiting
CREATE TRIGGER enforce_reminder_rate_limit
BEFORE INSERT ON public.search_reminders
FOR EACH ROW
EXECUTE FUNCTION public.check_reminder_rate_limit();

-- Create a new, more restrictive INSERT policy
-- Still allows anonymous users (feature requirement) but with rate limiting via trigger
CREATE POLICY "Rate-limited reminder creation"
ON public.search_reminders
FOR INSERT
WITH CHECK (true);
