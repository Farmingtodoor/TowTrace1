-- Add unique constraint to ensure only one claim per tow record (vehicle can only be claimed once)
ALTER TABLE public.claims ADD CONSTRAINT claims_tow_record_id_unique UNIQUE (tow_record_id);