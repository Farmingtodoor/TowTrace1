-- Add 'operator' value to the employee_role enum
ALTER TYPE public.employee_role ADD VALUE IF NOT EXISTS 'operator' AFTER 'viewer';