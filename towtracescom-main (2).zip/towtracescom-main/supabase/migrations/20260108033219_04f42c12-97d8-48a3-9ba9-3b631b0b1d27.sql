-- Add vehicle_type column to tow_records
ALTER TABLE public.tow_records 
ADD COLUMN vehicle_type text DEFAULT 'standard';

-- Create fee_configurations table for vehicle type-based fee defaults
CREATE TABLE public.fee_configurations (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tow_yard_id uuid NOT NULL REFERENCES public.tow_yards(id) ON DELETE CASCADE,
  vehicle_type text NOT NULL,
  tow_fee numeric NOT NULL DEFAULT 0,
  daily_storage_fee numeric NOT NULL DEFAULT 0,
  admin_fee numeric NOT NULL DEFAULT 0,
  gate_fee numeric NOT NULL DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(tow_yard_id, vehicle_type)
);

-- Enable RLS
ALTER TABLE public.fee_configurations ENABLE ROW LEVEL SECURITY;

-- Policies for fee_configurations
CREATE POLICY "Operators can view fee configs for their yards"
ON public.fee_configurations FOR SELECT
USING (EXISTS (
  SELECT 1 FROM tow_yard_operators
  WHERE tow_yard_operators.tow_yard_id = fee_configurations.tow_yard_id
  AND tow_yard_operators.operator_user_id = auth.uid()
));

CREATE POLICY "Operators can insert fee configs for their yards"
ON public.fee_configurations FOR INSERT
WITH CHECK (EXISTS (
  SELECT 1 FROM tow_yard_operators
  WHERE tow_yard_operators.tow_yard_id = fee_configurations.tow_yard_id
  AND tow_yard_operators.operator_user_id = auth.uid()
));

CREATE POLICY "Operators can update fee configs for their yards"
ON public.fee_configurations FOR UPDATE
USING (EXISTS (
  SELECT 1 FROM tow_yard_operators
  WHERE tow_yard_operators.tow_yard_id = fee_configurations.tow_yard_id
  AND tow_yard_operators.operator_user_id = auth.uid()
));

CREATE POLICY "Operators can delete fee configs for their yards"
ON public.fee_configurations FOR DELETE
USING (EXISTS (
  SELECT 1 FROM tow_yard_operators
  WHERE tow_yard_operators.tow_yard_id = fee_configurations.tow_yard_id
  AND tow_yard_operators.operator_user_id = auth.uid()
));

CREATE POLICY "Admins can manage all fee configs"
ON public.fee_configurations FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

-- Update trigger for updated_at
CREATE TRIGGER update_fee_configurations_updated_at
BEFORE UPDATE ON public.fee_configurations
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();