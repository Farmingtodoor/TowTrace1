-- 1/2: Add new role values (must be committed before being referenced)
DO $$
BEGIN
  BEGIN
    ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'super_admin';
  EXCEPTION WHEN duplicate_object THEN
    NULL;
  END;

  BEGIN
    ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'reviewer';
  EXCEPTION WHEN duplicate_object THEN
    NULL;
  END;

  BEGIN
    ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'analyst';
  EXCEPTION WHEN duplicate_object THEN
    NULL;
  END;
END$$;