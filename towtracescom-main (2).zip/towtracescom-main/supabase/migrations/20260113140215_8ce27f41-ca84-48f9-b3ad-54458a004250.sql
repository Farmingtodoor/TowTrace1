-- Fix ERROR: tow_records publicly readable - restrict to authenticated users only
-- Business requirement: Users need to search for their towed vehicle by plate/VIN
DROP POLICY IF EXISTS "Anyone can search tow records" ON public.tow_records;

CREATE POLICY "Authenticated users can search tow records"
ON public.tow_records
FOR SELECT
USING (auth.uid() IS NOT NULL);

-- Fix ERROR: email_templates "Service role can read templates" is too permissive
-- The service role policy with "true" condition allows anyone to read
DROP POLICY IF EXISTS "Service role can read templates" ON public.email_templates;