-- Fix: Restrict tow_yards to authenticated users only (remove public SELECT)
DROP POLICY IF EXISTS "Anyone can view approved tow yards" ON public.tow_yards;

CREATE POLICY "Authenticated users can view approved tow yards"
ON public.tow_yards
FOR SELECT
USING (auth.uid() IS NOT NULL AND is_approved = true);

-- Fix: Restrict email_templates to admins only
DROP POLICY IF EXISTS "Email templates are viewable by everyone" ON public.email_templates;
DROP POLICY IF EXISTS "Anyone can view email templates" ON public.email_templates;

CREATE POLICY "Only admins can view email templates"
ON public.email_templates
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_roles.user_id = auth.uid()
    AND user_roles.role = 'admin'
  )
);