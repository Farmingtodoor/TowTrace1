-- Create search_reminders table for storing reminder requests
CREATE TABLE public.search_reminders (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  search_type TEXT NOT NULL CHECK (search_type IN ('plate', 'vin')),
  search_value TEXT NOT NULL,
  reminder_minutes INTEGER NOT NULL DEFAULT 30,
  remind_at TIMESTAMP WITH TIME ZONE NOT NULL,
  sent BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.search_reminders ENABLE ROW LEVEL SECURITY;

-- Policy: Anyone can insert reminders (even anonymous)
CREATE POLICY "Anyone can create reminders"
ON public.search_reminders
FOR INSERT
TO authenticated, anon
WITH CHECK (true);

-- Policy: Users can view their own reminders
CREATE POLICY "Users can view their own reminders"
ON public.search_reminders
FOR SELECT
USING (
  (auth.uid() IS NOT NULL AND user_id = auth.uid()) 
  OR (auth.uid() IS NULL AND user_id IS NULL)
);

-- Policy: Service role can update reminders (for marking as sent)
CREATE POLICY "Service role can update reminders"
ON public.search_reminders
FOR UPDATE
USING (true)
WITH CHECK (true);

-- Create index for efficient reminder queries
CREATE INDEX idx_search_reminders_pending ON public.search_reminders(remind_at, sent) WHERE sent = false;