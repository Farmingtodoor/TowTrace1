import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";

async function sendNotification(type: string, to: string, name: string, data: Record<string, unknown>) {
  try {
    const response = await fetch(`${SUPABASE_URL}/functions/v1/send-notification`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${Deno.env.get("SUPABASE_ANON_KEY")}`,
      },
      body: JSON.stringify({ type, to, name, data }),
    });
    console.log("Notification sent:", await response.json());
  } catch (error) {
    console.error("Failed to send notification:", error);
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseClient = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
  );

  try {
    // Extract the Authorization header to verify the caller
    const authHeader = req.headers.get("Authorization");
    
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      console.error("Missing or invalid Authorization header");
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 401,
      });
    }

    const token = authHeader.replace("Bearer ", "");
    
    // Verify the user is authenticated
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token);
    
    if (authError || !user) {
      console.error("Auth verification failed:", authError?.message);
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 401,
      });
    }

    // Verify user has admin role using RPC
    const { data: isAdmin, error: roleError } = await supabaseClient.rpc('has_role', {
      _user_id: user.id,
      _role: 'admin'
    });

    // Also check if user is a tow yard operator (they can trigger notifications for their records)
    const { data: operatorData } = await supabaseClient
      .from('tow_yard_operators')
      .select('id')
      .eq('operator_user_id', user.id)
      .limit(1);
    
    const isOperator = operatorData && operatorData.length > 0;

    if (!isAdmin && !isOperator) {
      console.error("User not authorized:", user.id);
      return new Response(JSON.stringify({ error: "Forbidden: Admin or operator access required" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 403,
      });
    }

    const { type, email, name, data } = await req.json();

    // Log the request for audit purposes
    console.log(`Notification request from user ${user.id}: type=${type}, email=${email}`);

    // This is a manual trigger endpoint for sending notifications
    // Now secured to require authenticated admin/operator
    if (type && email) {
      await sendNotification(type, email, name || 'Customer', data || {});
      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      });
    }

    return new Response(JSON.stringify({ error: "Missing type or email" }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 400,
    });
  } catch (error: unknown) {
    // Comprehensive error logging
    let errorMessage = "Unknown error";
    let errorCode = "";
    let errorStack = "";
    
    if (error instanceof Error) {
      errorMessage = error.message;
      errorStack = error.stack || "";
    }
    
    console.error("payment-webhook Error:", JSON.stringify({
      message: errorMessage,
      code: errorCode || undefined,
      stack: errorStack,
      timestamp: new Date().toISOString(),
      function: "payment-webhook",
    }));
    
    return new Response(JSON.stringify({ 
      error: errorMessage,
      errorCode: errorCode || undefined,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
