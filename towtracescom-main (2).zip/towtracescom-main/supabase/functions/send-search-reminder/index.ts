import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import { Resend } from "https://esm.sh/resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

// HTML escape function to prevent XSS in email templates
function escapeHtml(text: string | undefined | null): string {
  if (text === undefined || text === null) return '';
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get all pending reminders that are due
    const now = new Date().toISOString();
    const { data: reminders, error: fetchError } = await supabase
      .from("search_reminders")
      .select("*")
      .eq("sent", false)
      .lte("remind_at", now);

    if (fetchError) {
      throw new Error(`Failed to fetch reminders: ${fetchError.message}`);
    }

    console.log(`Found ${reminders?.length || 0} pending reminders to process`);

    const results = [];

    for (const reminder of reminders || []) {
      try {
        const searchTypeLabel = reminder.search_type === 'plate' ? 'license plate' : 'VIN';
        const safeSearchValue = escapeHtml(reminder.search_value);
        
        const emailResponse = await resend.emails.send({
          from: "TowTrace <noreply@towtrace.com>",
          to: [reminder.email],
          subject: "⏰ Reminder: Search for your vehicle again",
          html: `
            <!DOCTYPE html>
            <html>
            <head>
              <style>
                body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(135deg, #1e3a5f 0%, #2d5a87 100%); color: white; padding: 30px; text-align: center; border-radius: 12px 12px 0 0; }
                .content { background: #f8f9fa; padding: 30px; border-radius: 0 0 12px 12px; }
                .search-info { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #f59e0b; }
                .cta-button { display: inline-block; background: #f59e0b; color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: bold; margin: 20px 0; }
                .footer { text-align: center; color: #666; font-size: 12px; margin-top: 20px; }
              </style>
            </head>
            <body>
              <div class="container">
                <div class="header">
                  <h1>🚗 Time to Search Again!</h1>
                </div>
                <div class="content">
                  <p>Hi there,</p>
                  <p>You set a reminder to search for your vehicle again. New tow records may have been added since your last search.</p>
                  
                  <div class="search-info">
                    <strong>Your Search Details:</strong><br>
                    <span style="color: #666;">Type:</span> ${searchTypeLabel.charAt(0).toUpperCase() + searchTypeLabel.slice(1)}<br>
                    <span style="color: #666;">Value:</span> <code style="background: #e5e5e5; padding: 2px 6px; border-radius: 4px;">${safeSearchValue}</code>
                  </div>
                  
                  <p>Click the button below to search again:</p>
                  
                  <a href="https://towtracescom.lovable.app" class="cta-button">
                    Search Now →
                  </a>
                  
                  <p style="color: #666; font-size: 14px;">
                    💡 <strong>Tip:</strong> If your vehicle was recently towed, it may take up to 2 hours for the record to appear in our system.
                  </p>
                </div>
                <div class="footer">
                  <p>© ${new Date().getFullYear()} TowTrace. Helping you find your vehicle faster.</p>
                  <p>You received this email because you set a search reminder on TowTrace.</p>
                </div>
              </div>
            </body>
            </html>
          `,
        });

        console.log(`Reminder email sent to ${reminder.email}:`, emailResponse);

        // Mark reminder as sent
        await supabase
          .from("search_reminders")
          .update({ sent: true })
          .eq("id", reminder.id);

        results.push({ id: reminder.id, status: "sent", email: reminder.email });
      } catch (emailError: any) {
        console.error(`Failed to send reminder to ${reminder.email}:`, emailError);
        results.push({ id: reminder.id, status: "failed", error: emailError.message });
      }
    }

    return new Response(
      JSON.stringify({ 
        processed: results.length, 
        results 
      }),
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  } catch (error: any) {
    console.error("Error in send-search-reminder function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
