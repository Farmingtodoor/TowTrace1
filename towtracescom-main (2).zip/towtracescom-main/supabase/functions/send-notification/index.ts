import { serve } from "https://deno.land/std@0.190.0/http/server.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface NotificationRequest {
  type: 'payment_completed' | 'subscription_created' | 'subscription_cancelled' | 'claim_status_changed' | 'evidence_requested';
  to: string;
  name?: string;
  data?: Record<string, unknown>;
}

// HTML escape function to prevent XSS in email templates
function escapeHtml(text: string | undefined | null): string {
  if (text === undefined || text === null) return '';
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

const getEmailContent = (type: string, name: string, data: Record<string, unknown>) => {
  // Escape all user-controlled inputs
  const safeName = escapeHtml(name);
  const safeAmount = escapeHtml(String(data.amount || '0.00'));
  const safeTransactionId = escapeHtml(String(data.transactionId || 'N/A'));
  const safePlan = escapeHtml(String(data.plan || 'Pro'));
  const safeStatus = escapeHtml(String(data.status || 'Updated'));
  const safeMessage = escapeHtml(String(data.message || ''));
  const safeDisputeType = escapeHtml(String(data.disputeType || 'dispute'));
  const safeVehicleInfo = escapeHtml(String(data.vehicleInfo || 'your vehicle'));
  const safeEvidenceNotes = escapeHtml(String(data.evidenceNotes || ''));
  const safeDisputeUrl = escapeHtml(String(data.disputeUrl || ''));

  const subjects: Record<string, string> = {
    payment_completed: 'Payment Confirmation - TowTrace',
    subscription_created: 'Welcome to TowTrace Pro!',
    subscription_cancelled: 'Subscription Cancelled - TowTrace',
    claim_status_changed: 'Claim Status Update - TowTrace',
    evidence_requested: 'Additional Evidence Needed - TowTrace Dispute',
  };

  const templates: Record<string, string> = {
    payment_completed: `
      <h1>Payment Confirmed!</h1>
      <p>Hi ${safeName},</p>
      <p>Your payment of <strong>$${safeAmount}</strong> has been processed successfully.</p>
      <p>Transaction ID: ${safeTransactionId}</p>
      <p>Thank you for using TowTrace!</p>
      <p>Best regards,<br>The TowTrace Team</p>
    `,
    subscription_created: `
      <h1>Welcome to TowTrace ${safePlan}!</h1>
      <p>Hi ${safeName},</p>
      <p>Your subscription is now active. You now have access to all ${safePlan} features.</p>
      <p>Thank you for choosing TowTrace!</p>
      <p>Best regards,<br>The TowTrace Team</p>
    `,
    subscription_cancelled: `
      <h1>Subscription Cancelled</h1>
      <p>Hi ${safeName},</p>
      <p>Your TowTrace subscription has been cancelled.</p>
      <p>We're sorry to see you go. If you change your mind, you can resubscribe anytime.</p>
      <p>Best regards,<br>The TowTrace Team</p>
    `,
    claim_status_changed: `
      <h1>Claim Status Update</h1>
      <p>Hi ${safeName},</p>
      <p>Your claim status has been updated to: <strong>${safeStatus}</strong></p>
      ${safeMessage ? `<p>${safeMessage}</p>` : ''}
      <p>Log in to TowTrace to view more details.</p>
      <p>Best regards,<br>The TowTrace Team</p>
    `,
    evidence_requested: `
      <h1>Additional Evidence Requested</h1>
      <p>Hi ${safeName},</p>
      <p>The tow yard operator reviewing your <strong>${safeDisputeType}</strong> dispute for <strong>${safeVehicleInfo}</strong> has requested additional evidence.</p>
      ${safeEvidenceNotes ? `
      <div style="background-color: #f5f5f5; padding: 16px; border-radius: 8px; margin: 16px 0;">
        <p style="margin: 0; font-weight: 600;">Operator's Notes:</p>
        <p style="margin: 8px 0 0 0;">${safeEvidenceNotes}</p>
      </div>
      ` : ''}
      <p>Please log in to your TowTrace account to upload the requested documents.</p>
      ${safeDisputeUrl ? `<p><a href="${safeDisputeUrl}" style="display: inline-block; background-color: #3b82f6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px;">View Dispute</a></p>` : ''}
      <p>If you have any questions, please contact the tow yard directly.</p>
      <p>Best regards,<br>The TowTrace Team</p>
    `,
  };

  return {
    subject: subjects[type] || 'Notification from TowTrace',
    html: templates[type] || `<p>Hi ${safeName}, you have a new notification from TowTrace.</p>`,
  };
};

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { type, to, name = 'Valued Customer', data = {} }: NotificationRequest = await req.json();

    if (!to || !type) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields: to, type' }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const { subject, html } = getEmailContent(type, name, data);

    const emailResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: "TowTrace <notifications@resend.dev>",
        to: [to],
        subject,
        html,
      }),
    });

    const result = await emailResponse.json();

    if (!emailResponse.ok) {
      throw new Error(result.message || "Failed to send email");
    }

    console.log("Notification sent successfully:", result);

    console.log("Notification sent successfully:", emailResponse);

    return new Response(JSON.stringify({ success: true, ...result }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: unknown) {
    // Comprehensive error logging
    let errorMessage = "Unknown error";
    let errorCode = "";
    let errorStack = "";
    
    if (error instanceof Error) {
      errorMessage = error.message;
      errorStack = error.stack || "";
    }
    
    // Check for Resend API specific errors
    const apiError = error as { statusCode?: number; code?: string };
    if (apiError.code) errorCode = apiError.code;
    
    console.error("send-notification Error:", JSON.stringify({
      message: errorMessage,
      code: errorCode || undefined,
      stack: errorStack,
      timestamp: new Date().toISOString(),
      function: "send-notification",
    }));
    
    return new Response(
      JSON.stringify({ 
        error: errorMessage,
        errorCode: errorCode || undefined,
      }),
      { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  }
};

serve(handler);
