import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";
import { checkRateLimit, getRateLimitIdentifier, rateLimitExceededResponse } from "../_shared/rate-limit.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SERVICE_FEE_PERCENTAGE = 0.05; // 5% service fee

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseClient = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_ANON_KEY") ?? ""
  );

  try {
    const authHeader = req.headers.get("Authorization")!;
    const token = authHeader.replace("Bearer ", "");
    const { data } = await supabaseClient.auth.getUser(token);
    const user = data.user;
    if (!user?.email) throw new Error("User not authenticated");

    // Rate limiting check
    const identifier = getRateLimitIdentifier(req, user.id);
    const { allowed, retryAfter } = checkRateLimit(identifier, "payment");
    
    if (!allowed) {
      return rateLimitExceededResponse(retryAfter, corsHeaders);
    }

    const { claimId, towRecordId, totalDue } = await req.json();
    if (!claimId || !towRecordId || !totalDue) {
      throw new Error("Missing required fields: claimId, towRecordId, totalDue");
    }

    // Calculate service fee (5% of total)
    const serviceFee = Math.round(totalDue * SERVICE_FEE_PERCENTAGE * 100) / 100;
    const grandTotal = totalDue + serviceFee;

    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
      apiVersion: "2025-08-27.basil",
    });

    // Check for existing customer
    const customers = await stripe.customers.list({ email: user.email, limit: 1 });
    let customerId;
    if (customers.data.length > 0) {
      customerId = customers.data[0].id;
    }

    // Create checkout session with dynamic pricing
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      customer_email: customerId ? undefined : user.email,
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: "Tow & Storage Fees",
              description: `Vehicle release payment for claim ${claimId}`,
            },
            unit_amount: Math.round(totalDue * 100), // Convert to cents
          },
          quantity: 1,
        },
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: "Service Fee",
              description: "Platform service fee (5%)",
            },
            unit_amount: Math.round(serviceFee * 100),
          },
          quantity: 1,
        },
      ],
      mode: "payment",
      success_url: `${req.headers.get("origin")}/my-claims?payment=success&claim=${claimId}`,
      cancel_url: `${req.headers.get("origin")}/my-claims?payment=cancelled&claim=${claimId}`,
      metadata: {
        claimId,
        towRecordId,
        totalDue: totalDue.toString(),
        serviceFee: serviceFee.toString(),
        userId: user.id,
      },
    });

    return new Response(JSON.stringify({ 
      url: session.url,
      serviceFee,
      grandTotal,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error: unknown) {
    // Log detailed payment gateway errors for debugging
    let errorMessage = "Unknown payment error";
    let errorCode = "";
    let errorType = "";
    
    if (error instanceof Error) {
      errorMessage = error.message;
      
      // Check if it's a Stripe error with additional details
      const stripeError = error as { type?: string; code?: string; decline_code?: string; param?: string };
      if (stripeError.type) {
        errorType = stripeError.type;
      }
      if (stripeError.code) {
        errorCode = stripeError.code;
      }
      if (stripeError.decline_code) {
        errorCode = stripeError.decline_code;
      }
    }
    
    // Log comprehensive error details
    console.error("Payment Error Details:", JSON.stringify({
      message: errorMessage,
      type: errorType,
      code: errorCode,
      timestamp: new Date().toISOString(),
    }));
    
    // Return user-friendly error with details for debugging
    return new Response(JSON.stringify({ 
      error: errorMessage,
      errorCode: errorCode || undefined,
      errorType: errorType || undefined,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
