import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CreditCard, Loader2, Shield, Info } from 'lucide-react';
import { useState } from 'react';
import { calculateServiceFee, calculateGrandTotal, createTowPayment } from '@/lib/payments';

interface PaymentSummaryProps {
  claimId: string;
  towRecordId: string;
  towFee: number;
  storageFee: number;
  adminFee: number;
  gateFee: number;
  daysStored?: number;
  dailyStorageFee?: number;
  onPaymentSuccess?: () => void;
}

export function PaymentSummary({
  claimId,
  towRecordId,
  towFee,
  storageFee,
  adminFee,
  gateFee,
  daysStored,
  dailyStorageFee,
  onPaymentSuccess,
}: PaymentSummaryProps) {
  const [loading, setLoading] = useState(false);

  const subtotal = towFee + storageFee + adminFee + gateFee;
  const serviceFee = calculateServiceFee(subtotal);
  const grandTotal = calculateGrandTotal(subtotal);

  const handlePayment = async () => {
    setLoading(true);
    try {
      const result = await createTowPayment(claimId, towRecordId, subtotal);
      if (result?.url) {
        window.open(result.url, '_blank');
        onPaymentSuccess?.();
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <CreditCard className="w-5 h-5" />
            Payment Summary
          </CardTitle>
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <Info className="w-4 h-4 text-muted-foreground" />
                <span className="sr-only">Fee breakdown details</span>
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80" align="end">
              <div className="space-y-3">
                <h4 className="font-semibold text-sm">Fee Breakdown</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Tow Fee</span>
                    <span className="font-medium">${towFee.toFixed(2)}</span>
                  </div>
                  {daysStored && dailyStorageFee ? (
                    <div className="bg-muted/50 rounded-lg p-2 space-y-1">
                      <div className="flex justify-between text-muted-foreground">
                        <span>Daily Storage Rate</span>
                        <span>${dailyStorageFee.toFixed(2)}/day</span>
                      </div>
                      <div className="flex justify-between text-muted-foreground">
                        <span>Days in Storage</span>
                        <span>{daysStored} day{daysStored !== 1 ? 's' : ''}</span>
                      </div>
                      <Separator className="my-1" />
                      <div className="flex justify-between font-medium">
                        <span>Storage Total</span>
                        <span>${storageFee.toFixed(2)}</span>
                      </div>
                    </div>
                  ) : (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Storage Fee</span>
                      <span className="font-medium">${storageFee.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Admin Fee</span>
                    <span className="font-medium">${adminFee.toFixed(2)}</span>
                  </div>
                  {gateFee > 0 && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Gate Fee</span>
                      <span className="font-medium">${gateFee.toFixed(2)}</span>
                    </div>
                  )}
                  <Separator />
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span className="font-medium">${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Service Fee (5%)</span>
                    <span className="font-medium">${serviceFee.toFixed(2)}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between text-base font-semibold">
                    <span>Total Due</span>
                    <span className="text-primary">${grandTotal.toFixed(2)}</span>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  Storage fees are calculated from the date your vehicle was towed until today.
                </p>
              </div>
            </PopoverContent>
          </Popover>
        </div>
        <CardDescription>Review your charges before payment</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Tow Fee</span>
          <span>${towFee.toFixed(2)}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">
            Storage Fee {daysStored && dailyStorageFee ? `(${daysStored} day${daysStored !== 1 ? 's' : ''} × $${dailyStorageFee.toFixed(2)})` : ''}
          </span>
          <span>${storageFee.toFixed(2)}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Admin Fee</span>
          <span>${adminFee.toFixed(2)}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Gate Fee</span>
          <span>${gateFee.toFixed(2)}</span>
        </div>
        
        <Separator />
        
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Subtotal</span>
          <span>${subtotal.toFixed(2)}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Service Fee (5%)</span>
          <span>${serviceFee.toFixed(2)}</span>
        </div>
        
        <Separator />
        
        <div className="flex justify-between font-semibold text-lg">
          <span>Total Due</span>
          <span className="text-primary">${grandTotal.toFixed(2)}</span>
        </div>
      </CardContent>
      <CardFooter className="flex-col gap-3">
        <Button 
          className="w-full" 
          size="lg"
          onClick={handlePayment}
          disabled={loading}
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Processing...
            </>
          ) : (
            <>
              <CreditCard className="w-4 h-4 mr-2" />
              Pay ${grandTotal.toFixed(2)}
            </>
          )}
        </Button>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Shield className="w-3 h-3" />
          <span>Secure payment powered by Stripe</span>
        </div>
      </CardFooter>
    </Card>
  );
}
