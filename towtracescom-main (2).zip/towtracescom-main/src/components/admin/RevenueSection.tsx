import { useState, useEffect, useMemo } from 'react';
import { format, parseISO, startOfDay, startOfWeek } from 'date-fns';
import {
  DollarSign,
  TrendingUp,
  CreditCard,
  ArrowUpRight,
  ArrowDownRight,
  Loader2,
  Building2,
  Calendar,
  BarChart3,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from 'recharts';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { supabase } from '@/integrations/supabase/client';

interface PaymentRecord {
  id: string;
  amount: number;
  currency: string | null;
  status: string;
  provider: string | null;
  created_at: string;
  claim_id: string;
  tow_yard_name: string;
}

interface RevenueByYard {
  yard_name: string;
  yard_id: string;
  total: number;
  count: number;
}

type TimeRange = '7d' | '30d' | '90d' | 'all';

export function RevenueSection() {
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState<TimeRange>('30d');

  useEffect(() => {
    fetchPayments();
  }, [timeRange]);

  const fetchPayments = async () => {
    setLoading(true);

    let query = supabase
      .from('payments')
      .select(`
        id,
        amount,
        currency,
        status,
        provider,
        created_at,
        claim_id,
        tow_record_id
      `)
      .order('created_at', { ascending: false });

    if (timeRange !== 'all') {
      const days = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 90;
      const since = new Date();
      since.setDate(since.getDate() - days);
      query = query.gte('created_at', since.toISOString());
    }

    const { data: paymentsData } = await query.limit(200);

    if (!paymentsData || paymentsData.length === 0) {
      setPayments([]);
      setLoading(false);
      return;
    }

    // Get tow yard names for each payment via tow_record -> tow_yard
    const recordIds = [...new Set(paymentsData.map((p) => p.tow_record_id))];
    const { data: records } = await supabase
      .from('tow_records')
      .select('id, tow_yard_id')
      .in('id', recordIds);

    const yardIds = [...new Set((records || []).map((r) => r.tow_yard_id))];
    const { data: yards } = await supabase
      .from('tow_yards')
      .select('id, name')
      .in('id', yardIds);

    const yardMap = new Map((yards || []).map((y) => [y.id, y.name]));
    const recordYardMap = new Map((records || []).map((r) => [r.id, r.tow_yard_id]));

    const enriched: PaymentRecord[] = paymentsData.map((p) => {
      const yardId = recordYardMap.get(p.tow_record_id) || '';
      return {
        id: p.id,
        amount: p.amount,
        currency: p.currency,
        status: p.status,
        provider: p.provider,
        created_at: p.created_at,
        claim_id: p.claim_id,
        tow_yard_name: yardMap.get(yardId) || 'Unknown',
      };
    });

    setPayments(enriched);
    setLoading(false);
  };

  // Compute metrics
  const totalRevenue = payments
    .filter((p) => p.status === 'succeeded')
    .reduce((sum, p) => sum + Number(p.amount), 0);

  const totalRefunded = payments
    .filter((p) => p.status === 'refunded')
    .reduce((sum, p) => sum + Number(p.amount), 0);

  const successCount = payments.filter((p) => p.status === 'succeeded').length;
  const failedCount = payments.filter((p) => p.status === 'failed').length;
  const totalCount = payments.length;

  // Revenue by yard
  const revenueByYard: RevenueByYard[] = Object.values(
    payments
      .filter((p) => p.status === 'succeeded')
      .reduce<Record<string, RevenueByYard>>((acc, p) => {
        const key = p.tow_yard_name;
        if (!acc[key]) {
          acc[key] = { yard_name: key, yard_id: key, total: 0, count: 0 };
        }
        acc[key].total += Number(p.amount);
        acc[key].count += 1;
        return acc;
      }, {})
  ).sort((a, b) => b.total - a.total);

  // Chart data: aggregate by day or week
  const [chartGranularity, setChartGranularity] = useState<'daily' | 'weekly'>('daily');

  const trendData = useMemo(() => {
    const succeeded = payments.filter((p) => p.status === 'succeeded');
    if (succeeded.length === 0) return [];

    const buckets: Record<string, { revenue: number; count: number }> = {};

    succeeded.forEach((p) => {
      const d = new Date(p.created_at);
      const key =
        chartGranularity === 'daily'
          ? format(startOfDay(d), 'yyyy-MM-dd')
          : format(startOfWeek(d, { weekStartsOn: 1 }), 'yyyy-MM-dd');

      if (!buckets[key]) buckets[key] = { revenue: 0, count: 0 };
      buckets[key].revenue += Number(p.amount);
      buckets[key].count += 1;
    });

    return Object.entries(buckets)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([date, data]) => ({
        date,
        label: chartGranularity === 'daily' ? format(parseISO(date), 'MMM d') : `Wk ${format(parseISO(date), 'MMM d')}`,
        revenue: Math.round(data.revenue * 100) / 100,
        count: data.count,
      }));
  }, [payments, chartGranularity]);

  const statusColor: Record<string, string> = {
    succeeded: 'bg-success/10 text-success border-success/20',
    initiated: 'bg-warning/10 text-warning border-warning/20',
    failed: 'bg-destructive/10 text-destructive border-destructive/20',
    refunded: 'bg-muted text-muted-foreground border-muted',
  };

  const formatCurrency = (amount: number, currency = 'USD') =>
    new Intl.NumberFormat('en-US', { style: 'currency', currency }).format(amount);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Time range selector */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          Financial overview (read-only)
        </p>
        <Select value={timeRange} onValueChange={(v) => setTimeRange(v as TimeRange)}>
          <SelectTrigger className="w-[140px]">
            <Calendar className="w-4 h-4 mr-2" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7d">Last 7 days</SelectItem>
            <SelectItem value="30d">Last 30 days</SelectItem>
            <SelectItem value="90d">Last 90 days</SelectItem>
            <SelectItem value="all">All time</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Revenue Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-muted-foreground">Total Revenue</span>
              <DollarSign className="w-4 h-4 text-success" />
            </div>
            <p className="text-xl font-bold">{formatCurrency(totalRevenue)}</p>
            <p className="text-xs text-muted-foreground mt-1">{successCount} payments</p>
          </CardContent>
        </Card>

        <Card className="border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-muted-foreground">Refunded</span>
              <ArrowDownRight className="w-4 h-4 text-destructive" />
            </div>
            <p className="text-xl font-bold">{formatCurrency(totalRefunded)}</p>
            <p className="text-xs text-muted-foreground mt-1">
              {payments.filter((p) => p.status === 'refunded').length} refunds
            </p>
          </CardContent>
        </Card>

        <Card className="border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-muted-foreground">Net Revenue</span>
              <TrendingUp className="w-4 h-4 text-primary" />
            </div>
            <p className="text-xl font-bold">{formatCurrency(totalRevenue - totalRefunded)}</p>
            <p className="text-xs text-muted-foreground mt-1">After refunds</p>
          </CardContent>
        </Card>

        <Card className="border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-muted-foreground">Success Rate</span>
              <CreditCard className="w-4 h-4 text-accent" />
            </div>
            <p className="text-xl font-bold">
              {totalCount > 0 ? Math.round((successCount / totalCount) * 100) : 0}%
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {failedCount} failed
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Revenue Trend Chart */}
      {trendData.length > 1 && (
        <Card className="border-border/50">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-muted-foreground" />
                Revenue Trend
              </CardTitle>
              <Select value={chartGranularity} onValueChange={(v) => setChartGranularity(v as 'daily' | 'weekly')}>
                <SelectTrigger className="w-[110px] h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="h-[280px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={trendData} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border/30" />
                  <XAxis
                    dataKey="label"
                    tick={{ fontSize: 11 }}
                    className="fill-muted-foreground"
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis
                    tick={{ fontSize: 11 }}
                    className="fill-muted-foreground"
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(v) => `$${v >= 1000 ? `${(v / 1000).toFixed(1)}k` : v}`}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--background))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                      fontSize: '12px',
                    }}
                    formatter={(value: number) => [`$${value.toLocaleString()}`, 'Revenue']}
                    labelStyle={{ color: 'hsl(var(--foreground))' }}
                  />
                  <Area
                    type="monotone"
                    dataKey="revenue"
                    stroke="hsl(var(--primary))"
                    strokeWidth={2}
                    fill="url(#revenueGradient)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Revenue by Company */}
      {revenueByYard.length > 0 && (
        <Card className="border-border/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Building2 className="w-4 h-4 text-muted-foreground" />
              Revenue by Company
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-3">
              {revenueByYard.slice(0, 10).map((yard) => (
                <div key={yard.yard_name} className="flex items-center justify-between p-2 rounded-lg bg-muted/30">
                  <div>
                    <p className="text-sm font-medium">{yard.yard_name}</p>
                    <p className="text-xs text-muted-foreground">{yard.count} payments</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold">{formatCurrency(yard.total)}</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <ArrowUpRight className="w-3 h-3 text-success" />
                      {totalRevenue > 0 ? Math.round((yard.total / totalRevenue) * 100) : 0}%
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Payments Table */}
      <div>
        <h3 className="text-sm font-medium mb-3 flex items-center gap-2">
          <CreditCard className="w-4 h-4 text-muted-foreground" />
          Recent Payments
          <Badge variant="outline" className="text-xs ml-auto">
            {payments.length} shown
          </Badge>
        </h3>

        {payments.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground text-sm">
            No payments found for this time period.
          </div>
        ) : (
          <div className="rounded-lg border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/30">
                  <TableHead className="text-xs">Date</TableHead>
                  <TableHead className="text-xs">Company</TableHead>
                  <TableHead className="text-xs">Amount</TableHead>
                  <TableHead className="text-xs">Status</TableHead>
                  <TableHead className="text-xs">Provider</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {payments.slice(0, 25).map((payment) => (
                  <TableRow key={payment.id}>
                    <TableCell className="text-sm text-muted-foreground">
                      {format(new Date(payment.created_at), 'MMM d, yyyy')}
                    </TableCell>
                    <TableCell className="text-sm font-medium">
                      {payment.tow_yard_name}
                    </TableCell>
                    <TableCell className="text-sm font-mono font-medium">
                      {formatCurrency(payment.amount, payment.currency || 'USD')}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className={`text-xs ${statusColor[payment.status] || ''}`}>
                        {payment.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground capitalize">
                      {payment.provider || '—'}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
    </div>
  );
}
