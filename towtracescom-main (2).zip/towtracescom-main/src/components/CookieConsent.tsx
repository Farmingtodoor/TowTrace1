import { useState, useEffect, forwardRef } from 'react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Cookie, X, Shield, BarChart3, Megaphone, Settings2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';

type CookiePreferences = {
  necessary: boolean;
  functional: boolean;
  analytics: boolean;
  marketing: boolean;
};

const defaultPreferences: CookiePreferences = {
  necessary: true,
  functional: false,
  analytics: false,
  marketing: false,
};

export const CookieConsent = forwardRef<HTMLDivElement, Record<string, never>>((_, ref) => {
  const [isVisible, setIsVisible] = useState(false);
  const [isClosing, setIsClosing] = useState(false);
  const [showPreferences, setShowPreferences] = useState(false);
  const [preferences, setPreferences] = useState<CookiePreferences>(defaultPreferences);

  useEffect(() => {
    const consent = localStorage.getItem('cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setIsVisible(true), 1000);
      return () => clearTimeout(timer);
    } else {
      // Load saved preferences
      try {
        setPreferences(JSON.parse(consent));
      } catch {
        // If parsing fails, keep defaults
      }
    }
  }, []);

  // Listen for event to reopen preferences
  useEffect(() => {
    const handleOpenPreferences = () => {
      setIsVisible(true);
      setIsClosing(false);
      setShowPreferences(true);
    };

    window.addEventListener('open-cookie-preferences', handleOpenPreferences);
    return () => window.removeEventListener('open-cookie-preferences', handleOpenPreferences);
  }, []);

  const saveAndClose = (prefs: CookiePreferences) => {
    setIsClosing(true);
    setTimeout(() => {
      localStorage.setItem('cookie-consent', JSON.stringify(prefs));
      setIsVisible(false);
      setShowPreferences(false);
    }, 300);
  };

  const handleAcceptAll = () => {
    const allAccepted: CookiePreferences = {
      necessary: true,
      functional: true,
      analytics: true,
      marketing: true,
    };
    setPreferences(allAccepted);
    saveAndClose(allAccepted);
  };

  const handleDeclineAll = () => {
    const onlyNecessary: CookiePreferences = {
      necessary: true,
      functional: false,
      analytics: false,
      marketing: false,
    };
    setPreferences(onlyNecessary);
    saveAndClose(onlyNecessary);
  };

  const handleSavePreferences = () => {
    saveAndClose(preferences);
  };

  const togglePreference = (key: keyof CookiePreferences) => {
    if (key === 'necessary') return; // Can't disable necessary cookies
    setPreferences(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const cookieCategories = [
    {
      key: 'necessary' as const,
      title: 'Strictly Necessary',
      description: 'These cookies are essential for the website to function properly. They cannot be disabled.',
      icon: Shield,
      required: true,
    },
    {
      key: 'functional' as const,
      title: 'Functional',
      description: 'These cookies enable personalized features and remember your preferences.',
      icon: Settings2,
      required: false,
    },
    {
      key: 'analytics' as const,
      title: 'Analytics',
      description: 'These cookies help us understand how visitors interact with our website.',
      icon: BarChart3,
      required: false,
    },
    {
      key: 'marketing' as const,
      title: 'Marketing',
      description: 'These cookies are used to deliver relevant advertisements and track campaign performance.',
      icon: Megaphone,
      required: false,
    },
  ];

  if (!isVisible) return null;

  return (
    <>
      <div
        className={cn(
          "fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:max-w-md z-50 bg-card border border-border rounded-lg shadow-lg p-4 transition-all duration-300",
          isClosing ? "opacity-0 translate-y-4" : "opacity-100 translate-y-0 animate-in slide-in-from-bottom-4"
        )}
      >
        <div className="flex items-start gap-3">
          <div className="flex-shrink-0 w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
            <Cookie className="w-5 h-5 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold text-foreground text-sm">We use cookies 🍪</h3>
            <p className="text-xs text-muted-foreground mt-1">
              We use cookies to enhance your browsing experience and analyze site traffic. Customize your preferences or accept all.
            </p>
            <div className="flex flex-wrap items-center gap-2 mt-3">
              <Button 
                size="sm" 
                onClick={handleAcceptAll}
                className="text-xs h-8"
              >
                Accept All
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                onClick={() => setShowPreferences(true)}
                className="text-xs h-8"
              >
                Manage Preferences
              </Button>
              <a 
                href="/privacy" 
                className="text-xs text-muted-foreground hover:text-foreground underline underline-offset-2"
              >
                Privacy Policy
              </a>
            </div>
          </div>
          <button
            onClick={handleDeclineAll}
            className="flex-shrink-0 text-muted-foreground hover:text-foreground transition-colors"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      <Dialog open={showPreferences} onOpenChange={setShowPreferences}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Cookie className="w-5 h-5 text-primary" />
              Cookie Preferences
            </DialogTitle>
            <DialogDescription>
              Manage your cookie preferences below. You can enable or disable different types of cookies.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {cookieCategories.map((category) => {
              const Icon = category.icon;
              return (
                <div
                  key={category.key}
                  className="flex items-start gap-3 p-3 rounded-lg border border-border bg-muted/30"
                >
                  <div className="flex-shrink-0 w-9 h-9 bg-primary/10 rounded-lg flex items-center justify-center mt-0.5">
                    <Icon className="w-4 h-4 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <h4 className="font-medium text-sm text-foreground">
                        {category.title}
                        {category.required && (
                          <span className="ml-2 text-xs text-muted-foreground">(Required)</span>
                        )}
                      </h4>
                      <Switch
                        checked={preferences[category.key]}
                        onCheckedChange={() => togglePreference(category.key)}
                        disabled={category.required}
                      />
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {category.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button variant="outline" onClick={handleDeclineAll} className="w-full sm:w-auto">
              Reject All
            </Button>
            <Button variant="outline" onClick={handleAcceptAll} className="w-full sm:w-auto">
              Accept All
            </Button>
            <Button onClick={handleSavePreferences} className="w-full sm:w-auto">
              Save Preferences
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
});

CookieConsent.displayName = 'CookieConsent';
