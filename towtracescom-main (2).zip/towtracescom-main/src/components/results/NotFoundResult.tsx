import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Search, 
  Clock, 
  Phone, 
  AlertCircle,
  RefreshCw,
  ShieldAlert,
  HelpCircle,
  MapPin,
  FileQuestion,
  ArrowRight,
  Bell
} from 'lucide-react';
import { ReminderModal } from './ReminderModal';

interface NotFoundResultProps {
  searchType: 'plate' | 'vin';
  searchValue: string;
  onSearchAgain: () => void;
}

export function NotFoundResult({ searchType, searchValue, onSearchAgain }: NotFoundResultProps) {
  const [showReminderModal, setShowReminderModal] = useState(false);
  return (
    <div className="w-full max-w-2xl mx-auto space-y-6 animate-fade-in">
      {/* Header Section */}
      <div className="text-center space-y-4 py-6">
        <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-muted to-muted/50 rounded-full animate-scale-in">
          <FileQuestion className="w-10 h-10 text-muted-foreground" />
        </div>
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 text-muted-foreground">
            <HelpCircle className="w-5 h-5" />
            <span className="text-sm font-medium uppercase tracking-wider">Search Complete</span>
            <HelpCircle className="w-5 h-5" />
          </div>
          <h1 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground">
            No Record Found
          </h1>
          <p className="text-lg text-muted-foreground max-w-md mx-auto">
            We couldn't find a tow record for {searchType === 'plate' ? 'plate' : 'VIN'}{' '}
            <span className="font-mono font-semibold bg-muted px-2 py-1 rounded">{searchValue}</span>
          </p>
        </div>
        
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={onSearchAgain}
          className="text-muted-foreground hover:text-foreground"
        >
          <Search className="w-4 h-4 mr-2" />
          Try a different search
        </Button>
      </div>

      {/* Don't Worry Banner */}
      <div className="bg-info/10 border border-info/20 rounded-xl p-5 flex items-start gap-4">
        <div className="w-12 h-12 bg-info/20 rounded-full flex items-center justify-center shrink-0">
          <AlertCircle className="w-6 h-6 text-info" />
        </div>
        <div>
          <p className="font-semibold text-info">Don't worry — this could be good news!</p>
          <p className="text-sm text-muted-foreground mt-1">
            No record might mean your vehicle wasn't towed at all. Let's explore some possibilities.
          </p>
        </div>
      </div>

      {/* What This Could Mean */}
      <div className="bg-card rounded-xl shadow-card p-5 space-y-4">
        <h3 className="font-semibold text-lg flex items-center gap-2">
          <HelpCircle className="w-5 h-5 text-accent" />
          What This Could Mean
        </h3>
        
        <div className="space-y-4">
          <div className="flex items-start gap-4 p-4 bg-muted/30 rounded-lg">
            <div className="w-10 h-10 bg-warning/10 rounded-lg flex items-center justify-center shrink-0">
              <Clock className="w-5 h-5 text-warning" />
            </div>
            <div>
              <p className="font-medium">Just Towed (Under 2 Hours)</p>
              <p className="text-sm text-muted-foreground">
                New tow records may take up to 2 hours to appear in our system. Try searching again shortly.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4 p-4 bg-muted/30 rounded-lg">
            <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center shrink-0">
              <MapPin className="w-5 h-5 text-accent" />
            </div>
            <div>
              <p className="font-medium">Different Jurisdiction</p>
              <p className="text-sm text-muted-foreground">
                Your vehicle might be at a tow yard not yet in our network. Some rural areas or private lots may not be covered.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4 p-4 bg-muted/30 rounded-lg">
            <div className="w-10 h-10 bg-success/10 rounded-lg flex items-center justify-center shrink-0">
              <ShieldAlert className="w-5 h-5 text-success" />
            </div>
            <div>
              <p className="font-medium">Vehicle Not Towed</p>
              <p className="text-sm text-muted-foreground">
                Great news! Your car may still be where you left it, or moved by a neighbor/building management.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Next Steps */}
      <div className="bg-card rounded-xl shadow-card p-5 space-y-4">
        <h3 className="font-semibold text-lg flex items-center gap-2">
          <ArrowRight className="w-5 h-5 text-accent" />
          Recommended Next Steps
        </h3>
        
        <ol className="space-y-3">
          <li className="flex items-start gap-4 p-3 border border-border rounded-lg hover:bg-muted/30 transition-colors">
            <span className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-bold shrink-0">
              1
            </span>
            <div>
              <p className="font-medium">Verify Your Search</p>
              <p className="text-sm text-muted-foreground">
                Double-check your plate number or VIN for any typos. Small mistakes are common!
              </p>
            </div>
          </li>
          <li className="flex items-start gap-4 p-3 border border-border rounded-lg hover:bg-muted/30 transition-colors">
            <span className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-bold shrink-0">
              2
            </span>
            <div>
              <p className="font-medium">Contact Local Authorities</p>
              <p className="text-sm text-muted-foreground">
                Call your local police non-emergency line (311) to check if your vehicle was towed.
              </p>
            </div>
          </li>
          <li className="flex items-start gap-4 p-3 border border-border rounded-lg hover:bg-muted/30 transition-colors">
            <span className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-bold shrink-0">
              3
            </span>
            <div>
              <p className="font-medium">Check Nearby Areas</p>
              <p className="text-sm text-muted-foreground">
                Walk around the area where you parked. Your vehicle may have been moved to a nearby street.
              </p>
            </div>
          </li>
          <li className="flex items-start gap-4 p-3 border border-destructive/50 rounded-lg bg-destructive/5">
            <span className="w-8 h-8 bg-destructive text-destructive-foreground rounded-full flex items-center justify-center text-sm font-bold shrink-0">
              4
            </span>
            <div>
              <p className="font-medium text-destructive">Suspect Theft?</p>
              <p className="text-sm text-muted-foreground">
                If you believe your car was stolen, contact 911 immediately to file a report.
              </p>
            </div>
          </li>
        </ol>
      </div>

      {/* Action Buttons */}
      <div className="grid sm:grid-cols-2 gap-3">
        <Button
          variant="hero"
          size="lg"
          className="w-full"
          onClick={onSearchAgain}
        >
          <RefreshCw className="w-5 h-5" />
          Search Again
        </Button>
        
        <Button
          variant="outline"
          size="lg"
          className="w-full"
          onClick={() => setShowReminderModal(true)}
        >
          <Bell className="w-5 h-5" />
          Set Reminder
        </Button>
      </div>

      {/* Call 311 Button */}
      <Button
        variant="ghost"
        size="lg"
        className="w-full text-muted-foreground"
        asChild
      >
        <a href="tel:311">
          <Phone className="w-5 h-5" />
          Call 311 (Non-Emergency)
        </a>
      </Button>

      {/* Tips Footer */}
      <div className="text-center text-sm text-muted-foreground py-4">
        <p>
          💡 <strong>Tip:</strong> If you find your vehicle on your own, that's great news! 
          We're glad we could help narrow down the search.
        </p>
      </div>

      {/* Reminder Modal */}
      <ReminderModal
        isOpen={showReminderModal}
        onClose={() => setShowReminderModal(false)}
        searchType={searchType}
        searchValue={searchValue}
      />
    </div>
  );
}
