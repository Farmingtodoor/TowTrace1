import { Link } from 'react-router-dom';

export function Header() {
  return (
    <Link to="/" className="flex items-center gap-4 text-primary-foreground group animate-fade-in">
      <div className="relative">
        <div className="absolute inset-0 bg-accent/40 rounded-2xl blur-xl group-hover:blur-2xl transition-all duration-500 scale-110" />
        <img 
          src="/favicon.png" 
          alt="TowTrace Logo" 
          className="w-14 h-14 relative z-10 drop-shadow-2xl group-hover:scale-110 transition-transform duration-300"
        />
      </div>
      <div className="flex flex-col">
        <span className="font-display font-bold text-3xl tracking-tight bg-gradient-to-r from-white to-white/80 bg-clip-text">
          TowTrace
        </span>
        <span className="text-xs text-white/50 -mt-0.5 tracking-[0.2em] uppercase">
          Vehicle Recovery
        </span>
      </div>
    </Link>
  );
}
