import { Car } from 'lucide-react';
import { Link } from 'react-router-dom';

export function PageFooter() {
  return (
    <footer className="bg-primary text-primary-foreground py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-accent rounded-xl flex items-center justify-center">
                <Car className="w-6 h-6 text-accent-foreground" />
              </div>
              <span className="font-display font-bold text-xl">TowTrace</span>
            </div>
            <p className="text-sm text-primary-foreground/70">
              Find your towed vehicle instantly. No calls, no hassle.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="font-semibold">Quick Links</h4>
            <nav className="flex flex-col gap-2">
              <Link to="/" className="text-sm text-primary-foreground/70 hover:text-primary-foreground transition-colors">
                Find Vehicle
              </Link>
              <Link to="/my-claims" className="text-sm text-primary-foreground/70 hover:text-primary-foreground transition-colors">
                My Claims
              </Link>
              <Link to="/about" className="text-sm text-primary-foreground/70 hover:text-primary-foreground transition-colors">
                About Us
              </Link>
            </nav>
          </div>

          {/* For Operators */}
          <div className="space-y-4">
            <h4 className="font-semibold">For Tow Yards</h4>
            <nav className="flex flex-col gap-2">
              <Link to="/operator" className="text-sm text-primary-foreground/70 hover:text-primary-foreground transition-colors">
                Login to Dashboard
              </Link>
              <a href="#partner" className="text-sm text-primary-foreground/70 hover:text-primary-foreground transition-colors">
                Become a Partner
              </a>
            </nav>
          </div>

          {/* Contact */}
          <div className="space-y-4">
            <h4 className="font-semibold">Support</h4>
            <nav className="flex flex-col gap-2">
              <a href="mailto:support@towtrace.com" className="text-sm text-primary-foreground/70 hover:text-primary-foreground transition-colors">
                support@towtrace.com
              </a>
              <a href="tel:1-800-TOW-FIND" className="text-sm text-primary-foreground/70 hover:text-primary-foreground transition-colors">
                1-800-TOW-FIND
              </a>
            </nav>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-primary-foreground/60">
            <p>© 2026 TowTrace. All rights reserved.</p>
            <div className="flex items-center gap-4">
              <Link to="/terms" className="hover:text-primary-foreground transition-colors">
                Terms & Conditions
              </Link>
              <Link to="/privacy" className="hover:text-primary-foreground transition-colors">
                Privacy Policy
              </Link>
              <button 
                onClick={() => window.dispatchEvent(new CustomEvent('open-cookie-preferences'))}
                className="hover:text-primary-foreground transition-colors"
              >
                Cookie Settings
              </button>
            </div>
          </div>
          <p className="text-center text-xs text-primary-foreground/40 mt-4">
            Payment does not guarantee vehicle release. Verification required.
          </p>
        </div>
      </div>
    </footer>
  );
}
