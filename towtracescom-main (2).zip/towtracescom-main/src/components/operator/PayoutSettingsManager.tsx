import { useState, useEffect } from 'react';
import { 
  Building2, 
  CreditCard, 
  Wallet, 
  Smartphone,
  Save,
  CheckCircle,
  AlertCircle,
  Loader2,
  ExternalLink
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface PayoutSettingsManagerProps {
  towYardId: string | null;
}

interface PayoutSettings {
  id?: string;
  tow_yard_id: string;
  payout_method: string;
  bank_name: string | null;
  bank_account_number: string | null;
  bank_routing_number: string | null;
  bank_account_holder_name: string | null;
  stripe_account_id: string | null;
  stripe_connected: boolean;
  paypal_email: string | null;
  apple_pay_merchant_id: string | null;
  minimum_payout_amount: number;
  payout_frequency: string;
  is_verified: boolean;
}

// Mask sensitive data - show only last 4 digits
const maskAccountNumber = (value: string | null): string => {
  if (!value || value.length < 4) return value || '';
  return '••••' + value.slice(-4);
};

const maskRoutingNumber = (value: string | null): string => {
  if (!value || value.length < 4) return value || '';
  return '•••••' + value.slice(-4);
};

const PAYOUT_METHODS = [
  { value: 'bank_account', label: 'Bank Account', icon: Building2, description: 'Direct bank transfer (ACH)' },
  { value: 'stripe', label: 'Stripe Connect', icon: CreditCard, description: 'Automated payouts via Stripe' },
  { value: 'paypal', label: 'PayPal', icon: Wallet, description: 'Receive funds to PayPal account' },
  { value: 'apple_pay', label: 'Apple Pay', icon: Smartphone, description: 'Apple Pay merchant payouts' },
];

const PAYOUT_FREQUENCIES = [
  { value: 'daily', label: 'Daily' },
  { value: 'weekly', label: 'Weekly' },
  { value: 'biweekly', label: 'Bi-weekly' },
  { value: 'monthly', label: 'Monthly' },
];

export function PayoutSettingsManager({ towYardId }: PayoutSettingsManagerProps) {
  const [settings, setSettings] = useState<PayoutSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  // Track if user is editing sensitive fields (to show raw vs masked)
  const [editingAccountNumber, setEditingAccountNumber] = useState(false);
  const [editingRoutingNumber, setEditingRoutingNumber] = useState(false);
  // Store original values to detect if user changed them
  const [originalAccountNumber, setOriginalAccountNumber] = useState<string | null>(null);
  const [originalRoutingNumber, setOriginalRoutingNumber] = useState<string | null>(null);

  useEffect(() => {
    if (!towYardId) return;
    fetchSettings();
  }, [towYardId]);

  const fetchSettings = async () => {
    if (!towYardId) return;
    
    setLoading(true);
    const { data, error } = await supabase
      .from('payout_settings')
      .select('*')
      .eq('tow_yard_id', towYardId)
      .maybeSingle();

    if (error) {
      console.error('Error fetching payout settings:', error);
    }

    if (data) {
      setSettings(data);
      // Store original values for masking comparison
      setOriginalAccountNumber(data.bank_account_number);
      setOriginalRoutingNumber(data.bank_routing_number);
    } else {
      // Initialize with defaults
      setSettings({
        tow_yard_id: towYardId,
        payout_method: 'bank_account',
        bank_name: null,
        bank_account_number: null,
        bank_routing_number: null,
        bank_account_holder_name: null,
        stripe_account_id: null,
        stripe_connected: false,
        paypal_email: null,
        apple_pay_merchant_id: null,
        minimum_payout_amount: 50,
        payout_frequency: 'weekly',
        is_verified: false,
      });
    }
    setLoading(false);
  };

  const handleSave = async () => {
    if (!settings || !towYardId) return;

    setSaving(true);
    try {
      if (settings.id) {
        // Update existing
        const { error } = await supabase
          .from('payout_settings')
          .update({
            payout_method: settings.payout_method,
            bank_name: settings.bank_name,
            bank_account_number: settings.bank_account_number,
            bank_routing_number: settings.bank_routing_number,
            bank_account_holder_name: settings.bank_account_holder_name,
            paypal_email: settings.paypal_email,
            apple_pay_merchant_id: settings.apple_pay_merchant_id,
            minimum_payout_amount: settings.minimum_payout_amount,
            payout_frequency: settings.payout_frequency,
          })
          .eq('id', settings.id);

        if (error) throw error;
      } else {
        // Insert new
        const { data, error } = await supabase
          .from('payout_settings')
          .insert({
            tow_yard_id: towYardId,
            payout_method: settings.payout_method,
            bank_name: settings.bank_name,
            bank_account_number: settings.bank_account_number,
            bank_routing_number: settings.bank_routing_number,
            bank_account_holder_name: settings.bank_account_holder_name,
            paypal_email: settings.paypal_email,
            apple_pay_merchant_id: settings.apple_pay_merchant_id,
            minimum_payout_amount: settings.minimum_payout_amount,
            payout_frequency: settings.payout_frequency,
          })
          .select()
          .single();

        if (error) throw error;
        setSettings(data);
      }

      toast.success('Payout settings saved successfully');
    } catch (error: any) {
      console.error('Error saving payout settings:', error);
      toast.error('Failed to save payout settings');
    } finally {
      setSaving(false);
    }
  };

  const updateField = (field: keyof PayoutSettings, value: any) => {
    if (!settings) return;
    setSettings({ ...settings, [field]: value });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!towYardId || !settings) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-muted-foreground text-center">
            Select a tow yard to manage payout settings.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Wallet className="w-5 h-5" />
                Payout Settings
              </CardTitle>
              <CardDescription>
                Configure how you receive payments from vehicle releases
              </CardDescription>
            </div>
            {settings.is_verified ? (
              <Badge variant="default" className="bg-green-500">
                <CheckCircle className="w-3 h-3 mr-1" />
                Verified
              </Badge>
            ) : (
              <Badge variant="secondary">
                <AlertCircle className="w-3 h-3 mr-1" />
                Pending Verification
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Payout Method Selection */}
          <div className="space-y-3">
            <Label>Payout Method</Label>
            <RadioGroup
              value={settings.payout_method}
              onValueChange={(value) => updateField('payout_method', value)}
              className="grid grid-cols-1 md:grid-cols-2 gap-4"
            >
              {PAYOUT_METHODS.map((method) => {
                const Icon = method.icon;
                return (
                  <div key={method.value}>
                    <RadioGroupItem
                      value={method.value}
                      id={method.value}
                      className="peer sr-only"
                    />
                    <Label
                      htmlFor={method.value}
                      className="flex items-center gap-3 p-4 border-2 rounded-lg cursor-pointer transition-all peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5 hover:border-muted-foreground/50"
                    >
                      <Icon className="w-5 h-5 text-primary" />
                      <div>
                        <p className="font-medium">{method.label}</p>
                        <p className="text-xs text-muted-foreground">{method.description}</p>
                      </div>
                    </Label>
                  </div>
                );
              })}
            </RadioGroup>
          </div>

          {/* Bank Account Fields */}
          {settings.payout_method === 'bank_account' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-muted/50 rounded-lg">
              <div className="space-y-2">
                <Label htmlFor="bank_name">Bank Name</Label>
                <Input
                  id="bank_name"
                  placeholder="Chase, Bank of America, etc."
                  value={settings.bank_name || ''}
                  onChange={(e) => updateField('bank_name', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="account_holder">Account Holder Name</Label>
                <Input
                  id="account_holder"
                  placeholder="Business or personal name"
                  value={settings.bank_account_holder_name || ''}
                  onChange={(e) => updateField('bank_account_holder_name', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="routing_number">Routing Number</Label>
                <Input
                  id="routing_number"
                  placeholder="9 digits"
                  value={editingRoutingNumber 
                    ? (settings.bank_routing_number || '') 
                    : (originalRoutingNumber ? maskRoutingNumber(originalRoutingNumber) : (settings.bank_routing_number || ''))
                  }
                  onChange={(e) => {
                    setEditingRoutingNumber(true);
                    updateField('bank_routing_number', e.target.value);
                  }}
                  onFocus={() => {
                    if (originalRoutingNumber && !editingRoutingNumber) {
                      // Clear to let user enter new value
                      updateField('bank_routing_number', '');
                      setEditingRoutingNumber(true);
                    }
                  }}
                  maxLength={9}
                />
                {originalRoutingNumber && !editingRoutingNumber && (
                  <p className="text-xs text-muted-foreground">Click to update routing number</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="account_number">Account Number</Label>
                <Input
                  id="account_number"
                  placeholder="••••••••"
                  value={editingAccountNumber 
                    ? (settings.bank_account_number || '') 
                    : (originalAccountNumber ? maskAccountNumber(originalAccountNumber) : (settings.bank_account_number || ''))
                  }
                  onChange={(e) => {
                    setEditingAccountNumber(true);
                    updateField('bank_account_number', e.target.value);
                  }}
                  onFocus={() => {
                    if (originalAccountNumber && !editingAccountNumber) {
                      // Clear to let user enter new value
                      updateField('bank_account_number', '');
                      setEditingAccountNumber(true);
                    }
                  }}
                />
                {originalAccountNumber && !editingAccountNumber && (
                  <p className="text-xs text-muted-foreground">Click to update account number</p>
                )}
              </div>
            </div>
          )}

          {/* Stripe Connect */}
          {settings.payout_method === 'stripe' && (
            <div className="p-4 bg-muted/50 rounded-lg space-y-4">
              {settings.stripe_connected ? (
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <div>
                    <p className="font-medium">Stripe Connected</p>
                    <p className="text-sm text-muted-foreground">Account ID: {settings.stripe_account_id}</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    Connect your Stripe account to receive automated payouts for vehicle releases.
                  </p>
                  <Button variant="outline">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Connect Stripe Account
                  </Button>
                </div>
              )}
            </div>
          )}

          {/* PayPal */}
          {settings.payout_method === 'paypal' && (
            <div className="p-4 bg-muted/50 rounded-lg">
              <div className="space-y-2">
                <Label htmlFor="paypal_email">PayPal Email</Label>
                <Input
                  id="paypal_email"
                  type="email"
                  placeholder="your@email.com"
                  value={settings.paypal_email || ''}
                  onChange={(e) => updateField('paypal_email', e.target.value)}
                />
              </div>
            </div>
          )}

          {/* Apple Pay */}
          {settings.payout_method === 'apple_pay' && (
            <div className="p-4 bg-muted/50 rounded-lg">
              <div className="space-y-2">
                <Label htmlFor="apple_merchant">Apple Pay Merchant ID</Label>
                <Input
                  id="apple_merchant"
                  placeholder="merchant.com.yourcompany"
                  value={settings.apple_pay_merchant_id || ''}
                  onChange={(e) => updateField('apple_pay_merchant_id', e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                  You can get this from your Apple Developer account.
                </p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Payout Preferences */}
      <Card>
        <CardHeader>
          <CardTitle>Payout Preferences</CardTitle>
          <CardDescription>
            Configure when and how much you want to receive
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="frequency">Payout Frequency</Label>
              <Select
                value={settings.payout_frequency}
                onValueChange={(value) => updateField('payout_frequency', value)}
              >
                <SelectTrigger id="frequency">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PAYOUT_FREQUENCIES.map((freq) => (
                    <SelectItem key={freq.value} value={freq.value}>
                      {freq.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="minimum">Minimum Payout Amount ($)</Label>
              <Input
                id="minimum"
                type="number"
                min={1}
                value={settings.minimum_payout_amount}
                onChange={(e) => updateField('minimum_payout_amount', parseFloat(e.target.value) || 50)}
              />
              <p className="text-xs text-muted-foreground">
                Payouts will only be triggered when balance exceeds this amount.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={saving}>
          {saving ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="w-4 h-4 mr-2" />
              Save Payout Settings
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
