import { useState, useEffect } from 'react';
import { Car, FileText, TrendingUp, DollarSign } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { cn } from '@/lib/utils';

interface RealTimeMetricsProps {
  towYardId: string | null;
}

interface Metrics {
  activeTows: number;
  pendingClaims: number;
  dailyRevenue: number;
  releasedToday: number;
}

export function RealTimeMetrics({ towYardId }: RealTimeMetricsProps) {
  const [metrics, setMetrics] = useState<Metrics>({
    activeTows: 0,
    pendingClaims: 0,
    dailyRevenue: 0,
    releasedToday: 0,
  });
  const [loading, setLoading] = useState(true);
  const [updatedField, setUpdatedField] = useState<string | null>(null);

  const fetchMetrics = async () => {
    if (!towYardId) return;

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const [towsRes, claimsRes, paymentsRes, releasedRes] = await Promise.all([
      // Active tows (not released)
      supabase
        .from('tow_records')
        .select('id', { count: 'exact', head: true })
        .eq('tow_yard_id', towYardId)
        .neq('status', 'released'),
      // Pending claims
      supabase
        .from('claims')
        .select('id, tow_record_id', { count: 'exact' })
        .in('claim_status', ['started', 'docs_submitted', 'payment_pending']),
      // Today's completed payments
      supabase
        .from('payments')
        .select('amount, tow_record_id')
        .eq('status', 'succeeded')
        .gte('created_at', today.toISOString()),
      // Released today
      supabase
        .from('tow_records')
        .select('id', { count: 'exact', head: true })
        .eq('tow_yard_id', towYardId)
        .eq('status', 'released')
        .gte('updated_at', today.toISOString()),
    ]);

    // Filter claims by tow yard - need to get tow_record_ids for this yard
    const { data: yardRecords } = await supabase
      .from('tow_records')
      .select('id')
      .eq('tow_yard_id', towYardId);

    const yardRecordIds = new Set(yardRecords?.map(r => r.id) || []);
    
    // Filter payments and claims for this yard
    const yardPayments = paymentsRes.data?.filter(p => yardRecordIds.has(p.tow_record_id)) || [];
    const dailyRevenue = yardPayments.reduce((sum, p) => sum + Number(p.amount || 0), 0);

    // Count pending claims for this yard
    const yardClaimsCount = claimsRes.data?.filter(c => yardRecordIds.has(c.tow_record_id)).length || 0;

    setMetrics({
      activeTows: towsRes.count || 0,
      pendingClaims: yardClaimsCount,
      dailyRevenue,
      releasedToday: releasedRes.count || 0,
    });
    setLoading(false);
  };

  useEffect(() => {
    fetchMetrics();
  }, [towYardId]);

  // Set up real-time subscriptions
  useEffect(() => {
    if (!towYardId) return;

    const channel = supabase
      .channel('realtime-metrics')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'tow_records',
          filter: `tow_yard_id=eq.${towYardId}`,
        },
        () => {
          setUpdatedField('tows');
          fetchMetrics();
          setTimeout(() => setUpdatedField(null), 1000);
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'claims',
        },
        () => {
          setUpdatedField('claims');
          fetchMetrics();
          setTimeout(() => setUpdatedField(null), 1000);
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'payments',
        },
        () => {
          setUpdatedField('revenue');
          fetchMetrics();
          setTimeout(() => setUpdatedField(null), 1000);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [towYardId]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const metricsData = [
    {
      key: 'tows',
      label: 'Active Tows',
      value: metrics.activeTows,
      icon: Car,
      colorClass: 'bg-primary/10 text-primary',
      pulseClass: 'ring-primary/50',
    },
    {
      key: 'claims',
      label: 'Pending Claims',
      value: metrics.pendingClaims,
      icon: FileText,
      colorClass: 'bg-warning/10 text-warning',
      pulseClass: 'ring-warning/50',
    },
    {
      key: 'revenue',
      label: 'Daily Revenue',
      value: formatCurrency(metrics.dailyRevenue),
      icon: DollarSign,
      colorClass: 'bg-success/10 text-success',
      pulseClass: 'ring-success/50',
    },
    {
      key: 'released',
      label: 'Released Today',
      value: metrics.releasedToday,
      icon: TrendingUp,
      colorClass: 'bg-accent/10 text-accent-foreground',
      pulseClass: 'ring-accent/50',
    },
  ];

  if (loading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="bg-card rounded-xl p-5 shadow-card animate-pulse">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-muted rounded-lg" />
              <div className="space-y-2">
                <div className="h-6 w-16 bg-muted rounded" />
                <div className="h-4 w-24 bg-muted rounded" />
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {metricsData.map((metric) => {
        const Icon = metric.icon;
        const isUpdated = updatedField === metric.key || 
          (updatedField === 'tows' && metric.key === 'released');

        return (
          <div
            key={metric.key}
            className={cn(
              "bg-card rounded-xl p-5 shadow-card transition-all duration-300",
              isUpdated && "ring-2 ring-offset-2 ring-offset-background",
              isUpdated && metric.pulseClass
            )}
          >
            <div className="flex items-center gap-4">
              <div className={cn("w-12 h-12 rounded-lg flex items-center justify-center", metric.colorClass)}>
                <Icon className="w-6 h-6" />
              </div>
              <div>
                <p className={cn(
                  "text-2xl font-bold transition-transform duration-300",
                  isUpdated && "scale-110"
                )}>
                  {metric.value}
                </p>
                <p className="text-sm text-muted-foreground">{metric.label}</p>
              </div>
            </div>
            {/* Live indicator */}
            <div className="flex items-center gap-1.5 mt-3">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-success opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-success"></span>
              </span>
              <span className="text-xs text-muted-foreground">Live</span>
            </div>
          </div>
        );
      })}
    </div>
  );
}
