import { useState, useCallback, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { logRecordCreated } from '@/lib/activityLog';
import { Loader2, User } from 'lucide-react';
import { FeeCalculator } from './FeeCalculator';
import { VINDecoderInput } from './VINDecoderInput';
import { VehiclePhotoUpload } from './VehiclePhotoUpload';
import { type VehicleType, type FeeConfiguration } from '@/lib/feeCalculator';
import { US_STATES, CA_PROVINCES } from '@/data/regions';
import { useAuth } from '@/hooks/useAuth';

const formSchema = z.object({
  plate_number: z.string().min(1, 'Plate number is required'),
  vin: z.string().optional(),
  make: z.string().min(1, 'Make is required'),
  model: z.string().min(1, 'Model is required'),
  color: z.string().optional(),
  tow_reason: z.string().optional(),
  tow_from_address: z.string().optional(),
  tow_fee: z.number().min(0),
  daily_storage_fee: z.number().min(0),
  admin_fee: z.number().min(0),
  gate_fee: z.number().min(0),
  country: z.enum(['US', 'CA']),
  plate_state_province: z.string().optional(),
  vehicle_type: z.string().default('standard'),
});

type FormData = z.infer<typeof formSchema>;

interface AddRecordDialogProps {
  isOpen: boolean;
  onClose: () => void;
  towYardId: string;
  onSuccess: () => void;
}

export function AddRecordDialog({
  isOpen,
  onClose,
  towYardId,
  onSuccess,
}: AddRecordDialogProps) {
  const { user } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [vehicleType, setVehicleType] = useState<VehicleType>('standard');
  const [feeConfigs, setFeeConfigs] = useState<Record<string, FeeConfiguration>>({});
  const [operatorName, setOperatorName] = useState<string>('');
  const [vehiclePhotos, setVehiclePhotos] = useState<string[]>([]);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      tow_fee: 150,
      daily_storage_fee: 45,
      admin_fee: 50,
      gate_fee: 0,
      country: 'US',
      vehicle_type: 'standard',
    },
  });

  // Fetch operator's name from profile
  useEffect(() => {
    if (!user) return;
    
    const fetchOperatorName = async () => {
      const { data: profile } = await supabase
        .from('profiles')
        .select('full_name, first_name, last_name')
        .eq('user_id', user.id)
        .maybeSingle();
      
      if (profile) {
        const name = profile.full_name || 
          [profile.first_name, profile.last_name].filter(Boolean).join(' ') || 
          user.email || 
          'Unknown';
        setOperatorName(name);
      }
    };
    
    fetchOperatorName();
  }, [user]);

  const country = watch('country');

  // Fetch saved fee configurations for this tow yard
  useEffect(() => {
    if (!isOpen || !towYardId) return;

    const fetchFeeConfigs = async () => {
      const { data, error } = await supabase
        .from('fee_configurations')
        .select('vehicle_type, tow_fee, daily_storage_fee, admin_fee, gate_fee')
        .eq('tow_yard_id', towYardId);

      if (!error && data) {
        const configMap: Record<string, FeeConfiguration> = {};
        data.forEach((config) => {
          configMap[config.vehicle_type] = {
            tow_fee: Number(config.tow_fee),
            daily_storage_fee: Number(config.daily_storage_fee),
            admin_fee: Number(config.admin_fee),
            gate_fee: Number(config.gate_fee),
          };
        });
        setFeeConfigs(configMap);
      }
    };

    fetchFeeConfigs();
  }, [isOpen, towYardId]);

  // Get custom config for current vehicle type
  const customConfig = feeConfigs[vehicleType] || null;

  const handleFeesCalculated = useCallback((fees: {
    towFee: number;
    dailyStorageFee: number;
    adminFee: number;
    gateFee: number;
  }) => {
    setValue('tow_fee', fees.towFee);
    setValue('daily_storage_fee', fees.dailyStorageFee);
    setValue('admin_fee', fees.adminFee);
    setValue('gate_fee', fees.gateFee);
  }, [setValue]);

  const handleVehicleTypeChange = (type: VehicleType) => {
    setVehicleType(type);
    setValue('vehicle_type', type);
  };

  const handleVINDecode = (data: {
    make: string | null;
    model: string | null;
    year: string | null;
    vehicleType: VehicleType;
  }) => {
    if (data.make) setValue('make', data.make);
    if (data.model) setValue('model', data.model);
    handleVehicleTypeChange(data.vehicleType);
  };

  const onSubmit = async (data: FormData) => {
    setIsSubmitting(true);
    setError(null);

    const now = new Date().toISOString();
    const { data: insertedData, error: insertError } = await supabase.from('tow_records').insert({
      tow_yard_id: towYardId,
      plate_number: data.plate_number?.toUpperCase().replace(/[\s-]/g, '') || null,
      vin: data.vin?.toUpperCase() || null,
      make: data.make,
      model: data.model,
      color: data.color || null,
      tow_reason: data.tow_reason || null,
      tow_from_address: data.tow_from_address || null,
      tow_fee: data.tow_fee,
      daily_storage_fee: data.daily_storage_fee,
      admin_fee: data.admin_fee,
      gate_fee: data.gate_fee,
      country: data.country,
      plate_state_province: data.plate_state_province?.toUpperCase() || null,
      currency: data.country === 'US' ? 'USD' : 'CAD',
      status: 'towed',
      vehicle_type: data.vehicle_type,
      tow_datetime: now,
      storage_start_datetime: now,
      driver_user_id: user?.id || null,
      driver_name: operatorName || null,
      vehicle_photos: vehiclePhotos.length > 0 ? vehiclePhotos : null,
    }).select('id').single();

    setIsSubmitting(false);

    if (insertError) {
      console.error('Error adding record:', insertError);
      setError('Failed to add record. Please try again.');
    } else if (insertedData) {
      // Log the activity
      await logRecordCreated(insertedData.id, {
        plate_number: data.plate_number,
        make: data.make,
        model: data.model,
        vin: data.vin,
        driver_name: operatorName,
        photo_count: vehiclePhotos.length,
      });
      reset();
      setVehiclePhotos([]);
      onSuccess();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add Tow Record</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          {/* Operator Info Display */}
          <div className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg text-sm">
            <User className="w-4 h-4 text-muted-foreground" />
            <span className="text-muted-foreground">Recording as:</span>
            <span className="font-medium">{operatorName || 'Loading...'}</span>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="plate_number">Plate Number *</Label>
              <Input
                id="plate_number"
                {...register('plate_number')}
                placeholder="ABC1234"
              />
              {errors.plate_number && (
                <p className="text-xs text-destructive">{errors.plate_number.message}</p>
              )}
            </div>
            <VINDecoderInput
              value={watch('vin') || ''}
              onChange={(vin) => setValue('vin', vin)}
              onDecode={handleVINDecode}
              optional
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="make">Make *</Label>
              <Input
                id="make"
                {...register('make')}
                placeholder="Honda"
              />
              {errors.make && (
                <p className="text-xs text-destructive">{errors.make.message}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="model">Model *</Label>
              <Input
                id="model"
                {...register('model')}
                placeholder="Civic"
              />
              {errors.model && (
                <p className="text-xs text-destructive">{errors.model.message}</p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="color">Color</Label>
              <Input
                id="color"
                {...register('color')}
                placeholder="Silver"
              />
            </div>
            <div className="space-y-2">
              <Label>Country</Label>
              <Select
                value={country}
                onValueChange={(value) => setValue('country', value as 'US' | 'CA')}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="US">United States</SelectItem>
                  <SelectItem value="CA">Canada</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>
              {country === 'US' ? 'State' : 'Province'}
            </Label>
            <Select
              value={watch('plate_state_province') || ''}
              onValueChange={(value) => setValue('plate_state_province', value)}
            >
              <SelectTrigger>
                <SelectValue placeholder={`Select ${country === 'US' ? 'state' : 'province'}`} />
              </SelectTrigger>
              <SelectContent>
                {(country === 'US' ? US_STATES : CA_PROVINCES).map((r) => (
                  <SelectItem key={r.code} value={r.code}>
                    {r.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="tow_reason">Tow Reason</Label>
            <Input
              id="tow_reason"
              {...register('tow_reason')}
              placeholder="Illegally parked"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="tow_from_address">Towed From</Label>
            <Input
              id="tow_from_address"
              {...register('tow_from_address')}
              placeholder="123 Main St"
            />
          </div>

          <VehiclePhotoUpload
            photos={vehiclePhotos}
            onPhotosChange={setVehiclePhotos}
            towYardId={towYardId}
          />

          <div className="border-t border-border pt-4">
            <FeeCalculator
              vehicleType={vehicleType}
              onVehicleTypeChange={handleVehicleTypeChange}
              onFeesCalculated={handleFeesCalculated}
              customConfig={customConfig}
              showPreview={true}
            />

            <div className="mt-4">
              <h4 className="font-medium mb-3 text-sm text-muted-foreground">Manual Override</h4>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="tow_fee">Tow Fee</Label>
                  <Input
                    id="tow_fee"
                    type="number"
                    step="0.01"
                    {...register('tow_fee', { valueAsNumber: true })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="daily_storage_fee">Daily Storage</Label>
                  <Input
                    id="daily_storage_fee"
                    type="number"
                    step="0.01"
                    {...register('daily_storage_fee', { valueAsNumber: true })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="admin_fee">Admin Fee</Label>
                  <Input
                    id="admin_fee"
                    type="number"
                    step="0.01"
                    {...register('admin_fee', { valueAsNumber: true })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="gate_fee">Gate Fee</Label>
                  <Input
                    id="gate_fee"
                    type="number"
                    step="0.01"
                    {...register('gate_fee', { valueAsNumber: true })}
                  />
                </div>
              </div>
            </div>
          </div>

          {error && (
            <p className="text-sm text-destructive">{error}</p>
          )}

          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting} className="flex-1">
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Adding...
                </>
              ) : (
                'Add Record'
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
