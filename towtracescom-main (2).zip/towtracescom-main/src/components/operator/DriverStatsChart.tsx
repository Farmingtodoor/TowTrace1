import { useState, useEffect } from 'react';
import { User, TrendingUp } from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from 'recharts';
import { supabase } from '@/integrations/supabase/client';

interface DriverStatsChartProps {
  towYardId: string | null;
  timeRange: '7d' | '30d' | '90d';
}

interface DriverStat {
  name: string;
  userId: string;
  count: number;
}

const COLORS = [
  'hsl(var(--accent))',
  'hsl(var(--primary))',
  'hsl(var(--info))',
  'hsl(var(--success))',
  'hsl(var(--warning))',
];

export function DriverStatsChart({ towYardId, timeRange }: DriverStatsChartProps) {
  const [driverStats, setDriverStats] = useState<DriverStat[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalTows, setTotalTows] = useState(0);

  useEffect(() => {
    if (!towYardId) return;

    const fetchDriverStats = async () => {
      setLoading(true);

      const daysAgo = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 90;
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - daysAgo);

      // Fetch tow records with driver info
      const { data: records, error } = await supabase
        .from('tow_records')
        .select('driver_user_id, driver_name')
        .eq('tow_yard_id', towYardId)
        .gte('tow_datetime', startDate.toISOString());

      if (error) {
        console.error('Error fetching driver stats:', error);
        setLoading(false);
        return;
      }

      // Aggregate by driver
      const driverCounts: Record<string, { name: string; count: number }> = {};
      let unassignedCount = 0;

      records?.forEach((record) => {
        if (record.driver_user_id) {
          const key = record.driver_user_id;
          if (!driverCounts[key]) {
            driverCounts[key] = {
              name: record.driver_name || 'Unknown Driver',
              count: 0,
            };
          }
          driverCounts[key].count++;
        } else {
          unassignedCount++;
        }
      });

      const stats: DriverStat[] = Object.entries(driverCounts)
        .map(([userId, data]) => ({
          userId,
          name: data.name,
          count: data.count,
        }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10); // Top 10 drivers

      if (unassignedCount > 0) {
        stats.push({
          userId: 'unassigned',
          name: 'Unassigned',
          count: unassignedCount,
        });
      }

      setDriverStats(stats);
      setTotalTows(records?.length || 0);
      setLoading(false);
    };

    fetchDriverStats();
  }, [towYardId, timeRange]);

  if (loading) {
    return (
      <div className="bg-card rounded-xl p-6 shadow-card animate-pulse">
        <div className="h-64 bg-muted rounded" />
      </div>
    );
  }

  if (driverStats.length === 0) {
    return (
      <div className="bg-card rounded-xl p-6 shadow-card">
        <h3 className="font-display text-lg font-semibold mb-4 flex items-center gap-2">
          <User className="w-5 h-5" />
          Tows by Driver
        </h3>
        <div className="h-64 flex items-center justify-center text-muted-foreground">
          No driver data available for this period
        </div>
      </div>
    );
  }

  const topDriver = driverStats[0];

  return (
    <div className="bg-card rounded-xl p-6 shadow-card">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-display text-lg font-semibold flex items-center gap-2">
          <User className="w-5 h-5" />
          Tows by Driver
        </h3>
        <div className="text-right">
          <p className="text-sm text-muted-foreground">Total Tows</p>
          <p className="text-xl font-bold">{totalTows}</p>
        </div>
      </div>

      {/* Top Driver Highlight */}
      {topDriver && topDriver.userId !== 'unassigned' && (
        <div className="bg-accent/10 rounded-lg p-4 mb-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-accent/20 rounded-full flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-accent" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Top Driver</p>
              <p className="font-semibold">{topDriver.name}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-accent">{topDriver.count}</p>
            <p className="text-xs text-muted-foreground">
              {((topDriver.count / totalTows) * 100).toFixed(0)}% of total
            </p>
          </div>
        </div>
      )}

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={driverStats} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" horizontal={false} />
            <XAxis 
              type="number"
              className="text-xs fill-muted-foreground"
              tick={{ fontSize: 12 }}
            />
            <YAxis 
              type="category"
              dataKey="name"
              className="text-xs fill-muted-foreground"
              tick={{ fontSize: 11 }}
              width={100}
              tickFormatter={(value) => 
                value.length > 12 ? value.slice(0, 12) + '...' : value
              }
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: 'hsl(var(--card))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '8px',
              }}
              formatter={(value: number, name: string, props: any) => [
                `${value} tows (${((value / totalTows) * 100).toFixed(1)}%)`,
                props.payload.name
              ]}
              labelFormatter={() => ''}
            />
            <Bar 
              dataKey="count" 
              radius={[0, 4, 4, 0]}
            >
              {driverStats.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={entry.userId === 'unassigned' 
                    ? 'hsl(var(--muted-foreground))' 
                    : COLORS[index % COLORS.length]
                  } 
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Driver List */}
      <div className="mt-4 space-y-2">
        {driverStats.slice(0, 5).map((driver, index) => (
          <div key={driver.userId} className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <div 
                className="w-3 h-3 rounded-full" 
                style={{ 
                  backgroundColor: driver.userId === 'unassigned' 
                    ? 'hsl(var(--muted-foreground))' 
                    : COLORS[index % COLORS.length] 
                }}
              />
              <span className={driver.userId === 'unassigned' ? 'text-muted-foreground' : ''}>
                {driver.name}
              </span>
            </div>
            <span className="font-medium">{driver.count} tows</span>
          </div>
        ))}
      </div>
    </div>
  );
}
