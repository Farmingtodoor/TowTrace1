import { useEffect, useState } from 'react';
import { Calculator, Car, TrendingUp } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import {
  calculateFees,
  getVehicleTypeOptions,
  type VehicleType,
  type FeeBreakdown,
  type FeeConfiguration,
} from '@/lib/feeCalculator';
import { cn } from '@/lib/utils';

interface FeeCalculatorProps {
  vehicleType: VehicleType;
  onVehicleTypeChange: (type: VehicleType) => void;
  onFeesCalculated: (fees: {
    towFee: number;
    dailyStorageFee: number;
    adminFee: number;
    gateFee: number;
  }) => void;
  storageStartDate?: Date;
  customConfig?: FeeConfiguration | null;
  showPreview?: boolean;
}

export function FeeCalculator({
  vehicleType,
  onVehicleTypeChange,
  onFeesCalculated,
  storageStartDate = new Date(),
  customConfig,
  showPreview = true,
}: FeeCalculatorProps) {
  const [fees, setFees] = useState<FeeBreakdown | null>(null);

  useEffect(() => {
    const calculated = calculateFees(vehicleType, storageStartDate, customConfig);
    setFees(calculated);
    onFeesCalculated({
      towFee: calculated.towFee,
      dailyStorageFee: calculated.dailyStorageFee,
      adminFee: calculated.adminFee,
      gateFee: calculated.gateFee,
    });
  }, [vehicleType, storageStartDate, customConfig, onFeesCalculated]);

  const vehicleOptions = getVehicleTypeOptions();

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Calculator className="w-5 h-5 text-primary" />
        <span className="font-medium">Auto Fee Calculator</span>
      </div>

      <div className="space-y-2">
        <Label htmlFor="vehicle-type" className="flex items-center gap-2">
          <Car className="w-4 h-4" />
          Vehicle Type
        </Label>
        <Select
          value={vehicleType}
          onValueChange={(value) => onVehicleTypeChange(value as VehicleType)}
        >
          <SelectTrigger id="vehicle-type">
            <SelectValue placeholder="Select vehicle type" />
          </SelectTrigger>
          <SelectContent>
            {vehicleOptions.map((option) => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {showPreview && fees && (
        <div className="bg-muted/50 rounded-lg p-4 space-y-3">
          <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
            <TrendingUp className="w-4 h-4" />
            Calculated Fees Preview
          </div>

          <div className="grid grid-cols-2 gap-2 text-sm">
            <FeeRow label="Tow Fee" value={fees.towFee} />
            <FeeRow label="Daily Storage" value={fees.dailyStorageFee} suffix="/day" />
            <FeeRow label="Admin Fee" value={fees.adminFee} />
            <FeeRow label="Gate Fee" value={fees.gateFee} />
          </div>

          <div className="pt-2 border-t border-border">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">
                Est. Total ({fees.daysStored} day{fees.daysStored !== 1 ? 's' : ''})
              </span>
              <span className="font-semibold text-primary">
                ${fees.totalDue.toFixed(2)}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function FeeRow({
  label,
  value,
  suffix = '',
}: {
  label: string;
  value: number;
  suffix?: string;
}) {
  return (
    <>
      <span className="text-muted-foreground">{label}</span>
      <span className={cn('text-right font-medium', value === 0 && 'text-muted-foreground')}>
        ${value.toFixed(2)}{suffix}
      </span>
    </>
  );
}
