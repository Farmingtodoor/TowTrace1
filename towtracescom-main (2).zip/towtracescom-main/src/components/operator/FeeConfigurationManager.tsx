import { useState, useEffect } from 'react';
import { Settings, Save, Loader2, Car, DollarSign, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { VEHICLE_TYPES, type VehicleType } from '@/lib/feeCalculator';

interface FeeConfig {
  id?: string;
  vehicle_type: string;
  tow_fee: number;
  daily_storage_fee: number;
  admin_fee: number;
  gate_fee: number;
}

interface FeeConfigurationManagerProps {
  towYardId: string | null;
}

const DEFAULT_FEES: Record<VehicleType, Omit<FeeConfig, 'id' | 'vehicle_type'>> = {
  motorcycle: { tow_fee: 105, daily_storage_fee: 31.5, admin_fee: 35, gate_fee: 0 },
  standard: { tow_fee: 150, daily_storage_fee: 45, admin_fee: 50, gate_fee: 0 },
  suv: { tow_fee: 180, daily_storage_fee: 54, admin_fee: 60, gate_fee: 0 },
  truck: { tow_fee: 195, daily_storage_fee: 58.5, admin_fee: 65, gate_fee: 0 },
  van: { tow_fee: 187.5, daily_storage_fee: 56.25, admin_fee: 62.5, gate_fee: 0 },
  commercial: { tow_fee: 225, daily_storage_fee: 67.5, admin_fee: 75, gate_fee: 0 },
  heavy_duty: { tow_fee: 300, daily_storage_fee: 90, admin_fee: 100, gate_fee: 0 },
};

export function FeeConfigurationManager({ towYardId }: FeeConfigurationManagerProps) {
  const [configs, setConfigs] = useState<Record<string, FeeConfig>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);

  useEffect(() => {
    if (!towYardId) return;
    fetchConfigs();
  }, [towYardId]);

  const fetchConfigs = async () => {
    if (!towYardId) return;
    setLoading(true);

    const { data, error } = await supabase
      .from('fee_configurations')
      .select('*')
      .eq('tow_yard_id', towYardId);

    if (error) {
      console.error('Error fetching fee configs:', error);
      toast.error('Failed to load fee configurations');
    } else {
      const configMap: Record<string, FeeConfig> = {};
      
      // Initialize with defaults for all vehicle types
      Object.keys(VEHICLE_TYPES).forEach((type) => {
        const vehicleType = type as VehicleType;
        configMap[vehicleType] = {
          vehicle_type: vehicleType,
          ...DEFAULT_FEES[vehicleType],
        };
      });

      // Override with saved configs
      data?.forEach((config) => {
        configMap[config.vehicle_type] = {
          id: config.id,
          vehicle_type: config.vehicle_type,
          tow_fee: Number(config.tow_fee),
          daily_storage_fee: Number(config.daily_storage_fee),
          admin_fee: Number(config.admin_fee),
          gate_fee: Number(config.gate_fee),
        };
      });

      setConfigs(configMap);
    }
    setLoading(false);
  };

  const updateConfig = (vehicleType: string, field: keyof FeeConfig, value: number) => {
    setConfigs((prev) => ({
      ...prev,
      [vehicleType]: {
        ...prev[vehicleType],
        [field]: value,
      },
    }));
    setHasChanges(true);
  };

  const resetToDefaults = (vehicleType: VehicleType) => {
    setConfigs((prev) => ({
      ...prev,
      [vehicleType]: {
        ...prev[vehicleType],
        ...DEFAULT_FEES[vehicleType],
      },
    }));
    setHasChanges(true);
  };

  const saveConfigs = async () => {
    if (!towYardId) return;
    setSaving(true);

    try {
      const upsertData = Object.values(configs).map((config) => ({
        id: config.id,
        tow_yard_id: towYardId,
        vehicle_type: config.vehicle_type,
        tow_fee: config.tow_fee,
        daily_storage_fee: config.daily_storage_fee,
        admin_fee: config.admin_fee,
        gate_fee: config.gate_fee,
      }));

      // Delete existing and insert new (simpler than upsert with composite key)
      await supabase
        .from('fee_configurations')
        .delete()
        .eq('tow_yard_id', towYardId);

      const { error } = await supabase
        .from('fee_configurations')
        .insert(upsertData.map(({ id, ...rest }) => rest));

      if (error) throw error;

      toast.success('Fee configurations saved successfully');
      setHasChanges(false);
      fetchConfigs(); // Refresh to get new IDs
    } catch (error) {
      console.error('Error saving configs:', error);
      toast.error('Failed to save fee configurations');
    } finally {
      setSaving(false);
    }
  };

  if (!towYardId) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        Select a tow yard to manage fee configurations
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
            <Settings className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h2 className="text-xl font-semibold">Fee Configuration</h2>
            <p className="text-muted-foreground text-sm">
              Set base fees for each vehicle type
            </p>
          </div>
        </div>
        <Button onClick={saveConfigs} disabled={saving || !hasChanges}>
          {saving ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="w-4 h-4 mr-2" />
              Save Changes
            </>
          )}
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {Object.entries(VEHICLE_TYPES).map(([type, { label, multiplier }]) => {
          const config = configs[type];
          if (!config) return null;

          return (
            <Card key={type} className="relative">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Car className="w-5 h-5 text-primary" />
                    <CardTitle className="text-base">{label}</CardTitle>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => resetToDefaults(type as VehicleType)}
                    title="Reset to defaults"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </Button>
                </div>
                <CardDescription className="text-xs">
                  Base multiplier: {multiplier}x
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Tow Fee</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                      <Input
                        type="number"
                        step="0.01"
                        value={config.tow_fee}
                        onChange={(e) => updateConfig(type, 'tow_fee', Number(e.target.value))}
                        className="pl-7 h-9"
                      />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Daily Storage</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                      <Input
                        type="number"
                        step="0.01"
                        value={config.daily_storage_fee}
                        onChange={(e) => updateConfig(type, 'daily_storage_fee', Number(e.target.value))}
                        className="pl-7 h-9"
                      />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Admin Fee</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                      <Input
                        type="number"
                        step="0.01"
                        value={config.admin_fee}
                        onChange={(e) => updateConfig(type, 'admin_fee', Number(e.target.value))}
                        className="pl-7 h-9"
                      />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Gate Fee</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                      <Input
                        type="number"
                        step="0.01"
                        value={config.gate_fee}
                        onChange={(e) => updateConfig(type, 'gate_fee', Number(e.target.value))}
                        className="pl-7 h-9"
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {hasChanges && (
        <div className="fixed bottom-4 right-4 bg-primary text-primary-foreground px-4 py-2 rounded-lg shadow-lg flex items-center gap-2">
          <span className="text-sm">You have unsaved changes</span>
          <Button size="sm" variant="secondary" onClick={saveConfigs} disabled={saving}>
            {saving ? 'Saving...' : 'Save Now'}
          </Button>
        </div>
      )}
    </div>
  );
}
