import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Mail, Lock, AlertCircle, CheckCircle2, User, ArrowLeft, Phone } from 'lucide-react';
import { PasswordStrengthIndicator, isPasswordStrong } from './PasswordStrengthIndicator';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export function AuthModal({ isOpen, onClose, onSuccess }: AuthModalProps) {
  const [mode, setMode] = useState<'signin' | 'signup' | 'forgot' | 'phone' | 'phone-verify'>('signin');
  const [authMethod, setAuthMethod] = useState<'email' | 'phone'>('email');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  
  const { signInWithPassword, signUp, resetPassword, signInWithPhone, verifyPhoneOtp } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setLoading(true);

    try {
      if (mode === 'phone') {
        const { error } = await signInWithPhone(phone);
        if (error) {
          setError(error.message);
        } else {
          setSuccess('Verification code sent to your phone!');
          setMode('phone-verify');
        }
      } else if (mode === 'phone-verify') {
        const { error } = await verifyPhoneOtp(phone, otp);
        if (error) {
          setError(error.message);
        } else {
          onSuccess?.();
          onClose();
        }
      } else if (mode === 'forgot') {
        const { error } = await resetPassword(email);
        if (error) {
          setError(error.message);
        } else {
          setSuccess('Password reset link sent! Check your email.');
        }
      } else if (mode === 'signup') {
        // Validate password strength
        if (!isPasswordStrong(password)) {
          setError('Please meet all password requirements');
          setLoading(false);
          return;
        }

        // Validate passwords match
        if (password !== confirmPassword) {
          setError('Passwords do not match');
          setLoading(false);
          return;
        }

        // Validate name fields
        if (!firstName.trim() || !lastName.trim()) {
          setError('Please enter your first and last name');
          setLoading(false);
          return;
        }

        const { error } = await signUp(email, password);
        if (error) {
          setError(error.message);
        } else {
          // Update the profile with the name after signup
          const { data: { user } } = await supabase.auth.getUser();
          if (user) {
            await supabase
              .from('profiles')
              .update({ full_name: `${firstName.trim()} ${lastName.trim()}` })
              .eq('user_id', user.id);
          }
          setSuccess('Account created! You can now sign in.');
          setMode('signin');
          // Reset signup fields
          setConfirmPassword('');
          setFirstName('');
          setLastName('');
        }
      } else {
        const { error } = await signInWithPassword(email, password);
        if (error) {
          setError(error.message);
        } else {
          onSuccess?.();
          onClose();
        }
      }
    } catch (err) {
      setError('An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  const switchMode = (newMode: 'signin' | 'signup' | 'forgot' | 'phone' | 'phone-verify') => {
    setMode(newMode);
    setError(null);
    setSuccess(null);
    setOtp('');
    if (newMode !== 'signup') {
      setPassword('');
      setConfirmPassword('');
      setFirstName('');
      setLastName('');
    }
  };

  const getTitle = () => {
    if (mode === 'signin') return 'Sign In';
    if (mode === 'signup') return 'Create Account';
    if (mode === 'phone') return 'Phone Sign In';
    if (mode === 'phone-verify') return 'Verify Code';
    return 'Reset Password';
  };

  const getDescription = () => {
    if (mode === 'signin') return 'Sign in to claim your vehicle and track your status';
    if (mode === 'signup') return 'Create an account to start your vehicle claim';
    if (mode === 'phone') return 'Enter your phone number to receive a verification code';
    if (mode === 'phone-verify') return 'Enter the 6-digit code sent to your phone';
    return 'Enter your email and we\'ll send you a reset link';
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center font-display text-2xl">
            {getTitle()}
          </DialogTitle>
          <DialogDescription className="text-center">
            {getDescription()}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          {/* Phone verification OTP input */}
          {mode === 'phone-verify' && (
            <div className="space-y-2">
              <Label>Verification Code</Label>
              <div className="flex justify-center">
                <InputOTP value={otp} onChange={setOtp} maxLength={6}>
                  <InputOTPGroup>
                    <InputOTPSlot index={0} />
                    <InputOTPSlot index={1} />
                    <InputOTPSlot index={2} />
                    <InputOTPSlot index={3} />
                    <InputOTPSlot index={4} />
                    <InputOTPSlot index={5} />
                  </InputOTPGroup>
                </InputOTP>
              </div>
            </div>
          )}

          {/* Phone number input */}
          {mode === 'phone' && (
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  id="phone"
                  type="tel"
                  placeholder="+1 (555) 123-4567"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
              <p className="text-xs text-muted-foreground">Include country code (e.g., +1 for US)</p>
            </div>
          )}

          {/* Email input - show for email-based modes */}
          {(mode === 'signin' || mode === 'signup' || mode === 'forgot') && (
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  placeholder="your@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>
          )}

          {mode === 'signup' && (
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name</Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    id="firstName"
                    type="text"
                    placeholder="John"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    className="pl-10"
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name</Label>
                <Input
                  id="lastName"
                  type="text"
                  placeholder="Doe"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  required
                />
              </div>
            </div>
          )}

          {(mode === 'signin' || mode === 'signup') && (
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label htmlFor="password">Password</Label>
                {mode === 'signin' && (
                  <button
                    type="button"
                    onClick={() => switchMode('forgot')}
                    className="text-xs text-accent hover:underline"
                  >
                    Forgot password?
                  </button>
                )}
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10"
                  required
                  minLength={6}
                />
              </div>
              {mode === 'signup' && <PasswordStrengthIndicator password={password} />}
            </div>
          )}

          {mode === 'signup' && (
            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirm Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="pl-10"
                  required
                  minLength={6}
                />
              </div>
              {password && confirmPassword && password !== confirmPassword && (
                <p className="text-xs text-destructive">Passwords do not match</p>
              )}
            </div>
          )}

          {error && (
            <div className="flex items-center gap-2 text-destructive text-sm bg-destructive/10 p-3 rounded-lg">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="flex items-center gap-2 text-success text-sm bg-success/10 p-3 rounded-lg">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{success}</span>
            </div>
          )}

          <Button 
            type="submit" 
            variant="hero" 
            size="lg" 
            className="w-full" 
            disabled={loading || (mode === 'signup' && !isPasswordStrong(password)) || (mode === 'phone-verify' && otp.length !== 6)}
          >
            {loading 
              ? 'Please wait...' 
              : mode === 'signin' 
                ? 'Sign In' 
                : mode === 'signup' 
                  ? 'Create Account' 
                  : mode === 'phone'
                    ? 'Send Code'
                    : mode === 'phone-verify'
                      ? 'Verify'
                      : 'Send Reset Link'
            }
          </Button>

          {/* Phone sign in option for sign in mode */}
          {mode === 'signin' && (
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">Or</span>
              </div>
            </div>
          )}

          {mode === 'signin' && (
            <Button
              type="button"
              variant="outline"
              size="lg"
              className="w-full"
              onClick={() => switchMode('phone')}
            >
              <Phone className="w-4 h-4 mr-2" />
              Sign in with Phone
            </Button>
          )}

          <div className="text-center text-sm space-y-2">
            {(mode === 'forgot' || mode === 'phone' || mode === 'phone-verify') ? (
              <button
                type="button"
                onClick={() => switchMode('signin')}
                className="text-accent hover:underline font-medium inline-flex items-center gap-1"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to sign in
              </button>
            ) : mode === 'signin' ? (
              <p className="text-muted-foreground">
                Don't have an account?{' '}
                <button
                  type="button"
                  onClick={() => switchMode('signup')}
                  className="text-accent hover:underline font-medium"
                >
                  Sign up
                </button>
              </p>
            ) : (
              <p className="text-muted-foreground">
                Already have an account?{' '}
                <button
                  type="button"
                  onClick={() => switchMode('signin')}
                  className="text-accent hover:underline font-medium"
                >
                  Sign in
                </button>
              </p>
            )}
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}