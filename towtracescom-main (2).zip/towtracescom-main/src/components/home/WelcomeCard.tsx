import { useState, useEffect, ReactNode } from 'react';
import { X, Search, Sparkles, ArrowRight, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';

type VisitorType = 'first-time' | 'returning';

const cardContent: Record<VisitorType, {
  icon: typeof Sparkles;
  title: string;
  description: ReactNode;
  ctaText: string;
  gradientFrom: string;
  gradientTo: string;
}> = {
  'first-time': {
    icon: Sparkles,
    title: "Looking for your towed vehicle?",
    description: <>Search over <span className="text-accent font-semibold">500+ tow yards</span> across the US & Canada. Find your car in seconds!</>,
    ctaText: "Search Now",
    gradientFrom: "from-accent/20",
    gradientTo: "to-info/20",
  },
  'returning': {
    icon: Heart,
    title: "Welcome back!",
    description: <>Good to see you again. Need to <span className="text-accent font-semibold">search for a vehicle</span> or check on an existing claim?</>,
    ctaText: "Continue",
    gradientFrom: "from-success/20",
    gradientTo: "to-accent/20",
  },
};

export function WelcomeCard() {
  const [isVisible, setIsVisible] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);
  const [visitorType, setVisitorType] = useState<VisitorType>('first-time');

  useEffect(() => {
    // Check if user has already dismissed the card in this session
    const hasSeenWelcome = sessionStorage.getItem('welcomeCardDismissed');
    if (hasSeenWelcome) {
      setIsDismissed(true);
      return;
    }

    // Check if this is a returning visitor using localStorage
    const hasVisitedBefore = localStorage.getItem('towtraceVisitor');
    if (hasVisitedBefore) {
      setVisitorType('returning');
    } else {
      // Mark as visited for future sessions
      localStorage.setItem('towtraceVisitor', 'true');
      setVisitorType('first-time');
    }

    // Show the card after a short delay for better UX
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  const handleDismiss = () => {
    setIsVisible(false);
    sessionStorage.setItem('welcomeCardDismissed', 'true');
    setTimeout(() => setIsDismissed(true), 300);
  };

  const handleSearchNow = () => {
    handleDismiss();
    // Scroll to search section
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (isDismissed) return null;

  const content = cardContent[visitorType];
  const IconComponent = content.icon;

  return (
    <div
      className={`fixed bottom-24 right-6 z-40 max-w-sm transition-all duration-500 ease-out ${
        isVisible
          ? 'translate-x-0 opacity-100'
          : 'translate-x-full opacity-0'
      }`}
    >
      <div className="relative bg-card border border-border rounded-2xl shadow-xl overflow-hidden">
        {/* Gradient accent bar */}
        <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${
          visitorType === 'returning' 
            ? 'from-success via-accent to-info' 
            : 'from-accent via-info to-success'
        }`} />
        
        {/* Close button */}
        <button
          onClick={handleDismiss}
          className="absolute top-3 right-3 p-1.5 rounded-full hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
          aria-label="Dismiss"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="p-5 pt-6">
          {/* Icon */}
          <div className={`w-12 h-12 bg-gradient-to-br ${content.gradientFrom} ${content.gradientTo} rounded-xl flex items-center justify-center mb-4`}>
            <IconComponent className={`w-6 h-6 ${visitorType === 'returning' ? 'text-success' : 'text-accent'}`} />
          </div>

          {/* Content */}
          <h3 className="font-display text-lg font-bold mb-2">
            {content.title}
          </h3>
          <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
            {content.description}
          </p>

          {/* CTA */}
          <div className="flex gap-2">
            <Button
              onClick={handleSearchNow}
              size="sm"
              className="flex-1 gap-2"
            >
              <Search className="w-4 h-4" />
              {content.ctaText}
              <ArrowRight className="w-3 h-3" />
            </Button>
            <Button
              onClick={handleDismiss}
              size="sm"
              variant="ghost"
              className="text-muted-foreground"
            >
              Later
            </Button>
          </div>
        </div>

        {/* Decorative background */}
        <div className={`absolute -bottom-8 -right-8 w-32 h-32 bg-gradient-to-br ${content.gradientFrom} to-transparent rounded-full blur-2xl pointer-events-none`} />
      </div>
    </div>
  );
}
