import { useEffect, useState, useRef } from 'react';
import { Car, Building2, Users, Clock } from 'lucide-react';

interface StatItem {
  icon: typeof Car;
  value: number;
  suffix: string;
  label: string;
  color: string;
}

const stats: StatItem[] = [
  { icon: Car, value: 50000, suffix: '+', label: 'Vehicles Found', color: 'from-accent to-accent/70' },
  { icon: Building2, value: 500, suffix: '+', label: 'Partner Tow Yards', color: 'from-info to-info/70' },
  { icon: Users, value: 98, suffix: '%', label: 'Satisfaction Rate', color: 'from-success to-success/70' },
  { icon: Clock, value: 24, suffix: '/7', label: 'Support Available', color: 'from-primary to-primary/70' },
];

function useCountUp(end: number, duration: number = 2000, startCounting: boolean = false) {
  const [count, setCount] = useState(0);
  const countRef = useRef(0);
  const startTimeRef = useRef<number | null>(null);

  useEffect(() => {
    if (!startCounting) return;
    
    const animate = (currentTime: number) => {
      if (!startTimeRef.current) {
        startTimeRef.current = currentTime;
      }
      
      const elapsed = currentTime - startTimeRef.current;
      const progress = Math.min(elapsed / duration, 1);
      
      // Easing function for smooth animation
      const easeOutQuart = 1 - Math.pow(1 - progress, 4);
      const currentCount = Math.floor(easeOutQuart * end);
      
      if (currentCount !== countRef.current) {
        countRef.current = currentCount;
        setCount(currentCount);
      }
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        setCount(end);
      }
    };
    
    requestAnimationFrame(animate);
  }, [end, duration, startCounting]);

  return count;
}

function StatCard({ stat, index, isVisible }: { stat: StatItem; index: number; isVisible: boolean }) {
  const count = useCountUp(stat.value, 2000, isVisible);
  const Icon = stat.icon;
  
  return (
    <div 
      className="relative group"
      style={{ animationDelay: `${index * 0.1}s` }}
    >
      <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 md:p-8 text-center border border-border/50 hover:border-accent/30 transition-all duration-300 hover:shadow-card-lg hover:-translate-y-1">
        {/* Icon */}
        <div className={`w-14 h-14 bg-gradient-to-br ${stat.color} rounded-xl flex items-center justify-center mx-auto mb-4 shadow-lg group-hover:scale-110 transition-transform duration-300`}>
          <Icon className="w-7 h-7 text-white" />
        </div>
        
        {/* Counter */}
        <div className="font-display text-3xl md:text-4xl font-bold mb-2">
          <span className="bg-gradient-to-r from-foreground to-foreground/80 bg-clip-text">
            {count.toLocaleString()}{stat.suffix}
          </span>
        </div>
        
        {/* Label */}
        <p className="text-muted-foreground font-medium">{stat.label}</p>
      </div>
    </div>
  );
}

export function AnimatedStats() {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section 
      ref={sectionRef}
      className="py-16 md:py-20 px-4 bg-gradient-to-b from-background to-muted/20 relative overflow-hidden"
    >
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-accent/5 rounded-full blur-3xl" />
      </div>

      <div className="max-w-5xl mx-auto relative z-10">
        <div className="text-center mb-12 space-y-4">
          <h2 className="font-display text-3xl md:text-4xl font-bold">
            Trusted Across North America
          </h2>
          <p className="text-lg text-muted-foreground max-w-xl mx-auto">
            Join thousands who've successfully recovered their vehicles with TowTrace
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {stats.map((stat, index) => (
            <StatCard key={index} stat={stat} index={index} isVisible={isVisible} />
          ))}
        </div>
      </div>
    </section>
  );
}
