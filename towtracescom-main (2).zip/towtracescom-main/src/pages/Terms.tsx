import { PageHeader } from '@/components/layout/PageHeader';
import { PageFooter } from '@/components/layout/PageFooter';
import { useState, useEffect } from 'react';
import { AuthModal } from '@/components/auth/AuthModal';

export default function Terms() {
  const [showAuthModal, setShowAuthModal] = useState(false);

  useEffect(() => {
    document.title = 'Terms and Conditions | TowTrace';
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <PageHeader onSignInClick={() => setShowAuthModal(true)} />

      <main className="flex-1 px-4 py-12">
        <div className="max-w-3xl mx-auto prose prose-gray dark:prose-invert">
          <h1 className="font-display text-4xl font-bold mb-8">Terms and Conditions</h1>
          
          <p className="text-muted-foreground mb-8">
            Last updated: January 27, 2026
          </p>

          <section className="mb-8">
            <h2 className="font-display text-2xl font-semibold mb-4">1. Acceptance of Terms</h2>
            <p className="text-muted-foreground mb-4">
              By accessing and using TowTrace ("the Service"), you accept and agree to be bound by the terms and provisions of this agreement. If you do not agree to these terms, please do not use our Service.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="font-display text-2xl font-semibold mb-4">2. Description of Service</h2>
            <p className="text-muted-foreground mb-4">
              TowTrace provides a platform that connects vehicle owners with tow yards to facilitate the location, documentation, and payment process for towed vehicles. Our Service includes:
            </p>
            <ul className="list-disc list-inside text-muted-foreground space-y-2 ml-4">
              <li>Vehicle lookup by license plate or VIN across the United States and Canada</li>
              <li>Digital document submission and verification</li>
              <li>Secure online payment processing with digital receipts</li>
              <li>Email receipt delivery for payment confirmation</li>
              <li>Integrated navigation to tow yards via Google Maps and Apple Maps</li>
              <li>Real-time claim status tracking and notifications</li>
              <li>AI-powered customer support assistance</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="font-display text-2xl font-semibold mb-4">3. User Accounts</h2>
            <p className="text-muted-foreground mb-4">
              To access certain features of the Service, you must create an account. You agree to:
            </p>
            <ul className="list-disc list-inside text-muted-foreground space-y-2 ml-4">
              <li>Provide accurate and complete information</li>
              <li>Maintain the security of your account credentials</li>
              <li>Notify us immediately of any unauthorized access</li>
              <li>Accept responsibility for all activities under your account</li>
              <li>Keep your contact information current for receipt delivery and notifications</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="font-display text-2xl font-semibold mb-4">4. Payment Terms</h2>
            <p className="text-muted-foreground mb-4">
              Payments made through TowTrace are processed securely through our payment partners. Please note:
            </p>
            <ul className="list-disc list-inside text-muted-foreground space-y-2 ml-4">
              <li>Payment does not automatically guarantee vehicle release</li>
              <li>Additional documentation may be required by the tow yard</li>
              <li>Fees displayed are provided by tow yards and may be subject to change</li>
              <li>Refunds are subject to individual tow yard policies</li>
              <li>Digital receipts are available for download and email delivery after successful payment</li>
              <li>Payment receipts serve as proof of payment but do not constitute vehicle release authorization</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="font-display text-2xl font-semibold mb-4">5. Receipt and Communication Services</h2>
            <p className="text-muted-foreground mb-4">
              TowTrace provides digital receipt and communication services to enhance your experience:
            </p>
            <ul className="list-disc list-inside text-muted-foreground space-y-2 ml-4">
              <li>Email receipts are sent to the email address associated with your account</li>
              <li>PDF receipts can be downloaded at any time from your claims dashboard</li>
              <li>Receipt emails are delivered via third-party email services; delivery times may vary</li>
              <li>It is your responsibility to ensure your email address is correct and can receive messages</li>
              <li>Push notifications and reminders are optional and can be managed in account settings</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="font-display text-2xl font-semibold mb-4">6. Navigation and Location Services</h2>
            <p className="text-muted-foreground mb-4">
              Our Service provides navigation links to tow yard locations:
            </p>
            <ul className="list-disc list-inside text-muted-foreground space-y-2 ml-4">
              <li>Navigation is provided via third-party services (Google Maps, Apple Maps)</li>
              <li>TowTrace is not responsible for directions accuracy or routing provided by third-party navigation apps</li>
              <li>Tow yard address information is provided by operators and may be subject to change</li>
              <li>Always verify tow yard hours of operation before visiting</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="font-display text-2xl font-semibold mb-4">7. Tow Yard Operators</h2>
            <p className="text-muted-foreground mb-4">
              Tow yard operators using our platform agree to:
            </p>
            <ul className="list-disc list-inside text-muted-foreground space-y-2 ml-4">
              <li>Provide accurate vehicle, fee, and location information</li>
              <li>Respond to claims and document submissions in a timely manner</li>
              <li>Comply with all applicable local, state, provincial, and federal laws</li>
              <li>Maintain appropriate business licenses and insurance</li>
              <li>Keep hours of operation and contact information current</li>
              <li>Honor payments processed through the TowTrace platform</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="font-display text-2xl font-semibold mb-4">8. Limitation of Liability</h2>
            <p className="text-muted-foreground mb-4">
              TowTrace acts as an intermediary platform and is not responsible for:
            </p>
            <ul className="list-disc list-inside text-muted-foreground space-y-2 ml-4">
              <li>The actions or policies of tow yards</li>
              <li>Disputes between vehicle owners and tow yards</li>
              <li>Vehicle damage or loss while in tow yard custody</li>
              <li>Accuracy of information provided by third parties</li>
              <li>Third-party navigation service accuracy or availability</li>
              <li>Email delivery failures due to user email configuration or spam filters</li>
              <li>Changes in tow yard fees after initial vehicle lookup</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="font-display text-2xl font-semibold mb-4">9. Intellectual Property</h2>
            <p className="text-muted-foreground mb-4">
              All content, features, and functionality of the Service are owned by TowTrace and are protected by copyright, trademark, and other intellectual property laws. This includes our logo, branding, receipt templates, and user interface designs.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="font-display text-2xl font-semibold mb-4">10. Data and Privacy</h2>
            <p className="text-muted-foreground mb-4">
              Your use of the Service is also governed by our Privacy Policy. By using TowTrace, you consent to:
            </p>
            <ul className="list-disc list-inside text-muted-foreground space-y-2 ml-4">
              <li>Collection of vehicle and personal information necessary for service delivery</li>
              <li>Storage of payment and receipt records for your account history</li>
              <li>Use of cookies and analytics as described in our Cookie Policy</li>
              <li>Email communications related to your claims and payments</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="font-display text-2xl font-semibold mb-4">11. Termination</h2>
            <p className="text-muted-foreground mb-4">
              We reserve the right to terminate or suspend your account at any time for violations of these terms or for any other reason at our sole discretion. Upon termination, your right to access claim history and receipts may be affected.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="font-display text-2xl font-semibold mb-4">12. Changes to Terms</h2>
            <p className="text-muted-foreground mb-4">
              We may modify these terms at any time. Continued use of the Service after changes constitutes acceptance of the new terms. We encourage you to review these terms periodically.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="font-display text-2xl font-semibold mb-4">13. Contact Information</h2>
            <p className="text-muted-foreground mb-4">
              For questions about these Terms, please contact us at:
            </p>
            <p className="text-muted-foreground">
              Email: legal@towtrace.com<br />
              Phone: 1-800-TOW-FIND<br />
              Support: support@towtrace.com
            </p>
          </section>
        </div>
      </main>

      <PageFooter />
      
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onSuccess={() => setShowAuthModal(false)}
      />
    </div>
  );
}