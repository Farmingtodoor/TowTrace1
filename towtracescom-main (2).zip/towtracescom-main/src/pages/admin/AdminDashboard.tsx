import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users,
  Building2,
  Car,
  FileText,
  Shield,
  Search,
  Loader2,
  RefreshCw,
  Filter,
  LayoutDashboard,
  Mail,
  DollarSign,
} from 'lucide-react';
import { PageHeader } from '@/components/layout/PageHeader';
import { PageFooter } from '@/components/layout/PageFooter';
import { AuthModal } from '@/components/auth/AuthModal';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

// Admin Components
import { StatsCard } from '@/components/admin/StatsCard';
import { UserManagementTable, type UserWithRole } from '@/components/admin/UserManagementTable';
import { TowYardManagementTable, type TowYard } from '@/components/admin/TowYardManagementTable';
import { UserDetailsDialog } from '@/components/admin/UserDetailsDialog';
import { TowYardDetailsDialog } from '@/components/admin/TowYardDetailsDialog';
import { PendingApprovalsCard } from '@/components/admin/PendingApprovalsCard';
import { EmailTemplateManager } from '@/components/admin/EmailTemplateManager';
import { RevenueSection } from '@/components/admin/RevenueSection';

interface Stats {
  totalUsers: number;
  totalTowYards: number;
  totalRecords: number;
  pendingApprovals: number;
}

export default function AdminDashboard() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const { toast } = useToast();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  
  // Search and filters
  const [searchQuery, setSearchQuery] = useState('');
  const [userRoleFilter, setUserRoleFilter] = useState<string>('all');
  const [yardStatusFilter, setYardStatusFilter] = useState<string>('all');
  
  // Data
  const [stats, setStats] = useState<Stats>({
    totalUsers: 0,
    totalTowYards: 0,
    totalRecords: 0,
    pendingApprovals: 0,
  });
  const [users, setUsers] = useState<UserWithRole[]>([]);
  const [towYards, setTowYards] = useState<TowYard[]>([]);
  
  // Dialogs
  const [selectedUser, setSelectedUser] = useState<UserWithRole | null>(null);
  const [showUserDialog, setShowUserDialog] = useState(false);
  const [selectedYard, setSelectedYard] = useState<TowYard | null>(null);
  const [showYardDialog, setShowYardDialog] = useState(false);

  // Check if user is admin
  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      setShowAuthModal(true);
      setLoading(false);
      return;
    }

    const checkAdminRole = async () => {
      const [{ data: admin }, { data: superAdmin }] = await Promise.all([
        supabase.rpc('has_role', { _user_id: user.id, _role: 'admin' }),
        supabase.rpc('has_role', { _user_id: user.id, _role: 'super_admin' as any }),
      ]);

      setIsAdmin(admin === true || superAdmin === true);
      setIsSuperAdmin(superAdmin === true);
      setLoading(false);
    };

    checkAdminRole();
  }, [user, authLoading]);

  // Fetch data when admin is confirmed
  useEffect(() => {
    if (!isAdmin) return;
    refreshData();
  }, [isAdmin]);

  const refreshData = async () => {
    setRefreshing(true);
    await Promise.all([fetchStats(), fetchUsers(), fetchTowYards()]);
    setRefreshing(false);
  };

  const fetchStats = async () => {
    const [usersResult, yardsResult, recordsResult, pendingResult] = await Promise.all([
      supabase.from('profiles').select('id', { count: 'exact', head: true }),
      supabase.from('tow_yards').select('id', { count: 'exact', head: true }),
      supabase.from('tow_records').select('id', { count: 'exact', head: true }),
      supabase.from('tow_yards').select('id', { count: 'exact', head: true }).eq('is_approved', false),
    ]);

    setStats({
      totalUsers: usersResult.count || 0,
      totalTowYards: yardsResult.count || 0,
      totalRecords: recordsResult.count || 0,
      pendingApprovals: pendingResult.count || 0,
    });
  };

  const fetchUsers = async () => {
    const { data: profiles } = await supabase
      .from('profiles')
      .select('user_id, email, created_at, full_name')
      .order('created_at', { ascending: false })
      .limit(200);

    if (!profiles) return;

    const usersWithRoles: UserWithRole[] = [];
    for (const profile of profiles) {
      const { data: roles } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', profile.user_id);

      usersWithRoles.push({
        id: profile.user_id,
        email: profile.email || 'Unknown',
        created_at: profile.created_at,
        roles: roles?.map((r) => r.role) || [],
        full_name: profile.full_name || undefined,
      });
    }

    setUsers(usersWithRoles);
  };

  const fetchTowYards = async () => {
    const { data } = await supabase
      .from('tow_yards')
      .select('id, name, city, state_province, country, phone, email, address, is_approved, created_at')
      .order('created_at', { ascending: false });

    if (data) {
      // Fetch operator counts for each yard
      const yardsWithCounts = await Promise.all(
        data.map(async (yard) => {
          const { count: operatorCount } = await supabase
            .from('tow_yard_operators')
            .select('id', { count: 'exact', head: true })
            .eq('tow_yard_id', yard.id);
          
          return {
            ...yard,
            operator_count: operatorCount || 0,
          };
        })
      );
      setTowYards(yardsWithCounts);
    }
  };

  const handleApproveYard = async (yardId: string, approve: boolean) => {
    const yard = towYards.find((y) => y.id === yardId);
    
    const { error } = await supabase
      .from('tow_yards')
      .update({ is_approved: approve })
      .eq('id', yardId);

    if (error) {
      toast({
        title: 'Error',
        description: 'Failed to update tow yard status.',
        variant: 'destructive',
      });
    } else {
      // Send notification email
      if (yard) {
        try {
          await supabase.functions.invoke('send-approval-notification', {
            body: {
              towYardId: yardId,
              towYardName: yard.name,
              approved: approve,
            },
          });
        } catch (notifError) {
          console.error('Failed to send notification:', notifError);
        }
      }

      toast({
        title: approve ? 'Company Approved' : 'Approval Revoked',
        description: `${yard?.name} has been ${approve ? 'approved' : 'rejected'}. Notification sent to operators.`,
      });
      fetchTowYards();
      fetchStats();
    }
  };

  type AppRole = 'consumer' | 'operator' | 'admin' | 'super_admin' | 'reviewer' | 'analyst';

  const handleAddRole = async (userId: string, role: Exclude<AppRole, 'consumer'>) => {
    // Extra safety: only super admins can grant super_admin.
    if (role === 'super_admin' && !isSuperAdmin) {
      toast({
        title: 'Not allowed',
        description: 'Only Super Admins can grant Super Admin role.',
        variant: 'destructive',
      });
      return;
    }

    const { error } = await supabase
      .from('user_roles')
      .insert({ user_id: userId, role: role as any });

    if (error) {
      if (error.code === '23505') {
        toast({
          title: 'Already has role',
          description: 'User already has this role.',
        });
      } else {
        toast({
          title: 'Error',
          description: 'Failed to add role.',
          variant: 'destructive',
        });
      }
    } else {
      toast({
        title: 'Role Added',
        description: `Successfully added ${role} role.`,
      });
      fetchUsers();
    }
  };

  const handleRemoveRole = async (userId: string, role: AppRole) => {
    // Extra safety: only super admins can remove super_admin.
    if (role === 'super_admin' && !isSuperAdmin) {
      toast({
        title: 'Not allowed',
        description: 'Only Super Admins can remove Super Admin role.',
        variant: 'destructive',
      });
      return;
    }

    const { error } = await supabase
      .from('user_roles')
      .delete()
      .eq('user_id', userId)
      .eq('role', role as any);

    if (error) {
      toast({
        title: 'Error',
        description: 'Failed to remove role.',
        variant: 'destructive',
      });
    } else {
      toast({
        title: 'Role Removed',
        description: `Successfully removed ${role} role.`,
      });
      fetchUsers();
    }
  };

  // Filtered data
  const filteredUsers = users.filter((u) => {
    const matchesSearch =
      u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (u.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ?? false);
    
    const matchesRole =
      userRoleFilter === 'all' ||
      (userRoleFilter === 'none' && u.roles.length === 0) ||
      u.roles.includes(userRoleFilter);
    
    return matchesSearch && matchesRole;
  });

  const filteredYards = towYards.filter((y) => {
    const matchesSearch =
      y.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      y.city.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesStatus =
      yardStatusFilter === 'all' ||
      (yardStatusFilter === 'approved' && y.is_approved) ||
      (yardStatusFilter === 'pending' && !y.is_approved);
    
    return matchesSearch && matchesStatus;
  });

  if (authLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <Loader2 className="w-10 h-10 animate-spin text-accent mx-auto" />
          <p className="text-muted-foreground">Loading admin portal...</p>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <PageHeader onSignInClick={() => setShowAuthModal(true)} />
        <main className="flex-1 flex items-center justify-center px-4">
          <div className="text-center max-w-md">
            <div className="w-20 h-20 bg-destructive/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <Shield className="w-10 h-10 text-destructive" />
            </div>
            <h1 className="font-display text-3xl font-bold mb-3">Access Denied</h1>
            <p className="text-muted-foreground mb-6">
              You don't have permission to access the admin portal. Please contact your administrator for access.
            </p>
            <Button onClick={() => navigate('/')} size="lg">
              Return Home
            </Button>
          </div>
        </main>
        <PageFooter />
        <AuthModal
          isOpen={showAuthModal}
          onClose={() => setShowAuthModal(false)}
          onSuccess={() => {
            setShowAuthModal(false);
            window.location.reload();
          }}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <PageHeader onSignInClick={() => setShowAuthModal(true)} />

      <main className="flex-1 px-4 py-6 lg:py-8">
        <div className="max-w-7xl mx-auto space-y-6 lg:space-y-8">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-3 mb-1">
                <div className="p-2 rounded-lg bg-primary/10">
                  <LayoutDashboard className="w-6 h-6 text-primary" />
                </div>
                <h1 className="font-display text-2xl lg:text-3xl font-bold">Admin Dashboard</h1>
              </div>
              <p className="text-muted-foreground">
                Manage users, tow companies, and system settings
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={refreshData}
              disabled={refreshing}
              className="shrink-0"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatsCard
              title="Total Users"
              value={stats.totalUsers}
              icon={Users}
              variant="info"
            />
            <StatsCard
              title="Tow Companies"
              value={stats.totalTowYards}
              icon={Building2}
              variant="accent"
            />
            <StatsCard
              title="Tow Records"
              value={stats.totalRecords}
              icon={Car}
              variant="success"
            />
            <StatsCard
              title="Pending Approvals"
              value={stats.pendingApprovals}
              icon={FileText}
              variant="warning"
            />
          </div>

          {/* Main Content */}
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Main Tabs Area */}
            <div className="lg:col-span-2">
              <Tabs defaultValue="users" className="space-y-4">
                <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
                  <TabsList className="grid w-full sm:w-auto grid-cols-4">
                    <TabsTrigger value="users" className="gap-2">
                      <Users className="w-4 h-4" />
                      Users
                    </TabsTrigger>
                    <TabsTrigger value="companies" className="gap-2">
                      <Building2 className="w-4 h-4" />
                      Companies
                    </TabsTrigger>
                    <TabsTrigger value="revenue" className="gap-2">
                      <DollarSign className="w-4 h-4" />
                      Revenue
                    </TabsTrigger>
                    <TabsTrigger value="emails" className="gap-2">
                      <Mail className="w-4 h-4" />
                      Emails
                    </TabsTrigger>
                  </TabsList>
                </div>

                <TabsContent value="users" className="space-y-4 mt-4">
                  {/* User Filters */}
                  <div className="flex flex-col sm:flex-row gap-3">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        placeholder="Search users by name or email..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                    <Select value={userRoleFilter} onValueChange={setUserRoleFilter}>
                      <SelectTrigger className="w-full sm:w-[160px]">
                        <Filter className="w-4 h-4 mr-2" />
                        <SelectValue placeholder="Filter role" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Roles</SelectItem>
                        <SelectItem value="super_admin">Super Admins</SelectItem>
                        <SelectItem value="admin">Admins</SelectItem>
                        <SelectItem value="reviewer">Reviewers</SelectItem>
                        <SelectItem value="analyst">Analysts</SelectItem>
                        <SelectItem value="operator">Operators</SelectItem>
                        <SelectItem value="consumer">Consumers</SelectItem>
                        <SelectItem value="none">No Roles</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <UserManagementTable
                    users={filteredUsers}
                    onViewUser={(user) => {
                      setSelectedUser(user);
                      setShowUserDialog(true);
                    }}
                    onAddRole={handleAddRole}
                    onRemoveRole={handleRemoveRole}
                  />
                </TabsContent>

                <TabsContent value="companies" className="space-y-4 mt-4">
                  {/* Yard Filters */}
                  <div className="flex flex-col sm:flex-row gap-3">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        placeholder="Search companies by name or city..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                    <Select value={yardStatusFilter} onValueChange={setYardStatusFilter}>
                      <SelectTrigger className="w-full sm:w-[160px]">
                        <Filter className="w-4 h-4 mr-2" />
                        <SelectValue placeholder="Filter status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="approved">Approved</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <TowYardManagementTable
                    yards={filteredYards}
                    onApprove={handleApproveYard}
                    onViewDetails={(yard) => {
                      setSelectedYard(yard);
                      setShowYardDialog(true);
                    }}
                  />
                </TabsContent>

                <TabsContent value="revenue" className="mt-4">
                  <RevenueSection />
                </TabsContent>

                <TabsContent value="emails" className="mt-4">
                  <EmailTemplateManager />
                </TabsContent>
              </Tabs>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              <PendingApprovalsCard
                yards={towYards}
                onApprove={handleApproveYard}
                onViewDetails={(yard) => {
                  setSelectedYard(yard);
                  setShowYardDialog(true);
                }}
              />
            </div>
          </div>
        </div>
      </main>

      <PageFooter />

      {/* Dialogs */}
      <UserDetailsDialog
        user={selectedUser}
        open={showUserDialog}
        onOpenChange={setShowUserDialog}
        onAddRole={handleAddRole}
        onRemoveRole={handleRemoveRole}
      />

      <TowYardDetailsDialog
        yard={selectedYard}
        open={showYardDialog}
        onOpenChange={setShowYardDialog}
        onApprove={handleApproveYard}
      />

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onSuccess={() => {
          setShowAuthModal(false);
          window.location.reload();
        }}
      />
    </div>
  );
}
