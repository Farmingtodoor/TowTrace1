import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  AlertTriangle, 
  ArrowLeft, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Eye,
  Loader2,
  FileText,
  FileQuestion,
  Upload,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { PageHeader } from '@/components/layout/PageHeader';
import { PageFooter } from '@/components/layout/PageFooter';

type DisputeStatus = 'open' | 'under_review' | 'resolved' | 'rejected';
type DisputeType = 'vehicle_damage' | 'property_damage' | 'missing_items' | 'overcharge' | 'other';

interface Dispute {
  id: string;
  claim_id: string;
  tow_record_id: string;
  dispute_type: DisputeType;
  status: DisputeStatus;
  description: string;
  evidence_urls: string[];
  resolution_notes: string | null;
  evidence_requested: boolean | null;
  evidence_request_notes: string | null;
  evidence_requested_at: string | null;
  evidence_submitted_at: string | null;
  created_at: string;
  updated_at: string;
  tow_records?: {
    plate_number: string | null;
    vin: string | null;
    make: string | null;
    model: string | null;
    color: string | null;
  };
  tow_yards?: {
    name: string;
  };
}

const statusConfig: Record<DisputeStatus, { label: string; color: string; icon: React.ComponentType<any> }> = {
  open: { label: 'Open', color: 'bg-warning/10 text-warning border-warning/20', icon: Clock },
  under_review: { label: 'Under Review', color: 'bg-info/10 text-info border-info/20', icon: Eye },
  resolved: { label: 'Resolved', color: 'bg-success/10 text-success border-success/20', icon: CheckCircle2 },
  rejected: { label: 'Rejected', color: 'bg-destructive/10 text-destructive border-destructive/20', icon: XCircle },
};

const disputeTypeLabels: Record<DisputeType, string> = {
  vehicle_damage: 'Vehicle Damage',
  property_damage: 'Property Damage',
  missing_items: 'Missing Items',
  overcharge: 'Overcharge',
  other: 'Other',
};

export default function MyDisputes() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [disputes, setDisputes] = useState<Dispute[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDispute, setSelectedDispute] = useState<Dispute | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [uploadOpen, setUploadOpen] = useState(false);
  const [newEvidenceFiles, setNewEvidenceFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);

  const fetchDisputes = useCallback(async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from('disputes')
        .select(`
          *,
          tow_records (
            plate_number,
            vin,
            make,
            model,
            color
          ),
          tow_yards (
            name
          )
        `)
        .eq('consumer_user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setDisputes(data as Dispute[]);
    } catch (error: any) {
      console.error('Error fetching disputes:', error);
      toast.error('Failed to load disputes');
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/');
      return;
    }

    if (user) {
      fetchDisputes();
    }
  }, [user, authLoading, navigate, fetchDisputes]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const validFiles = files.filter(file => {
      if (file.size > 10 * 1024 * 1024) {
        toast.error(`${file.name} is too large. Max size is 10MB.`);
        return false;
      }
      return true;
    });
    setNewEvidenceFiles(prev => [...prev, ...validFiles]);
  };

  const removeFile = (index: number) => {
    setNewEvidenceFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmitEvidence = async () => {
    if (!selectedDispute || newEvidenceFiles.length === 0) return;

    setUploading(true);
    try {
      const urls: string[] = [];

      for (const file of newEvidenceFiles) {
        const fileExt = file.name.split('.').pop();
        const fileName = `${crypto.randomUUID()}.${fileExt}`;
        const filePath = `disputes/${selectedDispute.claim_id}/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('claim-documents')
          .upload(filePath, file);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('claim-documents')
          .getPublicUrl(filePath);

        urls.push(publicUrl);
      }

      // Update dispute with new evidence
      const { error } = await supabase
        .from('disputes')
        .update({
          evidence_urls: [...(selectedDispute.evidence_urls || []), ...urls],
          evidence_submitted_at: new Date().toISOString(),
        })
        .eq('id', selectedDispute.id);

      if (error) throw error;

      toast.success('Evidence submitted successfully');
      setUploadOpen(false);
      setNewEvidenceFiles([]);
      fetchDisputes();
    } catch (error: any) {
      console.error('Error uploading evidence:', error);
      toast.error('Failed to upload evidence');
    } finally {
      setUploading(false);
    }
  };

  const hasOpenEvidenceRequest = (dispute: Dispute) => {
    return dispute.evidence_requested && 
           dispute.evidence_requested_at &&
           (!dispute.evidence_submitted_at || 
            new Date(dispute.evidence_submitted_at) < new Date(dispute.evidence_requested_at));
  };

  const getVehicleInfo = (dispute: Dispute) => {
    const record = dispute.tow_records;
    if (!record) return 'N/A';
    
    const parts = [
      record.color,
      record.make,
      record.model,
    ].filter(Boolean);
    
    return parts.length > 0 ? parts.join(' ') : (record.plate_number || record.vin || 'N/A');
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-accent" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <PageHeader />
      
      <main className="flex-1 container max-w-4xl mx-auto px-4 py-8">
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <h1 className="font-display text-2xl font-bold flex items-center gap-2">
              <AlertTriangle className="h-6 w-6 text-warning" />
              My Disputes
            </h1>
            <p className="text-muted-foreground">
              Track the status of your filed disputes
            </p>
          </div>
        </div>

        {disputes.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <FileText className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
              <h3 className="font-semibold mb-2">No Disputes Filed</h3>
              <p className="text-sm text-muted-foreground mb-4">
                You haven't filed any disputes yet. If you experience issues with a released vehicle, 
                you can file a dispute from your claims page.
              </p>
              <Button onClick={() => navigate('/my-claims')}>
                View My Claims
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {disputes.map((dispute) => {
              const StatusIcon = statusConfig[dispute.status].icon;
              return (
                <Card key={dispute.id} className="overflow-hidden">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg flex items-center gap-2">
                          <Badge variant="outline">
                            {disputeTypeLabels[dispute.dispute_type]}
                          </Badge>
                          <Badge className={statusConfig[dispute.status].color}>
                            <StatusIcon className="h-3 w-3 mr-1" />
                            {statusConfig[dispute.status].label}
                          </Badge>
                        </CardTitle>
                        <CardDescription className="mt-1">
                          Filed on {format(new Date(dispute.created_at), 'MMMM d, yyyy')}
                        </CardDescription>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setSelectedDispute(dispute);
                          setDetailsOpen(true);
                        }}
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        Details
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">Vehicle</p>
                        <p className="font-medium">{getVehicleInfo(dispute)}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Tow Yard</p>
                        <p className="font-medium">{dispute.tow_yards?.name || 'Unknown'}</p>
                      </div>
                    </div>
                    
                    {/* Evidence Request Alert */}
                    {hasOpenEvidenceRequest(dispute) && (
                      <div className="mt-4 p-3 bg-warning/10 border border-warning/20 rounded-lg">
                        <div className="flex items-start gap-2">
                          <FileQuestion className="h-5 w-5 text-warning flex-shrink-0 mt-0.5" />
                          <div className="flex-1">
                            <p className="text-sm font-medium text-warning">Additional Evidence Requested</p>
                            <p className="text-sm text-muted-foreground mt-1">
                              {dispute.evidence_request_notes || 'The tow company has requested additional evidence.'}
                            </p>
                            <Button
                              size="sm"
                              className="mt-2 gap-1"
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedDispute(dispute);
                                setUploadOpen(true);
                              }}
                            >
                              <Upload className="h-4 w-4" />
                              Upload Evidence
                            </Button>
                          </div>
                        </div>
                      </div>
                    )}

                    {dispute.resolution_notes && (
                      <div className="mt-4 p-3 bg-muted rounded-lg">
                        <p className="text-xs text-muted-foreground mb-1">Resolution Notes</p>
                        <p className="text-sm">{dispute.resolution_notes}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {/* Details Dialog */}
        <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Dispute Details</DialogTitle>
              <DialogDescription>
                Filed on {selectedDispute && format(new Date(selectedDispute.created_at), 'MMMM d, yyyy')}
              </DialogDescription>
            </DialogHeader>

            {selectedDispute && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Type</p>
                    <p className="font-medium">{disputeTypeLabels[selectedDispute.dispute_type]}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Status</p>
                    <Badge className={statusConfig[selectedDispute.status].color}>
                      {statusConfig[selectedDispute.status].label}
                    </Badge>
                  </div>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground mb-1">Vehicle</p>
                  <p className="font-medium">{getVehicleInfo(selectedDispute)}</p>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground mb-1">Tow Yard</p>
                  <p className="font-medium">{selectedDispute.tow_yards?.name || 'Unknown'}</p>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground mb-1">Your Description</p>
                  <p className="text-sm bg-muted p-3 rounded-lg">{selectedDispute.description}</p>
                </div>

                {selectedDispute.evidence_urls && selectedDispute.evidence_urls.length > 0 && (
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">
                      Evidence ({selectedDispute.evidence_urls.length} files)
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {selectedDispute.evidence_urls.map((url, index) => (
                        <a
                          key={index}
                          href={url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3 py-1.5 bg-muted rounded text-sm hover:bg-muted/80 transition-colors"
                        >
                          View File {index + 1}
                        </a>
                      ))}
                    </div>
                  </div>
                )}

                {/* Evidence Request Info in Details */}
                {selectedDispute.evidence_requested && selectedDispute.evidence_request_notes && (
                  <div className="p-3 bg-warning/10 border border-warning/20 rounded-lg">
                    <p className="text-sm font-medium text-warning mb-1">Evidence Request</p>
                    <p className="text-sm text-muted-foreground">
                      {selectedDispute.evidence_request_notes}
                    </p>
                    {selectedDispute.evidence_requested_at && (
                      <p className="text-xs text-muted-foreground mt-2">
                        Requested on {format(new Date(selectedDispute.evidence_requested_at), 'MMM d, yyyy')}
                        {selectedDispute.evidence_submitted_at && (
                          <> • Submitted on {format(new Date(selectedDispute.evidence_submitted_at), 'MMM d, yyyy')}</>
                        )}
                      </p>
                    )}
                  </div>
                )}

                {selectedDispute.resolution_notes && (
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Resolution Notes</p>
                    <p className="text-sm bg-success/10 border border-success/20 p-3 rounded-lg">
                      {selectedDispute.resolution_notes}
                    </p>
                  </div>
                )}
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Upload Evidence Dialog */}
        <Dialog open={uploadOpen} onOpenChange={setUploadOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5" />
                Upload Additional Evidence
              </DialogTitle>
              <DialogDescription>
                {selectedDispute?.evidence_request_notes || 'Upload the requested evidence files.'}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div className="border-2 border-dashed border-border rounded-lg p-4 text-center">
                <input
                  type="file"
                  multiple
                  accept="image/*,.pdf"
                  onChange={handleFileChange}
                  className="hidden"
                  id="evidence-upload-new"
                />
                <label
                  htmlFor="evidence-upload-new"
                  className="cursor-pointer flex flex-col items-center gap-2"
                >
                  <Upload className="h-8 w-8 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">
                    Click to upload photos or documents
                  </span>
                  <span className="text-xs text-muted-foreground">
                    Max 10MB per file
                  </span>
                </label>
              </div>

              {newEvidenceFiles.length > 0 && (
                <div className="space-y-2">
                  <p className="text-sm font-medium">Selected files:</p>
                  <div className="flex flex-wrap gap-2">
                    {newEvidenceFiles.map((file, index) => (
                      <div
                        key={index}
                        className="flex items-center gap-1 bg-muted px-2 py-1 rounded text-sm"
                      >
                        <span className="truncate max-w-[150px]">{file.name}</span>
                        <button
                          type="button"
                          onClick={() => removeFile(index)}
                          className="text-muted-foreground hover:text-destructive"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => {
                setUploadOpen(false);
                setNewEvidenceFiles([]);
              }}>
                Cancel
              </Button>
              <Button 
                onClick={handleSubmitEvidence} 
                disabled={uploading || newEvidenceFiles.length === 0}
              >
                {uploading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Uploading...
                  </>
                ) : (
                  'Submit Evidence'
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </main>

      <PageFooter />
    </div>
  );
}
