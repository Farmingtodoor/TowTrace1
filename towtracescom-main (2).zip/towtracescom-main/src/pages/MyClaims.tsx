import { useState, useEffect, useCallback, useMemo } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { FileText, Clock, CheckCircle, ArrowRight, Filter, AlertTriangle } from 'lucide-react';
import { PageHeader } from '@/components/layout/PageHeader';
import { PageFooter } from '@/components/layout/PageFooter';
import { AuthModal } from '@/components/auth/AuthModal';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { sendPaymentConfirmation } from '@/lib/notifications';
import { useClaimRealtime } from '@/hooks/useClaimRealtime';
import { PushNotificationToggle } from '@/components/notifications/PushNotificationToggle';
import { DownloadReceiptButton } from '@/components/payments/DownloadReceiptButton';
import { EmailReceiptButton } from '@/components/payments/EmailReceiptButton';
import { DisputeForm } from '@/components/disputes/DisputeForm';
import { calculateServiceFee, calculateGrandTotal } from '@/lib/payments';
import { toast } from 'sonner';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';

type StatusFilter = 'all' | 'pending' | 'approved' | 'complete';

interface Claim {
  id: string;
  claim_status: string;
  created_at: string;
  updated_at: string;
  tow_record_id: string;
  tow_record: {
    id: string;
    make: string | null;
    model: string | null;
    plate_number: string | null;
    vin: string | null;
    color: string | null;
    tow_fee: number;
    daily_storage_fee: number;
    admin_fee: number;
    gate_fee: number;
    storage_start_datetime: string | null;
    status: string;
    tow_yard_id: string;
    tow_yard: {
      name: string;
      address: string;
      city: string;
      state_province: string;
      phone: string;
    };
  };
}

export default function MyClaims() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [claims, setClaims] = useState<Claim[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [disputeOpen, setDisputeOpen] = useState(false);
  const [selectedClaimForDispute, setSelectedClaimForDispute] = useState<Claim | null>(null);

  // Filter claims based on selected status
  const filteredClaims = useMemo(() => {
    if (statusFilter === 'all') return claims;
    
    const statusMap: Record<StatusFilter, string[]> = {
      all: [],
      pending: ['started', 'docs_submitted', 'payment_pending'],
      approved: ['docs_approved'],
      complete: ['complete'],
    };
    
    return claims.filter(claim => statusMap[statusFilter].includes(claim.claim_status));
  }, [claims, statusFilter]);

  // Handle payment success
  useEffect(() => {
    if (searchParams.get('payment') === 'success' && user?.email) {
      toast.success('Payment completed successfully!');
      // Send confirmation email
      const claimId = searchParams.get('claim');
      sendPaymentConfirmation(
        user.email,
        user.user_metadata?.full_name || 'Customer',
        0, // Amount would need to be retrieved
        claimId || undefined
      );
    }
  }, [searchParams, user]);

  useEffect(() => {
    if (!authLoading && !user) {
      setShowAuthModal(true);
    }
  }, [authLoading, user]);

  const fetchClaims = useCallback(async () => {
    if (!user) return;
    
    setLoading(true);
    const { data, error } = await supabase
      .from('claims')
      .select(`
        id,
        claim_status,
        created_at,
        updated_at,
        tow_record_id,
        tow_record:tow_records (
          id,
          make,
          model,
          plate_number,
          vin,
          color,
          tow_fee,
          daily_storage_fee,
          admin_fee,
          gate_fee,
          storage_start_datetime,
          status,
          tow_yard_id,
          tow_yard:tow_yards (
            name,
            address,
            city,
            state_province,
            phone
          )
        )
      `)
      .eq('consumer_user_id', user.id)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching claims:', error);
    } else {
      setClaims(data as unknown as Claim[]);
    }
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchClaims();
  }, [fetchClaims]);

  // Real-time claim status updates
  useClaimRealtime({
    userId: user?.id,
    userEmail: user?.email,
    userName: user?.user_metadata?.full_name,
    onClaimUpdate: fetchClaims,
  });

  const getStatusBadge = (status: string) => {
    const badges: Record<string, { icon: typeof Clock; label: string; className: string }> = {
      started: {
        icon: FileText,
        label: 'Documents Needed',
        className: 'bg-warning/10 text-warning',
      },
      docs_submitted: {
        icon: Clock,
        label: 'Under Review',
        className: 'bg-info/10 text-info',
      },
      docs_approved: {
        icon: CheckCircle,
        label: 'Docs Approved',
        className: 'bg-success/10 text-success',
      },
      payment_pending: {
        icon: Clock,
        label: 'Payment Pending',
        className: 'bg-warning/10 text-warning',
      },
      complete: {
        icon: CheckCircle,
        label: 'Complete',
        className: 'bg-success/10 text-success',
      },
    };

    const badge = badges[status] || badges.started;
    const Icon = badge.icon;

    return (
      <span className={`inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full ${badge.className}`}>
        <Icon className="w-3 h-3" />
        {badge.label}
      </span>
    );
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <PageHeader onSignInClick={() => setShowAuthModal(true)} />

      <main className="flex-1 px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="font-display text-3xl font-bold">My Claims</h1>
              <p className="text-muted-foreground mt-2">
                Track the status of your vehicle claims and document verification.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate('/my-disputes')}
                className="gap-1"
              >
                <AlertTriangle className="h-4 w-4" />
                My Disputes
              </Button>
              <PushNotificationToggle />
            </div>
          </div>

          {/* Status Filter Tabs */}
          {claims.length > 0 && (
            <Tabs value={statusFilter} onValueChange={(v) => setStatusFilter(v as StatusFilter)} className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="all" className="text-xs sm:text-sm">
                  All ({claims.length})
                </TabsTrigger>
                <TabsTrigger value="pending" className="text-xs sm:text-sm">
                  Pending ({claims.filter(c => ['started', 'docs_submitted', 'payment_pending'].includes(c.claim_status)).length})
                </TabsTrigger>
                <TabsTrigger value="approved" className="text-xs sm:text-sm">
                  Approved ({claims.filter(c => c.claim_status === 'docs_approved').length})
                </TabsTrigger>
                <TabsTrigger value="complete" className="text-xs sm:text-sm">
                  Complete ({claims.filter(c => c.claim_status === 'complete').length})
                </TabsTrigger>
              </TabsList>
            </Tabs>
          )}
          {loading ? (
            <div className="bg-card rounded-xl p-8 text-center">
              <div className="animate-pulse text-muted-foreground">Loading your claims...</div>
            </div>
          ) : claims.length === 0 ? (
            <div className="bg-card rounded-xl p-8 text-center space-y-4">
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto">
                <FileText className="w-8 h-8 text-muted-foreground" />
              </div>
              <div>
                <p className="font-semibold text-lg">No Claims Yet</p>
                <p className="text-muted-foreground">
                  Search for your towed vehicle and start a claim to see it here.
                </p>
              </div>
              <Button asChild>
                <Link to="/">
                  Find My Vehicle
                </Link>
              </Button>
            </div>
          ) : filteredClaims.length === 0 ? (
            <div className="bg-card rounded-xl p-8 text-center space-y-4">
              <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto">
                <Filter className="w-8 h-8 text-muted-foreground" />
              </div>
              <div>
                <p className="font-semibold text-lg">No {statusFilter} claims</p>
                <p className="text-muted-foreground">
                  You don't have any claims with this status.
                </p>
              </div>
              <Button variant="outline" onClick={() => setStatusFilter('all')}>
                View All Claims
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredClaims.map((claim) => {
                // Calculate fees for receipt
                const daysStored = claim.tow_record?.storage_start_datetime
                  ? Math.max(1, Math.ceil((new Date().getTime() - new Date(claim.tow_record.storage_start_datetime).getTime()) / (1000 * 60 * 60 * 24)))
                  : 1;
                const storageFee = (claim.tow_record?.daily_storage_fee || 0) * daysStored;
                const subtotal = (claim.tow_record?.tow_fee || 0) + storageFee + (claim.tow_record?.admin_fee || 0) + (claim.tow_record?.gate_fee || 0);
                const serviceFee = calculateServiceFee(subtotal);
                const total = calculateGrandTotal(subtotal);

                return (
                  <div
                    key={claim.id}
                    className="bg-card rounded-xl p-5 hover:shadow-card-lg transition-shadow"
                  >
                    <Link
                      to={`/claim/${claim.tow_record?.vin || claim.id}`}
                      className="block"
                    >
                      <div className="flex items-center justify-between gap-4">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                            <FileText className="w-6 h-6 text-primary" />
                          </div>
                          <div>
                            <p className="font-semibold">
                              {claim.tow_record?.make} {claim.tow_record?.model}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              {claim.tow_record?.plate_number || claim.tow_record?.vin}
                            </p>
                            <p className="text-xs text-muted-foreground mt-1">
                              {claim.tow_record?.tow_yard?.name} • {claim.tow_record?.tow_yard?.city}, {claim.tow_record?.tow_yard?.state_province}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          {getStatusBadge(claim.claim_status)}
                          <ArrowRight className="w-5 h-5 text-muted-foreground" />
                        </div>
                      </div>
                    </Link>
                    
                    {/* Receipt options for completed claims */}
                    {claim.claim_status === 'complete' && claim.tow_record?.tow_yard && (
                      <div className="mt-4 pt-4 border-t border-border flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                        <p className="text-sm text-muted-foreground">
                          Payment completed on {new Date(claim.updated_at).toLocaleDateString()}
                        </p>
                        <div className="flex items-center gap-2">
                          <EmailReceiptButton
                            claimId={claim.id}
                            userEmail={user?.email || ''}
                            paymentDate={new Date(claim.updated_at)}
                            vehicleInfo={{
                              make: claim.tow_record?.make || undefined,
                              model: claim.tow_record?.model || undefined,
                              plateNumber: claim.tow_record?.plate_number || undefined,
                              vin: claim.tow_record?.vin || undefined,
                              color: claim.tow_record?.color || undefined,
                            }}
                            towYard={{
                              name: claim.tow_record.tow_yard.name,
                              address: claim.tow_record.tow_yard.address,
                              city: claim.tow_record.tow_yard.city,
                              state: claim.tow_record.tow_yard.state_province,
                              phone: claim.tow_record.tow_yard.phone,
                            }}
                            fees={{
                              towFee: claim.tow_record?.tow_fee || 0,
                              dailyStorageFee: claim.tow_record?.daily_storage_fee || 0,
                              daysStored,
                              storageFee,
                              adminFee: claim.tow_record?.admin_fee || 0,
                              gateFee: claim.tow_record?.gate_fee || 0,
                              subtotal,
                              serviceFee,
                              total,
                            }}
                            size="sm"
                          />
                          <DownloadReceiptButton
                            claimId={claim.id}
                            paymentDate={new Date(claim.updated_at)}
                            vehicleInfo={{
                              make: claim.tow_record?.make || undefined,
                              model: claim.tow_record?.model || undefined,
                              plateNumber: claim.tow_record?.plate_number || undefined,
                              vin: claim.tow_record?.vin || undefined,
                              color: claim.tow_record?.color || undefined,
                            }}
                            towYard={{
                              name: claim.tow_record.tow_yard.name,
                              address: claim.tow_record.tow_yard.address,
                              city: claim.tow_record.tow_yard.city,
                              state: claim.tow_record.tow_yard.state_province,
                              phone: claim.tow_record.tow_yard.phone,
                            }}
                            fees={{
                              towFee: claim.tow_record?.tow_fee || 0,
                              dailyStorageFee: claim.tow_record?.daily_storage_fee || 0,
                              daysStored,
                              storageFee,
                              adminFee: claim.tow_record?.admin_fee || 0,
                              gateFee: claim.tow_record?.gate_fee || 0,
                              subtotal,
                              serviceFee,
                              total,
                            }}
                            size="sm"
                          />
                        </div>
                      </div>
                    )}

                    {/* Dispute option for released vehicles */}
                    {claim.tow_record?.status === 'released' && claim.tow_record?.tow_yard && (
                      <div className="mt-4 pt-4 border-t border-border flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                        <p className="text-sm text-muted-foreground">
                          Vehicle released - experiencing issues?
                        </p>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={(e) => {
                            e.preventDefault();
                            setSelectedClaimForDispute(claim);
                            setDisputeOpen(true);
                          }}
                          className="gap-1 text-warning hover:text-warning"
                        >
                          <AlertTriangle className="h-4 w-4" />
                          File Dispute
                        </Button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </main>

      <PageFooter />

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => {
          setShowAuthModal(false);
          if (!user) navigate('/');
        }}
        onSuccess={() => setShowAuthModal(false)}
      />

      {/* Dispute Form Modal */}
      {selectedClaimForDispute && (
        <DisputeForm
          open={disputeOpen}
          onOpenChange={setDisputeOpen}
          claimId={selectedClaimForDispute.id}
          towRecordId={selectedClaimForDispute.tow_record_id}
          towYardId={selectedClaimForDispute.tow_record?.tow_yard_id || ''}
          onSuccess={() => {
            setSelectedClaimForDispute(null);
            toast.success('Dispute filed! View it in My Disputes.');
          }}
        />
      )}
    </div>
  );
}
