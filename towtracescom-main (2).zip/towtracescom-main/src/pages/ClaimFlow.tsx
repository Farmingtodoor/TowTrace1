import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, FileText, CheckCircle, Clock, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { PageHeader } from '@/components/layout/PageHeader';
import { PageFooter } from '@/components/layout/PageFooter';
import { DocumentUpload } from '@/components/claims/DocumentUpload';
import { PaymentSummary } from '@/components/payments/PaymentSummary';
import { AuthModal } from '@/components/auth/AuthModal';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { logClaimStarted, logDocsSubmitted } from '@/lib/activityLog';

interface ClaimData {
  id: string;
  claim_status: string;
  tow_record: {
    id: string;
    make: string | null;
    model: string | null;
    plate_number: string | null;
    vin: string | null;
    tow_fee: number;
    daily_storage_fee: number;
    admin_fee: number;
    gate_fee: number;
    storage_start_datetime: string | null;
  };
  documents: Array<{
    id: string;
    doc_type: string;
    status: string;
    file_name: string | null;
  }>;
}

function calculateDaysStored(storageStart: string | null): number {
  if (!storageStart) return 1;
  const start = new Date(storageStart);
  const now = new Date();
  const diffTime = Math.abs(now.getTime() - start.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return Math.max(1, diffDays);
}

const documentTypes = [
  {
    type: 'gov_id' as const,
    label: 'Government-Issued ID',
    description: "Driver's license, passport, or state ID",
    required: true,
  },
  {
    type: 'registration' as const,
    label: 'Vehicle Registration',
    description: 'Current vehicle registration document',
    required: true,
  },
  {
    type: 'insurance' as const,
    label: 'Proof of Insurance',
    description: 'Valid insurance card or declaration page',
    required: true,
  },
  {
    type: 'title' as const,
    label: 'Vehicle Title (if applicable)',
    description: 'Required if registration is not available',
    required: false,
  },
  {
    type: 'authorization' as const,
    label: 'Authorization Letter',
    description: 'If picking up on behalf of owner',
    required: false,
  },
];

export default function ClaimFlow() {
  const { recordId } = useParams<{ recordId: string }>();
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [claim, setClaim] = useState<ClaimData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !user) {
      setShowAuthModal(true);
    }
  }, [authLoading, user]);

  // Fetch or create claim
  useEffect(() => {
    if (!user || !recordId) return;

    const fetchOrCreateClaim = async () => {
      setLoading(true);
      setError(null);

      try {
        // First, determine if recordId is a UUID or a VIN/plate number
        const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(recordId);
        
        let towRecordId = recordId;
        
        // If not a UUID, look up the tow_record by VIN or plate number
        if (!isUuid) {
          const { data: towRecord, error: towRecordError } = await supabase
            .from('tow_records')
            .select('id')
            .or(`vin.eq.${recordId},plate_number.eq.${recordId}`)
            .maybeSingle();
          
          if (towRecordError) throw towRecordError;
          
          if (!towRecord) {
            setError('Vehicle not found. Please check the VIN or plate number.');
            setLoading(false);
            return;
          }
          
          towRecordId = towRecord.id;
        }

        // Check for existing claim using the resolved tow_record_id
        const { data: existingClaim, error: fetchError } = await supabase
          .from('claims')
          .select(`
            id,
            claim_status,
            tow_record:tow_records (
              id,
              make,
              model,
              plate_number,
              vin,
              tow_fee,
              daily_storage_fee,
              admin_fee,
              gate_fee,
              storage_start_datetime
            ),
            documents (
              id,
              doc_type,
              status,
              file_name
            )
          `)
          .eq('tow_record_id', towRecordId)
          .eq('consumer_user_id', user.id)
          .maybeSingle();

        if (fetchError) throw fetchError;

        if (existingClaim) {
          setClaim(existingClaim as unknown as ClaimData);
        } else {
          // Create new claim using the resolved towRecordId
          setCreating(true);
          const { data: newClaim, error: createError } = await supabase
            .from('claims')
            .insert({
              tow_record_id: towRecordId,
              consumer_user_id: user.id,
              claim_status: 'started',
            })
            .select(`
              id,
              claim_status,
              tow_record:tow_records (
                id,
                make,
                model,
                plate_number,
                vin,
                tow_fee,
                daily_storage_fee,
                admin_fee,
                gate_fee,
                storage_start_datetime
              ),
              documents (
                id,
                doc_type,
                status,
                file_name
              )
            `)
            .single();

          if (createError) throw createError;
          
          // Log claim creation
          await logClaimStarted(newClaim.id, towRecordId);
          
          setClaim(newClaim as unknown as ClaimData);
        }
      } catch (err) {
        console.error('Error fetching/creating claim:', err);
        setError('Failed to load claim. Please try again.');
      } finally {
        setLoading(false);
        setCreating(false);
      }
    };

    fetchOrCreateClaim();
  }, [user, recordId]);

  const getDocumentForType = (docType: string) => {
    return claim?.documents.find((d) => d.doc_type === docType);
  };

  const getStatusSteps = () => {
    const steps = [
      { key: 'started', label: 'Started', icon: FileText },
      { key: 'docs_submitted', label: 'Docs Submitted', icon: Clock },
      { key: 'docs_approved', label: 'Docs Approved', icon: CheckCircle },
      { key: 'payment_pending', label: 'Payment', icon: Clock },
      { key: 'complete', label: 'Complete', icon: CheckCircle },
    ];

    const currentIndex = steps.findIndex((s) => s.key === claim?.claim_status);

    return steps.map((step, index) => ({
      ...step,
      isComplete: index < currentIndex,
      isCurrent: index === currentIndex,
    }));
  };

  const handleSubmitDocuments = async () => {
    if (!claim) return;

    const requiredDocs = documentTypes.filter((d) => d.required);
    const uploadedDocs = claim.documents.filter((d) => d.status !== 'rejected');
    
    const allRequiredUploaded = requiredDocs.every((req) =>
      uploadedDocs.some((up) => up.doc_type === req.type)
    );

    if (!allRequiredUploaded) {
      setError('Please upload all required documents before submitting.');
      return;
    }

    try {
      const { error: updateError } = await supabase
        .from('claims')
        .update({ claim_status: 'docs_submitted' })
        .eq('id', claim.id);

      if (updateError) throw updateError;

      // Log document submission
      await logDocsSubmitted(claim.id);

      setClaim((prev) => prev ? { ...prev, claim_status: 'docs_submitted' } : null);
    } catch (err) {
      console.error('Error submitting documents:', err);
      setError('Failed to submit documents. Please try again.');
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <PageHeader onSignInClick={() => setShowAuthModal(true)} />

      <main className="flex-1 px-4 py-8">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Back Button */}
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Search
          </Link>

          {loading || creating ? (
            <div className="space-y-6 animate-in fade-in duration-300">
              {/* Header Skeleton */}
              <div className="bg-card rounded-xl p-6 space-y-4">
                <Skeleton className="h-8 w-48" />
                <div className="flex items-center gap-4">
                  <Skeleton className="w-12 h-12 rounded-lg" />
                  <div className="space-y-2">
                    <Skeleton className="h-5 w-32" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                </div>
              </div>

              {/* Progress Steps Skeleton */}
              <div className="bg-card rounded-xl p-6">
                <div className="flex items-center justify-between">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <div key={i} className="flex flex-col items-center gap-2">
                      <Skeleton className="w-10 h-10 rounded-full" />
                      <Skeleton className="h-3 w-12" />
                    </div>
                  ))}
                </div>
              </div>

              {/* Document Upload Skeleton */}
              <div className="space-y-4">
                <Skeleton className="h-6 w-40" />
                <Skeleton className="h-4 w-full max-w-md" />
                {[1, 2, 3].map((i) => (
                  <div key={i} className="bg-card rounded-xl p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Skeleton className="w-10 h-10 rounded-lg" />
                        <div className="space-y-2">
                          <Skeleton className="h-4 w-36" />
                          <Skeleton className="h-3 w-48" />
                        </div>
                      </div>
                      <Skeleton className="h-9 w-24 rounded-md" />
                    </div>
                  </div>
                ))}
                <Skeleton className="h-11 w-full rounded-md" />
              </div>
            </div>
          ) : error && !claim ? (
            <div className="bg-destructive/10 border border-destructive/20 rounded-xl p-6 flex items-center gap-3">
              <AlertCircle className="w-6 h-6 text-destructive" />
              <div>
                <p className="font-semibold text-destructive">Error</p>
                <p className="text-sm text-destructive/80">{error}</p>
              </div>
            </div>
          ) : claim ? (
            <>
              {/* Header */}
              <div className="bg-card rounded-xl p-6 space-y-4">
                <h1 className="font-display text-2xl font-bold">Claim Your Vehicle</h1>
                <div className="flex items-center gap-4">
                  <div className="bg-primary/10 rounded-lg p-3">
                    <FileText className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold">
                      {claim.tow_record.make} {claim.tow_record.model}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {claim.tow_record.plate_number || claim.tow_record.vin}
                    </p>
                  </div>
                </div>
              </div>

              {/* Progress Steps */}
              <div className="bg-card rounded-xl p-6">
                <div className="flex items-center justify-between">
                  {getStatusSteps().map((step, index) => (
                    <div key={step.key} className="flex flex-col items-center gap-2 relative">
                      <div
                        className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          step.isComplete
                            ? 'bg-success text-success-foreground'
                            : step.isCurrent
                            ? 'bg-accent text-accent-foreground'
                            : 'bg-muted text-muted-foreground'
                        }`}
                      >
                        <step.icon className="w-5 h-5" />
                      </div>
                      <span className="text-xs text-center text-muted-foreground max-w-16">
                        {step.label}
                      </span>
                      {index < getStatusSteps().length - 1 && (
                        <div
                          className={`absolute top-5 left-full w-full h-0.5 -translate-y-1/2 ${
                            step.isComplete ? 'bg-success' : 'bg-muted'
                          }`}
                          style={{ width: 'calc(100% - 40px)', left: '50%', marginLeft: '20px' }}
                        />
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Document Upload Section */}
              {(claim.claim_status === 'started' || claim.claim_status === 'docs_submitted') && (
                <div className="space-y-4">
                  <h2 className="font-display text-xl font-semibold">Upload Documents</h2>
                  <p className="text-muted-foreground">
                    Please upload the required documents for verification. All required documents
                    must be approved before you can proceed to payment.
                  </p>

                  {documentTypes.map((doc) => {
                    const existing = getDocumentForType(doc.type);
                    return (
                      <DocumentUpload
                        key={doc.type}
                        claimId={claim.id}
                        docType={doc.type}
                        label={doc.label}
                        description={doc.description}
                        required={doc.required}
                        existingDocument={
                          existing
                            ? {
                                id: existing.id,
                                status: existing.status as 'pending' | 'approved' | 'rejected',
                                fileName: existing.file_name || undefined,
                              }
                            : undefined
                        }
                        onUploadComplete={() => {
                          // Refresh claim data
                          window.location.reload();
                        }}
                      />
                    );
                  })}

                  {error && (
                    <div className="flex items-center gap-2 text-sm text-destructive">
                      <AlertCircle className="w-4 h-4" />
                      {error}
                    </div>
                  )}

                  {claim.claim_status === 'started' && (
                    <Button
                      className="w-full"
                      size="lg"
                      onClick={handleSubmitDocuments}
                    >
                      Submit Documents for Review
                    </Button>
                  )}

                  {claim.claim_status === 'docs_submitted' && (
                    <div className="bg-info/10 border border-info/20 rounded-xl p-4 flex items-center gap-3">
                      <Clock className="w-6 h-6 text-info" />
                      <div>
                        <p className="font-semibold text-info">Documents Under Review</p>
                        <p className="text-sm text-info/80">
                          We're reviewing your documents. You'll be notified when they're approved.
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Documents Approved - Show Payment */}
              {(claim.claim_status === 'docs_approved' || claim.claim_status === 'payment_pending') && (
                <div className="space-y-4">
                  <div className="bg-success/10 border border-success/20 rounded-xl p-4 flex items-center gap-3">
                    <CheckCircle className="w-6 h-6 text-success" />
                    <div>
                      <p className="font-semibold text-success">Documents Approved!</p>
                      <p className="text-sm text-success/80">
                        Your documents have been verified. Please proceed to payment.
                      </p>
                    </div>
                  </div>
                  
                  <PaymentSummary
                    claimId={claim.id}
                    towRecordId={claim.tow_record.id}
                    towFee={claim.tow_record.tow_fee}
                    storageFee={claim.tow_record.daily_storage_fee * calculateDaysStored(claim.tow_record.storage_start_datetime)}
                    adminFee={claim.tow_record.admin_fee}
                    gateFee={claim.tow_record.gate_fee}
                    daysStored={calculateDaysStored(claim.tow_record.storage_start_datetime)}
                    dailyStorageFee={claim.tow_record.daily_storage_fee}
                    onPaymentSuccess={() => {
                      // Update claim status
                      setClaim((prev) => prev ? { ...prev, claim_status: 'payment_pending' } : null);
                    }}
                  />
                </div>
              )}
            </>
          ) : null}
        </div>
      </main>

      <PageFooter />

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => {
          setShowAuthModal(false);
          if (!user) navigate('/');
        }}
        onSuccess={() => setShowAuthModal(false)}
      />
    </div>
  );
}
