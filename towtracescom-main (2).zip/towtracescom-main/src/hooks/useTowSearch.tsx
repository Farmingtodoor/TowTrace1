import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import type { TowRecord } from '@/components/results/TowResult';
import type { Tables } from '@/integrations/supabase/types';

type TowRecordRow = Tables<'tow_records'>;
type TowYardRow = Tables<'tow_yards'>;

interface SearchResult {
  status: 'idle' | 'loading' | 'found' | 'not_found';
  record?: TowRecord;
  searchType?: 'plate' | 'vin';
  searchValue?: string;
}

function calculateDaysStored(storageStart: string | null): number {
  if (!storageStart) return 1;
  const start = new Date(storageStart);
  const now = new Date();
  const diffTime = Math.abs(now.getTime() - start.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return Math.max(1, diffDays);
}

function mapToTowRecord(dbRecord: TowRecordRow, towYard: TowYardRow): TowRecord {
  const daysStored = calculateDaysStored(dbRecord.storage_start_datetime);
  const dailyStorage = Number(dbRecord.daily_storage_fee) || 0;
  const towFee = Number(dbRecord.tow_fee) || 0;
  const adminFee = Number(dbRecord.admin_fee) || 0;
  const gateFee = Number(dbRecord.gate_fee) || 0;
  const totalDue = towFee + (dailyStorage * daysStored) + adminFee + gateFee;

  // Parse hours JSON safely
  let hoursString = 'Call for hours';
  if (towYard.hours_json && typeof towYard.hours_json === 'object') {
    const hoursObj = towYard.hours_json as Record<string, string>;
    if (hoursObj.display) {
      hoursString = hoursObj.display;
    }
  }

  return {
    id: dbRecord.id,
    plate: dbRecord.plate_number || undefined,
    vin: dbRecord.vin || undefined,
    make: dbRecord.make || undefined,
    model: dbRecord.model || undefined,
    color: dbRecord.color || undefined,
    vehicleType: dbRecord.vehicle_type || undefined,
    towDateTime: dbRecord.tow_datetime,
    towReason: dbRecord.tow_reason || undefined,
    towFromAddress: dbRecord.tow_from_address || undefined,
    towYard: {
      name: towYard.name,
      address: towYard.address,
      city: towYard.city,
      state: towYard.state_province,
      phone: towYard.phone,
      hours: hoursString,
      acceptedPayments: towYard.accepted_payment_methods || ['Cash', 'Credit Card'],
    },
    fees: {
      towFee,
      dailyStorageFee: dailyStorage,
      adminFee,
      gateFee,
      daysStored,
      totalDue,
      currency: (dbRecord.currency as 'USD' | 'CAD') || 'USD',
    },
    status: dbRecord.status as TowRecord['status'],
    releaseRequirements: dbRecord.release_requirements || [
      'Valid government-issued photo ID',
      'Vehicle registration or title',
      'Proof of insurance',
      'Payment in full',
    ],
  };
}

export function useTowSearch() {
  const [result, setResult] = useState<SearchResult>({ status: 'idle' });

  const searchByPlate = useCallback(async (plate: string, region: string, country: 'US' | 'CA') => {
    setResult({ status: 'loading' });

    try {
      // Clean and normalize the plate
      const cleanPlate = plate.replace(/[\s-]/g, '').toUpperCase();
      const regionUpper = region.toUpperCase();
      
      const { data, error } = await supabase
        .from('tow_records')
        .select(`
          *,
          tow_yards!inner(*)
        `)
        .or(`plate_number.ilike.%${cleanPlate}%,plate_number.eq.${cleanPlate}`)
        .ilike('plate_state_province', regionUpper)
        .eq('country', country)
        .neq('status', 'released')
        .order('tow_datetime', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) {
        console.error('Search error:', error);
        setResult({ status: 'not_found', searchType: 'plate', searchValue: `${plate} (${region})` });
        return;
      }

      if (data && data.tow_yards) {
        const record = mapToTowRecord(data as TowRecordRow, data.tow_yards as TowYardRow);
        setResult({ status: 'found', record });
      } else {
        setResult({ status: 'not_found', searchType: 'plate', searchValue: `${plate} (${region})` });
      }
    } catch (err) {
      console.error('Search error:', err);
      setResult({ status: 'not_found', searchType: 'plate', searchValue: `${plate} (${region})` });
    }
  }, []);

  const searchByVIN = useCallback(async (vin: string) => {
    setResult({ status: 'loading' });

    try {
      const cleanVIN = vin.toUpperCase();
      
      const { data, error } = await supabase
        .from('tow_records')
        .select(`
          *,
          tow_yards!inner(*)
        `)
        .eq('vin', cleanVIN)
        .neq('status', 'released')
        .order('tow_datetime', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) {
        console.error('Search error:', error);
        setResult({ status: 'not_found', searchType: 'vin', searchValue: vin });
        return;
      }

      if (data && data.tow_yards) {
        const record = mapToTowRecord(data as TowRecordRow, data.tow_yards as TowYardRow);
        setResult({ status: 'found', record });
      } else {
        setResult({ status: 'not_found', searchType: 'vin', searchValue: vin });
      }
    } catch (err) {
      console.error('Search error:', err);
      setResult({ status: 'not_found', searchType: 'vin', searchValue: vin });
    }
  }, []);

  const reset = useCallback(() => {
    setResult({ status: 'idle' });
  }, []);

  return {
    ...result,
    searchByPlate,
    searchByVIN,
    reset,
    isLoading: result.status === 'loading',
  };
}
