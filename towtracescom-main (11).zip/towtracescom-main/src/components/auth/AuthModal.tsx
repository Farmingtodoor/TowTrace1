import { useState, forwardRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { lovable } from '@/integrations/lovable/index';
import { Mail, Lock, AlertCircle, CheckCircle2, User, ArrowLeft, Phone } from 'lucide-react';
import { PasswordStrengthIndicator, isPasswordStrong } from './PasswordStrengthIndicator';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';
import { Checkbox } from '@/components/ui/checkbox';
import { Link } from 'react-router-dom';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export const AuthModal = forwardRef<HTMLDivElement, AuthModalProps>(function AuthModal({ isOpen, onClose, onSuccess }, ref) {
  const [mode, setMode] = useState<'signin' | 'signup' | 'forgot' | 'phone' | 'phone-verify'>('signin');
  const [authMethod, setAuthMethod] = useState<'email' | 'phone'>('email');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  
  const { signInWithPassword, signUp, resetPassword, signInWithPhone, verifyPhoneOtp } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    setLoading(true);

    try {
      if (mode === 'phone') {
        const { error } = await signInWithPhone(phone);
        if (error) {
          setError(error.message);
        } else {
          setSuccess('Verification code sent to your phone!');
          setMode('phone-verify');
        }
      } else if (mode === 'phone-verify') {
        const { error } = await verifyPhoneOtp(phone, otp);
        if (error) {
          setError(error.message);
        } else {
          onSuccess?.();
          onClose();
        }
      } else if (mode === 'forgot') {
        const { error } = await resetPassword(email);
        if (error) {
          setError(error.message);
        } else {
          setSuccess('Password reset link sent! Check your email.');
        }
      } else if (mode === 'signup') {
        // Validate password strength
        if (!isPasswordStrong(password)) {
          setError('Please meet all password requirements');
          setLoading(false);
          return;
        }

        // Validate passwords match
        if (password !== confirmPassword) {
          setError('Passwords do not match');
          setLoading(false);
          return;
        }

        // Validate name fields
        if (!firstName.trim() || !lastName.trim()) {
          setError('Please enter your first and last name');
          setLoading(false);
          return;
        }

        const { error } = await signUp(email, password);
        if (error) {
          const msg = error.message.toLowerCase();
          if (msg.includes('already registered') || msg.includes('already been registered') || msg.includes('user already exists') || msg.includes('already exists')) {
            setError('An account with this email already exists. Please sign in instead.');
            setLoading(false);
            return;
          }
          setError(error.message);
        } else {
          // Update the profile with the name and terms acceptance after signup
          const { data: { user } } = await supabase.auth.getUser();
          if (user) {
            await supabase
              .from('profiles')
              .update({ 
                full_name: `${firstName.trim()} ${lastName.trim()}`,
                first_name: firstName.trim(),
                last_name: lastName.trim(),
                terms_accepted_at: new Date().toISOString(),
              })
              .eq('user_id', user.id);
            // User was auto-confirmed, proceed directly
            onSuccess?.();
            onClose();
          } else {
            // Email confirmation required
            setSuccess('Account created! Please check your email to verify your account, then sign in.');
            setMode('signin');
            setConfirmPassword('');
            setFirstName('');
            setLastName('');
          }
        }
      } else {
        const { error } = await signInWithPassword(email, password);
        if (error) {
          setError(error.message);
        } else {
          onSuccess?.();
          onClose();
        }
      }
    } catch (err) {
      setError('An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  const switchMode = (newMode: 'signin' | 'signup' | 'forgot' | 'phone' | 'phone-verify') => {
    setMode(newMode);
    setError(null);
    setSuccess(null);
    setOtp('');
    if (newMode !== 'signup') {
      setPassword('');
      setConfirmPassword('');
      setFirstName('');
      setLastName('');
      setAcceptedTerms(false);
    }
  };

  const getTitle = () => {
    if (mode === 'signin') return 'Sign In';
    if (mode === 'signup') return 'Create Account';
    if (mode === 'phone') return 'Phone Sign In';
    if (mode === 'phone-verify') return 'Verify Code';
    return 'Reset Password';
  };

  const getDescription = () => {
    if (mode === 'signin') return 'Sign in to claim your vehicle and track your status';
    if (mode === 'signup') return 'Create an account to start your vehicle claim';
    if (mode === 'phone') return 'Enter your phone number to receive a verification code';
    if (mode === 'phone-verify') return 'Enter the 6-digit code sent to your phone';
    return 'Enter your email and we\'ll send you a reset link';
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center font-display text-2xl">
            {getTitle()}
          </DialogTitle>
          <DialogDescription className="text-center">
            {getDescription()}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          {/* Phone verification OTP input */}
          {mode === 'phone-verify' && (
            <div className="space-y-2">
              <Label>Verification Code</Label>
              <div className="flex justify-center">
                <InputOTP value={otp} onChange={setOtp} maxLength={6}>
                  <InputOTPGroup>
                    <InputOTPSlot index={0} />
                    <InputOTPSlot index={1} />
                    <InputOTPSlot index={2} />
                    <InputOTPSlot index={3} />
                    <InputOTPSlot index={4} />
                    <InputOTPSlot index={5} />
                  </InputOTPGroup>
                </InputOTP>
              </div>
            </div>
          )}

          {/* Phone number input */}
          {mode === 'phone' && (
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  id="phone"
                  type="tel"
                  placeholder="+1 (555) 123-4567"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
              <p className="text-xs text-muted-foreground">Include country code (e.g., +1 for US)</p>
            </div>
          )}

          {/* Email input - show for email-based modes */}
          {(mode === 'signin' || mode === 'signup' || mode === 'forgot') && (
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  placeholder="your@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>
          )}

          {mode === 'signup' && (
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name</Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    id="firstName"
                    type="text"
                    placeholder="John"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    className="pl-10"
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name</Label>
                <Input
                  id="lastName"
                  type="text"
                  placeholder="Doe"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  required
                />
              </div>
            </div>
          )}

          {(mode === 'signin' || mode === 'signup') && (
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label htmlFor="password">Password</Label>
                {mode === 'signin' && (
                  <button
                    type="button"
                    onClick={() => switchMode('forgot')}
                    className="text-xs text-accent hover:underline"
                  >
                    Forgot password?
                  </button>
                )}
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10"
                  required
                  minLength={6}
                />
              </div>
              {mode === 'signup' && <PasswordStrengthIndicator password={password} />}
            </div>
          )}

          {mode === 'signup' && (
            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirm Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="pl-10"
                  required
                  minLength={6}
                />
              </div>
              {password && confirmPassword && password !== confirmPassword && (
                <p className="text-xs text-destructive">Passwords do not match</p>
              )}
            </div>
          )}

          {mode === 'signup' && (
            <div className="flex items-start space-x-2">
              <Checkbox
                id="terms"
                checked={acceptedTerms}
                onCheckedChange={(c) => setAcceptedTerms(c === true)}
                className="mt-0.5"
              />
              <label htmlFor="terms" className="text-sm text-muted-foreground leading-snug">
                I agree to the{' '}
                <Link to="/terms" target="_blank" className="text-accent hover:underline font-medium">
                  Terms & Conditions
                </Link>{' '}
                and{' '}
                <Link to="/privacy" target="_blank" className="text-accent hover:underline font-medium">
                  Privacy Policy
                </Link>
              </label>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-2 text-destructive text-sm bg-destructive/10 p-3 rounded-lg">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="flex items-center gap-2 text-success text-sm bg-success/10 p-3 rounded-lg">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{success}</span>
            </div>
          )}

          <Button 
            type="submit" 
            variant="hero" 
            size="lg" 
            className="w-full" 
            disabled={loading || (mode === 'signup' && (!isPasswordStrong(password) || !acceptedTerms)) || (mode === 'phone-verify' && otp.length !== 6)}
          >
            {loading 
              ? 'Please wait...' 
              : mode === 'signin' 
                ? 'Sign In' 
                : mode === 'signup' 
                  ? 'Create Account' 
                  : mode === 'phone'
                    ? 'Send Code'
                    : mode === 'phone-verify'
                      ? 'Verify'
                      : 'Send Reset Link'
            }
          </Button>

          {/* Phone sign in option for sign in mode */}
          {mode === 'signin' && (
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">Or</span>
              </div>
            </div>
          )}

          {(mode === 'signin' || mode === 'signup') && (
            <Button
              type="button"
              variant="outline"
              size="lg"
              className="w-full"
              onClick={async () => {
                setLoading(true);
                setError(null);
                const result = await lovable.auth.signInWithOAuth("google", {
                  redirect_uri: window.location.origin,
                });
                if (result.error) {
                  setError(result.error.message);
                  setLoading(false);
                  return;
                }
                if (result.redirected) return;
                onSuccess?.();
                onClose();
              }}
              disabled={loading}
            >
              <svg className="w-4 h-4 mr-2" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
              Continue with Google
            </Button>
          )}

          {(mode === 'signin' || mode === 'signup') && (
            <Button
              type="button"
              variant="outline"
              size="lg"
              className="w-full"
              onClick={async () => {
                setLoading(true);
                setError(null);
                const result = await lovable.auth.signInWithOAuth("apple", {
                  redirect_uri: window.location.origin,
                });
                if (result.error) {
                  setError(result.error.message);
                  setLoading(false);
                  return;
                }
                if (result.redirected) return;
                onSuccess?.();
                onClose();
              }}
              disabled={loading}
            >
              <svg className="w-4 h-4 mr-2" viewBox="0 0 24 24" fill="currentColor"><path d="M17.05 20.28c-.98.95-2.05.88-3.08.4-1.09-.5-2.08-.48-3.24 0-1.44.62-2.2.44-3.06-.4C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/></svg>
              Continue with Apple
            </Button>
          )}

          {mode === 'signin' && (
            <Button
              type="button"
              variant="outline"
              size="lg"
              className="w-full"
              onClick={() => switchMode('phone')}
            >
              <Phone className="w-4 h-4 mr-2" />
              Sign in with Phone
            </Button>
          )}

          <div className="text-center text-sm space-y-2">
            {(mode === 'forgot' || mode === 'phone' || mode === 'phone-verify') ? (
              <button
                type="button"
                onClick={() => switchMode('signin')}
                className="text-accent hover:underline font-medium inline-flex items-center gap-1"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to sign in
              </button>
            ) : mode === 'signin' ? (
              <p className="text-muted-foreground">
                Don't have an account?{' '}
                <button
                  type="button"
                  onClick={() => switchMode('signup')}
                  className="text-accent hover:underline font-medium"
                >
                  Sign up
                </button>
              </p>
            ) : (
              <p className="text-muted-foreground">
                Already have an account?{' '}
                <button
                  type="button"
                  onClick={() => switchMode('signin')}
                  className="text-accent hover:underline font-medium"
                >
                  Sign in
                </button>
              </p>
            )}

            {/* Tow Company signup link */}
            {(mode === 'signin' || mode === 'signup') && (
              <div className="pt-2 border-t border-border mt-3">
                <p className="text-muted-foreground">
                  Are you a tow company?{' '}
                  <Link
                    to="/signup/company"
                    onClick={onClose}
                    className="text-accent hover:underline font-medium"
                  >
                    Register your company
                  </Link>
                </p>
              </div>
            )}
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
});