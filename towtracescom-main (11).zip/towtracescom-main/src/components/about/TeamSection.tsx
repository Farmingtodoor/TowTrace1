import { Linkedin, Twitter } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export function TeamSection() {
  return (
    <section className="py-20 px-4 bg-muted/30">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4">Leadership</Badge>
          <h2 className="font-display text-3xl font-bold mb-4">Meet Our Team</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Industry veterans united by a mission to revolutionize vehicle recovery 
            through technology and exceptional service.
          </p>
        </div>

        {/* CEO Card */}
        <div className="bg-card rounded-2xl p-8 shadow-card text-center max-w-lg mx-auto">
          {/* Name & Role */}
          <h3 className="font-display text-2xl font-semibold mb-1">Clarkson Theophilius</h3>
          <p className="text-accent font-medium text-sm mb-4">Chief Executive Officer</p>

          {/* Bio */}
          <p className="text-muted-foreground text-sm leading-relaxed mb-4">
            A visionary leader with over a decade of experience transforming complex data ecosystems into actionable business intelligence. Clarkson brings deep expertise in enterprise data architecture, predictive analytics, and digital transformation from his tenure at Fortune 500 financial institutions.
          </p>

          {/* Experience Badges */}
          <div className="flex flex-wrap justify-center gap-2 mb-4">
            {['PwC', 'Citibank', 'Wells Fargo', 'Deloitte'].map((company) => (
              <Badge key={company} variant="outline" className="text-xs">
                {company}
              </Badge>
            ))}
          </div>

          {/* Social Links */}
          <div className="flex justify-center gap-3 pt-2 border-t border-border">
            <a href="https://www.linkedin.com/in/clarkson-theophilius-084359151/" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-accent transition-colors p-2" aria-label="Clarkson's LinkedIn">
              <Linkedin className="w-5 h-5" />
            </a>
          </div>
        </div>

        {/* CEO Quote */}
        <div className="mt-12 bg-gradient-to-r from-primary/5 via-accent/5 to-primary/5 rounded-2xl p-8 border border-border">
          <div className="text-center">
            <h4 className="font-display text-lg font-semibold mb-2">A Word from Our CEO</h4>
            <blockquote className="text-muted-foreground italic">
              "At TowTrace, we're applying the same rigor and data-driven approach that 
              powers the world's largest financial institutions to solve a problem that 
              affects millions of vehicle owners every year. Our mission is to bring 
              transparency, efficiency, and peace of mind to an industry that has long 
              been fragmented and frustrating."
            </blockquote>
            <p className="text-sm text-accent font-medium mt-3">— Clarkson Theophilius, CEO</p>
          </div>
        </div>
      </div>
    </section>
  );
}
