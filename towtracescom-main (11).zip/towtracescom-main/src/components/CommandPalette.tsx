import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList, CommandSeparator } from '@/components/ui/command';
import {
  Search, Home, Truck, FileText, Users, AlertCircle, Settings,
  CreditCard, Shield, HelpCircle, Info, Moon, Sun, LogOut, LogIn,
  ClipboardList, MapPin, Building2, Scale
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useUserProfile } from '@/hooks/useUserProfile';
import { useTheme } from 'next-themes';

interface CommandAction {
  id: string;
  label: string;
  icon: React.ReactNode;
  action: () => void;
  keywords?: string;
  group: string;
}

export function CommandPalette() {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const { user, signOut } = useAuth();
  const { isOperator } = useUserProfile();
  const { theme, setTheme } = useTheme();

  // Toggle with ⌘K / Ctrl+K
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((prev) => !prev);
      }
    };
    const openFromButton = () => setOpen(true);
    document.addEventListener('keydown', down);
    window.addEventListener('open-command-palette', openFromButton);
    return () => {
      document.removeEventListener('keydown', down);
      window.removeEventListener('open-command-palette', openFromButton);
    };
  }, []);

  const go = useCallback((path: string) => {
    navigate(path);
    setOpen(false);
  }, [navigate]);

  const navigationActions: CommandAction[] = [
    { id: 'home', label: 'Go to Home', icon: <Home className="w-4 h-4" />, action: () => go('/'), keywords: 'home main landing search', group: 'Navigation' },
    { id: 'about', label: 'About TowTrace', icon: <Info className="w-4 h-4" />, action: () => go('/about'), keywords: 'about team company', group: 'Navigation' },
    { id: 'faq', label: 'FAQ', icon: <HelpCircle className="w-4 h-4" />, action: () => go('/faq'), keywords: 'faq help questions answers', group: 'Navigation' },
    { id: 'join', label: 'Join as Operator', icon: <Building2 className="w-4 h-4" />, action: () => go('/join'), keywords: 'join register operator tow yard', group: 'Navigation' },
    { id: 'terms', label: 'Terms of Service', icon: <Scale className="w-4 h-4" />, action: () => go('/terms'), keywords: 'terms conditions legal', group: 'Navigation' },
    { id: 'privacy', label: 'Privacy Policy', icon: <Shield className="w-4 h-4" />, action: () => go('/privacy'), keywords: 'privacy policy data', group: 'Navigation' },
  ];

  const userActions: CommandAction[] = user ? [
    { id: 'account', label: 'Account Settings', icon: <Settings className="w-4 h-4" />, action: () => go('/account'), keywords: 'account settings profile', group: 'Account' },
    { id: 'claims', label: 'My Claims', icon: <ClipboardList className="w-4 h-4" />, action: () => go('/my-claims'), keywords: 'claims vehicles towed', group: 'Account' },
    { id: 'disputes', label: 'My Disputes', icon: <AlertCircle className="w-4 h-4" />, action: () => go('/my-disputes'), keywords: 'disputes issues complaints', group: 'Account' },
    { id: 'payments', label: 'Payment History', icon: <CreditCard className="w-4 h-4" />, action: () => go('/payments'), keywords: 'payments receipts billing', group: 'Account' },
    { id: 'signout', label: 'Sign Out', icon: <LogOut className="w-4 h-4" />, action: () => { signOut(); setOpen(false); }, keywords: 'sign out logout', group: 'Account' },
  ] : [
    { id: 'signin', label: 'Sign In', icon: <LogIn className="w-4 h-4" />, action: () => { setOpen(false); /* Handled by parent */ }, keywords: 'sign in login register', group: 'Account' },
  ];

  const operatorActions: CommandAction[] = isOperator ? [
    { id: 'dashboard', label: 'Operator Dashboard', icon: <Truck className="w-4 h-4" />, action: () => go('/operator'), keywords: 'dashboard operator tow records', group: 'Operator' },
    { id: 'documents', label: 'Review Documents', icon: <FileText className="w-4 h-4" />, action: () => go('/operator/documents'), keywords: 'documents review claims approve', group: 'Operator' },
    { id: 'employees', label: 'Team Management', icon: <Users className="w-4 h-4" />, action: () => go('/operator/employees'), keywords: 'team employees staff drivers invite', group: 'Operator' },
    { id: 'op-disputes', label: 'Dispute Resolution', icon: <AlertCircle className="w-4 h-4" />, action: () => go('/operator/disputes'), keywords: 'disputes resolve handle', group: 'Operator' },
  ] : [];

  const quickActions: CommandAction[] = [
    {
      id: 'toggle-theme',
      label: theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode',
      icon: theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />,
      action: () => { setTheme(theme === 'dark' ? 'light' : 'dark'); setOpen(false); },
      keywords: 'theme dark light mode toggle',
      group: 'Quick Actions',
    },
    {
      id: 'search-vehicle',
      label: 'Search for a Vehicle',
      icon: <Search className="w-4 h-4" />,
      action: () => { go('/'); setTimeout(() => document.querySelector<HTMLInputElement>('[data-lookup-input]')?.focus(), 300); },
      keywords: 'search find vehicle plate vin lookup tow',
      group: 'Quick Actions',
    },
  ];

  const groups = [
    { name: 'Quick Actions', actions: quickActions },
    ...(operatorActions.length > 0 ? [{ name: 'Operator', actions: operatorActions }] : []),
    { name: 'Account', actions: userActions },
    { name: 'Navigation', actions: navigationActions },
  ];

  return (
    <CommandDialog open={open} onOpenChange={setOpen}>
      <CommandInput placeholder="Type a command or search..." />
      <CommandList>
        <CommandEmpty>
          <div className="flex flex-col items-center gap-2 py-6 text-muted-foreground">
            <Search className="w-8 h-8 opacity-40" />
            <p className="text-sm">No results found.</p>
          </div>
        </CommandEmpty>
        {groups.map((group, i) => (
          <div key={group.name}>
            {i > 0 && <CommandSeparator />}
            <CommandGroup heading={group.name}>
              {group.actions.map((action) => (
                <CommandItem
                  key={action.id}
                  value={`${action.label} ${action.keywords || ''}`}
                  onSelect={action.action}
                  className="flex items-center gap-3 px-3 py-2.5 cursor-pointer"
                >
                  <span className="flex items-center justify-center w-8 h-8 rounded-md bg-muted text-muted-foreground">
                    {action.icon}
                  </span>
                  <span className="font-medium">{action.label}</span>
                </CommandItem>
              ))}
            </CommandGroup>
          </div>
        ))}
      </CommandList>
      <div className="border-t border-border px-3 py-2 flex items-center justify-between text-xs text-muted-foreground">
        <span>Navigate with ↑↓ · Select with ↵</span>
        <kbd className="inline-flex items-center gap-1 rounded border border-border bg-muted px-1.5 py-0.5 font-mono text-xs">
          ESC
        </kbd>
      </div>
    </CommandDialog>
  );
}
