import { useState, useEffect, useRef } from 'react';
import {
  MapPin,
  Camera,
  Car,
  Send,
  Loader2,
  CheckCircle2,
  Navigation,
  ChevronDown,
  Monitor,
  ShieldCheck,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { VEHICLE_TYPES } from '@/lib/feeCalculator';
import { useAuth } from '@/hooks/useAuth';
import { VehicleConditionReport } from './VehicleConditionReport';

interface DriverMobileModeProps {
  towYardId: string;
  towYardName: string;
  onSwitchToFull: () => void;
}

const TOW_REASONS = [
  'Illegally parked',
  'No parking zone',
  'Expired meter',
  'Blocking driveway',
  'Abandoned vehicle',
  'Accident/collision',
  'Police request',
  'Private property',
  'Other',
];

export function DriverMobileMode({ towYardId, towYardName, onSwitchToFull }: DriverMobileModeProps) {
  const { user } = useAuth();
  const [plate, setPlate] = useState('');
  const [vin, setVin] = useState('');
  const [make, setMake] = useState('');
  const [model, setModel] = useState('');
  const [color, setColor] = useState('');
  const [vehicleType, setVehicleType] = useState('standard');
  const [towReason, setTowReason] = useState('');
  const [towFromAddress, setTowFromAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [photos, setPhotos] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [showConditionReport, setShowConditionReport] = useState(false);
  const [lastRecordId, setLastRecordId] = useState<string | null>(null);
  const [gpsLoading, setGpsLoading] = useState(false);
  const [recentCount, setRecentCount] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  // Fetch today's tow count for the driver
  useEffect(() => {
    if (!user) return;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    supabase
      .from('tow_records')
      .select('id', { count: 'exact', head: true })
      .eq('tow_yard_id', towYardId)
      .eq('driver_user_id', user.id)
      .gte('created_at', today.toISOString())
      .then(({ count }) => setRecentCount(count ?? 0));
  }, [user, towYardId, submitted]);

  const handleGPSFill = () => {
    if (!navigator.geolocation) {
      toast.error('GPS not supported on this device');
      return;
    }
    setGpsLoading(true);
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        try {
          const { latitude, longitude } = position.coords;
          // Use reverse geocoding via a free API
          const res = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=18&addressdetails=1`
          );
          const data = await res.json();
          if (data.display_name) {
            setTowFromAddress(data.display_name);
            toast.success('Location captured');
          } else {
            setTowFromAddress(`${latitude.toFixed(6)}, ${longitude.toFixed(6)}`);
          }
        } catch {
          toast.error('Could not get address from GPS');
        } finally {
          setGpsLoading(false);
        }
      },
      (err) => {
        setGpsLoading(false);
        toast.error(`GPS error: ${err.message}`);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const handlePhotoCapture = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const remaining = 5 - photos.length;
    if (remaining <= 0) {
      toast.error('Maximum 5 photos');
      return;
    }

    setUploading(true);
    const uploaded: string[] = [];

    for (const file of Array.from(files).slice(0, remaining)) {
      if (!file.type.startsWith('image/')) continue;
      if (file.size > 5 * 1024 * 1024) {
        toast.error('Photo too large (max 5MB)');
        continue;
      }

      const ext = file.name.split('.').pop();
      const path = `${towYardId}/${crypto.randomUUID()}.${ext}`;

      const { error } = await supabase.storage
        .from('vehicle-photos')
        .upload(path, file, { contentType: file.type });

      if (error) {
        toast.error('Upload failed');
        continue;
      }

      const { data } = supabase.storage.from('vehicle-photos').getPublicUrl(path);
      uploaded.push(data.publicUrl);
    }

    if (uploaded.length > 0) {
      setPhotos((prev) => [...prev, ...uploaded]);
      toast.success(`${uploaded.length} photo(s) added`);
    }
    setUploading(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (cameraInputRef.current) cameraInputRef.current.value = '';
  };

  const handleSubmit = async () => {
    if (!plate && !vin) {
      toast.error('Enter a plate number or VIN');
      return;
    }
    if (!towReason) {
      toast.error('Select a tow reason');
      return;
    }

    setSubmitting(true);
    try {
      const { data: insertedRecord, error } = await supabase.from('tow_records').insert({
        tow_yard_id: towYardId,
        plate_number: plate.toUpperCase() || null,
        vin: vin.toUpperCase() || null,
        make: make || null,
        model: model || null,
        color: color || null,
        vehicle_type: vehicleType,
        tow_reason: towReason,
        tow_from_address: towFromAddress || null,
        vehicle_photos: photos.length > 0 ? photos : [],
        driver_user_id: user?.id || null,
        driver_name: user?.user_metadata?.full_name || null,
        status: 'towed',
      }).select('id').single();

      if (error) throw error;

      // Log activity
      await supabase.from('audit_logs').insert({
        actor_user_id: user?.id,
        action: 'create_record',
        entity_type: 'tow_record',
        metadata_json: {
          plate: plate.toUpperCase(),
          via: 'driver_mobile_mode',
          photos: photos.length,
        },
      });

      setLastRecordId(insertedRecord.id);
      setShowConditionReport(true);
      toast.success('Tow recorded! Now document vehicle condition.');
    } catch (err: any) {
      toast.error(err.message || 'Failed to submit');
    } finally {
      setSubmitting(false);
    }
  };

  const resetForm = () => {
    setPlate('');
    setVin('');
    setMake('');
    setModel('');
    setColor('');
    setVehicleType('standard');
    setTowReason('');
    setTowFromAddress('');
    setNotes('');
    setPhotos([]);
    setSubmitted(false);
    setShowConditionReport(false);
    setLastRecordId(null);
  };

  const finishConditionReport = () => {
    setShowConditionReport(false);
    setSubmitted(true);
  };

  // Show condition report step
  if (showConditionReport && lastRecordId) {
    return (
      <div className="min-h-screen bg-background pb-safe">
        <div className="sticky top-0 z-50 bg-primary text-primary-foreground px-4 py-3 flex items-center justify-between shadow-md">
          <div>
            <h1 className="font-bold text-lg flex items-center gap-2">
              <ShieldCheck className="w-5 h-5" />
              Condition Report
            </h1>
            <p className="text-primary-foreground/80 text-xs">{towYardName}</p>
          </div>
          <Badge variant="secondary" className="text-xs">
            Step 2 of 2
          </Badge>
        </div>
        <div className="p-4 max-w-lg mx-auto">
          <VehicleConditionReport
            towRecordId={lastRecordId}
            towYardId={towYardId}
            plateNumber={plate.toUpperCase()}
            onComplete={finishConditionReport}
            onSkip={finishConditionReport}
          />
        </div>
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6 gap-6">
        <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center animate-in zoom-in">
          <CheckCircle2 className="w-10 h-10 text-primary" />
        </div>
        <h2 className="text-2xl font-bold text-center">Tow Recorded!</h2>
        <p className="text-muted-foreground text-center">
          {plate && `Vehicle ${plate.toUpperCase()} has been logged.`}
          {!plate && vin && `Vehicle VIN ${vin.toUpperCase()} has been logged.`}
        </p>
        <div className="flex flex-col gap-3 w-full max-w-xs">
          <Button size="lg" onClick={resetForm} className="w-full">
            <Car className="w-5 h-5 mr-2" />
            Log Another Tow
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-safe">
      {/* Compact Header */}
      <div className="sticky top-0 z-50 bg-primary text-primary-foreground px-4 py-3 flex items-center justify-between shadow-md">
        <div>
          <h1 className="font-bold text-lg">Driver Mode</h1>
          <p className="text-primary-foreground/80 text-xs">{towYardName}</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-xs">
            {recentCount} today
          </Badge>
          <Button
            size="sm"
            variant="secondary"
            onClick={onSwitchToFull}
            className="text-xs"
          >
            <Monitor className="w-3 h-3 mr-1" />
            Full View
          </Button>
        </div>
      </div>

      <div className="p-4 space-y-4 max-w-lg mx-auto">
        {/* GPS Location */}
        <Card>
          <CardContent className="pt-4 space-y-3">
            <Label className="flex items-center gap-1.5 text-sm font-semibold">
              <MapPin className="w-4 h-4 text-primary" />
              Pickup Location
            </Label>
            <div className="flex gap-2">
              <Textarea
                placeholder="Enter address or use GPS..."
                value={towFromAddress}
                onChange={(e) => setTowFromAddress(e.target.value)}
                className="min-h-[60px] text-sm"
                rows={2}
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={handleGPSFill}
                disabled={gpsLoading}
                className="shrink-0 h-auto"
              >
                {gpsLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Navigation className="w-5 h-5 text-primary" />
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Vehicle Info */}
        <Card>
          <CardContent className="pt-4 space-y-3">
            <Label className="flex items-center gap-1.5 text-sm font-semibold">
              <Car className="w-4 h-4 text-primary" />
              Vehicle Information
            </Label>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs text-muted-foreground">Plate Number</Label>
                <Input
                  placeholder="ABC 1234"
                  value={plate}
                  onChange={(e) => setPlate(e.target.value)}
                  className="uppercase text-sm"
                />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Color</Label>
                <Input
                  placeholder="e.g. Black"
                  value={color}
                  onChange={(e) => setColor(e.target.value)}
                  className="text-sm"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs text-muted-foreground">Make</Label>
                <Input
                  placeholder="e.g. Toyota"
                  value={make}
                  onChange={(e) => setMake(e.target.value)}
                  className="text-sm"
                />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Model</Label>
                <Input
                  placeholder="e.g. Camry"
                  value={model}
                  onChange={(e) => setModel(e.target.value)}
                  className="text-sm"
                />
              </div>
            </div>

            <div>
              <Label className="text-xs text-muted-foreground">VIN (optional)</Label>
              <Input
                placeholder="17-character VIN"
                value={vin}
                onChange={(e) => setVin(e.target.value)}
                className="uppercase text-sm"
                maxLength={17}
              />
            </div>

            <div>
              <Label className="text-xs text-muted-foreground">Vehicle Type</Label>
              <Select value={vehicleType} onValueChange={setVehicleType}>
                <SelectTrigger className="text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(VEHICLE_TYPES).map(([value, { label }]) => (
                    <SelectItem key={value} value={value}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Tow Reason */}
        <Card>
          <CardContent className="pt-4 space-y-3">
            <Label className="text-xs text-muted-foreground">Tow Reason *</Label>
            <Select value={towReason} onValueChange={setTowReason}>
              <SelectTrigger className="text-sm">
                <SelectValue placeholder="Select reason..." />
              </SelectTrigger>
              <SelectContent>
                {TOW_REASONS.map((reason) => (
                  <SelectItem key={reason} value={reason}>
                    {reason}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        {/* Photos */}
        <Card>
          <CardContent className="pt-4 space-y-3">
            <Label className="flex items-center gap-1.5 text-sm font-semibold">
              <Camera className="w-4 h-4 text-primary" />
              Vehicle Photos
              <span className="text-muted-foreground font-normal text-xs">
                ({photos.length}/5)
              </span>
            </Label>

            {photos.length > 0 && (
              <div className="grid grid-cols-3 gap-2">
                {photos.map((url, i) => (
                  <div
                    key={i}
                    className="relative rounded-lg overflow-hidden border border-border aspect-square"
                  >
                    <img src={url} alt="" className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => setPhotos((p) => p.filter((_, idx) => idx !== i))}
                      className="absolute top-1 right-1 bg-destructive text-destructive-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            )}

            {photos.length < 5 && (
              <div className="grid grid-cols-2 gap-2">
                <input
                  ref={cameraInputRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={handlePhotoCapture}
                  className="hidden"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => cameraInputRef.current?.click()}
                  disabled={uploading}
                  className="text-sm"
                >
                  {uploading ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Camera className="w-4 h-4 mr-2" />
                  )}
                  Camera
                </Button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handlePhotoCapture}
                  className="hidden"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploading}
                  className="text-sm"
                >
                  Gallery
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Submit */}
        <Button
          size="lg"
          onClick={handleSubmit}
          disabled={submitting || (!plate && !vin)}
          className="w-full text-base py-6"
        >
          {submitting ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Submitting...
            </>
          ) : (
            <>
              <Send className="w-5 h-5 mr-2" />
              Log Tow
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
