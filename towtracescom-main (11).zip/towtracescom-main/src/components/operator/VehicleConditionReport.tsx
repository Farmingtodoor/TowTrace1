import { useState, useRef } from 'react';
import {
  Camera,
  Check,
  ChevronDown,
  ChevronUp,
  Loader2,
  AlertTriangle,
  ShieldCheck,
  X,
  Pencil,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';

interface DamageItem {
  area: string;
  label: string;
  hasDamage: boolean;
  severity: 'minor' | 'moderate' | 'severe' | '';
  notes: string;
}

interface AnnotatedPhoto {
  url: string;
  area: string;
  caption: string;
}

interface VehicleConditionReportProps {
  towRecordId: string;
  towYardId: string;
  plateNumber?: string;
  onComplete: () => void;
  onSkip: () => void;
}

const DAMAGE_AREAS: { area: string; label: string }[] = [
  { area: 'front_bumper', label: 'Front Bumper' },
  { area: 'rear_bumper', label: 'Rear Bumper' },
  { area: 'hood', label: 'Hood' },
  { area: 'trunk', label: 'Trunk/Tailgate' },
  { area: 'roof', label: 'Roof' },
  { area: 'driver_front', label: 'Driver Side – Front' },
  { area: 'driver_rear', label: 'Driver Side – Rear' },
  { area: 'passenger_front', label: 'Passenger Side – Front' },
  { area: 'passenger_rear', label: 'Passenger Side – Rear' },
  { area: 'windshield', label: 'Windshield' },
  { area: 'rear_window', label: 'Rear Window' },
  { area: 'mirrors', label: 'Side Mirrors' },
  { area: 'wheels_tires', label: 'Wheels & Tires' },
  { area: 'lights', label: 'Lights (Head/Tail/Signal)' },
  { area: 'undercarriage', label: 'Undercarriage' },
  { area: 'interior', label: 'Interior (visible)' },
];

export function VehicleConditionReport({
  towRecordId,
  towYardId,
  plateNumber,
  onComplete,
  onSkip,
}: VehicleConditionReportProps) {
  const { user } = useAuth();
  const [checklist, setChecklist] = useState<DamageItem[]>(
    DAMAGE_AREAS.map((a) => ({
      area: a.area,
      label: a.label,
      hasDamage: false,
      severity: '',
      notes: '',
    }))
  );
  const [photos, setPhotos] = useState<AnnotatedPhoto[]>([]);
  const [overallNotes, setOverallNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [expandedArea, setExpandedArea] = useState<string | null>(null);
  const [photoArea, setPhotoArea] = useState<string>('general');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const damagedCount = checklist.filter((c) => c.hasDamage).length;

  const overallSeverity = (): string => {
    const damaged = checklist.filter((c) => c.hasDamage);
    if (damaged.length === 0) return 'none';
    if (damaged.some((d) => d.severity === 'severe')) return 'severe';
    if (damaged.some((d) => d.severity === 'moderate')) return 'moderate';
    return 'minor';
  };

  const toggleDamage = (area: string) => {
    setChecklist((prev) =>
      prev.map((item) =>
        item.area === area
          ? {
              ...item,
              hasDamage: !item.hasDamage,
              severity: !item.hasDamage ? 'minor' : '',
              notes: !item.hasDamage ? item.notes : '',
            }
          : item
      )
    );
  };

  const updateItem = (area: string, field: 'severity' | 'notes', value: string) => {
    setChecklist((prev) =>
      prev.map((item) =>
        item.area === area ? { ...item, [field]: value } : item
      )
    );
  };

  const handlePhotoCapture = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    if (photos.length >= 10) {
      toast.error('Maximum 10 photos for condition report');
      return;
    }

    setUploading(true);
    const uploaded: AnnotatedPhoto[] = [];

    for (const file of Array.from(files).slice(0, 10 - photos.length)) {
      if (!file.type.startsWith('image/')) continue;
      if (file.size > 5 * 1024 * 1024) {
        toast.error('Photo too large (max 5MB)');
        continue;
      }

      const ext = file.name.split('.').pop();
      const path = `${towYardId}/condition/${towRecordId}/${crypto.randomUUID()}.${ext}`;

      const { error } = await supabase.storage
        .from('vehicle-photos')
        .upload(path, file, { contentType: file.type });

      if (error) {
        toast.error('Upload failed');
        continue;
      }

      const { data } = supabase.storage.from('vehicle-photos').getPublicUrl(path);
      uploaded.push({
        url: data.publicUrl,
        area: photoArea,
        caption: '',
      });
    }

    if (uploaded.length > 0) {
      setPhotos((prev) => [...prev, ...uploaded]);
      toast.success(`${uploaded.length} photo(s) added`);
    }
    setUploading(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (cameraInputRef.current) cameraInputRef.current.value = '';
  };

  const updatePhotoCaption = (index: number, caption: string) => {
    setPhotos((prev) =>
      prev.map((p, i) => (i === index ? { ...p, caption } : p))
    );
  };

  const removePhoto = (index: number) => {
    setPhotos((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async () => {
    // Validate damaged items have severity
    const invalid = checklist.filter((c) => c.hasDamage && !c.severity);
    if (invalid.length > 0) {
      toast.error(`Select severity for: ${invalid.map((i) => i.label).join(', ')}`);
      return;
    }

    setSubmitting(true);
    try {
      const { error } = await supabase.from('condition_reports' as any).insert({
        tow_record_id: towRecordId,
        tow_yard_id: towYardId,
        driver_user_id: user?.id,
        checklist: checklist.filter((c) => c.hasDamage).map((c) => ({
          area: c.area,
          label: c.label,
          severity: c.severity,
          notes: c.notes,
        })),
        photos: photos.map((p) => ({
          url: p.url,
          area: p.area,
          caption: p.caption,
        })),
        overall_notes: overallNotes || null,
        severity: overallSeverity(),
      } as any);

      if (error) throw error;

      // Audit log
      await supabase.from('audit_logs').insert({
        actor_user_id: user?.id,
        action: 'create_condition_report',
        entity_type: 'condition_report',
        entity_id: towRecordId,
        metadata_json: {
          damaged_areas: damagedCount,
          photos: photos.length,
          severity: overallSeverity(),
        },
      });

      toast.success('Condition report saved!');
      onComplete();
    } catch (err: any) {
      toast.error(err.message || 'Failed to save report');
    } finally {
      setSubmitting(false);
    }
  };

  const severityColor = (sev: string) => {
    switch (sev) {
      case 'minor': return 'bg-warning/10 text-warning border-warning/30';
      case 'moderate': return 'bg-destructive/10 text-destructive/80 border-destructive/20';
      case 'severe': return 'bg-destructive/10 text-destructive border-destructive/30';
      default: return '';
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-bold flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-primary" />
            Vehicle Condition Report
          </h3>
          <p className="text-muted-foreground text-sm">
            {plateNumber ? `Vehicle: ${plateNumber}` : 'Document pre-existing damage'}
          </p>
        </div>
        <Button variant="ghost" size="sm" onClick={onSkip} className="text-xs">
          Skip
        </Button>
      </div>

      {/* Damage Summary */}
      {damagedCount > 0 && (
        <Card className="border-warning/30 bg-warning/5">
          <CardContent className="pt-3 pb-3 flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-warning shrink-0" />
            <div>
              <p className="text-sm font-medium">
                {damagedCount} area{damagedCount > 1 ? 's' : ''} with damage noted
              </p>
              <p className="text-xs text-muted-foreground">
                Overall severity: <span className="font-semibold capitalize">{overallSeverity()}</span>
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Damage Checklist */}
      <Card>
        <CardContent className="pt-4 space-y-1">
          <Label className="text-sm font-semibold mb-2 block">Damage Checklist</Label>
          {checklist.map((item) => (
            <Collapsible
              key={item.area}
              open={expandedArea === item.area}
              onOpenChange={(open) => setExpandedArea(open ? item.area : null)}
            >
              <div className="flex items-center gap-3 py-2 border-b border-border/50 last:border-0">
                <Checkbox
                  checked={item.hasDamage}
                  onCheckedChange={() => toggleDamage(item.area)}
                  className="shrink-0"
                />
                <span
                  className={`text-sm flex-1 ${item.hasDamage ? 'font-medium' : 'text-muted-foreground'}`}
                >
                  {item.label}
                </span>
                {item.hasDamage && item.severity && (
                  <Badge variant="outline" className={`text-xs ${severityColor(item.severity)}`}>
                    {item.severity}
                  </Badge>
                )}
                {item.hasDamage && (
                  <CollapsibleTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-6 w-6">
                      {expandedArea === item.area ? (
                        <ChevronUp className="w-3.5 h-3.5" />
                      ) : (
                        <ChevronDown className="w-3.5 h-3.5" />
                      )}
                    </Button>
                  </CollapsibleTrigger>
                )}
              </div>
              <CollapsibleContent className="pl-9 pb-3 space-y-2">
                <div>
                  <Label className="text-xs text-muted-foreground">Severity</Label>
                  <Select
                    value={item.severity}
                    onValueChange={(v) => updateItem(item.area, 'severity', v)}
                  >
                    <SelectTrigger className="text-sm h-8">
                      <SelectValue placeholder="Select severity" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="minor">Minor – Cosmetic only</SelectItem>
                      <SelectItem value="moderate">Moderate – Noticeable damage</SelectItem>
                      <SelectItem value="severe">Severe – Structural/major</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Notes</Label>
                  <Input
                    placeholder="Describe the damage..."
                    value={item.notes}
                    onChange={(e) => updateItem(item.area, 'notes', e.target.value)}
                    className="text-sm h-8"
                  />
                </div>
              </CollapsibleContent>
            </Collapsible>
          ))}
        </CardContent>
      </Card>

      {/* Photo Documentation */}
      <Card>
        <CardContent className="pt-4 space-y-3">
          <Label className="flex items-center gap-1.5 text-sm font-semibold">
            <Camera className="w-4 h-4 text-primary" />
            Photo Documentation
            <span className="text-muted-foreground font-normal text-xs">
              ({photos.length}/10)
            </span>
          </Label>

          {/* Area selector for photos */}
          <div>
            <Label className="text-xs text-muted-foreground">Photo area tag</Label>
            <Select value={photoArea} onValueChange={setPhotoArea}>
              <SelectTrigger className="text-sm h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="general">General / Overview</SelectItem>
                {DAMAGE_AREAS.map((a) => (
                  <SelectItem key={a.area} value={a.area}>
                    {a.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Photo grid */}
          {photos.length > 0 && (
            <div className="grid grid-cols-2 gap-2">
              {photos.map((photo, i) => (
                <div key={i} className="relative rounded-lg overflow-hidden border border-border">
                  <img
                    src={photo.url}
                    alt={`Condition ${i + 1}`}
                    className="w-full aspect-square object-cover"
                  />
                  <button
                    type="button"
                    onClick={() => removePhoto(i)}
                    className="absolute top-1 right-1 bg-destructive text-destructive-foreground rounded-full w-5 h-5 flex items-center justify-center text-xs"
                  >
                    ×
                  </button>
                  <div className="absolute bottom-0 left-0 right-0 bg-background/90 px-2 py-1 space-y-1">
                    <Badge variant="secondary" className="text-[10px]">
                      {DAMAGE_AREAS.find((a) => a.area === photo.area)?.label || 'General'}
                    </Badge>
                    <Input
                      placeholder="Add caption..."
                      value={photo.caption}
                      onChange={(e) => updatePhotoCaption(i, e.target.value)}
                      className="h-6 text-xs border-0 bg-transparent p-0 focus-visible:ring-0"
                    />
                  </div>
                </div>
              ))}
            </div>
          )}

          {photos.length < 10 && (
            <div className="grid grid-cols-2 gap-2">
              <input
                ref={cameraInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handlePhotoCapture}
                className="hidden"
              />
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => cameraInputRef.current?.click()}
                disabled={uploading}
              >
                {uploading ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Camera className="w-4 h-4 mr-2" />
                )}
                Camera
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                multiple
                onChange={handlePhotoCapture}
                className="hidden"
              />
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
              >
                Gallery
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Overall Notes */}
      <Card>
        <CardContent className="pt-4 space-y-2">
          <Label className="text-sm font-semibold flex items-center gap-1.5">
            <Pencil className="w-4 h-4 text-primary" />
            Additional Notes
          </Label>
          <Textarea
            placeholder="Any other observations about the vehicle condition..."
            value={overallNotes}
            onChange={(e) => setOverallNotes(e.target.value)}
            rows={3}
            className="text-sm"
          />
        </CardContent>
      </Card>

      {/* Submit */}
      <Button
        size="lg"
        onClick={handleSubmit}
        disabled={submitting}
        className="w-full"
      >
        {submitting ? (
          <>
            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
            Saving Report...
          </>
        ) : (
          <>
            <Check className="w-5 h-5 mr-2" />
            Save Condition Report
          </>
        )}
      </Button>
    </div>
  );
}
