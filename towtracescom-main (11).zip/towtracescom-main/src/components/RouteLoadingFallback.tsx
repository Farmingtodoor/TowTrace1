import { motion } from "framer-motion";
import { Truck } from "lucide-react";

export function RouteLoadingFallback() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background gap-4">
      <motion.div
        animate={{ x: [0, 20, 0] }}
        transition={{ duration: 1.2, repeat: Infinity, ease: "easeInOut" }}
      >
        <Truck className="w-10 h-10 text-accent" />
      </motion.div>
      <motion.div
        className="h-1 w-32 rounded-full bg-muted overflow-hidden"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <motion.div
          className="h-full w-1/2 bg-accent rounded-full"
          animate={{ x: ["-100%", "200%"] }}
          transition={{ duration: 1, repeat: Infinity, ease: "easeInOut" }}
        />
      </motion.div>
    </div>
  );
}
