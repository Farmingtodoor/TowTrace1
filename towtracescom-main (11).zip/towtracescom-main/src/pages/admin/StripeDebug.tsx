import { useEffect, useState } from "react";
import { Loader2, RefreshCw, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";

export default function StripeDebug() {
  const { user } = useAuth();
  const [email, setEmail] = useState("");
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async (targetEmail?: string) => {
    setLoading(true);
    setError(null);
    try {
      const path = targetEmail ? `?email=${encodeURIComponent(targetEmail)}` : "";
      const { data: res, error: fnErr } = await supabase.functions.invoke(
        `debug-stripe-subscription${path}`,
        { method: "GET" }
      );
      if (fnErr) throw fnErr;
      if (res?.error) throw new Error(res.error);
      setData(res);
    } catch (e: any) {
      setError(e?.message || "Failed to load Stripe debug data");
      setData(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user?.email) {
      setEmail(user.email);
      fetchData();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.email]);

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-display font-semibold">Stripe Subscription Debug</h1>
            <p className="text-sm text-muted-foreground">
              Internal admin tool — raw Stripe fields used by the trial flow
            </p>
          </div>
          <Button variant="outline" onClick={() => fetchData(email)} disabled={loading}>
            {loading ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <RefreshCw className="w-4 h-4 mr-2" />
            )}
            Refresh
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Lookup customer by email</CardTitle>
          </CardHeader>
          <CardContent>
            <form
              className="flex gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                fetchData(email);
              }}
            >
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="customer@example.com"
              />
              <Button type="submit" disabled={loading || !email}>
                <Search className="w-4 h-4 mr-2" />
                Inspect
              </Button>
            </form>
          </CardContent>
        </Card>

        {error && (
          <Card className="border-destructive/50">
            <CardContent className="pt-6">
              <p className="text-destructive font-medium">Error: {error}</p>
            </CardContent>
          </Card>
        )}

        {loading && !data && (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
          </div>
        )}

        {data && (
          <>
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Context</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                  <span className="text-muted-foreground">Target email:</span>
                  <span className="font-mono">{data.target_email}</span>
                  <span className="text-muted-foreground">Stripe API version:</span>
                  <span className="font-mono">{data.stripe_api_version}</span>
                  <span className="text-muted-foreground">Now (UTC):</span>
                  <span className="font-mono">{data.now_iso}</span>
                </div>
              </CardContent>
            </Card>

            {data.customer ? (
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Customer</CardTitle>
                </CardHeader>
                <CardContent>
                  <pre className="text-xs bg-muted p-4 rounded-md overflow-auto">
                    {JSON.stringify(data.customer, null, 2)}
                  </pre>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="pt-6">
                  <p className="text-muted-foreground">
                    No Stripe customer found for {data.target_email}
                  </p>
                </CardContent>
              </Card>
            )}

            {data.subscriptions?.length > 0 ? (
              <div className="space-y-4">
                <h2 className="font-display text-lg font-semibold">
                  Subscriptions ({data.subscriptions.length})
                </h2>
                {data.subscriptions.map((s: any) => (
                  <Card key={s.id}>
                    <CardHeader>
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <CardTitle className="text-base font-mono">{s.id}</CardTitle>
                        <div className="flex gap-2 flex-wrap">
                          <Badge
                            variant={s.status === "active" || s.status === "trialing" ? "default" : "secondary"}
                          >
                            {s.status}
                          </Badge>
                          {s.is_trialing && <Badge variant="outline">TRIAL</Badge>}
                          <Badge variant="outline" className="font-mono text-[10px]">
                            period_end: {s.period_end_source}
                          </Badge>
                          {s.cancel_at_period_end && (
                            <Badge variant="destructive">cancels at period end</Badge>
                          )}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
                        <span className="text-muted-foreground">Trial end:</span>
                        <span className="font-mono">
                          {s.trial_end_iso || "—"}
                          {s.trial_days_remaining != null && (
                            <span className="text-muted-foreground ml-2">
                              ({s.trial_days_remaining}d left)
                            </span>
                          )}
                        </span>
                        <span className="text-muted-foreground">Period start:</span>
                        <span className="font-mono">{s.current_period_start_iso || "—"}</span>
                        <span className="text-muted-foreground">Period end:</span>
                        <span className="font-mono">{s.current_period_end_iso || "—"}</span>
                        <span className="text-muted-foreground">Created:</span>
                        <span className="font-mono">{s.created_iso}</span>
                      </div>

                      {/* Trial Flow Inputs — exact fields the app reads */}
                      <div className="rounded-md border border-primary/30 bg-primary/5 p-4 space-y-3">
                        <div className="flex items-center justify-between">
                          <h4 className="text-sm font-semibold">Trial Flow Inputs</h4>
                          <span className="text-[10px] text-muted-foreground font-mono">
                            check-subscription
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Exact Stripe fields the app reads to derive{" "}
                          <code className="font-mono">is_trial</code>,{" "}
                          <code className="font-mono">trial_end</code>, and{" "}
                          <code className="font-mono">subscription_end</code>.
                        </p>
                        <div className="overflow-x-auto">
                          <table className="w-full text-xs">
                            <thead>
                              <tr className="text-left text-muted-foreground border-b border-border/50">
                                <th className="py-1 pr-3 font-medium">App field</th>
                                <th className="py-1 pr-3 font-medium">Stripe source</th>
                                <th className="py-1 pr-3 font-medium">Raw value</th>
                                <th className="py-1 font-medium">Derived</th>
                              </tr>
                            </thead>
                            <tbody className="font-mono">
                              <tr className="border-b border-border/30">
                                <td className="py-1.5 pr-3">is_trial</td>
                                <td className="py-1.5 pr-3 text-muted-foreground">subscription.status === "trialing"</td>
                                <td className="py-1.5 pr-3">{String(s.status)}</td>
                                <td className="py-1.5">
                                  <Badge variant={s.is_trialing ? "default" : "secondary"} className="text-[10px]">
                                    {String(s.is_trialing)}
                                  </Badge>
                                </td>
                              </tr>
                              <tr className="border-b border-border/30">
                                <td className="py-1.5 pr-3">trial_end</td>
                                <td className="py-1.5 pr-3 text-muted-foreground">subscription.trial_end</td>
                                <td className="py-1.5 pr-3">{s.trial_end ?? "null"}</td>
                                <td className="py-1.5">{s.trial_end_iso || "—"}</td>
                              </tr>
                              <tr className="border-b border-border/30">
                                <td className="py-1.5 pr-3">trial_start</td>
                                <td className="py-1.5 pr-3 text-muted-foreground">subscription.trial_start</td>
                                <td className="py-1.5 pr-3">{s.trial_start ?? "null"}</td>
                                <td className="py-1.5">{s.trial_start_iso || "—"}</td>
                              </tr>
                              <tr className="border-b border-border/30">
                                <td className="py-1.5 pr-3">subscription_end</td>
                                <td className="py-1.5 pr-3 text-muted-foreground">
                                  items[0].current_period_end
                                  <br />
                                  <span className="text-[10px]">↳ fallback: subscription.current_period_end</span>
                                </td>
                                <td className="py-1.5 pr-3">{s.current_period_end_resolved ?? "null"}</td>
                                <td className="py-1.5">
                                  <div>{s.current_period_end_iso || "—"}</div>
                                  <Badge
                                    variant={s.period_end_source === "missing" ? "destructive" : "outline"}
                                    className="mt-1 text-[10px]"
                                  >
                                    src: {s.period_end_source}
                                  </Badge>
                                </td>
                              </tr>
                              <tr className="border-b border-border/30">
                                <td className="py-1.5 pr-3">cancel_at_period_end</td>
                                <td className="py-1.5 pr-3 text-muted-foreground">subscription.cancel_at_period_end</td>
                                <td className="py-1.5 pr-3">{String(s.cancel_at_period_end)}</td>
                                <td className="py-1.5">—</td>
                              </tr>
                              <tr>
                                <td className="py-1.5 pr-3">plan</td>
                                <td className="py-1.5 pr-3 text-muted-foreground">items[0].price.product → PRODUCT_IDS map</td>
                                <td className="py-1.5 pr-3">{String(s.items?.[0]?.product_id ?? "—")}</td>
                                <td className="py-1.5">{s.items?.[0]?.price_id ?? "—"}</td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                        {s.period_end_source === "missing" && (
                          <p className="text-xs text-destructive">
                            ⚠ No <code className="font-mono">current_period_end</code> on subscription or items —
                            <code className="font-mono"> subscription_end</code> will be null and date formatting may fail.
                          </p>
                        )}
                      </div>

                      <details className="text-xs">
                        <summary className="cursor-pointer text-muted-foreground hover:text-foreground">
                          Raw subscription JSON
                        </summary>
                        <pre className="mt-2 bg-muted p-4 rounded-md overflow-auto">
                          {JSON.stringify(s, null, 2)}
                        </pre>
                      </details>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              data.customer && (
                <Card>
                  <CardContent className="pt-6">
                    <p className="text-muted-foreground">
                      Customer has no subscriptions yet.
                    </p>
                  </CardContent>
                </Card>
              )
            )}
          </>
        )}
      </div>
    </div>
  );
}
