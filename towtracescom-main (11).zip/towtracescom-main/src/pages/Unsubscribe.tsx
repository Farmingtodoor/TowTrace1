import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Mail, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';

type Status = 'loading' | 'valid' | 'already' | 'invalid' | 'success' | 'error';

export default function Unsubscribe() {
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  const [status, setStatus] = useState<Status>('loading');
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    if (!token) {
      setStatus('invalid');
      return;
    }

    const validate = async () => {
      try {
        const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
        const anonKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
        const res = await fetch(
          `${supabaseUrl}/functions/v1/handle-email-unsubscribe?token=${token}`,
          { headers: { apikey: anonKey } }
        );
        const data = await res.json();
        if (!res.ok) {
          setStatus('invalid');
        } else if (data.valid === false && data.reason === 'already_unsubscribed') {
          setStatus('already');
        } else if (data.valid) {
          setStatus('valid');
        } else {
          setStatus('invalid');
        }
      } catch {
        setStatus('invalid');
      }
    };
    validate();
  }, [token]);

  const handleUnsubscribe = async () => {
    if (!token) return;
    setProcessing(true);
    try {
      const { data, error } = await supabase.functions.invoke('handle-email-unsubscribe', {
        body: { token },
      });
      if (error) throw error;
      if (data?.success) {
        setStatus('success');
      } else if (data?.reason === 'already_unsubscribed') {
        setStatus('already');
      } else {
        setStatus('error');
      }
    } catch {
      setStatus('error');
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <Card className="w-full max-w-md">
        <CardContent className="pt-8 pb-8 text-center space-y-4">
          {status === 'loading' && (
            <>
              <Loader2 className="w-10 h-10 text-muted-foreground animate-spin mx-auto" />
              <p className="text-muted-foreground">Validating your request...</p>
            </>
          )}

          {status === 'valid' && (
            <>
              <Mail className="w-10 h-10 text-accent mx-auto" />
              <h1 className="text-xl font-semibold">Unsubscribe from Emails</h1>
              <p className="text-sm text-muted-foreground">
                You'll no longer receive app emails from TowTrace. Authentication emails (like password resets) are not affected.
              </p>
              <Button onClick={handleUnsubscribe} disabled={processing} className="w-full">
                {processing ? 'Processing...' : 'Confirm Unsubscribe'}
              </Button>
            </>
          )}

          {status === 'success' && (
            <>
              <CheckCircle className="w-10 h-10 text-success mx-auto" />
              <h1 className="text-xl font-semibold">You've been unsubscribed</h1>
              <p className="text-sm text-muted-foreground">
                You won't receive any more app emails from TowTrace.
              </p>
            </>
          )}

          {status === 'already' && (
            <>
              <CheckCircle className="w-10 h-10 text-muted-foreground mx-auto" />
              <h1 className="text-xl font-semibold">Already Unsubscribed</h1>
              <p className="text-sm text-muted-foreground">
                You're already unsubscribed from TowTrace app emails.
              </p>
            </>
          )}

          {status === 'invalid' && (
            <>
              <AlertCircle className="w-10 h-10 text-destructive mx-auto" />
              <h1 className="text-xl font-semibold">Invalid Link</h1>
              <p className="text-sm text-muted-foreground">
                This unsubscribe link is invalid or has expired. Please contact support if you need assistance.
              </p>
            </>
          )}

          {status === 'error' && (
            <>
              <AlertCircle className="w-10 h-10 text-destructive mx-auto" />
              <h1 className="text-xl font-semibold">Something Went Wrong</h1>
              <p className="text-sm text-muted-foreground">
                We couldn't process your request. Please try again later.
              </p>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
