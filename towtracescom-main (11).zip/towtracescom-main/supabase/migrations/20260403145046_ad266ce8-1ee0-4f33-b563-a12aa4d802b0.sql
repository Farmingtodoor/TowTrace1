
-- Create condition_reports table
CREATE TABLE public.condition_reports (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tow_record_id UUID NOT NULL REFERENCES public.tow_records(id) ON DELETE CASCADE,
  tow_yard_id UUID NOT NULL REFERENCES public.tow_yards(id) ON DELETE CASCADE,
  driver_user_id UUID NOT NULL,
  checklist JSONB NOT NULL DEFAULT '[]'::jsonb,
  overall_notes TEXT,
  photos JSONB NOT NULL DEFAULT '[]'::jsonb,
  severity TEXT NOT NULL DEFAULT 'none' CHECK (severity IN ('none', 'minor', 'moderate', 'severe')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.condition_reports ENABLE ROW LEVEL SECURITY;

-- Operators can view condition reports for their yards
CREATE POLICY "Operators can view condition reports"
  ON public.condition_reports FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.tow_yard_operators tyo
      WHERE tyo.tow_yard_id = condition_reports.tow_yard_id
        AND tyo.operator_user_id = auth.uid()
    )
  );

-- Drivers can insert condition reports
CREATE POLICY "Drivers can insert condition reports"
  ON public.condition_reports FOR INSERT TO authenticated
  WITH CHECK (
    driver_user_id = auth.uid()
    AND EXISTS (
      SELECT 1 FROM public.tow_yard_operators tyo
      WHERE tyo.tow_yard_id = condition_reports.tow_yard_id
        AND tyo.operator_user_id = auth.uid()
    )
  );

-- Drivers can update their own condition reports
CREATE POLICY "Drivers can update own condition reports"
  ON public.condition_reports FOR UPDATE TO authenticated
  USING (driver_user_id = auth.uid());

-- Admins can manage all condition reports
CREATE POLICY "Admins can manage all condition reports"
  ON public.condition_reports FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::app_role));

-- Updated_at trigger
CREATE TRIGGER update_condition_reports_updated_at
  BEFORE UPDATE ON public.condition_reports
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
