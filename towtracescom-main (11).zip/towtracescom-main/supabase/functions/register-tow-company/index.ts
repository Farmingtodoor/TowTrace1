import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { checkRateLimit, getRateLimitIdentifier, rateLimitExceededResponse } from "../_shared/rate-limit.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface RegisterCompanyRequest {
  userId: string
  companyName: string
  address: string
  city: string
  stateProvince: string
  postalCode: string
  country: string
  phone: string
  email: string
  paymentMethods: string[]
  allowsInAppPayment: boolean
}

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!

    // Create admin client with service role to bypass RLS
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey)

    // Try to authenticate via JWT first; fall back to userId in body for unconfirmed signups
    let authenticatedUserId: string | null = null;

    const authHeader = req.headers.get('Authorization')
    if (authHeader) {
      const token = authHeader.replace('Bearer ', '')
      // Skip if the token is just the anon key (no real user session)
      const anonKey = Deno.env.get('SUPABASE_ANON_KEY') || ''
      if (token !== anonKey) {
        const { data: { user }, error: authError } = await supabaseAdmin.auth.getUser(token)
        if (!authError && user) {
          authenticatedUserId = user.id
        }
      }
    }

    // Parse body early so we can use userId from it
    const body: RegisterCompanyRequest = await req.json()

    // If no valid session, verify the userId from the body exists in auth.users
    if (!authenticatedUserId) {
      if (!body.userId) {
        return new Response(
          JSON.stringify({ error: 'Unauthorized' }),
          { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }
      const { data: existingUser, error: lookupError } = await supabaseAdmin.auth.admin.getUserById(body.userId)
      if (lookupError || !existingUser?.user) {
        console.error('User lookup failed:', lookupError)
        return new Response(
          JSON.stringify({ error: 'Invalid user' }),
          { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }
      authenticatedUserId = existingUser.user.id
    }

    // Rate limiting check - strict limit for company registration
    const identifier = getRateLimitIdentifier(req, authenticatedUserId);
    const { allowed, retryAfter } = checkRateLimit(identifier, "registration");
    
    if (!allowed) {
      return rateLimitExceededResponse(retryAfter, corsHeaders);
    }

    console.log('Registering company for user:', authenticatedUserId, 'Company:', body.companyName)

    // Validate required fields
    if (!body.companyName || !body.address || !body.city || !body.stateProvince || !body.country || !body.phone) {
      console.error('Missing required fields:', body)
      return new Response(
        JSON.stringify({ error: 'Missing required fields' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Create tow yard using service role (bypasses RLS)
    const { data: yard, error: yardError } = await supabaseAdmin
      .from('tow_yards')
      .insert({
        name: body.companyName,
        address: body.address,
        city: body.city,
        state_province: body.stateProvince,
        postal_code: body.postalCode,
        country: body.country,
        phone: body.phone,
        email: body.email,
        accepted_payment_methods: body.paymentMethods,
        allows_in_app_payment: body.allowsInAppPayment,
        is_approved: false,
      })
      .select()
      .single()

    if (yardError) {
      console.error('Error creating tow yard:', yardError)
      return new Response(
        JSON.stringify({ error: 'Failed to create company', details: yardError.message }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    console.log('Tow yard created:', yard.id)

    // Add user as admin operator of this yard
    const { error: operatorError } = await supabaseAdmin
      .from('tow_yard_operators')
      .insert({
        tow_yard_id: yard.id,
        operator_user_id: authenticatedUserId,
        permission_level: 'admin',
      })

    if (operatorError) {
      console.error('Error adding operator:', operatorError)
      // Rollback yard creation
      await supabaseAdmin.from('tow_yards').delete().eq('id', yard.id)
      return new Response(
        JSON.stringify({ error: 'Failed to assign operator', details: operatorError.message }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    console.log('Operator assigned to yard:', yard.id)

    // Add operator role to user
    const { error: roleError } = await supabaseAdmin
      .from('user_roles')
      .insert({
        user_id: authenticatedUserId,
        role: 'operator',
      })

    if (roleError && !roleError.message.includes('duplicate')) {
      console.error('Error adding role:', roleError)
      // Non-critical, user might already have operator role
    }

    console.log('Company registration complete for:', body.companyName)

    // Notify admin users about the new registration
    try {
      const { data: adminRoles } = await supabaseAdmin
        .from('user_roles')
        .select('user_id')
        .in('role', ['admin', 'super_admin'])

      if (adminRoles && adminRoles.length > 0) {
        const adminUserIds = adminRoles.map(r => r.user_id)
        const { data: adminProfiles } = await supabaseAdmin
          .from('profiles')
          .select('email')
          .in('user_id', adminUserIds)

        for (const profile of adminProfiles || []) {
          if (!profile.email) continue
          await supabaseAdmin.functions.invoke('send-transactional-email', {
            body: {
              templateName: 'new-company-admin-alert',
              recipientEmail: profile.email,
              idempotencyKey: `new-company-admin-${yard.id}-${profile.email}`,
              templateData: {
                companyName: body.companyName,
                city: body.city,
                stateProvince: body.stateProvince,
                country: body.country,
                contactEmail: body.email,
                phone: body.phone,
              },
            },
          })
        }
        console.log(`Admin notification sent to ${adminProfiles?.length || 0} admins`)
      }
    } catch (notifyErr) {
      console.error('Non-critical: failed to notify admins', notifyErr)
    }

    return new Response(
      JSON.stringify({ success: true, yardId: yard.id }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Unexpected error:', error)
    const errorMessage = error instanceof Error ? error.message : 'Unknown error'
    return new Response(
      JSON.stringify({ error: 'Internal server error', details: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
