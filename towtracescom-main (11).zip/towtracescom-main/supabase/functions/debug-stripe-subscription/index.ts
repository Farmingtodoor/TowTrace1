import Stripe from "npm:stripe@18.5.0";
import { createClient } from "npm:@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey) throw new Error("STRIPE_SECRET_KEY is not set");

    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("No authorization header");
    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userErr } = await supabaseClient.auth.getUser(token);
    if (userErr) throw new Error(`Auth error: ${userErr.message}`);
    const caller = userData.user;
    if (!caller?.email) throw new Error("Not authenticated");

    // Admin gate
    const { data: isAdmin } = await supabaseClient.rpc("check_user_access", {
      _user_id: caller.id,
      _required_role: "admin",
    });
    if (isAdmin !== true) {
      return new Response(JSON.stringify({ error: "Forbidden: admin only" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 403,
      });
    }

    // Optional ?email=foo to inspect another user; defaults to caller
    const url = new URL(req.url);
    const targetEmail = url.searchParams.get("email") || caller.email;

    const stripe = new Stripe(stripeKey, { apiVersion: "2025-08-27.basil" });
    const customers = await stripe.customers.list({ email: targetEmail, limit: 1 });

    if (customers.data.length === 0) {
      return new Response(JSON.stringify({
        target_email: targetEmail,
        customer: null,
        subscriptions: [],
        message: "No Stripe customer found for this email",
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      });
    }

    const customer = customers.data[0];
    const subs = await stripe.subscriptions.list({
      customer: customer.id,
      status: "all",
      limit: 10,
    });

    const now = Math.floor(Date.now() / 1000);

    const subscriptionsView = subs.data.map((s) => {
      const item = s.items.data[0];
      const itemAny = item as any;
      const subAny = s as any;
      const periodEnd = itemAny?.current_period_end ?? subAny?.current_period_end ?? null;
      const periodStart = itemAny?.current_period_start ?? subAny?.current_period_start ?? null;

      return {
        id: s.id,
        status: s.status,
        is_trialing: s.status === "trialing",
        trial_start: s.trial_start,
        trial_start_iso: s.trial_start ? new Date(s.trial_start * 1000).toISOString() : null,
        trial_end: s.trial_end,
        trial_end_iso: s.trial_end ? new Date(s.trial_end * 1000).toISOString() : null,
        trial_days_remaining: s.trial_end ? Math.max(0, Math.ceil((s.trial_end - now) / 86400)) : null,
        cancel_at_period_end: s.cancel_at_period_end,
        canceled_at: s.canceled_at,
        current_period_start_resolved: periodStart,
        current_period_start_iso: periodStart ? new Date(periodStart * 1000).toISOString() : null,
        current_period_end_resolved: periodEnd,
        current_period_end_iso: periodEnd ? new Date(periodEnd * 1000).toISOString() : null,
        period_end_source: itemAny?.current_period_end
          ? "subscription_item"
          : subAny?.current_period_end
            ? "subscription"
            : "missing",
        items: s.items.data.map((it) => {
          const itAny = it as any;
          return {
            id: it.id,
            price_id: it.price.id,
            product_id: it.price.product,
            unit_amount: it.price.unit_amount,
            currency: it.price.currency,
            recurring_interval: it.price.recurring?.interval,
            recurring_interval_count: it.price.recurring?.interval_count,
            quantity: it.quantity,
            current_period_start: itAny?.current_period_start ?? null,
            current_period_end: itAny?.current_period_end ?? null,
          };
        }),
        default_payment_method: s.default_payment_method,
        latest_invoice: s.latest_invoice,
        collection_method: s.collection_method,
        created: s.created,
        created_iso: new Date(s.created * 1000).toISOString(),
        metadata: s.metadata,
      };
    });

    return new Response(JSON.stringify({
      target_email: targetEmail,
      now_unix: now,
      now_iso: new Date(now * 1000).toISOString(),
      stripe_api_version: "2025-08-27.basil",
      customer: {
        id: customer.id,
        email: customer.email,
        name: customer.name,
        created: customer.created,
        created_iso: new Date(customer.created * 1000).toISOString(),
        delinquent: customer.delinquent,
        currency: customer.currency,
      },
      subscriptions: subscriptionsView,
    }, null, 2), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error";
    const stack = error instanceof Error ? error.stack : "";
    console.error("debug-stripe-subscription Error:", JSON.stringify({
      message,
      stack,
      timestamp: new Date().toISOString(),
    }));
    return new Response(JSON.stringify({ error: message }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
