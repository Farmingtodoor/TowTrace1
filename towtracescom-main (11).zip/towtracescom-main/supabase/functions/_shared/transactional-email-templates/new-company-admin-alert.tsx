/// <reference types="npm:@types/react@18.3.1" />

import * as React from 'npm:react@18.3.1'

import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Img,
  Button,
  Preview,
  Section,
  Text,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

const LOGO_URL = 'https://xrjrmwgshwdqjunynuiz.supabase.co/storage/v1/object/public/email-assets/logo.png'
const SITE_NAME = 'TowTrace'
const ADMIN_URL = 'https://towtraces.com/admin'

interface NewCompanyAdminAlertProps {
  companyName?: string
  city?: string
  stateProvince?: string
  country?: string
  contactEmail?: string
  phone?: string
}

const NewCompanyAdminAlertEmail = ({
  companyName,
  city,
  stateProvince,
  country,
  contactEmail,
  phone,
}: NewCompanyAdminAlertProps) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>New company registration: {companyName || 'Unknown'} — review needed</Preview>
    <Body style={main}>
      <Container style={container}>
        <Img src={LOGO_URL} alt="TowTrace" width="40" height="40" style={logo} />
        <Heading style={h1}>New Company Registration</Heading>
        <Text style={text}>
          A new tow company has registered on {SITE_NAME} and is awaiting your review.
        </Text>
        <Section style={detailsBox}>
          <Text style={detailLabel}>Company Name</Text>
          <Text style={detailValue}>{companyName || '—'}</Text>
          <Text style={detailLabel}>Location</Text>
          <Text style={detailValue}>
            {[city, stateProvince, country].filter(Boolean).join(', ') || '—'}
          </Text>
          <Text style={detailLabel}>Contact Email</Text>
          <Text style={detailValue}>{contactEmail || '—'}</Text>
          <Text style={detailLabel}>Phone</Text>
          <Text style={detailValue}>{phone || '—'}</Text>
        </Section>
        <Button style={button} href={ADMIN_URL}>
          Review in Admin Dashboard
        </Button>
        <Text style={footer}>
          This is an automated notification from {SITE_NAME}.
        </Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: NewCompanyAdminAlertEmail,
  subject: (data: Record<string, any>) =>
    `New company registration: ${data.companyName || 'Unknown'}`,
  displayName: 'New company admin alert',
  previewData: {
    companyName: 'ABC Towing',
    city: 'Houston',
    stateProvince: 'TX',
    country: 'US',
    contactEmail: 'info@abctowing.com',
    phone: '(555) 123-4567',
  },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: "'Inter', Arial, sans-serif" }
const container = { padding: '32px 28px', maxWidth: '560px', margin: '0 auto' }
const logo = { margin: '0 0 24px' }
const h1 = { fontSize: '22px', fontWeight: 'bold' as const, color: '#0f172a', margin: '0 0 20px' }
const text = { fontSize: '15px', color: '#64748b', lineHeight: '1.6', margin: '0 0 20px' }
const detailsBox = {
  backgroundColor: '#f8fafc',
  border: '1px solid #e2e8f0',
  borderRadius: '12px',
  padding: '20px 24px',
  margin: '0 0 25px',
}
const detailLabel = { fontSize: '12px', color: '#94a3b8', margin: '0 0 2px', textTransform: 'uppercase' as const, letterSpacing: '0.05em' }
const detailValue = { fontSize: '15px', color: '#0f172a', fontWeight: '500' as const, margin: '0 0 16px' }
const button = {
  backgroundColor: '#1a2744',
  color: '#f5f8fa',
  fontSize: '14px',
  fontWeight: '600' as const,
  borderRadius: '12px',
  padding: '12px 24px',
  textDecoration: 'none',
}
const footer = { fontSize: '12px', color: '#999999', margin: '30px 0 0' }
