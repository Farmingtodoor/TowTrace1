/// <reference types="npm:@types/react@18.3.1" />
import * as React from 'npm:react@18.3.1'

export interface TemplateEntry {
  component: React.ComponentType<any>
  subject: string | ((data: Record<string, any>) => string)
  to?: string
  displayName?: string
  previewData?: Record<string, any>
}

import { template as contactConfirmation } from './contact-confirmation.tsx'
import { template as companyWelcome } from './company-welcome.tsx'
import { template as newCompanyAdminAlert } from './new-company-admin-alert.tsx'

export const TEMPLATES: Record<string, TemplateEntry> = {
  'contact-confirmation': contactConfirmation,
  'company-welcome': companyWelcome,
  'new-company-admin-alert': newCompanyAdminAlert,
}
