/// <reference types="npm:@types/react@18.3.1" />

import * as React from 'npm:react@18.3.1'

import {
  Body,
  Button,
  Container,
  Head,
  Heading,
  Html,
  Img,
  Link,
  Preview,
  Text,
  Section,
} from 'npm:@react-email/components@0.0.22'
import type { TemplateEntry } from './registry.ts'

const LOGO_URL = 'https://xrjrmwgshwdqjunynuiz.supabase.co/storage/v1/object/public/email-assets/logo.png'
const SITE_NAME = 'TowTrace'
const SITE_URL = 'https://towtraces.com'

interface CompanyWelcomeProps {
  companyName?: string
}

const CompanyWelcomeEmail = ({ companyName }: CompanyWelcomeProps) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>Welcome to {SITE_NAME} — thank you for your business!</Preview>
    <Body style={main}>
      <Container style={container}>
        <Img src={LOGO_URL} alt="TowTrace" width="40" height="40" style={logo} />
        <Heading style={h1}>
          Welcome to {SITE_NAME}{companyName ? `, ${companyName}` : ''}!
        </Heading>
        <Text style={text}>
          Thank you for registering your company with {SITE_NAME}. We truly appreciate your business and look forward to working with you to streamline your tow operations.
        </Text>
        <Text style={text}>
          Your application is now under review. Once approved, you'll have access to your full operator dashboard where you can manage tow records, configure fees, add team members, and more.
        </Text>
        <Section style={highlightBox}>
          <Text style={highlightTitle}>While you wait, here's what's next:</Text>
          <Text style={highlightItem}>✓ We'll review your application shortly</Text>
          <Text style={highlightItem}>✓ You'll receive a notification once approved</Text>
          <Text style={highlightItem}>✓ Then you can start adding tow records right away</Text>
        </Section>
        <Button style={button} href={`${SITE_URL}/operator`}>
          Go to Dashboard
        </Button>
        <Text style={footer}>
          If you have any questions, don't hesitate to{' '}
          <Link href={`${SITE_URL}/contact`} style={link}>reach out to our team</Link>.
          We're here to help!
        </Text>
        <Text style={footer}>
          — The {SITE_NAME} Team
        </Text>
      </Container>
    </Body>
  </Html>
)

export const template = {
  component: CompanyWelcomeEmail,
  subject: 'Welcome to TowTrace — Thank you for your business!',
  displayName: 'Company welcome',
  previewData: { companyName: 'ABC Towing' },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: "'Inter', Arial, sans-serif" }
const container = { padding: '32px 28px', maxWidth: '560px', margin: '0 auto' }
const logo = { margin: '0 0 24px' }
const h1 = { fontSize: '22px', fontWeight: 'bold' as const, color: '#0f172a', margin: '0 0 20px' }
const text = { fontSize: '15px', color: '#64748b', lineHeight: '1.6', margin: '0 0 20px' }
const link = { color: '#1fad9f', textDecoration: 'underline' }
const button = {
  backgroundColor: '#1a2744',
  color: '#f5f8fa',
  fontSize: '14px',
  fontWeight: '600' as const,
  borderRadius: '12px',
  padding: '12px 24px',
  textDecoration: 'none',
}
const highlightBox = {
  backgroundColor: '#f0fdf9',
  border: '1px solid #d1fae5',
  borderRadius: '12px',
  padding: '20px 24px',
  margin: '0 0 25px',
}
const highlightTitle = { fontSize: '14px', fontWeight: '600' as const, color: '#0f172a', margin: '0 0 12px' }
const highlightItem = { fontSize: '14px', color: '#64748b', lineHeight: '1.6', margin: '0 0 4px' }
const footer = { fontSize: '12px', color: '#999999', margin: '30px 0 0' }
