import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");

function escapeHtml(text: string | undefined | null): string {
  if (!text) return '';
  return String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function generatePayoutEmailHtml(yardName: string, amount: number, transferId: string, date: string): string {
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif; background-color: #f4f4f5;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f4f4f5; padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
          <tr>
            <td style="background: linear-gradient(135deg, #14b8a6 0%, #0d9488 100%); padding: 32px; text-align: center;">
              <h1 style="margin: 0; color: #ffffff; font-size: 28px; font-weight: 700;">TowTrace</h1>
              <p style="margin: 8px 0 0; color: rgba(255,255,255,0.9); font-size: 14px;">Payout Deposit Confirmation</p>
            </td>
          </tr>
          <tr>
            <td style="padding: 32px;">
              <div style="text-align: center; margin-bottom: 24px;">
                <p style="margin: 0; color: #71717a; font-size: 14px;">Deposit Amount</p>
                <p style="margin: 8px 0 0; color: #14b8a6; font-size: 36px; font-weight: 700;">$${amount.toFixed(2)}</p>
              </div>
              <hr style="border: none; border-top: 1px solid #e4e4e7; margin: 0 0 24px;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td style="padding: 10px 0; color: #71717a; font-size: 14px;">Tow Yard</td>
                  <td style="padding: 10px 0; color: #18181b; font-size: 14px; text-align: right; font-weight: 500;">${escapeHtml(yardName)}</td>
                </tr>
                <tr>
                  <td style="padding: 10px 0; color: #71717a; font-size: 14px;">Date</td>
                  <td style="padding: 10px 0; color: #18181b; font-size: 14px; text-align: right; font-weight: 500;">${escapeHtml(date)}</td>
                </tr>
                <tr>
                  <td style="padding: 10px 0; color: #71717a; font-size: 14px;">Method</td>
                  <td style="padding: 10px 0; color: #18181b; font-size: 14px; text-align: right; font-weight: 500;">Stripe Connect (Auto)</td>
                </tr>
                <tr>
                  <td style="padding: 10px 0; color: #71717a; font-size: 14px;">Transfer ID</td>
                  <td style="padding: 10px 0; color: #18181b; font-size: 13px; text-align: right; font-weight: 500; font-family: monospace;">${escapeHtml(transferId)}</td>
                </tr>
              </table>
              <hr style="border: none; border-top: 1px solid #e4e4e7; margin: 24px 0;">
              <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f0fdf4; border-radius: 8px;">
                <tr>
                  <td style="padding: 16px; text-align: center;">
                    <p style="margin: 0; color: #166534; font-size: 14px; font-weight: 600;">✓ Funds deposited to your Stripe account</p>
                    <p style="margin: 6px 0 0; color: #166534; font-size: 12px;">Typically arrives in 1-2 business days</p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr>
            <td style="background-color: #fafafa; padding: 24px; text-align: center; border-top: 1px solid #e4e4e7;">
              <p style="margin: 0 0 8px; color: #71717a; font-size: 12px;">This is an automated payout notification from TowTrace.</p>
              <p style="margin: 0; color: #71717a; font-size: 12px;">View your payout history at <a href="https://towtrace.com/operator?tab=payouts" style="color: #14b8a6; text-decoration: none;">towtrace.com</a></p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

async function sendPayoutEmail(email: string, yardName: string, amount: number, transferId: string) {
  if (!RESEND_API_KEY) {
    console.warn("RESEND_API_KEY not set — skipping payout email");
    return;
  }
  const date = new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
  const html = generatePayoutEmailHtml(yardName, amount, transferId, date);
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
      body: JSON.stringify({
        from: "TowTrace <notifications@notify.towtraces.com>",
        to: [email],
        subject: `Payout of $${amount.toFixed(2)} deposited — ${yardName}`,
        html,
      }),
    });
    const result = await res.json();
    if (!res.ok) console.error("Payout email failed:", result);
    else console.log("Payout email sent to", email);
  } catch (e) {
    console.error("Error sending payout email:", e);
  }
}

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseAdmin = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
  );

  const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
  if (!stripeKey) {
    return new Response(JSON.stringify({ error: "STRIPE_SECRET_KEY not set" }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }

  const stripe = new Stripe(stripeKey, { apiVersion: "2025-08-27.basil" });

  try {
    // Find all yards with Stripe Connect that have auto-payouts enabled
    const { data: payoutSettings, error: settingsError } = await supabaseAdmin
      .from("payout_settings")
      .select("tow_yard_id, stripe_account_id, payout_frequency, minimum_payout_amount")
      .eq("stripe_connected", true)
      .eq("payout_method", "stripe")
      .not("stripe_account_id", "is", null);

    if (settingsError) throw settingsError;
    if (!payoutSettings || payoutSettings.length === 0) {
      return new Response(JSON.stringify({ message: "No auto-payout yards found", processed: 0 }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      });
    }

    let processed = 0;
    let skipped = 0;
    const results: Array<{ towYardId: string; status: string; amount?: number; error?: string }> = [];

    for (const setting of payoutSettings) {
      try {
        // Check frequency — should we process today?
        const shouldProcess = await shouldProcessToday(supabaseAdmin, setting.tow_yard_id, setting.payout_frequency || "weekly");
        if (!shouldProcess) {
          skipped++;
          results.push({ towYardId: setting.tow_yard_id, status: "skipped_frequency" });
          continue;
        }

        // Calculate available balance for this yard
        const { data: yardRecords } = await supabaseAdmin
          .from("tow_records")
          .select("id")
          .eq("tow_yard_id", setting.tow_yard_id);

        const recordIds = yardRecords?.map((r: any) => r.id) || [];
        if (recordIds.length === 0) {
          results.push({ towYardId: setting.tow_yard_id, status: "no_records" });
          continue;
        }

        // Get total succeeded payments
        const { data: payments } = await supabaseAdmin
          .from("payments")
          .select("amount, service_fee")
          .eq("status", "succeeded")
          .in("tow_record_id", recordIds);

        const grossEarnings = payments?.reduce((s: number, p: any) => s + Number(p.amount || 0), 0) || 0;
        const serviceFees = payments?.reduce((s: number, p: any) => s + Number(p.service_fee || 0), 0) || 0;

        // Get existing payout totals
        const { data: existingPayouts } = await supabaseAdmin
          .from("payout_requests")
          .select("amount, status")
          .eq("tow_yard_id", setting.tow_yard_id)
          .in("status", ["completed", "pending", "approved"]);

        const alreadyPaidOrPending = existingPayouts?.reduce((s: number, p: any) => s + Number(p.amount), 0) || 0;
        const netAvailable = grossEarnings - serviceFees - alreadyPaidOrPending;

        const minimumAmount = setting.minimum_payout_amount || 50;

        if (netAvailable < minimumAmount) {
          results.push({ towYardId: setting.tow_yard_id, status: "below_minimum", amount: netAvailable });
          continue;
        }

        // Create a Stripe transfer to the connected account
        const amountCents = Math.round(netAvailable * 100);
        const transfer = await stripe.transfers.create({
          amount: amountCents,
          currency: "usd",
          destination: setting.stripe_account_id!,
          description: `Auto-payout for tow yard - ${new Date().toISOString().split("T")[0]}`,
        });

        // Get the admin user for this yard to attribute the request
        const { data: yardAdmin } = await supabaseAdmin
          .from("tow_yard_operators")
          .select("operator_user_id")
          .eq("tow_yard_id", setting.tow_yard_id)
          .eq("permission_level", "admin")
          .limit(1)
          .single();

        // Record the payout request as completed
        await supabaseAdmin.from("payout_requests").insert({
          tow_yard_id: setting.tow_yard_id,
          requested_by_user_id: yardAdmin?.operator_user_id || "00000000-0000-0000-0000-000000000000",
          amount: netAvailable,
          payout_method: "stripe",
          status: "completed",
          completed_at: new Date().toISOString(),
          notes: `Auto-payout via Stripe Transfer ${transfer.id}`,
        });

        // Notify the yard admin (in-app + email)
        if (yardAdmin?.operator_user_id) {
          await supabaseAdmin.from("notifications").insert({
            user_id: yardAdmin.operator_user_id,
            title: "Auto-Payout Processed",
            message: `$${netAvailable.toFixed(2)} has been automatically transferred to your Stripe account.`,
            type: "payout",
            entity_type: "payout_request",
          });

          // Get yard name and operator email for the notification
          const { data: yardInfo } = await supabaseAdmin
            .from("tow_yards")
            .select("name")
            .eq("id", setting.tow_yard_id)
            .single();

          const { data: profile } = await supabaseAdmin
            .from("profiles")
            .select("email")
            .eq("user_id", yardAdmin.operator_user_id)
            .single();

          if (profile?.email) {
            await sendPayoutEmail(
              profile.email,
              yardInfo?.name || "Your Tow Yard",
              netAvailable,
              transfer.id
            );
          }
        }

        processed++;
        results.push({ towYardId: setting.tow_yard_id, status: "processed", amount: netAvailable });
        console.log(`Auto-payout: $${netAvailable.toFixed(2)} to ${setting.stripe_account_id}`);
      } catch (yardError: any) {
        const msg = yardError instanceof Error ? yardError.message : "Unknown error";
        console.error(`Error processing yard ${setting.tow_yard_id}:`, msg);
        results.push({ towYardId: setting.tow_yard_id, status: "error", error: msg });
      }
    }

    return new Response(JSON.stringify({
      message: `Processed ${processed} payouts, skipped ${skipped}`,
      processed,
      skipped,
      results,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Auto-payout error:", errorMessage);
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});

async function shouldProcessToday(
  supabase: any,
  towYardId: string,
  frequency: string
): Promise<boolean> {
  // Check the last completed auto-payout
  const { data: lastPayout } = await supabase
    .from("payout_requests")
    .select("completed_at")
    .eq("tow_yard_id", towYardId)
    .eq("payout_method", "stripe")
    .eq("status", "completed")
    .not("completed_at", "is", null)
    .order("completed_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (!lastPayout?.completed_at) return true; // Never processed — go ahead

  const lastDate = new Date(lastPayout.completed_at);
  const now = new Date();
  const daysSinceLast = Math.floor((now.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));

  switch (frequency) {
    case "daily": return daysSinceLast >= 1;
    case "weekly": return daysSinceLast >= 7;
    case "biweekly": return daysSinceLast >= 14;
    case "monthly": return daysSinceLast >= 28;
    default: return daysSinceLast >= 7;
  }
}
