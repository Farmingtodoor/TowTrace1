import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// In-memory OTP store (per cold start)
const otpStore = new Map<string, { code: string; expiresAt: number; attempts: number }>();
const rateLimitStore = new Map<string, { count: number; resetAt: number }>();

function generateOtp(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

function checkRateLimit(phone: string): boolean {
  const now = Date.now();
  const entry = rateLimitStore.get(phone);
  if (!entry || now > entry.resetAt) {
    rateLimitStore.set(phone, { count: 1, resetAt: now + 10 * 60 * 1000 });
    return true;
  }
  if (entry.count >= 3) return false;
  entry.count++;
  return true;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { phone, action, code } = await req.json();

    if (!phone) {
      return new Response(JSON.stringify({ error: "Phone number is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const GATEWAY_URL = "https://connector-gateway.lovable.dev/twilio";
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    const TWILIO_API_KEY = Deno.env.get("TWILIO_API_KEY");
    const TWILIO_PHONE_NUMBER = Deno.env.get("TWILIO_PHONE_NUMBER");

    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");
    if (!TWILIO_API_KEY) throw new Error("TWILIO_API_KEY is not configured");
    if (!TWILIO_PHONE_NUMBER) throw new Error("TWILIO_PHONE_NUMBER is not configured");

    if (action === "send") {
      if (!checkRateLimit(phone)) {
        return new Response(JSON.stringify({ error: "Too many attempts. Please try again later." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const otp = generateOtp();
      otpStore.set(phone, {
        code: otp,
        expiresAt: Date.now() + 10 * 60 * 1000,
        attempts: 0,
      });

      // Send SMS via Twilio gateway
      const response = await fetch(`${GATEWAY_URL}/Messages.json`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${LOVABLE_API_KEY}`,
          "X-Connection-Api-Key": TWILIO_API_KEY,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: new URLSearchParams({
          To: phone,
          From: TWILIO_PHONE_NUMBER,
          Body: `Your TowTrace verification code is: ${otp}. It expires in 10 minutes.`,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        console.error("Twilio error:", JSON.stringify(data));
        return new Response(JSON.stringify({ error: "Failed to send verification code. Please try again." }), {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      return new Response(JSON.stringify({ success: true, message: "Verification code sent" }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });

    } else if (action === "verify") {
      if (!code) {
        return new Response(JSON.stringify({ error: "Verification code is required" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      const stored = otpStore.get(phone);
      if (!stored) {
        return new Response(JSON.stringify({ error: "No verification code found. Please request a new one." }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      if (Date.now() > stored.expiresAt) {
        otpStore.delete(phone);
        return new Response(JSON.stringify({ error: "Verification code expired. Please request a new one." }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      stored.attempts++;
      if (stored.attempts > 5) {
        otpStore.delete(phone);
        return new Response(JSON.stringify({ error: "Too many failed attempts. Please request a new code." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      if (stored.code !== code) {
        return new Response(JSON.stringify({ error: "Invalid verification code" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // OTP verified successfully - sign in or create user via Supabase Admin
      otpStore.delete(phone);

      const supabaseAdmin = createClient(
        Deno.env.get("SUPABASE_URL")!,
        Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      );

      // Check if user with this phone exists
      const { data: existingUsers } = await supabaseAdmin.auth.admin.listUsers();
      const existingUser = existingUsers?.users?.find((u: any) => u.phone === phone);

      let userId: string;
      let accessToken: string;
      let refreshToken: string;

      if (existingUser) {
        // Generate a session for existing user
        const { data: sessionData, error: sessionError } = await supabaseAdmin.auth.admin.generateLink({
          type: "magiclink",
          email: existingUser.email || `${phone.replace(/\+/g, "")}@phone.towtrace.app`,
        });

        // Use signInWithPassword with a temp password approach won't work
        // Instead, create a custom token approach
        // For now, return user info and let frontend handle session
        userId = existingUser.id;
      } else {
        // Create new user with phone
        const tempEmail = `${phone.replace(/[^0-9]/g, "")}@phone.towtrace.app`;
        const { data: newUser, error: createError } = await supabaseAdmin.auth.admin.createUser({
          phone,
          email: tempEmail,
          phone_confirm: true,
          email_confirm: true,
          user_metadata: { phone_user: true },
        });

        if (createError) {
          console.error("Create user error:", createError);
          return new Response(JSON.stringify({ error: "Failed to create account" }), {
            status: 500,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        userId = newUser.user.id;
      }

      // Generate a magic link token to sign the user in
      const tempEmail = existingUser?.email || `${phone.replace(/[^0-9]/g, "")}@phone.towtrace.app`;
      const { data: linkData, error: linkError } = await supabaseAdmin.auth.admin.generateLink({
        type: "magiclink",
        email: tempEmail,
      });

      if (linkError || !linkData) {
        console.error("Generate link error:", linkError);
        return new Response(JSON.stringify({ error: "Failed to generate session" }), {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Extract the token from the action link
      const actionLink = linkData.properties?.action_link;
      const hashed_token = linkData.properties?.hashed_token;

      return new Response(JSON.stringify({
        success: true,
        verified: true,
        userId,
        email: tempEmail,
        hashed_token,
        action_link: actionLink,
      }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });

    } else {
      return new Response(JSON.stringify({ error: "Invalid action" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
  } catch (error) {
    console.error("Error:", error);
    return new Response(JSON.stringify({ error: error.message || "Internal server error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
