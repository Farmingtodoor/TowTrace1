import { supabase } from '@/integrations/supabase/client';

/**
 * Extract the storage path inside the claim-documents bucket from either:
 *  - a full public/sign URL produced by Supabase
 *  - a bare path already stored in the DB
 */
function extractClaimDocumentPath(urlOrPath: string): string {
  if (!urlOrPath) return urlOrPath;
  const marker = '/claim-documents/';
  const idx = urlOrPath.indexOf(marker);
  if (idx === -1) return urlOrPath.replace(/^\/+/, '');
  let path = urlOrPath.slice(idx + marker.length);
  // strip any query string from signed URLs
  const q = path.indexOf('?');
  if (q !== -1) path = path.slice(0, q);
  return path;
}

/**
 * Generate a short-lived signed URL for a claim-documents object and open it in a new tab.
 * Accepts either a stored public URL (legacy data) or a storage path.
 */
export async function openClaimDocument(urlOrPath: string, expiresInSeconds = 300): Promise<void> {
  try {
    const path = extractClaimDocumentPath(urlOrPath);
    const { data, error } = await supabase.storage
      .from('claim-documents')
      .createSignedUrl(path, expiresInSeconds);
    if (error || !data?.signedUrl) {
      console.error('Failed to create signed URL', error);
      return;
    }
    window.open(data.signedUrl, '_blank', 'noopener,noreferrer');
  } catch (err) {
    console.error('openClaimDocument error', err);
  }
}
