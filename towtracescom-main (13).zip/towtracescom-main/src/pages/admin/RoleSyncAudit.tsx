import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Loader2,
  RefreshCw,
  ShieldAlert,
  ShieldCheck,
  History,
  Users,
} from "lucide-react";

interface HistoryRow {
  id: string;
  user_id: string;
  email: string | null;
  full_name: string | null;
  role: string;
  created_at: string;
}

interface DualRoleUser {
  user_id: string;
  email: string | null;
  full_name: string | null;
  all_roles: string[];
  super_admin_at: string | null;
  admin_at: string | null;
  sync_drift_seconds: number;
  synced_by_trigger: boolean;
}

interface OrphanRow {
  user_id: string;
  email: string | null;
  full_name: string | null;
  super_admin_at: string | null;
}

interface AuditPayload {
  history: HistoryRow[];
  dual_role_users: DualRoleUser[];
  orphan_super_admins: OrphanRow[];
  total_role_rows: number;
}

const roleVariants: Record<
  string,
  "default" | "secondary" | "destructive" | "outline"
> = {
  super_admin: "destructive",
  admin: "destructive",
  operator: "default",
  reviewer: "secondary",
  analyst: "outline",
  consumer: "secondary",
};

function formatDate(s: string | null) {
  if (!s) return "—";
  return new Date(s).toLocaleString();
}

export default function RoleSyncAudit() {
  const [data, setData] = useState<AuditPayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    const { data: payload, error: err } = await supabase.functions.invoke(
      "admin-role-audit",
      { body: {} },
    );
    if (err || payload?.error) {
      setError(err?.message ?? payload?.error ?? "Failed to load audit");
      setData(null);
    } else {
      setData(payload as AuditPayload);
    }
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground p-6 md:p-10">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">
              Role Sync Audit
            </h1>
            <p className="text-muted-foreground mt-1">
              Recent role assignments and users carrying both super_admin and
              admin roles (kept in sync by the
              <code className="mx-1 px-1 rounded bg-muted text-xs">
                sync_super_admin_grants_admin
              </code>
              trigger).
            </p>
          </div>
          <Button onClick={load} variant="outline" disabled={loading}>
            <RefreshCw
              className={`w-4 h-4 mr-2 ${loading ? "animate-spin" : ""}`}
            />
            Refresh
          </Button>
        </div>

        {error && (
          <Card className="border-destructive/50">
            <CardContent className="pt-6 text-destructive">{error}</CardContent>
          </Card>
        )}

        {loading || !data ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-accent" />
          </div>
        ) : (
          <>
            <div className="grid gap-4 md:grid-cols-3">
              <SummaryCard
                icon={<Users className="w-5 h-5" />}
                label="Total role assignments"
                value={data.total_role_rows.toString()}
              />
              <SummaryCard
                icon={<ShieldCheck className="w-5 h-5 text-accent" />}
                label="Dual super_admin + admin"
                value={data.dual_role_users.length.toString()}
              />
              <SummaryCard
                icon={
                  data.orphan_super_admins.length > 0 ? (
                    <ShieldAlert className="w-5 h-5 text-destructive" />
                  ) : (
                    <ShieldCheck className="w-5 h-5 text-accent" />
                  )
                }
                label="Orphan super_admins (no admin row)"
                value={data.orphan_super_admins.length.toString()}
                highlight={data.orphan_super_admins.length > 0}
              />
            </div>

            {data.orphan_super_admins.length > 0 && (
              <Card className="border-destructive/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-destructive">
                    <ShieldAlert className="w-5 h-5" />
                    Orphan super_admins — missing matching admin role
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>User</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>super_admin granted</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {data.orphan_super_admins.map((u) => (
                        <TableRow key={u.user_id}>
                          <TableCell>{u.full_name ?? "—"}</TableCell>
                          <TableCell className="font-mono text-xs">
                            {u.email ?? u.user_id}
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {formatDate(u.super_admin_at)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5 text-accent" />
                  Users with both super_admin and admin
                </CardTitle>
              </CardHeader>
              <CardContent>
                {data.dual_role_users.length === 0 ? (
                  <p className="text-muted-foreground text-sm">
                    No users currently hold both roles.
                  </p>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>User</TableHead>
                        <TableHead>All roles</TableHead>
                        <TableHead>super_admin granted</TableHead>
                        <TableHead>admin granted</TableHead>
                        <TableHead>Sync drift</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {data.dual_role_users.map((u) => (
                        <TableRow key={u.user_id}>
                          <TableCell>
                            <div className="font-medium">
                              {u.full_name ?? "—"}
                            </div>
                            <div className="text-xs text-muted-foreground font-mono">
                              {u.email ?? u.user_id}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1">
                              {u.all_roles.map((r) => (
                                <Badge
                                  key={r}
                                  variant={roleVariants[r] ?? "outline"}
                                  className="text-xs"
                                >
                                  {r}
                                </Badge>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {formatDate(u.super_admin_at)}
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {formatDate(u.admin_at)}
                          </TableCell>
                          <TableCell>
                            {u.synced_by_trigger ? (
                              <Badge className="bg-accent text-accent-foreground">
                                auto ({u.sync_drift_seconds}s)
                              </Badge>
                            ) : (
                              <Badge variant="secondary">
                                manual ({u.sync_drift_seconds}s)
                              </Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <History className="w-5 h-5 text-accent" />
                  Role assignment history (latest 100)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>When</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Role granted</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {data.history.map((r) => (
                      <TableRow key={r.id}>
                        <TableCell className="text-sm text-muted-foreground whitespace-nowrap">
                          {formatDate(r.created_at)}
                        </TableCell>
                        <TableCell>
                          <div className="font-medium">
                            {r.full_name ?? "—"}
                          </div>
                          <div className="text-xs text-muted-foreground font-mono">
                            {r.email ?? r.user_id}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={roleVariants[r.role] ?? "outline"}
                            className="text-xs"
                          >
                            {r.role}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}

function SummaryCard({
  icon,
  label,
  value,
  highlight,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  highlight?: boolean;
}) {
  return (
    <Card className={highlight ? "border-destructive/50" : ""}>
      <CardContent className="pt-6">
        <div className="flex items-center gap-3">
          {icon}
          <div>
            <div className="text-2xl font-bold">{value}</div>
            <div className="text-xs text-muted-foreground">{label}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
