import { ReactNode } from 'react';
import { Navigate } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { useUserRoles } from '@/hooks/useUserRoles';

type RequiredRole = 'admin' | 'operator';

interface ProtectedRouteProps {
  children: ReactNode;
  requiredRole: RequiredRole;
}

export function ProtectedRoute({ children, requiredRole }: ProtectedRouteProps) {
  const { roles, loading } = useUserRoles();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-accent" />
      </div>
    );
  }

  const hasAccess =
    !!roles &&
    (requiredRole === 'admin' ? roles.isAdmin : roles.isOperator);

  if (!hasAccess) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}
