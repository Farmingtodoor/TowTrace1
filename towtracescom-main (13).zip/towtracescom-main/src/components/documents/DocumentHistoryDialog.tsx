import { useEffect, useState } from 'react';
import { Clock, CheckCircle2, XCircle, Upload, User } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { supabase } from '@/integrations/supabase/client';

interface HistoryRow {
  id: string;
  from_status: 'pending' | 'approved' | 'rejected' | null;
  to_status: 'pending' | 'approved' | 'rejected';
  rejection_reason: string | null;
  changed_by_role: string | null;
  created_at: string;
}

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  documentId: string | null;
  documentLabel?: string;
}

const STATUS_ICON: Record<string, JSX.Element> = {
  pending: <Upload className="w-4 h-4 text-warning" />,
  approved: <CheckCircle2 className="w-4 h-4 text-success" />,
  rejected: <XCircle className="w-4 h-4 text-destructive" />,
};

const STATUS_LABEL: Record<string, string> = {
  pending: 'Submitted for review',
  approved: 'Approved',
  rejected: 'Rejected',
};

export function DocumentHistoryDialog({ open, onOpenChange, documentId, documentLabel }: Props) {
  const [rows, setRows] = useState<HistoryRow[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open || !documentId) return;
    let cancelled = false;
    setLoading(true);
    (async () => {
      const { data, error } = await supabase
        .from('document_status_history')
        .select('id, from_status, to_status, rejection_reason, changed_by_role, created_at')
        .eq('document_id', documentId)
        .order('created_at', { ascending: false });
      if (cancelled) return;
      if (error) {
        console.error('Failed to load document history', error);
        setRows([]);
      } else {
        setRows((data || []) as HistoryRow[]);
      }
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [open, documentId]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-accent" />
            Document History
          </DialogTitle>
          <DialogDescription>
            {documentLabel
              ? `Review timeline for ${documentLabel}.`
              : 'Timeline of upload, approval, and rejection events for this document.'}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3 max-h-[60vh] overflow-y-auto">
          {loading ? (
            <>
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-16 w-full" />
            </>
          ) : rows.length === 0 ? (
            <p className="text-sm text-muted-foreground py-8 text-center">
              No history yet for this document.
            </p>
          ) : (
            rows.map((row) => (
              <div
                key={row.id}
                className="flex gap-3 p-3 rounded-lg bg-muted/50 border border-border"
              >
                <div className="mt-0.5">{STATUS_ICON[row.to_status]}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <p className="font-medium text-sm">
                      {STATUS_LABEL[row.to_status] || row.to_status}
                      {row.from_status && row.from_status !== row.to_status && (
                        <span className="text-muted-foreground font-normal">
                          {' '}
                          (was {row.from_status})
                        </span>
                      )}
                    </p>
                    <span className="text-xs text-muted-foreground">
                      {new Date(row.created_at).toLocaleString()}
                    </span>
                  </div>
                  {row.changed_by_role && (
                    <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                      <User className="w-3 h-3" />
                      By {row.changed_by_role}
                    </p>
                  )}
                  {row.to_status === 'rejected' && row.rejection_reason && (
                    <p className="text-sm text-destructive mt-2">
                      Reason: {row.rejection_reason}
                    </p>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
