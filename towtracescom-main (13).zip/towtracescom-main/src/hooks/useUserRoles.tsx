import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export interface UserRoles {
  userId: string;
  email: string | null;
  roles: string[];
  isAdmin: boolean;
  isSuperAdmin: boolean;
  isOperator: boolean;
  isConsumer: boolean;
}

// Module-level cache keyed by user id. Cleared on sign-out via auth state.
const cache = new Map<string, UserRoles>();
const inflight = new Map<string, Promise<UserRoles | null>>();

async function fetchRoles(userId: string): Promise<UserRoles | null> {
  if (cache.has(userId)) return cache.get(userId)!;
  if (inflight.has(userId)) return inflight.get(userId)!;

  const p = (async () => {
    const { data, error } = await supabase.functions.invoke("get-user-roles", {
      body: {},
    });
    if (error || !data || data.error) {
      console.error("useUserRoles fetch failed", error || data?.error);
      return null;
    }
    cache.set(userId, data as UserRoles);
    return data as UserRoles;
  })();

  inflight.set(userId, p);
  try {
    return await p;
  } finally {
    inflight.delete(userId);
  }
}

export function clearUserRolesCache(userId?: string) {
  if (userId) cache.delete(userId);
  else cache.clear();
}

export function useUserRoles(): {
  roles: UserRoles | null;
  loading: boolean;
} {
  const { user, loading: authLoading } = useAuth();
  const [roles, setRoles] = useState<UserRoles | null>(
    user ? (cache.get(user.id) ?? null) : null,
  );
  const [loading, setLoading] = useState(!roles);

  useEffect(() => {
    let active = true;
    if (authLoading) return;
    if (!user) {
      setRoles(null);
      setLoading(false);
      return;
    }
    setLoading(true);
    fetchRoles(user.id).then((r) => {
      if (!active) return;
      setRoles(r);
      setLoading(false);
    });
    return () => {
      active = false;
    };
  }, [user, authLoading]);

  return { roles, loading };
}
