import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import type { TowRecord } from '@/components/results/TowResult';

interface SearchResult {
  status: 'idle' | 'loading' | 'found' | 'not_found';
  record?: TowRecord;
  searchType?: 'plate' | 'vin';
  searchValue?: string;
}

function calculateDaysStored(storageStart: string | null): number {
  if (!storageStart) return 1;
  const start = new Date(storageStart);
  const now = new Date();
  const diffTime = Math.abs(now.getTime() - start.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return Math.max(1, diffDays);
}

interface PublicSearchRow {
  id: string;
  plate_number: string | null;
  vin: string | null;
  make: string | null;
  model: string | null;
  color: string | null;
  vehicle_type: string | null;
  tow_datetime: string;
  tow_reason: string | null;
  status: string;
  storage_start_datetime: string | null;
  tow_fee: number | string | null;
  daily_storage_fee: number | string | null;
  admin_fee: number | string | null;
  gate_fee: number | string | null;
  currency: string | null;
  release_requirements: string[] | null;
  tow_yard_id: string;
  yard_name: string;
  yard_address: string;
  yard_city: string;
  yard_state_province: string;
  yard_phone: string | null;
  yard_hours_json: unknown;
  yard_accepted_payment_methods: string[] | null;
}

function mapRpcRow(row: PublicSearchRow): TowRecord {
  const daysStored = calculateDaysStored(row.storage_start_datetime);
  const dailyStorage = Number(row.daily_storage_fee) || 0;
  const towFee = Number(row.tow_fee) || 0;
  const adminFee = Number(row.admin_fee) || 0;
  const gateFee = Number(row.gate_fee) || 0;
  const totalDue = towFee + (dailyStorage * daysStored) + adminFee + gateFee;

  let hoursString = 'Call for hours';
  if (row.yard_hours_json && typeof row.yard_hours_json === 'object') {
    const hoursObj = row.yard_hours_json as Record<string, string>;
    if (hoursObj.display) hoursString = hoursObj.display;
  }

  return {
    id: row.id,
    plate: row.plate_number || undefined,
    vin: row.vin || undefined,
    make: row.make || undefined,
    model: row.model || undefined,
    color: row.color || undefined,
    vehicleType: row.vehicle_type || undefined,
    towDateTime: row.tow_datetime,
    towReason: row.tow_reason || undefined,
    towFromAddress: undefined,
    towYard: {
      name: row.yard_name,
      address: row.yard_address,
      city: row.yard_city,
      state: row.yard_state_province,
      phone: row.yard_phone || '',
      hours: hoursString,
      acceptedPayments: row.yard_accepted_payment_methods || ['Cash', 'Credit Card'],
    },
    fees: {
      towFee,
      dailyStorageFee: dailyStorage,
      adminFee,
      gateFee,
      daysStored,
      totalDue,
      currency: (row.currency as 'USD' | 'CAD') || 'USD',
    },
    status: row.status as TowRecord['status'],
    releaseRequirements: row.release_requirements || [
      'Valid government-issued photo ID',
      'Vehicle registration or title',
      'Proof of insurance',
      'Payment in full',
    ],
  };
}

export function useTowSearch() {
  const [result, setResult] = useState<SearchResult>({ status: 'idle' });

  const searchByPlate = useCallback(async (plate: string, region: string, country: 'US' | 'CA') => {
    setResult({ status: 'loading' });
    try {
      const { data, error } = await supabase.rpc('public_search_tow_by_plate' as any, {
        _plate: plate,
        _region: region,
        _country: country,
      });

      if (error || !data || (Array.isArray(data) && data.length === 0)) {
        if (error) console.error('Search error:', error);
        setResult({ status: 'not_found', searchType: 'plate', searchValue: `${plate} (${region})` });
        return;
      }

      const row = (Array.isArray(data) ? data[0] : data) as PublicSearchRow;
      setResult({ status: 'found', record: mapRpcRow(row) });
    } catch (err) {
      console.error('Search error:', err);
      setResult({ status: 'not_found', searchType: 'plate', searchValue: `${plate} (${region})` });
    }
  }, []);

  const searchByVIN = useCallback(async (vin: string) => {
    setResult({ status: 'loading' });
    try {
      const { data, error } = await supabase.rpc('public_search_tow_by_vin' as any, {
        _vin: vin,
      });

      if (error || !data || (Array.isArray(data) && data.length === 0)) {
        if (error) console.error('Search error:', error);
        setResult({ status: 'not_found', searchType: 'vin', searchValue: vin });
        return;
      }

      const row = (Array.isArray(data) ? data[0] : data) as PublicSearchRow;
      setResult({ status: 'found', record: mapRpcRow(row) });
    } catch (err) {
      console.error('Search error:', err);
      setResult({ status: 'not_found', searchType: 'vin', searchValue: vin });
    }
  }, []);

  const reset = useCallback(() => {
    setResult({ status: 'idle' });
  }, []);

  return {
    ...result,
    searchByPlate,
    searchByVIN,
    reset,
    isLoading: result.status === 'loading',
  };
}
