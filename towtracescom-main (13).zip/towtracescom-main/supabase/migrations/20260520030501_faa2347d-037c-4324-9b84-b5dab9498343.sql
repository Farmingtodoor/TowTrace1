-- Enable Realtime Authorization on the messages broker so that
-- channel subscriptions for claim updates are gated per-user.
ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

-- Drop any existing policy with the same name (idempotent)
DROP POLICY IF EXISTS "Authorized claim channel reads" ON realtime.messages;
DROP POLICY IF EXISTS "Authorized claim channel writes" ON realtime.messages;

-- Allow a user to subscribe to a claim topic only if:
--   * it's their personal user-scoped topic (claims:user:<uid>), OR
--   * it's a specific claim topic (claim:<claim_id>) where they are the
--     owning consumer or an operator at the claim's yard.
CREATE POLICY "Authorized claim channel reads"
ON realtime.messages
FOR SELECT
TO authenticated
USING (
  (
    realtime.topic() = ('claims:user:' || auth.uid()::text)
  )
  OR (
    realtime.topic() LIKE 'claim:%'
    AND EXISTS (
      SELECT 1
      FROM public.claims c
      LEFT JOIN public.tow_records tr ON tr.id = c.tow_record_id
      LEFT JOIN public.tow_yard_operators tyo ON tyo.tow_yard_id = tr.tow_yard_id
       AND tyo.operator_user_id = auth.uid()
      WHERE c.id::text = split_part(realtime.topic(), ':', 2)
        AND (c.consumer_user_id = auth.uid() OR tyo.operator_user_id = auth.uid())
    )
  )
);

-- Mirror the same authorization for the broadcast write side so callers
-- can't push messages to topics they aren't authorized for.
CREATE POLICY "Authorized claim channel writes"
ON realtime.messages
FOR INSERT
TO authenticated
WITH CHECK (
  (
    realtime.topic() = ('claims:user:' || auth.uid()::text)
  )
  OR (
    realtime.topic() LIKE 'claim:%'
    AND EXISTS (
      SELECT 1
      FROM public.claims c
      LEFT JOIN public.tow_records tr ON tr.id = c.tow_record_id
      LEFT JOIN public.tow_yard_operators tyo ON tyo.tow_yard_id = tr.tow_yard_id
       AND tyo.operator_user_id = auth.uid()
      WHERE c.id::text = split_part(realtime.topic(), ':', 2)
        AND (c.consumer_user_id = auth.uid() OR tyo.operator_user_id = auth.uid())
    )
  )
);