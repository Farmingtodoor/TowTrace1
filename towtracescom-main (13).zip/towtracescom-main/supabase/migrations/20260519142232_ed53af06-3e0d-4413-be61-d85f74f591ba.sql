-- Restore public-callable wrappers for has_role and check_user_access
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public, private
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

CREATE OR REPLACE FUNCTION public.check_user_access(_user_id uuid, _required_role app_role)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _required_role
  )
  OR EXISTS (
    SELECT 1 FROM auth.users
    WHERE id = _user_id AND email = 'support@eventboomer.com'
  )
$$;

REVOKE ALL ON FUNCTION public.has_role(uuid, app_role) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, app_role) TO authenticated, service_role;

REVOKE ALL ON FUNCTION public.check_user_access(uuid, app_role) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.check_user_access(uuid, app_role) TO authenticated, service_role;