-- Revoke EXECUTE from anon/authenticated/PUBLIC on role-check RPCs.
-- Frontend now calls these via the get-user-roles / admin-list-role-grants edge functions (service role).
REVOKE ALL ON FUNCTION public.has_role(uuid, app_role) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.check_user_access(uuid, app_role) FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.admin_list_role_check_grants() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, app_role) TO service_role;
GRANT EXECUTE ON FUNCTION public.check_user_access(uuid, app_role) TO service_role;
GRANT EXECUTE ON FUNCTION public.admin_list_role_check_grants() TO service_role;