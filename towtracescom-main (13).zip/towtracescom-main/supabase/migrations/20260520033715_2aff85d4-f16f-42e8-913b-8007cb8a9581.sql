-- Extend realtime.messages RLS to also gate tow_record and tow_yard topics.
DROP POLICY IF EXISTS "Authorized tow channel reads" ON realtime.messages;
DROP POLICY IF EXISTS "Authorized tow channel writes" ON realtime.messages;

CREATE POLICY "Authorized tow channel reads"
ON realtime.messages
FOR SELECT
TO authenticated
USING (
  (
    realtime.topic() LIKE 'tow_yard:%'
    AND EXISTS (
      SELECT 1 FROM public.tow_yard_operators tyo
      WHERE tyo.operator_user_id = auth.uid()
        AND tyo.tow_yard_id::text = split_part(realtime.topic(), ':', 2)
    )
  )
  OR (
    realtime.topic() LIKE 'tow_record:%'
    AND EXISTS (
      SELECT 1
      FROM public.tow_records tr
      LEFT JOIN public.tow_yard_operators tyo
        ON tyo.tow_yard_id = tr.tow_yard_id
       AND tyo.operator_user_id = auth.uid()
      LEFT JOIN public.claims c
        ON c.tow_record_id = tr.id
       AND c.consumer_user_id = auth.uid()
      WHERE tr.id::text = split_part(realtime.topic(), ':', 2)
        AND (tyo.operator_user_id = auth.uid() OR c.consumer_user_id = auth.uid())
    )
  )
);

CREATE POLICY "Authorized tow channel writes"
ON realtime.messages
FOR INSERT
TO authenticated
WITH CHECK (
  (
    realtime.topic() LIKE 'tow_yard:%'
    AND EXISTS (
      SELECT 1 FROM public.tow_yard_operators tyo
      WHERE tyo.operator_user_id = auth.uid()
        AND tyo.tow_yard_id::text = split_part(realtime.topic(), ':', 2)
    )
  )
  OR (
    realtime.topic() LIKE 'tow_record:%'
    AND EXISTS (
      SELECT 1
      FROM public.tow_records tr
      LEFT JOIN public.tow_yard_operators tyo
        ON tyo.tow_yard_id = tr.tow_yard_id
       AND tyo.operator_user_id = auth.uid()
      LEFT JOIN public.claims c
        ON c.tow_record_id = tr.id
       AND c.consumer_user_id = auth.uid()
      WHERE tr.id::text = split_part(realtime.topic(), ':', 2)
        AND (tyo.operator_user_id = auth.uid() OR c.consumer_user_id = auth.uid())
    )
  )
);