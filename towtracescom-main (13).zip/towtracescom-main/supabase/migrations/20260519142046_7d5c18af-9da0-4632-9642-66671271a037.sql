
-- 1. Restore public vehicle search via column-grant approach
DROP FUNCTION IF EXISTS public.public_search_tow_by_plate(text, text, text);
DROP FUNCTION IF EXISTS public.public_search_tow_by_vin(text);

CREATE POLICY "Public can search tow records (limited)"
ON public.tow_records FOR SELECT TO anon
USING (status <> 'released'::tow_status);

REVOKE SELECT ON public.tow_records FROM anon;
GRANT SELECT (
  id, plate_number, vin, make, model, color, vehicle_type,
  tow_datetime, tow_reason, status, storage_start_datetime,
  tow_fee, daily_storage_fee, admin_fee, gate_fee, currency,
  release_requirements, tow_yard_id, plate_state_province, country
) ON public.tow_records TO anon;

-- 2. Drop bucket-listing policies
DROP POLICY IF EXISTS "Avatars are publicly accessible" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can view vehicle photos" ON storage.objects;

-- 3. Private schema + has_claim_on_record
CREATE SCHEMA IF NOT EXISTS private;
REVOKE ALL ON SCHEMA private FROM PUBLIC;
GRANT USAGE ON SCHEMA private TO postgres, service_role;

CREATE OR REPLACE FUNCTION private.has_claim_on_record(_user_id uuid, _record_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.claims WHERE consumer_user_id = _user_id AND tow_record_id = _record_id)
$$;
GRANT EXECUTE ON FUNCTION private.has_claim_on_record(uuid, uuid) TO authenticated;

DROP POLICY IF EXISTS "Consumers can view records with their claims" ON public.tow_records;
CREATE POLICY "Consumers can view records with their claims" ON public.tow_records
FOR SELECT TO authenticated USING (private.has_claim_on_record(auth.uid(), id));

DROP FUNCTION IF EXISTS public.has_claim_on_record(uuid, uuid);

-- 4. Lock down internal-only definer funcs
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.check_super_admin_on_signup() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.update_updated_at_column() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.check_reminder_rate_limit() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.calculate_total_due(uuid) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.is_super_admin(uuid) FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.is_tow_yard_operator(uuid, uuid) FROM PUBLIC, anon, authenticated;

-- 5. Record-lock functions → SECURITY INVOKER
ALTER FUNCTION public.acquire_record_lock(uuid, uuid, text, integer) SECURITY INVOKER;
ALTER FUNCTION public.release_record_lock(uuid, uuid, boolean) SECURITY INVOKER;
ALTER FUNCTION public.check_record_lock(uuid, integer) SECURITY INVOKER;

-- 6. Move has_role / is_tow_yard_admin / check_user_access to private
CREATE OR REPLACE FUNCTION private.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;
GRANT EXECUTE ON FUNCTION private.has_role(uuid, public.app_role) TO authenticated;

CREATE OR REPLACE FUNCTION private.is_tow_yard_admin(_user_id uuid, _tow_yard_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.tow_yard_operators tyo
    WHERE tyo.tow_yard_id = _tow_yard_id AND tyo.operator_user_id = _user_id
      AND tyo.permission_level = 'admin'::public.employee_role)
$$;
GRANT EXECUTE ON FUNCTION private.is_tow_yard_admin(uuid, uuid) TO authenticated;

-- Recreate every public policy that references public.has_role / public.is_tow_yard_admin
DROP POLICY IF EXISTS "Admins can view all audit logs" ON public.audit_logs;
CREATE POLICY "Admins can view all audit logs" ON public.audit_logs FOR SELECT TO authenticated USING (private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Admins can manage all claims" ON public.claims;
CREATE POLICY "Admins can manage all claims" ON public.claims FOR ALL TO authenticated USING (private.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Admins can manage all condition reports" ON public.condition_reports;
CREATE POLICY "Admins can manage all condition reports" ON public.condition_reports FOR ALL TO authenticated USING (private.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Admins can view contact submissions" ON public.contact_submissions;
CREATE POLICY "Admins can view contact submissions" ON public.contact_submissions FOR SELECT TO authenticated USING (private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Admins can manage all disputes" ON public.disputes;
CREATE POLICY "Admins can manage all disputes" ON public.disputes FOR ALL TO authenticated USING (private.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Admins can manage all documents" ON public.documents;
CREATE POLICY "Admins can manage all documents" ON public.documents FOR ALL TO authenticated USING (private.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Admins can manage email templates" ON public.email_templates;
CREATE POLICY "Admins can manage email templates" ON public.email_templates FOR ALL TO authenticated USING (private.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Admins can manage all fee configs" ON public.fee_configurations;
CREATE POLICY "Admins can manage all fee configs" ON public.fee_configurations FOR ALL TO authenticated USING (private.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Admins can manage all payments" ON public.payments;
CREATE POLICY "Admins can manage all payments" ON public.payments FOR ALL TO authenticated USING (private.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Admins can manage all payout requests" ON public.payout_requests;
CREATE POLICY "Admins can manage all payout requests" ON public.payout_requests FOR ALL TO authenticated USING (private.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Admins can manage all payout settings" ON public.payout_settings;
CREATE POLICY "Admins can manage all payout settings" ON public.payout_settings FOR ALL TO authenticated USING (private.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Admins can manage all profiles" ON public.profiles;
CREATE POLICY "Admins can manage all profiles" ON public.profiles FOR ALL TO authenticated USING (private.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Admins can view all profiles" ON public.profiles;
CREATE POLICY "Admins can view all profiles" ON public.profiles FOR SELECT TO authenticated USING (private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Admins can manage all tow records" ON public.tow_records;
CREATE POLICY "Admins can manage all tow records" ON public.tow_records FOR ALL TO authenticated USING (private.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Admins can manage all tow yards" ON public.tow_yards;
CREATE POLICY "Admins can manage all tow yards" ON public.tow_yards FOR ALL TO authenticated USING (private.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Admins can manage operator assignments" ON public.tow_yard_operators;
CREATE POLICY "Admins can manage operator assignments" ON public.tow_yard_operators FOR ALL TO authenticated USING (private.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Yard admins can delete operator assignments" ON public.tow_yard_operators;
CREATE POLICY "Yard admins can delete operator assignments" ON public.tow_yard_operators FOR DELETE TO authenticated
USING (private.is_tow_yard_admin(auth.uid(), tow_yard_id) OR private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Yard admins can update operator assignments" ON public.tow_yard_operators;
CREATE POLICY "Yard admins can update operator assignments" ON public.tow_yard_operators FOR UPDATE TO authenticated
USING (private.is_tow_yard_admin(auth.uid(), tow_yard_id) OR private.has_role(auth.uid(), 'admin'::public.app_role))
WITH CHECK (private.is_tow_yard_admin(auth.uid(), tow_yard_id) OR private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Admins can manage all roles" ON public.user_roles;
CREATE POLICY "Admins can manage all roles" ON public.user_roles FOR ALL TO authenticated USING (private.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));

-- storage.objects admin policy
DROP POLICY IF EXISTS "Admins can access all documents" ON storage.objects;
CREATE POLICY "Admins can access all documents" ON storage.objects FOR ALL TO authenticated
USING (bucket_id = 'claim-documents' AND private.has_role(auth.uid(), 'admin'::public.app_role))
WITH CHECK (bucket_id = 'claim-documents' AND private.has_role(auth.uid(), 'admin'::public.app_role));

-- Drop public copies
DROP FUNCTION IF EXISTS public.has_role(uuid, public.app_role);
DROP FUNCTION IF EXISTS public.is_tow_yard_admin(uuid, uuid);
DROP FUNCTION IF EXISTS public.check_user_access(uuid, text);

-- 7. Tighten the 3 permissive INSERT policies
DROP POLICY IF EXISTS "Authenticated users can insert audit logs" ON public.audit_logs;
CREATE POLICY "Authenticated users can insert audit logs" ON public.audit_logs FOR INSERT TO authenticated
WITH CHECK (auth.uid() IS NOT NULL AND length(action) <= 200 AND length(entity_type) <= 200);

DROP POLICY IF EXISTS "Anyone can submit contact form" ON public.contact_submissions;
CREATE POLICY "Anyone can submit contact form" ON public.contact_submissions FOR INSERT TO anon, authenticated
WITH CHECK (length(name) BETWEEN 1 AND 200 AND length(email) BETWEEN 3 AND 255 AND email LIKE '%@%'
  AND length(subject) BETWEEN 1 AND 300 AND length(message) BETWEEN 1 AND 5000);

DROP POLICY IF EXISTS "Rate-limited reminder creation" ON public.search_reminders;
CREATE POLICY "Rate-limited reminder creation" ON public.search_reminders FOR INSERT TO anon, authenticated
WITH CHECK (length(email) BETWEEN 3 AND 255 AND email LIKE '%@%'
  AND length(search_value) BETWEEN 1 AND 100
  AND search_type IN ('plate', 'vin') AND reminder_minutes BETWEEN 1 AND 10080);
