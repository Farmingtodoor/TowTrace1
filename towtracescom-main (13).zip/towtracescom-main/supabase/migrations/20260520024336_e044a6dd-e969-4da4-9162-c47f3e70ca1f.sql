
-- 1. audit_logs INSERT: bind actor_user_id to caller
DROP POLICY IF EXISTS "Authenticated users can insert audit logs" ON public.audit_logs;
CREATE POLICY "Authenticated users can insert audit logs"
ON public.audit_logs
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() IS NOT NULL
  AND (actor_user_id = auth.uid() OR actor_user_id IS NULL)
  AND length(action) <= 200
  AND length(entity_type) <= 200
);

-- 2. search_reminders SELECT: authenticated-only, own rows
DROP POLICY IF EXISTS "Users can view their own reminders" ON public.search_reminders;
CREATE POLICY "Users can view their own reminders"
ON public.search_reminders
FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- 3. tow_records anon SELECT: remove (anon must use public_search_tow_by_* RPCs)
DROP POLICY IF EXISTS "Public can search tow records (limited)" ON public.tow_records;

-- 4. claim-documents bucket → private
UPDATE storage.buckets SET public = false WHERE id = 'claim-documents';

-- 5. vehicle-photos upload: require folder = tow_yard_id of an operator membership
DROP POLICY IF EXISTS "Operators can upload vehicle photos" ON storage.objects;
CREATE POLICY "Operators can upload vehicle photos"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'vehicle-photos'
  AND EXISTS (
    SELECT 1 FROM public.tow_yard_operators tyo
    WHERE tyo.operator_user_id = auth.uid()
      AND (tyo.tow_yard_id)::text = (storage.foldername(name))[1]
  )
);
