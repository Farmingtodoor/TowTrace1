-- 1) Owner-scoped UPDATE so users can only modify files in their own folder
DROP POLICY IF EXISTS "Users can update their own documents" ON storage.objects;
CREATE POLICY "Users can update their own documents"
ON storage.objects
FOR UPDATE
TO authenticated
USING (
  bucket_id = 'claim-documents'
  AND auth.uid() IS NOT NULL
  AND (storage.foldername(name))[1] = (auth.uid())::text
)
WITH CHECK (
  bucket_id = 'claim-documents'
  AND auth.uid() IS NOT NULL
  AND (storage.foldername(name))[1] = (auth.uid())::text
);

-- 2) Tighter operator SELECT: path must be {consumer_user_id}/{claim_id}/...
--    AND that claim must be linked to a tow_record at the operator's yard.
DROP POLICY IF EXISTS "Operators can view claim documents" ON storage.objects;
CREATE POLICY "Operators can view claim documents"
ON storage.objects
FOR SELECT
TO authenticated
USING (
  bucket_id = 'claim-documents'
  AND EXISTS (
    SELECT 1
    FROM public.claims c
    JOIN public.tow_records tr ON tr.id = c.tow_record_id
    JOIN public.tow_yard_operators tyo ON tyo.tow_yard_id = tr.tow_yard_id
    WHERE tyo.operator_user_id = auth.uid()
      AND (storage.foldername(objects.name))[1] = (c.consumer_user_id)::text
      AND (storage.foldername(objects.name))[2] = (c.id)::text
  )
);