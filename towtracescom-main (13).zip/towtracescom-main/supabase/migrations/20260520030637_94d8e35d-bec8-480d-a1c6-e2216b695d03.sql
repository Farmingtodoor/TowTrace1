-- 1) History table
CREATE TABLE public.document_status_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id uuid NOT NULL,
  claim_id uuid NOT NULL,
  from_status doc_status,
  to_status doc_status NOT NULL,
  rejection_reason text,
  changed_by_user_id uuid,
  changed_by_role text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_doc_history_document_id ON public.document_status_history(document_id, created_at DESC);
CREATE INDEX idx_doc_history_claim_id ON public.document_status_history(claim_id, created_at DESC);

ALTER TABLE public.document_status_history ENABLE ROW LEVEL SECURITY;

-- 2) RLS: who can read
CREATE POLICY "Consumers can view history for their own documents"
ON public.document_status_history
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.claims c
    WHERE c.id = document_status_history.claim_id
      AND c.consumer_user_id = auth.uid()
  )
);

CREATE POLICY "Operators can view history for their yard"
ON public.document_status_history
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1
    FROM public.claims c
    JOIN public.tow_records tr ON tr.id = c.tow_record_id
    JOIN public.tow_yard_operators tyo ON tyo.tow_yard_id = tr.tow_yard_id
    WHERE c.id = document_status_history.claim_id
      AND tyo.operator_user_id = auth.uid()
  )
);

CREATE POLICY "Admins can view all document history"
ON public.document_status_history
FOR SELECT
TO authenticated
USING (private.has_role(auth.uid(), 'admin'::app_role));

-- No INSERT / UPDATE / DELETE policies → only SECURITY DEFINER trigger can write.

-- 3) Trigger function: log status changes
CREATE OR REPLACE FUNCTION public.log_document_status_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  actor uuid := auth.uid();
  actor_role text;
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.document_status_history (
      document_id, claim_id, from_status, to_status,
      rejection_reason, changed_by_user_id, changed_by_role
    )
    VALUES (
      NEW.id, NEW.claim_id, NULL, NEW.status,
      NEW.rejection_reason, COALESCE(NEW.reviewer_user_id, actor),
      'consumer'
    );
    RETURN NEW;
  END IF;

  IF TG_OP = 'UPDATE' AND NEW.status IS DISTINCT FROM OLD.status THEN
    -- Best-effort role label
    IF EXISTS (
      SELECT 1 FROM public.claims c
      WHERE c.id = NEW.claim_id AND c.consumer_user_id = actor
    ) THEN
      actor_role := 'consumer';
    ELSIF EXISTS (
      SELECT 1
      FROM public.claims c
      JOIN public.tow_records tr ON tr.id = c.tow_record_id
      JOIN public.tow_yard_operators tyo ON tyo.tow_yard_id = tr.tow_yard_id
      WHERE c.id = NEW.claim_id AND tyo.operator_user_id = actor
    ) THEN
      actor_role := 'operator';
    ELSE
      actor_role := 'system';
    END IF;

    INSERT INTO public.document_status_history (
      document_id, claim_id, from_status, to_status,
      rejection_reason, changed_by_user_id, changed_by_role
    )
    VALUES (
      NEW.id, NEW.claim_id, OLD.status, NEW.status,
      NEW.rejection_reason, COALESCE(NEW.reviewer_user_id, actor),
      actor_role
    );
  END IF;

  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_log_document_status_change
AFTER INSERT OR UPDATE OF status ON public.documents
FOR EACH ROW
EXECUTE FUNCTION public.log_document_status_change();