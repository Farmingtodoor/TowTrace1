-- Ensure super_admin users also hold the 'admin' role so RLS policies
-- (which check has_role(_user_id, 'admin')) grant them full admin access,
-- including reading the profiles table for the Admin → Users panel.
INSERT INTO public.user_roles (user_id, role)
SELECT ur.user_id, 'admin'::app_role
FROM public.user_roles ur
WHERE ur.role = 'super_admin'
ON CONFLICT (user_id, role) DO NOTHING;

-- Keep them in sync going forward: when a super_admin row is inserted,
-- also insert the matching admin row.
CREATE OR REPLACE FUNCTION public.sync_super_admin_grants_admin()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.role = 'super_admin' THEN
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.user_id, 'admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS sync_super_admin_grants_admin ON public.user_roles;
CREATE TRIGGER sync_super_admin_grants_admin
AFTER INSERT ON public.user_roles
FOR EACH ROW
EXECUTE FUNCTION public.sync_super_admin_grants_admin();