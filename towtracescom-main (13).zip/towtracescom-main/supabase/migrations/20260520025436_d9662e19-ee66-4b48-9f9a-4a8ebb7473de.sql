-- Remove client-writable INSERT policy
DROP POLICY IF EXISTS "Authenticated users can insert audit logs" ON public.audit_logs;

-- SECURITY DEFINER function so authenticated clients can log events
-- without being able to forge actor_user_id or arbitrary system entries.
CREATE OR REPLACE FUNCTION public.log_audit_event(
  _entity_type text,
  _entity_id uuid,
  _action text,
  _metadata jsonb DEFAULT '{}'::jsonb
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_id uuid;
  uid uuid := auth.uid();
BEGIN
  IF uid IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  IF _entity_type IS NULL OR length(_entity_type) = 0 OR length(_entity_type) > 200 THEN
    RAISE EXCEPTION 'Invalid entity_type';
  END IF;

  IF _action IS NULL OR length(_action) = 0 OR length(_action) > 200 THEN
    RAISE EXCEPTION 'Invalid action';
  END IF;

  INSERT INTO public.audit_logs (entity_type, entity_id, action, actor_user_id, metadata_json)
  VALUES (_entity_type, _entity_id, _action, uid, COALESCE(_metadata, '{}'::jsonb))
  RETURNING id INTO new_id;

  RETURN new_id;
END;
$$;

REVOKE ALL ON FUNCTION public.log_audit_event(text, uuid, text, jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.log_audit_event(text, uuid, text, jsonb) TO authenticated;