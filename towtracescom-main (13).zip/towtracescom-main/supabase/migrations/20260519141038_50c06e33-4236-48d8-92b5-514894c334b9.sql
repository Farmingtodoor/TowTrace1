
-- ============================================================
-- STORAGE: claim-documents
-- ============================================================
DROP POLICY IF EXISTS "Public can view claim documents" ON storage.objects;
DROP POLICY IF EXISTS "Authenticated users can upload claim documents" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete their own claim documents" ON storage.objects;

-- ============================================================
-- STORAGE: vehicle-photos - tighten delete
-- ============================================================
DROP POLICY IF EXISTS "Operators can delete their vehicle photos" ON storage.objects;

CREATE POLICY "Operators can delete vehicle photos for their yard"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'vehicle-photos'
  AND EXISTS (
    SELECT 1 FROM public.tow_yard_operators tyo
    WHERE tyo.operator_user_id = auth.uid()
      AND tyo.tow_yard_id::text = (storage.foldername(name))[1]
  )
);

-- ============================================================
-- tow_yard_operators: remove self-assign admin
-- ============================================================
DROP POLICY IF EXISTS "Users can self-assign as yard admin" ON public.tow_yard_operators;

-- ============================================================
-- notifications: restrict inserts
-- ============================================================
DROP POLICY IF EXISTS "Service can insert notifications" ON public.notifications;

CREATE POLICY "Service role or authenticated self can insert notifications"
ON public.notifications FOR INSERT
TO public
WITH CHECK (
  auth.role() = 'service_role'
  OR (auth.uid() IS NOT NULL AND user_id = auth.uid())
);

-- ============================================================
-- search_reminders: lock down UPDATE to service_role only
-- ============================================================
DROP POLICY IF EXISTS "Service role can update reminders" ON public.search_reminders;

CREATE POLICY "Service role can update reminders"
ON public.search_reminders FOR UPDATE
TO public
USING (auth.role() = 'service_role')
WITH CHECK (auth.role() = 'service_role');

-- ============================================================
-- tow_records: remove broad public SELECT, add minimal RPCs
-- ============================================================
DROP POLICY IF EXISTS "Public can search tow records" ON public.tow_records;

-- Public search by plate - returns only fields needed for the lookup UI
CREATE OR REPLACE FUNCTION public.public_search_tow_by_plate(
  _plate text,
  _region text,
  _country text
)
RETURNS TABLE (
  id uuid,
  plate_number text,
  vin text,
  make text,
  model text,
  color text,
  vehicle_type text,
  tow_datetime timestamptz,
  tow_reason text,
  status tow_status,
  storage_start_datetime timestamptz,
  tow_fee numeric,
  daily_storage_fee numeric,
  admin_fee numeric,
  gate_fee numeric,
  currency text,
  release_requirements text[],
  tow_yard_id uuid,
  yard_name text,
  yard_address text,
  yard_city text,
  yard_state_province text,
  yard_phone text,
  yard_hours_json jsonb,
  yard_accepted_payment_methods text[]
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    tr.id, tr.plate_number, tr.vin, tr.make, tr.model, tr.color, tr.vehicle_type,
    tr.tow_datetime, tr.tow_reason, tr.status, tr.storage_start_datetime,
    tr.tow_fee, tr.daily_storage_fee, tr.admin_fee, tr.gate_fee, tr.currency,
    tr.release_requirements, tr.tow_yard_id,
    ty.name, ty.address, ty.city, ty.state_province, ty.phone, ty.hours_json,
    ty.accepted_payment_methods
  FROM public.tow_records tr
  JOIN public.tow_yards ty ON ty.id = tr.tow_yard_id
  WHERE tr.status <> 'released'::tow_status
    AND ty.is_approved = true
    AND tr.country = _country
    AND upper(tr.plate_state_province) = upper(_region)
    AND (
      upper(replace(replace(tr.plate_number, ' ', ''), '-', '')) = upper(replace(replace(_plate, ' ', ''), '-', ''))
      OR tr.plate_number ILIKE '%' || _plate || '%'
    )
  ORDER BY tr.tow_datetime DESC
  LIMIT 1;
$$;

CREATE OR REPLACE FUNCTION public.public_search_tow_by_vin(_vin text)
RETURNS TABLE (
  id uuid,
  plate_number text,
  vin text,
  make text,
  model text,
  color text,
  vehicle_type text,
  tow_datetime timestamptz,
  tow_reason text,
  status tow_status,
  storage_start_datetime timestamptz,
  tow_fee numeric,
  daily_storage_fee numeric,
  admin_fee numeric,
  gate_fee numeric,
  currency text,
  release_requirements text[],
  tow_yard_id uuid,
  yard_name text,
  yard_address text,
  yard_city text,
  yard_state_province text,
  yard_phone text,
  yard_hours_json jsonb,
  yard_accepted_payment_methods text[]
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    tr.id, tr.plate_number, tr.vin, tr.make, tr.model, tr.color, tr.vehicle_type,
    tr.tow_datetime, tr.tow_reason, tr.status, tr.storage_start_datetime,
    tr.tow_fee, tr.daily_storage_fee, tr.admin_fee, tr.gate_fee, tr.currency,
    tr.release_requirements, tr.tow_yard_id,
    ty.name, ty.address, ty.city, ty.state_province, ty.phone, ty.hours_json,
    ty.accepted_payment_methods
  FROM public.tow_records tr
  JOIN public.tow_yards ty ON ty.id = tr.tow_yard_id
  WHERE tr.status <> 'released'::tow_status
    AND ty.is_approved = true
    AND upper(tr.vin) = upper(_vin)
  ORDER BY tr.tow_datetime DESC
  LIMIT 1;
$$;

REVOKE ALL ON FUNCTION public.public_search_tow_by_plate(text,text,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.public_search_tow_by_plate(text,text,text) TO anon, authenticated;

REVOKE ALL ON FUNCTION public.public_search_tow_by_vin(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.public_search_tow_by_vin(text) TO anon, authenticated;

-- ============================================================
-- Lock down pgmq wrapper functions
-- ============================================================
ALTER FUNCTION public.enqueue_email(text, jsonb) SET search_path = public, pgmq;
ALTER FUNCTION public.move_to_dlq(text, text, bigint, jsonb) SET search_path = public, pgmq;
ALTER FUNCTION public.read_email_batch(text, integer, integer) SET search_path = public, pgmq;
ALTER FUNCTION public.delete_email(text, bigint) SET search_path = public, pgmq;

REVOKE EXECUTE ON FUNCTION public.enqueue_email(text, jsonb) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.move_to_dlq(text, text, bigint, jsonb) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.read_email_batch(text, integer, integer) FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.delete_email(text, bigint) FROM anon, authenticated;
