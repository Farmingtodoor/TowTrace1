
CREATE OR REPLACE FUNCTION public._internal_list_role_check_grants()
RETURNS TABLE (
  function_name text,
  function_signature text,
  security_type text,
  grantee text,
  privilege_type text
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public, pg_catalog
AS $$
  SELECT
    p.proname::text AS function_name,
    pg_get_function_identity_arguments(p.oid)::text AS function_signature,
    CASE WHEN p.prosecdef THEN 'DEFINER' ELSE 'INVOKER' END AS security_type,
    COALESCE(r.rolname::text, 'PUBLIC') AS grantee,
    acl.privilege_type::text AS privilege_type
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  LEFT JOIN LATERAL aclexplode(COALESCE(p.proacl, acldefault('f', p.proowner))) AS acl ON true
  LEFT JOIN pg_roles r ON r.oid = acl.grantee
  WHERE n.nspname = 'public'
    AND p.proname = ANY(ARRAY[
      'has_role',
      'check_user_access',
      'is_super_admin',
      'is_tow_yard_operator',
      'is_tow_yard_admin',
      'admin_list_role_check_grants'
    ])
    AND acl.privilege_type = 'EXECUTE'
  ORDER BY p.proname, grantee;
$$;

REVOKE EXECUTE ON FUNCTION public._internal_list_role_check_grants() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public._internal_list_role_check_grants() TO service_role;
