// Validates that the live Supabase grants on the role-check RPCs stay
// consistent with the EXPECTED map used by src/pages/admin/RoleGrantsAudit.tsx.
//
// Run with: deno test (the test_edge_functions tool wires this up).
//
// If this test fails, either:
//   1. The DB drifted from policy → write a migration to re-lock the grants.
//   2. The policy intentionally changed → update BOTH this map AND the one
//      in src/pages/admin/RoleGrantsAudit.tsx so they stay in lockstep.

import "https://deno.land/std@0.224.0/dotenv/load.ts";
import {
  assertEquals,
  assert,
} from "https://deno.land/std@0.224.0/assert/mod.ts";
import { createClient } from "npm:@supabase/supabase-js@2.49.1";

// Keep in sync with EXPECTED in src/pages/admin/RoleGrantsAudit.tsx
const EXPECTED: Record<string, string[]> = {
  has_role: ["service_role"],
  check_user_access: ["service_role"],
  is_super_admin: ["service_role"],
  is_tow_yard_operator: ["service_role"],
  is_tow_yard_admin: ["service_role"],
  admin_list_role_check_grants: ["service_role"],
};

// Roles that are allowed to appear as owner/superuser-equivalent grantees
// and should NOT be flagged as unexpected.
const OWNER_GRANTEES = new Set(["postgres", "sandbox_exec"]);
const FORBIDDEN_GRANTEES = new Set(["PUBLIC", "anon"]);

const SUPABASE_URL =
  Deno.env.get("SUPABASE_URL") ?? Deno.env.get("VITE_SUPABASE_URL");
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

type GrantRow = {
  function_name: string;
  function_signature: string;
  security_type: string;
  grantee: string;
  privilege_type: string;
};

Deno.test(
  "EXPECTED map stays in sync with src/pages/admin/RoleGrantsAudit.tsx",
  async () => {
    const url = new URL(
      "../../../src/pages/admin/RoleGrantsAudit.tsx",
      import.meta.url,
    );
    const src = await Deno.readTextFile(url);
    const block = src.match(
      /const EXPECTED:\s*Record<string,\s*string\[\]>\s*=\s*\{([\s\S]*?)\};/,
    );
    assert(block, "Could not find EXPECTED in RoleGrantsAudit.tsx");
    const frontendKeys = Array.from(block![1].matchAll(/(\w+)\s*:\s*\[/g))
      .map((m) => m[1])
      .sort();
    assertEquals(
      frontendKeys,
      Object.keys(EXPECTED).sort(),
      "EXPECTED keys drifted — update both the frontend map and this test",
    );
    for (const key of Object.keys(EXPECTED)) {
      const m = block![1].match(new RegExp(`${key}\\s*:\\s*\\[([^\\]]*)\\]`));
      assert(m, `Could not parse frontend grants for ${key}`);
      const frontendGrants = m![1]
        .split(",")
        .map((s) => s.trim().replace(/['"]/g, ""))
        .filter(Boolean)
        .sort();
      assertEquals(
        frontendGrants,
        [...EXPECTED[key]].sort(),
        `Frontend grants for ${key} drifted from this test's EXPECTED`,
      );
    }
  },
);

Deno.test("live role-check RPC grants match EXPECTED policy", async () => {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    console.warn(
      "Skipping live check: SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY not set (expected in CI)",
    );
    return;
  }

  const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);
  const { data, error } = await admin.rpc(
    "_internal_list_role_check_grants" as never,
  );
  assertEquals(error, null, `RPC failed: ${error?.message}`);
  const rows = (data as GrantRow[] | null) ?? [];

  const failures: string[] = [];

  for (const [name, expected] of Object.entries(EXPECTED)) {
    const fnRows = rows.filter((r) => r.function_name === name);
    if (fnRows.length === 0) {
      failures.push(`✗ ${name}: function missing or has no EXECUTE grants`);
      continue;
    }

    const grantees = Array.from(new Set(fnRows.map((r) => r.grantee))).sort();
    const missing = expected.filter((g) => !grantees.includes(g));
    const unexpected = grantees.filter(
      (g) => !expected.includes(g) && !OWNER_GRANTEES.has(g),
    );
    const forbidden = grantees.filter((g) => FORBIDDEN_GRANTEES.has(g));

    if (missing.length) {
      failures.push(`✗ ${name}: missing grants → ${missing.join(", ")}`);
    }
    if (forbidden.length) {
      failures.push(
        `✗ ${name}: forbidden grantees present → ${forbidden.join(", ")}`,
      );
    }
    if (unexpected.length) {
      failures.push(`✗ ${name}: unexpected grantees → ${unexpected.join(", ")}`);
    }
  }

  assert(
    failures.length === 0,
    `Role-check RPC grants drifted from policy:\n${failures.join("\n")}`,
  );
});
