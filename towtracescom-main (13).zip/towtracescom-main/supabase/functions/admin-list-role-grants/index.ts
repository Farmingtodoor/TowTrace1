import { createClient } from "npm:@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPER_ADMIN_EMAIL = "support@eventboomer.com";

const TARGET_FUNCTIONS = [
  "has_role",
  "check_user_access",
  "is_super_admin",
  "is_tow_yard_operator",
  "is_tow_yard_admin",
  "admin_list_role_check_grants",
];

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return json({ error: "Unauthorized" }, 401);
    }

    const userClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );

    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData?.user?.id) {
      return json({ error: "Unauthorized" }, 401);
    }

    const userId = userData.user.id;
    const email = userData.user.email ?? null;

    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    // Admin check
    const { data: roleRows } = await admin
      .from("user_roles")
      .select("role")
      .eq("user_id", userId);
    const roles = (roleRows ?? []).map((r) => r.role as string);
    const isAdmin =
      roles.includes("admin") ||
      roles.includes("super_admin") ||
      email === SUPER_ADMIN_EMAIL;
    if (!isAdmin) {
      return json({ error: "Forbidden: admin access required" }, 403);
    }
    const { data, error } = await admin.rpc(
      "_internal_list_role_check_grants" as never,
    );
    if (error) {
      console.error("admin-list-role-grants rpc failed", error);
      return json({ error: error.message }, 500);
    }

    return json({ grants: data ?? [], target_functions: TARGET_FUNCTIONS });
  } catch (e) {
    console.error("admin-list-role-grants error", e);
    return json({ error: "Internal error" }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
