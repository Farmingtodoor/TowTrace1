import { createClient } from "npm:@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPER_ADMIN_EMAIL = "support@eventboomer.com";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return json({ error: "Unauthorized" }, 401);
    }

    const userClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );
    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData?.user?.id) {
      return json({ error: "Unauthorized" }, 401);
    }

    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    // Admin gate
    const { data: roleRows } = await admin
      .from("user_roles")
      .select("role")
      .eq("user_id", userData.user.id);
    const isAdmin =
      (roleRows ?? []).some(
        (r) => r.role === "admin" || r.role === "super_admin",
      ) || userData.user.email === SUPER_ADMIN_EMAIL;
    if (!isAdmin) {
      return json({ error: "Forbidden: admin access required" }, 403);
    }

    // Pull all role rows + profiles for joining email/name.
    const { data: allRoles, error: rolesErr } = await admin
      .from("user_roles")
      .select("id, user_id, role, created_at")
      .order("created_at", { ascending: false });
    if (rolesErr) {
      console.error("admin-role-audit roles fetch failed", rolesErr);
      return json({ error: rolesErr.message }, 500);
    }

    const userIds = Array.from(new Set((allRoles ?? []).map((r) => r.user_id)));
    const { data: profiles } = await admin
      .from("profiles")
      .select("user_id, email, full_name")
      .in("user_id", userIds.length ? userIds : ["00000000-0000-0000-0000-000000000000"]);

    const profileMap = new Map(
      (profiles ?? []).map((p) => [p.user_id, p]),
    );

    const history = (allRoles ?? []).slice(0, 100).map((r) => {
      const p = profileMap.get(r.user_id);
      return {
        id: r.id,
        user_id: r.user_id,
        email: p?.email ?? null,
        full_name: p?.full_name ?? null,
        role: r.role,
        created_at: r.created_at,
      };
    });

    // Group by user to find super_admin + admin overlaps.
    const byUser = new Map<string, { roles: string[]; created: Record<string, string> }>();
    for (const r of allRoles ?? []) {
      const entry = byUser.get(r.user_id) ?? { roles: [], created: {} };
      entry.roles.push(r.role);
      entry.created[r.role] = r.created_at;
      byUser.set(r.user_id, entry);
    }

    const dualRoleUsers = Array.from(byUser.entries())
      .filter(([, v]) => v.roles.includes("super_admin") && v.roles.includes("admin"))
      .map(([user_id, v]) => {
        const p = profileMap.get(user_id);
        const adminAt = v.created.admin ? new Date(v.created.admin).getTime() : 0;
        const superAt = v.created.super_admin ? new Date(v.created.super_admin).getTime() : 0;
        const drift = Math.abs(adminAt - superAt);
        return {
          user_id,
          email: p?.email ?? null,
          full_name: p?.full_name ?? null,
          all_roles: v.roles.sort(),
          super_admin_at: v.created.super_admin ?? null,
          admin_at: v.created.admin ?? null,
          // > 60s gap suggests manual/legacy state, not the auto-sync trigger.
          sync_drift_seconds: Math.round(drift / 1000),
          synced_by_trigger: drift <= 60_000,
        };
      })
      .sort((a, b) =>
        (b.super_admin_at ?? "").localeCompare(a.super_admin_at ?? ""),
      );

    // Super_admins that are MISSING the matching admin row (should be empty
    // after the sync trigger, but worth surfacing).
    const orphans = Array.from(byUser.entries())
      .filter(([, v]) => v.roles.includes("super_admin") && !v.roles.includes("admin"))
      .map(([user_id, v]) => {
        const p = profileMap.get(user_id);
        return {
          user_id,
          email: p?.email ?? null,
          full_name: p?.full_name ?? null,
          super_admin_at: v.created.super_admin ?? null,
        };
      });

    return json({
      history,
      dual_role_users: dualRoleUsers,
      orphan_super_admins: orphans,
      total_role_rows: allRoles?.length ?? 0,
    });
  } catch (e) {
    console.error("admin-role-audit error", e);
    return json({ error: "Internal error" }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
