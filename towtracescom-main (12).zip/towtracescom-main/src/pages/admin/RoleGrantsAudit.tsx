import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Loader2, ShieldAlert, ShieldCheck, RefreshCw } from "lucide-react";

type GrantRow = {
  function_name: string;
  function_signature: string;
  security_type: string;
  grantee: string;
  privilege_type: string;
};

// Expected EXECUTE grantees for each role-check RPC.
// Anything outside this set is flagged. PUBLIC / anon should never appear.
const EXPECTED: Record<string, string[]> = {
  has_role: ["authenticated", "service_role"],
  check_user_access: ["authenticated", "service_role"],
  is_super_admin: ["authenticated", "service_role"],
  is_tow_yard_operator: ["authenticated", "service_role"],
  is_tow_yard_admin: ["authenticated", "service_role"],
};

const FORBIDDEN_GRANTEES = new Set(["PUBLIC", "anon"]);

interface FunctionAudit {
  name: string;
  exists: boolean;
  securityType: string | null;
  grantees: string[];
  missing: string[];
  unexpected: string[];
  forbidden: string[];
  ok: boolean;
}

export default function RoleGrantsAudit() {
  const [rows, setRows] = useState<GrantRow[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    const { data, error } = await supabase.functions.invoke(
      "admin-list-role-grants",
      { body: {} },
    );
    if (error || data?.error) {
      setError(error?.message ?? data?.error ?? "Failed to load grants");
      setRows([]);
    } else {
      setRows((data?.grants as GrantRow[]) ?? []);
    }
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const audits: FunctionAudit[] = useMemo(() => {
    if (!rows) return [];
    return Object.entries(EXPECTED).map(([name, expected]) => {
      const fnRows = rows.filter((r) => r.function_name === name);
      const grantees = Array.from(new Set(fnRows.map((r) => r.grantee))).sort();
      const securityType = fnRows[0]?.security_type ?? null;
      const missing = expected.filter((g) => !grantees.includes(g));
      const unexpected = grantees.filter((g) => !expected.includes(g));
      const forbidden = grantees.filter((g) => FORBIDDEN_GRANTEES.has(g));
      return {
        name,
        exists: fnRows.length > 0,
        securityType,
        grantees,
        missing,
        unexpected,
        forbidden,
        ok:
          fnRows.length > 0 &&
          missing.length === 0 &&
          unexpected.length === 0 &&
          forbidden.length === 0,
      };
    });
  }, [rows]);

  const issueCount = audits.filter((a) => !a.ok).length;

  return (
    <div className="min-h-screen bg-background text-foreground p-6 md:p-10">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">
              Role-Check RPC Grants Audit
            </h1>
            <p className="text-muted-foreground mt-1">
              Shows current EXECUTE grants on role-check functions and flags any
              mismatches against the expected policy.
            </p>
          </div>
          <Button onClick={load} variant="outline" disabled={loading}>
            <RefreshCw
              className={`w-4 h-4 mr-2 ${loading ? "animate-spin" : ""}`}
            />
            Refresh
          </Button>
        </div>

        {error && (
          <Card className="border-destructive/50">
            <CardContent className="pt-6 text-destructive">{error}</CardContent>
          </Card>
        )}

        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-accent" />
          </div>
        ) : (
          <>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {issueCount === 0 ? (
                    <>
                      <ShieldCheck className="w-5 h-5 text-accent" />
                      All grants match expected policy
                    </>
                  ) : (
                    <>
                      <ShieldAlert className="w-5 h-5 text-destructive" />
                      {issueCount} function{issueCount === 1 ? "" : "s"} need
                      attention
                    </>
                  )}
                </CardTitle>
              </CardHeader>
            </Card>

            <div className="grid gap-4">
              {audits.map((a) => (
                <Card
                  key={a.name}
                  className={a.ok ? "" : "border-destructive/50"}
                >
                  <CardHeader className="pb-3">
                    <CardTitle className="flex items-center justify-between gap-2">
                      <span className="font-mono text-base">
                        public.{a.name}
                      </span>
                      {a.ok ? (
                        <Badge className="bg-accent text-accent-foreground">
                          OK
                        </Badge>
                      ) : (
                        <Badge variant="destructive">Mismatch</Badge>
                      )}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    {!a.exists ? (
                      <p className="text-destructive">
                        Function not found in the public schema.
                      </p>
                    ) : (
                      <>
                        <Row label="Security">
                          <Badge variant="outline">{a.securityType}</Badge>
                        </Row>
                        <Row label="Current grantees">
                          <div className="flex flex-wrap gap-1">
                            {a.grantees.map((g) => (
                              <Badge
                                key={g}
                                variant={
                                  FORBIDDEN_GRANTEES.has(g)
                                    ? "destructive"
                                    : EXPECTED[a.name].includes(g)
                                      ? "default"
                                      : "secondary"
                                }
                              >
                                {g}
                              </Badge>
                            ))}
                          </div>
                        </Row>
                        <Row label="Expected">
                          <div className="flex flex-wrap gap-1">
                            {EXPECTED[a.name].map((g) => (
                              <Badge key={g} variant="outline">
                                {g}
                              </Badge>
                            ))}
                          </div>
                        </Row>
                        {a.forbidden.length > 0 && (
                          <p className="text-destructive">
                            ⚠ Forbidden grantees present:{" "}
                            {a.forbidden.join(", ")}
                          </p>
                        )}
                        {a.missing.length > 0 && (
                          <p className="text-destructive">
                            ⚠ Missing required grants: {a.missing.join(", ")}
                          </p>
                        )}
                        {a.unexpected.length > 0 && (
                          <p className="text-yellow-500">
                            ⚠ Unexpected grants: {a.unexpected.join(", ")}
                          </p>
                        )}
                      </>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function Row({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-start gap-3">
      <span className="text-muted-foreground w-36 shrink-0">{label}</span>
      <div className="flex-1">{children}</div>
    </div>
  );
}
