import { createClient } from "npm:@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPER_ADMIN_EMAIL = "support@eventboomer.com";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return json({ error: "Unauthorized" }, 401);
    }

    const userClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );

    const token = authHeader.replace("Bearer ", "");
    const { data: claims, error: claimsErr } =
      await userClient.auth.getClaims(token);
    if (claimsErr || !claims?.claims?.sub) {
      return json({ error: "Unauthorized" }, 401);
    }

    const userId = claims.claims.sub as string;
    const email = (claims.claims.email as string | undefined) ?? null;

    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data: roleRows, error: rolesErr } = await admin
      .from("user_roles")
      .select("role")
      .eq("user_id", userId);

    if (rolesErr) {
      console.error("get-user-roles: roles fetch failed", rolesErr);
      return json({ error: "Failed to load roles" }, 500);
    }

    const roles = (roleRows ?? []).map((r) => r.role as string);
    const isSuperAdmin =
      roles.includes("super_admin") || email === SUPER_ADMIN_EMAIL;
    const isAdmin = roles.includes("admin") || isSuperAdmin;
    const isOperator = roles.includes("operator") || isAdmin;
    const isConsumer = roles.includes("consumer");

    return json({
      userId,
      email,
      roles,
      isAdmin,
      isSuperAdmin,
      isOperator,
      isConsumer,
    });
  } catch (e) {
    console.error("get-user-roles error", e);
    return json({ error: "Internal error" }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
