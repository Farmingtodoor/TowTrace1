import { createClient } from "npm:@supabase/supabase-js@2.49.1";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPER_ADMIN_EMAIL = "support@eventboomer.com";

const TARGET_FUNCTIONS = [
  "has_role",
  "check_user_access",
  "is_super_admin",
  "is_tow_yard_operator",
  "is_tow_yard_admin",
  "admin_list_role_check_grants",
];

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return json({ error: "Unauthorized" }, 401);
    }

    const userClient = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );

    const token = authHeader.replace("Bearer ", "");
    const { data: claims, error: claimsErr } =
      await userClient.auth.getClaims(token);
    if (claimsErr || !claims?.claims?.sub) {
      return json({ error: "Unauthorized" }, 401);
    }

    const userId = claims.claims.sub as string;
    const email = (claims.claims.email as string | undefined) ?? null;

    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    // Admin check
    const { data: roleRows } = await admin
      .from("user_roles")
      .select("role")
      .eq("user_id", userId);
    const roles = (roleRows ?? []).map((r) => r.role as string);
    const isAdmin =
      roles.includes("admin") ||
      roles.includes("super_admin") ||
      email === SUPER_ADMIN_EMAIL;
    if (!isAdmin) {
      return json({ error: "Forbidden: admin access required" }, 403);
    }

    // Query grants for target functions
    const sql = `
      SELECT
        p.proname::text AS function_name,
        pg_get_function_identity_arguments(p.oid)::text AS function_signature,
        CASE WHEN p.prosecdef THEN 'DEFINER' ELSE 'INVOKER' END AS security_type,
        COALESCE(r.rolname::text, 'PUBLIC') AS grantee,
        acl.privilege_type::text AS privilege_type
      FROM pg_proc p
      JOIN pg_namespace n ON n.oid = p.pronamespace
      LEFT JOIN LATERAL aclexplode(COALESCE(p.proacl, acldefault('f', p.proowner))) AS acl ON true
      LEFT JOIN pg_roles r ON r.oid = acl.grantee
      WHERE n.nspname = 'public'
        AND p.proname = ANY($1)
        AND acl.privilege_type = 'EXECUTE'
      ORDER BY p.proname, grantee;
    `;

    // Use pg-meta style via rpc to execute; if not available, fall back to a SECURITY DEFINER helper.
    // Simpler: use the existing admin_list_role_check_grants RPC via service role (still works since service_role bypasses our grants).
    const { data, error } = await admin.rpc(
      "admin_list_role_check_grants" as never,
    );
    if (error) {
      console.error("admin-list-role-grants rpc failed", error);
      return json({ error: error.message }, 500);
    }

    return json({ grants: data ?? [], target_functions: TARGET_FUNCTIONS });
  } catch (e) {
    console.error("admin-list-role-grants error", e);
    return json({ error: "Internal error" }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
