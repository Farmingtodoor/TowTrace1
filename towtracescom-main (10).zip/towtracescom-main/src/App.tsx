import { lazy, Suspense } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { ScrollToTop } from "@/components/ScrollToTop";
import { AuthProvider } from "@/hooks/useAuth";
import { ThemeProvider } from "@/components/ThemeProvider";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import { JackChatbot } from "@/components/chat/JackChatbot";
import { CookieConsent } from "@/components/CookieConsent";
import { BackToTop } from "@/components/BackToTop";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { PageTransition } from "@/components/PageTransition";
import { RouteLoadingFallback } from "@/components/RouteLoadingFallback";

// Vite 4.4+ fires this event when a preloaded chunk fails to fetch (stale deploy).
// A single page reload fetches the new entry point and resolves the mismatch.
window.addEventListener("vite:preloadError", (e) => {
  e.preventDefault(); // suppress the default error
  window.location.reload();
});

// Lazy-loaded pages — code-split per route
const Index = lazy(() => import("./pages/Index"));
const NotFound = lazy(() => import("./pages/NotFound"));
const MyClaims = lazy(() => import("./pages/MyClaims"));
const ClaimFlow = lazy(() => import("./pages/ClaimFlow"));
const OperatorDashboard = lazy(() => import("./pages/operator/OperatorDashboard"));
const EmployeeManagement = lazy(() => import("./pages/operator/EmployeeManagement"));
const DocumentReview = lazy(() => import("./pages/operator/DocumentReview"));
const DisputeResolution = lazy(() => import("./pages/operator/DisputeResolution"));
const AdminDashboard = lazy(() => import("./pages/admin/AdminDashboard"));
const CompanySignup = lazy(() => import("./pages/signup/CompanySignup"));
const ResetPassword = lazy(() => import("./pages/ResetPassword"));
const About = lazy(() => import("./pages/About"));
const AccountSettings = lazy(() => import("./pages/AccountSettings"));
const PaymentHistory = lazy(() => import("./pages/PaymentHistory"));
const Terms = lazy(() => import("./pages/Terms"));
const Privacy = lazy(() => import("./pages/Privacy"));
const Join = lazy(() => import("./pages/Join"));
const CitySignup = lazy(() => import("./pages/signup/CitySignup"));
const MyDisputes = lazy(() => import("./pages/MyDisputes"));
const SetupAccount = lazy(() => import("./pages/SetupAccount"));
const FAQ = lazy(() => import("./pages/FAQ"));
const Contact = lazy(() => import("./pages/Contact"));
const Unsubscribe = lazy(() => import("./pages/Unsubscribe"));

const queryClient = new QueryClient();

function AppRoutes() {
  const location = useLocation();

  return (
    <PageTransition>
      <ErrorBoundary resetKey={location.pathname}>
        <Suspense fallback={<RouteLoadingFallback />}>
         <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/my-claims" element={<MyClaims />} />
          <Route path="/claim/:recordId" element={<ClaimFlow />} />
          <Route path="/payments" element={<PaymentHistory />} />
          <Route
            path="/operator"
            element={
              <ProtectedRoute requiredRole="operator">
                <OperatorDashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/operator/employees"
            element={
              <ProtectedRoute requiredRole="operator">
                <EmployeeManagement />
              </ProtectedRoute>
            }
          />
          <Route
            path="/operator/documents"
            element={
              <ProtectedRoute requiredRole="operator">
                <DocumentReview />
              </ProtectedRoute>
            }
          />
          <Route
            path="/operator/disputes"
            element={
              <ProtectedRoute requiredRole="operator">
                <DisputeResolution />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin"
            element={
              <ProtectedRoute requiredRole="admin">
                <AdminDashboard />
              </ProtectedRoute>
            }
          />
          <Route path="/signup/company" element={<CompanySignup />} />
          <Route path="/reset-password" element={<ResetPassword />} />
          <Route path="/about" element={<About />} />
          <Route path="/account" element={<AccountSettings />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/join" element={<Join />} />
          <Route path="/signup/city" element={<CitySignup />} />
          <Route path="/my-disputes" element={<MyDisputes />} />
          <Route path="/setup-account" element={<SetupAccount />} />
          <Route path="/faq" element={<FAQ />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/unsubscribe" element={<Unsubscribe />} />
          <Route path="*" element={<NotFound />} />
         </Routes>
        </Suspense>
      </ErrorBoundary>
    </PageTransition>
  );
}

const App = () => (
  <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
            <ScrollToTop />
            <AppRoutes />
            <JackChatbot />
            <BackToTop />
            <CookieConsent />
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  </ThemeProvider>
);

export default App;
