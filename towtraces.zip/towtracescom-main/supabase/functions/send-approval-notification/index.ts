import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface ApprovalNotificationRequest {
  towYardId: string;
  towYardName: string;
  approved: boolean;
}

// HTML escape function to prevent XSS in email templates
function escapeHtml(text: string | undefined | null): string {
  if (text === undefined || text === null) return '';
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

async function sendEmail(to: string, subject: string, html: string) {
  const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
  
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${RESEND_API_KEY}`,
    },
    body: JSON.stringify({
      from: "TowTrace <onboarding@resend.dev>",
      to: [to],
      subject,
      html,
    }),
  });

  return response.json();
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { towYardId, towYardName, approved }: ApprovalNotificationRequest = await req.json();

    // Fetch the appropriate email template from database
    const templateKey = approved ? "company_approved" : "company_rejected";
    const { data: template, error: templateError } = await supabase
      .from("email_templates")
      .select("subject, html_body")
      .eq("template_key", templateKey)
      .single();

    if (templateError) {
      console.log("Template not found, using defaults:", templateError.message);
    }

    // Get all operators for this tow yard
    const { data: operators, error: operatorError } = await supabase
      .from("tow_yard_operators")
      .select("operator_user_id")
      .eq("tow_yard_id", towYardId);

    if (operatorError) {
      console.error("Error fetching operators:", operatorError);
      throw new Error("Failed to fetch operators");
    }

    if (!operators || operators.length === 0) {
      return new Response(
        JSON.stringify({ message: "No operators found for this tow yard" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Get profiles for all operators
    const userIds = operators.map((op) => op.operator_user_id);
    const { data: profiles, error: profileError } = await supabase
      .from("profiles")
      .select("email, first_name, full_name")
      .in("user_id", userIds);

    if (profileError) {
      console.error("Error fetching profiles:", profileError);
      throw new Error("Failed to fetch profiles");
    }

    // Define dashboard URL
    const dashboardUrl = "https://towtrace.lovable.app/operator";
    
    // Escape user-controlled data
    const safeTowYardName = escapeHtml(towYardName);

    // Default templates (fallback if not in database)
    const defaultApprovedSubject = `🎉 ${safeTowYardName} Has Been Approved!`;
    const defaultApprovedHtml = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #16a34a;">Congratulations!</h1>
        <p>Great news! Your tow company <strong>${safeTowYardName}</strong> has been approved on TowTrace.</p>
        <p>You can now:</p>
        <ul>
          <li>Add and manage tow records</li>
          <li>Configure your fee structure</li>
          <li>Manage your team members</li>
          <li>Accept vehicle claims and payments</li>
        </ul>
        <p style="margin-top: 24px;">
          <a href="${dashboardUrl}" 
             style="display: inline-block; background-color: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px;">
            Go to Operator Dashboard
          </a>
        </p>
        <p style="color: #6b7280; margin-top: 24px;">Thank you for choosing TowTrace!</p>
      </div>
    `;

    const defaultRejectedSubject = `Update: ${safeTowYardName} Approval Status`;
    const defaultRejectedHtml = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1 style="color: #dc2626;">Approval Status Update</h1>
        <p>Hello,</p>
        <p>The approval status for <strong>${safeTowYardName}</strong> has been updated.</p>
        <p>If you have any questions, please contact our support team.</p>
        <p style="color: #6b7280; margin-top: 24px;">The TowTrace Team</p>
      </div>
    `;

    // Determine email content - use template if available, otherwise use defaults
    let emailSubject: string;
    let emailHtmlTemplate: string;

    if (template) {
      // Replace variables in template with escaped values
      emailSubject = template.subject.replace(/\{\{company_name\}\}/g, safeTowYardName);
      emailHtmlTemplate = template.html_body
        .replace(/\{\{company_name\}\}/g, safeTowYardName)
        .replace(/\{\{dashboard_url\}\}/g, dashboardUrl);
    } else {
      emailSubject = approved ? defaultApprovedSubject : defaultRejectedSubject;
      emailHtmlTemplate = approved ? defaultApprovedHtml : defaultRejectedHtml;
    }

    // Send emails to all operators
    let successCount = 0;
    for (const profile of profiles || []) {
      if (!profile.email) continue;

      try {
        await sendEmail(profile.email, emailSubject, emailHtmlTemplate);
        successCount++;
      } catch (emailError) {
        console.error(`Failed to send email to ${profile.email}:`, emailError);
      }
    }

    console.log(`Sent ${successCount} notification emails for ${towYardName}`);

    return new Response(
      JSON.stringify({ success: true, emailsSent: successCount }),
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  } catch (error: unknown) {
    // Comprehensive error logging
    let errorMessage = "Unknown error";
    let errorCode = "";
    let errorStack = "";
    
    if (error instanceof Error) {
      errorMessage = error.message;
      errorStack = error.stack || "";
    }
    
    // Check for Resend API specific errors
    const apiError = error as { statusCode?: number; code?: string };
    if (apiError.code) errorCode = apiError.code;
    
    console.error("send-approval-notification Error:", JSON.stringify({
      message: errorMessage,
      code: errorCode || undefined,
      stack: errorStack,
      timestamp: new Date().toISOString(),
      function: "send-approval-notification",
    }));
    
    return new Response(
      JSON.stringify({ 
        error: errorMessage,
        errorCode: errorCode || undefined,
      }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
