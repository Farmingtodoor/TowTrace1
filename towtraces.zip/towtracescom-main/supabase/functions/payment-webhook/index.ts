import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, stripe-signature, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

// Helper: notify all operators of a tow yard
async function notifyYardOperators(
  supabaseClient: ReturnType<typeof createClient>,
  towRecordId: string,
  title: string,
  message: string,
  type: string,
  entityType: string,
  entityId: string
) {
  // Get the tow yard for this record
  const { data: record } = await supabaseClient
    .from("tow_records")
    .select("tow_yard_id, make, model, plate_number")
    .eq("id", towRecordId)
    .single();

  if (!record) return;

  // Get all operators for this yard
  const { data: operators } = await supabaseClient
    .from("tow_yard_operators")
    .select("operator_user_id")
    .eq("tow_yard_id", record.tow_yard_id);

  if (!operators || operators.length === 0) return;

  const vehicleDesc = [record.make, record.model].filter(Boolean).join(" ") || record.plate_number || "Unknown vehicle";

  // Insert notifications for all operators
  const notifications = operators.map((op) => ({
    user_id: op.operator_user_id,
    title,
    message: message.replace("{vehicle}", vehicleDesc),
    type,
    entity_type: entityType,
    entity_id: entityId,
  }));

  const { error } = await supabaseClient.from("notifications").insert(notifications);
  if (error) {
    console.error("Failed to insert notifications:", error);
  }
}

async function processPayment(
  supabaseClient: ReturnType<typeof createClient>,
  claimId: string,
  towRecordId: string,
  amount: number,
  providerRef: string | null,
  receiptUrl: string | null,
  userId: string | null,
  source: string,
  serviceFee: number = 0
) {
  // Insert payment record
  const { error: paymentError } = await supabaseClient
    .from("payments")
    .insert({
      claim_id: claimId,
      tow_record_id: towRecordId,
      amount,
      service_fee: serviceFee,
      status: "succeeded",
      provider: "stripe",
      provider_ref: providerRef,
      receipt_url: receiptUrl,
      currency: "USD",
    });

  if (paymentError) {
    console.error("Failed to insert payment:", paymentError);
  }

  // Update claim status to complete
  await supabaseClient
    .from("claims")
    .update({ claim_status: "complete" })
    .eq("id", claimId);

  // Update tow record status to paid
  await supabaseClient
    .from("tow_records")
    .update({ status: "paid" })
    .eq("id", towRecordId);

  // Log the payment activity
  await supabaseClient.from("audit_logs").insert({
    entity_type: "payment",
    entity_id: claimId,
    action: "payment_completed",
    actor_user_id: userId || null,
    metadata_json: {
      amount,
      tow_record_id: towRecordId,
      confirmed_by: source,
      timestamp: new Date().toISOString(),
    },
  });

  // Notify operators
  const formattedAmount = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(amount);

  await notifyYardOperators(
    supabaseClient,
    towRecordId,
    "Payment Received",
    `${formattedAmount} payment received for {vehicle}. Vehicle is ready for release.`,
    "payment",
    "claim",
    claimId
  );

  console.log(`Successfully processed payment for claim: ${claimId} (${source})`);
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseClient = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
  );

  try {
    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
      apiVersion: "2025-08-27.basil",
    });

    const body = await req.text();
    const signature = req.headers.get("stripe-signature");

    // If there's a Stripe signature, handle as webhook
    if (signature) {
      const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET");
      
      let event: Stripe.Event;
      
      if (webhookSecret) {
        event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
      } else {
        event = JSON.parse(body);
        console.warn("STRIPE_WEBHOOK_SECRET not set - webhook signature not verified");
      }

      console.log("Stripe webhook event:", event.type);

      if (event.type === "checkout.session.completed") {
        const session = event.data.object as Stripe.Checkout.Session;
        const metadata = session.metadata || {};
        
        const claimId = metadata.claimId;
        const towRecordId = metadata.towRecordId;
        const totalDue = parseFloat(metadata.totalDue || "0");
        const serviceFee = parseFloat(metadata.serviceFee || "0");
        const userId = metadata.userId;

        if (claimId && towRecordId) {
          await processPayment(
            supabaseClient,
            claimId,
            towRecordId,
            totalDue + serviceFee,
            session.payment_intent as string,
            session.receipt_url || null,
            userId || null,
            "stripe_webhook",
            serviceFee
          );
        }
      }

      return new Response(JSON.stringify({ received: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      });
    }

    // Fallback: handle manual payment confirmation (called from client after redirect)
    const authHeader = req.headers.get("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 401,
      });
    }

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token);
    
    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 401,
      });
    }

    const payload = JSON.parse(body);
    const { action, claimId } = payload;

    if (action === "confirm_payment" && claimId) {
      // Verify the claim belongs to this user
      const { data: claim, error: claimFetchError } = await supabaseClient
        .from("claims")
        .select("id, claim_status, tow_record_id")
        .eq("id", claimId)
        .eq("consumer_user_id", user.id)
        .single();

      if (claimFetchError || !claim) {
        return new Response(JSON.stringify({ error: "Claim not found" }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 404,
        });
      }

      if (claim.claim_status === "complete") {
        return new Response(JSON.stringify({ already_complete: true }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 200,
        });
      }

      // Check if a successful payment already exists
      const { data: existingPayment } = await supabaseClient
        .from("payments")
        .select("id")
        .eq("claim_id", claimId)
        .eq("status", "succeeded")
        .limit(1);

      if (existingPayment && existingPayment.length > 0) {
        await supabaseClient.from("claims").update({ claim_status: "complete" }).eq("id", claimId);
        await supabaseClient.from("tow_records").update({ status: "paid" }).eq("id", claim.tow_record_id);

        // Still notify operators if needed
        await notifyYardOperators(
          supabaseClient,
          claim.tow_record_id,
          "Claim Completed",
          "Claim for {vehicle} has been completed and is ready for release.",
          "claim",
          "claim",
          claimId
        );

        return new Response(JSON.stringify({ updated: true }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 200,
        });
      }

      // Search for the Stripe checkout session
      const sessions = await stripe.checkout.sessions.list({ limit: 20 });
      const matchingSession = sessions.data.find(
        (s) => s.metadata?.claimId === claimId && s.payment_status === "paid"
      );

      if (matchingSession) {
        const totalDue = parseFloat(matchingSession.metadata?.totalDue || "0");
        const serviceFee = parseFloat(matchingSession.metadata?.serviceFee || "0");

        await processPayment(
          supabaseClient,
          claimId,
          claim.tow_record_id,
          totalDue + serviceFee,
          matchingSession.payment_intent as string,
          null,
          user.id,
          "client_redirect",
          serviceFee
        );

        return new Response(JSON.stringify({ updated: true }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 200,
        });
      }

      return new Response(JSON.stringify({ payment_not_found: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      });
    }

    return new Response(JSON.stringify({ error: "Invalid action" }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 400,
    });
  } catch (error: unknown) {
    let errorMessage = "Unknown error";
    if (error instanceof Error) {
      errorMessage = error.message;
    }
    
    console.error("payment-webhook Error:", errorMessage);
    
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
