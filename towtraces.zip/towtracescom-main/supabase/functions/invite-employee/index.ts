import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "https://esm.sh/resend@2.0.0";
import { checkRateLimit, getRateLimitIdentifier, rateLimitExceededResponse } from "../_shared/rate-limit.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface InviteEmployeeRequest {
  email: string;
  fullName: string;
  towYardId: string;
  towYardName: string;
  permissionLevel: string;
  inviterName: string;
}

const escapeHtml = (text: string): string => {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
};

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const resendApiKey = Deno.env.get("RESEND_API_KEY");

    if (!resendApiKey) {
      throw new Error("RESEND_API_KEY not configured");
    }

    // Verify the caller is authenticated
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("Missing authorization header");
    }

    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    // Verify caller's session
    const supabaseClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user: callerUser }, error: authError } = await supabaseClient.auth.getUser();
    if (authError || !callerUser) {
      throw new Error("Unauthorized");
    }

    // Rate limiting check
    const identifier = getRateLimitIdentifier(req, callerUser.id);
    const { allowed, retryAfter } = checkRateLimit(identifier, "invite");
    
    if (!allowed) {
      return rateLimitExceededResponse(retryAfter, corsHeaders);
    }

    const { email, fullName, towYardId, towYardName, permissionLevel, inviterName }: InviteEmployeeRequest = await req.json();

    if (!email || !towYardId || !permissionLevel) {
      throw new Error("Missing required fields: email, towYardId, permissionLevel");
    }

    // Check if caller has permission to invite (must be admin of the tow yard)
    const { data: isYardAdmin } = await supabaseAdmin.rpc("is_tow_yard_admin", {
      _user_id: callerUser.id,
      _tow_yard_id: towYardId,
    });

    const { data: isSystemAdmin } = await supabaseAdmin.rpc("has_role", {
      _user_id: callerUser.id,
      _role: "admin",
    });

    if (!isYardAdmin && !isSystemAdmin) {
      throw new Error("You don't have permission to invite employees to this tow yard");
    }

    // Check if user already exists
    const { data: existingProfile } = await supabaseAdmin
      .from("profiles")
      .select("user_id")
      .eq("email", email.toLowerCase())
      .single();

    let userId: string;
    let isNewUser = false;

    if (existingProfile) {
      // User already exists, just add them to the tow yard
      userId = existingProfile.user_id;

      // Check if already an operator for this yard
      const { data: existingOp } = await supabaseAdmin
        .from("tow_yard_operators")
        .select("id")
        .eq("tow_yard_id", towYardId)
        .eq("operator_user_id", userId)
        .single();

      if (existingOp) {
        return new Response(
          JSON.stringify({ 
            error: "This user is already an employee of this tow yard. Check the Pending Invitations section to resend their invite." 
          }),
          { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
        );
      }
    } else {
      // Create new user with invite
      isNewUser = true;
      const tempPassword = crypto.randomUUID();

      const { data: newUser, error: createError } = await supabaseAdmin.auth.admin.createUser({
        email: email.toLowerCase(),
        password: tempPassword,
        email_confirm: false,
        user_metadata: {
          full_name: fullName || email.split("@")[0],
          invited_to_yard: towYardId,
          needs_password_setup: true,
        },
      });

      if (createError) {
        throw new Error(`Failed to create user: ${createError.message}`);
      }

      userId = newUser.user.id;

      // Create profile
      await supabaseAdmin.from("profiles").insert({
        user_id: userId,
        email: email.toLowerCase(),
        full_name: fullName || null,
      });

      // Add operator role
      await supabaseAdmin.from("user_roles").insert({
        user_id: userId,
        role: "operator",
      });
    }

    // Add to tow yard operators
    const { error: operatorError } = await supabaseAdmin.from("tow_yard_operators").insert({
      tow_yard_id: towYardId,
      operator_user_id: userId,
      permission_level: permissionLevel,
    });

    if (operatorError) {
      // If this fails and we created a new user, we should clean up
      if (isNewUser) {
        await supabaseAdmin.auth.admin.deleteUser(userId);
      }
      throw new Error(`Failed to add employee: ${operatorError.message}`);
    }

    // Send invitation email
    const resend = new Resend(resendApiKey);
    const siteUrl = req.headers.get("origin") || "https://towtracescom.lovable.app";

    if (isNewUser) {
      // Generate password reset link for new users
      const { data: resetData, error: resetError } = await supabaseAdmin.auth.admin.generateLink({
        type: "recovery",
        email: email.toLowerCase(),
        options: {
          redirectTo: `${siteUrl}/setup-account`,
        },
      });

      if (resetError) {
        throw new Error(`Failed to generate invite link: ${resetError.message}`);
      }

      const inviteLink = resetData.properties.action_link;

      // TODO: Replace with your verified domain from resend.com/domains
      // Example: "TowTrace <noreply@yourdomain.com>"
      await resend.emails.send({
        from: "TowTrace <noreply@towtrace.com>",
        to: [email.toLowerCase()],
        subject: `You've been invited to join ${escapeHtml(towYardName)} on TowTrace`,
        html: `
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
          </head>
          <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background: linear-gradient(135deg, #0d9488 0%, #14b8a6 100%); padding: 30px; border-radius: 12px 12px 0 0; text-align: center;">
              <h1 style="color: white; margin: 0; font-size: 24px;">Welcome to TowTrace!</h1>
            </div>
            <div style="background: #f9fafb; padding: 30px; border-radius: 0 0 12px 12px;">
              <p style="font-size: 16px;">Hi${fullName ? ` <strong>${escapeHtml(fullName)}</strong>` : ''},</p>
              <p style="font-size: 16px;">
                <strong>${escapeHtml(inviterName)}</strong> has invited you to join 
                <strong>${escapeHtml(towYardName)}</strong> on TowTrace as an employee.
              </p>
              <p style="font-size: 16px;">Click the button below to set up your account and get started:</p>
              <div style="text-align: center; margin: 30px 0;">
                <a href="${inviteLink}" 
                   style="display: inline-block; background: #0d9488; color: white; padding: 14px 32px; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 16px;">
                  Set Up Your Account
                </a>
              </div>
              <p style="font-size: 14px; color: #6b7280;">
                This link will expire in 24 hours. If you didn't expect this invitation, you can safely ignore this email.
              </p>
              <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 24px 0;">
              <p style="font-size: 12px; color: #9ca3af; text-align: center;">
                TowTrace - Connecting Tow Companies with Vehicle Owners
              </p>
            </div>
          </body>
          </html>
        `,
      });
    } else {
      // Existing user - just notify them they've been added
      // TODO: Replace with your verified domain from resend.com/domains
      await resend.emails.send({
        from: "TowTrace <noreply@towtrace.com>",
        to: [email.toLowerCase()],
        subject: `You've been added to ${escapeHtml(towYardName)} on TowTrace`,
        html: `
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
          </head>
          <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background: linear-gradient(135deg, #0d9488 0%, #14b8a6 100%); padding: 30px; border-radius: 12px 12px 0 0; text-align: center;">
              <h1 style="color: white; margin: 0; font-size: 24px;">You've Been Added!</h1>
            </div>
            <div style="background: #f9fafb; padding: 30px; border-radius: 0 0 12px 12px;">
              <p style="font-size: 16px;">Hi,</p>
              <p style="font-size: 16px;">
                <strong>${escapeHtml(inviterName)}</strong> has added you to 
                <strong>${escapeHtml(towYardName)}</strong> on TowTrace.
              </p>
              <p style="font-size: 16px;">You can now access the operator dashboard for this tow yard.</p>
              <div style="text-align: center; margin: 30px 0;">
                <a href="${siteUrl}/operator" 
                   style="display: inline-block; background: #0d9488; color: white; padding: 14px 32px; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 16px;">
                  Go to Dashboard
                </a>
              </div>
              <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 24px 0;">
              <p style="font-size: 12px; color: #9ca3af; text-align: center;">
                TowTrace - Connecting Tow Companies with Vehicle Owners
              </p>
            </div>
          </body>
          </html>
        `,
      });
    }

    // Log the invitation event
    await supabaseAdmin.from("invitation_logs").insert({
      tow_yard_id: towYardId,
      tow_yard_name: towYardName,
      invited_email: email.toLowerCase(),
      invited_name: fullName || null,
      invited_by_user_id: callerUser.id,
      inviter_name: inviterName,
      permission_level: permissionLevel,
      event_type: "invited",
      is_new_user: isNewUser,
    });

    return new Response(
      JSON.stringify({ 
        success: true, 
        isNewUser,
        message: isNewUser 
          ? "Invitation sent! The employee will receive an email to set up their account."
          : "Employee added! They've been notified via email."
      }),
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  } catch (error: any) {
    console.error("Error in invite-employee function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
});
