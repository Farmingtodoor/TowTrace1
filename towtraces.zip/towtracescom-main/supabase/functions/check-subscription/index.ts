import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const PRODUCT_IDS: Record<string, string> = {
  "prod_U2FStgvBJguHXP": "basic",
  "prod_U2FXL660MF4P5o": "basic",
  "prod_U2FTtNmH4e7cuw": "pro",
  "prod_U2FXWxNXAl3Phl": "pro",
  "prod_U2FT7TQDeV2CP2": "city",
  "prod_U2FYagMQ6CCkYA": "city",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseClient = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
    { auth: { persistSession: false } }
  );

  try {
    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey) throw new Error("STRIPE_SECRET_KEY is not set");

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("No authorization header provided");

    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userError } = await supabaseClient.auth.getUser(token);
    if (userError) throw new Error(`Authentication error: ${userError.message}`);
    const user = userData.user;
    if (!user?.email) throw new Error("User not authenticated");

    const stripe = new Stripe(stripeKey, { apiVersion: "2025-08-27.basil" });
    const customers = await stripe.customers.list({ email: user.email, limit: 1 });

    if (customers.data.length === 0) {
      return new Response(JSON.stringify({ 
        subscribed: false,
        plan: null,
        subscription_end: null,
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      });
    }

    const customerId = customers.data[0].id;
    const subscriptions = await stripe.subscriptions.list({
      customer: customerId,
      status: "all",
      limit: 5,
    });

    // Find active or trialing subscription
    const activeSub = subscriptions.data.find(
      (s) => s.status === "active" || s.status === "trialing"
    );

    const hasActiveSub = !!activeSub;
    let plan = null;
    let subscriptionEnd = null;
    let isTrial = false;
    let trialEnd = null;

    if (hasActiveSub) {
      const subscription = activeSub;
      subscriptionEnd = new Date(subscription.current_period_end * 1000).toISOString();
      isTrial = subscription.status === "trialing";
      if (subscription.trial_end) {
        trialEnd = new Date(subscription.trial_end * 1000).toISOString();
      }
      const productId = subscription.items.data[0].price.product as string;

      // Determine plan from product ID
      plan = PRODUCT_IDS[productId] || null;
    }

    return new Response(JSON.stringify({
      subscribed: hasActiveSub,
      plan,
      subscription_end: subscriptionEnd,
      is_trial: isTrial,
      trial_end: trialEnd,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error: unknown) {
    // Comprehensive error logging
    let errorMessage = "Unknown error";
    let errorCode = "";
    let errorType = "";
    let errorStack = "";
    
    if (error instanceof Error) {
      errorMessage = error.message;
      errorStack = error.stack || "";
      
      // Check for Stripe-specific error details
      const stripeError = error as { type?: string; code?: string; statusCode?: number };
      if (stripeError.type) errorType = stripeError.type;
      if (stripeError.code) errorCode = stripeError.code;
    }
    
    console.error("check-subscription Error:", JSON.stringify({
      message: errorMessage,
      type: errorType || undefined,
      code: errorCode || undefined,
      stack: errorStack,
      timestamp: new Date().toISOString(),
      function: "check-subscription",
    }));
    
    return new Response(JSON.stringify({ 
      error: errorMessage,
      errorCode: errorCode || undefined,
      errorType: errorType || undefined,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
