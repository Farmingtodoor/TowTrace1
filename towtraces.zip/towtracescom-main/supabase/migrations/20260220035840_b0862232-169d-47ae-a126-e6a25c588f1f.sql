
-- Make the claim-documents bucket public for viewing
UPDATE storage.buckets SET public = true WHERE id = 'claim-documents';

-- Allow public read access to claim documents
CREATE POLICY "Public can view claim documents"
ON storage.objects FOR SELECT
USING (bucket_id = 'claim-documents');

-- Allow authenticated users to upload claim documents
CREATE POLICY "Authenticated users can upload claim documents"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'claim-documents' AND auth.uid() IS NOT NULL);

-- Allow authenticated users to delete their own claim documents
CREATE POLICY "Users can delete their own claim documents"
ON storage.objects FOR DELETE
USING (bucket_id = 'claim-documents' AND auth.uid() IS NOT NULL);
