
-- Step 1: Add 'driver' to employee_role enum only
ALTER TYPE public.employee_role ADD VALUE IF NOT EXISTS 'driver' BEFORE 'viewer';
