
-- Allow operators to view consumer profiles involved in their yard's disputes
CREATE POLICY "Operators can view dispute consumer profiles"
ON public.profiles FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.disputes d
    JOIN public.tow_yard_operators tyo ON d.tow_yard_id = tyo.tow_yard_id
    WHERE d.consumer_user_id = profiles.user_id
    AND tyo.operator_user_id = auth.uid()
  )
);

-- Allow operators to view profiles of employees at their yards
CREATE POLICY "Operators can view yard employee profiles"
ON public.profiles FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.tow_yard_operators tyo1
    JOIN public.tow_yard_operators tyo2 ON tyo1.tow_yard_id = tyo2.tow_yard_id
    WHERE tyo1.operator_user_id = auth.uid()
    AND tyo2.operator_user_id = profiles.user_id
  )
);
