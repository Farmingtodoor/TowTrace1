
-- Table to track invitation lifecycle events
CREATE TABLE public.invitation_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tow_yard_id UUID NOT NULL REFERENCES public.tow_yards(id) ON DELETE CASCADE,
  tow_yard_name TEXT NOT NULL,
  invited_email TEXT NOT NULL,
  invited_name TEXT,
  invited_by_user_id UUID NOT NULL,
  inviter_name TEXT NOT NULL,
  permission_level TEXT NOT NULL DEFAULT 'operator',
  event_type TEXT NOT NULL CHECK (event_type IN ('invited', 'resent', 'accepted')),
  is_new_user BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Index for admin queries
CREATE INDEX idx_invitation_logs_created_at ON public.invitation_logs(created_at DESC);
CREATE INDEX idx_invitation_logs_tow_yard ON public.invitation_logs(tow_yard_id);

-- RLS
ALTER TABLE public.invitation_logs ENABLE ROW LEVEL SECURITY;

-- Admins can read all invitation logs
CREATE POLICY "Admins can view invitation logs"
  ON public.invitation_logs FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.user_roles
      WHERE user_roles.user_id = auth.uid()
      AND user_roles.role IN ('admin', 'super_admin')
    )
  );

-- Service role inserts (edge functions use service role)
-- No insert policy needed for authenticated users since edge functions use service role key
