-- =============================================================
-- FIX 1: tow_records - Restrict SELECT to operators, claim owners, and admins
-- Currently allows any authenticated user to view ALL records (privacy violation)
-- =============================================================

-- Drop the overly permissive policy
DROP POLICY IF EXISTS "Authenticated users can search tow records" ON public.tow_records;

-- Create a helper function to check if user has a claim on a tow record
CREATE OR REPLACE FUNCTION public.has_claim_on_record(_user_id uuid, _record_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.claims
    WHERE consumer_user_id = _user_id
      AND tow_record_id = _record_id
  )
$$;

-- New policy: Operators can view records for their assigned yards
CREATE POLICY "Operators can view records for their yards"
ON public.tow_records
FOR SELECT
USING (
  EXISTS (
    SELECT 1
    FROM public.tow_yard_operators
    WHERE tow_yard_operators.tow_yard_id = tow_records.tow_yard_id
      AND tow_yard_operators.operator_user_id = auth.uid()
  )
);

-- New policy: Consumers can view records they have claims on
CREATE POLICY "Consumers can view records with their claims"
ON public.tow_records
FOR SELECT
USING (public.has_claim_on_record(auth.uid(), id));

-- =============================================================
-- FIX 2: audit_logs - Remove user INSERT policies (audit should be system-only)
-- Users should not be able to create fake audit entries
-- =============================================================

DROP POLICY IF EXISTS "Authenticated users can insert audit logs" ON public.audit_logs;
DROP POLICY IF EXISTS "Authenticated users can insert their own audit logs" ON public.audit_logs;

-- =============================================================
-- FIX 3: profiles - Add admin view access and tighten existing policies
-- Admins need to view all profiles for user management
-- =============================================================

CREATE POLICY "Admins can view all profiles"
ON public.profiles
FOR SELECT
USING (public.has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can manage all profiles"
ON public.profiles
FOR ALL
USING (public.has_role(auth.uid(), 'admin'::app_role));

-- =============================================================
-- FIX 4: payout_settings - Add comment noting bank data should be masked
-- The RLS is already properly configured (operators/yard admins only)
-- Adding a table comment for documentation purposes
-- =============================================================

COMMENT ON COLUMN public.payout_settings.bank_account_number IS 'SENSITIVE: Should be masked in API responses. Only show last 4 digits to users.';
COMMENT ON COLUMN public.payout_settings.bank_routing_number IS 'SENSITIVE: Should be masked in API responses. Consider partial masking.';