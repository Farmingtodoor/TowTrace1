
-- Update tow_records RLS: restrict drivers to only their own records
DROP POLICY IF EXISTS "Operators can view records for their yards" ON public.tow_records;
CREATE POLICY "Operators can view records for their yards"
ON public.tow_records FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.tow_yard_operators tyo
    WHERE tyo.tow_yard_id = tow_records.tow_yard_id
      AND tyo.operator_user_id = auth.uid()
      AND tyo.permission_level != 'driver'::employee_role
  )
);

CREATE POLICY "Drivers can view their own records"
ON public.tow_records FOR SELECT TO authenticated
USING (
  driver_user_id = auth.uid()
  AND EXISTS (
    SELECT 1 FROM public.tow_yard_operators tyo
    WHERE tyo.tow_yard_id = tow_records.tow_yard_id
      AND tyo.operator_user_id = auth.uid()
      AND tyo.permission_level = 'driver'::employee_role
  )
);

DROP POLICY IF EXISTS "Operators can update records for their yards" ON public.tow_records;
CREATE POLICY "Operators can update records for their yards"
ON public.tow_records FOR UPDATE TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.tow_yard_operators tyo
    WHERE tyo.tow_yard_id = tow_records.tow_yard_id
      AND tyo.operator_user_id = auth.uid()
      AND tyo.permission_level != 'driver'::employee_role
  )
);

CREATE POLICY "Drivers can update their own records"
ON public.tow_records FOR UPDATE TO authenticated
USING (
  driver_user_id = auth.uid()
  AND EXISTS (
    SELECT 1 FROM public.tow_yard_operators tyo
    WHERE tyo.tow_yard_id = tow_records.tow_yard_id
      AND tyo.operator_user_id = auth.uid()
      AND tyo.permission_level = 'driver'::employee_role
  )
);

-- Restrict drivers from fee_configurations
DROP POLICY IF EXISTS "Operators can view fee configs for their yards" ON public.fee_configurations;
CREATE POLICY "Operators can view fee configs for their yards"
ON public.fee_configurations FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.tow_yard_operators tyo
    WHERE tyo.tow_yard_id = fee_configurations.tow_yard_id
      AND tyo.operator_user_id = auth.uid()
      AND tyo.permission_level != 'driver'::employee_role
  )
);

-- Restrict drivers from payout_settings
DROP POLICY IF EXISTS "Yard admins can view payout settings" ON public.payout_settings;
CREATE POLICY "Yard admins can view payout settings"
ON public.payout_settings FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.tow_yard_operators tyo
    WHERE tyo.tow_yard_id = payout_settings.tow_yard_id
      AND tyo.operator_user_id = auth.uid()
      AND tyo.permission_level = 'admin'::employee_role
  )
);

-- Restrict drivers from payout_requests
DROP POLICY IF EXISTS "Operators can view their yard payout requests" ON public.payout_requests;
CREATE POLICY "Operators can view their yard payout requests"
ON public.payout_requests FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.tow_yard_operators tyo
    WHERE tyo.tow_yard_id = payout_requests.tow_yard_id
      AND tyo.operator_user_id = auth.uid()
      AND tyo.permission_level != 'driver'::employee_role
  )
);

-- Restrict drivers from disputes
DROP POLICY IF EXISTS "Operators can view disputes for their yards" ON public.disputes;
CREATE POLICY "Operators can view disputes for their yards"
ON public.disputes FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.tow_yard_operators tyo
    WHERE tyo.tow_yard_id = disputes.tow_yard_id
      AND tyo.operator_user_id = auth.uid()
      AND tyo.permission_level != 'driver'::employee_role
  )
);

DROP POLICY IF EXISTS "Operators can update disputes for their yards" ON public.disputes;
CREATE POLICY "Operators can update disputes for their yards"
ON public.disputes FOR UPDATE TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.tow_yard_operators tyo
    WHERE tyo.tow_yard_id = disputes.tow_yard_id
      AND tyo.operator_user_id = auth.uid()
      AND tyo.permission_level != 'driver'::employee_role
  )
);
