
-- Update the dispute INSERT policy to enforce 2-day window after release
DROP POLICY IF EXISTS "Consumers can create disputes for their claims" ON public.disputes;

CREATE POLICY "Consumers can create disputes for their claims"
ON public.disputes FOR INSERT TO authenticated
WITH CHECK (
  (consumer_user_id = auth.uid())
  AND (EXISTS (
    SELECT 1
    FROM claims c
    JOIN tow_records tr ON c.tow_record_id = tr.id
    WHERE c.id = disputes.claim_id
      AND c.consumer_user_id = auth.uid()
      AND tr.status = 'released'::tow_status
      AND tr.updated_at >= (now() - interval '2 days')
  ))
);
