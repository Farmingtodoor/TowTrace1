-- Create enum for employee permission levels
CREATE TYPE public.employee_role AS ENUM ('viewer', 'editor', 'admin');

-- Add permission_level column to tow_yard_operators
ALTER TABLE public.tow_yard_operators 
ADD COLUMN permission_level employee_role NOT NULL DEFAULT 'editor';

-- Create push_subscriptions table for web push notifications
CREATE TABLE public.push_subscriptions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  endpoint TEXT NOT NULL,
  p256dh_key TEXT NOT NULL,
  auth_key TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, endpoint)
);

-- Enable RLS on push_subscriptions
ALTER TABLE public.push_subscriptions ENABLE ROW LEVEL SECURITY;

-- Users can manage their own push subscriptions
CREATE POLICY "Users can view their own subscriptions"
ON public.push_subscriptions
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own subscriptions"
ON public.push_subscriptions
FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own subscriptions"
ON public.push_subscriptions
FOR DELETE
USING (auth.uid() = user_id);

-- Add updated_at trigger
CREATE TRIGGER update_push_subscriptions_updated_at
BEFORE UPDATE ON public.push_subscriptions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Update RLS for tow_yard_operators to allow operators with admin permission to manage employees
CREATE POLICY "Operators with admin permission can manage employees"
ON public.tow_yard_operators
FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM public.tow_yard_operators tyo
    WHERE tyo.tow_yard_id = tow_yard_operators.tow_yard_id
    AND tyo.operator_user_id = auth.uid()
    AND tyo.permission_level = 'admin'
  )
);