-- =============================================================
-- FIX: payout_settings - Restrict SELECT to yard admins only (not all operators)
-- Security scan indicates regular operators shouldn't see banking details
-- =============================================================

-- Drop the overly permissive operator SELECT policy
DROP POLICY IF EXISTS "Operators can view their payout settings" ON public.payout_settings;

-- Create stricter policy: Only yard admins can view payout settings
CREATE POLICY "Yard admins can view payout settings"
ON public.payout_settings
FOR SELECT
USING (
  EXISTS (
    SELECT 1
    FROM public.tow_yard_operators
    WHERE tow_yard_operators.tow_yard_id = payout_settings.tow_yard_id
      AND tow_yard_operators.operator_user_id = auth.uid()
      AND tow_yard_operators.permission_level = 'admin'::public.employee_role
  )
);