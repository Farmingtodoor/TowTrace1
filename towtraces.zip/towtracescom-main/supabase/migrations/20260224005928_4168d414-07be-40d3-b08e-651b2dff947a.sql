
-- Fix security definer views by setting security_invoker = true
ALTER VIEW public.public_tow_yards SET (security_invoker = true);
ALTER VIEW public.public_tow_records SET (security_invoker = true);
