
-- Add vehicle_photos column to tow_records
ALTER TABLE public.tow_records ADD COLUMN vehicle_photos text[] DEFAULT '{}';

-- Create storage bucket for vehicle photos
INSERT INTO storage.buckets (id, name, public) VALUES ('vehicle-photos', 'vehicle-photos', true);

-- Storage policies
CREATE POLICY "Operators can upload vehicle photos"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'vehicle-photos' AND auth.role() = 'authenticated');

CREATE POLICY "Anyone can view vehicle photos"
ON storage.objects FOR SELECT
USING (bucket_id = 'vehicle-photos');

CREATE POLICY "Operators can delete their vehicle photos"
ON storage.objects FOR DELETE
USING (bucket_id = 'vehicle-photos' AND auth.role() = 'authenticated');
