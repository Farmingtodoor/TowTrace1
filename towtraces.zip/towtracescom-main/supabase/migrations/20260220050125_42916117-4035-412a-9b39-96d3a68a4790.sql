-- Add service_fee column to payments table to track platform revenue per payment
ALTER TABLE public.payments ADD COLUMN service_fee numeric DEFAULT 0;

-- Add a comment for clarity
COMMENT ON COLUMN public.payments.service_fee IS 'Platform service fee (5%) collected from this payment';