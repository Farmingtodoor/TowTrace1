
CREATE OR REPLACE FUNCTION public.check_user_access(_user_id uuid, _required_role text)
RETURNS boolean
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Admin check: user has admin or super_admin role
  IF _required_role = 'admin' THEN
    RETURN EXISTS (
      SELECT 1 FROM public.user_roles
      WHERE user_id = _user_id AND role IN ('admin'::app_role, 'super_admin'::app_role)
    );
  END IF;

  -- Operator check: admin/super_admin OR assigned to a tow yard
  IF _required_role = 'operator' THEN
    RETURN EXISTS (
      SELECT 1 FROM public.user_roles
      WHERE user_id = _user_id AND role IN ('admin'::app_role, 'super_admin'::app_role)
    ) OR EXISTS (
      SELECT 1 FROM public.tow_yard_operators
      WHERE operator_user_id = _user_id
    );
  END IF;

  RETURN false;
END;
$$;
