import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';

interface UserProfile {
  firstName: string | null;
  fullName: string | null;
  avatarUrl: string | null;
  email: string | null;
  phone: string | null;
}

interface UserRoles {
  isAdmin: boolean;
  isOperator: boolean;
  roles: string[];
}

interface OperatorAssignment {
  towYardId: string;
  towYardName: string;
  permissionLevel: string;
}

export function useUserProfile() {
  const { user } = useAuth();

  const { data: profile, isLoading: profileLoading } = useQuery({
    queryKey: ['user-profile', user?.id],
    queryFn: async (): Promise<UserProfile> => {
      if (!user) return { firstName: null, fullName: null, avatarUrl: null, email: null, phone: null };
      const { data } = await supabase
        .from('profiles')
        .select('first_name, full_name, avatar_url, email, phone')
        .eq('user_id', user.id)
        .single();
      return {
        firstName: data?.first_name || null,
        fullName: data?.full_name || null,
        avatarUrl: data?.avatar_url || null,
        email: data?.email || null,
        phone: data?.phone || null,
      };
    },
    enabled: !!user,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const { data: userRoles, isLoading: rolesLoading } = useQuery({
    queryKey: ['user-roles', user?.id],
    queryFn: async (): Promise<UserRoles> => {
      if (!user) return { isAdmin: false, isOperator: false, roles: [] };
      const { data: roleData } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id);
      const roles = roleData?.map(r => r.role) || [];
      return {
        isAdmin: roles.includes('admin'),
        isOperator: false, // Set below from operator query
        roles,
      };
    },
    enabled: !!user,
    staleTime: 5 * 60 * 1000,
  });

  const { data: operatorAssignment, isLoading: operatorLoading } = useQuery({
    queryKey: ['operator-assignment', user?.id],
    queryFn: async (): Promise<OperatorAssignment | null> => {
      if (!user) return null;
      const { data } = await supabase
        .from('tow_yard_operators')
        .select('tow_yard_id, permission_level, tow_yards(name)')
        .eq('operator_user_id', user.id)
        .limit(1)
        .maybeSingle();
      if (!data) return null;
      return {
        towYardId: data.tow_yard_id,
        towYardName: (data.tow_yards as any)?.name || '',
        permissionLevel: data.permission_level,
      };
    },
    enabled: !!user,
    staleTime: 5 * 60 * 1000,
  });

  const isOperator = !!operatorAssignment;
  const isAdmin = userRoles?.isAdmin || false;
  const displayName = profile?.firstName || profile?.fullName?.split(' ')[0] || user?.email?.split('@')[0] || 'User';

  return {
    profile: profile || { firstName: null, fullName: null, avatarUrl: null, email: null, phone: null },
    isAdmin,
    isOperator,
    operatorAssignment,
    displayName,
    loading: profileLoading || rolesLoading || operatorLoading,
  };
}
