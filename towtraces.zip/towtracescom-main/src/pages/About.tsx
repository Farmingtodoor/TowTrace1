import { PageHeader } from '@/components/layout/PageHeader';
import { PageFooter } from '@/components/layout/PageFooter';
import { AuthModal } from '@/components/auth/AuthModal';
import { TeamSection } from '@/components/about/TeamSection';
import { useState } from 'react';
import { 
  Car, 
  Shield, 
  Clock, 
  MapPin, 
  Users, 
  Building2, 
  Zap,
  Heart,
  Globe
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

export default function About() {
  const [showAuthModal, setShowAuthModal] = useState(false);

  const features = [
    {
      icon: Clock,
      title: 'Instant Search',
      description: 'Find your towed vehicle in seconds, not hours. No more calling dozens of tow yards.',
    },
    {
      icon: Shield,
      title: 'Verified Partners',
      description: 'All tow yards in our network are verified and meet our quality standards.',
    },
    {
      icon: MapPin,
      title: 'US & Canada Coverage',
      description: 'Extensive network spanning major cities across North America.',
    },
    {
      icon: Zap,
      title: 'Digital Documents',
      description: 'Upload your ID and registration online for faster vehicle release.',
    },
  ];

  const stats = [
    { value: '500+', label: 'Partner Tow Yards' },
    { value: '50K+', label: 'Vehicles Located' },
    { value: '< 30s', label: 'Average Search Time' },
    { value: '24/7', label: 'Availability' },
  ];

  const team = [
    {
      role: 'For Vehicle Owners',
      description: 'Stop the frustration of not knowing where your car is. Our platform gives you instant answers and a clear path to getting your vehicle back.',
      icon: Car,
    },
    {
      role: 'For Tow Yards',
      description: 'Reduce phone calls and streamline your operations. Our digital platform helps you manage records and process claims faster.',
      icon: Building2,
    },
    {
      role: 'For Cities',
      description: 'Improve citizen satisfaction with transparent towing processes. Partner with us to modernize municipal towing services.',
      icon: Globe,
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <PageHeader onSignInClick={() => setShowAuthModal(true)} />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="hero-gradient text-primary-foreground py-20 px-4">
          <div className="max-w-4xl mx-auto text-center space-y-6">
            <div className="inline-flex items-center gap-2 bg-primary-foreground/10 backdrop-blur-sm px-4 py-2 rounded-full text-sm">
              <Heart className="w-4 h-4" />
              Built with care for stressed vehicle owners
            </div>
            <h1 className="font-display text-4xl md:text-5xl font-bold text-balance">
              We're Making Vehicle Recovery Simple
            </h1>
            <p className="text-xl text-primary-foreground/80 max-w-2xl mx-auto">
              TowTrace connects vehicle owners with tow yards across North America, 
              eliminating the stress and confusion of finding a towed vehicle.
            </p>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-16 px-4 border-b border-border">
          <div className="max-w-5xl mx-auto">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <p className="font-display text-4xl font-bold text-accent">{stat.value}</p>
                  <p className="text-muted-foreground mt-2">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 px-4">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="font-display text-3xl font-bold mb-4">Why Choose TowTrace?</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                We've reimagined the vehicle recovery process from the ground up, 
                focusing on transparency, speed, and peace of mind.
              </p>
            </div>
            <div className="grid md:grid-cols-2 gap-8">
              {features.map((feature, index) => (
                <div 
                  key={index} 
                  className="bg-card rounded-2xl p-6 shadow-card hover:shadow-card-lg transition-shadow"
                >
                  <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center mb-4">
                    <feature.icon className="w-6 h-6 text-accent" />
                  </div>
                  <h3 className="font-display text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Mission Section */}
        <section className="py-20 px-4 bg-muted/30">
          <div className="max-w-4xl mx-auto text-center">
            <Users className="w-12 h-12 text-accent mx-auto mb-6" />
            <h2 className="font-display text-3xl font-bold mb-6">Our Mission</h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              We believe that nobody should have to spend hours on the phone trying to find their towed vehicle. 
              Our mission is to bring transparency and efficiency to the towing industry, 
              helping vehicle owners get back on the road faster while helping tow yards operate more efficiently.
            </p>
          </div>
        </section>

        {/* Team Section */}
        <TeamSection />

        {/* Who We Serve */}
        <section className="py-20 px-4">
          <div className="max-w-5xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="font-display text-3xl font-bold mb-4">Who We Serve</h2>
              <p className="text-muted-foreground">
                TowTrace creates value for everyone in the vehicle recovery ecosystem.
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              {team.map((item, index) => (
                <div 
                  key={index}
                  className="bg-card rounded-2xl p-6 shadow-card text-center"
                >
                  <div className="w-16 h-16 bg-gradient-to-br from-accent/20 to-primary/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <item.icon className="w-8 h-8 text-accent" />
                  </div>
                  <h3 className="font-display text-xl font-semibold mb-3">{item.role}</h3>
                  <p className="text-muted-foreground text-sm">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 px-4 bg-primary text-primary-foreground">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <h2 className="font-display text-3xl font-bold">Ready to Find Your Vehicle?</h2>
            <p className="text-primary-foreground/80">
              Search our network of partner tow yards across the US and Canada.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-white text-primary hover:bg-white/90">
                <Link to="/">
                  <Car className="w-5 h-5 mr-2" />
                  Search Now
                </Link>
              </Button>
              <Button asChild size="lg" variant="ghost-light">
                <Link to="/join">
                  <Building2 className="w-5 h-5 mr-2" />
                  Partner With Us
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <PageFooter />

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onSuccess={() => setShowAuthModal(false)}
      />
    </div>
  );
}
