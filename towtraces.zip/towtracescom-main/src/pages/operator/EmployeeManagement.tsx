import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users,
  Plus,
  MoreVertical,
  Loader2,
  Mail,
  Trash2,
  UserPlus,
  Shield,
  RefreshCw,
  Clock,
} from 'lucide-react';
import { PageHeader } from '@/components/layout/PageHeader';
import { PageFooter } from '@/components/layout/PageFooter';
import { AuthModal } from '@/components/auth/AuthModal';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';

type EmployeePermission = 'driver' | 'viewer' | 'operator' | 'editor' | 'admin';

interface Employee {
  id: string;
  operator_user_id: string;
  tow_yard_id: string;
  created_at: string;
  permission_level: EmployeePermission;
  isPending?: boolean;
  profile?: {
    email: string;
    full_name: string | null;
  };
}

interface TowYard {
  id: string;
  name: string;
}

const permissionLabels: Record<EmployeePermission, { label: string; description: string }> = {
  driver: { label: 'Driver', description: 'Can create tows and view/edit only their own records' },
  viewer: { label: 'Viewer', description: 'Can view records only' },
  operator: { label: 'Operator', description: 'Can create and manage their own tow records' },
  editor: { label: 'Editor', description: 'Can view and edit all records' },
  admin: { label: 'Admin', description: 'Full access including employee management' },
};

export default function EmployeeManagement() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const { toast } = useToast();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [isOperator, setIsOperator] = useState(false);
  const [loading, setLoading] = useState(true);
  const [employeesLoading, setEmployeesLoading] = useState(false);
  const [towYards, setTowYards] = useState<TowYard[]>([]);
  const [selectedYard, setSelectedYard] = useState<string>('');
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteName, setInviteName] = useState('');
  const [invitePermission, setInvitePermission] = useState<EmployeePermission>('operator');
  const [isInviting, setIsInviting] = useState(false);
  const [isResending, setIsResending] = useState<string | null>(null);
  const [currentUserPermission, setCurrentUserPermission] = useState<EmployeePermission>('viewer');

  // Check if user is operator
  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      setShowAuthModal(true);
      setLoading(false);
      return;
    }

    const checkOperatorRole = async () => {
      const { data: operatorCheck } = await supabase.rpc('has_role', {
        _user_id: user.id,
        _role: 'operator',
      });

      const { data: adminCheck } = await supabase.rpc('has_role', {
        _user_id: user.id,
        _role: 'admin',
      });

      setIsOperator(operatorCheck === true || adminCheck === true);
      setLoading(false);
    };

    checkOperatorRole();
  }, [user, authLoading]);

  // Fetch tow yards
  useEffect(() => {
    if (!isOperator || !user) return;

    const fetchYards = async () => {
      const { data: adminCheck } = await supabase.rpc('has_role', {
        _user_id: user.id,
        _role: 'admin',
      });

      let query = supabase.from('tow_yards').select('id, name');

      if (adminCheck !== true) {
        const { data: assignments } = await supabase
          .from('tow_yard_operators')
          .select('tow_yard_id')
          .eq('operator_user_id', user.id);

        const yardIds = assignments?.map((a) => a.tow_yard_id) || [];
        query = query.in('id', yardIds);
      }

      const { data } = await query;
      if (data && data.length > 0) {
        setTowYards(data);
        setSelectedYard(data[0].id);
      }
    };

    fetchYards();
  }, [isOperator, user]);

  // Fetch employees for selected yard
  useEffect(() => {
    if (!selectedYard) return;

    const fetchEmployees = async () => {
      setEmployeesLoading(true);
      
      const { data: operators } = await supabase
        .from('tow_yard_operators')
        .select('id, operator_user_id, tow_yard_id, created_at, permission_level')
        .eq('tow_yard_id', selectedYard);

      if (!operators) {
        setEmployeesLoading(false);
        return;
      }

      // Fetch profile info for each operator
      const employeesWithProfiles: Employee[] = [];
      for (const op of operators) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('email, full_name')
          .eq('user_id', op.operator_user_id)
          .single();

        employeesWithProfiles.push({
          ...op,
          permission_level: (op.permission_level as EmployeePermission) || 'editor',
          profile: profile || undefined,
        });
      }

      // Check pending status for all employees
      const userIds = operators.map((op) => op.operator_user_id);
      try {
        const { data: pendingData } = await supabase.functions.invoke('check-pending-employees', {
          body: { userIds },
        });

        if (pendingData?.pendingStatus) {
          employeesWithProfiles.forEach((emp) => {
            emp.isPending = pendingData.pendingStatus[emp.operator_user_id] === true;
          });
        }
      } catch (error) {
        console.error('Error checking pending status:', error);
      }

      setEmployees(employeesWithProfiles);
      setEmployeesLoading(false);
      
      // Find current user's permission level
      const currentUserEmp = employeesWithProfiles.find(e => e.operator_user_id === user?.id);
      if (currentUserEmp) {
        setCurrentUserPermission(currentUserEmp.permission_level);
      }
    };

    fetchEmployees();
  }, [selectedYard, user?.id]);

  const handleInviteEmployee = async () => {
    if (!inviteEmail || !selectedYard) return;

    setIsInviting(true);

    try {
      // Get selected yard name
      const selectedYardData = towYards.find((y) => y.id === selectedYard);
      const inviterName = user?.user_metadata?.full_name || user?.email || 'Admin';

      const response = await supabase.functions.invoke('invite-employee', {
        body: {
          email: inviteEmail,
          fullName: inviteName || undefined,
          towYardId: selectedYard,
          towYardName: selectedYardData?.name || 'Tow Yard',
          permissionLevel: invitePermission,
          inviterName,
        },
      });

      if (response.error) {
        throw new Error(response.error.message || 'Failed to invite employee');
      }

      const result = response.data;

      if (result.error) {
        throw new Error(result.error);
      }

      toast({
        title: result.isNewUser ? 'Invitation Sent!' : 'Employee Added!',
        description: result.message,
      });

      setShowAddDialog(false);
      setInviteEmail('');
      setInviteName('');
      setInvitePermission('operator');

      // Refresh employees list
      const { data: operators } = await supabase
        .from('tow_yard_operators')
        .select('id, operator_user_id, tow_yard_id, created_at, permission_level')
        .eq('tow_yard_id', selectedYard);

      if (operators) {
        const employeesWithProfiles: Employee[] = [];
        for (const op of operators) {
          const { data: prof } = await supabase
            .from('profiles')
            .select('email, full_name')
            .eq('user_id', op.operator_user_id)
            .single();

          employeesWithProfiles.push({
            ...op,
            permission_level: (op.permission_level as EmployeePermission) || 'operator',
            profile: prof || undefined,
          });
        }
        setEmployees(employeesWithProfiles);
      }
    } catch (error: any) {
      console.error('Invite error:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to invite employee. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsInviting(false);
    }
  };

  const handleRemoveEmployee = async (employeeId: string, userId: string) => {
    // Don't allow removing yourself
    if (userId === user?.id) {
      toast({
        title: 'Cannot Remove',
        description: 'You cannot remove yourself from the tow yard.',
        variant: 'destructive',
      });
      return;
    }

    const { error } = await supabase
      .from('tow_yard_operators')
      .delete()
      .eq('id', employeeId);

    if (error) {
      toast({
        title: 'Error',
        description: 'Failed to remove employee.',
        variant: 'destructive',
      });
    } else {
      toast({
        title: 'Employee Removed',
        description: 'Employee has been removed from the tow yard.',
      });
      setEmployees(employees.filter((e) => e.id !== employeeId));
    }
  };

  const handleUpdatePermission = async (employeeId: string, newPermission: EmployeePermission) => {
    const { error } = await supabase
      .from('tow_yard_operators')
      .update({ permission_level: newPermission as any })
      .eq('id', employeeId);

    if (error) {
      toast({
        title: 'Error',
        description: 'Failed to update permission.',
        variant: 'destructive',
      });
    } else {
      toast({
        title: 'Permission Updated',
        description: `Employee permission updated to ${permissionLabels[newPermission].label}.`,
      });
      setEmployees(employees.map((e) => 
        e.id === employeeId ? { ...e, permission_level: newPermission } : e
      ));
    }
  };

  const handleResendInvitation = async (employee: Employee) => {
    if (!selectedYard) return;

    setIsResending(employee.id);

    try {
      const selectedYardData = towYards.find((y) => y.id === selectedYard);
      const inviterName = user?.user_metadata?.full_name || user?.email || 'Admin';

      const response = await supabase.functions.invoke('resend-invitation', {
        body: {
          userId: employee.operator_user_id,
          towYardId: selectedYard,
          towYardName: selectedYardData?.name || 'Tow Yard',
          inviterName,
        },
      });

      if (response.error) {
        throw new Error(response.error.message || 'Failed to resend invitation');
      }

      const result = response.data;

      if (result.error) {
        throw new Error(result.error);
      }

      toast({
        title: 'Invitation Resent!',
        description: result.message,
      });
    } catch (error: any) {
      console.error('Resend error:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to resend invitation. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsResending(null);
    }
  };

  const canManageEmployees = currentUserPermission === 'admin';

  if (authLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-accent" />
      </div>
    );
  }

  if (!isOperator) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <PageHeader onSignInClick={() => setShowAuthModal(true)} />
        <main className="flex-1 flex items-center justify-center px-4">
          <div className="text-center">
            <Shield className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h1 className="font-display text-2xl font-bold mb-2">Access Denied</h1>
            <p className="text-muted-foreground">
              You need operator access to manage employees.
            </p>
            <Button onClick={() => navigate('/')} className="mt-4">
              Go Home
            </Button>
          </div>
        </main>
        <PageFooter />
        <AuthModal
          isOpen={showAuthModal}
          onClose={() => setShowAuthModal(false)}
          onSuccess={() => window.location.reload()}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <PageHeader onSignInClick={() => setShowAuthModal(true)} />

      <main className="flex-1 px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="font-display text-3xl font-bold">Employee Management</h1>
              <p className="text-muted-foreground mt-1">
                Manage your tow yard employees and drivers.
              </p>
            </div>
            {canManageEmployees && (
              <Button onClick={() => setShowAddDialog(true)}>
                <UserPlus className="w-4 h-4 mr-2" />
                Add Employee
              </Button>
            )}
          </div>

          {/* Yard Selector */}
          {towYards.length > 1 && (
            <div className="max-w-xs">
              <Label>Select Tow Yard</Label>
              <Select value={selectedYard} onValueChange={setSelectedYard}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {towYards.map((yard) => (
                    <SelectItem key={yard.id} value={yard.id}>
                      {yard.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Pending Invites Section */}
          {employees.filter(e => e.isPending).length > 0 && canManageEmployees && (
            <div className="bg-card rounded-xl shadow-card overflow-hidden">
              <div className="px-4 py-3 border-b border-border flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-600" />
                <h2 className="font-display font-semibold">Pending Invitations</h2>
                <Badge variant="outline" className="text-amber-600 border-amber-300 bg-amber-50 ml-auto">
                  {employees.filter(e => e.isPending).length} pending
                </Badge>
              </div>
              <div className="divide-y divide-border">
                {employees.filter(e => e.isPending).map((emp) => (
                  <div key={`pending-${emp.id}`} className="flex items-center justify-between px-4 py-3 gap-4">
                    <div className="min-w-0">
                      <p className="font-medium truncate">{emp.profile?.full_name || 'Unknown'}</p>
                      <p className="text-sm text-muted-foreground truncate">{emp.profile?.email || 'N/A'}</p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <Badge variant="outline" className="text-xs">
                        {permissionLabels[emp.permission_level].label}
                      </Badge>
                      <span className="text-xs text-muted-foreground">
                        Invited {format(new Date(emp.created_at), 'MMM d')}
                      </span>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleResendInvitation(emp)}
                        disabled={isResending === emp.id}
                      >
                        {isResending === emp.id ? (
                          <Loader2 className="w-3 h-3 animate-spin mr-1" />
                        ) : (
                          <RefreshCw className="w-3 h-3 mr-1" />
                        )}
                        Resend
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-destructive hover:text-destructive"
                        onClick={() => handleRemoveEmployee(emp.id, emp.operator_user_id)}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
              <div className="px-4 py-2 bg-muted/50 text-xs text-muted-foreground">
                💡 Invitees must check their email and click the link to complete signup. If using a test email domain, only verified recipients will receive emails.
              </div>
            </div>
          )}

          {/* Employees Table */}
          <div className="bg-card rounded-xl shadow-card overflow-hidden">
            {employeesLoading ? (
              <div className="p-4">
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex items-center gap-4 animate-pulse">
                      <div className="h-10 w-10 rounded-full bg-muted" />
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-muted rounded w-1/4" />
                        <div className="h-3 bg-muted rounded w-1/3" />
                      </div>
                      <div className="h-6 bg-muted rounded w-16" />
                      <div className="h-6 bg-muted rounded w-20" />
                      <div className="h-6 bg-muted rounded w-24" />
                    </div>
                  ))}
                </div>
              </div>
            ) : employees.length === 0 ? (
              <div className="p-8 text-center">
                <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="font-display text-lg font-semibold mb-2">
                  No Employees Yet
                </h3>
                <p className="text-muted-foreground mb-4">
                  Add employees to your tow yard to allow them to manage records.
                </p>
                <Button onClick={() => setShowAddDialog(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add First Employee
                </Button>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Added</TableHead>
                    <TableHead className="w-12"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {employees.map((emp) => (
                    <TableRow key={emp.id}>
                      <TableCell className="font-medium">
                        {emp.profile?.full_name || 'Unknown'}
                        {emp.operator_user_id === user?.id && (
                          <Badge variant="secondary" className="ml-2">
                            You
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {emp.profile?.email || 'N/A'}
                      </TableCell>
                      <TableCell>
                        {emp.isPending ? (
                          <Badge variant="outline" className="text-amber-600 border-amber-300 bg-amber-50">
                            <Clock className="w-3 h-3 mr-1" />
                            Pending
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="text-green-600 border-green-300 bg-green-50">
                            Active
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {canManageEmployees && emp.operator_user_id !== user?.id ? (
                          <Select
                            value={emp.permission_level}
                            onValueChange={(val) => handleUpdatePermission(emp.id, val as EmployeePermission)}
                          >
                            <SelectTrigger className="w-28 h-8">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="driver">Driver</SelectItem>
                              <SelectItem value="viewer">Viewer</SelectItem>
                              <SelectItem value="operator">Operator</SelectItem>
                              <SelectItem value="editor">Editor</SelectItem>
                              <SelectItem value="admin">Admin</SelectItem>
                            </SelectContent>
                          </Select>
                        ) : (
                          <Badge variant={emp.permission_level === 'admin' ? 'default' : 'outline'}>
                            {permissionLabels[emp.permission_level].label}
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {format(new Date(emp.created_at), 'MMM d, yyyy')}
                      </TableCell>
                      <TableCell>
                        {canManageEmployees && emp.operator_user_id !== user?.id && (
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" disabled={isResending === emp.id}>
                                {isResending === emp.id ? (
                                  <Loader2 className="w-4 h-4 animate-spin" />
                                ) : (
                                  <MoreVertical className="w-4 h-4" />
                                )}
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              {emp.isPending && (
                                <DropdownMenuItem
                                  onClick={() => handleResendInvitation(emp)}
                                  disabled={isResending === emp.id}
                                >
                                  <RefreshCw className="w-4 h-4 mr-2" />
                                  Resend Invitation
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuItem
                                onClick={() =>
                                  handleRemoveEmployee(emp.id, emp.operator_user_id)
                                }
                                className="text-destructive"
                              >
                                <Trash2 className="w-4 h-4 mr-2" />
                                Remove
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>

          {/* Back Link */}
          <Button variant="outline" onClick={() => navigate('/operator')}>
            Back to Dashboard
          </Button>
        </div>
      </main>

      <PageFooter />

      {/* Add Employee Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Invite Employee</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="inviteName">Full Name</Label>
              <Input
                id="inviteName"
                type="text"
                value={inviteName}
                onChange={(e) => setInviteName(e.target.value)}
                placeholder="John Doe"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="inviteEmail">Employee Email</Label>
              <Input
                id="inviteEmail"
                type="email"
                value={inviteEmail}
                onChange={(e) => setInviteEmail(e.target.value)}
                placeholder="employee@company.com"
              />
              <p className="text-xs text-muted-foreground">
                They'll receive an email invitation to set up their account.
              </p>
            </div>
            <div className="space-y-2">
              <Label>Permission Level</Label>
              <Select value={invitePermission} onValueChange={(val) => setInvitePermission(val as EmployeePermission)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="driver">
                    <div className="flex flex-col">
                      <span>Driver</span>
                      <span className="text-xs text-muted-foreground">Can create tows and view/edit only their own records</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="viewer">
                    <div className="flex flex-col">
                      <span>Viewer</span>
                      <span className="text-xs text-muted-foreground">Can view records only</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="operator">
                    <div className="flex flex-col">
                      <span>Operator</span>
                      <span className="text-xs text-muted-foreground">Can create and manage their own tow records</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="editor">
                    <div className="flex flex-col">
                      <span>Editor</span>
                      <span className="text-xs text-muted-foreground">Can view and edit all records</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="admin">
                    <div className="flex flex-col">
                      <span>Admin</span>
                      <span className="text-xs text-muted-foreground">Full access including employee management</span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleInviteEmployee} disabled={isInviting || !inviteEmail}>
              {isInviting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Sending Invite...
                </>
              ) : (
                <>
                  <Mail className="w-4 h-4 mr-2" />
                  Send Invitation
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onSuccess={() => window.location.reload()}
      />
    </div>
  );
}