import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { 
  Car, 
  Plus, 
  Search, 
  Filter,
  Building2,
  FileText,
  Users,
  CreditCard,
  BarChart3,
  History,
  Settings,
  Wallet,
  X,
  Scale,
  User
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { PageHeader } from '@/components/layout/PageHeader';
import { PageFooter } from '@/components/layout/PageFooter';
import { AuthModal } from '@/components/auth/AuthModal';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { sendSubscriptionConfirmation } from '@/lib/notifications';
import { TowRecordsList } from '@/components/operator/TowRecordsList';
import { AddRecordDialog } from '@/components/operator/AddRecordDialog';
import { SubscriptionSection } from '@/components/operator/SubscriptionSection';
import { AnalyticsSection } from '@/components/operator/AnalyticsSection';
import { RealTimeMetrics } from '@/components/operator/RealTimeMetrics';
import { ActivityLogsSection } from '@/components/operator/ActivityLogsSection';
import { FeeConfigurationManager } from '@/components/operator/FeeConfigurationManager';
import { PayoutSettingsManager } from '@/components/operator/PayoutSettingsManager';
import { VEHICLE_TYPES, type VehicleType } from '@/lib/feeCalculator';
import { toast } from 'sonner';
import { QuickActionsMenu } from '@/components/operator/QuickActionsMenu';

type EmployeePermission = 'driver' | 'viewer' | 'editor' | 'admin';

interface TowYard {
  id: string;
  name: string;
  address: string;
  city: string;
  state_province: string;
}

export default function OperatorDashboard() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [isOperator, setIsOperator] = useState<boolean | null>(null);
  const [towYards, setTowYards] = useState<TowYard[]>([]);
  const [selectedYard, setSelectedYard] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [userPermission, setUserPermission] = useState<EmployeePermission>('viewer');
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState(() => {
    // Check for tab parameter in URL
    const tabParam = new URLSearchParams(window.location.search).get('tab');
    return tabParam && ['records', 'employees', 'documents', 'activity', 'settings', 'payouts', 'disputes', 'subscription', 'analytics'].includes(tabParam) 
      ? tabParam 
      : 'records';
  });
  const [vehicleTypeFilter, setVehicleTypeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [driverFilter, setDriverFilter] = useState<string>('all');
  const [drivers, setDrivers] = useState<{ id: string; name: string }[]>([]);

  // Handle subscription success
  useEffect(() => {
    if (searchParams.get('subscription') === 'success') {
      toast.success('Subscription activated successfully!');
      // Send confirmation email
      if (user?.email) {
        sendSubscriptionConfirmation(
          user.email,
          user.user_metadata?.full_name || 'Operator',
          'Pro' // Would need to fetch actual plan
        );
      }
    }
  }, [searchParams, user]);

  // Check if user is an operator
  useEffect(() => {
    if (!authLoading && !user) {
      setShowAuthModal(true);
      return;
    }

    if (!user) return;

    const checkOperatorRole = async () => {
      const { data, error } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id)
        .in('role', ['operator', 'admin']);

      if (error) {
        console.error('Error checking role:', error);
        setIsOperator(false);
      } else {
        setIsOperator(data.length > 0);
      }
    };

    checkOperatorRole();
  }, [authLoading, user]);

  // Fetch operator's tow yards
  useEffect(() => {
    if (!user || isOperator === false) return;

    const fetchTowYards = async () => {
      setLoading(true);

      // Check if admin
      const { data: roleData } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id)
        .eq('role', 'admin')
        .maybeSingle();

      let yardsQuery;
      if (roleData) {
        // Admin can see all yards
        yardsQuery = supabase
          .from('tow_yards')
          .select('id, name, address, city, state_province');
      } else {
        // Operator sees assigned yards
        yardsQuery = supabase
          .from('tow_yard_operators')
          .select('tow_yard:tow_yards(id, name, address, city, state_province)')
          .eq('operator_user_id', user.id);
      }

      const { data, error } = await yardsQuery;

      if (error) {
        console.error('Error fetching tow yards:', error);
      } else {
        const yards = roleData
          ? (data as TowYard[])
          : (data as Array<{ tow_yard: TowYard }>).map((d) => d.tow_yard);
        
        setTowYards(yards);
        if (yards.length > 0) {
          setSelectedYard(yards[0].id);
        }
      }
      setLoading(false);
    };

    fetchTowYards();
  }, [user, isOperator]);

  // Fetch user permission for selected yard
  useEffect(() => {
    if (!selectedYard || !user) return;

    const fetchPermission = async () => {
      // Check if admin first
      const { data: adminCheck } = await supabase.rpc('has_role', {
        _user_id: user.id,
        _role: 'admin',
      });

      if (adminCheck) {
        setUserPermission('admin');
        return;
      }

      // Get permission from tow_yard_operators
      const { data: operatorData } = await supabase
        .from('tow_yard_operators')
        .select('permission_level')
        .eq('tow_yard_id', selectedYard)
        .eq('operator_user_id', user.id)
        .single();

      if (operatorData?.permission_level) {
        setUserPermission(operatorData.permission_level as EmployeePermission);
      }
    };

    fetchPermission();
  }, [selectedYard, user]);

  // Fetch drivers for the selected yard
  useEffect(() => {
    if (!selectedYard) return;

    const fetchDrivers = async () => {
      // Get unique drivers from tow records
      const { data: records } = await supabase
        .from('tow_records')
        .select('driver_user_id, driver_name')
        .eq('tow_yard_id', selectedYard)
        .not('driver_user_id', 'is', null);

      if (records) {
        const uniqueDrivers = new Map<string, string>();
        records.forEach((r) => {
          if (r.driver_user_id && !uniqueDrivers.has(r.driver_user_id)) {
            uniqueDrivers.set(r.driver_user_id, r.driver_name || 'Unknown');
          }
        });
        
        setDrivers(
          Array.from(uniqueDrivers.entries()).map(([id, name]) => ({ id, name }))
        );
      }
    };

    fetchDrivers();
  }, [selectedYard]);

  const isDriver = userPermission === 'driver';
  const canEdit = userPermission === 'editor' || userPermission === 'admin' || isDriver;
  const canManage = userPermission === 'admin';

  if (authLoading || loading) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <PageHeader />
        <main className="flex-1 px-4 py-8">
          <div className="max-w-7xl mx-auto space-y-6">
            <div className="space-y-2">
              <div className="h-8 bg-muted rounded w-1/3 animate-pulse" />
              <div className="h-4 bg-muted rounded w-1/4 animate-pulse" />
            </div>
            <div className="h-10 bg-muted rounded animate-pulse" />
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="bg-card rounded-xl p-4 space-y-3">
                  <div className="h-4 bg-muted rounded w-1/2 animate-pulse" />
                  <div className="h-8 bg-muted rounded w-3/4 animate-pulse" />
                  <div className="h-3 bg-muted rounded w-full animate-pulse" />
                </div>
              ))}
            </div>
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-card rounded-xl p-5 flex items-center gap-4">
                  <div className="w-10 h-10 bg-muted rounded animate-pulse" />
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-muted rounded w-1/3 animate-pulse" />
                    <div className="h-3 bg-muted rounded w-1/4 animate-pulse" />
                  </div>
                  <div className="h-6 bg-muted rounded-full w-16 animate-pulse" />
                </div>
              ))}
            </div>
          </div>
        </main>
        <PageFooter />
      </div>
    );
  }

  if (isOperator === false) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <PageHeader />
        <main className="flex-1 flex items-center justify-center px-4">
          <div className="text-center space-y-4">
            <div className="w-16 h-16 bg-destructive/10 rounded-full flex items-center justify-center mx-auto">
              <Building2 className="w-8 h-8 text-destructive" />
            </div>
            <h1 className="font-display text-2xl font-bold">Access Denied</h1>
            <p className="text-muted-foreground max-w-md">
              You don't have operator access. If you're a tow yard operator,
              please contact support to get your account set up.
            </p>
            <Button onClick={() => navigate('/')}>
              Return to Home
            </Button>
          </div>
        </main>
        <PageFooter />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <PageHeader onSignInClick={() => setShowAuthModal(true)} />

      <main className="flex-1 px-4 py-8">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h1 className="font-display text-3xl font-bold">
                {user?.user_metadata?.full_name 
                  ? `${user.user_metadata.full_name}'s Dashboard`
                  : 'Dashboard'}
              </h1>
              <p className="text-muted-foreground">
                Manage tow records and vehicle releases
              </p>
            </div>
            {canEdit && activeTab === 'records' && (
              <Button onClick={() => setShowAddDialog(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Tow Record
              </Button>
            )}
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList>
              <TabsTrigger value="records" className="flex items-center gap-2">
                <Car className="w-4 h-4" />
                Tow Records
              </TabsTrigger>
              {canManage && (
                <TabsTrigger value="employees" className="flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  Employees
                </TabsTrigger>
              )}
              {!isDriver && (
                <TabsTrigger value="documents" className="flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  Documents
                </TabsTrigger>
              )}
              {!isDriver && (
                <TabsTrigger value="activity" className="flex items-center gap-2">
                  <History className="w-4 h-4" />
                  Activity
                </TabsTrigger>
              )}
              {canManage && (
                <TabsTrigger value="settings" className="flex items-center gap-2">
                  <Settings className="w-4 h-4" />
                  Fee Settings
                </TabsTrigger>
              )}
              {canManage && (
                <TabsTrigger value="payouts" className="flex items-center gap-2">
                  <Wallet className="w-4 h-4" />
                  Payouts
                </TabsTrigger>
              )}
              {!isDriver && (
                <TabsTrigger value="disputes" className="flex items-center gap-2">
                  <Scale className="w-4 h-4" />
                  Disputes
                </TabsTrigger>
              )}
              {!isDriver && (
                <TabsTrigger value="subscription" className="flex items-center gap-2">
                  <CreditCard className="w-4 h-4" />
                  Subscription
                </TabsTrigger>
              )}
              {!isDriver && (
                <TabsTrigger value="analytics" className="flex items-center gap-2">
                  <BarChart3 className="w-4 h-4" />
                  Analytics
                </TabsTrigger>
              )}
            </TabsList>

            <TabsContent value="records" className="mt-6 space-y-6">
              {/* Yard Selector */}
              {towYards.length > 1 && (
                <div className="flex gap-2 overflow-x-auto pb-2">
                  {towYards.map((yard) => (
                    <Button
                      key={yard.id}
                      variant={selectedYard === yard.id ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setSelectedYard(yard.id)}
                      className="whitespace-nowrap"
                    >
                      <Building2 className="w-4 h-4 mr-2" />
                      {yard.name}
                    </Button>
                  ))}
                </div>
              )}

              {/* Real-Time Metrics */}
              <RealTimeMetrics towYardId={selectedYard} />

              {/* Search & Filter */}
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by plate, VIN, or vehicle..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <div className="flex gap-2">
                  <Select value={vehicleTypeFilter} onValueChange={setVehicleTypeFilter}>
                    <SelectTrigger className="w-[160px]">
                      <Car className="w-4 h-4 mr-2" />
                      <SelectValue placeholder="Vehicle Type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      {Object.entries(VEHICLE_TYPES).map(([value, { label }]) => (
                        <SelectItem key={value} value={value}>{label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-[140px]">
                      <Filter className="w-4 h-4 mr-2" />
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="towed">Towed</SelectItem>
                      <SelectItem value="docs_pending">Docs Pending</SelectItem>
                      <SelectItem value="docs_approved">Docs Approved</SelectItem>
                      <SelectItem value="paid">Paid</SelectItem>
                      <SelectItem value="released">Released</SelectItem>
                    </SelectContent>
                  </Select>
                  {drivers.length > 0 && (
                    <Select value={driverFilter} onValueChange={setDriverFilter}>
                      <SelectTrigger className="w-[160px]">
                        <User className="w-4 h-4 mr-2" />
                        <SelectValue placeholder="Driver" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Drivers</SelectItem>
                        <SelectItem value="unassigned">Unassigned</SelectItem>
                        {drivers.map((driver) => (
                          <SelectItem key={driver.id} value={driver.id}>
                            {driver.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                  {(vehicleTypeFilter !== 'all' || statusFilter !== 'all' || driverFilter !== 'all') && (
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => {
                        setVehicleTypeFilter('all');
                        setStatusFilter('all');
                        setDriverFilter('all');
                      }}
                      title="Clear filters"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </div>

              {/* Records List */}
              {selectedYard && (
                <TowRecordsList
                  towYardId={selectedYard}
                  searchQuery={searchQuery}
                  userPermission={userPermission}
                  vehicleTypeFilter={vehicleTypeFilter !== 'all' ? vehicleTypeFilter : undefined}
                  statusFilter={statusFilter !== 'all' ? statusFilter : undefined}
                  driverFilter={driverFilter !== 'all' ? driverFilter : undefined}
                />
              )}
            </TabsContent>

            {canManage && (
              <TabsContent value="employees" className="mt-6">
                <div className="bg-card rounded-xl p-6 shadow-card">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h2 className="text-xl font-semibold">Employee Management</h2>
                      <p className="text-muted-foreground text-sm">
                        Manage your tow yard staff and drivers
                      </p>
                    </div>
                    <Button onClick={() => navigate('/operator/employees')}>
                      <Users className="w-4 h-4 mr-2" />
                      Manage Employees
                    </Button>
                  </div>
                  <p className="text-muted-foreground">
                    Add employees to allow them to access this dashboard and manage tow records.
                  </p>
                </div>
              </TabsContent>
            )}

            <TabsContent value="documents" className="mt-6">
              <div className="bg-card rounded-xl p-6 shadow-card">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="text-xl font-semibold">Document Review</h2>
                    <p className="text-muted-foreground text-sm">
                      Review and approve customer documents for vehicle claims
                    </p>
                  </div>
                  <Button onClick={() => navigate('/operator/documents')}>
                    <FileText className="w-4 h-4 mr-2" />
                    Review Documents
                  </Button>
                </div>
                <p className="text-muted-foreground">
                  View pending documents submitted by customers and approve or reject them to proceed with vehicle releases.
                </p>
              </div>
            </TabsContent>

            <TabsContent value="activity" className="mt-6">
              <ActivityLogsSection towYardId={selectedYard} />
            </TabsContent>

            <TabsContent value="disputes" className="mt-6">
              <div className="bg-card rounded-xl p-6 shadow-card">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h2 className="text-xl font-semibold">Dispute Resolution</h2>
                    <p className="text-muted-foreground text-sm">
                      Review and resolve customer disputes for vehicle damages, overcharges, and more
                    </p>
                  </div>
                  <Button onClick={() => navigate('/operator/disputes')}>
                    <Scale className="w-4 h-4 mr-2" />
                    Manage Disputes
                  </Button>
                </div>
                <p className="text-muted-foreground">
                  Handle customer complaints, review submitted evidence, request additional documentation, and resolve disputes fairly.
                </p>
              </div>
            </TabsContent>

            {canManage && (
              <TabsContent value="settings" className="mt-6">
                <FeeConfigurationManager towYardId={selectedYard} />
              </TabsContent>
            )}

            {canManage && (
              <TabsContent value="payouts" className="mt-6">
                <PayoutSettingsManager towYardId={selectedYard} />
              </TabsContent>
            )}

            <TabsContent value="subscription" className="mt-6">
              <SubscriptionSection />
            </TabsContent>

            <TabsContent value="analytics" className="mt-6">
              <AnalyticsSection towYardId={selectedYard} />
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <PageFooter />

      {selectedYard && (
        <AddRecordDialog
          isOpen={showAddDialog}
          onClose={() => setShowAddDialog(false)}
          towYardId={selectedYard}
          onSuccess={() => {
            setShowAddDialog(false);
            // Refresh will happen via component remount
          }}
        />
      )}

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => {
          setShowAuthModal(false);
          if (!user) navigate('/');
        }}
        onSuccess={() => setShowAuthModal(false)}
      />

      {/* Mobile Quick Actions FAB */}
      {canEdit && (
        <QuickActionsMenu
          onAddRecord={() => setShowAddDialog(true)}
          onOpenFeeCalculator={() => setActiveTab('settings')}
          onNavigateToDisputes={() => setActiveTab('disputes')}
          onNavigateToActivity={() => setActiveTab('activity')}
          onNavigateToRecords={() => setActiveTab('records')}
        />
      )}
    </div>
  );
}
