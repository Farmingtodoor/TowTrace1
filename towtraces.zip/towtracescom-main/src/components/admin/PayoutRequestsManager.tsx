import { useState, useEffect } from 'react';
import {
  CheckCircle,
  XCircle,
  Clock,
  Loader2,
  ArrowUpRight,
  Building2,
  BadgeCheck,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';
import { format } from 'date-fns';

interface PayoutRequestRow {
  id: string;
  tow_yard_id: string;
  requested_by_user_id: string;
  amount: number;
  status: string;
  payout_method: string;
  notes: string | null;
  reviewed_by_user_id: string | null;
  reviewed_at: string | null;
  created_at: string;
  yard_name?: string;
  requester_email?: string;
}

export function PayoutRequestsManager() {
  const { user } = useAuth();
  const [requests, setRequests] = useState<PayoutRequestRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedRequest, setSelectedRequest] = useState<PayoutRequestRow | null>(null);
  const [reviewAction, setReviewAction] = useState<'approve' | 'reject' | 'complete' | null>(null);
  const [reviewNotes, setReviewNotes] = useState('');
  const [processing, setProcessing] = useState(false);

  useEffect(() => {
    fetchRequests();
  }, []);

  const fetchRequests = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('payout_requests')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(100);

    if (error) {
      console.error('Error fetching payout requests:', error);
      setLoading(false);
      return;
    }

    // Enrich with yard names and requester emails
    const enriched: PayoutRequestRow[] = [];
    const yardIds = [...new Set((data || []).map((r: any) => r.tow_yard_id))];
    const userIds = [...new Set((data || []).map((r: any) => r.requested_by_user_id))];

    const [{ data: yards }, { data: profiles }] = await Promise.all([
      supabase.from('tow_yards').select('id, name').in('id', yardIds),
      supabase.from('profiles').select('user_id, email, full_name').in('user_id', userIds),
    ]);

    const yardMap = new Map(yards?.map((y) => [y.id, y.name]) || []);
    const profileMap = new Map(profiles?.map((p) => [p.user_id, p.email || p.full_name || 'Unknown']) || []);

    for (const req of data || []) {
      enriched.push({
        ...(req as any),
        yard_name: yardMap.get(req.tow_yard_id) || 'Unknown Yard',
        requester_email: profileMap.get(req.requested_by_user_id) || 'Unknown',
      });
    }

    setRequests(enriched);
    setLoading(false);
  };

  const handleReview = async () => {
    if (!selectedRequest || !reviewAction || !user) return;
    setProcessing(true);

    try {
      const newStatus = reviewAction === 'approve' ? 'approved' : reviewAction === 'complete' ? 'completed' : 'rejected';
      const updateData: any = {
        status: newStatus,
      };
      // Only set reviewed fields on initial approve/reject, not on complete
      if (reviewAction !== 'complete') {
        updateData.reviewed_by_user_id = user.id;
        updateData.reviewed_at = new Date().toISOString();
      }
      if (reviewAction === 'complete') {
        updateData.completed_at = new Date().toISOString();
      }
      if (reviewNotes) {
        updateData.notes = reviewNotes;
      }
      const { error } = await supabase
        .from('payout_requests')
        .update(updateData)
        .eq('id', selectedRequest.id);

      if (error) throw error;

      // Notify the requester (in-app)
      const actionLabel = reviewAction === 'complete' ? 'Completed' : reviewAction === 'approve' ? 'Approved' : 'Rejected';
      await supabase.from('notifications').insert({
        user_id: selectedRequest.requested_by_user_id,
        title: `Payout ${actionLabel}`,
        message: `Your ${formatCurrency(selectedRequest.amount)} payout request has been ${newStatus}.${reviewNotes ? ` Note: ${reviewNotes}` : ''}`,
        type: 'payout',
        entity_type: 'payout_request',
        entity_id: selectedRequest.id,
      });

      // Send email notification
      if (selectedRequest.requester_email && selectedRequest.requester_email !== 'Unknown') {
        await supabase.functions.invoke('send-notification', {
          body: {
            type: 'payout_status_changed',
            to: selectedRequest.requester_email,
            name: selectedRequest.requester_email.split('@')[0],
            data: {
              amount: selectedRequest.amount.toFixed(2),
              status: actionLabel,
              payoutMethod: selectedRequest.payout_method.replace('_', ' '),
              yardName: selectedRequest.yard_name,
              notes: reviewNotes || '',
            },
          },
        });
      }

      toast.success(`Payout request ${newStatus}`);
      setSelectedRequest(null);
      setReviewAction(null);
      setReviewNotes('');
      fetchRequests();
    } catch (err) {
      console.error('Review error:', err);
      toast.error('Failed to process payout request');
    } finally {
      setProcessing(false);
    }
  };

  const formatCurrency = (amount: number) =>
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);

  const statusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="secondary"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      case 'approved':
        return <Badge className="bg-success text-success-foreground"><CheckCircle className="w-3 h-3 mr-1" />Approved</Badge>;
      case 'rejected':
        return <Badge variant="destructive"><XCircle className="w-3 h-3 mr-1" />Rejected</Badge>;
      case 'completed':
        return <Badge className="bg-primary text-primary-foreground"><CheckCircle className="w-3 h-3 mr-1" />Completed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const pendingCount = requests.filter((r) => r.status === 'pending').length;

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold">{requests.length}</p>
            <p className="text-xs text-muted-foreground">Total Requests</p>
          </CardContent>
        </Card>
        <Card className={pendingCount > 0 ? 'border-warning/50' : ''}>
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-warning">{pendingCount}</p>
            <p className="text-xs text-muted-foreground">Pending Review</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold text-success">
              {formatCurrency(requests.filter((r) => r.status === 'approved').reduce((s, r) => s + r.amount, 0))}
            </p>
            <p className="text-xs text-muted-foreground">Approved Total</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <p className="text-2xl font-bold">
              {formatCurrency(requests.filter((r) => r.status === 'pending').reduce((s, r) => s + r.amount, 0))}
            </p>
            <p className="text-xs text-muted-foreground">Pending Amount</p>
          </CardContent>
        </Card>
      </div>

      {/* Requests Table */}
      {requests.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <ArrowUpRight className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground">No payout requests yet</p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Payout Requests</CardTitle>
            <CardDescription>Review and manage withdrawal requests from tow companies</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Company</TableHead>
                  <TableHead>Requested By</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Method</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {requests.map((req) => (
                  <TableRow key={req.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-muted-foreground" />
                        {req.yard_name}
                      </div>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">{req.requester_email}</TableCell>
                    <TableCell className="font-semibold">{formatCurrency(req.amount)}</TableCell>
                    <TableCell className="text-sm capitalize">{req.payout_method.replace('_', ' ')}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {format(new Date(req.created_at), 'MMM d, yyyy')}
                    </TableCell>
                    <TableCell>{statusBadge(req.status)}</TableCell>
                    <TableCell className="text-right">
                      {req.status === 'pending' ? (
                        <div className="flex gap-2 justify-end">
                          <Button
                            size="sm"
                            onClick={() => {
                              setSelectedRequest(req);
                              setReviewAction('approve');
                              setReviewNotes('');
                            }}
                          >
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Approve
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => {
                              setSelectedRequest(req);
                              setReviewAction('reject');
                              setReviewNotes('');
                            }}
                          >
                            <XCircle className="w-3 h-3 mr-1" />
                            Reject
                          </Button>
                        </div>
                      ) : req.status === 'approved' ? (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setSelectedRequest(req);
                            setReviewAction('complete');
                            setReviewNotes('');
                          }}
                        >
                          <BadgeCheck className="w-3 h-3 mr-1" />
                          Mark Completed
                        </Button>
                      ) : (
                        <span className="text-xs text-muted-foreground">
                          {req.status === 'completed' && (req as any).completed_at
                            ? `Completed ${format(new Date((req as any).completed_at), 'MMM d')}`
                            : req.reviewed_at
                            ? `Reviewed ${format(new Date(req.reviewed_at), 'MMM d')}`
                            : '—'}
                        </span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Review Dialog */}
      <Dialog
        open={!!selectedRequest && !!reviewAction}
        onOpenChange={(open) => {
          if (!open) {
            setSelectedRequest(null);
            setReviewAction(null);
          }
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {reviewAction === 'approve' ? 'Approve' : reviewAction === 'complete' ? 'Complete' : 'Reject'} Payout Request
            </DialogTitle>
            <DialogDescription>
              {selectedRequest && (
                <>
                  {formatCurrency(selectedRequest.amount)} requested by{' '}
                  <strong>{selectedRequest.yard_name}</strong> via{' '}
                  {selectedRequest.payout_method.replace('_', ' ')}
                </>
              )}
            </DialogDescription>
          </DialogHeader>

          {selectedRequest?.notes && (
            <div className="p-3 rounded-lg bg-muted">
              <p className="text-xs text-muted-foreground mb-1">Operator Notes:</p>
              <p className="text-sm">{selectedRequest.notes}</p>
            </div>
          )}

          <div className="space-y-2">
            <Label>Notes (optional)</Label>
            <Textarea
              placeholder={
                reviewAction === 'reject'
                  ? 'Reason for rejection...'
                  : reviewAction === 'complete'
                  ? 'e.g. Transaction ref, transfer date...'
                  : 'Any notes about this approval...'
              }
              value={reviewNotes}
              onChange={(e) => setReviewNotes(e.target.value)}
            />
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => { setSelectedRequest(null); setReviewAction(null); }}>
              Cancel
            </Button>
            <Button
              variant={reviewAction === 'reject' ? 'destructive' : 'default'}
              onClick={handleReview}
              disabled={processing}
            >
              {processing ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Processing...</>
              ) : reviewAction === 'approve' ? (
                <><CheckCircle className="w-4 h-4 mr-2" />Approve Payout</>
              ) : reviewAction === 'complete' ? (
                <><BadgeCheck className="w-4 h-4 mr-2" />Mark Completed</>
              ) : (
                <><XCircle className="w-4 h-4 mr-2" />Reject Request</>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
