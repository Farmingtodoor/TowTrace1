import { useState, useEffect } from 'react';
import { format } from 'date-fns';
import {
  Building2,
  MapPin,
  Phone,
  Mail,
  CheckCircle,
  XCircle,
  CreditCard,
  Clock,
  Users,
  Car,
  FileText,
  Eye,
  Loader2,
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { supabase } from '@/integrations/supabase/client';
import type { TowYard } from './TowYardManagementTable';

interface TowRecord {
  id: string;
  plate_number: string | null;
  vin: string | null;
  make: string | null;
  model: string | null;
  status: string;
  tow_datetime: string;
  driver_name: string | null;
  tow_reason: string | null;
}

interface AuditLog {
  id: string;
  action: string;
  entity_type: string;
  created_at: string;
  metadata_json: any;
}

interface TowYardDetailsDialogProps {
  yard: TowYard | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onApprove: (yardId: string, approve: boolean) => void;
}

export function TowYardDetailsDialog({
  yard,
  open,
  onOpenChange,
  onApprove,
}: TowYardDetailsDialogProps) {
  const [records, setRecords] = useState<TowRecord[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [loadingRecords, setLoadingRecords] = useState(false);
  const [loadingLogs, setLoadingLogs] = useState(false);

  useEffect(() => {
    if (open && yard) {
      fetchRecords(yard.id);
      fetchAuditLogs(yard.id);
    }
  }, [open, yard?.id]);

  const fetchRecords = async (yardId: string) => {
    setLoadingRecords(true);
    const { data } = await supabase
      .from('tow_records')
      .select('id, plate_number, vin, make, model, status, tow_datetime, driver_name, tow_reason')
      .eq('tow_yard_id', yardId)
      .order('tow_datetime', { ascending: false })
      .limit(25);
    setRecords(data || []);
    setLoadingRecords(false);
  };

  const fetchAuditLogs = async (yardId: string) => {
    setLoadingLogs(true);
    const { data } = await supabase
      .from('audit_logs')
      .select('id, action, entity_type, created_at, metadata_json')
      .eq('entity_id', yardId)
      .order('created_at', { ascending: false })
      .limit(25);
    setAuditLogs(data || []);
    setLoadingLogs(false);
  };

  if (!yard) return null;

  const statusColor: Record<string, string> = {
    towed: 'bg-warning/10 text-warning border-warning/20',
    docs_pending: 'bg-accent/10 text-accent border-accent/20',
    docs_approved: 'bg-primary/10 text-primary border-primary/20',
    paid: 'bg-success/10 text-success border-success/20',
    released: 'bg-muted text-muted-foreground border-muted',
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Building2 className="w-5 h-5" />
            Tow Yard Details
            <Badge variant="outline" className="ml-2 text-xs font-normal">
              <Eye className="w-3 h-3 mr-1" />
              View Only
            </Badge>
          </DialogTitle>
        </DialogHeader>
        
        <Tabs defaultValue="details" className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="details">Details</TabsTrigger>
            <TabsTrigger value="records" className="gap-1">
              <Car className="w-3.5 h-3.5" />
              Records
            </TabsTrigger>
            <TabsTrigger value="activity" className="gap-1">
              <FileText className="w-3.5 h-3.5" />
              Activity
            </TabsTrigger>
          </TabsList>

          {/* Details Tab */}
          <TabsContent value="details" className="space-y-6">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-semibold text-xl">{yard.name}</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Applied on {format(new Date(yard.created_at), 'MMMM d, yyyy')}
                </p>
              </div>
              {yard.is_approved ? (
                <Badge className="bg-success/10 text-success border-success/20">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Approved
                </Badge>
              ) : (
                <Badge variant="outline" className="text-warning border-warning/30 bg-warning/10">
                  <Clock className="w-3 h-3 mr-1" />
                  Pending Review
                </Badge>
              )}
            </div>

            <Separator />

            <div className="space-y-3">
              <h4 className="font-medium flex items-center gap-2 text-sm">
                <MapPin className="w-4 h-4 text-muted-foreground" />
                Location
              </h4>
              <div className="bg-muted/50 rounded-lg p-4 space-y-1">
                <p className="font-medium">{yard.address}</p>
                <p className="text-muted-foreground">{yard.city}, {yard.state_province}</p>
                <p className="text-muted-foreground">{yard.country}</p>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-medium text-sm">Contact Information</h4>
              <div className="grid gap-3">
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Phone</p>
                    <p className="font-medium">{yard.phone}</p>
                  </div>
                </div>
                {yard.email && (
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                    <Mail className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <p className="text-xs text-muted-foreground">Email</p>
                      <p className="font-medium">{yard.email}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {(yard.operator_count !== undefined || yard.record_count !== undefined) && (
              <>
                <Separator />
                <div className="grid grid-cols-2 gap-4">
                  {yard.operator_count !== undefined && (
                    <div className="text-center p-4 rounded-lg bg-muted/50">
                      <Users className="w-5 h-5 mx-auto mb-2 text-muted-foreground" />
                      <p className="text-2xl font-bold">{yard.operator_count}</p>
                      <p className="text-xs text-muted-foreground">Operators</p>
                    </div>
                  )}
                  {yard.record_count !== undefined && (
                    <div className="text-center p-4 rounded-lg bg-muted/50">
                      <CreditCard className="w-5 h-5 mx-auto mb-2 text-muted-foreground" />
                      <p className="text-2xl font-bold">{yard.record_count}</p>
                      <p className="text-xs text-muted-foreground">Tow Records</p>
                    </div>
                  )}
                </div>
              </>
            )}
          </TabsContent>

          {/* Records Tab - Read Only */}
          <TabsContent value="records" className="space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                Recent tow records for this company (read-only)
              </p>
              <Badge variant="outline" className="text-xs">
                {records.length} shown
              </Badge>
            </div>
            {loadingRecords ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
              </div>
            ) : records.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground text-sm">
                No tow records found for this company.
              </div>
            ) : (
              <div className="rounded-lg border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/30">
                      <TableHead className="text-xs">Vehicle</TableHead>
                      <TableHead className="text-xs">Plate/VIN</TableHead>
                      <TableHead className="text-xs">Status</TableHead>
                      <TableHead className="text-xs">Date</TableHead>
                      <TableHead className="text-xs">Driver</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {records.map((rec) => (
                      <TableRow key={rec.id}>
                        <TableCell className="text-sm">
                          {rec.make && rec.model ? `${rec.make} ${rec.model}` : '—'}
                        </TableCell>
                        <TableCell className="text-sm font-mono">
                          {rec.plate_number || rec.vin?.slice(0, 8) || '—'}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className={`text-xs ${statusColor[rec.status] || ''}`}>
                            {rec.status.replace('_', ' ')}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {format(new Date(rec.tow_datetime), 'MMM d, yyyy')}
                        </TableCell>
                        <TableCell className="text-sm">
                          {rec.driver_name || '—'}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </TabsContent>

          {/* Activity Tab - Read Only */}
          <TabsContent value="activity" className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Recent activity logs for this company (read-only)
            </p>
            {loadingLogs ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
              </div>
            ) : auditLogs.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground text-sm">
                No activity logs found for this company.
              </div>
            ) : (
              <div className="space-y-2">
                {auditLogs.map((log) => (
                  <div key={log.id} className="flex items-start gap-3 p-3 rounded-lg bg-muted/30 border">
                    <div className="p-1.5 rounded bg-primary/10 mt-0.5">
                      <FileText className="w-3.5 h-3.5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium capitalize">
                        {log.action.replace(/_/g, ' ')}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {log.entity_type} · {format(new Date(log.created_at), 'MMM d, yyyy h:mm a')}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>

        <DialogFooter className="gap-2 sm:gap-0">
          {yard.is_approved ? (
            <Button
              variant="outline"
              className="text-destructive border-destructive/50 hover:bg-destructive/10"
              onClick={() => {
                onApprove(yard.id, false);
                onOpenChange(false);
              }}
            >
              <XCircle className="w-4 h-4 mr-2" />
              Revoke Approval
            </Button>
          ) : (
            <Button
              className="bg-success hover:bg-success/90"
              onClick={() => {
                onApprove(yard.id, true);
                onOpenChange(false);
              }}
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Approve Company
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
