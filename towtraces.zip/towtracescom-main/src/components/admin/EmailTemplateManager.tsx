import { useState, useEffect } from 'react';
import { format } from 'date-fns';
import DOMPurify from 'dompurify';
import {
  Mail,
  Edit,
  Save,
  X,
  Eye,
  Code,
  Loader2,
  Info,
  RefreshCw,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface EmailTemplate {
  id: string;
  template_key: string;
  name: string;
  subject: string;
  html_body: string;
  description: string | null;
  created_at: string;
  updated_at: string;
}

const TEMPLATE_VARIABLES = [
  { variable: '{{company_name}}', description: 'The name of the tow company' },
  { variable: '{{dashboard_url}}', description: 'Link to the operator dashboard' },
];

export function EmailTemplateManager() {
  const { toast } = useToast();
  const [templates, setTemplates] = useState<EmailTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  
  // Edit state
  const [editingTemplate, setEditingTemplate] = useState<EmailTemplate | null>(null);
  const [editSubject, setEditSubject] = useState('');
  const [editBody, setEditBody] = useState('');
  
  // Preview state
  const [previewTemplate, setPreviewTemplate] = useState<EmailTemplate | null>(null);
  const [previewTab, setPreviewTab] = useState<'preview' | 'code'>('preview');

  useEffect(() => {
    fetchTemplates();
  }, []);

  const fetchTemplates = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('email_templates')
      .select('*')
      .order('name');

    if (error) {
      toast({
        title: 'Error',
        description: 'Failed to load email templates.',
        variant: 'destructive',
      });
    } else {
      setTemplates(data || []);
    }
    setLoading(false);
  };

  const handleEdit = (template: EmailTemplate) => {
    setEditingTemplate(template);
    setEditSubject(template.subject);
    setEditBody(template.html_body);
  };

  const handleCancelEdit = () => {
    setEditingTemplate(null);
    setEditSubject('');
    setEditBody('');
  };

  const handleSave = async () => {
    if (!editingTemplate) return;
    
    setSaving(true);
    const { error } = await supabase
      .from('email_templates')
      .update({
        subject: editSubject,
        html_body: editBody,
      })
      .eq('id', editingTemplate.id);

    if (error) {
      toast({
        title: 'Error',
        description: 'Failed to save template.',
        variant: 'destructive',
      });
    } else {
      toast({
        title: 'Template Saved',
        description: 'Email template has been updated successfully.',
      });
      fetchTemplates();
      handleCancelEdit();
    }
    setSaving(false);
  };

  const getPreviewHtml = (html: string) => {
    const interpolatedHtml = html
      .replace(/\{\{company_name\}\}/g, 'ABC Towing Services')
      .replace(/\{\{dashboard_url\}\}/g, '#');
    
    // Sanitize HTML to prevent XSS attacks
    return DOMPurify.sanitize(interpolatedHtml, {
      ALLOWED_TAGS: ['div', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'strong', 'em', 'a', 'ul', 'ol', 'li', 'br', 'span', 'table', 'tr', 'td', 'th', 'thead', 'tbody', 'img', 'hr', 'blockquote', 'pre', 'code'],
      ALLOWED_ATTR: ['href', 'style', 'class', 'src', 'alt', 'width', 'height', 'target', 'rel'],
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold text-lg flex items-center gap-2">
            <Mail className="w-5 h-5" />
            Email Templates
          </h3>
          <p className="text-sm text-muted-foreground">
            Customize the emails sent to tow company operators
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={fetchTemplates}>
          <RefreshCw className="w-4 h-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* Variable Reference */}
      <Card className="bg-info/5 border-info/20">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <Info className="w-4 h-4 text-info" />
            Available Variables
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="flex flex-wrap gap-2">
            {TEMPLATE_VARIABLES.map((v) => (
              <TooltipProvider key={v.variable}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Badge variant="secondary" className="font-mono text-xs cursor-help">
                      {v.variable}
                    </Badge>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>{v.description}</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Template Cards */}
      <div className="grid gap-4">
        {templates.map((template) => (
          <Card key={template.id} className="overflow-hidden">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-base">{template.name}</CardTitle>
                  <CardDescription className="mt-1">
                    {template.description}
                  </CardDescription>
                </div>
                <Badge variant="outline" className="font-mono text-xs">
                  {template.template_key}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-3">
                <div>
                  <Label className="text-xs text-muted-foreground">Subject Line</Label>
                  <p className="text-sm font-medium mt-1">{template.subject}</p>
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  Last updated: {format(new Date(template.updated_at), 'MMM d, yyyy h:mm a')}
                </div>
                <div className="flex gap-2 pt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPreviewTemplate(template)}
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    Preview
                  </Button>
                  <Button
                    variant="default"
                    size="sm"
                    onClick={() => handleEdit(template)}
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    Edit
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Edit Dialog */}
      <Dialog open={!!editingTemplate} onOpenChange={() => handleCancelEdit()}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle>Edit Template: {editingTemplate?.name}</DialogTitle>
          </DialogHeader>
          
          <div className="flex-1 overflow-y-auto space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="subject">Subject Line</Label>
              <Input
                id="subject"
                value={editSubject}
                onChange={(e) => setEditSubject(e.target.value)}
                placeholder="Email subject..."
              />
              <p className="text-xs text-muted-foreground">
                You can use variables like {'{{company_name}}'} in the subject
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="body">HTML Body</Label>
              <Textarea
                id="body"
                value={editBody}
                onChange={(e) => setEditBody(e.target.value)}
                placeholder="Email HTML content..."
                className="font-mono text-sm min-h-[300px]"
              />
            </div>

            {/* Live Preview */}
            <div className="space-y-2">
              <Label>Live Preview</Label>
              <div className="border rounded-lg p-4 bg-white">
                <div
                  dangerouslySetInnerHTML={{ __html: getPreviewHtml(editBody) }}
                />
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={handleCancelEdit}>
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
            <Button onClick={handleSave} disabled={saving}>
              {saving ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Save className="w-4 h-4 mr-2" />
              )}
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Preview Dialog */}
      <Dialog open={!!previewTemplate} onOpenChange={() => setPreviewTemplate(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle>Preview: {previewTemplate?.name}</DialogTitle>
          </DialogHeader>
          
          <Tabs value={previewTab} onValueChange={(v) => setPreviewTab(v as 'preview' | 'code')}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="preview" className="gap-2">
                <Eye className="w-4 h-4" />
                Preview
              </TabsTrigger>
              <TabsTrigger value="code" className="gap-2">
                <Code className="w-4 h-4" />
                HTML Code
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="preview" className="mt-4">
              <ScrollArea className="h-[500px]">
                <div className="bg-muted/50 rounded-lg p-4">
                  <div className="bg-muted rounded p-3 mb-4">
                    <p className="text-xs text-muted-foreground">Subject:</p>
                    <p className="font-medium">
                      {previewTemplate?.subject.replace(/\{\{company_name\}\}/g, 'ABC Towing Services')}
                    </p>
                  </div>
                  <div className="bg-white rounded-lg p-4 shadow-sm">
                    {previewTemplate && (
                      <div
                        dangerouslySetInnerHTML={{
                          __html: getPreviewHtml(previewTemplate.html_body),
                        }}
                      />
                    )}
                  </div>
                </div>
              </ScrollArea>
            </TabsContent>
            
            <TabsContent value="code" className="mt-4">
              <ScrollArea className="h-[500px]">
                <pre className="bg-muted rounded-lg p-4 text-xs font-mono overflow-x-auto whitespace-pre-wrap">
                  {previewTemplate?.html_body}
                </pre>
              </ScrollArea>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </div>
  );
}
