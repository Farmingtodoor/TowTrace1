import { useState, useEffect } from 'react';
import { Mail, RefreshCw, UserPlus, RotateCw, CheckCircle, Loader2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { format, formatDistanceToNow } from 'date-fns';

interface InvitationLog {
  id: string;
  tow_yard_name: string;
  invited_email: string;
  invited_name: string | null;
  inviter_name: string;
  permission_level: string;
  event_type: 'invited' | 'resent' | 'accepted';
  is_new_user: boolean;
  created_at: string;
}

const eventConfig = {
  invited: {
    icon: UserPlus,
    label: 'Invited',
    badgeClass: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
  },
  resent: {
    icon: RotateCw,
    label: 'Resent',
    badgeClass: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400',
  },
  accepted: {
    icon: CheckCircle,
    label: 'Accepted',
    badgeClass: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400',
  },
};

export function InvitationActivityPanel() {
  const [logs, setLogs] = useState<InvitationLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchLogs = async () => {
    const { data, error } = await supabase
      .from('invitation_logs')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(30);

    if (!error && data) {
      setLogs(data as unknown as InvitationLog[]);
    }
    setLoading(false);
    setRefreshing(false);
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchLogs();
  };

  if (loading) {
    return (
      <div className="bg-card rounded-xl shadow-card p-6">
        <div className="flex items-center gap-2 mb-4">
          <Mail className="w-5 h-5 text-primary" />
          <h3 className="font-display font-semibold text-lg">Invitation Activity</h3>
        </div>
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-xl shadow-card overflow-hidden">
      <div className="px-4 py-3 border-b border-border flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Mail className="w-5 h-5 text-primary" />
          <h3 className="font-display font-semibold">Invitation Activity</h3>
          <Badge variant="outline" className="ml-1 text-xs">
            {logs.length} recent
          </Badge>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8"
          onClick={handleRefresh}
          disabled={refreshing}
        >
          <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
        </Button>
      </div>

      {logs.length === 0 ? (
        <div className="px-4 py-8 text-center text-muted-foreground text-sm">
          No invitation activity yet.
        </div>
      ) : (
        <div className="divide-y divide-border max-h-[400px] overflow-y-auto">
          {logs.map((log) => {
            const config = eventConfig[log.event_type] || eventConfig.invited;
            const Icon = config.icon;

            return (
              <div key={log.id} className="px-4 py-3 hover:bg-muted/50 transition-colors">
                <div className="flex items-start gap-3">
                  <div className="mt-0.5 p-1.5 rounded-md bg-muted shrink-0">
                    <Icon className="w-3.5 h-3.5 text-muted-foreground" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-medium text-sm truncate">
                        {log.invited_name || log.invited_email}
                      </span>
                      <span className={`text-xs px-1.5 py-0.5 rounded-full font-medium ${config.badgeClass}`}>
                        {config.label}
                      </span>
                    </div>
                    {log.invited_name && (
                      <p className="text-xs text-muted-foreground truncate">{log.invited_email}</p>
                    )}
                    <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                      <span className="truncate">{log.tow_yard_name}</span>
                      <span>·</span>
                      <span className="capitalize">{log.permission_level}</span>
                      <span>·</span>
                      <span title={format(new Date(log.created_at), 'PPpp')}>
                        {formatDistanceToNow(new Date(log.created_at), { addSuffix: true })}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      by {log.inviter_name}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
