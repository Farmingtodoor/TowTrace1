import { format } from 'date-fns';
import {
  CheckCircle,
  XCircle,
  MoreVertical,
  Eye,
  MapPin,
  Phone,
  Mail,
  AlertCircle,
  Building2,
  Users,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

export interface TowYard {
  id: string;
  name: string;
  city: string;
  state_province: string;
  country: string;
  phone: string;
  email: string | null;
  address: string;
  is_approved: boolean;
  created_at: string;
  operator_count?: number;
  record_count?: number;
}

interface TowYardManagementTableProps {
  yards: TowYard[];
  onApprove: (yardId: string, approve: boolean) => void;
  onViewDetails: (yard: TowYard) => void;
}

export function TowYardManagementTable({ yards, onApprove, onViewDetails }: TowYardManagementTableProps) {
  return (
    <div className="bg-card rounded-xl shadow-card border overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/30 hover:bg-muted/30">
            <TableHead className="font-semibold">Company</TableHead>
            <TableHead className="font-semibold">Location</TableHead>
            <TableHead className="font-semibold">Contact</TableHead>
            <TableHead className="font-semibold">Status</TableHead>
            <TableHead className="font-semibold">Applied</TableHead>
            <TableHead className="w-[100px] font-semibold">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {yards.length === 0 ? (
            <TableRow>
              <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                No tow yards found
              </TableCell>
            </TableRow>
          ) : (
            yards.map((yard) => (
              <TableRow key={yard.id} className="group">
                <TableCell>
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Building2 className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-semibold">{yard.name}</p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        {yard.operator_count !== undefined && (
                          <span className="flex items-center gap-1">
                            <Users className="w-3 h-3" />
                            {yard.operator_count} operators
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-start gap-2">
                    <MapPin className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
                    <div className="text-sm">
                      <p>{yard.city}, {yard.state_province}</p>
                      <p className="text-muted-foreground">{yard.country}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="space-y-1 text-sm">
                    <div className="flex items-center gap-2">
                      <Phone className="w-3.5 h-3.5 text-muted-foreground" />
                      <span>{yard.phone}</span>
                    </div>
                    {yard.email && (
                      <div className="flex items-center gap-2">
                        <Mail className="w-3.5 h-3.5 text-muted-foreground" />
                        <span className="truncate max-w-[150px]">{yard.email}</span>
                      </div>
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  {yard.is_approved ? (
                    <Badge className="bg-success/10 text-success border-success/20 hover:bg-success/20">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Approved
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="text-warning border-warning/30 bg-warning/10">
                      <AlertCircle className="w-3 h-3 mr-1" />
                      Pending
                    </Badge>
                  )}
                </TableCell>
                <TableCell className="text-muted-foreground text-sm">
                  {format(new Date(yard.created_at), 'MMM d, yyyy')}
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-1">
                    {!yard.is_approved && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-success hover:text-success hover:bg-success/10"
                        onClick={() => onApprove(yard.id, true)}
                      >
                        <CheckCircle className="w-4 h-4" />
                      </Button>
                    )}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-48">
                        <DropdownMenuItem onClick={() => onViewDetails(yard)}>
                          <Eye className="w-4 h-4 mr-2" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        {!yard.is_approved ? (
                          <DropdownMenuItem
                            onClick={() => onApprove(yard.id, true)}
                            className="text-success"
                          >
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Approve Company
                          </DropdownMenuItem>
                        ) : (
                          <DropdownMenuItem
                            onClick={() => onApprove(yard.id, false)}
                            className="text-destructive"
                          >
                            <XCircle className="w-4 h-4 mr-2" />
                            Revoke Approval
                          </DropdownMenuItem>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}
