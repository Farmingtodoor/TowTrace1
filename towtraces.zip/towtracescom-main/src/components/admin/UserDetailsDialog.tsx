import { format } from 'date-fns';
import {
  User,
  Mail,
  Calendar,
  Shield,
  Building2,
  Copy,
  ExternalLink,
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useToast } from '@/hooks/use-toast';
import type { UserWithRole } from './UserManagementTable';

interface UserDetailsDialogProps {
  user: UserWithRole | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAddRole: (userId: string, role: 'operator' | 'admin' | 'reviewer' | 'analyst' | 'super_admin') => void;
  onRemoveRole: (userId: string, role: 'consumer' | 'operator' | 'admin' | 'reviewer' | 'analyst' | 'super_admin') => void;
}

export function UserDetailsDialog({
  user,
  open,
  onOpenChange,
  onAddRole,
  onRemoveRole,
}: UserDetailsDialogProps) {
  const { toast } = useToast();

  if (!user) return null;

  const getInitials = (email: string, name?: string) => {
    if (name) {
      return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
    }
    return email.slice(0, 2).toUpperCase();
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: 'Copied to clipboard' });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>User Details</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* User Header */}
          <div className="flex items-center gap-4">
            <Avatar className="h-16 w-16 border-2">
              <AvatarFallback className="bg-primary/10 text-primary text-xl font-semibold">
                {getInitials(user.email, user.full_name)}
              </AvatarFallback>
            </Avatar>
            <div className="space-y-1">
              <h3 className="font-semibold text-lg">{user.full_name || 'User'}</h3>
              <p className="text-sm text-muted-foreground">{user.email}</p>
            </div>
          </div>

          <Separator />

          {/* Info Grid */}
          <div className="grid gap-4">
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">Email</p>
                  <p className="text-sm font-medium">{user.email}</p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => copyToClipboard(user.email)}
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>

            <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
              <div className="flex items-center gap-3">
                <User className="w-4 h-4 text-muted-foreground" />
                <div>
                  <p className="text-xs text-muted-foreground">User ID</p>
                  <p className="text-sm font-mono">{user.id.slice(0, 8)}...</p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => copyToClipboard(user.id)}
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>

            <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
              <Calendar className="w-4 h-4 text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Member Since</p>
                <p className="text-sm font-medium">{format(new Date(user.created_at), 'MMMM d, yyyy')}</p>
              </div>
            </div>
          </div>

          <Separator />

          {/* Roles Section */}
          <div className="space-y-3">
            <h4 className="font-medium flex items-center gap-2">
              <Shield className="w-4 h-4" />
              User Roles
            </h4>
            <div className="flex flex-wrap gap-2">
              {user.roles.length > 0 ? (
                user.roles.map((role) => (
                  <Badge
                    key={role}
                    variant={
                      role === 'super_admin' || role === 'admin'
                        ? 'destructive'
                        : role === 'operator'
                          ? 'default'
                          : role === 'reviewer'
                            ? 'secondary'
                            : 'outline'
                    }
                    className="px-3 py-1"
                  >
                    {role}
                    <button
                      className="ml-2 hover:text-destructive-foreground/80"
                      onClick={() =>
                        onRemoveRole(
                          user.id,
                          role as 'consumer' | 'operator' | 'admin' | 'reviewer' | 'analyst' | 'super_admin'
                        )
                      }
                    >
                      ×
                    </button>
                  </Badge>
                ))
              ) : (
                <Badge variant="outline" className="px-3 py-1">consumer</Badge>
              )}
            </div>

            {/* Add Role Buttons */}
            <div className="flex gap-2 pt-2 flex-wrap">
              {!user.roles.includes('operator') && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onAddRole(user.id, 'operator')}
                >
                  <Building2 className="w-4 h-4 mr-2" />
                  Add Operator
                </Button>
              )}
              {!user.roles.includes('reviewer') && (
                <Button variant="outline" size="sm" onClick={() => onAddRole(user.id, 'reviewer')}>
                  <Shield className="w-4 h-4 mr-2" />
                  Add Reviewer
                </Button>
              )}
              {!user.roles.includes('analyst') && (
                <Button variant="outline" size="sm" onClick={() => onAddRole(user.id, 'analyst')}>
                  <Shield className="w-4 h-4 mr-2" />
                  Add Analyst
                </Button>
              )}
              {!user.roles.includes('admin') && (
                <Button
                  variant="outline"
                  size="sm"
                  className="border-destructive/50 text-destructive hover:bg-destructive/10"
                  onClick={() => onAddRole(user.id, 'admin')}
                >
                  <Shield className="w-4 h-4 mr-2" />
                  Add Admin
                </Button>
              )}
              {!user.roles.includes('super_admin') && (
                <Button
                  variant="outline"
                  size="sm"
                  className="border-destructive/50 text-destructive hover:bg-destructive/10"
                  onClick={() => onAddRole(user.id, 'super_admin')}
                >
                  <Shield className="w-4 h-4 mr-2" />
                  Add Super Admin
                </Button>
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-2">
            <Button variant="outline" className="flex-1" onClick={() => window.open(`mailto:${user.email}`)}>
              <Mail className="w-4 h-4 mr-2" />
              Send Email
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
