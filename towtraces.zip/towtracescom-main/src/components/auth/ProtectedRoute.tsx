import { ReactNode, useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';

type RequiredRole = 'admin' | 'operator';

interface ProtectedRouteProps {
  children: ReactNode;
  requiredRole: RequiredRole;
}

export function ProtectedRoute({ children, requiredRole }: ProtectedRouteProps) {
  const { user, loading: authLoading } = useAuth();
  const [hasAccess, setHasAccess] = useState<boolean | null>(null);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    const checkAccess = async () => {
      if (authLoading) return;
      
      if (!user) {
        setHasAccess(false);
        setChecking(false);
        return;
      }

      const { data } = await supabase.rpc('check_user_access', {
        _user_id: user.id,
        _required_role: requiredRole,
      } as any);

      setHasAccess(data === true);
      setChecking(false);
    };

    checkAccess();
  }, [user, authLoading, requiredRole]);

  if (authLoading || checking) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-accent" />
      </div>
    );
  }

  if (!hasAccess) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}
