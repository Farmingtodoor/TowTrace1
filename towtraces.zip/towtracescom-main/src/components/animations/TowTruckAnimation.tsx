import { useEffect, useState } from 'react';

export function TowTruckAnimation() {
  const [position, setPosition] = useState(-100);

  useEffect(() => {
    const interval = setInterval(() => {
      setPosition((prev) => {
        if (prev > 120) return -100;
        return prev + 0.5;
      });
    }, 30);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative w-full h-24 overflow-hidden">
      {/* Road */}
      <div className="absolute bottom-4 left-0 right-0 h-2 bg-muted-foreground/20 rounded-full" />
      <div className="absolute bottom-5 left-0 right-0 flex gap-4 justify-around">
        {[...Array(10)].map((_, i) => (
          <div key={i} className="w-8 h-0.5 bg-muted-foreground/40 rounded-full" />
        ))}
      </div>
      
      {/* Tow Truck */}
      <div 
        className="absolute bottom-6 transition-none"
        style={{ left: `${position}%`, transform: 'translateX(-50%)' }}
      >
        <svg width="120" height="60" viewBox="0 0 120 60" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Towed Car */}
          <g transform="translate(70, 20)">
            <rect x="0" y="10" width="40" height="18" rx="3" className="fill-accent" />
            <rect x="5" y="2" width="25" height="12" rx="2" className="fill-accent" />
            <rect x="8" y="4" width="8" height="6" rx="1" className="fill-accent-foreground/30" />
            <rect x="19" y="4" width="8" height="6" rx="1" className="fill-accent-foreground/30" />
            {/* Wheels */}
            <circle cx="10" cy="28" r="6" className="fill-foreground" />
            <circle cx="10" cy="28" r="3" className="fill-muted" />
            <circle cx="32" cy="28" r="6" className="fill-foreground" />
            <circle cx="32" cy="28" r="3" className="fill-muted" />
          </g>
          
          {/* Tow Bar */}
          <line x1="60" y1="42" x2="70" y2="42" className="stroke-foreground" strokeWidth="2" />
          
          {/* Truck Body */}
          <rect x="10" y="20" width="50" height="25" rx="3" className="fill-primary" />
          <rect x="5" y="30" width="18" height="15" rx="2" className="fill-primary" />
          
          {/* Cab Windows */}
          <rect x="8" y="33" width="12" height="8" rx="1" className="fill-primary-foreground/30" />
          
          {/* Crane/Lift */}
          <rect x="50" y="10" width="4" height="15" className="fill-primary" />
          <rect x="45" y="8" width="14" height="4" rx="1" className="fill-primary" />
          
          {/* Wheels */}
          <circle cx="20" cy="45" r="7" className="fill-foreground" />
          <circle cx="20" cy="45" r="4" className="fill-muted" />
          <circle cx="48" cy="45" r="7" className="fill-foreground" />
          <circle cx="48" cy="45" r="4" className="fill-muted" />
          
          {/* Headlight */}
          <circle cx="6" cy="38" r="2" className="fill-warning" />
        </svg>
      </div>
    </div>
  );
}
