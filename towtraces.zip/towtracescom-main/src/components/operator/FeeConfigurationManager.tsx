import { useState, useEffect, useMemo } from 'react';
import { Settings, Save, Loader2, Car, DollarSign, RotateCcw, Plus, Trash2, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { VEHICLE_TYPES, type VehicleType } from '@/lib/feeCalculator';

interface FeeConfig {
  id?: string;
  vehicle_type: string;
  tow_fee: number;
  daily_storage_fee: number;
  admin_fee: number;
  gate_fee: number;
  label?: string;
  isCustom?: boolean;
}

interface FeeConfigurationManagerProps {
  towYardId: string | null;
}

// Generate defaults from VEHICLE_TYPES using multipliers
function generateDefaultFees(vehicleType: VehicleType): Omit<FeeConfig, 'id' | 'vehicle_type'> {
  const info = VEHICLE_TYPES[vehicleType];
  const m = info.multiplier;
  return {
    tow_fee: Math.round(150 * m * 100) / 100,
    daily_storage_fee: Math.round(45 * m * 100) / 100,
    admin_fee: Math.round(50 * m * 100) / 100,
    gate_fee: 0,
  };
}

export function FeeConfigurationManager({ towYardId }: FeeConfigurationManagerProps) {
  const [configs, setConfigs] = useState<Record<string, FeeConfig>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newTypeName, setNewTypeName] = useState('');
  const [newTypeTowFee, setNewTypeTowFee] = useState(150);
  const [newTypeStorageFee, setNewTypeStorageFee] = useState(45);
  const [newTypeAdminFee, setNewTypeAdminFee] = useState(50);
  const [newTypeGateFee, setNewTypeGateFee] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    if (!towYardId) return;
    fetchConfigs();
  }, [towYardId]);

  const fetchConfigs = async () => {
    if (!towYardId) return;
    setLoading(true);

    const { data, error } = await supabase
      .from('fee_configurations')
      .select('*')
      .eq('tow_yard_id', towYardId);

    if (error) {
      console.error('Error fetching fee configs:', error);
      toast.error('Failed to load fee configurations');
    } else {
      const configMap: Record<string, FeeConfig> = {};
      
      // Initialize with defaults for all preset vehicle types
      Object.keys(VEHICLE_TYPES).forEach((type) => {
        const vehicleType = type as VehicleType;
        configMap[vehicleType] = {
          vehicle_type: vehicleType,
          label: VEHICLE_TYPES[vehicleType].label,
          ...generateDefaultFees(vehicleType),
        };
      });

      // Override with saved configs (includes custom types)
      data?.forEach((config) => {
        const isPreset = config.vehicle_type in VEHICLE_TYPES;
        configMap[config.vehicle_type] = {
          id: config.id,
          vehicle_type: config.vehicle_type,
          tow_fee: Number(config.tow_fee),
          daily_storage_fee: Number(config.daily_storage_fee),
          admin_fee: Number(config.admin_fee),
          gate_fee: Number(config.gate_fee),
          label: isPreset ? VEHICLE_TYPES[config.vehicle_type as VehicleType].label : config.vehicle_type,
          isCustom: !isPreset,
        };
      });

      setConfigs(configMap);
    }
    setLoading(false);
  };

  const updateConfig = (vehicleType: string, field: keyof FeeConfig, value: number) => {
    setConfigs((prev) => ({
      ...prev,
      [vehicleType]: {
        ...prev[vehicleType],
        [field]: value,
      },
    }));
    setHasChanges(true);
  };

  const resetToDefaults = (vehicleType: string) => {
    if (vehicleType in VEHICLE_TYPES) {
      setConfigs((prev) => ({
        ...prev,
        [vehicleType]: {
          ...prev[vehicleType],
          ...generateDefaultFees(vehicleType as VehicleType),
        },
      }));
      setHasChanges(true);
    }
  };

  const addCustomType = () => {
    const trimmed = newTypeName.trim();
    if (!trimmed) {
      toast.error('Please enter a vehicle type name');
      return;
    }
    const key = `custom_${trimmed.toLowerCase().replace(/\s+/g, '_')}`;
    if (configs[key]) {
      toast.error('This vehicle type already exists');
      return;
    }
    setConfigs((prev) => ({
      ...prev,
      [key]: {
        vehicle_type: key,
        label: trimmed,
        tow_fee: newTypeTowFee,
        daily_storage_fee: newTypeStorageFee,
        admin_fee: newTypeAdminFee,
        gate_fee: newTypeGateFee,
        isCustom: true,
      },
    }));
    setHasChanges(true);
    setShowAddDialog(false);
    setNewTypeName('');
    setNewTypeTowFee(150);
    setNewTypeStorageFee(45);
    setNewTypeAdminFee(50);
    setNewTypeGateFee(0);
    toast.success(`Added "${trimmed}" vehicle type`);
  };

  const removeCustomType = (vehicleType: string) => {
    setConfigs((prev) => {
      const next = { ...prev };
      delete next[vehicleType];
      return next;
    });
    setHasChanges(true);
    toast.success('Custom vehicle type removed');
  };

  const saveConfigs = async () => {
    if (!towYardId) return;
    setSaving(true);

    try {
      // Delete existing and insert all
      await supabase
        .from('fee_configurations')
        .delete()
        .eq('tow_yard_id', towYardId);

      const insertData = Object.values(configs).map((config) => ({
        tow_yard_id: towYardId,
        vehicle_type: config.vehicle_type,
        tow_fee: config.tow_fee,
        daily_storage_fee: config.daily_storage_fee,
        admin_fee: config.admin_fee,
        gate_fee: config.gate_fee,
      }));

      const { error } = await supabase
        .from('fee_configurations')
        .insert(insertData);

      if (error) throw error;

      toast.success('Fee configurations saved successfully');
      setHasChanges(false);
      fetchConfigs();
    } catch (error) {
      console.error('Error saving configs:', error);
      toast.error('Failed to save fee configurations');
    } finally {
      setSaving(false);
    }
  };

  if (!towYardId) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        Select a tow yard to manage fee configurations
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  // Separate preset and custom types
  const filterEntry = ([, config]: [string, FeeConfig]) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (config.label || '').toLowerCase().includes(q) || config.vehicle_type.toLowerCase().includes(q);
  };

  const presetEntries = Object.entries(configs).filter(([key]) => key in VEHICLE_TYPES).filter(filterEntry);
  const customEntries = Object.entries(configs).filter(([key]) => !(key in VEHICLE_TYPES)).filter(filterEntry);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
            <Settings className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h2 className="text-xl font-semibold">Fee Configuration</h2>
            <p className="text-muted-foreground text-sm">
              Set base fees for each vehicle type
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Plus className="w-4 h-4 mr-2" />
                Add Custom Type
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Custom Vehicle Type</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-2">
                <div className="space-y-2">
                  <Label>Vehicle Type Name</Label>
                  <Input
                    placeholder="e.g. Flatbed, Golf Cart, ATV"
                    value={newTypeName}
                    onChange={(e) => setNewTypeName(e.target.value)}
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Tow Fee</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                      <Input type="number" step="0.01" value={newTypeTowFee} onChange={(e) => setNewTypeTowFee(Number(e.target.value))} className="pl-7" />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Daily Storage</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                      <Input type="number" step="0.01" value={newTypeStorageFee} onChange={(e) => setNewTypeStorageFee(Number(e.target.value))} className="pl-7" />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Admin Fee</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                      <Input type="number" step="0.01" value={newTypeAdminFee} onChange={(e) => setNewTypeAdminFee(Number(e.target.value))} className="pl-7" />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Gate Fee</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                      <Input type="number" step="0.01" value={newTypeGateFee} onChange={(e) => setNewTypeGateFee(Number(e.target.value))} className="pl-7" />
                    </div>
                  </div>
                </div>
                <Button onClick={addCustomType} className="w-full">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Vehicle Type
                </Button>
              </div>
            </DialogContent>
          </Dialog>
          <Button onClick={saveConfigs} disabled={saving || !hasChanges}>
            {saving ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </>
            )}
          </Button>
        </div>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search vehicle types..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-9"
        />
      </div>

      {/* Preset vehicle types */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {presetEntries.length === 0 && <p className="text-sm text-muted-foreground col-span-full">No matching vehicle types found.</p>}
        {presetEntries.map(([type, config]) => (
          <VehicleTypeCard
            key={type}
            type={type}
            config={config}
            label={config.label || type}
            subtitle={`Base multiplier: ${VEHICLE_TYPES[type as VehicleType]?.multiplier ?? 1}x`}
            onUpdate={updateConfig}
            onReset={() => resetToDefaults(type)}
          />
        ))}
      </div>

      {/* Custom vehicle types */}
      {customEntries.length > 0 && (
        <>
          <h3 className="text-lg font-semibold pt-2">Custom Vehicle Types</h3>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {customEntries.map(([type, config]) => (
              <VehicleTypeCard
                key={type}
                type={type}
                config={config}
                label={config.label || type}
                subtitle="Custom type"
                onUpdate={updateConfig}
                onRemove={() => removeCustomType(type)}
              />
            ))}
          </div>
        </>
      )}

      {hasChanges && (
        <div className="fixed bottom-4 right-4 bg-primary text-primary-foreground px-4 py-2 rounded-lg shadow-lg flex items-center gap-2">
          <span className="text-sm">You have unsaved changes</span>
          <Button size="sm" variant="secondary" onClick={saveConfigs} disabled={saving}>
            {saving ? 'Saving...' : 'Save Now'}
          </Button>
        </div>
      )}
    </div>
  );
}

function VehicleTypeCard({
  type,
  config,
  label,
  subtitle,
  onUpdate,
  onReset,
  onRemove,
}: {
  type: string;
  config: FeeConfig;
  label: string;
  subtitle: string;
  onUpdate: (type: string, field: keyof FeeConfig, value: number) => void;
  onReset?: () => void;
  onRemove?: () => void;
}) {
  return (
    <Card className="relative">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Car className="w-5 h-5 text-primary" />
            <CardTitle className="text-base">{label}</CardTitle>
          </div>
          {onReset && (
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onReset} title="Reset to defaults">
              <RotateCcw className="w-4 h-4" />
            </Button>
          )}
          {onRemove && (
            <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={onRemove} title="Remove custom type">
              <Trash2 className="w-4 h-4" />
            </Button>
          )}
        </div>
        <CardDescription className="text-xs">{subtitle}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          {([
            ['tow_fee', 'Tow Fee'],
            ['daily_storage_fee', 'Daily Storage'],
            ['admin_fee', 'Admin Fee'],
            ['gate_fee', 'Gate Fee'],
          ] as const).map(([field, fieldLabel]) => (
            <div key={field} className="space-y-1">
              <Label className="text-xs text-muted-foreground">{fieldLabel}</Label>
              <div className="relative">
                <DollarSign className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                <Input
                  type="number"
                  step="0.01"
                  value={config[field]}
                  onChange={(e) => onUpdate(type, field, Number(e.target.value))}
                  className="pl-7 h-9"
                />
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
