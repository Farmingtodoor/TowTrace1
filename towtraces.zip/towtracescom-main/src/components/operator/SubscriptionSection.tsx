import { useState, useEffect } from 'react';
import { CreditCard, Settings, Crown, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { SubscriptionCard } from '@/components/payments/SubscriptionCard';
import { 
  checkSubscription, 
  openCustomerPortal, 
  type SubscriptionStatus,
  type SubscriptionPlan,
  type BillingInterval,
  SUBSCRIPTION_TIERS
} from '@/lib/payments';
import { format } from 'date-fns';

export function SubscriptionSection() {
  const [subscription, setSubscription] = useState<SubscriptionStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [portalLoading, setPortalLoading] = useState(false);
  const [interval, setInterval] = useState<BillingInterval>('monthly');

  const fetchSubscription = async () => {
    setLoading(true);
    const status = await checkSubscription();
    setSubscription(status);
    setLoading(false);
  };

  useEffect(() => {
    fetchSubscription();
  }, []);

  const handleManageSubscription = async () => {
    setPortalLoading(true);
    await openCustomerPortal();
    setPortalLoading(false);
  };

  if (loading) {
    return (
      <div className="bg-card rounded-xl p-8 text-center">
        <Loader2 className="w-8 h-8 animate-spin mx-auto text-muted-foreground" />
        <p className="mt-2 text-muted-foreground">Loading subscription status...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Current Status */}
      <div className="bg-card rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
              subscription?.subscribed ? 'bg-primary/10' : 'bg-muted'
            }`}>
              <Crown className={`w-6 h-6 ${subscription?.subscribed ? 'text-primary' : 'text-muted-foreground'}`} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-semibold text-lg">
                  {subscription?.subscribed 
                    ? SUBSCRIPTION_TIERS[subscription.plan as SubscriptionPlan]?.name || 'Active Subscription'
                    : 'No Active Subscription'}
                </h3>
                {subscription?.subscribed && (
                  <Badge variant="outline" className={subscription.is_trial 
                    ? 'bg-warning/10 text-warning border-warning/30' 
                    : 'bg-success/10 text-success'}>
                    {subscription.is_trial ? 'Free Trial' : 'Active'}
                  </Badge>
                )}
              </div>
              {subscription?.subscribed && subscription.is_trial && subscription.trial_end && (
                <p className="text-sm text-muted-foreground">
                  Trial ends on {format(new Date(subscription.trial_end), 'MMMM d, yyyy')} — billing starts automatically
                </p>
              )}
              {subscription?.subscribed && !subscription.is_trial && subscription.subscription_end && (
                <p className="text-sm text-muted-foreground">
                  Renews on {format(new Date(subscription.subscription_end), 'MMMM d, yyyy')}
                </p>
              )}
              {!subscription?.subscribed && (
                <p className="text-sm text-muted-foreground">
                  Start with a 7-day free trial — subscribe to unlock all features
                </p>
              )}
            </div>
          </div>
          {subscription?.subscribed && (
            <Button
              variant="outline"
              onClick={handleManageSubscription}
              disabled={portalLoading}
            >
              {portalLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Loading...
                </>
              ) : (
                <>
                  <Settings className="w-4 h-4 mr-2" />
                  Manage Subscription
                </>
              )}
            </Button>
          )}
        </div>
      </div>

      {/* Subscription Plans */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-xl font-semibold">
            {subscription?.subscribed ? 'Your Plan Options' : 'Choose a Plan'}
          </h3>
          <div className="flex items-center gap-1 rounded-lg bg-muted p-1">
            <button
              className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${
                interval === 'monthly'
                  ? 'bg-background text-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
              onClick={() => setInterval('monthly')}
            >
              Monthly
            </button>
            <button
              className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors flex items-center gap-1.5 ${
                interval === 'annual'
                  ? 'bg-background text-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
              onClick={() => setInterval('annual')}
            >
              Annual
              <Badge variant="secondary" className="text-xs bg-primary/10 text-primary border-0">
                2 months free
              </Badge>
            </button>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <SubscriptionCard
            plan="basic"
            currentPlan={subscription?.plan || null}
            interval={interval}
            onSubscribe={fetchSubscription}
          />
          <SubscriptionCard
            plan="pro"
            currentPlan={subscription?.plan || null}
            interval={interval}
            onSubscribe={fetchSubscription}
            highlighted
          />
          <SubscriptionCard
            plan="city"
            currentPlan={subscription?.plan || null}
            interval={interval}
            onSubscribe={fetchSubscription}
          />
        </div>
      </div>
    </div>
  );
}
