import { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { History, User, Car, FileText, CreditCard, Filter, LogIn, LogOut, Upload, UserPlus, CheckCircle, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';

interface ActivityLog {
  id: string;
  entity_type: string;
  entity_id: string;
  action: string;
  created_at: string;
  metadata_json: Record<string, unknown>;
  actor_user_id: string;
  actor_profile?: {
    full_name: string | null;
    email: string | null;
  };
}

interface ActivityLogsSectionProps {
  towYardId: string | null;
}

const actionLabels: Record<string, { label: string; color: string }> = {
  record_created: { label: 'Record Created', color: 'text-success' },
  record_updated: { label: 'Record Updated', color: 'text-info' },
  record_deleted: { label: 'Record Deleted', color: 'text-destructive' },
  status_changed: { label: 'Status Changed', color: 'text-warning' },
  record_released: { label: 'Vehicle Released', color: 'text-accent' },
  user_login: { label: 'User Login', color: 'text-info' },
  user_logout: { label: 'User Logout', color: 'text-muted-foreground' },
  user_signup: { label: 'User Signup', color: 'text-success' },
  claim_started: { label: 'Claim Started', color: 'text-accent' },
  claim_updated: { label: 'Claim Updated', color: 'text-info' },
  docs_submitted: { label: 'Docs Submitted', color: 'text-warning' },
  docs_approved: { label: 'Docs Approved', color: 'text-success' },
  docs_rejected: { label: 'Docs Rejected', color: 'text-destructive' },
  payment_initiated: { label: 'Payment Started', color: 'text-warning' },
  payment_completed: { label: 'Payment Complete', color: 'text-success' },
  document_uploaded: { label: 'Document Uploaded', color: 'text-info' },
  profile_updated: { label: 'Profile Updated', color: 'text-info' },
};

const entityIcons: Record<string, typeof Car> = {
  tow_record: Car,
  claim: FileText,
  payment: CreditCard,
  user: User,
  document: Upload,
};

export function ActivityLogsSection({ towYardId }: ActivityLogsSectionProps) {
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>('all');

  useEffect(() => {
    const fetchLogs = async () => {
      if (!towYardId) return;
      
      setLoading(true);

      // First get tow records for this yard
      const { data: records } = await supabase
        .from('tow_records')
        .select('id')
        .eq('tow_yard_id', towYardId);

      if (!records || records.length === 0) {
        setLogs([]);
        setLoading(false);
        return;
      }

      const recordIds = records.map(r => r.id);

      // Fetch audit logs for these records
      let query = supabase
        .from('audit_logs')
        .select('*')
        .eq('entity_type', 'tow_record')
        .in('entity_id', recordIds)
        .order('created_at', { ascending: false })
        .limit(50);

      if (filter !== 'all') {
        query = query.eq('action', filter);
      }

      const { data: logsData, error } = await query;

      if (error) {
        console.error('Error fetching logs:', error);
        setLoading(false);
        return;
      }

      // Fetch actor profiles
      const logsWithProfiles: ActivityLog[] = [];
      const actorIds = [...new Set(logsData?.map(l => l.actor_user_id).filter(Boolean))];
      
      const { data: profiles } = await supabase
        .from('profiles')
        .select('user_id, full_name, email')
        .in('user_id', actorIds);

      const profileMap = new Map(profiles?.map(p => [p.user_id, p]));

      for (const log of logsData || []) {
        logsWithProfiles.push({
          ...log,
          metadata_json: (log.metadata_json as Record<string, unknown>) || {},
          actor_profile: log.actor_user_id ? profileMap.get(log.actor_user_id) : undefined,
        });
      }

      setLogs(logsWithProfiles);
      setLoading(false);
    };

    fetchLogs();
  }, [towYardId, filter]);

  const getActionInfo = (action: string) => {
    return actionLabels[action] || { label: action, color: 'text-muted-foreground' };
  };

  const formatMetadata = (action: string, metadata: Record<string, unknown>): string => {
    if (action === 'status_changed') {
      return `${metadata.old_status || 'unknown'} → ${metadata.new_status || 'unknown'}`;
    }
    if (action === 'record_created') {
      const details = [];
      if (metadata.plate_number) details.push(`Plate: ${metadata.plate_number}`);
      if (metadata.make) details.push(`${metadata.make} ${metadata.model || ''}`);
      return details.join(' • ') || 'New record';
    }
    if (action === 'record_updated') {
      const fields = Object.keys(metadata).filter(k => k !== 'id');
      return fields.length > 0 ? `Updated: ${fields.join(', ')}` : 'Record updated';
    }
    return '';
  };

  if (loading) {
    return (
      <div className="bg-card rounded-xl p-8 text-center">
        <div className="animate-pulse text-muted-foreground">Loading activity logs...</div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          <History className="w-5 h-5" />
          Activity Logs
        </h3>
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-40">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Filter" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Actions</SelectItem>
            <SelectItem value="record_created">Created</SelectItem>
            <SelectItem value="record_updated">Updated</SelectItem>
            <SelectItem value="status_changed">Status Changed</SelectItem>
            <SelectItem value="record_released">Released</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {logs.length === 0 ? (
        <div className="bg-card rounded-xl p-8 text-center">
          <History className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">No activity logs yet.</p>
        </div>
      ) : (
        <div className="bg-card rounded-xl shadow-card overflow-hidden">
          <div className="divide-y divide-border">
            {logs.map((log) => {
              const actionInfo = getActionInfo(log.action);
              const EntityIcon = entityIcons[log.entity_type] || Car;
              
              return (
                <div key={log.id} className="p-4 hover:bg-muted/50 transition-colors">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center shrink-0">
                      <EntityIcon className="w-5 h-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`font-medium ${actionInfo.color}`}>
                          {actionInfo.label}
                        </span>
                        <span className="text-sm text-muted-foreground">
                          {formatMetadata(log.action, log.metadata_json)}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                        <User className="w-3 h-3" />
                        <span>
                          {log.actor_profile?.full_name || log.actor_profile?.email || 'Unknown user'}
                        </span>
                        <span>•</span>
                        <span>{format(new Date(log.created_at), 'MMM d, yyyy h:mm a')}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
