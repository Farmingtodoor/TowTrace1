import { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Loader2, Search, Car, CheckCircle2, AlertCircle } from 'lucide-react';
import { useVINDecoder, mapBodyClassToVehicleType } from '@/hooks/useVINDecoder';
import { cn } from '@/lib/utils';
import type { VehicleType } from '@/lib/feeCalculator';

interface VINDecoderInputProps {
  value: string;
  onChange: (vin: string) => void;
  onDecode?: (data: {
    make: string | null;
    model: string | null;
    year: string | null;
    vehicleType: VehicleType;
  }) => void;
  disabled?: boolean;
  className?: string;
  optional?: boolean;
}

export function VINDecoderInput({
  value,
  onChange,
  onDecode,
  disabled,
  className,
  optional = false,
}: VINDecoderInputProps) {
  const { decode, isDecoding, decodedData, error, reset } = useVINDecoder();
  const [showResult, setShowResult] = useState(false);

  // Auto-decode when VIN reaches 17 characters
  useEffect(() => {
    if (value.length === 17 && !decodedData && !isDecoding) {
      handleDecode();
    }
    // Reset when VIN changes significantly
    if (value.length < 17 && decodedData) {
      reset();
      setShowResult(false);
    }
  }, [value]);

  const handleDecode = async () => {
    const result = await decode(value);
    if (result && onDecode) {
      const vehicleType = mapBodyClassToVehicleType(result.bodyClass) as VehicleType;
      onDecode({
        make: result.make,
        model: result.model,
        year: result.year,
        vehicleType,
      });
      setShowResult(true);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Only allow alphanumeric, uppercase
    const cleaned = e.target.value.toUpperCase().replace(/[^A-HJ-NPR-Z0-9]/g, '');
    onChange(cleaned.slice(0, 17));
  };

  return (
    <div className={cn('space-y-2', className)}>
      <div className="flex items-center gap-2">
        <Label htmlFor="vin-input" className="flex items-center gap-2">
          <Car className="w-4 h-4" />
          VIN {!optional && '*'}
        </Label>
        {value.length > 0 && (
          <Badge 
            variant={value.length === 17 ? 'default' : 'secondary'}
            className="text-xs"
          >
            {value.length}/17
          </Badge>
        )}
      </div>
      
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Input
            id="vin-input"
            value={value}
            onChange={handleInputChange}
            placeholder="Enter 17-character VIN"
            disabled={disabled || isDecoding}
            className={cn(
              'font-mono tracking-wider uppercase pr-10',
              decodedData && 'border-success focus-visible:ring-success',
              error && 'border-destructive focus-visible:ring-destructive'
            )}
            maxLength={17}
          />
          {isDecoding && (
            <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-muted-foreground" />
          )}
          {decodedData && !isDecoding && (
            <CheckCircle2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-success" />
          )}
          {error && !isDecoding && (
            <AlertCircle className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-destructive" />
          )}
        </div>
        
        <Button
          type="button"
          variant="outline"
          size="icon"
          onClick={handleDecode}
          disabled={disabled || isDecoding || value.length !== 17}
          title="Decode VIN"
        >
          {isDecoding ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Search className="w-4 h-4" />
          )}
        </Button>
      </div>

      {/* Decoded Vehicle Info */}
      {showResult && decodedData && (
        <div className="bg-success/10 border border-success/20 rounded-lg p-3 animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="flex items-center gap-2 text-sm font-medium text-success mb-2">
            <CheckCircle2 className="w-4 h-4" />
            Vehicle Identified
          </div>
          <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
            {decodedData.year && (
              <>
                <span className="text-muted-foreground">Year</span>
                <span className="font-medium">{decodedData.year}</span>
              </>
            )}
            {decodedData.make && (
              <>
                <span className="text-muted-foreground">Make</span>
                <span className="font-medium">{decodedData.make}</span>
              </>
            )}
            {decodedData.model && (
              <>
                <span className="text-muted-foreground">Model</span>
                <span className="font-medium">{decodedData.model}</span>
              </>
            )}
            {decodedData.trimLevel && (
              <>
                <span className="text-muted-foreground">Trim</span>
                <span className="font-medium">{decodedData.trimLevel}</span>
              </>
            )}
            {decodedData.bodyClass && (
              <>
                <span className="text-muted-foreground">Body</span>
                <span className="font-medium">{decodedData.bodyClass}</span>
              </>
            )}
            {decodedData.driveType && (
              <>
                <span className="text-muted-foreground">Drive</span>
                <span className="font-medium">{decodedData.driveType}</span>
              </>
            )}
          </div>
        </div>
      )}

      {error && (
        <p className="text-xs text-destructive flex items-center gap-1">
          <AlertCircle className="w-3 h-3" />
          {error}
        </p>
      )}
    </div>
  );
}
