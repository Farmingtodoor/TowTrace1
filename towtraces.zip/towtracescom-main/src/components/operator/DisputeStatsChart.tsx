import { useState, useEffect } from 'react';
import { Scale, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import { supabase } from '@/integrations/supabase/client';

interface DisputeStatsChartProps {
  towYardId: string | null;
  timeRange: '7d' | '30d' | '90d';
}

interface DisputeStats {
  open: number;
  underReview: number;
  resolved: number;
  rejected: number;
  total: number;
}

interface DisputeTrendData {
  date: string;
  open: number;
  resolved: number;
  rejected: number;
}

const COLORS = {
  open: 'hsl(var(--warning))',
  underReview: 'hsl(var(--info))',
  resolved: 'hsl(var(--success))',
  rejected: 'hsl(var(--destructive))',
};

export function DisputeStatsChart({ towYardId, timeRange }: DisputeStatsChartProps) {
  const [stats, setStats] = useState<DisputeStats>({
    open: 0,
    underReview: 0,
    resolved: 0,
    rejected: 0,
    total: 0,
  });
  const [trendData, setTrendData] = useState<DisputeTrendData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!towYardId) return;

    const fetchDisputeStats = async () => {
      setLoading(true);

      const daysAgo = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 90;
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - daysAgo);

      // Fetch disputes for the selected yard
      const { data: disputes, error } = await supabase
        .from('disputes')
        .select('id, status, created_at, updated_at')
        .eq('tow_yard_id', towYardId)
        .gte('created_at', startDate.toISOString());

      if (error) {
        console.error('Error fetching disputes:', error);
        setLoading(false);
        return;
      }

      // Calculate stats
      const disputeStats: DisputeStats = {
        open: disputes?.filter((d) => d.status === 'open').length || 0,
        underReview: disputes?.filter((d) => d.status === 'under_review').length || 0,
        resolved: disputes?.filter((d) => d.status === 'resolved').length || 0,
        rejected: disputes?.filter((d) => d.status === 'rejected').length || 0,
        total: disputes?.length || 0,
      };
      setStats(disputeStats);

      // Group by date for trend chart
      const groupedData: Record<string, { open: number; resolved: number; rejected: number }> = {};

      for (let i = 0; i < daysAgo; i++) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dateStr = date.toISOString().split('T')[0];
        groupedData[dateStr] = { open: 0, resolved: 0, rejected: 0 };
      }

      disputes?.forEach((dispute) => {
        const dateStr = dispute.created_at.split('T')[0];
        if (groupedData[dateStr]) {
          if (dispute.status === 'open' || dispute.status === 'under_review') {
            groupedData[dateStr].open += 1;
          } else if (dispute.status === 'resolved') {
            groupedData[dateStr].resolved += 1;
          } else if (dispute.status === 'rejected') {
            groupedData[dateStr].rejected += 1;
          }
        }
      });

      const chartData = Object.entries(groupedData)
        .map(([date, data]) => ({
          date: new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
          open: data.open,
          resolved: data.resolved,
          rejected: data.rejected,
        }))
        .reverse();

      setTrendData(chartData);
      setLoading(false);
    };

    fetchDisputeStats();
  }, [towYardId, timeRange]);

  const pieData = [
    { name: 'Open', value: stats.open, color: COLORS.open },
    { name: 'Under Review', value: stats.underReview, color: COLORS.underReview },
    { name: 'Resolved', value: stats.resolved, color: COLORS.resolved },
    { name: 'Rejected', value: stats.rejected, color: COLORS.rejected },
  ].filter((d) => d.value > 0);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="bg-card rounded-xl p-5 shadow-card animate-pulse">
              <div className="h-16 bg-muted rounded" />
            </div>
          ))}
        </div>
        <div className="bg-card rounded-xl p-6 shadow-card animate-pulse">
          <div className="h-64 bg-muted rounded" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Dispute Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-card rounded-xl p-5 shadow-card">
          <div className="w-12 h-12 bg-warning/10 rounded-lg flex items-center justify-center">
            <AlertTriangle className="w-6 h-6 text-warning" />
          </div>
          <p className="text-2xl font-bold mt-3">{stats.open}</p>
          <p className="text-sm text-muted-foreground">Open Disputes</p>
        </div>

        <div className="bg-card rounded-xl p-5 shadow-card">
          <div className="w-12 h-12 bg-info/10 rounded-lg flex items-center justify-center">
            <Scale className="w-6 h-6 text-info" />
          </div>
          <p className="text-2xl font-bold mt-3">{stats.underReview}</p>
          <p className="text-sm text-muted-foreground">Under Review</p>
        </div>

        <div className="bg-card rounded-xl p-5 shadow-card">
          <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
            <CheckCircle className="w-6 h-6 text-success" />
          </div>
          <p className="text-2xl font-bold mt-3">{stats.resolved}</p>
          <p className="text-sm text-muted-foreground">Resolved</p>
        </div>

        <div className="bg-card rounded-xl p-5 shadow-card">
          <div className="w-12 h-12 bg-destructive/10 rounded-lg flex items-center justify-center">
            <XCircle className="w-6 h-6 text-destructive" />
          </div>
          <p className="text-2xl font-bold mt-3">{stats.rejected}</p>
          <p className="text-sm text-muted-foreground">Rejected</p>
        </div>
      </div>

      {/* Dispute Trend and Distribution Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-card rounded-xl p-6 shadow-card">
          <h3 className="font-display text-lg font-semibold mb-4">Dispute Trend</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis
                  dataKey="date"
                  className="text-xs fill-muted-foreground"
                  tick={{ fontSize: 12 }}
                />
                <YAxis
                  className="text-xs fill-muted-foreground"
                  tick={{ fontSize: 12 }}
                  allowDecimals={false}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="open"
                  stackId="1"
                  stroke={COLORS.open}
                  fill={COLORS.open}
                  fillOpacity={0.6}
                  name="Open/Under Review"
                />
                <Area
                  type="monotone"
                  dataKey="resolved"
                  stackId="1"
                  stroke={COLORS.resolved}
                  fill={COLORS.resolved}
                  fillOpacity={0.6}
                  name="Resolved"
                />
                <Area
                  type="monotone"
                  dataKey="rejected"
                  stackId="1"
                  stroke={COLORS.rejected}
                  fill={COLORS.rejected}
                  fillOpacity={0.6}
                  name="Rejected"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-card rounded-xl p-6 shadow-card">
          <h3 className="font-display text-lg font-semibold mb-4">Dispute Distribution</h3>
          {stats.total === 0 ? (
            <div className="h-64 flex items-center justify-center text-muted-foreground">
              <div className="text-center">
                <Scale className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>No disputes in this period</p>
              </div>
            </div>
          ) : (
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                    label={({ name, percent }) =>
                      `${name} ${(percent * 100).toFixed(0)}%`
                    }
                    labelLine={false}
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--card))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
