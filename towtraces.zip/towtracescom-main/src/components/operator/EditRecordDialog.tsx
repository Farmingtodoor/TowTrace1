import { useState, useEffect, useRef, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/integrations/supabase/client';
import { logRecordUpdated, logStatusChanged } from '@/lib/activityLog';
import { Loader2, Lock, AlertTriangle, Check, CloudOff, RefreshCw } from 'lucide-react';
import { useRecordLock } from '@/hooks/useRecordLock';
import { RecordLockIndicator } from '@/components/operator/RecordLockIndicator';
import { useToast } from '@/hooks/use-toast';

type AutoSaveStatus = 'idle' | 'saving' | 'saved' | 'error';

const formSchema = z.object({
  plate_number: z.string().optional(),
  vin: z.string().optional(),
  make: z.string().min(1, 'Make is required'),
  model: z.string().min(1, 'Model is required'),
  color: z.string().optional(),
  tow_reason: z.string().optional(),
  tow_from_address: z.string().optional(),
  tow_fee: z.number().min(0),
  daily_storage_fee: z.number().min(0),
  admin_fee: z.number().min(0),
  gate_fee: z.number().min(0),
  status: z.enum(['towed', 'docs_pending', 'docs_approved', 'paid', 'released']),
});

type FormData = z.infer<typeof formSchema>;

interface EditRecordDialogProps {
  isOpen: boolean;
  onClose: () => void;
  record: {
    id: string;
    plate_number: string | null;
    vin: string | null;
    make: string | null;
    model: string | null;
    color: string | null;
    status: string;
    tow_fee: number;
    daily_storage_fee: number;
    admin_fee: number;
    gate_fee: number;
  };
  onSuccess: () => void;
}

export function EditRecordDialog({
  isOpen,
  onClose,
  record,
  onSuccess,
}: EditRecordDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [autoSaveStatus, setAutoSaveStatus] = useState<AutoSaveStatus>('idle');
  const [lastSavedAt, setLastSavedAt] = useState<Date | null>(null);
  const autoSaveIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const { toast } = useToast();
  
  const { lockStatus, isLoading: lockLoading, acquireLock, releaseLock, canEdit } = useRecordLock(
    isOpen ? record.id : null
  );

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors, isDirty },
    reset,
  } = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      plate_number: record.plate_number || '',
      vin: record.vin || '',
      make: record.make || '',
      model: record.model || '',
      color: record.color || '',
      tow_fee: record.tow_fee,
      daily_storage_fee: record.daily_storage_fee,
      admin_fee: record.admin_fee,
      gate_fee: record.gate_fee,
      status: record.status as FormData['status'],
    },
  });

  const status = watch('status');
  const formValues = watch();

  // Auto-save function
  const performAutoSave = useCallback(async () => {
    if (!canEdit || !isDirty || isSubmitting) return;

    setAutoSaveStatus('saving');

    const data = formValues;
    const { error: updateError } = await supabase
      .from('tow_records')
      .update({
        plate_number: data.plate_number || null,
        vin: data.vin || null,
        make: data.make,
        model: data.model,
        color: data.color || null,
        tow_reason: data.tow_reason || null,
        tow_from_address: data.tow_from_address || null,
        tow_fee: data.tow_fee,
        daily_storage_fee: data.daily_storage_fee,
        admin_fee: data.admin_fee,
        gate_fee: data.gate_fee,
        status: data.status,
      })
      .eq('id', record.id);

    if (updateError) {
      console.error('Auto-save error:', updateError);
      setAutoSaveStatus('error');
    } else {
      setAutoSaveStatus('saved');
      setLastSavedAt(new Date());
      // Reset dirty state after successful save
      reset(data, { keepDirty: false });
      // Clear saved status after 3 seconds
      setTimeout(() => setAutoSaveStatus('idle'), 3000);
    }
  }, [canEdit, isDirty, isSubmitting, formValues, record.id, reset]);

  // Set up auto-save interval (every 30 seconds)
  useEffect(() => {
    if (isOpen && canEdit) {
      autoSaveIntervalRef.current = setInterval(() => {
        performAutoSave();
      }, 30000); // 30 seconds
    }

    return () => {
      if (autoSaveIntervalRef.current) {
        clearInterval(autoSaveIntervalRef.current);
        autoSaveIntervalRef.current = null;
      }
    };
  }, [isOpen, canEdit, performAutoSave]);

  // Auto-acquire lock when dialog opens
  useEffect(() => {
    if (isOpen && !lockStatus.locked && !lockLoading) {
      acquireLock();
    }
  }, [isOpen]);

  // Reset auto-save status when dialog closes
  useEffect(() => {
    if (!isOpen) {
      setAutoSaveStatus('idle');
      setLastSavedAt(null);
    }
  }, [isOpen]);

  const handleClose = async () => {
    // Perform final auto-save if there are unsaved changes
    if (isDirty && canEdit) {
      await performAutoSave();
    }
    
    if (lockStatus.isOwnLock) {
      await releaseLock();
    }
    if (autoSaveIntervalRef.current) {
      clearInterval(autoSaveIntervalRef.current);
      autoSaveIntervalRef.current = null;
    }
    onClose();
  };

  const onSubmit = async (data: FormData) => {
    if (!canEdit) {
      setError('Cannot save: Record is locked by another user.');
      return;
    }
    
    setIsSubmitting(true);
    setError(null);

    const oldStatus = record.status;
    const newStatus = data.status;

    const { error: updateError } = await supabase
      .from('tow_records')
      .update({
        plate_number: data.plate_number || null,
        vin: data.vin || null,
        make: data.make,
        model: data.model,
        color: data.color || null,
        tow_reason: data.tow_reason || null,
        tow_from_address: data.tow_from_address || null,
        tow_fee: data.tow_fee,
        daily_storage_fee: data.daily_storage_fee,
        admin_fee: data.admin_fee,
        gate_fee: data.gate_fee,
        status: data.status,
      })
      .eq('id', record.id);

    setIsSubmitting(false);

    if (updateError) {
      console.error('Error updating record:', updateError);
      setError('Failed to update record. Please try again.');
    } else {
      // Log the update activity
      await logRecordUpdated(record.id, {
        plate_number: data.plate_number,
        make: data.make,
        model: data.model,
        tow_fee: data.tow_fee,
        daily_storage_fee: data.daily_storage_fee,
        admin_fee: data.admin_fee,
        gate_fee: data.gate_fee,
      });

      // Log status change if status was modified
      if (oldStatus !== newStatus) {
        await logStatusChanged(record.id, oldStatus, newStatus);
      }

      toast({
        title: "Changes saved",
        description: "Record has been updated successfully.",
      });

      // Release lock and trigger success callback
      if (lockStatus.isOwnLock) {
        await releaseLock();
      }
      if (autoSaveIntervalRef.current) {
        clearInterval(autoSaveIntervalRef.current);
        autoSaveIntervalRef.current = null;
      }
      onSuccess();
    }
  };

  const getAutoSaveIndicator = () => {
    switch (autoSaveStatus) {
      case 'saving':
        return (
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <RefreshCw className="w-3 h-3 animate-spin" />
            <span>Saving...</span>
          </div>
        );
      case 'saved':
        return (
          <div className="flex items-center gap-1.5 text-xs text-success">
            <Check className="w-3 h-3" />
            <span>Auto-saved</span>
          </div>
        );
      case 'error':
        return (
          <div className="flex items-center gap-1.5 text-xs text-destructive">
            <CloudOff className="w-3 h-3" />
            <span>Auto-save failed</span>
          </div>
        );
      default:
        if (isDirty) {
          return (
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <span>Unsaved changes</span>
            </div>
          );
        }
        return null;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle>Edit Tow Record</DialogTitle>
            {getAutoSaveIndicator()}
          </div>
        </DialogHeader>

        {/* Lock Status */}
        <div className="mb-4">
          <RecordLockIndicator
            lockStatus={lockStatus}
            isLoading={lockLoading}
            onAcquireLock={acquireLock}
            onReleaseLock={releaseLock}
            variant="badge"
            showActions={false}
          />
        </div>

        {!canEdit && (
          <Alert variant="destructive" className="mb-4">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              This record is currently being edited by {lockStatus.lockedByName}. 
              You can view but not save changes.
            </AlertDescription>
          </Alert>
        )}

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="plate_number">Plate Number</Label>
              <Input
                id="plate_number"
                {...register('plate_number')}
                placeholder="ABC1234"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="vin">VIN</Label>
              <Input
                id="vin"
                {...register('vin')}
                placeholder="1HGBH41..."
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="make">Make *</Label>
              <Input
                id="make"
                {...register('make')}
                placeholder="Honda"
              />
              {errors.make && (
                <p className="text-xs text-destructive">{errors.make.message}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="model">Model *</Label>
              <Input
                id="model"
                {...register('model')}
                placeholder="Civic"
              />
              {errors.model && (
                <p className="text-xs text-destructive">{errors.model.message}</p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="color">Color</Label>
              <Input
                id="color"
                {...register('color')}
                placeholder="Silver"
              />
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select
                value={status}
                onValueChange={(value) => setValue('status', value as FormData['status'])}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="towed">Towed</SelectItem>
                  <SelectItem value="docs_pending">Docs Pending</SelectItem>
                  <SelectItem value="docs_approved">Docs Approved</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="released">Released</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="border-t border-border pt-4">
            <h4 className="font-medium mb-3">Fees</h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="tow_fee">Tow Fee</Label>
                <Input
                  id="tow_fee"
                  type="number"
                  step="0.01"
                  {...register('tow_fee', { valueAsNumber: true })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="daily_storage_fee">Daily Storage</Label>
                <Input
                  id="daily_storage_fee"
                  type="number"
                  step="0.01"
                  {...register('daily_storage_fee', { valueAsNumber: true })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="admin_fee">Admin Fee</Label>
                <Input
                  id="admin_fee"
                  type="number"
                  step="0.01"
                  {...register('admin_fee', { valueAsNumber: true })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="gate_fee">Gate Fee</Label>
                <Input
                  id="gate_fee"
                  type="number"
                  step="0.01"
                  {...register('gate_fee', { valueAsNumber: true })}
                />
              </div>
            </div>
          </div>

          {error && (
            <p className="text-sm text-destructive">{error}</p>
          )}

          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" onClick={handleClose} className="flex-1">
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting || !canEdit} className="flex-1">
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : !canEdit ? (
                <>
                  <Lock className="w-4 h-4 mr-2" />
                  Locked
                </>
              ) : (
                'Save Changes'
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
