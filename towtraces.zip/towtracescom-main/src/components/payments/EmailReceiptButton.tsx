import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Mail, Loader2, Check } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { generateReceiptNumber } from '@/lib/receiptGenerator';
import { toast } from 'sonner';

interface EmailReceiptButtonProps {
  claimId: string;
  userEmail: string;
  paymentDate: Date;
  vehicleInfo: {
    make?: string;
    model?: string;
    year?: string;
    plateNumber?: string;
    vin?: string;
    color?: string;
  };
  towYard: {
    name: string;
    address: string;
    city: string;
    state: string;
    phone: string;
  };
  fees: {
    towFee: number;
    dailyStorageFee: number;
    daysStored: number;
    storageFee: number;
    adminFee: number;
    gateFee: number;
    subtotal: number;
    serviceFee: number;
    total: number;
  };
  variant?: 'default' | 'outline' | 'secondary' | 'ghost';
  size?: 'default' | 'sm' | 'lg' | 'icon';
  className?: string;
}

export function EmailReceiptButton({
  claimId,
  userEmail,
  paymentDate,
  vehicleInfo,
  towYard,
  fees,
  variant = 'outline',
  size = 'default',
  className,
}: EmailReceiptButtonProps) {
  const [isSending, setIsSending] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSendEmail = async () => {
    setIsSending(true);
    
    try {
      const receiptNumber = generateReceiptNumber(claimId, paymentDate);
      
      const { data, error } = await supabase.functions.invoke('send-receipt-email', {
        body: {
          email: userEmail,
          receiptNumber,
          paymentDate: paymentDate.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
          }),
          vehicleInfo,
          towYard,
          fees,
        },
      });

      if (error) throw error;
      
      setSent(true);
      toast.success('Receipt sent!', {
        description: `Email sent to ${userEmail}`,
      });

      // Reset sent state after 3 seconds
      setTimeout(() => setSent(false), 3000);
    } catch (error) {
      console.error('Error sending receipt email:', error);
      toast.error('Failed to send receipt', {
        description: 'Please try again or download the PDF instead',
      });
    } finally {
      setIsSending(false);
    }
  };

  return (
    <Button
      variant={variant}
      size={size}
      onClick={handleSendEmail}
      disabled={isSending || sent}
      className={className}
    >
      {isSending ? (
        <>
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          Sending...
        </>
      ) : sent ? (
        <>
          <Check className="w-4 h-4 mr-2" />
          Sent!
        </>
      ) : (
        <>
          <Mail className="w-4 h-4 mr-2" />
          Email Receipt
        </>
      )}
    </Button>
  );
}
