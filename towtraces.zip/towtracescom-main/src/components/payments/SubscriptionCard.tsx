import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Check, Loader2 } from 'lucide-react';
import { useState } from 'react';
import { SUBSCRIPTION_TIERS, createSubscription, openCustomerPortal, type SubscriptionPlan, type BillingInterval } from '@/lib/payments';

interface SubscriptionCardProps {
  plan: SubscriptionPlan;
  currentPlan: SubscriptionPlan | null;
  interval: BillingInterval;
  onSubscribe?: () => void;
  highlighted?: boolean;
}

export function SubscriptionCard({ plan, currentPlan, interval, onSubscribe, highlighted }: SubscriptionCardProps) {
  const [loading, setLoading] = useState(false);
  const tier = SUBSCRIPTION_TIERS[plan];
  const isCurrentPlan = currentPlan === plan;

  const price = interval === 'annual' ? tier.annualPrice : tier.monthlyPrice;
  const monthlyEquivalent = interval === 'annual' ? Math.round(tier.annualPrice / 12) : tier.monthlyPrice;

  const handleSubscribe = async () => {
    setLoading(true);
    try {
      const url = await createSubscription(plan, interval);
      if (url) {
        window.open(url, '_blank');
        onSubscribe?.();
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className={`relative transition-all ${isCurrentPlan ? 'opacity-60 grayscale border-muted bg-muted/30' : highlighted ? 'border-primary/60 ring-1 ring-primary/40 shadow-lg' : ''}`}>
      {isCurrentPlan ? (
        <Badge variant="secondary" className="absolute -top-3 left-1/2 -translate-x-1/2 bg-muted text-muted-foreground">Current Plan</Badge>
      ) : highlighted ? (
        <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground">Most Popular</Badge>
      ) : null}
      <CardHeader>
        <CardTitle className="text-xl">{tier.name}</CardTitle>
        <CardDescription className="space-y-1">
          <div>
            <span className="text-3xl font-bold text-foreground">
              ${interval === 'annual' ? monthlyEquivalent.toLocaleString() : price.toLocaleString()}
            </span>
            <span className="text-muted-foreground">/month</span>
          </div>
          {interval === 'annual' && (
            <p className="text-sm text-muted-foreground">
              Billed annually at <span className="font-medium text-foreground">${price.toLocaleString()}/yr</span>
              {' '}— <span className="font-medium text-primary">2 months free</span>
            </p>
          )}
          {tier.trialDays && !isCurrentPlan && (
            <p className="text-sm font-medium text-primary">
              {tier.trialDays}-day free trial — no charge until trial ends
            </p>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ul className="space-y-2">
          {tier.features.map((feature, index) => (
            <li key={index} className="flex items-center gap-2 text-sm">
              <Check className="w-4 h-4 text-primary shrink-0" />
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>
      <CardFooter>
        {isCurrentPlan ? (
          <Button
            className="w-full"
            variant="outline"
            disabled={loading}
            onClick={async () => {
              setLoading(true);
              await openCustomerPortal();
              setLoading(false);
            }}
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Loading...
              </>
            ) : (
              'Change Plan'
            )}
          </Button>
        ) : (
          <Button
            className="w-full"
            disabled={loading}
            onClick={handleSubscribe}
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Processing...
              </>
            ) : (
              `Start ${tier.trialDays}-Day Free Trial`
            )}
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}
