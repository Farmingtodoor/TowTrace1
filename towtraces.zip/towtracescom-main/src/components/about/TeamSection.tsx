import { Linkedin, Twitter } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';

import clarksonImage from '@/assets/team/clarkson-theophilius.jpg';
import mayaImage from '@/assets/team/maya-rodriguez.jpg';
import davidImage from '@/assets/team/david-chen.jpg';

interface TeamMember {
  name: string;
  role: string;
  bio: string;
  experience: string[];
  image: string;
  initials: string;
  linkedin?: string;
  twitter?: string;
}

const teamMembers: TeamMember[] = [
  {
    name: 'Clarkson Theophilius',
    role: 'Chief Executive Officer',
    bio: 'A visionary leader with over a decade of experience transforming complex data ecosystems into actionable business intelligence. Clarkson brings deep expertise in enterprise data architecture, predictive analytics, and digital transformation from his tenure at Fortune 500 financial institutions.',
    experience: ['PwC', 'Citibank', 'Wells Fargo', 'Deloitte'],
    image: clarksonImage,
    initials: 'CT',
    linkedin: '#',
    twitter: '#',
  },
  {
    name: 'Maya Rodriguez',
    role: 'Chief Technology Officer',
    bio: 'Full-stack engineer and systems architect with 12+ years building scalable platforms. Maya leads our engineering team in delivering seamless, real-time vehicle tracking experiences across North America.',
    experience: ['Google', 'Stripe', 'Uber'],
    image: mayaImage,
    initials: 'MR',
    linkedin: '#',
  },
  {
    name: 'David Chen',
    role: 'Chief Operations Officer',
    bio: 'Operations strategist who has built and scaled logistics networks across multiple industries. David ensures our tow yard partner network delivers consistent, reliable service to vehicle owners.',
    experience: ['Amazon', 'FedEx', 'DoorDash'],
    image: davidImage,
    initials: 'DC',
    linkedin: '#',
    twitter: '#',
  },
];

export function TeamSection() {
  return (
    <section className="py-20 px-4 bg-muted/30">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4">Leadership</Badge>
          <h2 className="font-display text-3xl font-bold mb-4">Meet Our Team</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Industry veterans united by a mission to revolutionize vehicle recovery 
            through technology and exceptional service.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {teamMembers.map((member, index) => (
            <div
              key={index}
              className="bg-card rounded-2xl p-6 shadow-card hover:shadow-card-lg transition-all duration-300 hover:-translate-y-1 text-center group"
            >
              {/* Avatar */}
              <div className="relative mx-auto mb-5">
                <div className="absolute inset-0 bg-gradient-to-br from-accent/20 to-primary/20 rounded-full blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
                <Avatar className="w-24 h-24 mx-auto border-4 border-background shadow-lg">
                  <AvatarImage src={member.image} alt={member.name} />
                  <AvatarFallback className="bg-gradient-to-br from-accent to-primary text-primary-foreground text-xl font-bold">
                    {member.initials}
                  </AvatarFallback>
                </Avatar>
              </div>

              {/* Name & Role */}
              <h3 className="font-display text-xl font-semibold mb-1">{member.name}</h3>
              <p className="text-accent font-medium text-sm mb-4">{member.role}</p>

              {/* Bio */}
              <p className="text-muted-foreground text-sm leading-relaxed mb-4">
                {member.bio}
              </p>

              {/* Experience Badges */}
              <div className="flex flex-wrap justify-center gap-2 mb-4">
                {member.experience.map((company, i) => (
                  <Badge key={i} variant="outline" className="text-xs">
                    {company}
                  </Badge>
                ))}
              </div>

              {/* Social Links */}
              <div className="flex justify-center gap-3 pt-2 border-t border-border">
                {member.linkedin && (
                  <a
                    href={member.linkedin}
                    className="text-muted-foreground hover:text-accent transition-colors p-2"
                    aria-label={`${member.name}'s LinkedIn`}
                  >
                    <Linkedin className="w-5 h-5" />
                  </a>
                )}
                {member.twitter && (
                  <a
                    href={member.twitter}
                    className="text-muted-foreground hover:text-accent transition-colors p-2"
                    aria-label={`${member.name}'s Twitter`}
                  >
                    <Twitter className="w-5 h-5" />
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* CEO Highlight */}
        <div className="mt-12 bg-gradient-to-r from-primary/5 via-accent/5 to-primary/5 rounded-2xl p-8 border border-border">
          <div className="flex flex-col md:flex-row items-center gap-6">
            <Avatar className="w-20 h-20 border-4 border-accent/20 shadow-lg shrink-0">
              <AvatarImage src={clarksonImage} alt="Clarkson Theophilius" />
              <AvatarFallback className="bg-gradient-to-br from-accent to-primary text-primary-foreground text-2xl font-bold">
                CT
              </AvatarFallback>
            </Avatar>
            <div className="text-center md:text-left">
              <h4 className="font-display text-lg font-semibold mb-2">A Word from Our CEO</h4>
              <blockquote className="text-muted-foreground italic">
                "At TowTrace, we're applying the same rigor and data-driven approach that 
                powers the world's largest financial institutions to solve a problem that 
                affects millions of vehicle owners every year. Our mission is to bring 
                transparency, efficiency, and peace of mind to an industry that has long 
                been fragmented and frustrating."
              </blockquote>
              <p className="text-sm text-accent font-medium mt-3">— Clarkson Theophilius, CEO</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
