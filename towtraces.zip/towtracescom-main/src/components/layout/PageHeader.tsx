import { Car, User, LogOut, Menu, Settings, Shield, Truck } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';
import { useState } from 'react';
import { ThemeToggle } from '@/components/ThemeToggle';
import { NotificationBell } from '@/components/notifications/NotificationBell';
import { useUserProfile } from '@/hooks/useUserProfile';
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from '@/components/ui/sheet';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface PageHeaderProps {
  onSignInClick?: () => void;
}

export function PageHeader({ onSignInClick }: PageHeaderProps) {
  const { user, signOut, loading } = useAuth();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { profile, isAdmin, isOperator, displayName } = useUserProfile();

  const initials = displayName.charAt(0).toUpperCase();

  // Different navigation for operators vs consumers
  const consumerNavLinks = [
    { href: '/', label: 'Find Vehicle' },
    { href: '/my-claims', label: 'My Claims' },
    { href: '/about', label: 'About' },
    { href: '/signup/company', label: 'For Tow Companies' },
    { href: '/join', label: 'Join' },
  ];

  const operatorNavLinks = [
    { href: '/operator', label: 'Dashboard' },
    { href: '/operator/employees', label: 'Team' },
    { href: '/operator/disputes', label: 'Disputes' },
    { href: '/operator/documents', label: 'Documents' },
    { href: '/about', label: 'About' },
  ];

  const navLinks = isOperator ? operatorNavLinks : consumerNavLinks;

  return (
    <header className="w-full py-4 px-4 bg-background border-b border-border sticky top-0 z-50">
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 text-foreground">
          <div className="w-10 h-10 bg-accent rounded-xl flex items-center justify-center">
            <Car className="w-6 h-6 text-accent-foreground" />
          </div>
          <span className="font-display font-bold text-xl">TowTrace</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-6">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              to={link.href}
              className={`text-sm font-medium transition-colors hover:text-accent ${
                location.pathname === link.href
                  ? 'text-accent'
                  : 'text-muted-foreground'
              }`}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Right Side: Theme + Auth */}
        <div className="flex items-center gap-1">
          <ThemeToggle />
          {user && <NotificationBell />}
          {!loading && (
            <>
              {user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="hidden sm:flex items-center gap-2">
                      {profile.avatarUrl ? (
                        <img src={profile.avatarUrl} alt="" className="w-6 h-6 rounded-full object-cover" />
                      ) : (
                        <div className="w-6 h-6 rounded-full bg-accent flex items-center justify-center text-accent-foreground text-xs font-medium">
                          {initials}
                        </div>
                      )}
                      <span className="max-w-32 truncate">Welcome, {displayName}</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <DropdownMenuItem asChild>
                      <Link to="/account" className="flex items-center">
                        <Settings className="w-4 h-4 mr-2" />
                        Account Settings
                      </Link>
                    </DropdownMenuItem>
                    {isOperator ? (
                      <DropdownMenuItem asChild>
                        <Link to="/operator" className="flex items-center">
                          <Truck className="w-4 h-4 mr-2" />
                          Operator Dashboard
                        </Link>
                      </DropdownMenuItem>
                    ) : (
                      <DropdownMenuItem asChild>
                        <Link to="/my-claims" className="flex items-center">
                          <Car className="w-4 h-4 mr-2" />
                          My Claims
                        </Link>
                      </DropdownMenuItem>
                    )}
                    {isAdmin && (
                      <DropdownMenuItem asChild>
                        <Link to="/admin" className="flex items-center">
                          <Shield className="w-4 h-4 mr-2" />
                          Admin Portal
                        </Link>
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => signOut()}>
                      <LogOut className="w-4 h-4 mr-2" />
                      Sign Out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onSignInClick}
                  className="hidden sm:flex"
                >
                  <User className="w-4 h-4 mr-2" />
                  Sign In
                </Button>
              )}
            </>
          )}

          {/* Mobile Menu */}
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72">
              <nav className="flex flex-col gap-4 mt-8">
                {navLinks.map((link) => (
                  <Link
                    key={link.href}
                    to={link.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`text-lg font-medium p-2 rounded-lg transition-colors ${
                      location.pathname === link.href
                        ? 'bg-accent/10 text-accent'
                        : 'text-foreground hover:bg-muted'
                    }`}
                  >
                    {link.label}
                  </Link>
                ))}
                
                <div className="border-t border-border pt-4 mt-4 space-y-2">
                  {user ? (
                    <>
                      <Link
                        to="/account"
                        onClick={() => setMobileMenuOpen(false)}
                        className="flex items-center gap-2 p-2 rounded-lg hover:bg-muted"
                      >
                        <Settings className="w-4 h-4" />
                        Account Settings
                      </Link>
                      {isOperator && (
                        <Link
                          to="/operator"
                          onClick={() => setMobileMenuOpen(false)}
                          className="flex items-center gap-2 p-2 rounded-lg hover:bg-muted"
                        >
                          <Truck className="w-4 h-4" />
                          Operator Dashboard
                        </Link>
                      )}
                      {isAdmin && (
                        <Link
                          to="/admin"
                          onClick={() => setMobileMenuOpen(false)}
                          className="flex items-center gap-2 p-2 rounded-lg hover:bg-muted"
                        >
                          <Shield className="w-4 h-4" />
                          Admin Portal
                        </Link>
                      )}
                      <div className="flex items-center gap-2 px-2">
                        {profile.avatarUrl ? (
                          <img src={profile.avatarUrl} alt="" className="w-8 h-8 rounded-full object-cover" />
                        ) : (
                          <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center text-accent-foreground text-sm font-medium">
                            {initials}
                          </div>
                        )}
                        <p className="text-sm text-muted-foreground">
                          Welcome, {displayName}
                        </p>
                      </div>
                      <Button
                        variant="outline"
                        className="w-full"
                        onClick={() => {
                          signOut();
                          setMobileMenuOpen(false);
                        }}
                      >
                        <LogOut className="w-4 h-4 mr-2" />
                        Sign Out
                      </Button>
                    </>
                  ) : (
                    <Button
                      className="w-full"
                      onClick={() => {
                        onSignInClick?.();
                        setMobileMenuOpen(false);
                      }}
                    >
                      <User className="w-4 h-4 mr-2" />
                      Sign In
                    </Button>
                  )}
                </div>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
