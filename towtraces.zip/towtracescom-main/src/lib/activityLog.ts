import { supabase } from '@/integrations/supabase/client';
import type { Json } from '@/integrations/supabase/types';

export type AuditAction = 
  | 'record_created'
  | 'record_updated'
  | 'record_deleted'
  | 'status_changed'
  | 'record_released'
  | 'user_login'
  | 'user_logout'
  | 'user_signup'
  | 'claim_started'
  | 'claim_updated'
  | 'docs_submitted'
  | 'docs_approved'
  | 'docs_rejected'
  | 'payment_initiated'
  | 'payment_completed'
  | 'document_uploaded'
  | 'profile_updated';

export type EntityType = 'tow_record' | 'claim' | 'payment' | 'user' | 'document';

export interface AuditLogEntry {
  entity_type: EntityType;
  entity_id: string;
  action: AuditAction;
  metadata_json?: Json;
}

export async function logActivity(entry: AuditLogEntry): Promise<void> {
  const { data: { user } } = await supabase.auth.getUser();
  
  const { error } = await supabase.from('audit_logs').insert([{
    entity_type: entry.entity_type,
    entity_id: entry.entity_id,
    action: entry.action,
    actor_user_id: user?.id || null,
    metadata_json: entry.metadata_json || {},
  }]);

  if (error) {
    console.error('Failed to log activity:', error);
  }
}

// Tow Record Actions
export async function logRecordCreated(recordId: string, details: Record<string, unknown>): Promise<void> {
  await logActivity({
    entity_type: 'tow_record',
    entity_id: recordId,
    action: 'record_created',
    metadata_json: details as Json,
  });
}

export async function logRecordUpdated(recordId: string, changes: Record<string, unknown>): Promise<void> {
  await logActivity({
    entity_type: 'tow_record',
    entity_id: recordId,
    action: 'record_updated',
    metadata_json: changes as Json,
  });
}

export async function logStatusChanged(recordId: string, oldStatus: string, newStatus: string): Promise<void> {
  await logActivity({
    entity_type: 'tow_record',
    entity_id: recordId,
    action: 'status_changed',
    metadata_json: { old_status: oldStatus, new_status: newStatus } as Json,
  });
}

export async function logRecordReleased(recordId: string): Promise<void> {
  await logActivity({
    entity_type: 'tow_record',
    entity_id: recordId,
    action: 'record_released',
    metadata_json: { released_at: new Date().toISOString() } as Json,
  });
}

// User Actions
export async function logUserLogin(userId: string, method: string): Promise<void> {
  await logActivity({
    entity_type: 'user',
    entity_id: userId,
    action: 'user_login',
    metadata_json: { method, timestamp: new Date().toISOString() } as Json,
  });
}

export async function logUserLogout(userId: string): Promise<void> {
  await logActivity({
    entity_type: 'user',
    entity_id: userId,
    action: 'user_logout',
    metadata_json: { timestamp: new Date().toISOString() } as Json,
  });
}

export async function logUserSignup(userId: string, email: string): Promise<void> {
  await logActivity({
    entity_type: 'user',
    entity_id: userId,
    action: 'user_signup',
    metadata_json: { email, timestamp: new Date().toISOString() } as Json,
  });
}

export async function logProfileUpdated(userId: string, changes: Record<string, unknown>): Promise<void> {
  await logActivity({
    entity_type: 'user',
    entity_id: userId,
    action: 'profile_updated',
    metadata_json: { ...changes, timestamp: new Date().toISOString() } as Json,
  });
}

// Claim Actions
export async function logClaimStarted(claimId: string, towRecordId: string): Promise<void> {
  await logActivity({
    entity_type: 'claim',
    entity_id: claimId,
    action: 'claim_started',
    metadata_json: { tow_record_id: towRecordId, timestamp: new Date().toISOString() } as Json,
  });
}

export async function logDocsSubmitted(claimId: string): Promise<void> {
  await logActivity({
    entity_type: 'claim',
    entity_id: claimId,
    action: 'docs_submitted',
    metadata_json: { timestamp: new Date().toISOString() } as Json,
  });
}

export async function logDocsApproved(claimId: string): Promise<void> {
  await logActivity({
    entity_type: 'claim',
    entity_id: claimId,
    action: 'docs_approved',
    metadata_json: { timestamp: new Date().toISOString() } as Json,
  });
}

export async function logDocsRejected(claimId: string, reason: string): Promise<void> {
  await logActivity({
    entity_type: 'claim',
    entity_id: claimId,
    action: 'docs_rejected',
    metadata_json: { reason, timestamp: new Date().toISOString() } as Json,
  });
}

// Document Actions
export async function logDocumentUploaded(documentId: string, docType: string, claimId: string): Promise<void> {
  await logActivity({
    entity_type: 'document',
    entity_id: documentId,
    action: 'document_uploaded',
    metadata_json: { doc_type: docType, claim_id: claimId, timestamp: new Date().toISOString() } as Json,
  });
}

// Payment Actions
export async function logPaymentInitiated(paymentId: string, amount: number, claimId: string): Promise<void> {
  await logActivity({
    entity_type: 'payment',
    entity_id: paymentId,
    action: 'payment_initiated',
    metadata_json: { amount, claim_id: claimId, timestamp: new Date().toISOString() } as Json,
  });
}

export async function logPaymentCompleted(paymentId: string, amount: number): Promise<void> {
  await logActivity({
    entity_type: 'payment',
    entity_id: paymentId,
    action: 'payment_completed',
    metadata_json: { amount, timestamp: new Date().toISOString() } as Json,
  });
}
