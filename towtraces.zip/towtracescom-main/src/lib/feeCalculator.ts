// Vehicle types with default fee multipliers
export const VEHICLE_TYPES = {
  motorcycle: { label: 'Motorcycle', multiplier: 0.7 },
  compact: { label: 'Compact Car', multiplier: 0.85 },
  sedan: { label: 'Sedan', multiplier: 1.0 },
  standard: { label: 'Standard (Sedan/Coupe)', multiplier: 1.0 },
  coupe: { label: 'Coupe', multiplier: 1.0 },
  convertible: { label: 'Convertible', multiplier: 1.1 },
  suv: { label: 'SUV/Crossover', multiplier: 1.2 },
  truck: { label: 'Pickup Truck', multiplier: 1.3 },
  van: { label: 'Van/Minivan', multiplier: 1.25 },
  wagon: { label: 'Station Wagon', multiplier: 1.1 },
  sports: { label: 'Sports Car', multiplier: 1.3 },
  luxury: { label: 'Luxury Vehicle', multiplier: 1.4 },
  electric: { label: 'Electric Vehicle (EV)', multiplier: 1.2 },
  commercial: { label: 'Commercial Vehicle', multiplier: 1.5 },
  trailer: { label: 'Trailer', multiplier: 1.5 },
  bus: { label: 'Bus/Shuttle', multiplier: 2.0 },
  heavy_duty: { label: 'Heavy Duty/RV', multiplier: 2.0 },
} as const;

export type VehicleType = keyof typeof VEHICLE_TYPES;

// Base fees (can be overridden by fee_configurations)
const BASE_FEES = {
  towFee: 150,
  dailyStorageFee: 45,
  adminFee: 50,
  gateFee: 0,
};

export interface FeeBreakdown {
  towFee: number;
  dailyStorageFee: number;
  adminFee: number;
  gateFee: number;
  daysStored: number;
  storageTotalFee: number;
  totalDue: number;
}

export interface FeeConfiguration {
  tow_fee: number;
  daily_storage_fee: number;
  admin_fee: number;
  gate_fee: number;
}

export function calculateFees(
  vehicleType: VehicleType,
  storageStartDate: Date,
  customConfig?: FeeConfiguration | null
): FeeBreakdown {
  const multiplier = VEHICLE_TYPES[vehicleType]?.multiplier ?? 1.0;
  
  // Use custom config or base fees
  const baseTowFee = customConfig?.tow_fee ?? BASE_FEES.towFee;
  const baseDailyStorage = customConfig?.daily_storage_fee ?? BASE_FEES.dailyStorageFee;
  const baseAdminFee = customConfig?.admin_fee ?? BASE_FEES.adminFee;
  const baseGateFee = customConfig?.gate_fee ?? BASE_FEES.gateFee;

  // Apply vehicle type multiplier
  const towFee = Math.round(baseTowFee * multiplier * 100) / 100;
  const dailyStorageFee = Math.round(baseDailyStorage * multiplier * 100) / 100;
  const adminFee = Math.round(baseAdminFee * multiplier * 100) / 100;
  const gateFee = baseGateFee; // Gate fee typically doesn't scale

  // Calculate days stored (minimum 1 day)
  const now = new Date();
  const diffMs = now.getTime() - storageStartDate.getTime();
  const daysStored = Math.max(1, Math.ceil(diffMs / (1000 * 60 * 60 * 24)));

  const storageTotalFee = dailyStorageFee * daysStored;
  const totalDue = towFee + storageTotalFee + adminFee + gateFee;

  return {
    towFee,
    dailyStorageFee,
    adminFee,
    gateFee,
    daysStored,
    storageTotalFee,
    totalDue,
  };
}

export function getVehicleTypeLabel(type: VehicleType): string {
  return VEHICLE_TYPES[type]?.label ?? 'Standard';
}

export function getVehicleTypeOptions(): Array<{ value: VehicleType; label: string }> {
  return Object.entries(VEHICLE_TYPES).map(([value, { label }]) => ({
    value: value as VehicleType,
    label,
  }));
}
