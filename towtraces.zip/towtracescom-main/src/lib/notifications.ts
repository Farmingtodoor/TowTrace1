import { supabase } from '@/integrations/supabase/client';

type NotificationType = 
  | 'payment_completed' 
  | 'subscription_created' 
  | 'subscription_cancelled' 
  | 'claim_status_changed'
  | 'vehicle_released';

interface NotificationData {
  amount?: string;
  transactionId?: string;
  plan?: string;
  status?: string;
  message?: string;
}

export async function sendNotification(
  type: NotificationType,
  to: string,
  name?: string,
  data?: NotificationData
) {
  try {
    const { data: response, error } = await supabase.functions.invoke('send-notification', {
      body: { type, to, name, data },
    });

    if (error) {
      console.error('Failed to send notification:', error);
      return { success: false, error };
    }

    return { success: true, data: response };
  } catch (error) {
    console.error('Notification error:', error);
    return { success: false, error };
  }
}

export async function sendPaymentConfirmation(
  email: string,
  name: string,
  amount: number,
  transactionId?: string
) {
  return sendNotification('payment_completed', email, name, {
    amount: amount.toFixed(2),
    transactionId: transactionId || 'N/A',
  });
}

export async function sendSubscriptionConfirmation(
  email: string,
  name: string,
  plan: string
) {
  return sendNotification('subscription_created', email, name, { plan });
}

export async function sendClaimStatusUpdate(
  email: string,
  name: string,
  status: string,
  message?: string
) {
  return sendNotification('claim_status_changed', email, name, { status, message });
}

export async function sendVehicleReleasedNotification(
  email: string,
  name: string,
  vehicleInfo: string,
  yardName: string,
  claimsUrl: string
) {
  return sendNotification('vehicle_released', email, name, {
    vehicleInfo,
    yardName,
    claimsUrl,
  } as any);
}
