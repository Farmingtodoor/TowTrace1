import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  MapPin, 
  User, 
  Store, 
  FileText, 
  CheckCircle, 
  Truck,
  Shield,
  DollarSign,
  Clock,
  Users
} from "lucide-react";
import Header from "@/components/Header";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import { geocodeZipCode } from "@/services/geocodingService";
import { useFocusField } from "@/hooks/useFocusField";

const US_STATES = [
  "Alabama","Alaska","Arizona","Arkansas","California","Colorado","Connecticut","Delaware","Florida","Georgia",
  "Hawaii","Idaho","Illinois","Indiana","Iowa","Kansas","Kentucky","Louisiana","Maine","Maryland",
  "Massachusetts","Michigan","Minnesota","Mississippi","Missouri","Montana","Nebraska","Nevada","New Hampshire","New Jersey",
  "New Mexico","New York","North Carolina","North Dakota","Ohio","Oklahoma","Oregon","Pennsylvania","Rhode Island","South Carolina",
  "South Dakota","Tennessee","Texas","Utah","Vermont","Virginia","Washington","West Virginia","Wisconsin","Wyoming",
];

const STATE_ABBREVIATIONS = [
  "AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA",
  "HI","ID","IL","IN","IA","KS","KY","LA","ME","MD",
  "MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ",
  "NM","NY","NC","ND","OH","OK","OR","PA","RI","SC",
  "SD","TN","TX","UT","VT","VA","WA","WV","WI","WY",
];

const STATE_BY_ABBREVIATION: Record<string, string> = Object.fromEntries(
  STATE_ABBREVIATIONS.map((abbr, i) => [abbr, US_STATES[i]])
);


const farmerApplicationSchema = z.object({
  firstName: z.string().trim().min(1, { message: "First name is required" }).max(80),
  lastName: z.string().trim().min(1, { message: "Last name is required" }).max(80),
  email: z.string().trim().email({ message: "Enter a valid email address" }).max(255),
  farmName: z.string().trim().min(1, { message: "Farm name is required" }).max(120),
  farmAddress: z.string().trim().min(1, { message: "Farm address is required" }).max(300),
  city: z
    .string()
    .trim()
    .min(2, { message: "City is required so customers can find your farm" })
    .max(100, { message: "City must be less than 100 characters" }),
  state: z
    .string()
    .trim()
    .min(2, { message: "State is required so customers can find your farm" })
    .max(60),
  zipCode: z
    .string()
    .trim()
    .regex(/^\d{5}$/, { message: "Enter a valid 5-digit ZIP code" }),
});

export default function FarmerOnboarding() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const requestedStep = searchParams.get("step");
  const validSteps = ["personal", "farm", "products", "business"];
  const [currentStep, setCurrentStep] = useState(
    requestedStep && validSteps.includes(requestedStep) ? requestedStep : "overview"
  );
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [formData, setFormData] = useState({
    // Personal Information
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    
    // Farm Information
    farmName: "",
    farmAddress: "",
    city: "",
    state: "",
    zipCode: "",
    farmSize: "",
    farmType: "",
    description: "",
    
    // Products
    productCategories: [] as string[],
    organicCertified: false,
    
    // Business
    businessLicense: "",
    taxId: "",
    insuranceInfo: "",
    
    // Preferences
    deliveryRadius: "25",
    processingServices: [] as string[],
    acceptsOnlinePayments: true,
  });

  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [zipLookup, setZipLookup] = useState<{ status: "idle" | "loading" | "found" | "error"; message?: string }>({ status: "idle" });

  // Deep-link support: /farmer-onboarding?step=farm&focus=farmName
  useFocusField(currentStep !== "overview");

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setFieldErrors(prev => {
      if (!prev[field]) return prev;
      const next = { ...prev };
      delete next[field];
      return next;
    });
  };

  const handleZipChange = async (raw: string) => {
    const zip = raw.replace(/\D/g, "").slice(0, 5);
    handleInputChange("zipCode", zip);

    if (zip.length !== 5) {
      setZipLookup({ status: "idle" });
      return;
    }

    setZipLookup({ status: "loading" });
    const result = await geocodeZipCode(zip);

    if (!result.success) {
      setZipLookup({ status: "error", message: "We couldn't find that ZIP code — enter your city and state manually." });
      return;
    }

    const fullState = STATE_BY_ABBREVIATION[result.state] ?? "";
    setFormData(prev => ({
      ...prev,
      zipCode: zip,
      city: result.city || prev.city,
      state: fullState || prev.state,
    }));
    setFieldErrors(prev => {
      const next = { ...prev };
      delete next.city;
      delete next.state;
      delete next.zipCode;
      return next;
    });
    setZipLookup({
      status: "found",
      message: `Auto-filled ${result.city}, ${fullState || result.state} from ZIP ${zip}. You can edit it if it's wrong.`,
    });
  };


  const handleCategoryToggle = (categories: string[]) => {
    setFormData(prev => ({ ...prev, selectedCategories: categories }));
  };

  const handleSubcategoryToggle = (subcategories: string[]) => {
    setFormData(prev => ({ ...prev, selectedSubcategories: subcategories }));
  };

  const handleProcessingToggle = (service: string) => {
    setFormData(prev => ({
      ...prev,
      processingServices: prev.processingServices.includes(service)
        ? prev.processingServices.filter(s => s !== service)
        : [...prev.processingServices, service]
    }));
  };

  const handleSubmit = async () => {
    const validation = farmerApplicationSchema.safeParse(formData);

    if (!validation.success) {
      const errors: Record<string, string> = {};
      validation.error.issues.forEach(issue => {
        const key = String(issue.path[0]);
        if (!errors[key]) errors[key] = issue.message;
      });
      setFieldErrors(errors);

      const locationMissing = errors.city || errors.state || errors.zipCode;
      if (locationMissing) setCurrentStep("farm");

      toast({
        title: "Please complete required details",
        description: locationMissing
          ? "Your farm city, state and ZIP code are required before your farm can be listed publicly."
          : Object.values(errors)[0],
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        toast({
          title: "Authentication required",
          description: "Please sign in to submit your application.",
          variant: "destructive"
        });
        return;
      }

      const applicationData = {
        user_id: user.id,
        full_name: `${formData.firstName} ${formData.lastName}`,
        email: formData.email,
        phone: formData.phone,
        farm_name: formData.farmName,
        farm_address: formData.farmAddress,
        farm_size: formData.farmSize,
        farm_description: formData.description,
        farming_experience: formData.farmType,
        business_registration_number: formData.businessLicense,
        tax_id: formData.taxId,
        insurance_details: formData.insuranceInfo,
        processing_methods: formData.processingServices,
        certifications: formData.organicCertified ? ['Organic'] : [],
        status: 'pending'
      };

      // Persist the public location on the profile — required before the farm can be approved/listed
      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          city: validation.data.city,
          state: validation.data.state,
          zip_code: validation.data.zipCode,
        })
        .eq('id', user.id);

      if (profileError) {
        console.error('Error saving farm location:', profileError);
        toast({
          title: "Could not save your farm location",
          description: "Your city and state are required. Please try again.",
          variant: "destructive"
        });
        return;
      }

      const { error } = await supabase
        .from('farmer_applications')
        .insert([applicationData]);

      if (error) {
        console.error('Error submitting application:', error);
        toast({
          title: "Submission failed",
          description: "There was an error submitting your application. Please try again.",
          variant: "destructive"
        });
        return;
      }

      setShowSuccess(true);
      
      // Close page after 3 seconds
      setTimeout(() => {
        navigate('/farmers');
      }, 3000);

    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Submission failed",
        description: "There was an error submitting your application. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const processingServices = [
    "Roasting", "Skin off / Special prep", "Basic portioning/packaging",
    "Custom butchering", "Vacuum sealing", "Smoking/Curing"
  ];

  if (showSuccess) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <CheckCircle className="w-24 h-24 text-green-500 mx-auto mb-6" />
          <h1 className="text-3xl font-bold mb-4 text-green-600">
            Application Submitted Successfully!!
          </h1>
          <p className="text-lg text-muted-foreground mb-4">
            We'll review your application and get back to you within 2-3 business days.
          </p>
          <p className="text-sm text-muted-foreground">
            Redirecting you back to the farmers page...
          </p>
        </div>
      </div>
    );
  }

  if (currentStep === "overview") {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-6xl mx-auto">
            {/* Hero Section */}
            <div className="text-center mb-16">
              <h1 className="text-4xl md:text-5xl font-bold mb-6">
                Start Selling on <span className="text-primary">Farm2Door</span>
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
                Join thousands of farmers connecting directly with customers. 
                No middleman, fair prices, and complete control over your sales.
              </p>
              <Button 
                size="lg" 
                className="text-lg px-8 py-6"
                onClick={() => setCurrentStep("personal")}
              >
                Start Your Application
              </Button>
            </div>

            {/* Benefits Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
              <Card className="text-center">
                <CardContent className="pt-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <DollarSign className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">Keep 95% of Sales</h3>
                  <p className="text-sm text-muted-foreground">
                    Only 5% platform fee. No hidden charges or monthly fees.
                  </p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="pt-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Users className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">Direct Customer Access</h3>
                  <p className="text-sm text-muted-foreground">
                    Build relationships with local customers who value quality.
                  </p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="pt-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Truck className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">Flexible Fulfillment</h3>
                  <p className="text-sm text-muted-foreground">
                    Offer pickup, delivery, or both. You set the rules.
                  </p>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardContent className="pt-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Clock className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">Quick Setup</h3>
                  <p className="text-sm text-muted-foreground">
                    Get approved and start selling within 2-3 business days.
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* How It Works */}
            <Card className="mb-16">
              <CardHeader>
                <CardTitle className="text-2xl text-center">How It Works</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-8">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                      1
                    </div>
                    <h4 className="font-semibold mb-2">Apply & Get Approved</h4>
                    <p className="text-sm text-muted-foreground">
                      Complete our simple application with your farm details and product information.
                    </p>
                  </div>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                      2
                    </div>
                    <h4 className="font-semibold mb-2">List Your Products</h4>
                    <p className="text-sm text-muted-foreground">
                      Add your products with photos, descriptions, and pricing. Set your delivery preferences.
                    </p>
                  </div>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
                      3
                    </div>
                    <h4 className="font-semibold mb-2">Start Selling</h4>
                    <p className="text-sm text-muted-foreground">
                      Receive orders, fulfill them, and get paid directly. We handle the payments for you.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Requirements */}
            <Card>
              <CardHeader>
                <CardTitle>Requirements to Join</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                      <Shield className="w-5 h-5 text-primary" />
                      Basic Requirements
                    </h4>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        Valid business license or farm registration
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        Liability insurance
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        Food safety certifications (where applicable)
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        Bank account for payments
                      </li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                      <FileText className="w-5 h-5 text-primary" />
                      Documentation
                    </h4>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        Farm location and size verification
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        Product quality standards agreement
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        Tax identification (if applicable)
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        Organic certifications (optional)
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-2">Farmer Application</h1>
            <p className="text-muted-foreground">
              Tell us about your farm and products to get started
            </p>
          </div>

          <Tabs value={currentStep} onValueChange={setCurrentStep} className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="personal" className="text-xs">
                <User className="w-4 h-4 mr-1" />
                Personal
              </TabsTrigger>
              <TabsTrigger value="farm" className="text-xs">
                <Store className="w-4 h-4 mr-1" />
                Farm Info
              </TabsTrigger>
              <TabsTrigger value="products" className="text-xs">
                <FileText className="w-4 h-4 mr-1" />
                Products
              </TabsTrigger>
              <TabsTrigger value="business" className="text-xs">
                <Shield className="w-4 h-4 mr-1" />
                Business
              </TabsTrigger>
            </TabsList>

            <TabsContent value="personal" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Personal Information</CardTitle>
                  <CardDescription>
                    Basic information about the primary farm contact
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        value={formData.firstName}
                        onChange={(e) => handleInputChange("firstName", e.target.value)}
                        placeholder="John"
                      />
                    </div>
                    <div>
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        value={formData.lastName}
                        onChange={(e) => handleInputChange("lastName", e.target.value)}
                        placeholder="Smith"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      placeholder="john@farm.com"
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => handleInputChange("phone", e.target.value)}
                      placeholder="(555) 123-4567"
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="farm" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Farm Information</CardTitle>
                  <CardDescription>
                    Details about your farm and operations
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="farmName">Farm Name</Label>
                    <Input
                      id="farmName"
                      value={formData.farmName}
                      onChange={(e) => handleInputChange("farmName", e.target.value)}
                      placeholder="Green Valley Farm"
                    />
                  </div>
                  <div>
                    <Label htmlFor="farmAddress">Farm Address</Label>
                    <Textarea
                      id="farmAddress"
                      value={formData.farmAddress}
                      onChange={(e) => handleInputChange("farmAddress", e.target.value)}
                      placeholder="123 Farm Road, Rural County, State 12345"
                    />
                    {fieldErrors.farmAddress && (
                      <p className="text-sm text-destructive mt-1">{fieldErrors.farmAddress}</p>
                    )}
                  </div>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="city">City <span className="text-destructive">*</span></Label>
                      <Input
                        id="city"
                        value={formData.city}
                        onChange={(e) => handleInputChange("city", e.target.value)}
                        placeholder="Dallas"
                        maxLength={100}
                        aria-invalid={!!fieldErrors.city}
                      />
                      {fieldErrors.city && (
                        <p className="text-sm text-destructive mt-1">{fieldErrors.city}</p>
                      )}
                    </div>
                    <div>
                      <Label htmlFor="state">State <span className="text-destructive">*</span></Label>
                      <Select value={formData.state} onValueChange={(value) => handleInputChange("state", value)}>
                        <SelectTrigger id="state" aria-invalid={!!fieldErrors.state}>
                          <SelectValue placeholder="Select state" />
                        </SelectTrigger>
                        <SelectContent className="max-h-64">
                          {US_STATES.map(stateName => (
                            <SelectItem key={stateName} value={stateName}>{stateName}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {fieldErrors.state && (
                        <p className="text-sm text-destructive mt-1">{fieldErrors.state}</p>
                      )}
                    </div>
                    <div>
                      <Label htmlFor="zipCode">ZIP Code <span className="text-destructive">*</span></Label>
                      <Input
                        id="zipCode"
                        value={formData.zipCode}
                        onChange={(e) => handleZipChange(e.target.value)}
                        placeholder="75212"
                        inputMode="numeric"
                        aria-invalid={!!fieldErrors.zipCode}
                      />
                      {fieldErrors.zipCode && (
                        <p className="text-sm text-destructive mt-1">{fieldErrors.zipCode}</p>
                      )}
                    </div>
                  </div>
                  {zipLookup.status === "loading" && (
                    <p className="text-xs text-muted-foreground">Looking up your ZIP code…</p>
                  )}
                  {zipLookup.status === "found" && zipLookup.message && (
                    <p className="text-xs text-primary">{zipLookup.message}</p>
                  )}
                  {zipLookup.status === "error" && zipLookup.message && (
                    <p className="text-xs text-destructive">{zipLookup.message}</p>
                  )}
                  <p className="text-xs text-muted-foreground">
                    Enter your ZIP code first and we'll fill in your city and state automatically. Your city and state are shown publicly so customers can find you. Farms without a city and state cannot be approved or listed.
                  </p>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="farmSize">Farm Size (acres)</Label>
                      <Input
                        id="farmSize"
                        value={formData.farmSize}
                        onChange={(e) => handleInputChange("farmSize", e.target.value)}
                        placeholder="50"
                      />
                    </div>
                    <div>
                      <Label htmlFor="farmType">Farm Type</Label>
                      <Select value={formData.farmType} onValueChange={(value) => handleInputChange("farmType", value)}>
                        <SelectTrigger id="farmType">
                          <SelectValue placeholder="Select farm type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="vegetable">Vegetable Farm</SelectItem>
                          <SelectItem value="fruit">Fruit Farm</SelectItem>
                          <SelectItem value="livestock">Livestock Farm</SelectItem>
                          <SelectItem value="dairy">Dairy Farm</SelectItem>
                          <SelectItem value="mixed">Mixed Farm</SelectItem>
                          <SelectItem value="organic">Organic Farm</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="description">Farm Description</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => handleInputChange("description", e.target.value)}
                      placeholder="Tell customers about your farm, farming practices, and what makes your products special..."
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="products" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Products & Services</CardTitle>
                  <CardDescription>
                    What products do you plan to sell?
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div id="productCategories" tabIndex={-1} className="outline-none">
                    <Label className="text-base font-semibold">Product Categories</Label>
                    <p className="text-sm text-muted-foreground mb-4">
                      Advanced category selection will be available soon. For now, please indicate if you're organic certified below.
                    </p>
                  </div>

                  <Separator />

                  <div>
                    <div className="flex items-center space-x-2 mb-4">
                      <Checkbox
                        id="organic"
                        checked={formData.organicCertified}
                        onCheckedChange={(checked) => handleInputChange("organicCertified", checked)}
                      />
                      <Label htmlFor="organic" className="font-semibold">
                        Organic Certified
                      </Label>
                    </div>
                  </div>

                  <Separator />

                  <div>
                    <Label className="text-base font-semibold">Processing Services (Optional)</Label>
                    <p className="text-sm text-muted-foreground mb-3">
                      Additional services you can offer to customers
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {processingServices.map((service) => (
                        <div key={service} className="flex items-center space-x-2">
                          <Checkbox
                            id={service}
                            checked={formData.processingServices.includes(service)}
                            onCheckedChange={() => handleProcessingToggle(service)}
                          />
                          <Label htmlFor={service} className="text-sm">
                            {service}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  <div>
                    <Label htmlFor="deliveryRadius">Delivery Radius (miles)</Label>
                    <Select value={formData.deliveryRadius} onValueChange={(value) => handleInputChange("deliveryRadius", value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="10">10 miles</SelectItem>
                        <SelectItem value="25">25 miles</SelectItem>
                        <SelectItem value="50">50 miles</SelectItem>
                        <SelectItem value="100">100 miles</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="business" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Business Information</CardTitle>
                  <CardDescription>
                    Legal and compliance information
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="businessLicense">Business License Number</Label>
                    <Input
                      id="businessLicense"
                      value={formData.businessLicense}
                      onChange={(e) => handleInputChange("businessLicense", e.target.value)}
                      placeholder="BL-123456789"
                    />
                  </div>
                  <div>
                    <Label htmlFor="taxId">Tax ID / EIN (if applicable)</Label>
                    <Input
                      id="taxId"
                      value={formData.taxId}
                      onChange={(e) => handleInputChange("taxId", e.target.value)}
                      placeholder="12-3456789"
                    />
                  </div>
                  <div>
                    <Label htmlFor="insuranceInfo">Liability Insurance Information</Label>
                    <Textarea
                      id="insuranceInfo"
                      value={formData.insuranceInfo}
                      onChange={(e) => handleInputChange("insuranceInfo", e.target.value)}
                      placeholder="Insurance company, policy number, coverage amount..."
                    />
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <h4 className="font-semibold">Payment Preferences</h4>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="payments"
                        checked={formData.acceptsOnlinePayments}
                        onCheckedChange={(checked) => handleInputChange("acceptsOnlinePayments", checked)}
                      />
                      <Label htmlFor="payments">
                        Accept online payments through Farm2Door (credit cards, Apple Pay, etc.)
                      </Label>
                    </div>
                  </div>

                  <Button 
                    onClick={handleSubmit} 
                    className="w-full mt-6" 
                    size="lg"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? "Submitting..." : "Submit Application"}
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <div className="flex justify-between mt-6">
            <Button 
              variant="outline" 
              onClick={() => setCurrentStep("overview")}
            >
              Back to Overview
            </Button>
            <div className="flex gap-2">
              {currentStep !== "personal" && (
                <Button 
                  variant="outline"
                  onClick={() => {
                    const steps = ["personal", "farm", "products", "business"];
                    const currentIndex = steps.indexOf(currentStep);
                    if (currentIndex > 0) setCurrentStep(steps[currentIndex - 1]);
                  }}
                >
                  Previous
                </Button>
              )}
              {currentStep !== "business" && (
                <Button 
                  onClick={() => {
                    const steps = ["personal", "farm", "products", "business"];
                    const currentIndex = steps.indexOf(currentStep);
                    if (currentIndex < steps.length - 1) setCurrentStep(steps[currentIndex + 1]);
                  }}
                >
                  Next
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}