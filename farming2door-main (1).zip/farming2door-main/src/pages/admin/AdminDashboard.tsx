import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useAdmin } from "@/contexts/AdminContext";
import { BarChart3, Package, ShoppingCart, Users, Mail, TrendingUp } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export default function AdminDashboard() {
  const { userRole, isSuperAdmin, isAdmin, isFarmer } = useAdmin();
  const navigate = useNavigate();
  const [stats, setStats] = useState<any[]>([]);
  const [recentActivity, setRecentActivity] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const getRoleDisplay = (role: string) => {
    const roleMap = {
      'super_admin': { label: 'Super Admin', variant: 'destructive' as const },
      'admin': { label: 'Admin', variant: 'default' as const },
      'farmer': { label: 'Farmer', variant: 'secondary' as const },
      'customer': { label: 'Customer', variant: 'outline' as const }
    };
    return roleMap[role as keyof typeof roleMap] || { label: role, variant: 'outline' as const };
  };

  const roleInfo = getRoleDisplay(userRole || 'customer');

  useEffect(() => {
    fetchDashboardData();
  }, [isAdmin, isFarmer]);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      
      // Fetch orders count
      const { count: ordersCount } = await supabase
        .from('orders')
        .select('*', { count: 'exact', head: true });

      // Fetch products count  
      const { count: productsCount } = await supabase
        .from('products')
        .select('*', { count: 'exact', head: true });

      // Fetch users count
      const { count: usersCount } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true });

      // Fetch email subscribers count
      const { count: subscribersCount } = await supabase
        .from('app_notifications')
        .select('*', { count: 'exact', head: true });

      // Calculate total revenue
      const { data: orders } = await supabase
        .from('orders')
        .select('total_amount')
        .eq('status', 'delivered');

      const totalRevenue = orders?.reduce((sum, order) => sum + (order.total_amount || 0), 0) || 0;

      // Get recent activity
      const { data: recentOrders } = await supabase
        .from('orders')
        .select(`
          id, status, created_at,
          profiles!orders_customer_id_fkey(full_name, email)
        `)
        .order('created_at', { ascending: false })
        .limit(5);

      const activity = recentOrders?.map(order => ({
        id: order.id,
        message: `Order ${order.status} for ${order.profiles?.full_name || order.profiles?.email || 'Unknown customer'}`,
        time: new Date(order.created_at).toLocaleString(),
        status: order.status
      })) || [];

      setRecentActivity(activity);

      const dashboardStats = [
        {
          title: "Total Orders",
          value: ordersCount?.toString() || "0",
          description: "All time orders",
          icon: ShoppingCart,
          show: isAdmin || isFarmer,
          path: "/admin/orders"
        },
        {
          title: "Active Products",
          value: productsCount?.toString() || "0", 
          description: "Products in catalog",
          icon: Package,
          show: isAdmin || isFarmer,
          path: isFarmer ? "/farmer-products" : "/admin/products"
        },
        {
          title: "Total Users",
          value: usersCount?.toString() || "0",
          description: "Registered users",
          icon: Users,
          show: isAdmin,
          path: "/admin/users"
        },
        {
          title: "Email Subscribers",
          value: subscribersCount?.toString() || "0",
          description: "Newsletter subscribers",
          icon: Mail,
          show: isAdmin,
          path: "/admin/settings"
        },
        {
          title: "Revenue",
          value: `$${totalRevenue.toFixed(2)}`,
          description: "From delivered orders",
          icon: TrendingUp,
          show: isAdmin,
          path: "/admin/orders"
        }
      ].filter(stat => stat.show);

      setStats(dashboardStats);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">
            Welcome to your admin dashboard
          </p>
        </div>
        <Badge variant={roleInfo.variant} className="text-sm">
          {roleInfo.label}
        </Badge>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {loading ? (
          Array.from({ length: 3 }).map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="pb-2">
                <div className="h-4 bg-muted rounded w-1/2"></div>
              </CardHeader>
              <CardContent>
                <div className="h-8 bg-muted rounded w-1/3 mb-2"></div>
                <div className="h-3 bg-muted rounded w-2/3"></div>
              </CardContent>
            </Card>
          ))
        ) : (
          stats.map((stat) => (
            <Card key={stat.title} className="cursor-pointer hover:bg-muted/50 transition-colors" onClick={() => navigate(stat.path)}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {stat.title}
                </CardTitle>
                <stat.icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <p className="text-xs text-muted-foreground">
                  {stat.description}
                </p>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>
              Latest activities in your system
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {loading ? (
                Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="flex items-center space-x-4 p-2">
                    <div className="w-2 h-2 bg-muted rounded-full"></div>
                    <div className="flex-1 space-y-1">
                      <div className="h-4 bg-muted rounded w-3/4"></div>
                      <div className="h-3 bg-muted rounded w-1/2"></div>
                    </div>
                  </div>
                ))
              ) : recentActivity.length > 0 ? (
                recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-center space-x-4 cursor-pointer hover:bg-muted/50 p-2 rounded transition-colors" onClick={() => navigate("/admin/orders")}>
                    <div className={`w-2 h-2 rounded-full ${
                      activity.status === 'delivered' ? 'bg-green-500' :
                      activity.status === 'pending' ? 'bg-yellow-500' :
                      activity.status === 'confirmed' ? 'bg-blue-500' :
                      'bg-gray-500'
                    }`}></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">{activity.message}</p>
                      <p className="text-xs text-muted-foreground">{activity.time}</p>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-sm text-muted-foreground text-center py-4">No recent activity</p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>
              Common administrative tasks
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {isFarmer && (
                <>
                  <div className="p-3 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors" onClick={() => navigate("/farmer-products")}>
                    <p className="text-sm font-medium">Add New Product</p>
                    <p className="text-xs text-muted-foreground">Create a new product listing</p>
                  </div>
                  <div className="p-3 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors" onClick={() => navigate("/admin/orders")}>
                    <p className="text-sm font-medium">Manage Orders</p>
                    <p className="text-xs text-muted-foreground">Update order statuses</p>
                  </div>
                </>
              )}
              {isAdmin && (
                <>
                  <div className="p-3 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors" onClick={() => navigate("/admin/users")}>
                    <p className="text-sm font-medium">User Management</p>
                    <p className="text-xs text-muted-foreground">Manage user accounts</p>
                  </div>
                  <div className="p-3 border rounded-lg hover:bg-muted/50 cursor-pointer transition-colors" onClick={() => navigate("/admin/settings")}>
                    <p className="text-sm font-medium">System Settings</p>
                    <p className="text-xs text-muted-foreground">Configure application settings</p>
                  </div>
                </>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}