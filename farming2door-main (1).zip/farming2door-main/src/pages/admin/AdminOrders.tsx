import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAdmin } from "@/contexts/AdminContext";

export default function AdminOrders() {
  const [filteredStatus, setFilteredStatus] = useState<string | null>(null);
  const [orderList, setOrderList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const { isAdmin, isFarmer } = useAdmin();

  useEffect(() => {
    fetchOrders();
  }, [isAdmin, isFarmer]);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const { data: orders, error } = await supabase
        .from('orders')
        .select(`
          id,
          status,
          total_amount,
          created_at,
          profiles!orders_customer_id_fkey(full_name, email),
          order_items(quantity)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const formattedOrders = orders?.map(order => ({
        id: order.id,
        customer: order.profiles?.full_name || order.profiles?.email || 'Unknown',
        total: `$${order.total_amount?.toFixed(2) || '0.00'}`,
        status: order.status,
        date: new Date(order.created_at).toLocaleDateString(),
        items: order.order_items?.reduce((sum, item) => sum + item.quantity, 0) || 0
      })) || [];

      setOrderList(formattedOrders);
    } catch (error) {
      console.error('Error fetching orders:', error);
      toast.error('Failed to fetch orders');
    } finally {
      setLoading(false);
    }
  };

  const statusOrder = ['pending', 'confirmed', 'processing', 'delivered', 'cancelled'];

  const filteredOrders = filteredStatus 
    ? orderList.filter(order => order.status === filteredStatus)
    : orderList;

  const handleFilterByStatus = (status: string | null) => {
    setFilteredStatus(status);
    toast.success(`Filtered orders by ${status || 'all'} status`);
  };

  const handleStatusChange = async (orderId: string, currentStatus: string) => {
    const currentIndex = statusOrder.indexOf(currentStatus);
    const nextIndex = (currentIndex + 1) % statusOrder.length;
    const newStatus = statusOrder[nextIndex];
    
    try {
      const { error } = await supabase
        .from('orders')
        .update({ status: newStatus })
        .eq('id', orderId);

      if (error) throw error;

      setOrderList(orders => 
        orders.map(order => 
          order.id === orderId 
            ? { ...order, status: newStatus }
            : order
        )
      );
      toast.success(`Order status changed to ${newStatus}`);
    } catch (error) {
      console.error('Error updating order status:', error);
      toast.error('Failed to update order status');
    }
  };

  const handleViewOrder = (orderId: string) => {
    toast.success(`Opening order #${orderId} details`);
    // In a real app, this would navigate to order details page
  };

  const handleUpdateOrder = (orderId: string) => {
    toast.success(`Opening order #${orderId} for editing`);
    // In a real app, this would open an edit modal or navigate to edit page
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'warning';
      case 'confirmed': return 'default';
      case 'processing': return 'secondary';
      case 'delivered': return 'success';
      case 'cancelled': return 'destructive';
      default: return 'outline';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Order Management</h1>
          <p className="text-muted-foreground">Track and manage all orders</p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card className="cursor-pointer hover:bg-muted/50 transition-colors" onClick={() => handleFilterByStatus(null)}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {loading ? '...' : orderList.length}
            </div>
            <p className="text-xs text-muted-foreground">Click to show all</p>
          </CardContent>
        </Card>
        <Card className="cursor-pointer hover:bg-muted/50 transition-colors" onClick={() => handleFilterByStatus('pending')}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Pending</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{orderList.filter(o => o.status === 'pending').length}</div>
            <p className="text-xs text-muted-foreground">Click to filter</p>
          </CardContent>
        </Card>
        <Card className="cursor-pointer hover:bg-muted/50 transition-colors" onClick={() => handleFilterByStatus('processing')}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Processing</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{orderList.filter(o => o.status === 'processing').length}</div>
            <p className="text-xs text-muted-foreground">Click to filter</p>
          </CardContent>
        </Card>
        <Card className="cursor-pointer hover:bg-muted/50 transition-colors" onClick={() => handleFilterByStatus('delivered')}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Delivered</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{orderList.filter(o => o.status === 'delivered').length}</div>
            <p className="text-xs text-muted-foreground">Click to filter</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Orders</CardTitle>
          <CardDescription>
            {filteredStatus ? `Showing ${filteredStatus} orders` : 'Latest orders in the system'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredOrders.map((order) => (
              <div key={order.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center gap-3">
                    <div>
                      <p className="font-medium">Order #{order.id}</p>
                      <p className="text-sm text-muted-foreground">
                        {order.customer} • {order.items} items • {order.date}
                      </p>
                    </div>
                    <Badge 
                      variant={getStatusColor(order.status) as any}
                      className="cursor-pointer hover:opacity-80 transition-opacity"
                      onClick={() => handleStatusChange(order.id, order.status)}
                      title="Click to change status"
                    >
                      {order.status}
                    </Badge>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <span className="font-semibold">{order.total}</span>
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleViewOrder(order.id)}
                    >
                      View
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleUpdateOrder(order.id)}
                    >
                      Update
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}