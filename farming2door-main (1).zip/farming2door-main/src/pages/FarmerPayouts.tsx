import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { DollarSign, Calendar, Clock, CheckCircle, XCircle, Home, ArrowLeft, Settings } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Link } from "react-router-dom";

interface PayoutRequest {
  id: string;
  amount: number;
  status: string;
  payment_method: string;
  bank_account_holder: string;
  bank_account_number: string;
  routing_number: string;
  additional_notes: string;
  requested_at: string;
  reviewed_at: string | null;
  admin_notes: string | null;
}

export default function FarmerPayouts() {
  const { user } = useAuth();
  const [payoutRequests, setPayoutRequests] = useState<PayoutRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    amount: "",
    bank_account_holder: "",
    bank_account_number: "",
    routing_number: "",
    additional_notes: "",
  });

  useEffect(() => {
    if (user) {
      fetchPayoutRequests();
    }
  }, [user]);

  const fetchPayoutRequests = async () => {
    try {
      const { data, error } = await supabase.rpc('get_decrypted_payout_requests', {
        p_farmer_id: user?.id
      });

      if (error) throw error;
      setPayoutRequests(data || []);
    } catch (error) {
      console.error("Error fetching payout requests:", error);
      toast.error("Failed to load payout requests");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.amount || !formData.bank_account_holder || !formData.bank_account_number || !formData.routing_number) {
      toast.error("Please fill in all required fields");
      return;
    }

    try {
      const { data, error } = await supabase.rpc('insert_encrypted_payout_request', {
        p_farmer_id: user?.id,
        p_amount: parseFloat(formData.amount),
        p_payment_method: 'bank_transfer',
        p_bank_account_holder: formData.bank_account_holder,
        p_bank_account_number: formData.bank_account_number,
        p_routing_number: formData.routing_number,
        p_additional_notes: formData.additional_notes || null
      });

      if (error) throw error;

      toast.success("Payout request submitted successfully!");
      setIsDialogOpen(false);
      setFormData({
        amount: "",
        bank_account_holder: "",
        bank_account_number: "",
        routing_number: "",
        additional_notes: "",
      });
      fetchPayoutRequests();
    } catch (error) {
      console.error("Error submitting payout request:", error);
      toast.error("Failed to submit payout request");
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
      case "approved":
        return <Badge variant="default"><CheckCircle className="h-3 w-3 mr-1" />Approved</Badge>;
      case "rejected":
        return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" />Rejected</Badge>;
      case "paid":
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200"><CheckCircle className="h-3 w-3 mr-1" />Paid</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto py-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-1/4"></div>
          <div className="h-32 bg-muted rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Link 
          to="/admin" 
          className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Admin Portal
        </Link>
      </div>
      
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          <h1 className="text-3xl font-bold">Payout Requests</h1>
          <Link 
            to="/admin" 
            className="flex items-center gap-2 px-3 py-1 text-sm bg-muted hover:bg-muted/80 rounded-lg transition-colors"
          >
            <Settings className="h-3 w-3" />
            Admin Portal
          </Link>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <DollarSign className="h-4 w-4 mr-2" />
              Request Payout
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Request Payout</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="amount">Amount ($) *</Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  placeholder="0.00"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="bank_account_holder">Account Holder Name *</Label>
                <Input
                  id="bank_account_holder"
                  value={formData.bank_account_holder}
                  onChange={(e) => setFormData({ ...formData, bank_account_holder: e.target.value })}
                  placeholder="John Doe"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="bank_account_number">Account Number *</Label>
                <Input
                  id="bank_account_number"
                  value={formData.bank_account_number}
                  onChange={(e) => setFormData({ ...formData, bank_account_number: e.target.value })}
                  placeholder="1234567890"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="routing_number">Routing Number *</Label>
                <Input
                  id="routing_number"
                  value={formData.routing_number}
                  onChange={(e) => setFormData({ ...formData, routing_number: e.target.value })}
                  placeholder="021000021"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="additional_notes">Additional Notes</Label>
                <Textarea
                  id="additional_notes"
                  value={formData.additional_notes}
                  onChange={(e) => setFormData({ ...formData, additional_notes: e.target.value })}
                  placeholder="Any additional information..."
                  rows={3}
                />
              </div>
              
              <div className="flex gap-2 pt-4">
                <Button type="submit" className="flex-1">Submit Request</Button>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {payoutRequests.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center">
            <DollarSign className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">No payout requests yet</h3>
            <p className="text-muted-foreground mb-4">
              Request your first payout to get started
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {payoutRequests.map((request) => (
            <Card key={request.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5" />
                    ${request.amount.toFixed(2)}
                  </CardTitle>
                  {getStatusBadge(request.status)}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Account Holder:</span>
                    <p className="text-muted-foreground">{request.bank_account_holder}</p>
                  </div>
                  <div>
                    <span className="font-medium">Account Number:</span>
                    <p className="text-muted-foreground">****{request.bank_account_number ? request.bank_account_number.slice(-4) : '****'}</p>
                  </div>
                  <div>
                    <span className="font-medium">Requested:</span>
                    <p className="text-muted-foreground flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {new Date(request.requested_at).toLocaleDateString()}
                    </p>
                  </div>
                  {request.reviewed_at && (
                    <div>
                      <span className="font-medium">Reviewed:</span>
                      <p className="text-muted-foreground flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {new Date(request.reviewed_at).toLocaleDateString()}
                      </p>
                    </div>
                  )}
                </div>
                
                {request.additional_notes && (
                  <div>
                    <span className="font-medium">Your Notes:</span>
                    <p className="text-muted-foreground">{request.additional_notes}</p>
                  </div>
                )}
                
                {request.admin_notes && (
                  <div>
                    <span className="font-medium">Admin Notes:</span>
                    <p className="text-muted-foreground">{request.admin_notes}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}