import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { AdminProvider } from "@/contexts/AdminContext";
import { CartProvider } from "@/contexts/CartContext";
import { CartSidebar } from "@/components/cart/CartSidebar";
import { AIChatButton } from "@/components/chat/AIChatButton";
import RealtimeNotifications from "@/components/realtime/RealtimeNotifications";
import { MandatoryReviewProvider } from "@/components/reviews/MandatoryReviewProvider";
import Index from "./pages/Index";
import Shop from "./pages/Shop";
import Farmers from "./pages/Farmers";
import Subscriptions from "./pages/Subscriptions";
import SubscriptionSuccess from "./pages/SubscriptionSuccess";
import About from "./pages/About";
import Team from "./pages/Team";
import Careers from "./pages/Careers";
import HowItWorks from "./pages/HowItWorks";
import CheckoutSuccess from "./pages/CheckoutSuccess";
import CheckoutCancelled from "./pages/CheckoutCancelled";
import FarmerOnboarding from "./pages/FarmerOnboarding";
import MyOrders from "./pages/MyOrders";
import CustomOrders from "./pages/CustomOrders";
import NewCustomOrder from "./pages/NewCustomOrder";
import FarmerCustomOrders from "./pages/FarmerCustomOrders";
import FarmerOrders from "./pages/FarmerOrders";
import AccountSettings from "./pages/AccountSettings";
import NotFound from "./pages/NotFound";
import { AdminLayout } from "@/components/admin/AdminLayout";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminUsers from "./pages/admin/AdminUsers";
import AdminOrders from "./pages/admin/AdminOrders";
import AdminSettings from "./pages/admin/AdminSettings";
import AdminWaitlist from "./pages/admin/AdminWaitlist";

import AdminFarmers from "./pages/admin/AdminFarmers";
import AdminFarmersFixRoles from "./pages/admin/AdminFarmersFixRoles";
import AdminProducts from "./pages/admin/AdminProducts";
import AdminNotifications from "./pages/admin/AdminNotifications";
import AdminRoles from "./pages/admin/AdminRoles";
import AdminPayouts from "./pages/admin/AdminPayouts";
import ProductDetail from "./pages/ProductDetail";
import FarmerProfile from "./pages/FarmerProfile";
import BreedingStock from "./pages/BreedingStock";
import CreateBreedingStockListing from "./pages/CreateBreedingStockListing";
import BreedingStockDetail from "./pages/BreedingStockDetail";
import FarmerProducts from "./pages/FarmerProducts";
import FarmerSubscriptions from "./pages/FarmerSubscriptions";
import FarmerPayouts from "./pages/FarmerPayouts";
import FarmerPromotions from "./pages/FarmerPromotions";
import FarmerPickupAvailability from "./pages/FarmerPickupAvailability";
import FarmerDeliverySettings from "./pages/FarmerDeliverySettings";
import Referrals from "./pages/Referrals";
import ResetPassword from "./pages/ResetPassword";
import FAQ from "./pages/FAQ";
import Blog from "./pages/Blog";
import HowBuyingHalfCowWorks from "./pages/blog/HowBuyingHalfCowWorks";
import Terms from "./pages/Terms";
import Privacy from "./pages/Privacy";
import RefundPolicy from "./pages/RefundPolicy";
import FoodSafety from "./pages/FoodSafety";
import Messages from "./pages/Messages";
import AdvancedBrowse from "./pages/AdvancedBrowse";
import FarmerAnalytics from "./pages/FarmerAnalytics";
import DriverSignup from "./pages/DriverSignup";
import DriverDashboard from "./pages/DriverDashboard";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <MandatoryReviewProvider>
        <AdminProvider>
          <CartProvider>
            <TooltipProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
              <Routes>
                <Route path="/" element={<Index />} />
            <Route path="/shop" element={<Shop />} />
            <Route path="/breeding-stock" element={<BreedingStock />} />
            <Route path="/breeding-stock/create" element={<CreateBreedingStockListing />} />
            <Route path="/breeding-stock/:id" element={<BreedingStockDetail />} />
            <Route path="/subscriptions" element={<Subscriptions />} />
            <Route path="/subscription-success" element={<SubscriptionSuccess />} />
            <Route path="/farmers" element={<Farmers />} />
                <Route path="/farmers/:farmerSlug" element={<FarmerProfile />} />
                <Route path="/products/:productId" element={<ProductDetail />} />
                <Route path="/about" element={<About />} />
                <Route path="/team" element={<Team />} />
                <Route path="/careers" element={<Careers />} />
                <Route path="/how-it-works" element={<HowItWorks />} />
                <Route path="/checkout-success" element={<CheckoutSuccess />} />
                <Route path="/checkout-cancelled" element={<CheckoutCancelled />} />
                <Route path="/farmer-onboarding" element={<FarmerOnboarding />} />
                <Route path="/farmer-products" element={<FarmerProducts />} />
            <Route path="/farmer-subscriptions" element={<FarmerSubscriptions />} />
            <Route path="/farmer-payouts" element={<FarmerPayouts />} />
                <Route path="/farmer-promotions" element={<FarmerPromotions />} />
                <Route path="/farmer-pickup-availability" element={<FarmerPickupAvailability />} />
                <Route path="/farmer-delivery-settings" element={<FarmerDeliverySettings />} />

                <Route path="/referrals" element={<Referrals />} />
          <Route path="/messages" element={<Messages />} />
          <Route path="/search" element={<AdvancedBrowse />} />
                 <Route path="/farmer-analytics" element={<FarmerAnalytics />} />
                 <Route path="/driver-signup" element={<DriverSignup />} />
                 <Route path="/driver-dashboard" element={<DriverDashboard />} />
              <Route path="/reset-password" element={<ResetPassword />} />
              <Route path="/my-orders" element={<MyOrders />} />
              <Route path="/custom-orders" element={<CustomOrders />} />
              <Route path="/custom-orders/new" element={<NewCustomOrder />} />
              <Route path="/farmer/custom-orders" element={<FarmerCustomOrders />} />
              <Route path="/farmer/orders" element={<FarmerOrders />} />
                <Route path="/account-settings" element={<AccountSettings />} />
                
                {/* SEO & Compliance Pages */}
                <Route path="/faq" element={<FAQ />} />
                <Route path="/blog" element={<Blog />} />
                <Route path="/blog/how-buying-half-cow-works" element={<HowBuyingHalfCowWorks />} />
                <Route path="/terms" element={<Terms />} />
                <Route path="/privacy" element={<Privacy />} />
                <Route path="/refund-policy" element={<RefundPolicy />} />
                <Route path="/food-safety" element={<FoodSafety />} />
                
                {/* Admin Routes */}
                <Route path="/admin" element={<AdminLayout />}>
                  <Route index element={<AdminDashboard />} />
                  <Route path="users" element={<AdminUsers />} />
                  <Route path="orders" element={<AdminOrders />} />
                  <Route path="products" element={<AdminProducts />} />
                  <Route path="farmers" element={<AdminFarmers />} />
                  <Route path="fix-roles" element={<AdminFarmersFixRoles />} />
                  <Route path="notifications" element={<AdminNotifications />} />
                  <Route path="roles" element={<AdminRoles />} />
                  <Route path="payouts" element={<AdminPayouts />} />
                  <Route path="waitlist" element={<AdminWaitlist />} />
                  <Route path="settings" element={<AdminSettings />} />

                </Route>
                
                {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
                <Route path="*" element={<NotFound />} />
              </Routes>
              <CartSidebar />
              <AIChatButton />
              <RealtimeNotifications />
            </BrowserRouter>
            </TooltipProvider>
          </CartProvider>
        </AdminProvider>
      </MandatoryReviewProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
