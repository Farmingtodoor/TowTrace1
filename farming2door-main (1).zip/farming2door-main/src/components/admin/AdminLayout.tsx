import { Outlet, Navigate } from "react-router-dom";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AdminSidebar } from "./AdminSidebar";
import { useAdmin } from "@/contexts/AdminContext";
import { useAuth } from "@/contexts/AuthContext";
import { Loader2 } from "lucide-react";
import { NotificationBell } from "@/components/notifications/NotificationBell";
import { UserMenu } from "@/components/auth/UserMenu";

export function AdminLayout() {
  const { user, loading: authLoading } = useAuth();
  const { isAdmin, isFarmer, loading: adminLoading } = useAdmin();

  if (authLoading || adminLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/" replace />;
  }

  if (!isAdmin && !isFarmer) {
    return <Navigate to="/" replace />;
  }

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AdminSidebar />
        
        <div className="flex-1 flex flex-col">
          <header className="h-12 flex items-center justify-between border-b bg-background">
            <div className="flex items-center">
              <SidebarTrigger className="ml-2" />
              <div className="px-4">
                <h1 className="text-lg font-semibold">Admin Panel</h1>
              </div>
            </div>
            <div className="flex items-center gap-2 mr-4">
              <NotificationBell />
              <UserMenu />
            </div>
          </header>
          
          <main className="flex-1 p-6 bg-muted/20">
            <Outlet />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}