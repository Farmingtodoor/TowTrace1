import { 
  BarChart3, 
  Package, 
  ShoppingCart, 
  Users, 
  Settings, 
  Mail,
  Shield,
  Home,
  Store,
  UserCheck,
  DollarSign,
  BellRing

} from "lucide-react";
import { NavLink, useLocation } from "react-router-dom";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarTrigger,
  useSidebar,
} from "@/components/ui/sidebar";
import { useAdmin } from "@/contexts/AdminContext";

export function AdminSidebar() {
  const { state } = useSidebar();
  const location = useLocation();
  const currentPath = location.pathname;
  const { isSuperAdmin, isAdmin, isFarmer } = useAdmin();
  const collapsed = state === "collapsed";

  const isActive = (path: string) => currentPath === path;
  const getNavCls = ({ isActive }: { isActive: boolean }) =>
    isActive ? "bg-muted text-primary font-medium" : "hover:bg-muted/50";

  // Define menu items based on user role
  const menuItems = [
    {
      title: "Dashboard",
      url: "/admin",
      icon: BarChart3,
      roles: ['admin', 'super_admin', 'farmer']
    },
    {
      title: "Orders",
      url: "/admin/orders",
      icon: ShoppingCart,
      roles: ['admin', 'super_admin']
    },
    {
      title: "Customer Orders",
      url: "/farmer/orders",
      icon: ShoppingCart,
      roles: ['farmer']
    },
    {
      title: "Custom Requests",
      url: "/farmer/custom-orders",
      icon: UserCheck,
      roles: ['farmer']
    },
    {
      title: "Products",
      url: isFarmer ? "/farmer-products" : "/admin/products",
      icon: Package,
      roles: ['admin', 'super_admin', 'farmer']
    },
    {
      title: "Payouts",
      url: isFarmer ? "/farmer-payouts" : "/admin/payouts",
      icon: DollarSign,
      roles: ['admin', 'super_admin', 'farmer']
    },
    {
      title: "Users",
      url: "/admin/users",
      icon: Users,
      roles: ['admin', 'super_admin']
    },
    {
      title: "Farmers",
      url: "/admin/farmers",
      icon: Store,
      roles: ['admin', 'super_admin']
    },
    {
      title: "Fix Farmer Roles",
      url: "/admin/fix-roles",
      icon: UserCheck,
      roles: ['super_admin']
    },
    {
      title: "Notifications",
      url: "/admin/notifications",
      icon: Mail,
      roles: ['admin', 'super_admin']
    },
    {
      title: "Roles",
      url: "/admin/roles",
      icon: Shield,
      roles: ['super_admin']
    },
    {
      title: "Delivery Waitlist",
      url: "/admin/waitlist",
      icon: BellRing,
      roles: ['admin', 'super_admin', 'farmer']
    },
    {
      title: "Settings",

      url: "/admin/settings",
      icon: Settings,
      roles: ['admin', 'super_admin']
    }
  ];

  // Filter menu items based on user role
  const filteredItems = menuItems.filter(item => {
    if (isSuperAdmin) return item.roles.includes('super_admin');
    if (isAdmin) return item.roles.includes('admin');
    if (isFarmer) return item.roles.includes('farmer');
    return false;
  });

  const generalItems = [
    {
      title: "Back to Site",
      url: "/",
      icon: Home,
    }
  ];

  return (
    <Sidebar
      className={collapsed ? "w-14" : "w-60"}
      collapsible="icon"
    >
      <SidebarTrigger className="m-2 self-end" />

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Admin Panel</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {filteredItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink to={item.url} end className={getNavCls}>
                      <item.icon className="mr-2 h-4 w-4" />
                      {!collapsed && <span>{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>General</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {generalItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink to={item.url} className={getNavCls}>
                      <item.icon className="mr-2 h-4 w-4" />
                      {!collapsed && <span>{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}