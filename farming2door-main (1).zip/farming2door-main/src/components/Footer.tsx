import { Leaf, Mail, Phone, MapPin, Facebook, Instagram, Twitter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useState, useEffect } from "react";

interface Category {
  id: string;
  name: string;
}

const Footer = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [honeypot, setHoneypot] = useState(""); // Bot detection
  const [dialogOpen, setDialogOpen] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('categories')
        .select('id, name')
        .eq('is_active', true)
        .order('display_order');

      if (error) throw error;
      setCategories(data || []);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const handleDownloadApp = () => {
    toast({
      title: "App Coming Soon!",
      description: "Our mobile app is in development. Sign up for early access notifications!",
    });
  };

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
    return emailRegex.test(email) && 
           email.length <= 254 && 
           email.length >= 5 &&
           !email.includes('..') &&
           !email.startsWith('.') &&
           !email.endsWith('.');
  };

  const handleNotifyMe = async () => {
    // Bot detection - if honeypot is filled, it's likely a bot
    if (honeypot) {
      console.warn("Bot detected via honeypot");
      return;
    }
    
    if (!email.trim()) {
      toast({
        title: "Email Required",
        description: "Please enter your email address.",
        variant: "destructive",
      });
      return;
    }

    // Enhanced client-side validation
    if (!validateEmail(email)) {
      toast({
        title: "Invalid Email",
        description: "Please enter a valid email address.",
        variant: "destructive",
      });
      return;
    }

    // Check for suspicious patterns
    const suspiciousPatterns = /[0-9]{4,}|test|fake|spam|temp/i;
    if (suspiciousPatterns.test(email)) {
      toast({
        title: "Invalid Email",
        description: "Please use a valid personal or business email address.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      const { error } = await supabase
        .from('app_notifications')
        .insert([{ email: email.trim().toLowerCase() }]);

      if (error) {
        console.error("Subscription error:", error);
        
        // Handle different error types based on security constraints
        if (error.code === '23505') { // Unique constraint violation
          toast({
            title: "Already Subscribed",
            description: "You're already signed up for notifications!",
          });
        } else if (error.message?.includes('rate limit') || error.message?.includes('check_email_subscription_rate_limit')) {
          toast({
            title: "Too Many Attempts",
            description: "Please wait a few minutes before trying again.",
            variant: "destructive",
          });
        } else if (error.message?.includes('is_valid_email') || error.message?.includes('email format')) {
          toast({
            title: "Invalid Email Format",
            description: "Please enter a valid email address.",
            variant: "destructive",
          });
        } else if (error.message?.includes('suspicious') || error.message?.includes('is_suspicious_email')) {
          toast({
            title: "Email Not Accepted",
            description: "Please use a different email address.",
            variant: "destructive",
          });
        } else {
          throw error;
        }
      } else {
        toast({
          title: "Success!",
          description: "We'll notify you when the app launches. Thanks for your interest!",
        });
        setEmail("");
        setDialogOpen(false);
      }
    } catch (error) {
      console.error('Error saving notification email:', error);
      toast({
        title: "Error",
        description: "Something went wrong. Please try again later.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleLinkClick = (path: string, external?: boolean) => {
    if (external) {
      window.open(path, '_blank');
    } else {
      navigate(path);
    }
  };

  const shopCategories = categories.map(category => ({
    label: category.name,
    path: `/shop?category=${category.name.toLowerCase().replace(/\s+/g, '-').replace('&', 'and')}`
  }));

  const supportLinks = [
    { label: "How it Works", path: "/how-it-works" },
    { label: "About Us", path: "/about" },
    { label: "FAQ", path: "/faq" },
    { label: "Blog", path: "/blog" },
    { label: "Terms of Service", path: "/terms" },
    { label: "Privacy Policy", path: "/privacy" },
    { label: "Refund Policy", path: "/refund-policy" },
    { label: "Food Safety", path: "/food-safety" },
  ];

  const companyLinks = [
    { label: "Our Team", path: "/team" },
    { label: "Careers", path: "/careers" },
    { label: "Drive for Us", path: "/driver-signup" },
  ];
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-8">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Leaf className="h-8 w-8" />
              <span className="text-2xl font-bold">Farming2Door</span>
            </div>
            <p className="text-primary-foreground/80 leading-relaxed">
              Connecting communities with fresh, local produce and premium livestock 
              directly from trusted farmers.
            </p>
            <div className="flex gap-3">
              <Button
                variant="ghost"
                size="sm"
                className="h-10 w-10 p-0 rounded-full bg-primary-foreground/10 hover:bg-primary-foreground/20"
                onClick={() => window.open('https://facebook.com/farming2door', '_blank')}
              >
                <Facebook className="h-5 w-5" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="h-10 w-10 p-0 rounded-full bg-primary-foreground/10 hover:bg-primary-foreground/20"
                onClick={() => window.open('https://instagram.com/farming2door', '_blank')}
              >
                <Instagram className="h-5 w-5" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="h-10 w-10 p-0 rounded-full bg-primary-foreground/10 hover:bg-primary-foreground/20"
                onClick={() => window.open('https://twitter.com/farming2door', '_blank')}
              >
                <Twitter className="h-5 w-5" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="h-10 w-10 p-0 rounded-full bg-primary-foreground/10 hover:bg-primary-foreground/20"
                onClick={() => window.open('https://tiktok.com/@farming2door', '_blank')}
              >
                <svg className="h-5 w-5 fill-current" viewBox="0 0 24 24">
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
                </svg>
              </Button>
            </div>
            <div className="flex gap-2">
              <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="secondary" size="sm" onClick={handleDownloadApp}>
                    Download App
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Farming2Door Mobile App</DialogTitle>
                    <DialogDescription>
                      Our mobile app is currently in development. Get notified when it's available!
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <p className="text-sm text-muted-foreground">
                      Features coming soon:
                    </p>
                    <ul className="text-sm space-y-1 text-muted-foreground ml-4">
                      <li>• Real-time order tracking</li>
                      <li>• Push notifications for fresh arrivals</li>
                      <li>• Offline browsing capability</li>
                      <li>• Farmer chat integration</li>
                    </ul>
                    <div className="space-y-3">
                      <div className="space-y-2">
                        <Label htmlFor="email">Email Address</Label>
                        {/* Honeypot field - hidden from users but visible to bots */}
                        <input
                          type="text"
                          name="website"
                          value={honeypot}
                          onChange={(e) => setHoneypot(e.target.value)}
                          style={{ 
                            position: 'absolute', 
                            left: '-9999px', 
                            opacity: 0, 
                            pointerEvents: 'none' 
                          }}
                          tabIndex={-1}
                          autoComplete="off"
                        />
                        <Input
                          id="email"
                          type="email"
                          placeholder="your@email.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              handleNotifyMe();
                            }
                          }}
                          maxLength={254}
                          required
                        />
                      </div>
                      <Button 
                        className="w-full" 
                        onClick={handleNotifyMe}
                        disabled={isLoading || !email}
                      >
                        {isLoading ? "Subscribing..." : "Notify Me When Available"}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Shop</h3>
            <ul className="space-y-2 text-primary-foreground/80">
              {shopCategories.map((item) => (
                <li key={item.path}>
                  <button 
                    onClick={() => handleLinkClick(item.path)}
                    className="hover:text-primary-foreground transition-colors text-left"
                  >
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Company</h3>
            <ul className="space-y-2 text-primary-foreground/80">
              {companyLinks.map((item) => (
                <li key={`company-${item.label}`}>
                  <button 
                    onClick={() => handleLinkClick(item.path)}
                    className="hover:text-primary-foreground transition-colors text-left"
                  >
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Support</h3>
            <ul className="space-y-2 text-primary-foreground/80">
              {supportLinks.map((item) => (
                <li key={`support-${item.label}`}>
                  <button 
                    onClick={() => handleLinkClick(item.path)}
                    className="hover:text-primary-foreground transition-colors text-left"
                  >
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Contact</h3>
            <div className="space-y-3 text-primary-foreground/80">
              <button 
                onClick={() => window.open('tel:1-800-327-6669', '_self')}
                className="flex items-center gap-2 hover:text-primary-foreground transition-colors"
              >
                <Phone className="h-4 w-4" />
                <span>1-800-FARM-NOW</span>
              </button>
              <button 
                onClick={() => window.open('mailto:hello@farm2door.com', '_self')}
                className="flex items-center gap-2 hover:text-primary-foreground transition-colors"
              >
                <Mail className="h-4 w-4" />
                <span>hello@farm2door.com</span>
              </button>
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4" />
                <span>San Francisco, CA</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 mt-12 pt-8 text-center text-primary-foreground/60">
          <p>&copy; 2024 Farming2Door. All rights reserved. Made with 💚 for farmers and communities.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;