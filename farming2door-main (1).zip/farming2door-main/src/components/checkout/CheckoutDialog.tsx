import { useState, useEffect, useRef } from "react";
import { DeliveryEligibilityBadge } from "@/components/checkout/DeliveryEligibilityBadge";
import { CheckoutCoverageMap } from "@/components/checkout/CheckoutCoverageMap";
import type { EligibilityResult } from "@/services/zipCoverageService";
import { useCart } from "@/contexts/CartContext";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { MapPin, Clock, Package, CreditCard, Shield, Smartphone, CheckCircle, AlertCircle, Loader2, Info } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { PromotionCodeInput } from "@/components/promotions/PromotionCodeInput";
import { PickupSlotSelector, SelectedPickupSlot } from "@/components/checkout/PickupSlotSelector";
import { DeliveryWaitlistForm } from "@/components/checkout/DeliveryWaitlistForm";


interface AddOn {
  id: string;
  name: string;
  price: number;
  description: string;
  enabled: boolean;
}

interface FeeBreakdown {
  baseFee: number;
  distanceFee: number;
  serviceFee: number;
  smallOrderFee: number;
  peakFee: number;
  totalFee: number;
  estimatedDeliveryTime: string;
}

interface DeliveryOption {
  type: 'pickup' | 'delivery';
  address?: string;
  distance?: number;
  deliveryFee: number;
  timeWindow?: 'AM' | 'PM';
  breakdown?: FeeBreakdown;
  durationMinutes?: number;
  outOfRange?: boolean;
}

interface FarmDeliverySettings {
  offersDelivery: boolean;
  offersPickup: boolean;
  radiusMiles: number;
  minimumOrder: number;
  notes: string | null;
}

const MAX_DELIVERY_MILES = 50;

export const CheckoutDialog = () => {
  const { items, getTotalPrice, clearCart } = useCart();
  const { user } = useAuth();
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Form state
  const [customerEmail, setCustomerEmail] = useState("");
  const [deliveryOption, setDeliveryOption] = useState<DeliveryOption>({
    type: 'pickup',
    deliveryFee: 0,
  });
  const [deliveryAddress, setDeliveryAddress] = useState("");
  const [timeWindow, setTimeWindow] = useState<'AM' | 'PM'>('AM');
  const [calculatingFee, setCalculatingFee] = useState(false);
  const [eligibility, setEligibility] = useState<EligibilityResult | null>(null);
  const [coveragePoints, setCoveragePoints] = useState<{
    origin: { lat: number; lng: number };
    customer: { lat: number; lng: number };
  } | null>(null);
  const addressDebounce = useRef<ReturnType<typeof setTimeout> | null>(null);


  // Pickup scheduling state
  const [cartFarmerId, setCartFarmerId] = useState<string | null>(null);
  const [pickupSlot, setPickupSlot] = useState<SelectedPickupSlot | null>(null);
  const [pickupSlotCount, setPickupSlotCount] = useState(0);

  // Farm fulfillment capabilities
  const [farmDelivery, setFarmDelivery] = useState<FarmDeliverySettings>({
    offersDelivery: true,
    offersPickup: true,
    radiusMiles: MAX_DELIVERY_MILES,
    minimumOrder: 0,
    notes: null,
  });

  // Add-ons state - fetch from database
  const [addOns, setAddOns] = useState<AddOn[]>([]);
  
  // Promotion state
  const [currentDiscount, setCurrentDiscount] = useState<{ amount: number; code: string; promotionId: string } | null>(null);

  // Load add-ons from database and set user email if logged in
  useEffect(() => {
    const loadAddOns = async () => {
      const { data: addOnsData, error } = await supabase
        .from('add_ons')
        .select('*');
      
      if (addOnsData && !error) {
        setAddOns(addOnsData.map(addon => ({
          id: addon.id,
          name: addon.name,
          price: parseFloat(addon.price.toString()),
          description: addon.description || '',
          enabled: false
        })));
      }
    };

    loadAddOns();
    
    // Auto-populate email if user is logged in
    if (user?.email) {
      setCustomerEmail(user.email);
    }
  }, [user]);

  // Resolve the farm the cart belongs to so we can offer its pickup windows
  useEffect(() => {
    const loadFarmer = async () => {
      if (items.length === 0) {
        setCartFarmerId(null);
        return;
      }
      const { data, error } = await supabase
        .from('products')
        .select('farmer_id')
        .eq('id', items[0].id)
        .maybeSingle();

      if (error || !data?.farmer_id) {
        setCartFarmerId(null);
        return;
      }
      setCartFarmerId(data.farmer_id);
    };

    loadFarmer();
  }, [items]);

  // Load the farm's fulfillment settings so we only show options they can fulfill
  useEffect(() => {
    const loadDeliverySettings = async () => {
      if (!cartFarmerId) {
        setFarmDelivery({
          offersDelivery: true,
          offersPickup: true,
          radiusMiles: MAX_DELIVERY_MILES,
          minimumOrder: 0,
          notes: null,
        });
        return;
      }

      const { data } = await supabase
        .from('farmer_delivery_settings')
        .select('offers_delivery, offers_pickup, delivery_radius_miles, delivery_minimum_order, delivery_notes')
        .eq('farmer_id', cartFarmerId)
        .maybeSingle();

      if (!data) {
        // No settings saved yet — fall back to pickup only (farmer hasn't opted into delivery)
        setFarmDelivery({
          offersDelivery: false,
          offersPickup: true,
          radiusMiles: MAX_DELIVERY_MILES,
          minimumOrder: 0,
          notes: null,
        });
        return;
      }

      setFarmDelivery({
        offersDelivery: data.offers_delivery,
        offersPickup: data.offers_pickup,
        radiusMiles: Math.min(Number(data.delivery_radius_miles) || MAX_DELIVERY_MILES, MAX_DELIVERY_MILES),
        minimumOrder: Number(data.delivery_minimum_order) || 0,
        notes: data.delivery_notes,
      });
    };

    loadDeliverySettings();
  }, [cartFarmerId]);

  // Keep the selected method valid for what this farm supports
  useEffect(() => {
    if (!farmDelivery.offersDelivery && deliveryOption.type === 'delivery') {
      setDeliveryOption({ type: 'pickup', deliveryFee: 0 });
    } else if (!farmDelivery.offersPickup && farmDelivery.offersDelivery && deliveryOption.type === 'pickup') {
      setDeliveryOption(prev => ({ ...prev, type: 'delivery' }));
    }
  }, [farmDelivery, deliveryOption.type]);



  const effectiveMaxMiles = Math.min(farmDelivery.radiusMiles, MAX_DELIVERY_MILES);
  const subtotal = getTotalPrice();
  const platformFee = subtotal * 0.05;
  const addOnsTotal = addOns.filter(addon => addon.enabled).reduce((sum, addon) => sum + addon.price, 0);
  const discountAmount = currentDiscount?.amount || 0;
  const total = subtotal + platformFee + addOnsTotal + deliveryOption.deliveryFee - discountAmount;

  const handleAddOnToggle = (id: string, enabled: boolean) => {
    setAddOns(prev => prev.map(addon => 
      addon.id === id ? { ...addon, enabled } : addon
    ));
  };

  const handleDiscountApplied = (discount: { amount: number; code: string; promotionId: string }) => {
    setCurrentDiscount(discount);
    toast({
      title: "Discount Applied!",
      description: `You saved $${discount.amount.toFixed(2)} with code ${discount.code}`,
    });
  };

  const handleDiscountRemoved = () => {
    setCurrentDiscount(null);
  };

  const calculateDeliveryFeeForAddress = async (address: string) => {
    const { extractZip } = await import('@/services/zipCoverageService');
    const zip = extractZip(address);

    if (!zip) {
      setEligibility(null);
      setCoveragePoints(null);
      setDeliveryOption(prev => ({ ...prev, address, distance: undefined, breakdown: undefined, deliveryFee: 0, outOfRange: false }));
      return;
    }

    setCalculatingFee(true);
    try {
      const { geocodeZipCode } = await import('@/services/geocodingService');
      const { calculateDeliveryFee: calcFee } = await import('@/services/deliveryFeeService');
      const { getDrivingRoute } = await import('@/services/mapboxRoutingService');
      const {
        resolveZipWithNearby, estimateDistanceRange, evaluateEligibility,
      } = await import('@/services/zipCoverageService');

      // Get farmer's ZIP from the first cart item's farmer
      const farmerName = items[0]?.farmer;
      let farmerCoords: { lat: number; lng: number } | null = null;

      if (farmerName) {
        const { data: farmerProfile } = await supabase
          .from('profiles').select('zip_code').eq('full_name', farmerName).single();
        if (farmerProfile?.zip_code) {
          const farmerGeo = await geocodeZipCode(farmerProfile.zip_code);
          if (farmerGeo.success) farmerCoords = { lat: farmerGeo.latitude, lng: farmerGeo.longitude };
        }
      }

      // Resolve the customer ZIP, falling back to nearby ZIPs when unknown
      const resolved = await resolveZipWithNearby(zip);

      if (!resolved.success || !farmerCoords) {
        setEligibility(evaluateEligibility(null, resolved, effectiveMaxMiles));
        setCoveragePoints(null);
        setDeliveryOption(prev => ({ ...prev, address, distance: undefined, breakdown: undefined, deliveryFee: 0, outOfRange: false }));
        return;
      }

      setCoveragePoints({
        origin: farmerCoords,
        customer: { lat: resolved.location.latitude, lng: resolved.location.longitude },
      });


      // Prefer a real driving distance when Mapbox can route it
      let knownRoadMiles: number | undefined;
      let durationMinutes = 30;
      const route = await getDrivingRoute(farmerCoords, {
        lat: resolved.location.latitude, lng: resolved.location.longitude,
      });
      if (route.success) {
        knownRoadMiles = route.distanceMiles;
        durationMinutes = route.durationMinutes;
      }

      const range = await estimateDistanceRange(farmerCoords, resolved, knownRoadMiles);
      const result = evaluateEligibility(range, resolved, effectiveMaxMiles);
      setEligibility(result);

      const distance = range ? range.centerMiles : 15;

      if (result.status === 'outside') {
        setDeliveryOption(prev => ({
          ...prev, address, distance, deliveryFee: 0, timeWindow,
          outOfRange: true, durationMinutes, breakdown: undefined,
        }));
        return;
      }

      const breakdown = calcFee({ distanceMiles: distance, orderSubtotal: subtotal });

      setDeliveryOption(prev => ({
        ...prev, address, distance,
        deliveryFee: Math.round(breakdown.totalFee * 100) / 100,
        timeWindow,
        breakdown, durationMinutes, outOfRange: false,
      }));
    } catch (error) {
      console.error('Error calculating delivery fee:', error);
      const { calculateDeliveryFee: calcFee } = await import('@/services/deliveryFeeService');
      const fallback = calcFee({ distanceMiles: 15, orderSubtotal: subtotal });
      setEligibility(null);
      setCoveragePoints(null);
      setDeliveryOption(prev => ({
        ...prev, address, distance: 15, deliveryFee: fallback.totalFee,
        timeWindow,
        breakdown: fallback, durationMinutes: 30, outOfRange: false,
      }));
    } finally {
      setCalculatingFee(false);
    }
  };

  const handleDeliveryTypeChange = async (type: 'pickup' | 'delivery') => {
    if (type === 'pickup') {
      setDeliveryOption({ type: 'pickup', deliveryFee: 0 });
    } else {
      setDeliveryOption(prev => ({ ...prev, type: 'delivery' }));
      if (deliveryAddress) {
        await calculateDeliveryFeeForAddress(deliveryAddress);
      }
    }
  };

  const handleAddressChange = (address: string) => {
    setDeliveryAddress(address);
    if (addressDebounce.current) clearTimeout(addressDebounce.current);
    if (deliveryOption.type !== 'delivery' || !address.trim()) return;
    addressDebounce.current = setTimeout(() => {
      calculateDeliveryFeeForAddress(address);
    }, 500);
  };

  const handleCheckout = async () => {
    // For logged-in users, use their email; for guests, require email input
    const email = user?.email || customerEmail;
    console.log('Starting checkout process with email:', email);
    
    if (!email || !email.includes('@')) {
      toast({
        title: "Email Required",
        description: "Please enter a valid email address to proceed.",
        variant: "destructive",
      });
      return;
    }

    if (deliveryOption.type === 'pickup' && pickupSlotCount > 0 && !pickupSlot) {
      toast({
        title: "Pickup Time Required",
        description: "Please choose an available pickup time window.",
        variant: "destructive",
      });
      return;
    }

    if (deliveryOption.type === 'delivery' && !deliveryAddress.trim()) {
      toast({
        title: "Delivery Address Required",
        description: "Please enter your delivery address.",
        variant: "destructive",
      });
      return;
    }

    if (deliveryOption.type === 'delivery' && deliveryOption.outOfRange) {
      toast({
        title: "Outside delivery area",
        description: `Sorry, this address is ${deliveryOption.distance} miles away. This farm delivers within ${effectiveMaxMiles} miles. Please choose pickup instead.`,
        variant: "destructive",
      });
      return;
    }

    if (deliveryOption.type === 'delivery' && subtotal < farmDelivery.minimumOrder) {
      toast({
        title: "Delivery minimum not met",
        description: `This farm requires a $${farmDelivery.minimumOrder.toFixed(2)} subtotal for delivery. Add more items or choose pickup.`,
        variant: "destructive",
      });
      return;
    }


    setIsProcessing(true);
    console.log('Cart items to process:', items);
    
    try {
      // Transform cart items to match the secure API format (only IDs and quantities)
      const secureItems = items.map(item => ({
        id: item.id.toString(), // Ensure ID is string for UUID matching
        quantity: item.quantity
      }));

      console.log('Secure items:', secureItems);
      console.log('Add-ons:', addOns);
      console.log('Delivery option:', deliveryOption);

      const payload = {
        items: secureItems,
        addOns,
        delivery: deliveryOption,
        customerEmail: email,
        promotion: currentDiscount,
        pickupSlot: deliveryOption.type === 'pickup' ? pickupSlot : null,
      };
      
      console.log('Invoking create-checkout function with payload:', payload);

      const { data, error } = await supabase.functions.invoke('create-checkout', {
        body: payload,
      });

      console.log('Function response data:', data);
      console.log('Function response error:', error);

      if (error) {
        console.error('Supabase function error:', error);
        throw error;
      }

      if (!data) {
        console.error('No data returned from function');
        throw new Error('No response data from checkout function');
      }

      if (data?.url) {
        console.log('Redirecting to checkout URL:', data.url);
        // Redirect to Stripe checkout on same page
        window.location.href = data.url;
      } else {
        console.error('No checkout URL returned:', data);
        throw new Error('No checkout URL returned from payment service');
      }
    } catch (error) {
      console.error('Checkout error:', error);
      toast({
        title: "Checkout Error",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  if (items.length === 0) return null;

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button className="w-full" size="lg">
          <CreditCard className="w-4 h-4 mr-2" />
          Proceed to Checkout
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="w-5 h-5" />
            Checkout
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Customer Email - only show for non-logged-in users */}
          {!user && (
            <div className="space-y-2">
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                placeholder="your@email.com"
                value={customerEmail}
                onChange={(e) => setCustomerEmail(e.target.value)}
                required
              />
            </div>
          )}
          
          {/* Show current user email for logged-in users */}
          {user && (
            <div className="space-y-2">
              <Label>Order Email</Label>
              <div className="text-sm text-muted-foreground bg-muted p-2 rounded">
                {user.email}
              </div>
            </div>
          )}

          {/* Delivery Options */}
          <div className="space-y-4">
            <Label className="text-base font-semibold">Fulfillment Options</Label>
            <RadioGroup
              value={deliveryOption.type}
              onValueChange={(value) => handleDeliveryTypeChange(value as 'pickup' | 'delivery')}
            >
              {farmDelivery.offersPickup && (
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="pickup" id="pickup" />
                  <Label htmlFor="pickup" className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    Free Pickup at Farm (Free)
                  </Label>
                </div>
              )}
              {farmDelivery.offersDelivery && (
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="delivery" id="delivery" />
                  <Label htmlFor="delivery" className="flex items-center gap-2">
                    <Package className="w-4 h-4" />
                    Home Delivery (within {effectiveMaxMiles} mi)
                  </Label>
                </div>
              )}
            </RadioGroup>

            {!farmDelivery.offersDelivery && (
              <div className="flex items-start gap-2 text-xs text-muted-foreground p-3 bg-muted/40 rounded-lg">
                <Info className="h-4 w-4 mt-0.5 shrink-0" />
                <span>This farm doesn't offer delivery right now — orders are picked up at the farm.</span>
              </div>
            )}

            {farmDelivery.offersDelivery && farmDelivery.notes && (
              <div className="flex items-start gap-2 text-xs text-muted-foreground p-3 bg-muted/40 rounded-lg">
                <Info className="h-4 w-4 mt-0.5 shrink-0" />
                <span>{farmDelivery.notes}</span>
              </div>
            )}

            {deliveryOption.type === 'pickup' && (
              <PickupSlotSelector
                farmerId={cartFarmerId}
                selected={pickupSlot}
                onSelect={setPickupSlot}
                onAvailabilityChange={setPickupSlotCount}
              />
            )}


            {deliveryOption.type === 'delivery' && (
              <div className="space-y-4 pl-6 border-l-2 border-muted">
                <div className="space-y-2">
                  <Label htmlFor="address">Delivery Address</Label>
                  <Input
                    id="address"
                    placeholder="123 Main St, City, State, ZIP"
                    value={deliveryAddress}
                    onChange={(e) => handleAddressChange(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    We check delivery eligibility from the ZIP code in your address.
                  </p>
                </div>

                <DeliveryEligibilityBadge
                  loading={calculatingFee}
                  result={eligibility}
                  offersPickup={farmDelivery.offersPickup}
                  onSwitchToPickup={
                    farmDelivery.offersPickup ? () => handleDeliveryTypeChange('pickup') : undefined
                  }
                />


                {!calculatingFee && coveragePoints && eligibility && eligibility.status !== 'unknown' && (
                  <CheckoutCoverageMap
                    origin={coveragePoints.origin}
                    customer={coveragePoints.customer}
                    radiusMiles={effectiveMaxMiles}
                    status={eligibility.status}
                  />
                )}

                

                
                <div className="space-y-2">
                  <Label>Delivery Time Window</Label>
                  <RadioGroup value={timeWindow} onValueChange={(value) => setTimeWindow(value as 'AM' | 'PM')}>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="AM" id="am" />
                      <Label htmlFor="am" className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        Morning (8AM - 12PM)
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="PM" id="pm" />
                      <Label htmlFor="pm" className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        Afternoon (1PM - 6PM)
                      </Label>
                    </div>
                  </RadioGroup>
                </div>

                {!calculatingFee && deliveryOption.outOfRange && (
                  <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-3 space-y-2">
                    <p className="text-sm font-semibold text-destructive">
                      Delivery unavailable for this ZIP
                    </p>
                    {farmDelivery.offersPickup ? (
                      <>
                        <p className="text-xs text-muted-foreground">
                          You can still order — pick your items up at the farm and choose a time window.
                        </p>
                        <Button
                          type="button"
                          size="sm"
                          variant="secondary"
                          onClick={() => handleDeliveryTypeChange('pickup')}
                        >
                          <MapPin className="h-4 w-4 mr-1.5" />
                          Switch to free farm pickup
                        </Button>
                      </>
                    ) : (
                      <>
                        <p className="text-xs text-muted-foreground">
                          This farm doesn't offer pickup either. Join the waitlist and we'll let you know
                          the moment they deliver to your area.
                        </p>
                        <DeliveryWaitlistForm
                          farmerId={cartFarmerId}
                          zip={eligibility?.resolved?.zip ?? null}
                          distanceMiles={deliveryOption.distance}
                          defaultEmail={user?.email ?? customerEmail}
                          userId={user?.id ?? null}
                        />
                      </>
                    )}

                  </div>
                )}


                {!calculatingFee && subtotal < farmDelivery.minimumOrder && (
                  <div className="flex items-start gap-2 text-sm p-3 bg-destructive/10 border border-destructive/30 rounded-lg text-destructive">
                    <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                    <div>
                      <p className="font-semibold">Delivery minimum not met</p>
                      <p className="text-xs mt-0.5 text-destructive/80">
                        This farm requires a ${farmDelivery.minimumOrder.toFixed(2)} subtotal for delivery.
                      </p>
                    </div>
                  </div>
                )}

                {!calculatingFee && !deliveryOption.outOfRange && deliveryOption.distance != null && deliveryOption.breakdown && (
                  <div className="rounded-xl border bg-muted/30 overflow-hidden">
                    <div className="flex items-center justify-between px-4 py-3 bg-muted/50">
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-primary" />
                        <span className="text-sm font-semibold">
                          {deliveryOption.breakdown.estimatedDeliveryTime}
                        </span>
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {eligibility?.range
                          ? `${eligibility.range.minMiles}–${eligibility.range.maxMiles} mi`
                          : `~${deliveryOption.distance} mi`} • Farm Direct
                      </span>
                    </div>
                    <div className="p-4 space-y-1.5 text-sm">
                      <div className="flex justify-between text-muted-foreground">
                        <span>Base fee</span>
                        <span>${deliveryOption.breakdown.baseFee.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-muted-foreground">
                        <span>Distance fee ({deliveryOption.distance} mi)</span>
                        <span>${deliveryOption.breakdown.distanceFee.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-muted-foreground">
                        <span>Service fee</span>
                        <span>${deliveryOption.breakdown.serviceFee.toFixed(2)}</span>
                      </div>
                      {deliveryOption.breakdown.smallOrderFee > 0 && (
                        <div className="flex justify-between text-amber-700">
                          <span className="flex items-center gap-1">Small order fee <Info className="h-3 w-3" /></span>
                          <span>${deliveryOption.breakdown.smallOrderFee.toFixed(2)}</span>
                        </div>
                      )}
                      {deliveryOption.breakdown.peakFee > 0 && (
                        <div className="flex justify-between text-amber-700">
                          <span>Peak hours surcharge</span>
                          <span>${deliveryOption.breakdown.peakFee.toFixed(2)}</span>
                        </div>
                      )}
                      <Separator className="my-2" />
                      <div className="flex justify-between font-semibold">
                        <span>Delivery total</span>
                        <span>${deliveryOption.deliveryFee.toFixed(2)}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Processing Add-ons */}
          <div className="space-y-4">
            <Label className="text-base font-semibold">Processing Add-ons</Label>
            <div className="space-y-3">
              {addOns.map((addon) => (
                <div key={addon.id} className="flex items-start space-x-3 p-3 rounded-lg border">
                  <Checkbox
                    id={addon.id}
                    checked={addon.enabled}
                    onCheckedChange={(checked) => handleAddOnToggle(addon.id, checked as boolean)}
                  />
                  <div className="flex-1">
                    <Label htmlFor={addon.id} className="font-medium">
                      {addon.name} (+${addon.price})
                    </Label>
                    <p className="text-sm text-muted-foreground">{addon.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          {/* Order Summary */}
          <div className="space-y-2">
            <h4 className="font-semibold">Order Summary</h4>
            <div className="space-y-1 text-sm">
              <div className="flex justify-between">
                <span>Items Subtotal:</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-muted-foreground">
                <span>Platform Fee (5%):</span>
                <span>${platformFee.toFixed(2)}</span>
              </div>
              {addOnsTotal > 0 && (
                <div className="flex justify-between">
                  <span>Processing Add-ons:</span>
                  <span>${addOnsTotal.toFixed(2)}</span>
                </div>
              )}
              {deliveryOption.type === 'pickup' && pickupSlot && (
                <div className="flex justify-between text-muted-foreground">
                  <span>Pickup Time:</span>
                  <span>{pickupSlot.label}</span>
                </div>
              )}
              {deliveryOption.deliveryFee > 0 && (
                <div className="flex justify-between">
                  <span>Delivery Fee:</span>
                  <span>${deliveryOption.deliveryFee.toFixed(2)}</span>
                </div>
              )}
              {discountAmount > 0 && (
                <div className="flex justify-between text-green-600">
                  <span>Discount ({currentDiscount?.code}):</span>
                  <span>-${discountAmount.toFixed(2)}</span>
                </div>
              )}
              <Separator />
              <div className="flex justify-between font-semibold text-base">
                <span>Total (+ tax):</span>
                <span>${total.toFixed(2)}</span>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              * Tax will be calculated automatically at checkout
            </p>
          </div>

          <Button 
            onClick={handleCheckout} 
            className="w-full" 
            size="lg"
            disabled={isProcessing || calculatingFee || (!user && !customerEmail) || (deliveryOption.type === 'delivery' && (deliveryOption.outOfRange || subtotal < farmDelivery.minimumOrder))}
          >
            {isProcessing
              ? "Processing..."
              : deliveryOption.type === 'delivery' && deliveryOption.outOfRange
                ? "Delivery unavailable for this ZIP"
                : `Pay $${total.toFixed(2)} + tax`}
          </Button>




          {/* Trust Badges */}
          <div className="flex flex-wrap items-center justify-center gap-4 pt-4 text-xs text-muted-foreground">
            <div className="flex items-center gap-1">
              <Shield className="w-3 h-3" />
              <span>Secure checkout with Stripe</span>
            </div>
            <div className="flex items-center gap-1">
              <Smartphone className="w-3 h-3" />
              <span>Apple Pay</span>
            </div>
            <div className="flex items-center gap-1">
              <Smartphone className="w-3 h-3" />
              <span>Google Pay</span>
            </div>
            <div className="flex items-center gap-1">
              <CheckCircle className="w-3 h-3" />
              <span>Verified farms</span>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};