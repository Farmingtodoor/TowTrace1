import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@14.21.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface PaymentSuccessRequest {
  sessionId: string;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Processing payment success...');

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("No authorization header provided");
    }

    // Create Supabase client for user authentication
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? ""
    );

    // Get authenticated user
    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userError } = await supabaseClient.auth.getUser(token);
    if (userError || !userData.user) {
      throw new Error("User not authenticated");
    }

    const { sessionId }: PaymentSuccessRequest = await req.json();
    
    if (!sessionId) {
      throw new Error("Session ID is required");
    }

    console.log('Processing session:', sessionId);

    // Initialize Stripe
    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
      apiVersion: "2023-10-16",
    });

    // Retrieve the checkout session from Stripe
    const session = await stripe.checkout.sessions.retrieve(sessionId, {
      expand: ['line_items', 'line_items.data.price.product']
    });

    console.log('Retrieved Stripe session:', session.id, 'Status:', session.payment_status);

    if (session.payment_status !== 'paid') {
      throw new Error("Payment not completed");
    }

    // Create Supabase client with service role for database operations
    const supabaseService = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );

    // Get customer profile
    const { data: customerProfile, error: profileError } = await supabaseService
      .from('profiles')
      .select('id, full_name, email')
      .eq('email', userData.user.email)
      .single();

    if (profileError || !customerProfile) {
      throw new Error("Customer profile not found");
    }

    console.log('Found customer profile:', customerProfile.id);

    // Parse line items to extract product information and farmer data
    const lineItems = session.line_items?.data || [];
    console.log('Processing line items:', lineItems.map((item: any) => ({ 
      name: item.price?.product?.name, 
      description: item.description 
    })));
    
    // Filter out service items (platform fee, delivery, add-ons) and keep only actual products
    // Products have names in format: "Product Name - Farmer Name"
    const productItems = lineItems.filter((item: any) => {
      const productName = item.price?.product?.name || '';
      return productName.includes(' - ') && 
             !productName.includes('Platform Service Fee') &&
             !productName.includes('Delivery') &&
             item.description !== 'Processing add-on' &&
             item.description !== '5% platform commission';
    });

    console.log('Found product items:', productItems.length);
    
    if (productItems.length === 0) {
      console.error('No valid products found. Available items:', lineItems.map((item: any) => ({
        name: item.price?.product?.name,
        description: item.description
      })));
      throw new Error("No valid products found in session");
    }

    // Extract farmer information from the first product (assuming single farmer per order)
    const firstProductName = productItems[0].price?.product?.name || '';
    const farmerInfo = firstProductName.split(' - ')[1]; // Extract farmer info from product name
    
    if (!farmerInfo) {
      console.error('Cannot extract farmer info from product:', firstProductName);
      throw new Error("Farmer information not found in product data");
    }

    console.log('Looking for farmer with info:', farmerInfo);

    // Get farmer profile by email (since product names contain email)
    const { data: farmerProfile, error: farmerError } = await supabaseService
      .from('profiles')
      .select('id, full_name, email')
      .eq('email', farmerInfo)
      .single();

    if (farmerError || !farmerProfile) {
      console.error('Farmer lookup error:', farmerError, 'for email:', farmerInfo);
      throw new Error(`Farmer profile not found for email: ${farmerInfo}`);
    }

    console.log('Found farmer profile:', farmerProfile.id);

    // Calculate total amount (convert from cents)
    const totalAmount = (session.amount_total || 0) / 100;

    // Determine delivery type and address from session metadata
    const deliveryType = session.metadata?.delivery_type || 'pickup';
    const deliveryAddress = session.shipping_details?.address ? 
      `${session.shipping_details.address.line1}, ${session.shipping_details.address.city}, ${session.shipping_details.address.state} ${session.shipping_details.address.postal_code}` : 
      null;

    // Create the order
    const { data: orderData, error: orderError } = await supabaseService
      .from('orders')
      .insert({
        customer_id: customerProfile.id,
        farmer_id: farmerProfile.id,
        total_amount: totalAmount,
        delivery_type: deliveryType,
        delivery_address: deliveryAddress,
        pickup_slot_id: session.metadata?.pickup_slot_id || null,
        pickup_scheduled_at: session.metadata?.pickup_scheduled_at || null,
        pickup_scheduled_end: session.metadata?.pickup_scheduled_end || null,
        status: 'pending',
        customer_notes: `Order from Stripe session: ${sessionId}`
      })
      .select()
      .single();

    if (orderError || !orderData) {
      throw new Error(`Failed to create order: ${orderError?.message}`);
    }

    console.log('Created order:', orderData.id);

    // Create order items
    const orderItemsToInsert = productItems.map((item: any) => {
      const productName = item.price?.product?.name || item.description || 'Unknown Product';
      const cleanProductName = productName.split(' - ')[0]; // Remove farmer name from product name
      
      return {
        order_id: orderData.id,
        product_name: cleanProductName,
        quantity: item.quantity || 1,
        unit_price: (item.price?.unit_amount || 0) / 100,
        total_price: ((item.price?.unit_amount || 0) * (item.quantity || 1)) / 100,
        product_description: item.description
      };
    });

    const { error: itemsError } = await supabaseService
      .from('order_items')
      .insert(orderItemsToInsert);

    if (itemsError) {
      console.error('Error creating order items:', itemsError);
      // Don't fail the entire process, just log the error
    }

    console.log('Created order items for order:', orderData.id);

    console.log('Starting email sending process...');
    
    // Send emails (farmer notification and customer confirmation)
    const emailPromises = [];

    // Farmer notification email
    const farmerEmailPayload = {
      farmerName: farmerProfile.full_name || 'Valued Farmer',
      farmerEmail: farmerProfile.email,
      customerName: customerProfile.full_name || 'A Customer',
      customerEmail: customerProfile.email,
      orderId: orderData.id,
      totalAmount: totalAmount,
      deliveryType: deliveryType,
      deliveryAddress: deliveryAddress || 'Pickup at farm',
      items: orderItemsToInsert.map((item: any) => ({
        name: item.product_name,
        quantity: item.quantity,
        price: item.unit_price
      }))
    };

    emailPromises.push(
      supabaseService.functions.invoke('send-order-notification-email', {
        body: farmerEmailPayload
      }).catch(error => {
        console.error('Error sending farmer notification email:', error);
        return { error };
      })
    );

    // Customer confirmation email
    const customerEmailPayload = {
      customerName: customerProfile.full_name || 'Valued Customer',
      customerEmail: customerProfile.email,
      orderId: orderData.id,
      totalAmount: totalAmount,
      deliveryType: deliveryType,
      deliveryAddress: deliveryAddress || 'Pickup at farm',
      farmerName: farmerProfile.full_name || 'Your Farmer',
      items: orderItemsToInsert.map((item: any) => ({
        name: item.product_name,
        quantity: item.quantity,
        price: item.unit_price
      }))
    };

    emailPromises.push(
      supabaseService.functions.invoke('send-customer-confirmation-email', {
        body: customerEmailPayload
      }).catch(error => {
        console.error('Error sending customer confirmation email:', error);
        return { error };
      })
    );

    // Send both emails concurrently
    try {
      console.log('Invoking email functions...');
      const emailResults = await Promise.all(emailPromises);
      const farmerEmailResult = emailResults[0];
      const customerEmailResult = emailResults[1];

      console.log('Farmer notification email result:', farmerEmailResult.error ? `Failed: ${farmerEmailResult.error.message}` : 'Success');
      console.log('Customer confirmation email result:', customerEmailResult.error ? `Failed: ${customerEmailResult.error.message}` : 'Success');
      
      console.log('Email processing completed');
    } catch (emailError) {
      console.error('Failed to send emails:', emailError);
      // Continue processing even if emails fail
    }

    // Return success response with order details
    return new Response(JSON.stringify({
      success: true,
      orderId: orderData.id,
      totalAmount: totalAmount,
      deliveryType: deliveryType,
      farmerNotified: true,
      customerNotified: true
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });

  } catch (error) {
    console.error('Payment processing error:', error);
    return new Response(JSON.stringify({ 
      error: (error as Error)?.message ?? 'Unknown error',
      success: false 
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});