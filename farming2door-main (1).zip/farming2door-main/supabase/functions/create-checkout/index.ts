import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@14.21.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// ============= ANTI-CARD-TESTING RATE LIMITER =============
interface RateLimitEntry {
  count: number;
  firstRequest: number;
  lastRequest: number;
}

const rateLimitStore = new Map<string, RateLimitEntry>();
const WINDOW_SIZE = 60 * 1000; // 1 minute
const MAX_REQUESTS_PER_WINDOW = 5; // Max 5 attempts per minute
const BLOCK_DURATION = 15 * 60 * 1000; // 15 minute block

function getClientIP(req: Request): string {
  return req.headers.get('cf-connecting-ip') || 
         req.headers.get('x-real-ip') || 
         req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 
         'unknown';
}

function checkRateLimit(ip: string): { allowed: boolean; retryAfter?: number } {
  const now = Date.now();
  const entry = rateLimitStore.get(ip);
  
  if (!entry) {
    rateLimitStore.set(ip, { count: 1, firstRequest: now, lastRequest: now });
    return { allowed: true };
  }
  
  if (now - entry.firstRequest > WINDOW_SIZE) {
    rateLimitStore.set(ip, { count: 1, firstRequest: now, lastRequest: now });
    return { allowed: true };
  }
  
  if (entry.count >= MAX_REQUESTS_PER_WINDOW) {
    const blockEnds = entry.lastRequest + BLOCK_DURATION;
    if (now < blockEnds) {
      return { allowed: false, retryAfter: Math.ceil((blockEnds - now) / 1000) };
    }
    rateLimitStore.set(ip, { count: 1, firstRequest: now, lastRequest: now });
    return { allowed: true };
  }
  
  entry.count++;
  entry.lastRequest = now;
  return { allowed: true };
}

function isDisposableEmail(email: string): boolean {
  const disposableDomains = [
    'tempmail.com', 'throwaway.email', 'guerrillamail.com', 'mailinator.com',
    '10minutemail.com', 'yopmail.com', 'temp-mail.org', 'fakeinbox.com',
    'trashmail.com', 'getnada.com', 'discard.email', 'sharklasers.com'
  ];
  const domain = email.split('@')[1]?.toLowerCase();
  return disposableDomains.some(d => domain?.includes(d));
}

function detectSuspiciousRequest(req: Request): { suspicious: boolean; reason?: string } {
  const userAgent = req.headers.get('user-agent') || '';
  if (!userAgent || userAgent.length < 10) {
    return { suspicious: true, reason: 'Invalid user agent' };
  }
  const botPatterns = ['curl', 'wget', 'python-requests', 'scrapy', 'bot', 'crawler', 'postman'];
  if (botPatterns.some(p => userAgent.toLowerCase().includes(p))) {
    return { suspicious: true, reason: 'Automated request detected' };
  }
  return { suspicious: false };
}
// ============= END RATE LIMITER =============

interface CartItem {
  id: string;
  quantity: number;
}

interface AddOn {
  id: string;
  name: string;
  price: number;
  enabled: boolean;
}

interface DeliveryOption {
  type: 'pickup' | 'delivery';
  address?: string;
  distance?: number;
  deliveryFee: number;
  timeWindow?: 'AM' | 'PM';
}

interface PickupSlotSelection {
  slotId: string;
  date: string;
  startTime: string;
  endTime: string;
  label?: string;
}

interface CheckoutRequest {
  items: CartItem[];
  addOns: AddOn[];
  delivery: DeliveryOption;
  customerEmail: string;
  pickupSlot?: PickupSlotSelection | null;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // ====== ANTI-CARD-TESTING CHECKS ======
    const clientIP = getClientIP(req);
    console.log('[ANTI-FRAUD] Request from IP:', clientIP);
    
    // 1. Rate limiting check
    const rateLimitResult = checkRateLimit(clientIP);
    if (!rateLimitResult.allowed) {
      console.log('[ANTI-FRAUD] Rate limit exceeded for IP:', clientIP);
      return new Response(JSON.stringify({ 
        error: "Too many payment attempts. Please try again later.",
        retryAfter: rateLimitResult.retryAfter 
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json", "Retry-After": String(rateLimitResult.retryAfter) },
        status: 429,
      });
    }
    
    // 2. Suspicious request detection
    const suspiciousCheck = detectSuspiciousRequest(req);
    if (suspiciousCheck.suspicious) {
      console.log('[ANTI-FRAUD] Suspicious request blocked:', suspiciousCheck.reason);
      return new Response(JSON.stringify({ error: "Request blocked for security reasons" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 403,
      });
    }
    // ====== END ANTI-FRAUD CHECKS ======

    console.log('Starting checkout process...');
    const requestBody = await req.json();
    
    const { items, addOns, delivery, customerEmail, pickupSlot }: CheckoutRequest = requestBody;

    // Validate input data
    if (!items || !Array.isArray(items) || items.length === 0) {
      console.error('Invalid items:', items);
      return new Response(JSON.stringify({ error: "Cart items are required" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      });
    }

    // Enhanced email validation
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!customerEmail || !emailRegex.test(customerEmail) || customerEmail.length > 254) {
      console.error('[ANTI-FRAUD] Invalid email format:', customerEmail);
      return new Response(JSON.stringify({ error: "Valid customer email is required" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      });
    }

    // Block disposable emails
    if (isDisposableEmail(customerEmail)) {
      console.log('[ANTI-FRAUD] Disposable email blocked:', customerEmail);
      return new Response(JSON.stringify({ error: "Please use a valid email address" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      });
    }

    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    
    if (!stripeKey) {
      console.error('STRIPE_SECRET_KEY environment variable is not configured');
      return new Response(JSON.stringify({ error: "Payment service configuration error" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500,
      });
    }

    // Create Supabase client for fetching authoritative prices
    console.log('Creating Supabase client...');
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") || "",
      Deno.env.get("SUPABASE_ANON_KEY") || ""
    );

    console.log('Creating Stripe client...');
    const stripe = new Stripe(stripeKey, {
      apiVersion: "2023-10-16",
    });

    // Validate and fetch product prices from database
    console.log('Fetching products for IDs:', items.map(item => item.id));
    const productIds = items.map(item => item.id);
    
    if (productIds.length === 0) {
      console.error('No product IDs found');
      return new Response(JSON.stringify({ error: "No products selected" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      });
    }

    const { data: products, error: productsError } = await supabase
      .from('products')
      .select('id, name, farmer, farmer_id, price, category, is_organic')
      .in('id', productIds);

    console.log('Products fetched:', products);
    console.log('Products error:', productsError);

    if (productsError) {
      console.error('Error fetching products:', productsError);
      return new Response(JSON.stringify({ error: "Database error fetching products" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500,
      });
    }

    if (!products || products.length === 0) {
      console.error('No products found for IDs:', productIds);
      return new Response(JSON.stringify({ error: "Products not found" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      });
    }

    // Calculate subtotal using authoritative prices
    const itemsSubtotal = items.reduce((total, item) => {
      const product = products.find(p => p.id === item.id);
      if (!product) return total;
      return total + (parseFloat(product.price.toString()) * item.quantity * 100); // Convert to cents
    }, 0);

    // Calculate platform fee (5% of item subtotal)
    const platformFee = Math.round(itemsSubtotal * 0.05);

    // Fetch authoritative add-on prices
    const enabledAddOnIds = addOns.filter(addon => addon.enabled).map(addon => addon.id);
    const { data: addOnPrices, error: addOnError } = await supabase
      .from('add_ons')
      .select('id, name, price')
      .in('id', enabledAddOnIds);

    if (addOnError) {
      console.error('Error fetching add-on prices:', addOnError);
      return new Response(JSON.stringify({ error: "Invalid add-on selection" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      });
    }

    // Calculate add-ons total using authoritative prices
    const addOnsTotal = (addOnPrices || []).reduce((total, addon) => {
      return total + (parseFloat(addon.price.toString()) * 100); // Convert to cents
    }, 0);

    // Create line items for Stripe
    const lineItems: Stripe.Checkout.SessionCreateParams.LineItem[] = [];

    // Add cart items using authoritative product data
    items.forEach(item => {
      const product = products.find(p => p.id === item.id);
      if (!product) return;
      
      lineItems.push({
        price_data: {
          currency: "usd",
          product_data: {
            name: `${product.name} - ${product.farmer}`,
            description: `${product.category}${product.is_organic ? ' (Organic)' : ''}`,
          },
          unit_amount: Math.round(parseFloat(product.price.toString()) * 100),
        },
        quantity: item.quantity,
      });
    });

    // Add platform fee as a line item
    if (platformFee > 0) {
      lineItems.push({
        price_data: {
          currency: "usd",
          product_data: {
            name: "Platform Service Fee",
            description: "5% platform commission",
          },
          unit_amount: platformFee,
        },
        quantity: 1,
      });
    }

    // Add enabled add-ons using authoritative prices
    (addOnPrices || []).forEach(addon => {
      lineItems.push({
        price_data: {
          currency: "usd",
          product_data: {
            name: addon.name,
            description: "Processing add-on",
          },
          unit_amount: Math.round(parseFloat(addon.price.toString()) * 100),
        },
        quantity: 1,
      });
    });

    // Enforce the farm's own delivery opt-in, radius and minimum order server-side
    if (delivery.type === 'delivery') {
      const cartFarmerId = products.find(p => p.farmer_id)?.farmer_id ?? null;
      if (cartFarmerId) {
        const { data: farmSettings } = await supabase
          .from('farmer_delivery_settings')
          .select('offers_delivery, delivery_radius_miles, delivery_minimum_order')
          .eq('farmer_id', cartFarmerId)
          .maybeSingle();

        if (!farmSettings?.offers_delivery) {
          return new Response(JSON.stringify({ error: "This farm does not offer delivery. Please choose pickup." }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
            status: 400,
          });
        }

        const radius = Math.min(Number(farmSettings.delivery_radius_miles) || 50, 50);
        if ((delivery.distance || 0) > radius) {
          return new Response(JSON.stringify({ error: `This address is outside the farm's ${radius}-mile delivery radius.` }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
            status: 400,
          });
        }

        const minimumOrderCents = Math.round((Number(farmSettings.delivery_minimum_order) || 0) * 100);
        if (itemsSubtotal < minimumOrderCents) {
          return new Response(JSON.stringify({ error: `This farm requires a $${(minimumOrderCents / 100).toFixed(2)} subtotal for delivery.` }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
            status: 400,
          });
        }
      }
    }

    // Calculate delivery fee server-side (simple distance-based calculation)
    let deliveryFee = 0;
    if (delivery.type === 'delivery') {
      // Simple calculation: $2 base + $0.50 per estimated mile
      const estimatedDistance = delivery.distance || 5; // Default 5 miles if not provided
      deliveryFee = 2.00 + (estimatedDistance * 0.50);
      
      lineItems.push({
        price_data: {
          currency: "usd",
          product_data: {
            name: `Delivery${delivery.timeWindow ? ` (${delivery.timeWindow})` : ''}`,
            description: `~${estimatedDistance} miles delivery`,
          },
          unit_amount: Math.round(deliveryFee * 100),
        },
        quantity: 1,
      });
    }

    // Validate the requested pickup window server-side (existence + capacity)
    let validatedPickup: { slotId: string; scheduledAt: string; scheduledEnd: string } | null = null;
    if (delivery.type === 'pickup' && pickupSlot?.slotId && pickupSlot?.date) {
      const { data: slotRow, error: slotError } = await supabase
        .from('farmer_pickup_slots')
        .select('id, farmer_id, is_active')
        .eq('id', pickupSlot.slotId)
        .maybeSingle();

      if (slotError || !slotRow || !slotRow.is_active) {
        return new Response(JSON.stringify({ error: "Selected pickup time is no longer available" }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 400,
        });
      }

      const { data: available, error: availError } = await supabase.rpc('get_available_pickup_slots', {
        _farmer_id: slotRow.farmer_id,
        _days: 30,
      });

      if (availError) {
        console.error('Error validating pickup slot:', availError.message);
        return new Response(JSON.stringify({ error: "Could not validate pickup time" }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 500,
        });
      }

      const match = (available || []).find(
        (s: any) => s.slot_id === pickupSlot.slotId && s.pickup_date === pickupSlot.date && s.remaining > 0
      );

      if (!match) {
        return new Response(JSON.stringify({ error: "That pickup window is full or no longer offered. Please pick another time." }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 400,
        });
      }

      validatedPickup = {
        slotId: match.slot_id,
        scheduledAt: `${match.pickup_date}T${match.start_time}`,
        scheduledEnd: `${match.pickup_date}T${match.end_time}`,
      };
    }

    // Create Stripe checkout session

    const session = await stripe.checkout.sessions.create({
      // Remove payment_method_types to allow all available methods (Apple Pay, Google Pay, etc.)
      payment_intent_data: {
        setup_future_usage: 'off_session',
      },
      line_items: lineItems,
      mode: "payment",
      success_url: `${req.headers.get("origin")}/checkout-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${req.headers.get("origin")}/checkout-cancelled`,
      customer_email: customerEmail,
      automatic_tax: {
        enabled: true,
      },
      tax_id_collection: {
        enabled: false,
      },
      shipping_address_collection: delivery.type === 'delivery' ? {
        allowed_countries: ['US'],
      } : undefined,
      metadata: {
        delivery_type: delivery.type,
        pickup_slot_id: validatedPickup?.slotId || '',
        pickup_scheduled_at: validatedPickup?.scheduledAt || '',
        pickup_scheduled_end: validatedPickup?.scheduledEnd || '',
        delivery_time_window: delivery.timeWindow || '',
        items_count: items.length.toString(),
        items: JSON.stringify(items),
        addOns: JSON.stringify(addOns || []),
        delivery: JSON.stringify(delivery || {}),
      },
      // Customize branding and hide merchant info
      custom_text: {
        submit: {
          message: "We'll process your order and send you a confirmation email."
        },
        ...(delivery.type === 'delivery' && {
          shipping_address: {
            message: 'Please provide your delivery address for farm fresh products.'
          }
        })
      },
      // This hides the account name/email from the checkout page
      ui_mode: 'hosted',
    });

    return new Response(JSON.stringify({ url: session.url }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });

  } catch (err) {
    console.error('Checkout error:', err);
    const message = (err as Error)?.message ?? 'Unknown error';
    return new Response(JSON.stringify({ error: message }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});