import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface ReceiptEmailRequest {
  email: string;
  receiptNumber: string;
  paymentDate: string;
  vehicleInfo: {
    make?: string;
    model?: string;
    year?: string;
    plateNumber?: string;
    vin?: string;
    color?: string;
  };
  towYard: {
    name: string;
    address: string;
    city: string;
    state: string;
    phone: string;
  };
  fees: {
    towFee: number;
    dailyStorageFee: number;
    daysStored: number;
    storageFee: number;
    adminFee: number;
    gateFee: number;
    subtotal: number;
    serviceFee: number;
    total: number;
  };
}

// HTML escape function to prevent XSS
function escapeHtml(text: string | undefined | null): string {
  if (text === undefined || text === null) return '';
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function formatCurrency(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function generateReceiptEmailHtml(data: ReceiptEmailRequest): string {
  const vehicleDesc = [
    data.vehicleInfo.year,
    data.vehicleInfo.make,
    data.vehicleInfo.model
  ].filter(Boolean).join(' ') || 'Vehicle';

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Payment Receipt - TowTrace</title>
</head>
<body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background-color: #f4f4f5;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f4f4f5; padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
          <!-- Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #14b8a6 0%, #0d9488 100%); padding: 32px; text-align: center;">
              <h1 style="margin: 0; color: #ffffff; font-size: 28px; font-weight: 700;">TowTrace</h1>
              <p style="margin: 8px 0 0 0; color: rgba(255, 255, 255, 0.9); font-size: 14px;">Vehicle Release Receipt</p>
            </td>
          </tr>
          
          <!-- Receipt Info -->
          <tr>
            <td style="padding: 32px;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td width="50%" style="padding-bottom: 24px;">
                    <p style="margin: 0; color: #71717a; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px;">Receipt Number</p>
                    <p style="margin: 4px 0 0 0; color: #18181b; font-size: 16px; font-weight: 600;">${escapeHtml(data.receiptNumber)}</p>
                  </td>
                  <td width="50%" style="padding-bottom: 24px; text-align: right;">
                    <p style="margin: 0; color: #71717a; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px;">Payment Date</p>
                    <p style="margin: 4px 0 0 0; color: #18181b; font-size: 16px; font-weight: 600;">${escapeHtml(data.paymentDate)}</p>
                  </td>
                </tr>
              </table>
              
              <hr style="border: none; border-top: 1px solid #e4e4e7; margin: 0 0 24px 0;">
              
              <!-- Vehicle Info -->
              <h2 style="margin: 0 0 16px 0; color: #14b8a6; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px;">Vehicle Information</h2>
              <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom: 24px;">
                <tr>
                  <td style="padding: 8px 0; color: #71717a; font-size: 14px;">Vehicle</td>
                  <td style="padding: 8px 0; color: #18181b; font-size: 14px; text-align: right; font-weight: 500;">${escapeHtml(vehicleDesc)}</td>
                </tr>
                ${data.vehicleInfo.plateNumber ? `
                <tr>
                  <td style="padding: 8px 0; color: #71717a; font-size: 14px;">License Plate</td>
                  <td style="padding: 8px 0; color: #18181b; font-size: 14px; text-align: right; font-weight: 500;">${escapeHtml(data.vehicleInfo.plateNumber)}</td>
                </tr>
                ` : ''}
                ${data.vehicleInfo.vin ? `
                <tr>
                  <td style="padding: 8px 0; color: #71717a; font-size: 14px;">VIN</td>
                  <td style="padding: 8px 0; color: #18181b; font-size: 14px; text-align: right; font-weight: 500;">${escapeHtml(data.vehicleInfo.vin)}</td>
                </tr>
                ` : ''}
                ${data.vehicleInfo.color ? `
                <tr>
                  <td style="padding: 8px 0; color: #71717a; font-size: 14px;">Color</td>
                  <td style="padding: 8px 0; color: #18181b; font-size: 14px; text-align: right; font-weight: 500;">${escapeHtml(data.vehicleInfo.color)}</td>
                </tr>
                ` : ''}
              </table>
              
              <!-- Tow Yard Info -->
              <h2 style="margin: 0 0 16px 0; color: #14b8a6; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px;">Tow Yard</h2>
              <p style="margin: 0 0 4px 0; color: #18181b; font-size: 14px; font-weight: 600;">${escapeHtml(data.towYard.name)}</p>
              <p style="margin: 0 0 4px 0; color: #71717a; font-size: 14px;">${escapeHtml(data.towYard.address)}</p>
              <p style="margin: 0 0 4px 0; color: #71717a; font-size: 14px;">${escapeHtml(data.towYard.city)}, ${escapeHtml(data.towYard.state)}</p>
              <p style="margin: 0 0 24px 0; color: #71717a; font-size: 14px;">${escapeHtml(data.towYard.phone)}</p>
              
              <hr style="border: none; border-top: 1px solid #e4e4e7; margin: 0 0 24px 0;">
              
              <!-- Fee Breakdown -->
              <h2 style="margin: 0 0 16px 0; color: #14b8a6; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px;">Fee Breakdown</h2>
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td style="padding: 8px 0; color: #71717a; font-size: 14px;">Tow Fee</td>
                  <td style="padding: 8px 0; color: #18181b; font-size: 14px; text-align: right;">${formatCurrency(data.fees.towFee)}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #71717a; font-size: 14px;">Storage Fee (${data.fees.daysStored} day${data.fees.daysStored !== 1 ? 's' : ''} × ${formatCurrency(data.fees.dailyStorageFee)})</td>
                  <td style="padding: 8px 0; color: #18181b; font-size: 14px; text-align: right;">${formatCurrency(data.fees.storageFee)}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #71717a; font-size: 14px;">Admin Fee</td>
                  <td style="padding: 8px 0; color: #18181b; font-size: 14px; text-align: right;">${formatCurrency(data.fees.adminFee)}</td>
                </tr>
                ${data.fees.gateFee > 0 ? `
                <tr>
                  <td style="padding: 8px 0; color: #71717a; font-size: 14px;">Gate Fee</td>
                  <td style="padding: 8px 0; color: #18181b; font-size: 14px; text-align: right;">${formatCurrency(data.fees.gateFee)}</td>
                </tr>
                ` : ''}
              </table>
              
              <hr style="border: none; border-top: 1px solid #e4e4e7; margin: 16px 0;">
              
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td style="padding: 8px 0; color: #71717a; font-size: 14px;">Subtotal</td>
                  <td style="padding: 8px 0; color: #18181b; font-size: 14px; text-align: right;">${formatCurrency(data.fees.subtotal)}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #71717a; font-size: 14px;">Service Fee (5%)</td>
                  <td style="padding: 8px 0; color: #18181b; font-size: 14px; text-align: right;">${formatCurrency(data.fees.serviceFee)}</td>
                </tr>
              </table>
              
              <!-- Total Box -->
              <table width="100%" cellpadding="0" cellspacing="0" style="margin-top: 16px; background-color: #f4f4f5; border-radius: 8px;">
                <tr>
                  <td style="padding: 16px;">
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="color: #18181b; font-size: 16px; font-weight: 700;">TOTAL PAID</td>
                        <td style="color: #14b8a6; font-size: 20px; font-weight: 700; text-align: right;">${formatCurrency(data.fees.total)}</td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #fafafa; padding: 24px; text-align: center; border-top: 1px solid #e4e4e7;">
              <p style="margin: 0 0 8px 0; color: #71717a; font-size: 12px;">This receipt confirms payment for vehicle release fees.</p>
              <p style="margin: 0; color: #71717a; font-size: 12px;">For questions, contact the tow yard directly or visit <a href="https://towtrace.com" style="color: #14b8a6; text-decoration: none;">towtrace.com</a></p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseClient = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
  );

  try {
    // Verify authentication
    const authHeader = req.headers.get("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 401,
      });
    }

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token);
    
    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 401,
      });
    }

    const requestData: ReceiptEmailRequest = await req.json();

    if (!requestData.email || !requestData.receiptNumber) {
      return new Response(
        JSON.stringify({ error: "Missing required fields: email, receiptNumber" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const html = generateReceiptEmailHtml(requestData);

    const emailResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: "TowTrace <receipts@resend.dev>",
        to: [requestData.email],
        subject: `Payment Receipt #${requestData.receiptNumber} - TowTrace`,
        html,
      }),
    });

    const result = await emailResponse.json();

    if (!emailResponse.ok) {
      throw new Error(result.message || "Failed to send receipt email");
    }

    console.log("Receipt email sent successfully:", { 
      receiptNumber: requestData.receiptNumber, 
      email: requestData.email,
      result 
    });

    return new Response(JSON.stringify({ success: true, ...result }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: unknown) {
    let errorMessage = "Unknown error";
    let errorStack = "";
    
    if (error instanceof Error) {
      errorMessage = error.message;
      errorStack = error.stack || "";
    }
    
    console.error("send-receipt-email Error:", JSON.stringify({
      message: errorMessage,
      stack: errorStack,
      timestamp: new Date().toISOString(),
      function: "send-receipt-email",
    }));
    
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  }
});
