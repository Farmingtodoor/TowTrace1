import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@18.5.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";
import { checkRateLimit, getRateLimitIdentifier, rateLimitExceededResponse } from "../_shared/rate-limit.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Subscription tiers
const PRICE_IDS = {
  basic: "price_1Sn9IvIRt89bxpEw7TLEwkcX",
  pro: "price_1Sn9JAIRt89bxpEwOdbA4W7D",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseClient = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_ANON_KEY") ?? ""
  );

  try {
    const authHeader = req.headers.get("Authorization")!;
    const token = authHeader.replace("Bearer ", "");
    const { data } = await supabaseClient.auth.getUser(token);
    const user = data.user;
    if (!user?.email) throw new Error("User not authenticated");

    // Rate limiting check
    const identifier = getRateLimitIdentifier(req, user.id);
    const { allowed, retryAfter } = checkRateLimit(identifier, "subscription");
    
    if (!allowed) {
      return rateLimitExceededResponse(retryAfter, corsHeaders);
    }

    const { plan } = await req.json();
    if (!plan || !PRICE_IDS[plan as keyof typeof PRICE_IDS]) {
      throw new Error("Invalid plan. Choose 'basic' or 'pro'");
    }

    const priceId = PRICE_IDS[plan as keyof typeof PRICE_IDS];

    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
      apiVersion: "2025-08-27.basil",
    });

    // Check for existing customer
    const customers = await stripe.customers.list({ email: user.email, limit: 1 });
    let customerId;
    if (customers.data.length > 0) {
      customerId = customers.data[0].id;
    }

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      customer_email: customerId ? undefined : user.email,
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      mode: "subscription",
      success_url: `${req.headers.get("origin")}/operator?subscription=success`,
      cancel_url: `${req.headers.get("origin")}/operator?subscription=cancelled`,
      metadata: {
        userId: user.id,
        plan,
      },
    });

    return new Response(JSON.stringify({ url: session.url }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error: unknown) {
    // Comprehensive error logging
    let errorMessage = "Unknown error";
    let errorCode = "";
    let errorType = "";
    let errorStack = "";
    
    if (error instanceof Error) {
      errorMessage = error.message;
      errorStack = error.stack || "";
      
      // Check for Stripe-specific error details
      const stripeError = error as { type?: string; code?: string; decline_code?: string };
      if (stripeError.type) errorType = stripeError.type;
      if (stripeError.code) errorCode = stripeError.code;
      if (stripeError.decline_code) errorCode = stripeError.decline_code;
    }
    
    console.error("create-subscription Error:", JSON.stringify({
      message: errorMessage,
      type: errorType || undefined,
      code: errorCode || undefined,
      stack: errorStack,
      timestamp: new Date().toISOString(),
      function: "create-subscription",
    }));
    
    return new Response(JSON.stringify({ 
      error: errorMessage,
      errorCode: errorCode || undefined,
      errorType: errorType || undefined,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
