-- Enable realtime for tow_records table
ALTER PUBLICATION supabase_realtime ADD TABLE public.tow_records;