-- Create email_templates table for storing customizable email templates
CREATE TABLE public.email_templates (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  template_key text NOT NULL UNIQUE,
  name text NOT NULL,
  subject text NOT NULL,
  html_body text NOT NULL,
  description text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.email_templates ENABLE ROW LEVEL SECURITY;

-- Only admins can manage email templates
CREATE POLICY "Admins can manage email templates"
ON public.email_templates
FOR ALL
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Anyone can read templates (needed for edge functions via service role)
CREATE POLICY "Service role can read templates"
ON public.email_templates
FOR SELECT
TO anon
USING (true);

-- Add trigger for updated_at
CREATE TRIGGER update_email_templates_updated_at
BEFORE UPDATE ON public.email_templates
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default templates
INSERT INTO public.email_templates (template_key, name, subject, html_body, description) VALUES
(
  'company_approved',
  'Company Approved',
  'Great news! {{company_name}} has been approved',
  '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
    <div style="background: linear-gradient(135deg, #1a365d 0%, #2d4a6f 100%); padding: 30px; border-radius: 12px 12px 0 0; text-align: center;">
      <h1 style="color: white; margin: 0; font-size: 24px;">🎉 Congratulations!</h1>
    </div>
    <div style="background: #f8fafc; padding: 30px; border-radius: 0 0 12px 12px;">
      <p style="font-size: 16px; color: #334155; margin-bottom: 20px;">
        Great news! <strong>{{company_name}}</strong> has been approved on TowTrace.
      </p>
      <p style="font-size: 16px; color: #334155; margin-bottom: 20px;">
        You can now start managing your tow records and helping vehicle owners locate their cars.
      </p>
      <div style="text-align: center; margin: 30px 0;">
        <a href="{{dashboard_url}}" style="background: #0d9488; color: white; padding: 14px 28px; text-decoration: none; border-radius: 8px; font-weight: 600;">
          Go to Dashboard
        </a>
      </div>
      <p style="font-size: 14px; color: #64748b; margin-top: 30px;">
        If you have any questions, please contact our support team.
      </p>
    </div>
  </div>',
  'Sent when a tow company registration is approved by an admin.'
),
(
  'company_rejected',
  'Company Rejected',
  'Update on your {{company_name}} registration',
  '<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
    <div style="background: linear-gradient(135deg, #7f1d1d 0%, #991b1b 100%); padding: 30px; border-radius: 12px 12px 0 0; text-align: center;">
      <h1 style="color: white; margin: 0; font-size: 24px;">Registration Update</h1>
    </div>
    <div style="background: #f8fafc; padding: 30px; border-radius: 0 0 12px 12px;">
      <p style="font-size: 16px; color: #334155; margin-bottom: 20px;">
        We''ve reviewed your registration for <strong>{{company_name}}</strong> and unfortunately, we''re unable to approve it at this time.
      </p>
      <p style="font-size: 16px; color: #334155; margin-bottom: 20px;">
        This may be due to incomplete information or verification issues. Please contact our support team for more details.
      </p>
      <p style="font-size: 14px; color: #64748b; margin-top: 30px;">
        If you believe this was a mistake, please reach out to our support team.
      </p>
    </div>
  </div>',
  'Sent when a tow company registration is rejected by an admin.'
);