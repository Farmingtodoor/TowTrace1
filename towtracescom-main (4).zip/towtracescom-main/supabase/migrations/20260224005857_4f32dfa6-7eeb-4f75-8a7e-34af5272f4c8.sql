
-- Create a secure view for public tow yard data (excludes email, phone)
CREATE OR REPLACE VIEW public.public_tow_yards AS
SELECT 
  id, name, address, city, state_province, country, postal_code,
  hours_json, allows_in_app_payment, is_approved, accepted_payment_methods,
  created_at, updated_at
FROM public.tow_yards
WHERE is_approved = true;

-- Create a secure view for public tow record search (excludes driver_name, driver_user_id, locked_by fields)
CREATE OR REPLACE VIEW public.public_tow_records AS
SELECT 
  id, tow_yard_id, plate_number, plate_state_province, country, vin,
  make, model, color, vehicle_type, tow_datetime, tow_reason, tow_from_address,
  tow_fee, daily_storage_fee, admin_fee, gate_fee, storage_start_datetime,
  status, currency, release_requirements, vehicle_photos, created_at, updated_at
FROM public.tow_records
WHERE status <> 'released';

-- Grant access to the views for anon and authenticated roles
GRANT SELECT ON public.public_tow_yards TO anon, authenticated;
GRANT SELECT ON public.public_tow_records TO anon, authenticated;
