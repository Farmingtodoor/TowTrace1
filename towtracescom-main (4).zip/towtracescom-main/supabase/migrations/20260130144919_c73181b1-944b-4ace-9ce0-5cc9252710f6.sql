-- Drop the existing INSERT policy
DROP POLICY IF EXISTS "Authenticated users can submit tow yard applications" ON public.tow_yards;

-- Recreate with explicit authentication check in WITH CHECK
CREATE POLICY "Authenticated users can submit tow yard applications" 
ON public.tow_yards 
FOR INSERT 
TO authenticated
WITH CHECK (is_approved = false);