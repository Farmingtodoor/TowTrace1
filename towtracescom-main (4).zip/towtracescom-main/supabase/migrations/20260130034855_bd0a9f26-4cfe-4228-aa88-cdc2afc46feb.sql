-- Create enum for dispute status
CREATE TYPE public.dispute_status AS ENUM ('open', 'under_review', 'resolved', 'rejected');

-- Create enum for dispute type
CREATE TYPE public.dispute_type AS ENUM ('vehicle_damage', 'property_damage', 'missing_items', 'overcharge', 'other');

-- Create disputes table
CREATE TABLE public.disputes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  claim_id UUID NOT NULL REFERENCES public.claims(id) ON DELETE CASCADE,
  tow_record_id UUID NOT NULL REFERENCES public.tow_records(id) ON DELETE CASCADE,
  consumer_user_id UUID NOT NULL,
  tow_yard_id UUID NOT NULL REFERENCES public.tow_yards(id) ON DELETE CASCADE,
  dispute_type dispute_type NOT NULL,
  status dispute_status NOT NULL DEFAULT 'open',
  description TEXT NOT NULL,
  evidence_urls TEXT[] DEFAULT '{}',
  resolution_notes TEXT,
  resolved_by_user_id UUID,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.disputes ENABLE ROW LEVEL SECURITY;

-- Consumers can create disputes for their own claims
CREATE POLICY "Consumers can create disputes for their claims"
ON public.disputes
FOR INSERT
WITH CHECK (
  consumer_user_id = auth.uid() AND
  EXISTS (
    SELECT 1 FROM public.claims c
    JOIN public.tow_records tr ON c.tow_record_id = tr.id
    WHERE c.id = disputes.claim_id
    AND c.consumer_user_id = auth.uid()
    AND tr.status = 'released'
  )
);

-- Consumers can view their own disputes
CREATE POLICY "Consumers can view their own disputes"
ON public.disputes
FOR SELECT
USING (consumer_user_id = auth.uid());

-- Operators can view disputes for their yards
CREATE POLICY "Operators can view disputes for their yards"
ON public.disputes
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.tow_yard_operators tyo
    WHERE tyo.tow_yard_id = disputes.tow_yard_id
    AND tyo.operator_user_id = auth.uid()
  )
);

-- Operators can update disputes for their yards
CREATE POLICY "Operators can update disputes for their yards"
ON public.disputes
FOR UPDATE
USING (
  EXISTS (
    SELECT 1 FROM public.tow_yard_operators tyo
    WHERE tyo.tow_yard_id = disputes.tow_yard_id
    AND tyo.operator_user_id = auth.uid()
  )
);

-- Admins can manage all disputes
CREATE POLICY "Admins can manage all disputes"
ON public.disputes
FOR ALL
USING (has_role(auth.uid(), 'admin'));

-- Create trigger for updating timestamps
CREATE TRIGGER update_disputes_updated_at
BEFORE UPDATE ON public.disputes
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();