import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Loader2, Building2, CheckCircle } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';

const contactSchema = z.object({
  name: z.string().trim().min(2, 'Name is required').max(100, 'Name must be less than 100 characters'),
  email: z.string().trim().email('Valid email required').max(255, 'Email must be less than 255 characters'),
  company: z.string().trim().min(2, 'Company name is required').max(100, 'Company name must be less than 100 characters'),
  phone: z.string().trim().min(10, 'Valid phone number required').max(20, 'Phone must be less than 20 characters'),
  fleetSize: z.string().min(1, 'Please select fleet size'),
  message: z.string().trim().max(1000, 'Message must be less than 1000 characters').optional(),
});

type ContactFormData = z.infer<typeof contactSchema>;

interface EnterpriseContactModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function EnterpriseContactModal({ isOpen, onClose }: EnterpriseContactModalProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const {
    register,
    handleSubmit,
    setValue,
    reset,
    formState: { errors },
  } = useForm<ContactFormData>({
    resolver: zodResolver(contactSchema),
    defaultValues: {
      fleetSize: '',
    },
  });

  const onSubmit = async (data: ContactFormData) => {
    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsSubmitting(false);
    setIsSuccess(true);
    
    toast({
      title: 'Message Sent!',
      description: 'Our enterprise team will contact you within 24 hours.',
    });
  };

  const handleClose = () => {
    reset();
    setIsSuccess(false);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg">
        {isSuccess ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-accent" />
            </div>
            <DialogTitle className="font-display text-2xl mb-2">Thank You!</DialogTitle>
            <DialogDescription className="mb-6">
              Our enterprise sales team will contact you within 24 hours to discuss your needs.
            </DialogDescription>
            <Button onClick={handleClose} className="w-full">
              Close
            </Button>
          </div>
        ) : (
          <>
            <DialogHeader>
              <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center mb-2">
                <Building2 className="w-6 h-6 text-accent" />
              </div>
              <DialogTitle className="font-display text-xl">Contact Enterprise Sales</DialogTitle>
              <DialogDescription>
                Get a custom quote for your large-scale towing operation. Our team will reach out within 24 hours.
              </DialogDescription>
            </DialogHeader>

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Your Name *</Label>
                  <Input
                    id="name"
                    {...register('name')}
                    placeholder="John Smith"
                  />
                  {errors.name && (
                    <p className="text-xs text-destructive">{errors.name.message}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    {...register('email')}
                    placeholder="john@company.com"
                  />
                  {errors.email && (
                    <p className="text-xs text-destructive">{errors.email.message}</p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="company">Company Name *</Label>
                  <Input
                    id="company"
                    {...register('company')}
                    placeholder="ABC Towing Inc."
                  />
                  {errors.company && (
                    <p className="text-xs text-destructive">{errors.company.message}</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone *</Label>
                  <Input
                    id="phone"
                    {...register('phone')}
                    placeholder="(555) 123-4567"
                  />
                  {errors.phone && (
                    <p className="text-xs text-destructive">{errors.phone.message}</p>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Fleet Size *</Label>
                <Select onValueChange={(v) => setValue('fleetSize', v)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select your fleet size" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10-25">10-25 tow trucks</SelectItem>
                    <SelectItem value="26-50">26-50 tow trucks</SelectItem>
                    <SelectItem value="51-100">51-100 tow trucks</SelectItem>
                    <SelectItem value="100+">100+ tow trucks</SelectItem>
                    <SelectItem value="multi-location">Multi-location operation</SelectItem>
                  </SelectContent>
                </Select>
                {errors.fleetSize && (
                  <p className="text-xs text-destructive">{errors.fleetSize.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">Message (Optional)</Label>
                <Textarea
                  id="message"
                  {...register('message')}
                  placeholder="Tell us about your needs, current challenges, or any questions..."
                  rows={3}
                />
                {errors.message && (
                  <p className="text-xs text-destructive">{errors.message.message}</p>
                )}
              </div>

              <div className="flex gap-3 pt-2">
                <Button type="button" variant="outline" onClick={handleClose} className="flex-1">
                  Cancel
                </Button>
                <Button type="submit" disabled={isSubmitting} className="flex-1">
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    'Send Message'
                  )}
                </Button>
              </div>
            </form>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}