import { useState, useCallback } from 'react';
import { Upload, X, FileText, Check, Loader2, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { logDocumentUploaded } from '@/lib/activityLog';

type DocType = 'gov_id' | 'registration' | 'title' | 'insurance' | 'authorization';

interface DocumentUploadProps {
  claimId: string;
  docType: DocType;
  label: string;
  description: string;
  required?: boolean;
  existingDocument?: {
    id: string;
    status: 'pending' | 'approved' | 'rejected';
    fileName?: string;
  };
  onUploadComplete?: (docId: string) => void;
}

export function DocumentUpload({
  claimId,
  docType,
  label,
  description,
  required = false,
  existingDocument,
  onUploadComplete,
}: DocumentUploadProps) {
  const { user } = useAuth();
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploadedFile, setUploadedFile] = useState<string | null>(
    existingDocument?.fileName || null
  );
  const [status, setStatus] = useState<'pending' | 'approved' | 'rejected' | null>(
    existingDocument?.status || null
  );

  const handleFileChange = useCallback(
    async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file || !user) return;

      // Validate file type
      const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];
      if (!allowedTypes.includes(file.type)) {
        setError('Please upload a JPG, PNG, WebP, or PDF file');
        return;
      }

      // Validate file size (10MB max)
      if (file.size > 10 * 1024 * 1024) {
        setError('File size must be under 10MB');
        return;
      }

      setIsUploading(true);
      setError(null);

      try {
        // Upload to storage
        const fileName = `${Date.now()}-${file.name}`;
        const filePath = `${user.id}/${claimId}/${docType}/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('claim-documents')
          .upload(filePath, file);

        if (uploadError) throw uploadError;

        // Get public URL
        const { data: urlData } = supabase.storage
          .from('claim-documents')
          .getPublicUrl(filePath);

        // Insert document record
        const { data: docData, error: docError } = await supabase
          .from('documents')
          .insert({
            claim_id: claimId,
            doc_type: docType,
            file_url: urlData.publicUrl,
            file_name: file.name,
            status: 'pending',
          })
          .select('id')
          .single();

        if (docError) throw docError;

        // Log the document upload
        await logDocumentUploaded(docData.id, docType, claimId);

        setUploadedFile(file.name);
        setStatus('pending');
        onUploadComplete?.(docData.id);
      } catch (err) {
        console.error('Upload error:', err);
        setError('Failed to upload document. Please try again.');
      } finally {
        setIsUploading(false);
      }
    },
    [user, claimId, docType, onUploadComplete]
  );

  const getStatusBadge = () => {
    if (!status) return null;

    const badges = {
      pending: (
        <span className="inline-flex items-center gap-1 text-xs bg-warning/10 text-warning px-2 py-1 rounded-full">
          <Loader2 className="w-3 h-3 animate-spin" />
          Under Review
        </span>
      ),
      approved: (
        <span className="inline-flex items-center gap-1 text-xs bg-success/10 text-success px-2 py-1 rounded-full">
          <Check className="w-3 h-3" />
          Approved
        </span>
      ),
      rejected: (
        <span className="inline-flex items-center gap-1 text-xs bg-destructive/10 text-destructive px-2 py-1 rounded-full">
          <X className="w-3 h-3" />
          Rejected
        </span>
      ),
    };

    return badges[status];
  };

  return (
    <div className="border border-border rounded-xl p-4 space-y-3">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h4 className="font-semibold flex items-center gap-2">
            <FileText className="w-4 h-4 text-accent" />
            {label}
            {required && <span className="text-destructive">*</span>}
          </h4>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
        {getStatusBadge()}
      </div>

      {uploadedFile ? (
        <div className="flex items-center gap-3 bg-muted/50 rounded-lg p-3">
          <FileText className="w-5 h-5 text-muted-foreground" />
          <span className="text-sm truncate flex-1">{uploadedFile}</span>
          {status === 'rejected' && (
            <label className="cursor-pointer">
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp,application/pdf"
                onChange={handleFileChange}
                className="hidden"
              />
              <Button variant="outline" size="sm" asChild>
                <span>Re-upload</span>
              </Button>
            </label>
          )}
        </div>
      ) : (
        <label className="cursor-pointer">
          <input
            type="file"
            accept="image/jpeg,image/png,image/webp,application/pdf"
            onChange={handleFileChange}
            className="hidden"
            disabled={isUploading}
          />
          <div className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-accent hover:bg-accent/5 transition-colors">
            {isUploading ? (
              <div className="flex flex-col items-center gap-2">
                <Loader2 className="w-8 h-8 text-accent animate-spin" />
                <p className="text-sm text-muted-foreground">Uploading...</p>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2">
                <Upload className="w-8 h-8 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">
                  Click to upload or drag and drop
                </p>
                <p className="text-xs text-muted-foreground">
                  JPG, PNG, WebP, or PDF up to 10MB
                </p>
              </div>
            )}
          </div>
        </label>
      )}

      {error && (
        <div className="flex items-center gap-2 text-sm text-destructive">
          <AlertCircle className="w-4 h-4" />
          {error}
        </div>
      )}
    </div>
  );
}
