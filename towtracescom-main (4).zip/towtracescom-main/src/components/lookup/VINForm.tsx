import { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, AlertCircle, Info, Loader2, CheckCircle2, Car } from 'lucide-react';
import { validateVIN, formatVIN } from '@/lib/validation';
import { useVINDecoder } from '@/hooks/useVINDecoder';

interface VINFormProps {
  onSearch: (vin: string) => void;
  isLoading?: boolean;
}

export function VINForm({ onSearch, isLoading }: VINFormProps) {
  const [vin, setVin] = useState('');
  const [error, setError] = useState<string | null>(null);
  const { decode, isDecoding, decodedData, reset: resetDecoder } = useVINDecoder();

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const formatted = formatVIN(vin);
    const validation = validateVIN(formatted);
    
    if (!validation.valid) {
      setError(validation.message || 'Invalid VIN');
      return;
    }

    onSearch(formatted);
  }, [vin, onSearch]);

  const charCount = formatVIN(vin).length;

  const handleVINChange = async (value: string) => {
    const formatted = value.toUpperCase().replace(/[^A-HJ-NPR-Z0-9]/g, '');
    setVin(formatted);
    setError(null);
    
    // Auto-decode when VIN reaches 17 characters
    if (formatted.length === 17 && !decodedData) {
      decode(formatted);
    } else if (formatted.length < 17 && decodedData) {
      resetDecoder();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {/* VIN Input */}
      <div className="space-y-2">
        <label htmlFor="vin" className="text-sm font-medium text-foreground">
          Vehicle Identification Number (VIN)
        </label>
        <div className="relative">
          <Input
            id="vin"
            type="text"
            placeholder="1HGBH41JXMN109186"
            value={vin}
            onChange={(e) => handleVINChange(e.target.value)}
            className="text-lg font-mono tracking-wider uppercase pr-20"
            maxLength={17}
          />
          <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-2">
            {isDecoding && <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />}
            {decodedData && !isDecoding && <CheckCircle2 className="w-4 h-4 text-success" />}
            <span className={`text-sm font-medium ${
              charCount === 17 ? 'text-success' : 'text-muted-foreground'
            }`}>
              {charCount}/17
            </span>
          </div>
        </div>
      </div>

      {/* Decoded Vehicle Info */}
      {decodedData && (
        <div className="bg-success/10 border border-success/20 rounded-lg p-3 animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="flex items-center gap-2 text-sm font-medium text-success mb-2">
            <Car className="w-4 h-4" />
            Vehicle Identified
          </div>
          <p className="text-sm font-medium">
            {decodedData.year} {decodedData.make} {decodedData.model}
            {decodedData.trimLevel && ` ${decodedData.trimLevel}`}
          </p>
          {decodedData.bodyClass && (
            <p className="text-xs text-muted-foreground mt-1">{decodedData.bodyClass}</p>
          )}
        </div>
      )}

      {/* VIN Info */}
      {!decodedData && (
        <div className="flex items-start gap-2 p-3 bg-secondary/50 rounded-lg text-sm">
          <Info className="w-4 h-4 text-secondary-foreground mt-0.5 shrink-0" />
          <p className="text-secondary-foreground">
            Your VIN is a 17-character code found on your dashboard (driver's side) or inside the driver's door frame.
          </p>
        </div>
      )}

      {/* Error Message */}
      {error && (
        <div className="flex items-center gap-2 text-destructive text-sm animate-fade-in">
          <AlertCircle className="w-4 h-4" />
          <span>{error}</span>
        </div>
      )}

      {/* Submit Button */}
      <Button
        type="submit"
        variant="hero"
        size="lg"
        className="w-full"
        disabled={isLoading}
      >
        {isLoading ? (
          <span className="flex items-center gap-2">
            <span className="w-5 h-5 border-2 border-accent-foreground/30 border-t-accent-foreground rounded-full animate-spin" />
            Searching...
          </span>
        ) : (
          <span className="flex items-center gap-2">
            <Search className="w-5 h-5" />
            Find My Vehicle
          </span>
        )}
      </Button>
    </form>
  );
}
