import { Car, Search, FileText, CreditCard, CheckCircle, Sparkles } from 'lucide-react';

export function HeroDescription() {
  const steps = [
    {
      icon: Search,
      title: 'Search',
      description: 'Enter your plate number or VIN',
      color: 'from-accent to-accent/70',
    },
    {
      icon: FileText,
      title: 'Verify',
      description: 'Upload required documents',
      color: 'from-info to-info/70',
    },
    {
      icon: CreditCard,
      title: 'Pay',
      description: 'Clear fees securely online',
      color: 'from-success to-success/70',
    },
    {
      icon: CheckCircle,
      title: 'Collect',
      description: 'Pick up your vehicle',
      color: 'from-primary to-primary/70',
    },
  ];

  return (
    <section className="py-20 md:py-28 px-4 bg-gradient-to-b from-muted/50 to-background relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 right-10 w-64 h-64 bg-accent/5 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-10 w-72 h-72 bg-info/5 rounded-full blur-3xl" />
      </div>

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Main Description */}
        <div className="text-center mb-16 space-y-6">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-accent/10 to-info/10 px-5 py-2.5 rounded-full text-accent text-sm font-medium border border-accent/20">
            <Sparkles className="w-4 h-4" />
            The Smarter Way to Recover Your Vehicle
          </div>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-balance">
            From Towed to Returned in{' '}
            <span className="relative inline-block">
              <span className="bg-gradient-to-r from-accent to-info bg-clip-text text-transparent">4 Simple Steps</span>
            </span>
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            TowTrace connects you directly with tow yards across the US and Canada. 
            No more endless phone calls or confusion about where your car is.
          </p>
        </div>

        {/* Steps - Timeline Style */}
        <div className="relative">
          {/* Connection line */}
          <div className="hidden md:block absolute top-1/2 left-0 right-0 h-1 bg-gradient-to-r from-accent via-info via-success to-primary -translate-y-1/2 rounded-full opacity-20" />
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
            {steps.map((step, index) => (
              <div 
                key={index}
                className="relative group"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="bg-card rounded-3xl p-6 md:p-8 shadow-card text-center transition-all duration-300 hover:shadow-card-lg hover:-translate-y-2 border border-border/50">
                  {/* Step Number */}
                  <div className={`absolute -top-4 left-1/2 -translate-x-1/2 w-8 h-8 bg-gradient-to-br ${step.color} text-white rounded-full flex items-center justify-center font-bold text-sm shadow-lg ring-4 ring-background`}>
                    {index + 1}
                  </div>
                  
                  {/* Icon */}
                  <div className={`w-16 h-16 bg-gradient-to-br ${step.color} rounded-2xl flex items-center justify-center mx-auto mb-5 shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                    <step.icon className="w-8 h-8 text-white" />
                  </div>
                  
                  {/* Content */}
                  <h3 className="font-display text-xl font-bold mb-2">{step.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Benefits */}
        <div className="mt-16 md:mt-20 grid md:grid-cols-3 gap-6">
          {[
            { title: 'Transparent Pricing', desc: 'See all fees upfront before you visit' },
            { title: 'Verified Tow Yards', desc: 'All partners are vetted for quality' },
            { title: 'Digital Process', desc: 'Submit documents online, save time' },
          ].map((benefit, index) => (
            <div 
              key={index}
              className="flex items-start gap-4 bg-card/50 backdrop-blur-sm rounded-2xl p-5 border border-border/50 hover:border-accent/30 transition-colors"
            >
              <div className="w-12 h-12 bg-gradient-to-br from-success/20 to-accent/20 rounded-xl flex items-center justify-center shrink-0">
                <CheckCircle className="w-6 h-6 text-success" />
              </div>
              <div>
                <p className="font-semibold text-lg">{benefit.title}</p>
                <p className="text-muted-foreground">{benefit.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
