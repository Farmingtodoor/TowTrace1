import { useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { 
  MapPin, 
  Phone, 
  Clock, 
  DollarSign, 
  Calendar,
  Car,
  ExternalLink,
  FileText,
  AlertTriangle,
  PartyPopper,
  Search,
  Sparkles
} from 'lucide-react';
import confetti from 'canvas-confetti';

export interface TowRecord {
  id: string;
  plate?: string;
  vin?: string;
  make?: string;
  model?: string;
  color?: string;
  vehicleType?: string;
  towDateTime: string;
  towReason?: string;
  towFromAddress?: string;
  towYard: {
    name: string;
    address: string;
    city: string;
    state: string;
    phone: string;
    hours: string;
    acceptedPayments: string[];
  };
  fees: {
    towFee: number;
    dailyStorageFee: number;
    adminFee: number;
    gateFee: number;
    daysStored: number;
    totalDue: number;
    currency: 'USD' | 'CAD';
  };
  status: 'towed' | 'docs_pending' | 'docs_approved' | 'paid' | 'released';
  releaseRequirements: string[];
}

const VEHICLE_TYPE_LABELS: Record<string, string> = {
  motorcycle: 'Motorcycle',
  standard: 'Standard (Sedan/Coupe)',
  suv: 'SUV/Crossover',
  truck: 'Pickup Truck',
  van: 'Van/Minivan',
  commercial: 'Commercial Vehicle',
  heavy_duty: 'Heavy Duty/RV',
};

interface TowResultProps {
  record: TowRecord;
  onClaimVehicle: () => void;
  onSearchAgain?: () => void;
}

export function TowResult({ record, onClaimVehicle, onSearchAgain }: TowResultProps) {
  const currencySymbol = record.fees.currency === 'USD' ? '$' : 'CA$';
  
  const formatCurrency = (amount: number) => {
    return `${currencySymbol}${amount.toFixed(2)}`;
  };

  const fullAddress = `${record.towYard.address}, ${record.towYard.city}, ${record.towYard.state}`;
  
  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(fullAddress)}`;
  
  const appleMapsUrl = `https://maps.apple.com/?q=${encodeURIComponent(fullAddress)}`;

  // Fire confetti on mount
  useEffect(() => {
    const duration = 3000;
    const end = Date.now() + duration;

    const colors = ['#10b981', '#3b82f6', '#f59e0b', '#ec4899'];

    const frame = () => {
      confetti({
        particleCount: 3,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: colors
      });
      confetti({
        particleCount: 3,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: colors
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };

    // Initial burst
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
      colors: colors
    });

    frame();
  }, []);

  return (
    <div className="w-full max-w-2xl mx-auto space-y-6 animate-fade-in">
      {/* Exciting Success Header */}
      <div className="text-center space-y-4 py-6">
        <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-success/20 to-accent/20 rounded-full animate-scale-in">
          <PartyPopper className="w-10 h-10 text-success" />
        </div>
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 text-accent">
            <Sparkles className="w-5 h-5" />
            <span className="text-sm font-medium uppercase tracking-wider">Great News!</span>
            <Sparkles className="w-5 h-5" />
          </div>
          <h1 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground">
            🎉 We Found Your Car!
          </h1>
          <p className="text-lg text-muted-foreground max-w-md mx-auto">
            Your vehicle has been located and is safely stored at the tow yard below.
          </p>
        </div>
        
        {onSearchAgain && (
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onSearchAgain}
            className="text-muted-foreground hover:text-foreground"
          >
            <Search className="w-4 h-4 mr-2" />
            Search for another vehicle
          </Button>
        )}
      </div>

      {/* Vehicle Info Card */}
      <div className="bg-card rounded-xl shadow-card p-5 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
            <Car className="w-6 h-6 text-primary" />
          </div>
          <div>
            <p className="font-semibold text-lg">
              {record.make && record.model 
                ? `${record.make} ${record.model}` 
                : 'Vehicle Details'}
            </p>
            <div className="flex items-center gap-2">
              {record.color && (
                <span className="text-sm text-muted-foreground">{record.color}</span>
              )}
              {record.vehicleType && (
                <span className="text-xs bg-muted px-2 py-0.5 rounded">
                  {VEHICLE_TYPE_LABELS[record.vehicleType] || record.vehicleType}
                </span>
              )}
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-3 text-sm">
          {record.plate && (
            <div className="bg-muted/50 rounded-lg p-3">
              <p className="text-muted-foreground text-xs">Plate</p>
              <p className="font-mono font-semibold">{record.plate}</p>
            </div>
          )}
          {record.vin && (
            <div className="bg-muted/50 rounded-lg p-3">
              <p className="text-muted-foreground text-xs">VIN</p>
              <p className="font-mono font-semibold text-xs">{record.vin}</p>
            </div>
          )}
        </div>
      </div>

      {/* Tow Yard Card */}
      <div className="bg-card rounded-xl shadow-card p-5 space-y-4">
        <h3 className="font-semibold text-lg flex items-center gap-2">
          <MapPin className="w-5 h-5 text-accent" />
          Tow Yard Location
        </h3>
        
        <div className="space-y-3">
          <div>
            <p className="font-semibold">{record.towYard.name}</p>
            <p className="text-muted-foreground text-sm">
              {record.towYard.address}<br />
              {record.towYard.city}, {record.towYard.state}
            </p>
          </div>
          
          <a
            href={`tel:${record.towYard.phone}`}
            className="inline-flex items-center gap-2 bg-primary/10 text-primary hover:bg-primary/20 px-4 py-2 rounded-lg text-sm font-medium transition-colors"
          >
            <Phone className="w-4 h-4" />
            {record.towYard.phone}
          </a>

          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="w-4 h-4" />
            <span>{record.towYard.hours}</span>
          </div>
        </div>
      </div>

      {/* Prominent Get Directions Section */}
      <div className="bg-gradient-to-br from-accent/10 via-card to-info/10 rounded-xl shadow-card p-6 space-y-4 border border-accent/20">
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-14 h-14 bg-accent/20 rounded-full">
            <MapPin className="w-7 h-7 text-accent" />
          </div>
          <h3 className="font-semibold text-lg">Get Directions to Tow Yard</h3>
          <p className="text-sm text-muted-foreground">
            Choose your preferred navigation app
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <a
            href={mapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-3 bg-accent text-accent-foreground hover:bg-accent/90 px-6 py-4 rounded-xl text-base font-semibold transition-all shadow-md hover:shadow-lg"
          >
            <ExternalLink className="w-5 h-5" />
            Open in Google Maps
          </a>
          <a
            href={appleMapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-3 bg-foreground text-background hover:bg-foreground/90 px-6 py-4 rounded-xl text-base font-semibold transition-all shadow-md hover:shadow-lg"
          >
            <ExternalLink className="w-5 h-5" />
            Open in Apple Maps
          </a>
        </div>
        
        <p className="text-xs text-center text-muted-foreground">
          {record.towYard.address}, {record.towYard.city}, {record.towYard.state}
        </p>
      </div>

      {/* Tow Details */}
      <div className="bg-card rounded-xl shadow-card p-5 space-y-3">
        <h3 className="font-semibold text-lg flex items-center gap-2">
          <Calendar className="w-5 h-5 text-accent" />
          Tow Details
        </h3>
        
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Towed On</span>
            <span className="font-medium">{new Date(record.towDateTime).toLocaleDateString('en-US', {
              weekday: 'short',
              month: 'short',
              day: 'numeric',
              year: 'numeric',
              hour: 'numeric',
              minute: '2-digit'
            })}</span>
          </div>
          {record.towReason && (
            <div className="flex justify-between">
              <span className="text-muted-foreground">Reason</span>
              <span className="font-medium">{record.towReason}</span>
            </div>
          )}
          {record.towFromAddress && (
            <div className="flex justify-between">
              <span className="text-muted-foreground">Towed From</span>
              <span className="font-medium text-right">{record.towFromAddress}</span>
            </div>
          )}
        </div>
      </div>

      {/* Fees Breakdown */}
      <div className="bg-card rounded-xl shadow-card p-5 space-y-4">
        <h3 className="font-semibold text-lg flex items-center gap-2">
          <DollarSign className="w-5 h-5 text-accent" />
          Fees & Charges
        </h3>
        
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Tow Fee</span>
            <span>{formatCurrency(record.fees.towFee)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">
              Storage ({record.fees.daysStored} days × {formatCurrency(record.fees.dailyStorageFee)}/day)
            </span>
            <span>{formatCurrency(record.fees.dailyStorageFee * record.fees.daysStored)}</span>
          </div>
          {record.fees.adminFee > 0 && (
            <div className="flex justify-between">
              <span className="text-muted-foreground">Admin Fee</span>
              <span>{formatCurrency(record.fees.adminFee)}</span>
            </div>
          )}
          {record.fees.gateFee > 0 && (
            <div className="flex justify-between">
              <span className="text-muted-foreground">Gate Fee</span>
              <span>{formatCurrency(record.fees.gateFee)}</span>
            </div>
          )}
          <div className="border-t border-border pt-2 mt-2">
            <div className="flex justify-between font-semibold text-base">
              <span>Total Due</span>
              <span className="text-accent">{formatCurrency(record.fees.totalDue)}</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              * Storage fees increase daily
            </p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2 pt-2">
          <span className="text-xs text-muted-foreground">Accepted:</span>
          {record.towYard.acceptedPayments.map((method) => (
            <span key={method} className="text-xs bg-muted px-2 py-1 rounded-md">
              {method}
            </span>
          ))}
        </div>
      </div>

      {/* Release Requirements */}
      <div className="bg-card rounded-xl shadow-card p-5 space-y-3">
        <h3 className="font-semibold text-lg flex items-center gap-2">
          <FileText className="w-5 h-5 text-accent" />
          Required for Release
        </h3>
        
        <ul className="space-y-2">
          {record.releaseRequirements.map((req, index) => (
            <li key={index} className="flex items-start gap-2 text-sm">
              <span className="w-5 h-5 bg-accent/10 text-accent rounded-full flex items-center justify-center text-xs font-semibold shrink-0 mt-0.5">
                {index + 1}
              </span>
              <span>{req}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Disclaimer */}
      <div className="bg-warning/10 border border-warning/20 rounded-xl p-4 flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 text-warning shrink-0 mt-0.5" />
        <p className="text-sm text-warning-foreground">
          <strong>Important:</strong> Payment does not guarantee release. The tow yard must verify your identity and documentation before releasing your vehicle.
        </p>
      </div>

      {/* CTA Button */}
      <Button
        variant="hero"
        size="xl"
        className="w-full"
        onClick={onClaimVehicle}
      >
        Claim My Vehicle
      </Button>
    </div>
  );
}
