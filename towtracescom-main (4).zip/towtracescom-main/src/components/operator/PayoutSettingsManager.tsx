import { useState, useEffect } from 'react';
import { 
  Building2, 
  CreditCard, 
  Wallet, 
  Smartphone,
  Save,
  CheckCircle,
  AlertCircle,
  Loader2,
  ExternalLink,
  ArrowUpRight,
  Clock,
  XCircle,
  History
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/useAuth';
import { Separator } from '@/components/ui/separator';
import { format } from 'date-fns';

interface PayoutRequest {
  id: string;
  amount: number;
  status: string;
  payout_method: string;
  notes: string | null;
  created_at: string;
}

interface PayoutSettingsManagerProps {
  towYardId: string | null;
}

interface PayoutSettings {
  id?: string;
  tow_yard_id: string;
  payout_method: string;
  bank_name: string | null;
  bank_account_number: string | null;
  bank_routing_number: string | null;
  bank_account_holder_name: string | null;
  stripe_account_id: string | null;
  stripe_connected: boolean;
  paypal_email: string | null;
  apple_pay_merchant_id: string | null;
  minimum_payout_amount: number;
  payout_frequency: string;
  is_verified: boolean;
}

// Mask sensitive data - show only last 4 digits
const maskAccountNumber = (value: string | null): string => {
  if (!value || value.length < 4) return value || '';
  return '••••' + value.slice(-4);
};

const maskRoutingNumber = (value: string | null): string => {
  if (!value || value.length < 4) return value || '';
  return '•••••' + value.slice(-4);
};

const PAYOUT_METHODS = [
  { value: 'bank_account', label: 'Bank Account', icon: Building2, description: 'Direct bank transfer (ACH)' },
  { value: 'stripe', label: 'Stripe Connect', icon: CreditCard, description: 'Automated payouts via Stripe' },
  { value: 'paypal', label: 'PayPal', icon: Wallet, description: 'Receive funds to PayPal account' },
  { value: 'apple_pay', label: 'Apple Pay', icon: Smartphone, description: 'Apple Pay merchant payouts' },
];

const PAYOUT_FREQUENCIES = [
  { value: 'daily', label: 'Daily' },
  { value: 'weekly', label: 'Weekly' },
  { value: 'biweekly', label: 'Bi-weekly' },
  { value: 'monthly', label: 'Monthly' },
];

export function PayoutSettingsManager({ towYardId }: PayoutSettingsManagerProps) {
  const { user } = useAuth();
  const [settings, setSettings] = useState<PayoutSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [balance, setBalance] = useState<number>(0);
  const [balanceLoading, setBalanceLoading] = useState(true);
  const [payoutRequests, setPayoutRequests] = useState<PayoutRequest[]>([]);
  const [requestingPayout, setRequestingPayout] = useState(false);
  const [payoutAmount, setPayoutAmount] = useState('');
  const [payoutNotes, setPayoutNotes] = useState('');
  const [showRequestForm, setShowRequestForm] = useState(false);
  const [connectLoading, setConnectLoading] = useState(false);
  const [connectStatus, setConnectStatus] = useState<{
    chargesEnabled?: boolean;
    payoutsEnabled?: boolean;
    detailsSubmitted?: boolean;
    isFullyOnboarded?: boolean;
  } | null>(null);
  // Track if user is editing sensitive fields (to show raw vs masked)
  const [editingAccountNumber, setEditingAccountNumber] = useState(false);
  const [editingRoutingNumber, setEditingRoutingNumber] = useState(false);
  // Store original values to detect if user changed them
  const [originalAccountNumber, setOriginalAccountNumber] = useState<string | null>(null);
  const [originalRoutingNumber, setOriginalRoutingNumber] = useState<string | null>(null);

  useEffect(() => {
    if (!towYardId) return;
    fetchSettings();
    fetchBalance();
    fetchPayoutRequests();
  }, [towYardId]);

  // Check Connect status when settings load with a stripe_account_id
  useEffect(() => {
    if (settings?.stripe_account_id && towYardId) {
      checkConnectStatus();
    }
  }, [settings?.stripe_account_id]);

  const checkConnectStatus = async () => {
    if (!towYardId) return;
    try {
      const { data, error } = await supabase.functions.invoke('create-connect-account', {
        body: { towYardId, action: 'check_status' },
      });
      if (error) throw error;
      setConnectStatus(data);
      if (data.isFullyOnboarded && settings) {
        setSettings({ ...settings, stripe_connected: true, is_verified: true });
      }
    } catch (err) {
      console.error('Error checking connect status:', err);
    }
  };

  const handleConnectStripe = async () => {
    if (!towYardId) return;
    setConnectLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('create-connect-account', {
        body: { towYardId, action: 'onboard' },
      });
      if (error) throw error;
      if (data?.url) {
        window.location.href = data.url;
      }
    } catch (err: any) {
      console.error('Connect error:', err);
      toast.error('Failed to start Stripe Connect onboarding');
    } finally {
      setConnectLoading(false);
    }
  };

  const fetchBalance = async () => {
    if (!towYardId) return;
    setBalanceLoading(true);
    try {
      // Get all tow record IDs for this yard
      const { data: yardRecords } = await supabase
        .from('tow_records')
        .select('id')
        .eq('tow_yard_id', towYardId);

      const recordIds = yardRecords?.map(r => r.id) || [];
      if (recordIds.length === 0) {
        setBalance(0);
        setBalanceLoading(false);
        return;
      }

      // Get all succeeded payments for these records
      const { data: payments } = await supabase
        .from('payments')
        .select('amount')
        .eq('status', 'succeeded')
        .in('tow_record_id', recordIds);

      const total = payments?.reduce((sum, p) => sum + Number(p.amount || 0), 0) || 0;
      setBalance(total);
    } catch (err) {
      console.error('Error fetching balance:', err);
    } finally {
      setBalanceLoading(false);
    }
  };

  const fetchPayoutRequests = async () => {
    if (!towYardId) return;
    const { data } = await supabase
      .from('payout_requests')
      .select('id, amount, status, payout_method, notes, created_at')
      .eq('tow_yard_id', towYardId)
      .order('created_at', { ascending: false })
      .limit(10);
    setPayoutRequests((data as PayoutRequest[]) || []);
  };

  const handleRequestPayout = async () => {
    if (!towYardId || !user || !settings) return;
    const amount = parseFloat(payoutAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }
    if (amount > balance) {
      toast.error('Amount exceeds available balance');
      return;
    }
    setRequestingPayout(true);
    try {
      const { error } = await supabase.from('payout_requests').insert({
        tow_yard_id: towYardId,
        requested_by_user_id: user.id,
        amount,
        payout_method: settings.payout_method,
        notes: payoutNotes || null,
      });
      if (error) throw error;
      toast.success(`Payout request for ${formatCurrency(amount)} submitted`);
      setPayoutAmount('');
      setPayoutNotes('');
      setShowRequestForm(false);
      fetchPayoutRequests();
    } catch (err: any) {
      console.error('Payout request error:', err);
      toast.error('Failed to submit payout request');
    } finally {
      setRequestingPayout(false);
    }
  };

  const fetchSettings = async () => {
    if (!towYardId) return;
    
    setLoading(true);
    const { data, error } = await supabase
      .from('payout_settings')
      .select('*')
      .eq('tow_yard_id', towYardId)
      .maybeSingle();

    if (error) {
      console.error('Error fetching payout settings:', error);
    }

    if (data) {
      setSettings(data);
      // Store original values for masking comparison
      setOriginalAccountNumber(data.bank_account_number);
      setOriginalRoutingNumber(data.bank_routing_number);
    } else {
      // Initialize with defaults
      setSettings({
        tow_yard_id: towYardId,
        payout_method: 'bank_account',
        bank_name: null,
        bank_account_number: null,
        bank_routing_number: null,
        bank_account_holder_name: null,
        stripe_account_id: null,
        stripe_connected: false,
        paypal_email: null,
        apple_pay_merchant_id: null,
        minimum_payout_amount: 50,
        payout_frequency: 'weekly',
        is_verified: false,
      });
    }
    setLoading(false);
  };

  const handleSave = async () => {
    if (!settings || !towYardId) return;

    setSaving(true);
    try {
      if (settings.id) {
        // Update existing
        const { error } = await supabase
          .from('payout_settings')
          .update({
            payout_method: settings.payout_method,
            bank_name: settings.bank_name,
            bank_account_number: settings.bank_account_number,
            bank_routing_number: settings.bank_routing_number,
            bank_account_holder_name: settings.bank_account_holder_name,
            paypal_email: settings.paypal_email,
            apple_pay_merchant_id: settings.apple_pay_merchant_id,
            minimum_payout_amount: settings.minimum_payout_amount,
            payout_frequency: settings.payout_frequency,
          })
          .eq('id', settings.id);

        if (error) throw error;
      } else {
        // Insert new
        const { data, error } = await supabase
          .from('payout_settings')
          .insert({
            tow_yard_id: towYardId,
            payout_method: settings.payout_method,
            bank_name: settings.bank_name,
            bank_account_number: settings.bank_account_number,
            bank_routing_number: settings.bank_routing_number,
            bank_account_holder_name: settings.bank_account_holder_name,
            paypal_email: settings.paypal_email,
            apple_pay_merchant_id: settings.apple_pay_merchant_id,
            minimum_payout_amount: settings.minimum_payout_amount,
            payout_frequency: settings.payout_frequency,
          })
          .select()
          .single();

        if (error) throw error;
        setSettings(data);
      }

      toast.success('Payout settings saved successfully');
    } catch (error: any) {
      console.error('Error saving payout settings:', error);
      toast.error('Failed to save payout settings');
    } finally {
      setSaving(false);
    }
  };

  const updateField = (field: keyof PayoutSettings, value: any) => {
    if (!settings) return;
    setSettings({ ...settings, [field]: value });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!towYardId || !settings) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-muted-foreground text-center">
            Select a tow yard to manage payout settings.
          </p>
        </CardContent>
      </Card>
    );
  }

  const formatCurrency = (amount: number) =>
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);

  return (
    <div className="space-y-6">
      {/* Available Balance Card */}
      <Card className="border-primary/20 bg-primary/5">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <p className="text-sm font-medium text-muted-foreground">Available Balance</p>
              {balanceLoading ? (
                <div className="h-9 w-32 bg-muted rounded animate-pulse" />
              ) : (
                <p className="text-3xl font-bold text-foreground">{formatCurrency(balance)}</p>
              )}
              <p className="text-xs text-muted-foreground">
                Total succeeded payments for your yard
              </p>
            </div>
            <div className="flex items-center gap-3">
              <Button
                onClick={() => setShowRequestForm(!showRequestForm)}
                disabled={balance <= 0 || balanceLoading}
                size="lg"
              >
                <ArrowUpRight className="w-4 h-4 mr-2" />
                Request Payout
              </Button>
              <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center">
                <Wallet className="w-7 h-7 text-primary" />
              </div>
            </div>
          </div>

          {/* Payout Request Form */}
          {showRequestForm && (
            <div className="mt-4 pt-4 border-t border-border space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="payout_amount">Amount</Label>
                  <Input
                    id="payout_amount"
                    type="number"
                    min={1}
                    max={balance}
                    placeholder={`Up to ${formatCurrency(balance)}`}
                    value={payoutAmount}
                    onChange={(e) => setPayoutAmount(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="payout_notes">Notes (optional)</Label>
                  <Input
                    id="payout_notes"
                    placeholder="e.g. Weekly withdrawal"
                    value={payoutNotes}
                    onChange={(e) => setPayoutNotes(e.target.value)}
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Button onClick={handleRequestPayout} disabled={requestingPayout}>
                  {requestingPayout ? (
                    <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Submitting...</>
                  ) : (
                    'Submit Request'
                  )}
                </Button>
                <Button variant="outline" onClick={() => setShowRequestForm(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Wallet className="w-5 h-5" />
                Payout Settings
              </CardTitle>
              <CardDescription>
                Configure how you receive payments from vehicle releases
              </CardDescription>
            </div>
            {settings.is_verified ? (
              <Badge variant="default" className="bg-green-500">
                <CheckCircle className="w-3 h-3 mr-1" />
                Verified
              </Badge>
            ) : (
              <Badge variant="secondary">
                <AlertCircle className="w-3 h-3 mr-1" />
                Pending Verification
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Payout Method Selection */}
          <div className="space-y-3">
            <Label>Payout Method</Label>
            <RadioGroup
              value={settings.payout_method}
              onValueChange={(value) => updateField('payout_method', value)}
              className="grid grid-cols-1 md:grid-cols-2 gap-4"
            >
              {PAYOUT_METHODS.map((method) => {
                const Icon = method.icon;
                return (
                  <div key={method.value}>
                    <RadioGroupItem
                      value={method.value}
                      id={method.value}
                      className="peer sr-only"
                    />
                    <Label
                      htmlFor={method.value}
                      className="flex items-center gap-3 p-4 border-2 rounded-lg cursor-pointer transition-all peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5 hover:border-muted-foreground/50"
                    >
                      <Icon className="w-5 h-5 text-primary" />
                      <div>
                        <p className="font-medium">{method.label}</p>
                        <p className="text-xs text-muted-foreground">{method.description}</p>
                      </div>
                    </Label>
                  </div>
                );
              })}
            </RadioGroup>
          </div>

          {/* Bank Account Fields */}
          {settings.payout_method === 'bank_account' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-muted/50 rounded-lg">
              <div className="space-y-2">
                <Label htmlFor="bank_name">Bank Name</Label>
                <Input
                  id="bank_name"
                  placeholder="Chase, Bank of America, etc."
                  value={settings.bank_name || ''}
                  onChange={(e) => updateField('bank_name', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="account_holder">Account Holder Name</Label>
                <Input
                  id="account_holder"
                  placeholder="Business or personal name"
                  value={settings.bank_account_holder_name || ''}
                  onChange={(e) => updateField('bank_account_holder_name', e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="routing_number">Routing Number</Label>
                <Input
                  id="routing_number"
                  placeholder="9 digits"
                  value={editingRoutingNumber 
                    ? (settings.bank_routing_number || '') 
                    : (originalRoutingNumber ? maskRoutingNumber(originalRoutingNumber) : (settings.bank_routing_number || ''))
                  }
                  onChange={(e) => {
                    setEditingRoutingNumber(true);
                    updateField('bank_routing_number', e.target.value);
                  }}
                  onFocus={() => {
                    if (originalRoutingNumber && !editingRoutingNumber) {
                      // Clear to let user enter new value
                      updateField('bank_routing_number', '');
                      setEditingRoutingNumber(true);
                    }
                  }}
                  maxLength={9}
                />
                {originalRoutingNumber && !editingRoutingNumber && (
                  <p className="text-xs text-muted-foreground">Click to update routing number</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="account_number">Account Number</Label>
                <Input
                  id="account_number"
                  placeholder="••••••••"
                  value={editingAccountNumber 
                    ? (settings.bank_account_number || '') 
                    : (originalAccountNumber ? maskAccountNumber(originalAccountNumber) : (settings.bank_account_number || ''))
                  }
                  onChange={(e) => {
                    setEditingAccountNumber(true);
                    updateField('bank_account_number', e.target.value);
                  }}
                  onFocus={() => {
                    if (originalAccountNumber && !editingAccountNumber) {
                      // Clear to let user enter new value
                      updateField('bank_account_number', '');
                      setEditingAccountNumber(true);
                    }
                  }}
                />
                {originalAccountNumber && !editingAccountNumber && (
                  <p className="text-xs text-muted-foreground">Click to update account number</p>
                )}
              </div>
            </div>
          )}

          {/* Stripe Connect */}
          {settings.payout_method === 'stripe' && (
            <div className="p-4 bg-muted/50 rounded-lg space-y-4">
              {settings.stripe_connected || connectStatus?.isFullyOnboarded ? (
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <div>
                      <p className="font-medium">Stripe Connected</p>
                      <p className="text-sm text-muted-foreground">
                        Your account is fully onboarded. Service fees (5%) are automatically separated on each payment.
                      </p>
                    </div>
                  </div>
                  {connectStatus && (
                    <div className="flex gap-2">
                      <Badge variant="default" className="bg-green-500">Charges Enabled</Badge>
                      <Badge variant="default" className="bg-green-500">Payouts Enabled</Badge>
                    </div>
                  )}
                </div>
              ) : connectStatus?.detailsSubmitted ? (
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <Clock className="w-5 h-5 text-yellow-500" />
                    <div>
                      <p className="font-medium">Onboarding In Progress</p>
                      <p className="text-sm text-muted-foreground">
                        Your details have been submitted. Stripe is reviewing your account.
                      </p>
                    </div>
                  </div>
                  <Button variant="outline" onClick={checkConnectStatus}>
                    <Loader2 className="w-4 h-4 mr-2" />
                    Refresh Status
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    Connect your Stripe account to receive automatic payouts when vehicles are released.
                    The platform's 5% service fee will be automatically separated from each payment.
                  </p>
                  <Button onClick={handleConnectStripe} disabled={connectLoading}>
                    {connectLoading ? (
                      <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Setting up...</>
                    ) : (
                      <><ExternalLink className="w-4 h-4 mr-2" />Connect Stripe Account</>
                    )}
                  </Button>
                </div>
              )}
            </div>
          )}

          {/* PayPal */}
          {settings.payout_method === 'paypal' && (
            <div className="p-4 bg-muted/50 rounded-lg">
              <div className="space-y-2">
                <Label htmlFor="paypal_email">PayPal Email</Label>
                <Input
                  id="paypal_email"
                  type="email"
                  placeholder="your@email.com"
                  value={settings.paypal_email || ''}
                  onChange={(e) => updateField('paypal_email', e.target.value)}
                />
              </div>
            </div>
          )}

          {/* Apple Pay */}
          {settings.payout_method === 'apple_pay' && (
            <div className="p-4 bg-muted/50 rounded-lg">
              <div className="space-y-2">
                <Label htmlFor="apple_merchant">Apple Pay Merchant ID</Label>
                <Input
                  id="apple_merchant"
                  placeholder="merchant.com.yourcompany"
                  value={settings.apple_pay_merchant_id || ''}
                  onChange={(e) => updateField('apple_pay_merchant_id', e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                  You can get this from your Apple Developer account.
                </p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Payout Preferences */}
      <Card>
        <CardHeader>
          <CardTitle>Payout Preferences</CardTitle>
          <CardDescription>
            Configure when and how much you want to receive
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="frequency">Payout Frequency</Label>
              <Select
                value={settings.payout_frequency}
                onValueChange={(value) => updateField('payout_frequency', value)}
              >
                <SelectTrigger id="frequency">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PAYOUT_FREQUENCIES.map((freq) => (
                    <SelectItem key={freq.value} value={freq.value}>
                      {freq.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="minimum">Minimum Payout Amount ($)</Label>
              <Input
                id="minimum"
                type="number"
                min={1}
                value={settings.minimum_payout_amount}
                onChange={(e) => updateField('minimum_payout_amount', parseFloat(e.target.value) || 50)}
              />
              <p className="text-xs text-muted-foreground">
                Payouts will only be triggered when balance exceeds this amount.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Payout Request History */}
      {payoutRequests.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <History className="w-5 h-5" />
              Payout Requests
            </CardTitle>
            <CardDescription>Your recent withdrawal requests</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {payoutRequests.map((req) => (
                <div key={req.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-3">
                    {req.status === 'pending' && <Clock className="w-4 h-4 text-warning" />}
                    {req.status === 'approved' && <CheckCircle className="w-4 h-4 text-success" />}
                    {req.status === 'rejected' && <XCircle className="w-4 h-4 text-destructive" />}
                    {req.status === 'completed' && <CheckCircle className="w-4 h-4 text-primary" />}
                    <div>
                      <p className="font-medium">{formatCurrency(req.amount)}</p>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(req.created_at), 'MMM d, yyyy h:mm a')} · {req.payout_method.replace('_', ' ')}
                      </p>
                    </div>
                  </div>
                  <Badge variant={
                    req.status === 'pending' ? 'secondary' :
                    req.status === 'approved' ? 'default' :
                    req.status === 'rejected' ? 'destructive' : 'default'
                  }>
                    {req.status}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={saving}>
          {saving ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="w-4 h-4 mr-2" />
              Save Payout Settings
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
