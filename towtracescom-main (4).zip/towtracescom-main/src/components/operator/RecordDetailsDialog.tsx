import { format } from 'date-fns';
import { X, Car, Truck, Bike, MapPin, Calendar, DollarSign, User, FileText, Hash } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { VEHICLE_TYPES, type VehicleType } from '@/lib/feeCalculator';
import { useRecordLock } from '@/hooks/useRecordLock';
import { RecordLockIndicator } from '@/components/operator/RecordLockIndicator';

interface ClaimInfo {
  id: string;
  claim_status: string;
  pending_docs_count: number;
}

interface TowRecord {
  id: string;
  plate_number: string | null;
  vin: string | null;
  make: string | null;
  model: string | null;
  color: string | null;
  status: string;
  tow_datetime: string;
  tow_fee: number;
  daily_storage_fee: number;
  admin_fee: number;
  gate_fee: number;
  vehicle_type: string | null;
  driver_name: string | null;
  driver_user_id: string | null;
  tow_reason?: string | null;
  tow_from_address?: string | null;
  storage_start_datetime?: string | null;
  locked_by_user_id?: string | null;
  locked_by_name?: string | null;
  locked_at?: string | null;
  claim?: ClaimInfo | null;
}

interface RecordDetailsDialogProps {
  isOpen: boolean;
  onClose: () => void;
  record: TowRecord;
  onLockChange?: () => void;
}

export function RecordDetailsDialog({ isOpen, onClose, record, onLockChange }: RecordDetailsDialogProps) {
  const { lockStatus, isLoading, acquireLock, releaseLock, canEdit } = useRecordLock(
    isOpen ? record.id : null
  );

  const handleAcquireLock = async () => {
    const success = await acquireLock();
    if (success) onLockChange?.();
    return success;
  };

  const handleReleaseLock = async () => {
    const success = await releaseLock();
    if (success) onLockChange?.();
    return success;
  };

  const getVehicleTypeIcon = (type: string | null) => {
    switch (type) {
      case 'motorcycle':
        return <Bike className="w-6 h-6 text-primary" />;
      case 'truck':
      case 'commercial':
      case 'heavy_duty':
        return <Truck className="w-6 h-6 text-primary" />;
      default:
        return <Car className="w-6 h-6 text-primary" />;
    }
  };

  const getVehicleTypeLabel = (type: string | null): string => {
    if (!type) return 'Standard';
    return VEHICLE_TYPES[type as VehicleType]?.label || type;
  };

  const getStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      towed: 'bg-warning/10 text-warning border-warning/20',
      docs_pending: 'bg-info/10 text-info border-info/20',
      docs_approved: 'bg-accent/10 text-accent border-accent/20',
      paid: 'bg-success/10 text-success border-success/20',
      released: 'bg-muted text-muted-foreground border-muted',
    };

    return (
      <Badge variant="outline" className={styles[status] || styles.towed}>
        {status.replace('_', ' ')}
      </Badge>
    );
  };

  const totalFees = record.tow_fee + record.daily_storage_fee + record.admin_fee + record.gate_fee;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
              {getVehicleTypeIcon(record.vehicle_type)}
            </div>
            <div>
              <p className="text-lg font-semibold">
                {record.make || 'Unknown'} {record.model || 'Vehicle'}
              </p>
              <p className="text-sm text-muted-foreground font-normal">
                {getVehicleTypeLabel(record.vehicle_type)}
              </p>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Lock Status */}
          <div className="flex items-center justify-between flex-wrap gap-2">
            <RecordLockIndicator
              lockStatus={lockStatus}
              isLoading={isLoading}
              onAcquireLock={handleAcquireLock}
              onReleaseLock={handleReleaseLock}
              variant="badge"
            />
            {record.claim && (
              <Badge variant="outline" className="bg-info/10 text-info border-info/20">
                Claim: {record.claim.claim_status.replace('_', ' ')}
              </Badge>
            )}
          </div>

          {/* Status */}
          <div className="flex items-center gap-2">
            {getStatusBadge(record.status)}
          </div>
          {/* Vehicle Info */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <Hash className="w-3 h-3" /> Plate Number
              </p>
              <p className="font-mono font-medium">{record.plate_number || '—'}</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">VIN</p>
              <p className="font-mono text-sm">{record.vin || '—'}</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Color</p>
              <p className="font-medium">{record.color || '—'}</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <User className="w-3 h-3" /> Driver
              </p>
              <p className="font-medium">{record.driver_name || '—'}</p>
            </div>
          </div>

          <Separator />

          {/* Tow Details */}
          <div className="space-y-3">
            <h4 className="text-sm font-semibold text-muted-foreground">Tow Details</h4>
            <div className="grid gap-3">
              <div className="flex items-start gap-3">
                <Calendar className="w-4 h-4 text-muted-foreground mt-0.5" />
                <div>
                  <p className="text-xs text-muted-foreground">Tow Date & Time</p>
                  <p className="font-medium">
                    {format(new Date(record.tow_datetime), 'PPpp')}
                  </p>
                </div>
              </div>
              {record.tow_from_address && (
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-xs text-muted-foreground">Towed From</p>
                    <p className="font-medium">{record.tow_from_address}</p>
                  </div>
                </div>
              )}
              {record.tow_reason && (
                <div className="flex items-start gap-3">
                  <FileText className="w-4 h-4 text-muted-foreground mt-0.5" />
                  <div>
                    <p className="text-xs text-muted-foreground">Reason</p>
                    <p className="font-medium">{record.tow_reason}</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          <Separator />

          {/* Fees Breakdown */}
          <div className="space-y-3">
            <h4 className="text-sm font-semibold text-muted-foreground flex items-center gap-2">
              <DollarSign className="w-4 h-4" /> Fees Breakdown
            </h4>
            <div className="bg-muted/50 rounded-lg p-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span>Tow Fee</span>
                <span className="font-medium">${record.tow_fee.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Daily Storage Fee</span>
                <span className="font-medium">${record.daily_storage_fee.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Admin Fee</span>
                <span className="font-medium">${record.admin_fee.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Gate Fee</span>
                <span className="font-medium">${record.gate_fee.toFixed(2)}</span>
              </div>
              <Separator className="my-2" />
              <div className="flex justify-between font-semibold">
                <span>Total</span>
                <span className="text-primary">${totalFees.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
