import { useState } from 'react';
import { PageHeader } from '@/components/layout/PageHeader';
import { PageFooter } from '@/components/layout/PageFooter';
import { AuthModal } from '@/components/auth/AuthModal';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Globe, 
  CheckCircle, 
  MapPin, 
  Users, 
  Shield, 
  BarChart3,
  Building2,
  Phone,
  Mail,
  Send
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function CitySignup() {
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    cityName: '',
    stateName: '',
    contactName: '',
    title: '',
    email: '',
    phone: '',
    population: '',
    message: '',
  });

  const benefits = [
    { icon: Users, text: 'Improve citizen satisfaction with transparent towing processes' },
    { icon: MapPin, text: 'Centralized tracking for all municipal towing operations' },
    { icon: BarChart3, text: 'Comprehensive analytics and compliance reporting' },
    { icon: Shield, text: 'Ensure all tow operators meet city standards and regulations' },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsSubmitting(false);
    setSubmitted(true);
    toast({
      title: "Request Submitted!",
      description: "Our team will contact you within 2 business days.",
    });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <PageHeader onSignInClick={() => setShowAuthModal(true)} />

      <main className="flex-1">
        {/* Hero Section */}
        <section className="hero-gradient text-primary-foreground py-16 px-4">
          <div className="max-w-4xl mx-auto text-center space-y-6">
            <div className="inline-flex items-center gap-2 bg-primary-foreground/10 backdrop-blur-sm px-4 py-2 rounded-full text-sm">
              <Globe className="w-4 h-4" />
              Municipal Partnership Program
            </div>
            <h1 className="font-display text-4xl md:text-5xl font-bold text-balance">
              Partner with TowTrace for Your City
            </h1>
            <p className="text-xl text-primary-foreground/80 max-w-2xl mx-auto">
              Modernize your municipal towing oversight with a transparent, citizen-friendly 
              platform that ensures compliance and accountability.
            </p>
          </div>
        </section>

        {/* Benefits Section */}
        <section className="py-16 px-4 bg-muted/30">
          <div className="max-w-5xl mx-auto">
            <h2 className="font-display text-2xl font-bold text-center mb-8">
              Why Cities Choose TowTrace
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              {benefits.map((benefit, index) => (
                <div 
                  key={index}
                  className="flex items-start gap-4 bg-card p-6 rounded-xl shadow-sm"
                >
                  <div className="w-10 h-10 bg-info/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <benefit.icon className="w-5 h-5 text-info" />
                  </div>
                  <p className="text-muted-foreground">{benefit.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Form Section */}
        <section className="py-16 px-4">
          <div className="max-w-2xl mx-auto">
            <Card className="shadow-card">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-info/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Building2 className="w-8 h-8 text-info" />
                </div>
                <CardTitle className="font-display text-2xl">Request Partnership Information</CardTitle>
                <CardDescription>
                  Fill out the form below and our municipal partnerships team will contact you 
                  within 2 business days.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {submitted ? (
                  <div className="text-center py-8 space-y-4">
                    <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto">
                      <CheckCircle className="w-8 h-8 text-success" />
                    </div>
                    <h3 className="font-display text-xl font-semibold">Thank You!</h3>
                    <p className="text-muted-foreground">
                      Your partnership request has been submitted. Our team will be in touch soon.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="cityName">City Name *</Label>
                        <Input
                          id="cityName"
                          name="cityName"
                          value={formData.cityName}
                          onChange={handleChange}
                          placeholder="e.g., San Francisco"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="stateName">State/Province *</Label>
                        <Input
                          id="stateName"
                          name="stateName"
                          value={formData.stateName}
                          onChange={handleChange}
                          placeholder="e.g., California"
                          required
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="contactName">Contact Name *</Label>
                        <Input
                          id="contactName"
                          name="contactName"
                          value={formData.contactName}
                          onChange={handleChange}
                          placeholder="Full name"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="title">Title/Position *</Label>
                        <Input
                          id="title"
                          name="title"
                          value={formData.title}
                          onChange={handleChange}
                          placeholder="e.g., Transportation Director"
                          required
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="email">Email Address *</Label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                          <Input
                            id="email"
                            name="email"
                            type="email"
                            value={formData.email}
                            onChange={handleChange}
                            placeholder="you@city.gov"
                            className="pl-10"
                            required
                          />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number *</Label>
                        <div className="relative">
                          <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                          <Input
                            id="phone"
                            name="phone"
                            type="tel"
                            value={formData.phone}
                            onChange={handleChange}
                            placeholder="(555) 123-4567"
                            className="pl-10"
                            required
                          />
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="population">City Population (approximate)</Label>
                      <Input
                        id="population"
                        name="population"
                        value={formData.population}
                        onChange={handleChange}
                        placeholder="e.g., 500,000"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="message">Additional Information</Label>
                      <Textarea
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        placeholder="Tell us about your current towing oversight challenges or any specific requirements..."
                        rows={4}
                      />
                    </div>

                    <Button type="submit" size="lg" className="w-full" disabled={isSubmitting}>
                      {isSubmitting ? (
                        <>
                          <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2" />
                          Submitting...
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4 mr-2" />
                          Submit Request
                        </>
                      )}
                    </Button>
                  </form>
                )}
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      <PageFooter />

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onSuccess={() => setShowAuthModal(false)}
      />
    </div>
  );
}
