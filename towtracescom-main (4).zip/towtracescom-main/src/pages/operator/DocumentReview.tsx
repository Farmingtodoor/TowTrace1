import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, FileText, Check, X, Loader2, ExternalLink, AlertCircle, ChevronDown, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PageHeader } from '@/components/layout/PageHeader';
import { PageFooter } from '@/components/layout/PageFooter';
import { AuthModal } from '@/components/auth/AuthModal';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface Document {
  id: string;
  doc_type: string;
  file_url: string;
  file_name: string | null;
  status: 'pending' | 'approved' | 'rejected';
  rejection_reason: string | null;
  created_at: string;
}

interface ClaimWithDocuments {
  id: string;
  claim_status: string;
  created_at: string;
  tow_record: {
    id: string;
    plate_number: string | null;
    vin: string | null;
    make: string | null;
    model: string | null;
    tow_datetime: string;
  };
  documents: Document[];
}

interface TowYard {
  id: string;
  name: string;
}

const DOC_TYPE_LABELS: Record<string, string> = {
  gov_id: 'Government ID',
  registration: 'Vehicle Registration',
  title: 'Vehicle Title',
  insurance: 'Proof of Insurance',
  authorization: 'Authorization Letter',
};

export default function DocumentReview() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [claims, setClaims] = useState<ClaimWithDocuments[]>([]);
  const [towYards, setTowYards] = useState<TowYard[]>([]);
  const [selectedYard, setSelectedYard] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [expandedClaims, setExpandedClaims] = useState<Set<string>>(new Set());
  
  // Rejection dialog state
  const [rejectingDoc, setRejectingDoc] = useState<Document | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [processing, setProcessing] = useState(false);

  // Check if user is operator
  useEffect(() => {
    if (!authLoading && !user) {
      setShowAuthModal(true);
    }
  }, [authLoading, user]);

  // Fetch tow yards
  useEffect(() => {
    if (!user) return;

    const fetchTowYards = async () => {
      const { data: userRoles } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id);

      const isAdmin = userRoles?.some((r) => r.role === 'admin');

      if (isAdmin) {
        const { data } = await supabase.from('tow_yards').select('id, name');
        setTowYards(data || []);
        if (data && data.length > 0) {
          setSelectedYard(data[0].id);
        }
      } else {
        const { data } = await supabase
          .from('tow_yard_operators')
          .select('tow_yard_id, tow_yards(id, name)')
          .eq('operator_user_id', user.id);

        if (data && data.length > 0) {
          const yards = data
            .map((d) => d.tow_yards as unknown as TowYard)
            .filter(Boolean);
          setTowYards(yards);
          if (yards.length > 0) {
            setSelectedYard(yards[0].id);
          }
        }
      }
    };

    fetchTowYards();
  }, [user]);

  // Fetch claims with pending documents
  useEffect(() => {
    if (!selectedYard) {
      setLoading(false);
      return;
    }

    const fetchClaims = async () => {
      setLoading(true);

      const { data, error } = await supabase
        .from('claims')
        .select(`
          id,
          claim_status,
          created_at,
          tow_record:tow_records (
            id,
            plate_number,
            vin,
            make,
            model,
            tow_datetime,
            tow_yard_id
          ),
          documents (
            id,
            doc_type,
            file_url,
            file_name,
            status,
            rejection_reason,
            created_at
          )
        `)
        .in('claim_status', ['docs_submitted', 'started'])
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching claims:', error);
        toast.error('Failed to load claims');
      } else {
        // Filter claims that belong to the selected yard and have pending docs
        const filteredClaims = (data || [])
          .filter((claim: any) => {
            const towRecord = claim.tow_record;
            return towRecord && towRecord.tow_yard_id === selectedYard;
          })
          .filter((claim: any) => {
            // Only show claims with at least one pending document
            return claim.documents?.some((d: any) => d.status === 'pending');
          })
          .map((claim: any) => ({
            ...claim,
            documents: claim.documents || [],
          })) as ClaimWithDocuments[];

        setClaims(filteredClaims);
        
        // Auto-expand first claim
        if (filteredClaims.length > 0) {
          setExpandedClaims(new Set([filteredClaims[0].id]));
        }
      }

      setLoading(false);
    };

    fetchClaims();
  }, [selectedYard]);

  const toggleClaim = (claimId: string) => {
    const newExpanded = new Set(expandedClaims);
    if (newExpanded.has(claimId)) {
      newExpanded.delete(claimId);
    } else {
      newExpanded.add(claimId);
    }
    setExpandedClaims(newExpanded);
  };

  const handleApprove = async (doc: Document, claimId: string) => {
    setProcessing(true);

    const { error } = await supabase
      .from('documents')
      .update({ 
        status: 'approved',
        reviewer_user_id: user?.id,
        rejection_reason: null,
      })
      .eq('id', doc.id);

    if (error) {
      console.error('Error approving document:', error);
      toast.error('Failed to approve document');
    } else {
      toast.success('Document approved');
      
      // Update local state
      setClaims((prev) =>
        prev.map((claim) =>
          claim.id === claimId
            ? {
                ...claim,
                documents: claim.documents.map((d) =>
                  d.id === doc.id ? { ...d, status: 'approved' as const } : d
                ),
              }
            : claim
        )
      );

      // Check if all docs are now approved
      await checkAndUpdateClaimStatus(claimId);
    }

    setProcessing(false);
  };

  const handleReject = async () => {
    if (!rejectingDoc || !rejectionReason.trim()) {
      toast.error('Please provide a rejection reason');
      return;
    }

    setProcessing(true);

    const { error } = await supabase
      .from('documents')
      .update({ 
        status: 'rejected',
        rejection_reason: rejectionReason,
        reviewer_user_id: user?.id,
      })
      .eq('id', rejectingDoc.id);

    if (error) {
      console.error('Error rejecting document:', error);
      toast.error('Failed to reject document');
    } else {
      toast.success('Document rejected');
      
      // Find which claim this document belongs to
      const claim = claims.find((c) => c.documents.some((d) => d.id === rejectingDoc.id));
      
      if (claim) {
        // Update local state
        setClaims((prev) =>
          prev.map((c) =>
            c.id === claim.id
              ? {
                  ...c,
                  documents: c.documents.map((d) =>
                    d.id === rejectingDoc.id 
                      ? { ...d, status: 'rejected' as const, rejection_reason: rejectionReason } 
                      : d
                  ),
                }
              : c
          )
        );

        // Update claim status back to started so user can re-upload
        await supabase
          .from('claims')
          .update({ claim_status: 'started' })
          .eq('id', claim.id);
      }
    }

    setRejectingDoc(null);
    setRejectionReason('');
    setProcessing(false);
  };

  const checkAndUpdateClaimStatus = async (claimId: string) => {
    const claim = claims.find((c) => c.id === claimId);
    if (!claim) return;

    // Get fresh document statuses
    const { data: docs } = await supabase
      .from('documents')
      .select('status')
      .eq('claim_id', claimId);

    const allApproved = docs?.every((d) => d.status === 'approved');
    const requiredDocTypes = ['gov_id', 'registration', 'insurance'];

    // Check if we have all required docs approved
    const { data: allDocs } = await supabase
      .from('documents')
      .select('doc_type, status')
      .eq('claim_id', claimId);

    const hasAllRequired = requiredDocTypes.every((type) =>
      allDocs?.some((d) => d.doc_type === type && d.status === 'approved')
    );

    if (hasAllRequired && allApproved) {
      await supabase
        .from('claims')
        .update({ claim_status: 'docs_approved' })
        .eq('id', claimId);

      toast.success('All documents approved! Claim moved to payment stage.');
      
      // Remove claim from list
      setClaims((prev) => prev.filter((c) => c.id !== claimId));
    }
  };

  const getDocStatusBadge = (status: string) => {
    const styles: Record<string, string> = {
      pending: 'bg-warning/10 text-warning',
      approved: 'bg-success/10 text-success',
      rejected: 'bg-destructive/10 text-destructive',
    };

    return (
      <span className={`text-xs px-2 py-1 rounded-full ${styles[status] || styles.pending}`}>
        {status}
      </span>
    );
  };

  const pendingDocsCount = claims.reduce(
    (acc, claim) => acc + claim.documents.filter((d) => d.status === 'pending').length,
    0
  );

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-pulse text-muted-foreground">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <PageHeader onSignInClick={() => setShowAuthModal(true)} />

      <main className="flex-1 px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Back Button */}
          <Link
            to="/operator"
            className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </Link>

          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="font-display text-2xl font-bold">Document Review</h1>
              <p className="text-muted-foreground">
                Review and approve customer documents for vehicle claims
              </p>
            </div>
            {pendingDocsCount > 0 && (
              <span className="inline-flex items-center gap-1 text-sm px-3 py-1.5 rounded-full bg-warning/10 text-warning">
                <AlertCircle className="w-4 h-4" />
                {pendingDocsCount} pending
              </span>
            )}
          </div>

          {/* Yard Selector */}
          {towYards.length > 1 && (
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Viewing:</span>
              <select
                value={selectedYard}
                onChange={(e) => setSelectedYard(e.target.value)}
                className="bg-card border border-border rounded-lg px-3 py-1.5 text-sm"
              >
                {towYards.map((yard) => (
                  <option key={yard.id} value={yard.id}>
                    {yard.name}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Claims List */}
          {loading ? (
            <div className="bg-card rounded-xl p-8 text-center">
              <Loader2 className="w-8 h-8 animate-spin mx-auto text-muted-foreground" />
              <p className="text-muted-foreground mt-2">Loading claims...</p>
            </div>
          ) : claims.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="font-semibold text-lg">No Documents to Review</p>
                <p className="text-muted-foreground">
                  All submitted documents have been reviewed.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {claims.map((claim) => {
                const isExpanded = expandedClaims.has(claim.id);
                const pendingDocs = claim.documents.filter((d) => d.status === 'pending');

                return (
                  <Card key={claim.id} className="overflow-hidden">
                    <CardHeader 
                      className="cursor-pointer hover:bg-muted/50 transition-colors"
                      onClick={() => toggleClaim(claim.id)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {isExpanded ? (
                            <ChevronDown className="w-5 h-5 text-muted-foreground" />
                          ) : (
                            <ChevronRight className="w-5 h-5 text-muted-foreground" />
                          )}
                          <div>
                            <CardTitle className="text-lg">
                              {claim.tow_record.make} {claim.tow_record.model}
                            </CardTitle>
                            <p className="text-sm text-muted-foreground">
                              {claim.tow_record.plate_number || claim.tow_record.vin} • 
                              Towed {new Date(claim.tow_record.tow_datetime).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <span className="inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full bg-warning/10 text-warning">
                          {pendingDocs.length} pending
                        </span>
                      </div>
                    </CardHeader>

                    {isExpanded && (
                      <CardContent className="border-t border-border pt-4">
                        <div className="space-y-4">
                          {claim.documents.map((doc) => (
                            <div
                              key={doc.id}
                              className="flex items-start justify-between gap-4 p-4 bg-muted/50 rounded-lg"
                            >
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                  <FileText className="w-4 h-4 text-accent" />
                                  <span className="font-medium">
                                    {DOC_TYPE_LABELS[doc.doc_type] || doc.doc_type}
                                  </span>
                                  {getDocStatusBadge(doc.status)}
                                </div>
                                <p className="text-sm text-muted-foreground">
                                  {doc.file_name || 'Uploaded document'}
                                </p>
                                {doc.rejection_reason && (
                                  <p className="text-sm text-destructive mt-1">
                                    Rejection reason: {doc.rejection_reason}
                                  </p>
                                )}
                              </div>

                              <div className="flex items-center gap-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  asChild
                                >
                                  <a 
                                    href={doc.file_url} 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                  >
                                    <ExternalLink className="w-4 h-4 mr-1" />
                                    View
                                  </a>
                                </Button>

                                {doc.status === 'pending' && (
                                  <>
                                    <Button
                                      variant="default"
                                      size="sm"
                                      onClick={() => handleApprove(doc, claim.id)}
                                      disabled={processing}
                                    >
                                      <Check className="w-4 h-4 mr-1" />
                                      Approve
                                    </Button>
                                    <Button
                                      variant="destructive"
                                      size="sm"
                                      onClick={() => setRejectingDoc(doc)}
                                      disabled={processing}
                                    >
                                      <X className="w-4 h-4 mr-1" />
                                      Reject
                                    </Button>
                                  </>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    )}
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </main>

      <PageFooter />

      {/* Rejection Dialog */}
      <Dialog open={!!rejectingDoc} onOpenChange={() => setRejectingDoc(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Document</DialogTitle>
            <DialogDescription>
              Please provide a reason for rejecting this document. The customer will see this
              message and can re-upload a new document.
            </DialogDescription>
          </DialogHeader>

          <Textarea
            placeholder="e.g., Document is expired, image is blurry, name doesn't match..."
            value={rejectionReason}
            onChange={(e) => setRejectionReason(e.target.value)}
            rows={3}
          />

          <DialogFooter>
            <Button variant="outline" onClick={() => setRejectingDoc(null)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleReject}
              disabled={processing || !rejectionReason.trim()}
            >
              {processing ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : (
                <X className="w-4 h-4 mr-2" />
              )}
              Reject Document
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => {
          setShowAuthModal(false);
          if (!user) navigate('/');
        }}
        onSuccess={() => setShowAuthModal(false)}
      />
    </div>
  );
}
