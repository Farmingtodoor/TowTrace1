import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  AlertTriangle, 
  ArrowLeft, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Eye,
  MessageSquare,
  Image as ImageIcon,
  Loader2,
  RefreshCw,
  FileQuestion,
  Send
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';
import { format } from 'date-fns';

type DisputeStatus = 'open' | 'under_review' | 'resolved' | 'rejected';
type DisputeType = 'vehicle_damage' | 'property_damage' | 'missing_items' | 'overcharge' | 'other';

interface Dispute {
  id: string;
  claim_id: string;
  tow_record_id: string;
  consumer_user_id: string;
  tow_yard_id: string;
  dispute_type: DisputeType;
  status: DisputeStatus;
  description: string;
  evidence_urls: string[];
  resolution_notes: string | null;
  resolved_by_user_id: string | null;
  evidence_requested: boolean | null;
  evidence_request_notes: string | null;
  evidence_requested_at: string | null;
  evidence_submitted_at: string | null;
  created_at: string;
  updated_at: string;
  tow_records?: {
    plate_number: string | null;
    vin: string | null;
    make: string | null;
    model: string | null;
    color: string | null;
  };
  profiles?: {
    full_name: string | null;
    email: string | null;
    phone: string | null;
  };
}

const statusConfig: Record<DisputeStatus, { label: string; color: string; icon: React.ComponentType<any> }> = {
  open: { label: 'Open', color: 'bg-warning/10 text-warning border-warning/20', icon: Clock },
  under_review: { label: 'Under Review', color: 'bg-info/10 text-info border-info/20', icon: Eye },
  resolved: { label: 'Resolved', color: 'bg-success/10 text-success border-success/20', icon: CheckCircle2 },
  rejected: { label: 'Rejected', color: 'bg-destructive/10 text-destructive border-destructive/20', icon: XCircle },
};

const disputeTypeLabels: Record<DisputeType, string> = {
  vehicle_damage: 'Vehicle Damage',
  property_damage: 'Property Damage',
  missing_items: 'Missing Items',
  overcharge: 'Overcharge',
  other: 'Other',
};

export default function DisputeResolution() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [disputes, setDisputes] = useState<Dispute[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDispute, setSelectedDispute] = useState<Dispute | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [resolveOpen, setResolveOpen] = useState(false);
  const [evidenceRequestOpen, setEvidenceRequestOpen] = useState(false);
  const [evidenceRequestNotes, setEvidenceRequestNotes] = useState('');
  const [resolutionNotes, setResolutionNotes] = useState('');
  const [newStatus, setNewStatus] = useState<DisputeStatus>('resolved');
  const [updating, setUpdating] = useState(false);
  const [filter, setFilter] = useState<DisputeStatus | 'all'>('all');

  const fetchDisputes = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      let query = supabase
        .from('disputes')
        .select(`
          *,
          tow_records (
            plate_number,
            vin,
            make,
            model,
            color
          )
        `)
        .order('created_at', { ascending: false });

      if (filter !== 'all') {
        query = query.eq('status', filter);
      }

      const { data, error } = await query;

      if (error) throw error;

      // Fetch consumer profiles separately
      if (data && data.length > 0) {
        const consumerIds = [...new Set(data.map(d => d.consumer_user_id))];
        const { data: profiles } = await supabase
          .from('profiles')
          .select('user_id, full_name, email, phone')
          .in('user_id', consumerIds);

        const profileMap = new Map(profiles?.map(p => [p.user_id, p]) || []);
        
        const enrichedData = data.map(dispute => ({
          ...dispute,
          profiles: profileMap.get(dispute.consumer_user_id) || null,
        }));

        setDisputes(enrichedData as Dispute[]);
      } else {
        setDisputes([]);
      }
    } catch (error: any) {
      console.error('Error fetching disputes:', error);
      toast.error('Failed to load disputes');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDisputes();
  }, [user, filter]);

  const handleViewDetails = (dispute: Dispute) => {
    setSelectedDispute(dispute);
    setDetailsOpen(true);
  };

  const handleOpenResolve = (dispute: Dispute) => {
    setSelectedDispute(dispute);
    setResolutionNotes(dispute.resolution_notes || '');
    setNewStatus(dispute.status === 'open' ? 'under_review' : 'resolved');
    setResolveOpen(true);
  };

  const handleOpenEvidenceRequest = (dispute: Dispute) => {
    setSelectedDispute(dispute);
    setEvidenceRequestNotes(dispute.evidence_request_notes || '');
    setEvidenceRequestOpen(true);
  };

  const handleRequestEvidence = async () => {
    if (!selectedDispute || !user) return;

    setUpdating(true);
    try {
      const { error } = await supabase
        .from('disputes')
        .update({
          evidence_requested: true,
          evidence_request_notes: evidenceRequestNotes,
          evidence_requested_at: new Date().toISOString(),
          status: 'under_review' as DisputeStatus,
        })
        .eq('id', selectedDispute.id);

      if (error) throw error;

      // Send email notification to customer
      if (selectedDispute.profiles?.email) {
        const vehicleInfo = getVehicleInfo(selectedDispute);
        const disputeUrl = `${window.location.origin}/my-disputes`;
        
        try {
          await supabase.functions.invoke('send-notification', {
            body: {
              type: 'evidence_requested',
              to: selectedDispute.profiles.email,
              name: selectedDispute.profiles.full_name || 'Valued Customer',
              data: {
                disputeType: disputeTypeLabels[selectedDispute.dispute_type],
                vehicleInfo,
                evidenceNotes: evidenceRequestNotes,
                disputeUrl,
              },
            },
          });
        } catch (emailError) {
          console.error('Failed to send email notification:', emailError);
          // Don't fail the whole operation if email fails
        }
      }

      toast.success('Evidence request sent to customer');
      setEvidenceRequestOpen(false);
      setEvidenceRequestNotes('');
      fetchDisputes();
    } catch (error: any) {
      console.error('Error requesting evidence:', error);
      toast.error('Failed to request evidence');
    } finally {
      setUpdating(false);
    }
  };

  const handleUpdateStatus = async () => {
    if (!selectedDispute || !user) return;

    setUpdating(true);
    try {
      const { error } = await supabase
        .from('disputes')
        .update({
          status: newStatus,
          resolution_notes: resolutionNotes,
          resolved_by_user_id: newStatus === 'resolved' || newStatus === 'rejected' ? user.id : null,
        })
        .eq('id', selectedDispute.id);

      if (error) throw error;

      toast.success('Dispute updated successfully');
      setResolveOpen(false);
      fetchDisputes();
    } catch (error: any) {
      console.error('Error updating dispute:', error);
      toast.error('Failed to update dispute');
    } finally {
      setUpdating(false);
    }
  };

  const getVehicleInfo = (dispute: Dispute) => {
    const record = dispute.tow_records;
    if (!record) return 'N/A';
    
    const parts = [
      record.color,
      record.make,
      record.model,
    ].filter(Boolean);
    
    return parts.length > 0 ? parts.join(' ') : (record.plate_number || record.vin || 'N/A');
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container max-w-6xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="icon" onClick={() => navigate('/operator')}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex-1">
            <h1 className="font-display text-2xl font-bold flex items-center gap-2">
              <AlertTriangle className="h-6 w-6 text-warning" />
              Dispute Resolution
            </h1>
            <p className="text-muted-foreground">
              Review and resolve customer disputes
            </p>
          </div>
          <Button variant="outline" size="icon" onClick={fetchDisputes}>
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="py-4">
            <div className="flex items-center gap-4">
              <span className="text-sm font-medium">Filter by status:</span>
              <div className="flex gap-2 flex-wrap">
                <Button
                  variant={filter === 'all' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setFilter('all')}
                >
                  All
                </Button>
                {Object.entries(statusConfig).map(([key, config]) => {
                  const Icon = config.icon;
                  return (
                    <Button
                      key={key}
                      variant={filter === key ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setFilter(key as DisputeStatus)}
                      className="gap-1"
                    >
                      <Icon className="h-3 w-3" />
                      {config.label}
                    </Button>
                  );
                })}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Disputes Table */}
        <Card>
          <CardHeader>
            <CardTitle>Disputes</CardTitle>
            <CardDescription>
              {disputes.length} dispute{disputes.length !== 1 ? 's' : ''} found
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : disputes.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <AlertTriangle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No disputes found</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Vehicle</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {disputes.map((dispute) => {
                      const StatusIcon = statusConfig[dispute.status].icon;
                      return (
                        <TableRow key={dispute.id}>
                          <TableCell className="whitespace-nowrap">
                            {format(new Date(dispute.created_at), 'MMM d, yyyy')}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">
                              {disputeTypeLabels[dispute.dispute_type]}
                            </Badge>
                          </TableCell>
                          <TableCell className="max-w-[200px] truncate">
                            {getVehicleInfo(dispute)}
                          </TableCell>
                          <TableCell>
                            {dispute.profiles?.full_name || dispute.profiles?.email || 'Unknown'}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Badge className={statusConfig[dispute.status].color}>
                                <StatusIcon className="h-3 w-3 mr-1" />
                                {statusConfig[dispute.status].label}
                              </Badge>
                              {dispute.evidence_requested && !dispute.evidence_submitted_at && (
                                <Badge variant="outline" className="text-warning border-warning/30">
                                  <FileQuestion className="h-3 w-3 mr-1" />
                                  Awaiting Evidence
                                </Badge>
                              )}
                              {dispute.evidence_submitted_at && dispute.evidence_requested_at && 
                               new Date(dispute.evidence_submitted_at) > new Date(dispute.evidence_requested_at) && (
                                <Badge variant="outline" className="text-success border-success/30">
                                  <CheckCircle2 className="h-3 w-3 mr-1" />
                                  New Evidence
                                </Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleViewDetails(dispute)}
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                              {dispute.status !== 'resolved' && dispute.status !== 'rejected' && (
                                <>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleOpenEvidenceRequest(dispute)}
                                    title="Request additional evidence"
                                  >
                                    <FileQuestion className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => handleOpenResolve(dispute)}
                                  >
                                    <MessageSquare className="h-4 w-4 mr-1" />
                                    Respond
                                  </Button>
                                </>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Details Dialog */}
        <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
          <DialogContent className="sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>Dispute Details</DialogTitle>
              <DialogDescription>
                Filed on {selectedDispute && format(new Date(selectedDispute.created_at), 'MMMM d, yyyy')}
              </DialogDescription>
            </DialogHeader>

            {selectedDispute && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Type</p>
                    <p className="font-medium">{disputeTypeLabels[selectedDispute.dispute_type]}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Status</p>
                    <Badge className={statusConfig[selectedDispute.status].color}>
                      {statusConfig[selectedDispute.status].label}
                    </Badge>
                  </div>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground mb-1">Vehicle</p>
                  <p className="font-medium">{getVehicleInfo(selectedDispute)}</p>
                  {selectedDispute.tow_records?.plate_number && (
                    <p className="text-sm text-muted-foreground">
                      Plate: {selectedDispute.tow_records.plate_number}
                    </p>
                  )}
                </div>

                <div>
                  <p className="text-sm text-muted-foreground mb-1">Customer</p>
                  <p className="font-medium">{selectedDispute.profiles?.full_name || 'Unknown'}</p>
                  {selectedDispute.profiles?.email && (
                    <p className="text-sm text-muted-foreground">{selectedDispute.profiles.email}</p>
                  )}
                  {selectedDispute.profiles?.phone && (
                    <p className="text-sm text-muted-foreground">{selectedDispute.profiles.phone}</p>
                  )}
                </div>

                <div>
                  <p className="text-sm text-muted-foreground mb-1">Description</p>
                  <p className="text-sm bg-muted p-3 rounded-lg">{selectedDispute.description}</p>
                </div>

                {selectedDispute.evidence_urls && selectedDispute.evidence_urls.length > 0 && (
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Evidence ({selectedDispute.evidence_urls.length} files)</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedDispute.evidence_urls.map((url, index) => (
                        <a
                          key={index}
                          href={url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-1 px-3 py-1.5 bg-muted rounded text-sm hover:bg-muted/80 transition-colors"
                        >
                          <ImageIcon className="h-4 w-4" />
                          File {index + 1}
                        </a>
                      ))}
                    </div>
                  </div>
                )}

                {/* Evidence Request Info */}
                {selectedDispute.evidence_requested && (
                  <div className="p-3 bg-warning/10 border border-warning/20 rounded-lg">
                    <p className="text-sm font-medium text-warning mb-1">Evidence Requested</p>
                    <p className="text-sm text-muted-foreground">
                      {selectedDispute.evidence_request_notes || 'Additional evidence requested from customer.'}
                    </p>
                    <p className="text-xs text-muted-foreground mt-2">
                      Requested on {format(new Date(selectedDispute.evidence_requested_at!), 'MMM d, yyyy')}
                      {selectedDispute.evidence_submitted_at && (
                        <> • Submitted on {format(new Date(selectedDispute.evidence_submitted_at), 'MMM d, yyyy')}</>
                      )}
                    </p>
                  </div>
                )}

                {selectedDispute.resolution_notes && (
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Resolution Notes</p>
                    <p className="text-sm bg-success/10 border border-success/20 p-3 rounded-lg">
                      {selectedDispute.resolution_notes}
                    </p>
                  </div>
                )}
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Resolve Dialog */}
        <Dialog open={resolveOpen} onOpenChange={setResolveOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Update Dispute Status</DialogTitle>
              <DialogDescription>
                Update the status and add resolution notes
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">New Status</label>
                <Select value={newStatus} onValueChange={(v) => setNewStatus(v as DisputeStatus)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="under_review">Under Review</SelectItem>
                    <SelectItem value="resolved">Resolved</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Resolution Notes</label>
                <Textarea
                  value={resolutionNotes}
                  onChange={(e) => setResolutionNotes(e.target.value)}
                  placeholder="Add notes about the resolution or reason for rejection..."
                  className="min-h-[100px]"
                />
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setResolveOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleUpdateStatus} disabled={updating}>
                {updating ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Updating...
                  </>
                ) : (
                  'Update Status'
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Evidence Request Dialog */}
        <Dialog open={evidenceRequestOpen} onOpenChange={setEvidenceRequestOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <FileQuestion className="h-5 w-5 text-warning" />
                Request Additional Evidence
              </DialogTitle>
              <DialogDescription>
                Ask the customer to provide more evidence to support their dispute.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">What evidence do you need?</label>
                <Textarea
                  value={evidenceRequestNotes}
                  onChange={(e) => setEvidenceRequestNotes(e.target.value)}
                  placeholder="Please provide photos of the damage from multiple angles, including close-up shots..."
                  className="min-h-[120px]"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Be specific about what you need to help resolve the dispute.
                </p>
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setEvidenceRequestOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleRequestEvidence} 
                disabled={updating || !evidenceRequestNotes.trim()}
                className="gap-1"
              >
                {updating ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Sending...
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4" />
                    Send Request
                  </>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
