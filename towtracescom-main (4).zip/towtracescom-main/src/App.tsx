import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ScrollToTop, PageTransition } from "@/components/ScrollToTop";
import { AuthProvider } from "@/hooks/useAuth";
import { ThemeProvider } from "@/components/ThemeProvider";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import { JackChatbot } from "@/components/chat/JackChatbot";
import { CookieConsent } from "@/components/CookieConsent";
import { BackToTop } from "@/components/BackToTop";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import MyClaims from "./pages/MyClaims";
import ClaimFlow from "./pages/ClaimFlow";
import OperatorDashboard from "./pages/operator/OperatorDashboard";
import EmployeeManagement from "./pages/operator/EmployeeManagement";
import DocumentReview from "./pages/operator/DocumentReview";
import DisputeResolution from "./pages/operator/DisputeResolution";
import AdminDashboard from "./pages/admin/AdminDashboard";
import CompanySignup from "./pages/signup/CompanySignup";
import ResetPassword from "./pages/ResetPassword";
import About from "./pages/About";
import AccountSettings from "./pages/AccountSettings";
import PaymentHistory from "./pages/PaymentHistory";
import Terms from "./pages/Terms";
import Privacy from "./pages/Privacy";
import Join from "./pages/Join";
import CitySignup from "./pages/signup/CitySignup";
import MyDisputes from "./pages/MyDisputes";
import SetupAccount from "./pages/SetupAccount";

const queryClient = new QueryClient();

const App = () => (
  <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <ScrollToTop />
            <PageTransition>
              <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/my-claims" element={<MyClaims />} />
                <Route path="/claim/:recordId" element={<ClaimFlow />} />
                <Route path="/payments" element={<PaymentHistory />} />
                <Route
                  path="/operator"
                  element={
                    <ProtectedRoute requiredRole="operator">
                      <OperatorDashboard />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/operator/employees"
                  element={
                    <ProtectedRoute requiredRole="operator">
                      <EmployeeManagement />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/operator/documents"
                  element={
                    <ProtectedRoute requiredRole="operator">
                      <DocumentReview />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/operator/disputes"
                  element={
                    <ProtectedRoute requiredRole="operator">
                      <DisputeResolution />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/admin"
                  element={
                    <ProtectedRoute requiredRole="admin">
                      <AdminDashboard />
                    </ProtectedRoute>
                  }
                />
                <Route path="/signup/company" element={<CompanySignup />} />
                <Route path="/reset-password" element={<ResetPassword />} />
                <Route path="/about" element={<About />} />
                <Route path="/account" element={<AccountSettings />} />
                <Route path="/terms" element={<Terms />} />
                <Route path="/privacy" element={<Privacy />} />
                <Route path="/join" element={<Join />} />
                <Route path="/signup/city" element={<CitySignup />} />
                <Route path="/my-disputes" element={<MyDisputes />} />
                <Route path="/setup-account" element={<SetupAccount />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </PageTransition>
            <JackChatbot />
            <BackToTop />
            <CookieConsent />
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  </ThemeProvider>
);

export default App;
