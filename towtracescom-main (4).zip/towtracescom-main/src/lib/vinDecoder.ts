// NHTSA Vehicle API - Free, no API key required
// Documentation: https://vpic.nhtsa.dot.gov/api/

interface NHTSAResult {
  Variable: string;
  Value: string | null;
}

interface NHTSAResponse {
  Results: NHTSAResult[];
}

export interface DecodedVehicle {
  make: string | null;
  model: string | null;
  year: string | null;
  bodyClass: string | null;
  vehicleType: string | null;
  trimLevel: string | null;
  driveType: string | null;
  fuelType: string | null;
  engineCylinders: string | null;
  displacementL: string | null;
}

const VARIABLE_MAP: Record<string, keyof DecodedVehicle> = {
  'Make': 'make',
  'Model': 'model',
  'Model Year': 'year',
  'Body Class': 'bodyClass',
  'Vehicle Type': 'vehicleType',
  'Trim': 'trimLevel',
  'Drive Type': 'driveType',
  'Fuel Type - Primary': 'fuelType',
  'Engine Number of Cylinders': 'engineCylinders',
  'Displacement (L)': 'displacementL',
};

export async function decodeVIN(vin: string): Promise<DecodedVehicle | null> {
  if (!vin || vin.length !== 17) {
    return null;
  }

  try {
    const response = await fetch(
      `https://vpic.nhtsa.dot.gov/api/vehicles/decodevin/${vin}?format=json`
    );

    if (!response.ok) {
      console.error('NHTSA API error:', response.status);
      return null;
    }

    const data: NHTSAResponse = await response.json();
    
    const decoded: DecodedVehicle = {
      make: null,
      model: null,
      year: null,
      bodyClass: null,
      vehicleType: null,
      trimLevel: null,
      driveType: null,
      fuelType: null,
      engineCylinders: null,
      displacementL: null,
    };

    for (const result of data.Results) {
      const key = VARIABLE_MAP[result.Variable];
      if (key && result.Value && result.Value.trim() !== '') {
        decoded[key] = result.Value;
      }
    }

    // Check if we got meaningful data
    if (!decoded.make && !decoded.model) {
      return null;
    }

    return decoded;
  } catch (error) {
    console.error('VIN decode error:', error);
    return null;
  }
}

// Map NHTSA body class to our vehicle types
export function mapBodyClassToVehicleType(bodyClass: string | null): string {
  if (!bodyClass) return 'standard';
  
  const lower = bodyClass.toLowerCase();
  
  if (lower.includes('motorcycle')) return 'motorcycle';
  if (lower.includes('truck') && lower.includes('pickup')) return 'truck';
  if (lower.includes('truck') && !lower.includes('pickup')) return 'commercial';
  if (lower.includes('van') || lower.includes('minivan')) return 'van';
  if (lower.includes('suv') || lower.includes('sport utility')) return 'suv';
  if (lower.includes('crossover')) return 'suv';
  if (lower.includes('bus') || lower.includes('motorhome') || lower.includes('rv')) return 'heavy_duty';
  if (lower.includes('commercial') || lower.includes('cargo')) return 'commercial';
  
  return 'standard';
}
