import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface PaymentResult {
  url: string;
  serviceFee: number;
  grandTotal: number;
}

export const SERVICE_FEE_PERCENTAGE = 0.10; // 10%

export const calculateServiceFee = (totalDue: number): number => {
  return Math.round(totalDue * SERVICE_FEE_PERCENTAGE * 100) / 100;
};

export const calculateGrandTotal = (totalDue: number): number => {
  return totalDue + calculateServiceFee(totalDue);
};

export const createTowPayment = async (
  claimId: string,
  towRecordId: string,
  totalDue: number
): Promise<PaymentResult | null> => {
  try {
    const { data, error } = await supabase.functions.invoke('create-tow-payment', {
      body: { claimId, towRecordId, totalDue },
    });

    if (error) {
      toast.error('Failed to create payment session');
      console.error('Payment error:', error);
      return null;
    }

    return data as PaymentResult;
  } catch (err) {
    toast.error('An error occurred while processing payment');
    console.error('Payment error:', err);
    return null;
  }
};

export type SubscriptionPlan = 'basic' | 'pro';

export interface SubscriptionStatus {
  subscribed: boolean;
  plan: SubscriptionPlan | null;
  subscription_end: string | null;
}

export const SUBSCRIPTION_TIERS = {
  basic: {
    name: 'Basic Plan',
    price: 49.99,
    features: [
      'Up to 100 tow records/month',
      'Basic reporting',
      'Email support',
      'Single yard management',
    ],
  },
  pro: {
    name: 'Pro Plan',
    price: 99.99,
    features: [
      'Unlimited tow records',
      'Advanced analytics',
      'Priority support',
      'Multi-yard management',
      'API access',
      'Custom branding',
    ],
  },
};

export const createSubscription = async (plan: SubscriptionPlan): Promise<string | null> => {
  try {
    const { data, error } = await supabase.functions.invoke('create-subscription', {
      body: { plan },
    });

    if (error) {
      toast.error('Failed to create subscription session');
      console.error('Subscription error:', error);
      return null;
    }

    return data.url;
  } catch (err) {
    toast.error('An error occurred while creating subscription');
    console.error('Subscription error:', err);
    return null;
  }
};

export const checkSubscription = async (): Promise<SubscriptionStatus | null> => {
  try {
    const { data, error } = await supabase.functions.invoke('check-subscription');

    if (error) {
      console.error('Check subscription error:', error);
      return null;
    }

    return data as SubscriptionStatus;
  } catch (err) {
    console.error('Check subscription error:', err);
    return null;
  }
};

export const openCustomerPortal = async (): Promise<void> => {
  try {
    const { data, error } = await supabase.functions.invoke('customer-portal');

    if (error) {
      toast.error('Failed to open subscription management');
      console.error('Portal error:', error);
      return;
    }

    if (data.url) {
      window.open(data.url, '_blank');
    }
  } catch (err) {
    toast.error('An error occurred while opening subscription management');
    console.error('Portal error:', err);
  }
};
