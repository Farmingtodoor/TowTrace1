import { jsPDF } from 'jspdf';

export interface ReceiptData {
  receiptNumber: string;
  paymentDate: Date;
  vehicleInfo: {
    make?: string;
    model?: string;
    year?: string;
    plateNumber?: string;
    vin?: string;
    color?: string;
  };
  towYard: {
    name: string;
    address: string;
    city: string;
    state: string;
    phone: string;
  };
  fees: {
    towFee: number;
    dailyStorageFee: number;
    daysStored: number;
    storageFee: number;
    adminFee: number;
    gateFee: number;
    subtotal: number;
    serviceFee: number;
    total: number;
  };
  customerInfo?: {
    name?: string;
    email?: string;
  };
}

export function generateReceipt(data: ReceiptData): jsPDF {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.getWidth();
  let y = 20;

  // Colors
  const primaryColor: [number, number, number] = [20, 184, 166]; // Teal
  const darkColor: [number, number, number] = [30, 41, 59];
  const mutedColor: [number, number, number] = [100, 116, 139];

  // Header
  doc.setFillColor(...primaryColor);
  doc.rect(0, 0, pageWidth, 40, 'F');
  
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(24);
  doc.setFont('helvetica', 'bold');
  doc.text('TowTrace', 20, 25);
  
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text('Vehicle Release Receipt', pageWidth - 20, 20, { align: 'right' });
  doc.text(`#${data.receiptNumber}`, pageWidth - 20, 28, { align: 'right' });

  y = 55;

  // Receipt details box
  doc.setTextColor(...mutedColor);
  doc.setFontSize(9);
  doc.text('PAYMENT DATE', 20, y);
  doc.text('RECEIPT NUMBER', pageWidth / 2, y);
  
  y += 6;
  doc.setTextColor(...darkColor);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text(formatDate(data.paymentDate), 20, y);
  doc.text(data.receiptNumber, pageWidth / 2, y);

  // Divider
  y += 12;
  doc.setDrawColor(226, 232, 240);
  doc.setLineWidth(0.5);
  doc.line(20, y, pageWidth - 20, y);

  // Vehicle Information
  y += 15;
  doc.setTextColor(...primaryColor);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('VEHICLE INFORMATION', 20, y);

  y += 10;
  doc.setTextColor(...darkColor);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');

  const vehicleLines = [];
  if (data.vehicleInfo.year || data.vehicleInfo.make || data.vehicleInfo.model) {
    vehicleLines.push({
      label: 'Vehicle',
      value: `${data.vehicleInfo.year || ''} ${data.vehicleInfo.make || ''} ${data.vehicleInfo.model || ''}`.trim(),
    });
  }
  if (data.vehicleInfo.plateNumber) {
    vehicleLines.push({ label: 'License Plate', value: data.vehicleInfo.plateNumber });
  }
  if (data.vehicleInfo.vin) {
    vehicleLines.push({ label: 'VIN', value: data.vehicleInfo.vin });
  }
  if (data.vehicleInfo.color) {
    vehicleLines.push({ label: 'Color', value: data.vehicleInfo.color });
  }

  vehicleLines.forEach((line) => {
    doc.setTextColor(...mutedColor);
    doc.text(line.label + ':', 20, y);
    doc.setTextColor(...darkColor);
    doc.text(line.value, 70, y);
    y += 7;
  });

  // Tow Yard Information
  y += 8;
  doc.setTextColor(...primaryColor);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('TOW YARD', 20, y);

  y += 10;
  doc.setTextColor(...darkColor);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text(data.towYard.name, 20, y);
  
  y += 6;
  doc.setFont('helvetica', 'normal');
  doc.text(data.towYard.address, 20, y);
  y += 5;
  doc.text(`${data.towYard.city}, ${data.towYard.state}`, 20, y);
  y += 5;
  doc.text(data.towYard.phone, 20, y);

  // Fee Breakdown
  y += 15;
  doc.setTextColor(...primaryColor);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('FEE BREAKDOWN', 20, y);

  y += 10;
  const feeStartY = y;
  
  // Fee table
  const fees = [
    { label: 'Tow Fee', value: data.fees.towFee },
    { 
      label: `Storage Fee (${data.fees.daysStored} day${data.fees.daysStored !== 1 ? 's' : ''} × $${data.fees.dailyStorageFee.toFixed(2)})`, 
      value: data.fees.storageFee 
    },
    { label: 'Admin Fee', value: data.fees.adminFee },
  ];

  if (data.fees.gateFee > 0) {
    fees.push({ label: 'Gate Fee', value: data.fees.gateFee });
  }

  doc.setFontSize(10);
  fees.forEach((fee) => {
    doc.setTextColor(...mutedColor);
    doc.setFont('helvetica', 'normal');
    doc.text(fee.label, 20, y);
    doc.setTextColor(...darkColor);
    doc.text(`$${fee.value.toFixed(2)}`, pageWidth - 20, y, { align: 'right' });
    y += 7;
  });

  // Subtotal line
  y += 3;
  doc.setDrawColor(226, 232, 240);
  doc.line(20, y, pageWidth - 20, y);
  y += 8;

  doc.setTextColor(...mutedColor);
  doc.text('Subtotal', 20, y);
  doc.setTextColor(...darkColor);
  doc.text(`$${data.fees.subtotal.toFixed(2)}`, pageWidth - 20, y, { align: 'right' });
  
  y += 7;
  doc.setTextColor(...mutedColor);
  doc.text('Service Fee (5%)', 20, y);
  doc.setTextColor(...darkColor);
  doc.text(`$${data.fees.serviceFee.toFixed(2)}`, pageWidth - 20, y, { align: 'right' });

  // Total box
  y += 10;
  doc.setFillColor(241, 245, 249);
  doc.roundedRect(20, y - 5, pageWidth - 40, 20, 3, 3, 'F');
  
  y += 7;
  doc.setTextColor(...darkColor);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text('TOTAL PAID', 25, y);
  doc.setTextColor(...primaryColor);
  doc.setFontSize(14);
  doc.text(`$${data.fees.total.toFixed(2)}`, pageWidth - 25, y, { align: 'right' });

  // Footer
  y = doc.internal.pageSize.getHeight() - 30;
  doc.setDrawColor(226, 232, 240);
  doc.line(20, y, pageWidth - 20, y);
  
  y += 10;
  doc.setTextColor(...mutedColor);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.text('This receipt confirms payment for vehicle release fees.', pageWidth / 2, y, { align: 'center' });
  y += 5;
  doc.text('For questions, contact the tow yard directly or visit towtrace.com', pageWidth / 2, y, { align: 'center' });
  y += 5;
  doc.text(`Generated on ${formatDate(new Date())}`, pageWidth / 2, y, { align: 'center' });

  return doc;
}

export function downloadReceipt(data: ReceiptData): void {
  const doc = generateReceipt(data);
  const filename = `TowTrace-Receipt-${data.receiptNumber}.pdf`;
  doc.save(filename);
}

function formatDate(date: Date): string {
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

// Generate a receipt number from claim/payment ID
export function generateReceiptNumber(id: string, date: Date): string {
  const dateStr = date.toISOString().slice(0, 10).replace(/-/g, '');
  const shortId = id.slice(0, 8).toUpperCase();
  return `TT-${dateStr}-${shortId}`;
}
