import React, { createContext, useCallback, useContext, useEffect, useState } from "react";

export type SidebarDensity = "comfortable" | "compact";

const STORAGE_KEY = "admin-sidebar-density";

interface SidebarDensityContextValue {
  density: SidebarDensity;
  setDensity: (density: SidebarDensity) => void;
  toggleDensity: () => void;
  isCompact: boolean;
}

const SidebarDensityContext = createContext<SidebarDensityContextValue | undefined>(undefined);

export const SidebarDensityProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [density, setDensityState] = useState<SidebarDensity>(() => {
    if (typeof window === "undefined") return "comfortable";
    const stored = window.localStorage.getItem(STORAGE_KEY);
    return stored === "compact" ? "compact" : "comfortable";
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, density);
    } catch {
      /* ignore storage errors */
    }
  }, [density]);

  const setDensity = useCallback((next: SidebarDensity) => setDensityState(next), []);
  const toggleDensity = useCallback(
    () => setDensityState((prev) => (prev === "compact" ? "comfortable" : "compact")),
    []
  );

  return (
    <SidebarDensityContext.Provider
      value={{ density, setDensity, toggleDensity, isCompact: density === "compact" }}
    >
      {children}
    </SidebarDensityContext.Provider>
  );
};

export const useSidebarDensity = () => {
  const ctx = useContext(SidebarDensityContext);
  if (!ctx) throw new Error("useSidebarDensity must be used within a SidebarDensityProvider");
  return ctx;
};
