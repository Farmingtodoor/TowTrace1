import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface DiscountInfo {
  hasDiscount: boolean;
  originalPrice: number;
  discountedPrice: number;
  discountPercentage: number;
  promotionName?: string;
  promotionCode?: string;
}

export const useProductDiscounts = (productId: string, productPrice: number, farmerId?: string) => {
  const [discountInfo, setDiscountInfo] = useState<DiscountInfo>({
    hasDiscount: false,
    originalPrice: productPrice,
    discountedPrice: productPrice,
    discountPercentage: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDiscounts = async () => {
      if (!productId || !farmerId) {
        setLoading(false);
        return;
      }

        try {
          // Fetch active promotions for this farmer that are not expired
          const currentTime = new Date().toISOString();
          const { data: promotions, error } = await supabase
            .from('promotions')
            .select('*')
            .eq('farmer_id', farmerId)
            .eq('is_active', true)
            .gte('expires_at', currentTime)
            .order('discount_value', { ascending: false });

          if (error) {
            // Requests aborted by navigation/unmount surface as "Failed to fetch" — not actionable
            if (!String(error.message || '').includes('Failed to fetch')) {
              console.error('Error fetching promotions:', error);
            }
            setLoading(false);
            return;
          }

          if (!promotions || promotions.length === 0) {
            setLoading(false);
            return;
          }

          // Find the best applicable promotion
          let bestPromotion = null;
          let maxDiscount = 0;

          for (const promotion of promotions) {
            const applicableProducts = Array.isArray(promotion.applicable_products) 
              ? promotion.applicable_products as string[]
              : [];
            
            // Check if promotion applies to this product
            // If applicable_products is empty/null, it applies to all products
            // Otherwise, check if this product ID is in the array
            const appliesTo = applicableProducts.length === 0 || applicableProducts.includes(productId);
            
            if (!appliesTo) continue;

            // Calculate discount amount
            let discountAmount = 0;
            if (promotion.discount_type === 'percentage') {
              discountAmount = (productPrice * promotion.discount_value) / 100;
            } else {
              discountAmount = promotion.discount_value;
            }

            // Ensure discount doesn't exceed product price
            discountAmount = Math.min(discountAmount, productPrice);

            if (discountAmount > maxDiscount) {
              maxDiscount = discountAmount;
              bestPromotion = promotion;
            }
          }

          if (bestPromotion && maxDiscount > 0) {
            const discountedPrice = Math.max(0, productPrice - maxDiscount);
            const discountPercentage = ((maxDiscount / productPrice) * 100);

            setDiscountInfo({
              hasDiscount: true,
              originalPrice: productPrice,
              discountedPrice,
              discountPercentage,
              promotionName: bestPromotion.name,
              promotionCode: bestPromotion.code
            });
          } else {
            // Reset discount info if no applicable promotions found
            setDiscountInfo({
              hasDiscount: false,
              originalPrice: productPrice,
              discountedPrice: productPrice,
              discountPercentage: 0
            });
          }
      } catch (error) {
        console.error('Error calculating discounts:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchDiscounts();
  }, [productId, productPrice, farmerId]);

  return { discountInfo, loading };
};