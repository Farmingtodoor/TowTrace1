import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { formatWindow } from "@/lib/scheduleWindow";


interface OrderRow {
  id: string;
  status?: string | null;
  order_number?: string | null;
  total_amount?: number | null;
  delivery_type?: string | null;
  pickup_scheduled_at?: string | null;
  pickup_scheduled_end?: string | null;
  delivery_scheduled_at?: string | null;
  delivery_scheduled_end?: string | null;
}


interface Options {
  /** Disable the subscription entirely (e.g. while auth is loading) */
  enabled?: boolean;
  /** Called (debounced) whenever an order row changes — use it to refetch */
  onChange?: () => void;
  /** Show a toast for new orders / status changes */
  notify?: boolean;
  /** Called for every order event (new order / status change) */
  onOrderEvent?: (event: {
    orderId: string;
    title: string;
    description?: string;
    status?: string;
  }) => void;
  /** Fallback polling interval in ms when realtime is unavailable */
  pollIntervalMs?: number;
}

const label = (order: OrderRow) =>
  order.order_number ? `#${order.order_number}` : `#${String(order.id).slice(0, 8)}`;

/**
 * Live order updates for the admin portal.
 * Uses Supabase realtime on public.orders and falls back to polling
 * if the realtime channel fails to connect.
 */
export function useAdminOrderRealtime({
  enabled = true,
  onChange,
  notify = false,
  onOrderEvent,
  pollIntervalMs = 30000,
}: Options = {}) {
  const [isLive, setIsLive] = useState(false);
  const [lastEventAt, setLastEventAt] = useState<Date | null>(null);
  const onChangeRef = useRef(onChange);
  onChangeRef.current = onChange;
  const onEventRef = useRef(onOrderEvent);
  onEventRef.current = onOrderEvent;
  const debounceRef = useRef<ReturnType<typeof setTimeout>>();

  useEffect(() => {
    if (!enabled) return;

    const trigger = () => {
      setLastEventAt(new Date());
      if (debounceRef.current) clearTimeout(debounceRef.current);
      debounceRef.current = setTimeout(() => onChangeRef.current?.(), 400);
    };

    let live = false;
    let pollTimer: ReturnType<typeof setInterval> | undefined;

    const startPolling = () => {
      if (pollTimer) return;
      pollTimer = setInterval(() => onChangeRef.current?.(), pollIntervalMs);
    };

    const channel = supabase
      .channel("admin-orders-live")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "orders" },
        (payload) => {
          const order = payload.new as OrderRow;
          if (notify) toast.success(`New order ${label(order)}`, { description: "Just came in" });
          onEventRef.current?.({
            orderId: String(order.id),
            title: `New order ${label(order)}`,
            description: order.total_amount != null ? `$${Number(order.total_amount).toFixed(2)}` : undefined,
            status: order.status ?? undefined,
          });
          trigger();
        }
      )
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "orders" },
        (payload) => {
          const next = payload.new as OrderRow;
          const prev = payload.old as OrderRow;
          if (next?.status && next.status !== prev?.status) {
            if (notify) toast(`Order ${label(next)} is now ${String(next.status).replace(/_/g, " ")}`);
            onEventRef.current?.({
              orderId: String(next.id),
              title: `Order ${label(next)} updated`,
              description: `Status changed to ${String(next.status).replace(/_/g, " ")}`,
              status: next.status ?? undefined,
            });
          }

          // Schedule window changes (only detectable when the old row is replicated).
          const isPickup = next?.delivery_type === "pickup";
          const startKey = isPickup ? "pickup_scheduled_at" : "delivery_scheduled_at";
          const endKey = isPickup ? "pickup_scheduled_end" : "delivery_scheduled_end";
          const hadWindow = prev && startKey in prev;
          const changed =
            hadWindow &&
            (next?.[startKey] !== prev?.[startKey] || next?.[endKey] !== prev?.[endKey]);
          if (changed) {
            const window = formatWindow(next?.[startKey], next?.[endKey]);
            const kind = isPickup ? "pickup" : "delivery";
            if (notify) {
              toast(`Order ${label(next)} ${kind} window ${window ? "updated" : "cleared"}`, {
                description: window ?? undefined,
              });
            }
            onEventRef.current?.({
              orderId: String(next.id),
              title: `Order ${label(next)} ${kind} window ${window ? "updated" : "cleared"}`,
              description: window ?? `No ${kind} window scheduled`,
              status: next.status ?? undefined,
            });
          }

          trigger();
        }

      )
      .subscribe((status) => {
        if (status === "SUBSCRIBED") {
          live = true;
          setIsLive(true);
          if (pollTimer) {
            clearInterval(pollTimer);
            pollTimer = undefined;
          }
        } else if (status === "CHANNEL_ERROR" || status === "TIMED_OUT" || status === "CLOSED") {
          live = false;
          setIsLive(false);
          startPolling();
        }
      });

    // Safety net: if realtime never connects, poll instead.
    const connectCheck = setTimeout(() => {
      if (!live) startPolling();
    }, 8000);

    return () => {
      clearTimeout(connectCheck);
      if (debounceRef.current) clearTimeout(debounceRef.current);
      if (pollTimer) clearInterval(pollTimer);
      supabase.removeChannel(channel);
    };
  }, [enabled, notify, pollIntervalMs]);

  return { isLive, lastEventAt };
}
