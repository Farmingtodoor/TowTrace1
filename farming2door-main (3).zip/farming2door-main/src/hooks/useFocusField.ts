import { useEffect } from "react";
import { useSearchParams } from "react-router-dom";

const HIGHLIGHT_CLASSES = ["ring-2", "ring-primary", "ring-offset-2", "rounded-md", "transition-shadow"];

/**
 * Reads a `?focus=<element-id>` query param and scrolls that element into view,
 * focuses it when focusable, and briefly highlights it.
 *
 * @param ready set to false while the target section is still loading/hidden
 */
export function useFocusField(ready: boolean = true) {
  const [searchParams] = useSearchParams();
  const focusId = searchParams.get("focus");

  useEffect(() => {
    if (!ready || !focusId) return;

    let cleared = false;
    let clearTimer: number | undefined;

    const timer = window.setTimeout(() => {
      const el = document.getElementById(focusId);
      if (!el) return;

      el.scrollIntoView({ behavior: "smooth", block: "center" });
      if (typeof (el as HTMLElement).focus === "function") {
        (el as HTMLElement).focus({ preventScroll: true });
      }
      el.classList.add(...HIGHLIGHT_CLASSES);
      clearTimer = window.setTimeout(() => {
        if (!cleared) el.classList.remove(...HIGHLIGHT_CLASSES);
      }, 2500);
    }, 350);

    return () => {
      cleared = true;
      window.clearTimeout(timer);
      if (clearTimer) window.clearTimeout(clearTimer);
      document.getElementById(focusId)?.classList.remove(...HIGHLIGHT_CLASSES);
    };
  }, [focusId, ready]);

  return focusId;
}

export default useFocusField;
