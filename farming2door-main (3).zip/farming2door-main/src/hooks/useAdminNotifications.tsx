import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export interface AdminNotification {
  id: string;
  orderId?: string;
  title: string;
  description?: string;
  status?: string;
  createdAt: string;
  read: boolean;
}

const FEED_KEY = "admin-notification-feed";
const MUTED_KEY = "admin-notification-muted-orders";
const GLOBAL_MUTE_KEY = "admin-notification-muted-all";
const EMAIL_KEY = "admin-notification-email-enabled";
const PUSH_KEY = "admin-notification-push-enabled";
const MAX_ITEMS = 50;

export type PushPermission = "unsupported" | "default" | "granted" | "denied";

interface Ctx {
  notifications: AdminNotification[];
  unreadCount: number;
  mutedOrders: string[];
  mutedAll: boolean;
  emailEnabled: boolean;
  pushEnabled: boolean;
  pushPermission: PushPermission;
  push: (n: Omit<AdminNotification, "id" | "createdAt" | "read"> & { id?: string }) => boolean;
  dismiss: (id: string) => void;
  dismissAll: () => void;
  markAllRead: () => void;
  markRead: (id: string) => void;
  isOrderMuted: (orderId?: string) => boolean;
  toggleOrderMute: (orderId: string) => void;
  setMutedAll: (muted: boolean) => void;
  setEmailEnabled: (enabled: boolean) => void;
  /** Enables browser push after requesting permission; returns the resulting permission. */
  setPushEnabled: (enabled: boolean) => Promise<PushPermission>;
}

const AdminNotificationsContext = createContext<Ctx | undefined>(undefined);

function read<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write(key: string, value: unknown) {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* ignore */
  }
}

function currentPermission(): PushPermission {
  if (typeof window === "undefined" || !("Notification" in window)) return "unsupported";
  return Notification.permission as PushPermission;
}

export const AdminNotificationsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<AdminNotification[]>(() =>
    read<AdminNotification[]>(FEED_KEY, [])
  );
  const [mutedOrders, setMutedOrders] = useState<string[]>(() => read<string[]>(MUTED_KEY, []));
  const [mutedAll, setMutedAllState] = useState<boolean>(() => read<boolean>(GLOBAL_MUTE_KEY, false));
  const [emailEnabled, setEmailEnabledState] = useState<boolean>(() => read<boolean>(EMAIL_KEY, false));
  const [pushEnabled, setPushEnabledState] = useState<boolean>(() => read<boolean>(PUSH_KEY, false));
  const [pushPermission, setPushPermission] = useState<PushPermission>(() => currentPermission());

  const userIdRef = useRef<string | undefined>(user?.id);
  userIdRef.current = user?.id;

  useEffect(() => write(FEED_KEY, notifications), [notifications]);
  useEffect(() => write(MUTED_KEY, mutedOrders), [mutedOrders]);
  useEffect(() => write(GLOBAL_MUTE_KEY, mutedAll), [mutedAll]);
  useEffect(() => write(EMAIL_KEY, emailEnabled), [emailEnabled]);
  useEffect(() => write(PUSH_KEY, pushEnabled), [pushEnabled]);

  const isOrderMuted = useCallback(
    (orderId?: string) => (orderId ? mutedOrders.includes(orderId) : false),
    [mutedOrders]
  );

  /** Fan out an already-unmuted event to browser push and email. */
  const deliver = useCallback(
    (entry: AdminNotification) => {
      if (pushEnabled && currentPermission() === "granted") {
        try {
          new Notification(entry.title, {
            body: entry.description,
            tag: entry.orderId ?? entry.id,
          });
        } catch {
          /* browser refused — the in-app feed still has it */
        }
      }

      const userId = userIdRef.current;
      if (emailEnabled && userId) {
        supabase.functions
          .invoke("send-notification-email", {
            body: {
              notification: {
                user_id: userId,
                title: entry.title,
                message: entry.description ?? entry.title,
                type: "admin_order_update",
                order_id: entry.orderId,
              },
            },
          })
          .catch((error) => console.error("Admin notification email failed:", error));
      }
    },
    [emailEnabled, pushEnabled]
  );

  /** Returns false when the event was suppressed by a mute rule. */
  const push: Ctx["push"] = useCallback(
    (n) => {
      if (mutedAll) return false;
      if (n.orderId && mutedOrders.includes(n.orderId)) return false;
      const entry: AdminNotification = {
        id: n.id ?? `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        orderId: n.orderId,
        title: n.title,
        description: n.description,
        status: n.status,
        createdAt: new Date().toISOString(),
        read: false,
      };
      setNotifications((prev) => [entry, ...prev].slice(0, MAX_ITEMS));
      deliver(entry);
      return true;
    },
    [mutedAll, mutedOrders, deliver]
  );

  const setPushEnabled = useCallback(async (enabled: boolean) => {
    if (!enabled) {
      setPushEnabledState(false);
      return currentPermission();
    }
    if (!("Notification" in window)) {
      setPushPermission("unsupported");
      return "unsupported" as PushPermission;
    }
    let permission = Notification.permission as PushPermission;
    if (permission === "default") {
      try {
        permission = (await Notification.requestPermission()) as PushPermission;
      } catch {
        permission = "denied";
      }
    }
    setPushPermission(permission);
    setPushEnabledState(permission === "granted");
    return permission;
  }, []);

  const value = useMemo<Ctx>(
    () => ({
      notifications,
      unreadCount: notifications.filter((n) => !n.read).length,
      mutedOrders,
      mutedAll,
      emailEnabled,
      pushEnabled,
      pushPermission,
      push,
      dismiss: (id) => setNotifications((prev) => prev.filter((n) => n.id !== id)),
      dismissAll: () => setNotifications([]),
      markAllRead: () => setNotifications((prev) => prev.map((n) => ({ ...n, read: true }))),
      markRead: (id) => setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n))),
      isOrderMuted,
      toggleOrderMute: (orderId) =>
        setMutedOrders((prev) =>
          prev.includes(orderId) ? prev.filter((o) => o !== orderId) : [...prev, orderId]
        ),
      setMutedAll: (muted) => setMutedAllState(muted),
      setEmailEnabled: (enabled) => setEmailEnabledState(enabled),
      setPushEnabled,
    }),
    [
      notifications,
      mutedOrders,
      mutedAll,
      emailEnabled,
      pushEnabled,
      pushPermission,
      push,
      isOrderMuted,
      setPushEnabled,
    ]
  );

  return (
    <AdminNotificationsContext.Provider value={value}>{children}</AdminNotificationsContext.Provider>
  );
};

export function useAdminNotifications() {
  const ctx = useContext(AdminNotificationsContext);
  if (!ctx) throw new Error("useAdminNotifications must be used within an AdminNotificationsProvider");
  return ctx;
}
