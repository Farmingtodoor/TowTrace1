import { useCallback, useMemo } from "react";
import { toast } from "sonner";
import { useAdmin } from "@/contexts/AdminContext";
import {
  AppRole,
  Permission,
  deniedMessage,
  permissionsForRole,
  roleCan,
} from "@/lib/permissions";

/**
 * Role-based permissions derived from the Supabase role claim
 * (public.user_roles via get_current_user_role).
 */
export function usePermissions() {
  const { userRole, loading } = useAdmin();
  const role = (userRole as AppRole | null) ?? null;

  const permissions = useMemo(() => permissionsForRole(role), [role]);

  const can = useCallback((permission: Permission) => roleCan(role, permission), [role]);

  /** Returns true when allowed; otherwise shows an explanatory toast and returns false. */
  const requirePermission = useCallback(
    (permission: Permission) => {
      if (roleCan(role, permission)) return true;
      toast.error("Not allowed", { description: deniedMessage(permission) });
      return false;
    },
    [role]
  );

  return { role, permissions, can, requirePermission, loading };
}
