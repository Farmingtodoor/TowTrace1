import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export const useProductTracking = (productId: string, productCategory?: string) => {
  const { user } = useAuth();

  useEffect(() => {
    if (!productId) return;

    // Generate a session ID for anonymous users
    let sessionId = localStorage.getItem('browsing_session_id');
    if (!sessionId) {
      sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      localStorage.setItem('browsing_session_id', sessionId);
    }

    // Track the product view
    const trackView = async () => {
      try {
        await supabase.rpc('track_product_view', {
          p_product_id: productId,
          p_user_id: user?.id || null,
          p_session_id: sessionId
        });

        // Update user preferences if user is logged in and category is available
        if (user && productCategory) {
          await supabase.rpc('update_user_preferences', {
            p_user_id: user.id,
            p_category: productCategory
          });
        }

        // Track analytics event
        await supabase.rpc('track_analytics_event', {
          p_event_type: 'product_view',
          p_event_data: {
            product_id: productId,
            category: productCategory,
            timestamp: new Date().toISOString(),
            user_type: user ? 'authenticated' : 'anonymous'
          },
          p_user_id: user?.id || null,
          p_session_id: sessionId,
          p_page_url: window.location.href
        });
      } catch (error) {
        console.error('Error tracking product view:', error);
      }
    };

    // Track immediately, then track again after 10 seconds if user is still on page
    trackView();
    
    const timer = setTimeout(() => {
      trackView();
    }, 10000);

    return () => clearTimeout(timer);
  }, [productId, user, productCategory]);
};

export const useRecommendationTracking = () => {
  const trackRecommendationClick = async (
    originalProductId: string,
    recommendedProductId: string,
    recommendationType: string,
    position: number
  ) => {
    try {
      // Track the recommendation click
      await supabase.rpc('track_analytics_event', {
        p_event_type: 'recommendation_click',
        p_event_data: {
          original_product_id: originalProductId,
          recommended_product_id: recommendedProductId,
          recommendation_type: recommendationType,
          position: position,
          timestamp: new Date().toISOString()
        },
        p_page_url: window.location.href
      });
    } catch (error) {
      console.error('Error tracking recommendation click:', error);
    }
  };

  const trackRecommendationView = async (
    recommendationType: string,
    productIds: string[],
    context?: string
  ) => {
    try {
      await supabase.rpc('track_analytics_event', {
        p_event_type: 'recommendation_view',
        p_event_data: {
          recommendation_type: recommendationType,
          product_ids: productIds,
          context: context,
          count: productIds.length,
          timestamp: new Date().toISOString()
        },
        p_page_url: window.location.href
      });
    } catch (error) {
      console.error('Error tracking recommendation view:', error);
    }
  };

  return {
    trackRecommendationClick,
    trackRecommendationView
  };
};

export const useInventoryTracking = (productId: string) => {
  const trackLowStockAlert = async (stockLevel: number) => {
    try {
      await supabase.rpc('track_analytics_event', {
        p_event_type: 'low_stock_alert',
        p_event_data: {
          product_id: productId,
          stock_level: stockLevel,
          timestamp: new Date().toISOString()
        }
      });
    } catch (error) {
      console.error('Error tracking low stock alert:', error);
    }
  };

  const trackBackInStockAlert = async (newStockLevel: number) => {
    try {
      await supabase.rpc('track_analytics_event', {
        p_event_type: 'back_in_stock_alert',
        p_event_data: {
          product_id: productId,
          new_stock_level: newStockLevel,
          timestamp: new Date().toISOString()
        }
      });
    } catch (error) {
      console.error('Error tracking back in stock alert:', error);
    }
  };

  return {
    trackLowStockAlert,
    trackBackInStockAlert
  };
};