export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      add_ons: {
        Row: {
          created_at: string
          description: string | null
          id: string
          name: string
          price: number
        }
        Insert: {
          created_at?: string
          description?: string | null
          id: string
          name: string
          price: number
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          price?: number
        }
        Relationships: []
      }
      analytics_events: {
        Row: {
          created_at: string
          event_data: Json | null
          event_type: string
          id: string
          page_url: string | null
          session_id: string | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string
          event_data?: Json | null
          event_type: string
          id?: string
          page_url?: string | null
          session_id?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string
          event_data?: Json | null
          event_type?: string
          id?: string
          page_url?: string | null
          session_id?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      app_notifications: {
        Row: {
          created_at: string
          email: string
          id: string
          notified: boolean
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          notified?: boolean
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          notified?: boolean
        }
        Relationships: []
      }
      breeding_stock_breeds: {
        Row: {
          category_id: string | null
          created_at: string | null
          description: string | null
          display_order: number | null
          id: string
          is_active: boolean | null
          name: string
          type: string | null
        }
        Insert: {
          category_id?: string | null
          created_at?: string | null
          description?: string | null
          display_order?: number | null
          id?: string
          is_active?: boolean | null
          name: string
          type?: string | null
        }
        Update: {
          category_id?: string | null
          created_at?: string | null
          description?: string | null
          display_order?: number | null
          id?: string
          is_active?: boolean | null
          name?: string
          type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "breeding_stock_breeds_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "breeding_stock_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      breeding_stock_categories: {
        Row: {
          created_at: string | null
          description: string | null
          display_order: number | null
          icon: string | null
          id: string
          is_active: boolean | null
          name: string
          slug: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          display_order?: number | null
          icon?: string | null
          id?: string
          is_active?: boolean | null
          name: string
          slug: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          display_order?: number | null
          icon?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
          slug?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      breeding_stock_inquiries: {
        Row: {
          buyer_id: string
          created_at: string | null
          id: string
          is_read: boolean | null
          listing_id: string | null
          message: string
          seller_id: string
        }
        Insert: {
          buyer_id: string
          created_at?: string | null
          id?: string
          is_read?: boolean | null
          listing_id?: string | null
          message: string
          seller_id: string
        }
        Update: {
          buyer_id?: string
          created_at?: string | null
          id?: string
          is_read?: boolean | null
          listing_id?: string | null
          message?: string
          seller_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "breeding_stock_inquiries_listing_id_fkey"
            columns: ["listing_id"]
            isOneToOne: false
            referencedRelation: "breeding_stock_listings"
            referencedColumns: ["id"]
          },
        ]
      }
      breeding_stock_listings: {
        Row: {
          age_months: number | null
          biosecurity_notes: string | null
          breed_id: string | null
          breeding_guarantee: string | null
          breeding_status: string | null
          category_id: string | null
          contact_preferences: Json | null
          created_at: string | null
          custom_breed: string | null
          date_of_birth: string | null
          delivery_mileage_rate: number | null
          deposit_allowed: boolean | null
          deposit_percentage: number | null
          deworming_records: Json | null
          farmer_id: string
          handling_notes: string | null
          health_certificate_url: string | null
          health_tests: Json | null
          heat_cycle_notes: string | null
          id: string
          is_featured: boolean | null
          latitude: number | null
          location_city: string | null
          location_state: string | null
          longitude: number | null
          photos: Json | null
          price: number
          registration_cert_url: string | null
          registration_number: string | null
          registry_name: string | null
          return_refund_terms: string | null
          sex: string | null
          status: string | null
          temperament: string | null
          title: string
          transport_delivery: boolean | null
          transport_pickup: boolean | null
          transport_third_party: boolean | null
          type: string
          updated_at: string | null
          vaccinations: Json | null
          videos: Json | null
          views_count: number | null
          weight_lbs: number | null
          zip_code: string | null
        }
        Insert: {
          age_months?: number | null
          biosecurity_notes?: string | null
          breed_id?: string | null
          breeding_guarantee?: string | null
          breeding_status?: string | null
          category_id?: string | null
          contact_preferences?: Json | null
          created_at?: string | null
          custom_breed?: string | null
          date_of_birth?: string | null
          delivery_mileage_rate?: number | null
          deposit_allowed?: boolean | null
          deposit_percentage?: number | null
          deworming_records?: Json | null
          farmer_id: string
          handling_notes?: string | null
          health_certificate_url?: string | null
          health_tests?: Json | null
          heat_cycle_notes?: string | null
          id?: string
          is_featured?: boolean | null
          latitude?: number | null
          location_city?: string | null
          location_state?: string | null
          longitude?: number | null
          photos?: Json | null
          price: number
          registration_cert_url?: string | null
          registration_number?: string | null
          registry_name?: string | null
          return_refund_terms?: string | null
          sex?: string | null
          status?: string | null
          temperament?: string | null
          title: string
          transport_delivery?: boolean | null
          transport_pickup?: boolean | null
          transport_third_party?: boolean | null
          type: string
          updated_at?: string | null
          vaccinations?: Json | null
          videos?: Json | null
          views_count?: number | null
          weight_lbs?: number | null
          zip_code?: string | null
        }
        Update: {
          age_months?: number | null
          biosecurity_notes?: string | null
          breed_id?: string | null
          breeding_guarantee?: string | null
          breeding_status?: string | null
          category_id?: string | null
          contact_preferences?: Json | null
          created_at?: string | null
          custom_breed?: string | null
          date_of_birth?: string | null
          delivery_mileage_rate?: number | null
          deposit_allowed?: boolean | null
          deposit_percentage?: number | null
          deworming_records?: Json | null
          farmer_id?: string
          handling_notes?: string | null
          health_certificate_url?: string | null
          health_tests?: Json | null
          heat_cycle_notes?: string | null
          id?: string
          is_featured?: boolean | null
          latitude?: number | null
          location_city?: string | null
          location_state?: string | null
          longitude?: number | null
          photos?: Json | null
          price?: number
          registration_cert_url?: string | null
          registration_number?: string | null
          registry_name?: string | null
          return_refund_terms?: string | null
          sex?: string | null
          status?: string | null
          temperament?: string | null
          title?: string
          transport_delivery?: boolean | null
          transport_pickup?: boolean | null
          transport_third_party?: boolean | null
          type?: string
          updated_at?: string | null
          vaccinations?: Json | null
          videos?: Json | null
          views_count?: number | null
          weight_lbs?: number | null
          zip_code?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "breeding_stock_listings_breed_id_fkey"
            columns: ["breed_id"]
            isOneToOne: false
            referencedRelation: "breeding_stock_breeds"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "breeding_stock_listings_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "breeding_stock_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      breeding_stock_transactions: {
        Row: {
          balance_amount: number | null
          balance_paid_at: string | null
          bill_of_sale_url: string | null
          buyer_id: string
          buyer_notes: string | null
          completed_at: string | null
          created_at: string | null
          deposit_amount: number | null
          deposit_paid_at: string | null
          health_certificate_url: string | null
          id: string
          listing_id: string | null
          notes: string | null
          pickup_scheduled_date: string | null
          seller_id: string
          seller_notes: string | null
          signed_at: string | null
          status: string | null
          stripe_balance_session_id: string | null
          stripe_deposit_session_id: string | null
          total_price: number
          updated_at: string | null
        }
        Insert: {
          balance_amount?: number | null
          balance_paid_at?: string | null
          bill_of_sale_url?: string | null
          buyer_id: string
          buyer_notes?: string | null
          completed_at?: string | null
          created_at?: string | null
          deposit_amount?: number | null
          deposit_paid_at?: string | null
          health_certificate_url?: string | null
          id?: string
          listing_id?: string | null
          notes?: string | null
          pickup_scheduled_date?: string | null
          seller_id: string
          seller_notes?: string | null
          signed_at?: string | null
          status?: string | null
          stripe_balance_session_id?: string | null
          stripe_deposit_session_id?: string | null
          total_price: number
          updated_at?: string | null
        }
        Update: {
          balance_amount?: number | null
          balance_paid_at?: string | null
          bill_of_sale_url?: string | null
          buyer_id?: string
          buyer_notes?: string | null
          completed_at?: string | null
          created_at?: string | null
          deposit_amount?: number | null
          deposit_paid_at?: string | null
          health_certificate_url?: string | null
          id?: string
          listing_id?: string | null
          notes?: string | null
          pickup_scheduled_date?: string | null
          seller_id?: string
          seller_notes?: string | null
          signed_at?: string | null
          status?: string | null
          stripe_balance_session_id?: string | null
          stripe_deposit_session_id?: string | null
          total_price?: number
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "breeding_stock_transactions_listing_id_fkey"
            columns: ["listing_id"]
            isOneToOne: false
            referencedRelation: "breeding_stock_listings"
            referencedColumns: ["id"]
          },
        ]
      }
      browsing_history: {
        Row: {
          id: string
          product_id: string
          referrer: string | null
          session_id: string | null
          user_id: string | null
          viewed_at: string
        }
        Insert: {
          id?: string
          product_id: string
          referrer?: string | null
          session_id?: string | null
          user_id?: string | null
          viewed_at?: string
        }
        Update: {
          id?: string
          product_id?: string
          referrer?: string | null
          session_id?: string | null
          user_id?: string | null
          viewed_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "browsing_history_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      categories: {
        Row: {
          created_at: string | null
          description: string | null
          display_order: number | null
          icon: string | null
          id: string
          is_active: boolean | null
          name: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          display_order?: number | null
          icon?: string | null
          id?: string
          is_active?: boolean | null
          name: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          display_order?: number | null
          icon?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      conversations: {
        Row: {
          created_at: string
          customer_id: string
          farmer_id: string
          id: string
          last_message_at: string | null
          status: string
          subject: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          customer_id: string
          farmer_id: string
          id?: string
          last_message_at?: string | null
          status?: string
          subject?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          customer_id?: string
          farmer_id?: string
          id?: string
          last_message_at?: string | null
          status?: string
          subject?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      custom_orders: {
        Row: {
          created_at: string
          customer_id: string
          customer_notes: string | null
          delivery_address: string | null
          delivery_fee: number | null
          delivery_method: string | null
          estimated_total: number | null
          farmer_id: string
          farmer_notes: string | null
          id: string
          proposed_delivery_date: string | null
          requested_delivery_date: string
          requested_products: Json
          responded_at: string | null
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          customer_id: string
          customer_notes?: string | null
          delivery_address?: string | null
          delivery_fee?: number | null
          delivery_method?: string | null
          estimated_total?: number | null
          farmer_id: string
          farmer_notes?: string | null
          id?: string
          proposed_delivery_date?: string | null
          requested_delivery_date: string
          requested_products?: Json
          responded_at?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          customer_id?: string
          customer_notes?: string | null
          delivery_address?: string | null
          delivery_fee?: number | null
          delivery_method?: string | null
          estimated_total?: number | null
          farmer_id?: string
          farmer_notes?: string | null
          id?: string
          proposed_delivery_date?: string | null
          requested_delivery_date?: string
          requested_products?: Json
          responded_at?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      customer_insights: {
        Row: {
          avg_order_value: number | null
          created_at: string
          customer_id: string
          email: string | null
          first_order_date: string | null
          full_name: string | null
          id: string
          last_order_date: string | null
          total_orders: number | null
          total_spent: number | null
          updated_at: string
        }
        Insert: {
          avg_order_value?: number | null
          created_at?: string
          customer_id: string
          email?: string | null
          first_order_date?: string | null
          full_name?: string | null
          id?: string
          last_order_date?: string | null
          total_orders?: number | null
          total_spent?: number | null
          updated_at?: string
        }
        Update: {
          avg_order_value?: number | null
          created_at?: string
          customer_id?: string
          email?: string | null
          first_order_date?: string | null
          full_name?: string | null
          id?: string
          last_order_date?: string | null
          total_orders?: number | null
          total_spent?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      delivery_partners: {
        Row: {
          api_endpoint: string | null
          base_fee: number
          created_at: string
          estimated_delivery_time: string | null
          id: string
          is_active: boolean
          logo_url: string | null
          maximum_delivery_distance_miles: number
          minimum_order_amount: number
          name: string
          operating_hours: Json | null
          per_mile_fee: number
          service_areas: Json | null
          slug: string
          updated_at: string
        }
        Insert: {
          api_endpoint?: string | null
          base_fee?: number
          created_at?: string
          estimated_delivery_time?: string | null
          id?: string
          is_active?: boolean
          logo_url?: string | null
          maximum_delivery_distance_miles?: number
          minimum_order_amount?: number
          name: string
          operating_hours?: Json | null
          per_mile_fee?: number
          service_areas?: Json | null
          slug: string
          updated_at?: string
        }
        Update: {
          api_endpoint?: string | null
          base_fee?: number
          created_at?: string
          estimated_delivery_time?: string | null
          id?: string
          is_active?: boolean
          logo_url?: string | null
          maximum_delivery_distance_miles?: number
          minimum_order_amount?: number
          name?: string
          operating_hours?: Json | null
          per_mile_fee?: number
          service_areas?: Json | null
          slug?: string
          updated_at?: string
        }
        Relationships: []
      }
      delivery_waitlist: {
        Row: {
          created_at: string
          distance_miles: number | null
          email: string
          farmer_id: string
          id: string
          notes: string | null
          notify_delivery: boolean
          notify_pickup: boolean
          status: string
          updated_at: string
          user_id: string | null
          zip_code: string
        }
        Insert: {
          created_at?: string
          distance_miles?: number | null
          email: string
          farmer_id: string
          id?: string
          notes?: string | null
          notify_delivery?: boolean
          notify_pickup?: boolean
          status?: string
          updated_at?: string
          user_id?: string | null
          zip_code: string
        }
        Update: {
          created_at?: string
          distance_miles?: number | null
          email?: string
          farmer_id?: string
          id?: string
          notes?: string | null
          notify_delivery?: boolean
          notify_pickup?: boolean
          status?: string
          updated_at?: string
          user_id?: string | null
          zip_code?: string
        }
        Relationships: []
      }
      delivery_zones: {
        Row: {
          created_at: string
          delivery_fee: number
          delivery_windows: Json | null
          id: string
          is_active: boolean | null
          max_distance_km: number | null
          name: string
          zip_codes: Json
        }
        Insert: {
          created_at?: string
          delivery_fee?: number
          delivery_windows?: Json | null
          id?: string
          is_active?: boolean | null
          max_distance_km?: number | null
          name: string
          zip_codes?: Json
        }
        Update: {
          created_at?: string
          delivery_fee?: number
          delivery_windows?: Json | null
          id?: string
          is_active?: boolean | null
          max_distance_km?: number | null
          name?: string
          zip_codes?: Json
        }
        Relationships: []
      }
      driver_location_history: {
        Row: {
          driver_id: string
          id: string
          latitude: number
          longitude: number
          order_assignment_id: string | null
          recorded_at: string
        }
        Insert: {
          driver_id: string
          id?: string
          latitude: number
          longitude: number
          order_assignment_id?: string | null
          recorded_at?: string
        }
        Update: {
          driver_id?: string
          id?: string
          latitude?: number
          longitude?: number
          order_assignment_id?: string | null
          recorded_at?: string
        }
        Relationships: []
      }
      driver_order_assignments: {
        Row: {
          assigned_at: string
          created_at: string
          customer_rating: number | null
          delivered_at: string | null
          driver_earnings: number
          driver_id: string
          driver_notes: string | null
          id: string
          order_id: string
          picked_up_at: string | null
          status: string
          updated_at: string
        }
        Insert: {
          assigned_at?: string
          created_at?: string
          customer_rating?: number | null
          delivered_at?: string | null
          driver_earnings?: number
          driver_id: string
          driver_notes?: string | null
          id?: string
          order_id: string
          picked_up_at?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          assigned_at?: string
          created_at?: string
          customer_rating?: number | null
          delivered_at?: string | null
          driver_earnings?: number
          driver_id?: string
          driver_notes?: string | null
          id?: string
          order_id?: string
          picked_up_at?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      driver_profiles: {
        Row: {
          created_at: string
          current_latitude: number | null
          current_longitude: number | null
          driver_license_number: string
          email: string
          full_name: string
          id: string
          is_active: boolean
          is_verified: boolean
          last_location_update: string | null
          license_plate: string
          phone: string
          rating: number | null
          status: string
          total_deliveries: number | null
          updated_at: string
          user_id: string
          vehicle_type: string
        }
        Insert: {
          created_at?: string
          current_latitude?: number | null
          current_longitude?: number | null
          driver_license_number: string
          email: string
          full_name: string
          id?: string
          is_active?: boolean
          is_verified?: boolean
          last_location_update?: string | null
          license_plate: string
          phone: string
          rating?: number | null
          status?: string
          total_deliveries?: number | null
          updated_at?: string
          user_id: string
          vehicle_type?: string
        }
        Update: {
          created_at?: string
          current_latitude?: number | null
          current_longitude?: number | null
          driver_license_number?: string
          email?: string
          full_name?: string
          id?: string
          is_active?: boolean
          is_verified?: boolean
          last_location_update?: string | null
          license_plate?: string
          phone?: string
          rating?: number | null
          status?: string
          total_deliveries?: number | null
          updated_at?: string
          user_id?: string
          vehicle_type?: string
        }
        Relationships: []
      }
      farmer_applications: {
        Row: {
          admin_notes: string | null
          business_registration_encrypted: string | null
          business_registration_number: string | null
          categories: Json | null
          certifications: string[] | null
          created_at: string
          email: string
          email_encrypted: string | null
          farm_address: string
          farm_address_encrypted: string | null
          farm_description: string | null
          farm_name: string
          farm_size: string | null
          farming_experience: string | null
          full_name: string
          full_name_encrypted: string | null
          id: string
          insurance_details: string | null
          insurance_details_encrypted: string | null
          next_harvest_date: string | null
          phone: string | null
          phone_encrypted: string | null
          processing_methods: string[] | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          subcategories: Json | null
          tax_id: string | null
          tax_id_encrypted: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          admin_notes?: string | null
          business_registration_encrypted?: string | null
          business_registration_number?: string | null
          categories?: Json | null
          certifications?: string[] | null
          created_at?: string
          email: string
          email_encrypted?: string | null
          farm_address: string
          farm_address_encrypted?: string | null
          farm_description?: string | null
          farm_name: string
          farm_size?: string | null
          farming_experience?: string | null
          full_name: string
          full_name_encrypted?: string | null
          id?: string
          insurance_details?: string | null
          insurance_details_encrypted?: string | null
          next_harvest_date?: string | null
          phone?: string | null
          phone_encrypted?: string | null
          processing_methods?: string[] | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          subcategories?: Json | null
          tax_id?: string | null
          tax_id_encrypted?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          admin_notes?: string | null
          business_registration_encrypted?: string | null
          business_registration_number?: string | null
          categories?: Json | null
          certifications?: string[] | null
          created_at?: string
          email?: string
          email_encrypted?: string | null
          farm_address?: string
          farm_address_encrypted?: string | null
          farm_description?: string | null
          farm_name?: string
          farm_size?: string | null
          farming_experience?: string | null
          full_name?: string
          full_name_encrypted?: string | null
          id?: string
          insurance_details?: string | null
          insurance_details_encrypted?: string | null
          next_harvest_date?: string | null
          phone?: string | null
          phone_encrypted?: string | null
          processing_methods?: string[] | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          subcategories?: Json | null
          tax_id?: string | null
          tax_id_encrypted?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      farmer_categories: {
        Row: {
          category_id: string | null
          created_at: string | null
          farmer_id: string | null
          id: string
        }
        Insert: {
          category_id?: string | null
          created_at?: string | null
          farmer_id?: string | null
          id?: string
        }
        Update: {
          category_id?: string | null
          created_at?: string | null
          farmer_id?: string | null
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "farmer_categories_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      farmer_delivery_settings: {
        Row: {
          created_at: string
          delivery_minimum_order: number
          delivery_notes: string | null
          delivery_radius_miles: number
          farmer_id: string
          id: string
          offers_delivery: boolean
          offers_pickup: boolean
          origin_zip: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          delivery_minimum_order?: number
          delivery_notes?: string | null
          delivery_radius_miles?: number
          farmer_id: string
          id?: string
          offers_delivery?: boolean
          offers_pickup?: boolean
          origin_zip?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          delivery_minimum_order?: number
          delivery_notes?: string | null
          delivery_radius_miles?: number
          farmer_id?: string
          id?: string
          offers_delivery?: boolean
          offers_pickup?: boolean
          origin_zip?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      farmer_payout_accounts: {
        Row: {
          bank_last4: string | null
          bank_name: string | null
          charges_enabled: boolean
          country: string | null
          created_at: string
          details_submitted: boolean
          farmer_id: string
          id: string
          payouts_enabled: boolean
          requirements_due: Json
          stripe_account_id: string
          updated_at: string
        }
        Insert: {
          bank_last4?: string | null
          bank_name?: string | null
          charges_enabled?: boolean
          country?: string | null
          created_at?: string
          details_submitted?: boolean
          farmer_id: string
          id?: string
          payouts_enabled?: boolean
          requirements_due?: Json
          stripe_account_id: string
          updated_at?: string
        }
        Update: {
          bank_last4?: string | null
          bank_name?: string | null
          charges_enabled?: boolean
          country?: string | null
          created_at?: string
          details_submitted?: boolean
          farmer_id?: string
          id?: string
          payouts_enabled?: boolean
          requirements_due?: Json
          stripe_account_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      farmer_pickup_slots: {
        Row: {
          capacity: number
          created_at: string
          day_of_week: number
          end_time: string
          farmer_id: string
          id: string
          is_active: boolean
          location_note: string | null
          start_time: string
          updated_at: string
        }
        Insert: {
          capacity?: number
          created_at?: string
          day_of_week: number
          end_time: string
          farmer_id: string
          id?: string
          is_active?: boolean
          location_note?: string | null
          start_time: string
          updated_at?: string
        }
        Update: {
          capacity?: number
          created_at?: string
          day_of_week?: number
          end_time?: string
          farmer_id?: string
          id?: string
          is_active?: boolean
          location_note?: string | null
          start_time?: string
          updated_at?: string
        }
        Relationships: []
      }
      farmer_revenue_summary: {
        Row: {
          avg_order_value: number | null
          created_at: string
          farm_name: string | null
          farmer_id: string
          id: string
          month: string
          total_orders: number | null
          total_revenue: number | null
          unique_customers: number | null
          updated_at: string
        }
        Insert: {
          avg_order_value?: number | null
          created_at?: string
          farm_name?: string | null
          farmer_id: string
          id?: string
          month: string
          total_orders?: number | null
          total_revenue?: number | null
          unique_customers?: number | null
          updated_at?: string
        }
        Update: {
          avg_order_value?: number | null
          created_at?: string
          farm_name?: string | null
          farmer_id?: string
          id?: string
          month?: string
          total_orders?: number | null
          total_revenue?: number | null
          unique_customers?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      farmer_subcategories: {
        Row: {
          created_at: string | null
          farmer_id: string | null
          id: string
          subcategory_id: string | null
        }
        Insert: {
          created_at?: string | null
          farmer_id?: string | null
          id?: string
          subcategory_id?: string | null
        }
        Update: {
          created_at?: string | null
          farmer_id?: string | null
          id?: string
          subcategory_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "farmer_subcategories_subcategory_id_fkey"
            columns: ["subcategory_id"]
            isOneToOne: false
            referencedRelation: "subcategories"
            referencedColumns: ["id"]
          },
        ]
      }
      featured_purchases: {
        Row: {
          amount: number
          created_at: string | null
          expires_at: string
          farmer_id: string
          id: string
          item_id: string | null
          service_id: string | null
          starts_at: string | null
          status: string | null
          stripe_session_id: string | null
          updated_at: string | null
        }
        Insert: {
          amount: number
          created_at?: string | null
          expires_at: string
          farmer_id: string
          id?: string
          item_id?: string | null
          service_id?: string | null
          starts_at?: string | null
          status?: string | null
          stripe_session_id?: string | null
          updated_at?: string | null
        }
        Update: {
          amount?: number
          created_at?: string | null
          expires_at?: string
          farmer_id?: string
          id?: string
          item_id?: string | null
          service_id?: string | null
          starts_at?: string | null
          status?: string | null
          stripe_session_id?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "featured_purchases_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "featured_services"
            referencedColumns: ["id"]
          },
        ]
      }
      featured_services: {
        Row: {
          created_at: string | null
          description: string | null
          duration_days: number
          feature_type: string
          id: string
          is_active: boolean | null
          max_items: number | null
          name: string
          price: number
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          duration_days: number
          feature_type: string
          id?: string
          is_active?: boolean | null
          max_items?: number | null
          name: string
          price: number
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          duration_days?: number
          feature_type?: string
          id?: string
          is_active?: boolean | null
          max_items?: number | null
          name?: string
          price?: number
          updated_at?: string | null
        }
        Relationships: []
      }
      inventory_tracking: {
        Row: {
          id: string
          last_updated: string
          low_stock_threshold: number
          notes: string | null
          product_id: string
          reorder_point: number
          stock_level: number
        }
        Insert: {
          id?: string
          last_updated?: string
          low_stock_threshold?: number
          notes?: string | null
          product_id: string
          reorder_point?: number
          stock_level?: number
        }
        Update: {
          id?: string
          last_updated?: string
          low_stock_threshold?: number
          notes?: string | null
          product_id?: string
          reorder_point?: number
          stock_level?: number
        }
        Relationships: [
          {
            foreignKeyName: "inventory_tracking_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: true
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      job_applications: {
        Row: {
          cover_letter: string | null
          created_at: string
          email: string
          full_name: string
          id: string
          linkedin_url: string | null
          phone: string | null
          portfolio_url: string | null
          position: string
          resume_url: string | null
          status: string | null
          updated_at: string
          years_experience: string | null
        }
        Insert: {
          cover_letter?: string | null
          created_at?: string
          email: string
          full_name: string
          id?: string
          linkedin_url?: string | null
          phone?: string | null
          portfolio_url?: string | null
          position: string
          resume_url?: string | null
          status?: string | null
          updated_at?: string
          years_experience?: string | null
        }
        Update: {
          cover_letter?: string | null
          created_at?: string
          email?: string
          full_name?: string
          id?: string
          linkedin_url?: string | null
          phone?: string | null
          portfolio_url?: string | null
          position?: string
          resume_url?: string | null
          status?: string | null
          updated_at?: string
          years_experience?: string | null
        }
        Relationships: []
      }
      messages: {
        Row: {
          content: string
          conversation_id: string
          created_at: string
          id: string
          is_read: boolean
          message_type: string | null
          sender_id: string
          updated_at: string
        }
        Insert: {
          content: string
          conversation_id: string
          created_at?: string
          id?: string
          is_read?: boolean
          message_type?: string | null
          sender_id: string
          updated_at?: string
        }
        Update: {
          content?: string
          conversation_id?: string
          created_at?: string
          id?: string
          is_read?: boolean
          message_type?: string | null
          sender_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          created_at: string
          id: string
          message: string
          order_id: string | null
          read: boolean
          sent_email: boolean
          title: string
          type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          message: string
          order_id?: string | null
          read?: boolean
          sent_email?: boolean
          title: string
          type: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          message?: string
          order_id?: string | null
          read?: boolean
          sent_email?: boolean
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notifications_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      order_items: {
        Row: {
          created_at: string
          id: string
          order_id: string
          product_description: string | null
          product_name: string
          quantity: number
          total_price: number
          unit_price: number
        }
        Insert: {
          created_at?: string
          id?: string
          order_id: string
          product_description?: string | null
          product_name: string
          quantity: number
          total_price: number
          unit_price: number
        }
        Update: {
          created_at?: string
          id?: string
          order_id?: string
          product_description?: string | null
          product_name?: string
          quantity?: number
          total_price?: number
          unit_price?: number
        }
        Relationships: [
          {
            foreignKeyName: "order_items_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      orders: {
        Row: {
          amount_paid: number | null
          created_at: string
          currency: string
          customer_id: string
          customer_notes: string | null
          delivery_address: string | null
          delivery_fee: number | null
          delivery_latitude: number | null
          delivery_longitude: number | null
          delivery_partner_fee: number | null
          delivery_partner_id: string | null
          delivery_partner_order_id: string | null
          delivery_partner_tracking_url: string | null
          delivery_scheduled_at: string | null
          delivery_scheduled_end: string | null
          delivery_type: string
          estimated_delivery_time: string | null
          farmer_earnings: number
          farmer_id: string
          farmer_notes: string | null
          id: string
          paid_at: string | null
          payment_status: string
          pickup_latitude: number | null
          pickup_longitude: number | null
          pickup_scheduled_at: string | null
          pickup_scheduled_end: string | null
          pickup_slot_id: string | null
          platform_fee: number
          status: string
          stripe_payment_intent_id: string | null
          stripe_session_id: string | null
          total_amount: number
          updated_at: string
        }
        Insert: {
          amount_paid?: number | null
          created_at?: string
          currency?: string
          customer_id: string
          customer_notes?: string | null
          delivery_address?: string | null
          delivery_fee?: number | null
          delivery_latitude?: number | null
          delivery_longitude?: number | null
          delivery_partner_fee?: number | null
          delivery_partner_id?: string | null
          delivery_partner_order_id?: string | null
          delivery_partner_tracking_url?: string | null
          delivery_scheduled_at?: string | null
          delivery_scheduled_end?: string | null
          delivery_type?: string
          estimated_delivery_time?: string | null
          farmer_earnings?: number
          farmer_id: string
          farmer_notes?: string | null
          id?: string
          paid_at?: string | null
          payment_status?: string
          pickup_latitude?: number | null
          pickup_longitude?: number | null
          pickup_scheduled_at?: string | null
          pickup_scheduled_end?: string | null
          pickup_slot_id?: string | null
          platform_fee?: number
          status?: string
          stripe_payment_intent_id?: string | null
          stripe_session_id?: string | null
          total_amount: number
          updated_at?: string
        }
        Update: {
          amount_paid?: number | null
          created_at?: string
          currency?: string
          customer_id?: string
          customer_notes?: string | null
          delivery_address?: string | null
          delivery_fee?: number | null
          delivery_latitude?: number | null
          delivery_longitude?: number | null
          delivery_partner_fee?: number | null
          delivery_partner_id?: string | null
          delivery_partner_order_id?: string | null
          delivery_partner_tracking_url?: string | null
          delivery_scheduled_at?: string | null
          delivery_scheduled_end?: string | null
          delivery_type?: string
          estimated_delivery_time?: string | null
          farmer_earnings?: number
          farmer_id?: string
          farmer_notes?: string | null
          id?: string
          paid_at?: string | null
          payment_status?: string
          pickup_latitude?: number | null
          pickup_longitude?: number | null
          pickup_scheduled_at?: string | null
          pickup_scheduled_end?: string | null
          pickup_slot_id?: string | null
          platform_fee?: number
          status?: string
          stripe_payment_intent_id?: string | null
          stripe_session_id?: string | null
          total_amount?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "orders_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "orders_delivery_partner_id_fkey"
            columns: ["delivery_partner_id"]
            isOneToOne: false
            referencedRelation: "delivery_partners"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "orders_farmer_id_fkey"
            columns: ["farmer_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "orders_pickup_slot_id_fkey"
            columns: ["pickup_slot_id"]
            isOneToOne: false
            referencedRelation: "farmer_pickup_slots"
            referencedColumns: ["id"]
          },
        ]
      }
      payout_receipts: {
        Row: {
          amount: number
          created_at: string
          currency: string
          failure_reason: string | null
          farmer_id: string
          id: string
          payout_request_id: string
          receipt_number: string
          sent_at: string
          sent_by: string | null
          status: string
          stripe_account_id: string | null
          stripe_payout_id: string | null
          stripe_transfer_id: string | null
          updated_at: string
        }
        Insert: {
          amount: number
          created_at?: string
          currency?: string
          failure_reason?: string | null
          farmer_id: string
          id?: string
          payout_request_id: string
          receipt_number: string
          sent_at?: string
          sent_by?: string | null
          status?: string
          stripe_account_id?: string | null
          stripe_payout_id?: string | null
          stripe_transfer_id?: string | null
          updated_at?: string
        }
        Update: {
          amount?: number
          created_at?: string
          currency?: string
          failure_reason?: string | null
          farmer_id?: string
          id?: string
          payout_request_id?: string
          receipt_number?: string
          sent_at?: string
          sent_by?: string | null
          status?: string
          stripe_account_id?: string | null
          stripe_payout_id?: string | null
          stripe_transfer_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "payout_receipts_payout_request_id_fkey"
            columns: ["payout_request_id"]
            isOneToOne: false
            referencedRelation: "payout_requests"
            referencedColumns: ["id"]
          },
        ]
      }
      payout_requests: {
        Row: {
          additional_notes: string | null
          admin_notes: string | null
          amount: number
          bank_account_holder: string | null
          bank_account_number: string | null
          created_at: string
          farmer_id: string
          id: string
          payment_method: string
          requested_at: string
          reviewed_at: string | null
          reviewed_by: string | null
          routing_number: string | null
          status: string
          updated_at: string
        }
        Insert: {
          additional_notes?: string | null
          admin_notes?: string | null
          amount: number
          bank_account_holder?: string | null
          bank_account_number?: string | null
          created_at?: string
          farmer_id: string
          id?: string
          payment_method?: string
          requested_at?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          routing_number?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          additional_notes?: string | null
          admin_notes?: string | null
          amount?: number
          bank_account_holder?: string | null
          bank_account_number?: string | null
          created_at?: string
          farmer_id?: string
          id?: string
          payment_method?: string
          requested_at?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          routing_number?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      pickup_reminders: {
        Row: {
          created_at: string
          id: string
          order_id: string
          reminder_type: string
          sent_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          order_id: string
          reminder_type: string
          sent_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          order_id?: string
          reminder_type?: string
          sent_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "pickup_reminders_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
        ]
      }
      product_performance: {
        Row: {
          avg_rating: number | null
          category: string | null
          created_at: string
          farm_name: string | null
          farmer_id: string | null
          id: string
          name: string | null
          product_id: string
          review_count: number | null
          times_ordered: number | null
          total_quantity_sold: number | null
          total_revenue: number | null
          updated_at: string
        }
        Insert: {
          avg_rating?: number | null
          category?: string | null
          created_at?: string
          farm_name?: string | null
          farmer_id?: string | null
          id?: string
          name?: string | null
          product_id: string
          review_count?: number | null
          times_ordered?: number | null
          total_quantity_sold?: number | null
          total_revenue?: number | null
          updated_at?: string
        }
        Update: {
          avg_rating?: number | null
          category?: string | null
          created_at?: string
          farm_name?: string | null
          farmer_id?: string | null
          id?: string
          name?: string | null
          product_id?: string
          review_count?: number | null
          times_ordered?: number | null
          total_quantity_sold?: number | null
          total_revenue?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      product_recommendations: {
        Row: {
          created_at: string
          id: string
          product_id: string
          recommendation_type: string
          recommended_product_id: string
          score: number | null
        }
        Insert: {
          created_at?: string
          id?: string
          product_id: string
          recommendation_type: string
          recommended_product_id: string
          score?: number | null
        }
        Update: {
          created_at?: string
          id?: string
          product_id?: string
          recommendation_type?: string
          recommended_product_id?: string
          score?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "product_recommendations_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "product_recommendations_recommended_product_id_fkey"
            columns: ["recommended_product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      products: {
        Row: {
          animal_portion_type: string | null
          average_rating: number | null
          category: string
          certifications: Json | null
          created_at: string
          description: string | null
          expiration_date: string | null
          farm_distance: number | null
          farmer: string
          farmer_id: string | null
          freshness_type: string | null
          harvest_date: string | null
          id: string
          image_url: string | null
          images: Json | null
          is_available: boolean | null
          is_organic: boolean | null
          name: string
          next_delivery_date: string | null
          portion_options: Json | null
          price: number
          processing_addons: Json | null
          review_count: number | null
          stock_quantity: number | null
          subcategory: string | null
          unit: string | null
          updated_at: string
          videos: Json | null
        }
        Insert: {
          animal_portion_type?: string | null
          average_rating?: number | null
          category: string
          certifications?: Json | null
          created_at?: string
          description?: string | null
          expiration_date?: string | null
          farm_distance?: number | null
          farmer: string
          farmer_id?: string | null
          freshness_type?: string | null
          harvest_date?: string | null
          id?: string
          image_url?: string | null
          images?: Json | null
          is_available?: boolean | null
          is_organic?: boolean | null
          name: string
          next_delivery_date?: string | null
          portion_options?: Json | null
          price: number
          processing_addons?: Json | null
          review_count?: number | null
          stock_quantity?: number | null
          subcategory?: string | null
          unit?: string | null
          updated_at?: string
          videos?: Json | null
        }
        Update: {
          animal_portion_type?: string | null
          average_rating?: number | null
          category?: string
          certifications?: Json | null
          created_at?: string
          description?: string | null
          expiration_date?: string | null
          farm_distance?: number | null
          farmer?: string
          farmer_id?: string | null
          freshness_type?: string | null
          harvest_date?: string | null
          id?: string
          image_url?: string | null
          images?: Json | null
          is_available?: boolean | null
          is_organic?: boolean | null
          name?: string
          next_delivery_date?: string | null
          portion_options?: Json | null
          price?: number
          processing_addons?: Json | null
          review_count?: number | null
          stock_quantity?: number | null
          subcategory?: string | null
          unit?: string | null
          updated_at?: string
          videos?: Json | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          city: string | null
          country: string | null
          created_at: string
          email: string
          full_name: string | null
          id: string
          phone: string | null
          profile_picture_url: string | null
          role: Database["public"]["Enums"]["app_role"] | null
          state: string | null
          status: string
          updated_at: string
          user_type: string
          zip_code: string | null
        }
        Insert: {
          city?: string | null
          country?: string | null
          created_at?: string
          email: string
          full_name?: string | null
          id: string
          phone?: string | null
          profile_picture_url?: string | null
          role?: Database["public"]["Enums"]["app_role"] | null
          state?: string | null
          status?: string
          updated_at?: string
          user_type?: string
          zip_code?: string | null
        }
        Update: {
          city?: string | null
          country?: string | null
          created_at?: string
          email?: string
          full_name?: string | null
          id?: string
          phone?: string | null
          profile_picture_url?: string | null
          role?: Database["public"]["Enums"]["app_role"] | null
          state?: string | null
          status?: string
          updated_at?: string
          user_type?: string
          zip_code?: string | null
        }
        Relationships: []
      }
      promotion_usage: {
        Row: {
          discount_amount: number
          id: string
          order_id: string | null
          promotion_id: string | null
          used_at: string | null
          user_id: string | null
        }
        Insert: {
          discount_amount: number
          id?: string
          order_id?: string | null
          promotion_id?: string | null
          used_at?: string | null
          user_id?: string | null
        }
        Update: {
          discount_amount?: number
          id?: string
          order_id?: string | null
          promotion_id?: string | null
          used_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "promotion_usage_promotion_id_fkey"
            columns: ["promotion_id"]
            isOneToOne: false
            referencedRelation: "promotions"
            referencedColumns: ["id"]
          },
        ]
      }
      promotions: {
        Row: {
          applicable_products: Json | null
          code: string
          created_at: string | null
          created_by: string | null
          description: string | null
          discount_type: Database["public"]["Enums"]["discount_type"]
          discount_value: number
          expires_at: string | null
          farmer_id: string | null
          id: string
          is_active: boolean | null
          max_uses: number | null
          minimum_order_amount: number | null
          name: string
          starts_at: string | null
          type: Database["public"]["Enums"]["promotion_type"]
          updated_at: string | null
          uses_count: number | null
        }
        Insert: {
          applicable_products?: Json | null
          code: string
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          discount_type: Database["public"]["Enums"]["discount_type"]
          discount_value: number
          expires_at?: string | null
          farmer_id?: string | null
          id?: string
          is_active?: boolean | null
          max_uses?: number | null
          minimum_order_amount?: number | null
          name: string
          starts_at?: string | null
          type: Database["public"]["Enums"]["promotion_type"]
          updated_at?: string | null
          uses_count?: number | null
        }
        Update: {
          applicable_products?: Json | null
          code?: string
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          discount_type?: Database["public"]["Enums"]["discount_type"]
          discount_value?: number
          expires_at?: string | null
          farmer_id?: string | null
          id?: string
          is_active?: boolean | null
          max_uses?: number | null
          minimum_order_amount?: number | null
          name?: string
          starts_at?: string | null
          type?: Database["public"]["Enums"]["promotion_type"]
          updated_at?: string | null
          uses_count?: number | null
        }
        Relationships: []
      }
      rate_limits: {
        Row: {
          action: string
          count: number | null
          created_at: string | null
          id: string
          identifier: string
          window_start: string | null
        }
        Insert: {
          action: string
          count?: number | null
          created_at?: string | null
          id?: string
          identifier: string
          window_start?: string | null
        }
        Update: {
          action?: string
          count?: number | null
          created_at?: string | null
          id?: string
          identifier?: string
          window_start?: string | null
        }
        Relationships: []
      }
      reviews: {
        Row: {
          comment: string | null
          created_at: string
          customer_id: string
          id: string
          is_helpful_count: number | null
          is_verified: boolean | null
          order_id: string | null
          photos: Json | null
          product_id: string
          rating: number
          title: string | null
          updated_at: string
        }
        Insert: {
          comment?: string | null
          created_at?: string
          customer_id: string
          id?: string
          is_helpful_count?: number | null
          is_verified?: boolean | null
          order_id?: string | null
          photos?: Json | null
          product_id: string
          rating: number
          title?: string | null
          updated_at?: string
        }
        Update: {
          comment?: string | null
          created_at?: string
          customer_id?: string
          id?: string
          is_helpful_count?: number | null
          is_verified?: boolean | null
          order_id?: string | null
          photos?: Json | null
          product_id?: string
          rating?: number
          title?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "reviews_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reviews_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "products"
            referencedColumns: ["id"]
          },
        ]
      }
      search_filters: {
        Row: {
          created_at: string
          id: string
          is_active: boolean | null
          name: string
          options: Json | null
          type: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_active?: boolean | null
          name: string
          options?: Json | null
          type: string
        }
        Update: {
          created_at?: string
          id?: string
          is_active?: boolean | null
          name?: string
          options?: Json | null
          type?: string
        }
        Relationships: []
      }
      seasonal_alerts: {
        Row: {
          alert_month: number | null
          created_at: string
          farmer_id: string | null
          id: string
          is_active: boolean
          last_notified_at: string | null
          product_category: string
          product_name: string | null
          user_id: string
        }
        Insert: {
          alert_month?: number | null
          created_at?: string
          farmer_id?: string | null
          id?: string
          is_active?: boolean
          last_notified_at?: string | null
          product_category: string
          product_name?: string | null
          user_id: string
        }
        Update: {
          alert_month?: number | null
          created_at?: string
          farmer_id?: string | null
          id?: string
          is_active?: boolean
          last_notified_at?: string | null
          product_category?: string
          product_name?: string | null
          user_id?: string
        }
        Relationships: []
      }
      security_audit_log: {
        Row: {
          action: string
          created_at: string | null
          details: Json | null
          id: string
          ip_address: unknown
          record_id: string | null
          table_name: string | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string | null
          details?: Json | null
          id?: string
          ip_address?: unknown
          record_id?: string | null
          table_name?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string | null
          details?: Json | null
          id?: string
          ip_address?: unknown
          record_id?: string | null
          table_name?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      security_audit_log_archive: {
        Row: {
          action: string
          archived_at: string
          created_at: string | null
          details: Json | null
          id: string
          ip_address: unknown
          record_id: string | null
          table_name: string | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          action: string
          archived_at?: string
          created_at?: string | null
          details?: Json | null
          id: string
          ip_address?: unknown
          record_id?: string | null
          table_name?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string
          archived_at?: string
          created_at?: string | null
          details?: Json | null
          id?: string
          ip_address?: unknown
          record_id?: string | null
          table_name?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      security_audit_log_settings: {
        Row: {
          archive_enabled: boolean
          archive_retention_days: number
          created_at: string
          id: string
          last_run_archived: number
          last_run_at: string | null
          last_run_deleted: number
          retention_days: number
          updated_at: string
        }
        Insert: {
          archive_enabled?: boolean
          archive_retention_days?: number
          created_at?: string
          id?: string
          last_run_archived?: number
          last_run_at?: string | null
          last_run_deleted?: number
          retention_days?: number
          updated_at?: string
        }
        Update: {
          archive_enabled?: boolean
          archive_retention_days?: number
          created_at?: string
          id?: string
          last_run_archived?: number
          last_run_at?: string | null
          last_run_deleted?: number
          retention_days?: number
          updated_at?: string
        }
        Relationships: []
      }
      subcategories: {
        Row: {
          category_id: string | null
          created_at: string | null
          description: string | null
          display_order: number | null
          id: string
          is_active: boolean | null
          name: string
          updated_at: string | null
        }
        Insert: {
          category_id?: string | null
          created_at?: string | null
          description?: string | null
          display_order?: number | null
          id?: string
          is_active?: boolean | null
          name: string
          updated_at?: string | null
        }
        Update: {
          category_id?: string | null
          created_at?: string | null
          description?: string | null
          display_order?: number | null
          id?: string
          is_active?: boolean | null
          name?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "subcategories_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      subscription_deliveries: {
        Row: {
          created_at: string
          delivery_date: string
          farmer_notes: string | null
          id: string
          items: Json
          status: string
          subscription_id: string
          total_amount: number | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          delivery_date: string
          farmer_notes?: string | null
          id?: string
          items?: Json
          status?: string
          subscription_id: string
          total_amount?: number | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          delivery_date?: string
          farmer_notes?: string | null
          id?: string
          items?: Json
          status?: string
          subscription_id?: string
          total_amount?: number | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "subscription_deliveries_subscription_id_fkey"
            columns: ["subscription_id"]
            isOneToOne: false
            referencedRelation: "subscriptions"
            referencedColumns: ["id"]
          },
        ]
      }
      subscription_plans: {
        Row: {
          created_at: string
          description: string | null
          farmer_id: string
          id: string
          interval_count: number
          interval_type: string
          is_active: boolean
          max_items: number | null
          name: string
          price: number
          stripe_price_id: string | null
          stripe_product_id: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          farmer_id: string
          id?: string
          interval_count?: number
          interval_type: string
          is_active?: boolean
          max_items?: number | null
          name: string
          price: number
          stripe_price_id?: string | null
          stripe_product_id?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          farmer_id?: string
          id?: string
          interval_count?: number
          interval_type?: string
          is_active?: boolean
          max_items?: number | null
          name?: string
          price?: number
          stripe_price_id?: string | null
          stripe_product_id?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      subscriptions: {
        Row: {
          created_at: string
          current_period_end: string | null
          current_period_start: string | null
          customer_id: string
          delivery_address: string
          farmer_id: string
          id: string
          next_delivery_date: string | null
          plan_id: string
          special_instructions: string | null
          status: string
          stripe_subscription_id: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          current_period_end?: string | null
          current_period_start?: string | null
          customer_id: string
          delivery_address: string
          farmer_id: string
          id?: string
          next_delivery_date?: string | null
          plan_id: string
          special_instructions?: string | null
          status?: string
          stripe_subscription_id?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          current_period_end?: string | null
          current_period_start?: string | null
          customer_id?: string
          delivery_address?: string
          farmer_id?: string
          id?: string
          next_delivery_date?: string | null
          plan_id?: string
          special_instructions?: string | null
          status?: string
          stripe_subscription_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "subscriptions_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "subscription_plans"
            referencedColumns: ["id"]
          },
        ]
      }
      terms_acceptances: {
        Row: {
          accepted_at: string
          created_at: string
          id: string
          ip_address: unknown
          terms_version: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          accepted_at?: string
          created_at?: string
          id?: string
          ip_address?: unknown
          terms_version?: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          accepted_at?: string
          created_at?: string
          id?: string
          ip_address?: unknown
          terms_version?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_favorites: {
        Row: {
          created_at: string
          id: string
          product_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          product_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          product_id?: string
          user_id?: string
        }
        Relationships: []
      }
      user_preferences: {
        Row: {
          id: string
          preferred_categories: Json | null
          prefers_organic: boolean | null
          price_preference: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          id?: string
          preferred_categories?: Json | null
          prefers_organic?: boolean | null
          price_preference?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          id?: string
          preferred_categories?: Json | null
          prefers_organic?: boolean | null
          price_preference?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_referrals: {
        Row: {
          completed_at: string | null
          created_at: string | null
          id: string
          referral_code: string
          referred_id: string | null
          referrer_id: string | null
          reward_amount: number | null
          status: string | null
        }
        Insert: {
          completed_at?: string | null
          created_at?: string | null
          id?: string
          referral_code: string
          referred_id?: string | null
          referrer_id?: string | null
          reward_amount?: number | null
          status?: string | null
        }
        Update: {
          completed_at?: string | null
          created_at?: string | null
          id?: string
          referral_code?: string
          referred_id?: string | null
          referrer_id?: string | null
          reward_amount?: number | null
          status?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      waitlist_alerts_sent: {
        Row: {
          alert_type: string
          created_at: string
          id: string
          waitlist_id: string
        }
        Insert: {
          alert_type: string
          created_at?: string
          id?: string
          waitlist_id: string
        }
        Update: {
          alert_type?: string
          created_at?: string
          id?: string
          waitlist_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "waitlist_alerts_sent_waitlist_id_fkey"
            columns: ["waitlist_id"]
            isOneToOne: false
            referencedRelation: "delivery_waitlist"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_run_audit_log_retention: { Args: never; Returns: Json }
      admin_set_farmer_location: {
        Args: {
          _city: string
          _state: string
          _user_id: string
          _zip_code?: string
        }
        Returns: undefined
      }
      admin_update_payout_status: {
        Args: { p_admin_notes?: string; p_payout_id: string; p_status: string }
        Returns: boolean
      }
      audit_access: {
        Args: { action_name: string; record_ref?: string; table_ref: string }
        Returns: undefined
      }
      calculate_delivery_fee: {
        Args: {
          customer_lat: number
          customer_lng: number
          farm_lat: number
          farm_lng: number
        }
        Returns: number
      }
      calculate_next_delivery_date: {
        Args: {
          interval_count: number
          interval_type: string
          start_date: string
        }
        Returns: string
      }
      check_email_subscription_rate_limit: { Args: never; Returns: boolean }
      check_payout_rate_limit: {
        Args: { p_farmer_id: string }
        Returns: boolean
      }
      check_system_security: { Args: never; Returns: Json }
      cleanup_old_notifications: { Args: never; Returns: undefined }
      decrypt_farmer_sensitive_data: {
        Args: { encrypted_data: string }
        Returns: string
      }
      decrypt_sensitive_data: {
        Args: { encrypted_data: string }
        Returns: string
      }
      encrypt_farmer_sensitive_data: { Args: { data: string }; Returns: string }
      expire_featured_items: { Args: never; Returns: undefined }
      farm2door_encrypt: { Args: { input_data: string }; Returns: string }
      find_nearby_drivers: {
        Args: { farm_lat: number; farm_lng: number; radius_km?: number }
        Returns: {
          distance_km: number
          driver_id: string
          driver_name: string
          phone: string
          rating: number
          vehicle_type: string
        }[]
      }
      generate_order_based_recommendations: { Args: never; Returns: undefined }
      generate_referral_code: { Args: { user_id: string }; Returns: string }
      generate_seasonal_recommendations: { Args: never; Returns: undefined }
      get_admin_farmer_earnings_report: {
        Args: never
        Returns: {
          available_balance: number
          bank_verified: boolean
          farm_name: string
          farmer_email: string
          farmer_id: string
          gross_earnings: number
          is_approved: boolean
          last_payout_at: string
          paid_orders: number
          pending_amount: number
          pending_requests: number
          total_paid_out: number
        }[]
      }
      get_admin_payout_details: {
        Args: { p_payout_id: string }
        Returns: {
          additional_notes: string
          admin_notes: string
          amount: number
          bank_account_holder: string
          bank_account_number: string
          created_at: string
          farmer_id: string
          id: string
          payment_method: string
          requested_at: string
          reviewed_at: string
          reviewed_by: string
          routing_number: string
          status: string
          updated_at: string
        }[]
      }
      get_admin_payout_list: {
        Args: never
        Returns: {
          account_holder_masked: string
          account_number_masked: string
          additional_notes: string
          admin_notes: string
          amount: number
          created_at: string
          farmer_id: string
          id: string
          payment_method: string
          requested_at: string
          reviewed_at: string
          reviewed_by: string
          status: string
          updated_at: string
        }[]
      }
      get_admin_payout_report: {
        Args: never
        Returns: {
          approved_count: number
          paid_count: number
          pending_count: number
          receipts_failed: number
          receipts_sent: number
          rejected_count: number
          success_rate: number
          total_approved: number
          total_paid: number
          total_pending: number
          total_rejected: number
        }[]
      }
      get_all_driver_profiles_secure_admin: {
        Args: never
        Returns: {
          created_at: string
          current_latitude: number
          current_longitude: number
          driver_license_number: string
          email: string
          full_name: string
          id: string
          is_active: boolean
          is_verified: boolean
          last_location_update: string
          license_plate: string
          phone: string
          rating: number
          status: string
          total_deliveries: number
          updated_at: string
          user_id: string
          vehicle_type: string
        }[]
      }
      get_approved_farmers_public: {
        Args: never
        Returns: {
          categories: Json
          certifications: string[]
          created_at: string
          display_name: string
          farm_description: string
          farm_name: string
          general_location: string
          next_harvest_date: string
          processing_methods: string[]
          subcategories: Json
          user_id: string
        }[]
      }
      get_available_pickup_slots: {
        Args: { _days?: number; _farmer_id: string }
        Returns: {
          booked: number
          capacity: number
          end_time: string
          location_note: string
          pickup_date: string
          remaining: number
          slot_id: string
          start_time: string
        }[]
      }
      get_current_user_role: {
        Args: never
        Returns: Database["public"]["Enums"]["app_role"]
      }
      get_custom_order_amount: { Args: { order_uuid: string }; Returns: number }
      get_customer_contact_safe: {
        Args: { customer_id_param: string }
        Returns: {
          contact_available: boolean
          display_name: string
          id: string
          masked_email: string
        }[]
      }
      get_decrypted_payout_requests: {
        Args: { p_farmer_id?: string }
        Returns: {
          additional_notes: string
          admin_notes: string
          amount: number
          bank_account_holder: string
          bank_account_number: string
          created_at: string
          farmer_id: string
          id: string
          payment_method: string
          requested_at: string
          reviewed_at: string
          reviewed_by: string
          routing_number: string
          status: string
          updated_at: string
        }[]
      }
      get_driver_info_for_customer_order: {
        Args: { order_id_param: string }
        Returns: {
          current_latitude: number
          current_longitude: number
          driver_id: string
          first_name: string
          rating: number
          vehicle_type: string
        }[]
      }
      get_driver_location_for_customer_order: {
        Args: { order_id_param: string }
        Returns: {
          current_latitude: number
          current_longitude: number
          last_location_update: string
        }[]
      }
      get_farmer_application_secure: {
        Args: { application_id: string }
        Returns: {
          admin_notes: string
          business_registration_number: string
          categories: Json
          certifications: string[]
          created_at: string
          email: string
          farm_address: string
          farm_description: string
          farm_name: string
          farm_size: string
          farming_experience: string
          full_name: string
          id: string
          insurance_details: string
          phone: string
          processing_methods: string[]
          reviewed_at: string
          reviewed_by: string
          status: string
          subcategories: Json
          tax_id: string
          updated_at: string
          user_id: string
        }[]
      }
      get_farmer_application_secure_admin_only: {
        Args: { application_id: string }
        Returns: {
          admin_notes: string
          business_registration_number: string
          categories: Json
          certifications: string[]
          created_at: string
          email: string
          farm_address: string
          farm_description: string
          farm_name: string
          farm_size: string
          farming_experience: string
          full_name: string
          id: string
          insurance_details: string
          phone: string
          processing_methods: string[]
          reviewed_at: string
          reviewed_by: string
          status: string
          subcategories: Json
          tax_id: string
          updated_at: string
          user_id: string
        }[]
      }
      get_farmer_applications_secure_admin: {
        Args: never
        Returns: {
          admin_notes: string
          business_registration_number: string
          categories: Json
          certifications: string[]
          created_at: string
          email: string
          farm_address: string
          farm_description: string
          farm_name: string
          farm_size: string
          farming_experience: string
          full_name: string
          id: string
          insurance_details: string
          phone: string
          processing_methods: string[]
          reviewed_at: string
          reviewed_by: string
          status: string
          subcategories: Json
          tax_id: string
          updated_at: string
          user_id: string
        }[]
      }
      get_farmer_contacts_for_orders: {
        Args: never
        Returns: {
          contact_email: string
          farm_name: string
          user_id: string
        }[]
      }
      get_farmer_public_locations: {
        Args: { _user_ids: string[] }
        Returns: {
          city: string
          country: string
          id: string
          state: string
          zip_code: string
        }[]
      }
      get_farmers_public_safe: {
        Args: never
        Returns: {
          categories: Json
          certifications: string[]
          created_at: string
          display_name: string
          farm_description: string
          farm_name: string
          next_harvest_date: string
          processing_methods: string[]
          subcategories: Json
          user_id: string
        }[]
      }
      get_farms_missing_location: {
        Args: never
        Returns: {
          application_id: string
          city: string
          created_at: string
          farm_address: string
          farm_name: string
          state: string
          status: string
          user_id: string
          zip_code: string
        }[]
      }
      get_featured_items: {
        Args: { feature_type_param?: string }
        Returns: {
          expires_at: string
          farm_name: string
          farmer_id: string
          feature_type: string
          item_id: string
          product_name: string
          purchase_id: string
        }[]
      }
      get_masked_customer_insights: {
        Args: never
        Returns: {
          avg_order_value: number
          created_at: string
          customer_id: string
          first_order_date: string
          id: string
          last_order_date: string
          masked_email: string
          masked_name: string
          total_orders: number
          total_spent: number
          updated_at: string
        }[]
      }
      get_personalized_recommendations: {
        Args: { p_limit?: number; p_user_id: string }
        Returns: {
          category: string
          farmer_name: string
          image_url: string
          is_organic: boolean
          name: string
          price: number
          product_id: string
          recommendation_score: number
        }[]
      }
      get_product_recommendations: {
        Args: { p_limit?: number; p_product_id: string }
        Returns: {
          farmer_name: string
          image_url: string
          name: string
          price: number
          product_id: string
          recommendation_score: number
        }[]
      }
      get_security_recommendations: {
        Args: never
        Returns: {
          action_required: string
          priority: string
          recommendation: string
        }[]
      }
      get_security_status: { Args: never; Returns: Json }
      get_trending_products: {
        Args: { p_limit?: number }
        Returns: {
          avg_rating: number
          category: string
          farmer_name: string
          image_url: string
          is_organic: boolean
          name: string
          order_count: number
          price: number
          product_id: string
        }[]
      }
      get_user_profiles_secure_admin: {
        Args: never
        Returns: {
          city: string
          country: string
          created_at: string
          email: string
          full_name: string
          id: string
          phone: string
          profile_picture_url: string
          state: string
          status: string
          updated_at: string
          user_type: string
          zip_code: string
        }[]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      has_used_first_order_discount: {
        Args: { user_id: string }
        Returns: boolean
      }
      insert_encrypted_payout_request: {
        Args: {
          p_additional_notes?: string
          p_amount: number
          p_bank_account_holder?: string
          p_bank_account_number?: string
          p_farmer_id: string
          p_payment_method?: string
          p_routing_number?: string
        }
        Returns: string
      }
      is_approved_farmer: { Args: { _user_id: string }; Returns: boolean }
      is_suspicious_email: { Args: { email: string }; Returns: boolean }
      is_valid_email: { Args: { email: string }; Returns: boolean }
      log_pii_access: {
        Args: { access_type: string; record_ref: string; table_ref: string }
        Returns: undefined
      }
      log_sensitive_farmer_data_access: {
        Args: {
          access_reason?: string
          accessed_fields: string[]
          application_id: string
        }
        Returns: undefined
      }
      mask_email: { Args: { email: string }; Returns: string }
      mask_email_safe: { Args: { email: string }; Returns: string }
      mask_phone: { Args: { phone: string }; Returns: string }
      run_security_audit_log_retention: { Args: never; Returns: Json }
      search_products_advanced: {
        Args: {
          p_category?: string
          p_farmer_id?: string
          p_in_stock_only?: boolean
          p_limit?: number
          p_max_price?: number
          p_min_price?: number
          p_min_rating?: number
          p_offset?: number
          p_organic_only?: boolean
          p_search_term?: string
          p_sort_by?: string
          p_sort_order?: string
          p_subcategory?: string
        }
        Returns: {
          animal_portion_type: string
          average_rating: number
          category: string
          certifications: Json
          created_at: string
          description: string
          expiration_date: string
          farm_distance: number
          farmer: string
          farmer_id: string
          freshness_type: string
          harvest_date: string
          id: string
          image_url: string
          images: Json
          is_available: boolean
          is_organic: boolean
          name: string
          next_delivery_date: string
          portion_options: Json
          price: number
          processing_addons: Json
          review_count: number
          stock_quantity: number
          subcategory: string
          unit: string
          updated_at: string
          videos: Json
        }[]
      }
      secure_data_access: {
        Args: {
          operation_param: string
          record_id_param?: string
          table_name_param: string
        }
        Returns: undefined
      }
      track_analytics_event: {
        Args: {
          p_event_data?: Json
          p_event_type: string
          p_page_url?: string
          p_session_id?: string
          p_user_id?: string
        }
        Returns: undefined
      }
      track_product_view: {
        Args: {
          p_product_id: string
          p_session_id?: string
          p_user_id?: string
        }
        Returns: undefined
      }
      update_customer_insights: { Args: never; Returns: undefined }
      update_farmer_revenue_analytics: { Args: never; Returns: undefined }
      update_product_performance: { Args: never; Returns: undefined }
      update_user_preferences: {
        Args: {
          p_category: string
          p_is_organic?: boolean
          p_price_range?: string
          p_user_id: string
        }
        Returns: undefined
      }
      validate_payout_amount: { Args: { amount: number }; Returns: boolean }
      validate_promotion: {
        Args: { order_total?: number; promotion_code: string; user_id?: string }
        Returns: {
          discount_amount: number
          error_message: string
          promotion_id: string
          valid: boolean
        }[]
      }
      validate_webhook_signature: {
        Args: { payload: string; secret: string; signature: string }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "super_admin" | "admin" | "farmer" | "customer" | "driver"
      discount_type: "percentage" | "fixed_amount"
      promotion_type:
        | "referral"
        | "first_order"
        | "product_specific"
        | "general"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["super_admin", "admin", "farmer", "customer", "driver"],
      discount_type: ["percentage", "fixed_amount"],
      promotion_type: [
        "referral",
        "first_order",
        "product_specific",
        "general",
      ],
    },
  },
} as const
