import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { 
  Package, 
  User, 
  MapPin, 
  Calendar, 
  DollarSign, 
  MessageCircle, 
  Check, 
  X,
  Clock,
  Truck,
  CheckCircle
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';

interface Order {
  id: string;
  customer_id: string;
  farmer_id: string;
  status: string;
  total_amount: number;
  delivery_type: string;
  delivery_address?: string;
  customer_notes?: string;
  farmer_notes?: string;
  created_at: string;
  updated_at: string;
  customer_name?: string;
  customer_email?: string;
  items?: any[];
}

interface FarmerOrderCardProps {
  order: Order;
  onOrderUpdate: () => void;
}

export const FarmerOrderCard = ({ order, onOrderUpdate }: FarmerOrderCardProps) => {
  const { toast } = useToast();
  const [isUpdating, setIsUpdating] = useState(false);
  const [farmerNotes, setFarmerNotes] = useState(order.farmer_notes || '');
  const [showNotesDialog, setShowNotesDialog] = useState(false);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-500';
      case 'confirmed':
        return 'bg-blue-500';
      case 'processing':
        return 'bg-orange-500';
      case 'ready':
        return 'bg-green-500';
      case 'out_for_delivery':
        return 'bg-purple-500';
      case 'delivered':
        return 'bg-green-600';
      case 'cancelled':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="h-4 w-4" />;
      case 'confirmed':
        return <Check className="h-4 w-4" />;
      case 'processing':
        return <Package className="h-4 w-4" />;
      case 'ready':
        return <CheckCircle className="h-4 w-4" />;
      case 'out_for_delivery':
        return <Truck className="h-4 w-4" />;
      case 'delivered':
        return <CheckCircle className="h-4 w-4" />;
      case 'cancelled':
        return <X className="h-4 w-4" />;
      default:
        return <Package className="h-4 w-4" />;
    }
  };

  const updateOrderStatus = async (newStatus: string, notes?: string) => {
    setIsUpdating(true);
    try {
      const updateData: any = { 
        status: newStatus,
        updated_at: new Date().toISOString()
      };
      
      if (notes !== undefined) {
        updateData.farmer_notes = notes;
      }

      const { error } = await supabase
        .from('orders')
        .update(updateData)
        .eq('id', order.id);

      if (error) throw error;

      toast({
        title: "Order Updated",
        description: `Order status changed to ${newStatus}`,
      });
      
      onOrderUpdate();
    } catch (error) {
      console.error('Error updating order:', error);
      toast({
        title: "Error",
        description: "Failed to update order status",
        variant: "destructive",
      });
    } finally {
      setIsUpdating(false);
    }
  };

  const handleAcceptOrder = () => {
    updateOrderStatus('confirmed');
  };

  const handleRejectOrder = () => {
    updateOrderStatus('cancelled', 'Order rejected by farmer');
  };

  const handleUpdateNotes = () => {
    updateOrderStatus(order.status, farmerNotes);
    setShowNotesDialog(false);
  };

  const getNextStatusOptions = () => {
    const statusFlow = {
      'pending': ['confirmed', 'cancelled'],
      'confirmed': ['processing', 'cancelled'],
      'processing': ['ready', 'cancelled'],
      'ready': ['out_for_delivery', 'delivered'],
      'out_for_delivery': ['delivered'],
    };
    return statusFlow[order.status as keyof typeof statusFlow] || [];
  };

  const canUpdateStatus = (status: string) => {
    return !['delivered', 'cancelled'].includes(status);
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Package className="h-5 w-5" />
            Order #{order.id.slice(-8)}
          </CardTitle>
          <Badge className={`${getStatusColor(order.status)} text-white flex items-center gap-1`}>
            {getStatusIcon(order.status)}
            {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Customer Information */}
        <div className="flex items-center gap-2">
          <User className="h-4 w-4 text-muted-foreground" />
          <span className="font-medium">
            {order.customer_name || order.customer_email || 'Unknown Customer'}
          </span>
        </div>

        {/* Order Details */}
        <div className="grid grid-cols-2 gap-4">
          <div className="flex items-center gap-2">
            <DollarSign className="h-4 w-4 text-muted-foreground" />
            <span className="font-bold text-lg">${order.total_amount}</span>
          </div>
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">
              {format(new Date(order.created_at), 'MMM d, yyyy')}
            </span>
          </div>
        </div>

        {/* Delivery Information */}
        <div className="flex items-center gap-2">
          <MapPin className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm">
            {order.delivery_type === 'delivery' 
              ? `Delivery: ${order.delivery_address || 'Address not specified'}`
              : 'Pickup at farm'
            }
          </span>
        </div>

        {/* Customer Notes */}
        {order.customer_notes && (
          <div className="space-y-2">
            <Label className="text-sm font-medium">Customer Notes:</Label>
            <p className="text-sm text-muted-foreground bg-muted p-2 rounded">
              {order.customer_notes}
            </p>
          </div>
        )}

        {/* Farmer Notes */}
        {order.farmer_notes && (
          <div className="space-y-2">
            <Label className="text-sm font-medium">Your Notes:</Label>
            <p className="text-sm text-muted-foreground bg-blue-50 p-2 rounded">
              {order.farmer_notes}
            </p>
          </div>
        )}

        <Separator />

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-2">
          {order.status === 'pending' && (
            <>
              <Button 
                onClick={handleAcceptOrder}
                disabled={isUpdating}
                size="sm"
                className="flex items-center gap-2"
              >
                <Check className="h-4 w-4" />
                Accept Order
              </Button>
              <Button 
                onClick={handleRejectOrder}
                disabled={isUpdating}
                variant="destructive"
                size="sm"
                className="flex items-center gap-2"
              >
                <X className="h-4 w-4" />
                Reject Order
              </Button>
            </>
          )}

          {/* Status Update Buttons */}
          {canUpdateStatus(order.status) && getNextStatusOptions().map((nextStatus) => (
            <Button
              key={nextStatus}
              onClick={() => updateOrderStatus(nextStatus)}
              disabled={isUpdating}
              variant="outline"
              size="sm"
            >
              Mark as {nextStatus.charAt(0).toUpperCase() + nextStatus.slice(1)}
            </Button>
          ))}

          <Button variant="outline" size="sm" asChild>
            <Link to={`/farmer/orders/${order.id}`}>View timeline</Link>
          </Button>


          {/* Notes Dialog */}
          <Dialog open={showNotesDialog} onOpenChange={setShowNotesDialog}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" className="flex items-center gap-2">
                <MessageCircle className="h-4 w-4" />
                {order.farmer_notes ? 'Edit Notes' : 'Add Notes'}
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Order Notes</DialogTitle>
                <DialogDescription>
                  Add or update notes for this order. These will be visible to you only.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea
                    id="notes"
                    value={farmerNotes}
                    onChange={(e) => setFarmerNotes(e.target.value)}
                    placeholder="Add notes about this order..."
                    rows={4}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setShowNotesDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={handleUpdateNotes} disabled={isUpdating}>
                  Save Notes
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </CardContent>
    </Card>
  );
};