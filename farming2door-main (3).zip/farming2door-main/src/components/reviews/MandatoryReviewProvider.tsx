import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { MandatoryReviewDialog } from './MandatoryReviewDialog';

interface PendingReview {
  orderId: string;
  customerId: string;
}

interface MandatoryReviewContextType {
  showReviewDialog: (orderId: string, customerId: string) => void;
  hideReviewDialog: () => void;
}

const MandatoryReviewContext = createContext<MandatoryReviewContextType | undefined>(undefined);

export const useMandatoryReview = () => {
  const context = useContext(MandatoryReviewContext);
  if (context === undefined) {
    throw new Error('useMandatoryReview must be used within a MandatoryReviewProvider');
  }
  return context;
};

interface MandatoryReviewProviderProps {
  children: ReactNode;
}

export const MandatoryReviewProvider = ({ children }: MandatoryReviewProviderProps) => {
  const [pendingReview, setPendingReview] = useState<PendingReview | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    if (!user) return;

    // Check for any orders that were recently delivered and need reviews
    checkForPendingReviews();

    // Subscribe to order status changes
    const channel = supabase
      .channel('order-status-changes')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'orders',
          filter: `customer_id=eq.${user.id}`
        },
        (payload) => {
          const newOrder = payload.new as any;
          const oldOrder = payload.old as any;
          
          // Check if order status changed to delivered
          if (newOrder.status === 'delivered' && oldOrder.status !== 'delivered') {
            checkIfReviewsNeeded(newOrder.id, newOrder.customer_id);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const checkForPendingReviews = async () => {
    if (!user) return;

    try {
      // Get recently delivered orders that haven't been reviewed
      const { data: deliveredOrders, error } = await supabase
        .from('orders')
        .select(`
          id,
          customer_id,
          created_at,
          order_items (
            id,
            product_name
          )
        `)
        .eq('customer_id', user.id)
        .eq('status', 'delivered')
        .gte('updated_at', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()) // Last 7 days
        .order('updated_at', { ascending: false });

      if (error) throw error;

      // Check each order to see if it has pending reviews
      for (const order of deliveredOrders || []) {
        const hasUnreviewedItems = await checkIfReviewsNeeded(order.id, order.customer_id, false);
        if (hasUnreviewedItems) {
          // Show review dialog for the first order that needs reviews
          showReviewDialog(order.id, order.customer_id);
          break;
        }
      }
    } catch (error) {
      console.error('Error checking for pending reviews:', error);
    }
  };

  const checkIfReviewsNeeded = async (orderId: string, customerId: string, shouldShow: boolean = true) => {
    try {
      // Get all products from this order
      const { data: orderItems, error: itemsError } = await supabase
        .from('order_items')
        .select('product_name')
        .eq('order_id', orderId);

      if (itemsError) throw itemsError;

      if (!orderItems || orderItems.length === 0) return false;

      // Get product IDs for these product names
      const productNames = orderItems.map(item => item.product_name);
      const { data: products, error: productsError } = await supabase
        .from('products')
        .select('id, name')
        .in('name', productNames);

      if (productsError) throw productsError;

      // Check if there are existing reviews for these products from this customer and order
      const productIds = products?.map(p => p.id) || [];
      
      if (productIds.length === 0) return false;

      const { data: existingReviews, error: reviewsError } = await supabase
        .from('reviews')
        .select('product_id')
        .eq('customer_id', customerId)
        .eq('order_id', orderId)
        .in('product_id', productIds);

      if (reviewsError) throw reviewsError;

      const reviewedProductIds = existingReviews?.map(r => r.product_id) || [];
      const hasUnreviewedItems = productIds.some(id => !reviewedProductIds.includes(id));

      if (hasUnreviewedItems && shouldShow) {
        showReviewDialog(orderId, customerId);
      }

      return hasUnreviewedItems;
    } catch (error) {
      console.error('Error checking if reviews needed:', error);
      return false;
    }
  };

  const showReviewDialog = (orderId: string, customerId: string) => {
    setPendingReview({ orderId, customerId });
    setIsDialogOpen(true);
  };

  const hideReviewDialog = () => {
    setIsDialogOpen(false);
    setPendingReview(null);
  };

  return (
    <MandatoryReviewContext.Provider value={{ showReviewDialog, hideReviewDialog }}>
      {children}
      {pendingReview && (
        <MandatoryReviewDialog
          isOpen={isDialogOpen}
          onClose={hideReviewDialog}
          orderId={pendingReview.orderId}
          customerId={pendingReview.customerId}
        />
      )}
    </MandatoryReviewContext.Provider>
  );
};