import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Star } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface OrderItem {
  id: string;
  product_name: string;
  order_id: string;
}

interface Product {
  id: string;
  name: string;
  image_url?: string;
}

interface MandatoryReviewDialogProps {
  isOpen: boolean;
  onClose: () => void;
  orderId: string;
  customerId: string;
}

export const MandatoryReviewDialog = ({ isOpen, onClose, orderId, customerId }: MandatoryReviewDialogProps) => {
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [currentItemIndex, setCurrentItemIndex] = useState(0);
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [comment, setComment] = useState('');
  const [title, setTitle] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen && orderId) {
      fetchOrderItems();
    }
  }, [isOpen, orderId]);

  const fetchOrderItems = async () => {
    try {
      setLoading(true);
      
      // Get order items
      const { data: items, error: itemsError } = await supabase
        .from('order_items')
        .select('id, product_name, order_id')
        .eq('order_id', orderId);

      if (itemsError) throw itemsError;

      if (items && items.length > 0) {
        setOrderItems(items);

        // Get corresponding products
        const productNames = items.map(item => item.product_name);
        const { data: productData, error: productError } = await supabase
          .from('products')
          .select('id, name, image_url')
          .in('name', productNames);

        if (productError) throw productError;
        
        setProducts(productData || []);
      }
    } catch (error) {
      console.error('Error fetching order items:', error);
      toast({
        title: "Error",
        description: "Failed to load order items for review",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitReview = async () => {
    if (rating === 0) {
      toast({
        title: "Rating Required",
        description: "Please select a star rating before submitting",
        variant: "destructive",
      });
      return;
    }

    if (!comment.trim()) {
      toast({
        title: "Comment Required", 
        description: "Please provide a comment with your review",
        variant: "destructive",
      });
      return;
    }

    const currentItem = orderItems[currentItemIndex];
    const currentProduct = products.find(p => p.name === currentItem.product_name);

    if (!currentProduct) {
      toast({
        title: "Error",
        description: "Product not found for review",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const { error } = await supabase
        .from('reviews')
        .insert({
          product_id: currentProduct.id,
          customer_id: customerId,
          order_id: orderId,
          rating: rating,
          title: title.trim() || `Review for ${currentProduct.name}`,
          comment: comment.trim(),
          is_verified: true
        });

      if (error) throw error;

      toast({
        title: "Review Submitted",
        description: `Thank you for reviewing ${currentProduct.name}!`,
      });

      // Move to next item or close dialog
      if (currentItemIndex < orderItems.length - 1) {
        setCurrentItemIndex(currentItemIndex + 1);
        setRating(0);
        setHoveredRating(0);
        setComment('');
        setTitle('');
      } else {
        // All items reviewed
        toast({
          title: "All Reviews Complete",
          description: "Thank you for reviewing all your items!",
        });
        onClose();
      }
    } catch (error) {
      console.error('Error submitting review:', error);
      toast({
        title: "Error",
        description: "Failed to submit review. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleStarClick = (starRating: number) => {
    setRating(starRating);
  };

  const handleStarHover = (starRating: number) => {
    setHoveredRating(starRating);
  };

  const handleStarLeave = () => {
    setHoveredRating(0);
  };

  if (loading) {
    return (
      <Dialog open={isOpen} onOpenChange={() => {}}>
        <DialogContent className="max-w-md">
          <div className="flex justify-center items-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  if (orderItems.length === 0) {
    return null;
  }

  const currentItem = orderItems[currentItemIndex];
  const currentProduct = products.find(p => p.name === currentItem.product_name);
  const progress = ((currentItemIndex + 1) / orderItems.length) * 100;

  return (
    <Dialog open={isOpen} onOpenChange={() => {}}>
      <DialogContent className="max-w-md [&>button]:hidden">
        <DialogHeader>
          <DialogTitle className="text-center">
            Review Your Order
          </DialogTitle>
          <div className="text-sm text-muted-foreground text-center">
            Item {currentItemIndex + 1} of {orderItems.length}
          </div>
          <div className="w-full bg-muted rounded-full h-2 mt-2">
            <div 
              className="bg-primary h-2 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Product Information */}
          <div className="text-center">
            {currentProduct?.image_url && (
              <img 
                src={currentProduct.image_url} 
                alt={currentProduct.name}
                className="w-24 h-24 object-cover rounded-lg mx-auto mb-3"
              />
            )}
            <h3 className="font-semibold text-lg">{currentProduct?.name}</h3>
            <p className="text-muted-foreground text-sm">How was this product?</p>
          </div>

          {/* Star Rating */}
          <div className="flex justify-center space-x-1">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                className="p-1 transition-colors"
                onClick={() => handleStarClick(star)}
                onMouseEnter={() => handleStarHover(star)}
                onMouseLeave={handleStarLeave}
              >
                <Star
                  className={`w-8 h-8 ${
                    star <= (hoveredRating || rating)
                      ? 'fill-yellow-400 text-yellow-400'
                      : 'text-gray-300'
                  } transition-colors`}
                />
              </button>
            ))}
          </div>

          {/* Rating Label */}
          <div className="text-center text-sm text-muted-foreground">
            {rating === 0 && "Click to rate"}
            {rating === 1 && "Poor"}
            {rating === 2 && "Fair"}
            {rating === 3 && "Good"}
            {rating === 4 && "Very Good"}
            {rating === 5 && "Excellent"}
          </div>

          {/* Optional Title */}
          <div>
            <label className="block text-sm font-medium mb-2">
              Review Title (Optional)
            </label>
            <input
              type="text"
              placeholder="Summarize your experience"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              maxLength={100}
            />
          </div>

          {/* Comment */}
          <div>
            <label className="block text-sm font-medium mb-2">
              Tell us more about your experience *
            </label>
            <Textarea
              placeholder="Share your thoughts about this product..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="min-h-[100px] resize-none"
              maxLength={500}
              required
            />
            <div className="text-xs text-muted-foreground text-right mt-1">
              {comment.length}/500 characters
            </div>
          </div>

          {/* Submit Button */}
          <Button
            onClick={handleSubmitReview}
            disabled={isSubmitting || rating === 0 || !comment.trim()}
            className="w-full"
          >
            {isSubmitting ? "Submitting..." : 
             currentItemIndex < orderItems.length - 1 ? "Submit & Next" : "Submit Review"}
          </Button>

          <div className="text-xs text-center text-muted-foreground">
            Please complete reviews for all items to continue using the app
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};