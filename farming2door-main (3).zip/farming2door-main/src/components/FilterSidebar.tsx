import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { MapPin, Truck, ShieldCheck, X, Tags } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface FilterSidebarProps {
  filters: {
    distance: number;
    deliveryAvailable: boolean;
    priceRange: [number, number];
    certifications: string[];
    animalPortion: string[];
    subcategories: string[];
  };
  onFiltersChange: (filters: any) => void;
  onClearFilters: () => void;
}

const certificationOptions = [
  { id: "organic", label: "Organic", icon: ShieldCheck },
  { id: "halal", label: "Halal", icon: ShieldCheck },
  { id: "kosher", label: "Kosher", icon: ShieldCheck },
  { id: "grass-fed", label: "Grass-fed", icon: ShieldCheck },
];

const animalPortionOptions = [
  { id: "whole", label: "Whole Animal" },
  { id: "half", label: "Half Animal" },
  { id: "quarter", label: "Quarter Animal" },
];

export default function FilterSidebar({ filters, onFiltersChange, onClearFilters }: FilterSidebarProps) {
  const [subcategories, setSubcategories] = useState<{id: string, name: string}[]>([]);

  useEffect(() => {
    fetchSubcategories();
  }, []);

  const fetchSubcategories = async () => {
    try {
      const { data, error } = await supabase
        .from('subcategories')
        .select('id, name')
        .eq('is_active', true)
        .order('name');

      if (error) throw error;
      setSubcategories(data || []);
    } catch (error) {
      console.error('Error fetching subcategories:', error);
    }
  };

  const hasActiveFilters = 
    filters.distance < 400 || 
    filters.deliveryAvailable || 
    filters.priceRange[0] > 0 || 
    filters.priceRange[1] < 10000 ||
    filters.certifications.length > 0 ||
    filters.animalPortion.length > 0 ||
    filters.subcategories.length > 0;

  const handleDistanceChange = (value: number[]) => {
    onFiltersChange({ ...filters, distance: value[0] });
  };

  const handleDeliveryToggle = (checked: boolean) => {
    onFiltersChange({ ...filters, deliveryAvailable: checked });
  };

  const handlePriceRangeChange = (value: number[]) => {
    onFiltersChange({ ...filters, priceRange: value as [number, number] });
  };

  const handleCertificationToggle = (certification: string, checked: boolean) => {
    const newCertifications = checked 
      ? [...filters.certifications, certification]
      : filters.certifications.filter(c => c !== certification);
    onFiltersChange({ ...filters, certifications: newCertifications });
  };

  const handleAnimalPortionToggle = (portion: string, checked: boolean) => {
    const newPortions = checked 
      ? [...filters.animalPortion, portion]
      : filters.animalPortion.filter(p => p !== portion);
    onFiltersChange({ ...filters, animalPortion: newPortions });
  };

  const handleSubcategoryToggle = (subcategory: string, checked: boolean) => {
    const newSubcategories = checked 
      ? [...filters.subcategories, subcategory]
      : filters.subcategories.filter(s => s !== subcategory);
    onFiltersChange({ ...filters, subcategories: newSubcategories });
  };

  return (
    <Card className="sticky top-4">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Filters</CardTitle>
          {hasActiveFilters && (
            <Button variant="ghost" size="sm" onClick={onClearFilters}>
              <X className="h-4 w-4 mr-1" />
              Clear
            </Button>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Distance Filter */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            <span className="font-medium">Distance</span>
          </div>
            <div className="space-y-2">
              <Slider
                value={[filters.distance]}
                onValueChange={handleDistanceChange}
                max={400}
                min={0}
                step={10}
                className="w-full"
              />
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>0mi</span>
                <span>{filters.distance}mi</span>
                <span>400mi+</span>
              </div>
            </div>
        </div>

        <Separator />

        {/* Delivery Available */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Truck className="h-4 w-4" />
              <span className="font-medium">Delivery Available</span>
            </div>
            <Checkbox
              checked={filters.deliveryAvailable}
              onCheckedChange={handleDeliveryToggle}
            />
          </div>
        </div>

        <Separator />

        {/* Price Range */}
        <div className="space-y-3">
          <span className="font-medium">Price Range</span>
          <div className="space-y-2">
            <Slider
              value={filters.priceRange}
              onValueChange={handlePriceRangeChange}
              max={10000}
              min={0}
              step={100}
              className="w-full"
            />
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>${filters.priceRange[0].toLocaleString()}</span>
              <span>${filters.priceRange[1].toLocaleString()}</span>
            </div>
          </div>
        </div>

        <Separator />

        {/* Certifications */}
        <div className="space-y-3">
          <span className="font-medium">Certifications</span>
          <div className="space-y-2">
            {certificationOptions.map((cert) => (
              <div key={cert.id} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <cert.icon className="h-4 w-4" />
                  <span className="text-sm">{cert.label}</span>
                </div>
                <Checkbox
                  checked={filters.certifications.includes(cert.id)}
                  onCheckedChange={(checked) => handleCertificationToggle(cert.id, checked as boolean)}
                />
              </div>
            ))}
          </div>
        </div>

        <Separator />

        {/* Subcategories */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <Tags className="h-4 w-4" />
            <span className="font-medium">Subcategories</span>
          </div>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {subcategories.map((subcategory) => (
              <div key={subcategory.id} className="flex items-center justify-between">
                <span className="text-sm">{subcategory.name}</span>
                <Checkbox
                  checked={filters.subcategories.includes(subcategory.name)}
                  onCheckedChange={(checked) => handleSubcategoryToggle(subcategory.name, checked as boolean)}
                />
              </div>
            ))}
          </div>
        </div>

        <Separator />

        {/* Animal Portion */}
        <div className="space-y-3">
          <span className="font-medium">Animal Portion</span>
          <div className="space-y-2">
            {animalPortionOptions.map((portion) => (
              <div key={portion.id} className="flex items-center justify-between">
                <span className="text-sm">{portion.label}</span>
                <Checkbox
                  checked={filters.animalPortion.includes(portion.id)}
                  onCheckedChange={(checked) => handleAnimalPortionToggle(portion.id, checked as boolean)}
                />
              </div>
            ))}
          </div>
        </div>

        {/* Active Filters Summary */}
        {hasActiveFilters && (
          <>
            <Separator />
            <div className="space-y-2">
              <span className="font-medium text-sm">Active Filters:</span>
              <div className="flex flex-wrap gap-1">
              {filters.distance < 400 && (
                <Badge variant="secondary">Within {filters.distance}mi</Badge>
              )}
                {filters.deliveryAvailable && (
                  <Badge variant="secondary">Delivery Available</Badge>
                )}
                {filters.certifications.map(cert => (
                  <Badge key={cert} variant="secondary">{cert}</Badge>
                ))}
                 {filters.animalPortion.map(portion => (
                   <Badge key={portion} variant="secondary">{portion}</Badge>
                 ))}
                 {filters.subcategories.map(subcategory => (
                   <Badge key={subcategory} variant="secondary">{subcategory}</Badge>
                 ))}
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}