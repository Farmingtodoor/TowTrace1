import { Card } from "@/components/ui/card";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export default function UserStatsCards() {
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    suspended: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUserStats();
  }, []);

  const fetchUserStats = async () => {
    try {
      setLoading(true);
      
      // Get total users
      const { count: totalUsers } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true });

      // Get active users
      const { count: activeUsers } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'active');

      // Get suspended users
      const { count: suspendedUsers } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'suspended');

      setStats({
        total: totalUsers || 0,
        active: activeUsers || 0,
        suspended: suspendedUsers || 0
      });
    } catch (error) {
      console.error('Error fetching user stats:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {Array.from({ length: 3 }).map((_, i) => (
          <Card key={i} className="p-4 animate-pulse">
            <div className="text-center">
              <div className="h-4 bg-muted rounded w-1/2 mx-auto mb-2"></div>
              <div className="h-8 bg-muted rounded w-1/3 mx-auto"></div>
            </div>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <Card className="p-4">
        <div className="text-center">
          <h3 className="font-semibold">Total Users</h3>
          <p className="text-2xl font-bold text-primary">{stats.total}</p>
        </div>
      </Card>
      <Card className="p-4">
        <div className="text-center">
          <h3 className="font-semibold">Active Users</h3>
          <p className="text-2xl font-bold text-green-600">{stats.active}</p>
        </div>
      </Card>
      <Card className="p-4">
        <div className="text-center">
          <h3 className="font-semibold">Suspended Users</h3>
          <p className="text-2xl font-bold text-red-600">{stats.suspended}</p>
        </div>
      </Card>
    </div>
  );
}