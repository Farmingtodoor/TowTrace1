import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Upload, X, Image, Video, FileImage, FileVideo } from "lucide-react";

interface MediaFile {
  url: string;
  type: 'image' | 'video';
  name: string;
}

interface MediaUploadProps {
  images: MediaFile[];
  videos: MediaFile[];
  onImagesChange: (images: MediaFile[]) => void;
  onVideosChange: (videos: MediaFile[]) => void;
  userId: string;
}

export default function MediaUpload({ 
  images, 
  videos, 
  onImagesChange, 
  onVideosChange, 
  userId 
}: MediaUploadProps) {
  const [uploading, setUploading] = useState(false);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>, type: 'image' | 'video') => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    setUploading(true);
    const uploadPromises = Array.from(files).map(async (file) => {
      try {
        const fileExt = file.name.split('.').pop();
        const fileName = `${userId}/${Date.now()}-${Math.random()}.${fileExt}`;
        const bucketName = type === 'image' ? 'product-images' : 'product-videos';

        // Validate file size (10MB for images, 50MB for videos)
        const maxSize = type === 'image' ? 10 * 1024 * 1024 : 50 * 1024 * 1024;
        if (file.size > maxSize) {
          throw new Error(`${type === 'image' ? 'Image' : 'Video'} must be smaller than ${type === 'image' ? '10MB' : '50MB'}`);
        }

        const { error: uploadError } = await supabase.storage
          .from(bucketName)
          .upload(fileName, file);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from(bucketName)
          .getPublicUrl(fileName);

        return {
          url: publicUrl,
          type,
          name: file.name
        } as MediaFile;
      } catch (error: any) {
        console.error(`Error uploading ${type}:`, error);
        toast.error(`Failed to upload ${file.name}: ${error.message}`);
        return null;
      }
    });

    try {
      const results = await Promise.all(uploadPromises);
      const successfulUploads = results.filter((result): result is MediaFile => result !== null);
      
      if (type === 'image') {
        onImagesChange([...images, ...successfulUploads]);
      } else {
        onVideosChange([...videos, ...successfulUploads]);
      }

      if (successfulUploads.length > 0) {
        toast.success(`Successfully uploaded ${successfulUploads.length} ${type}(s)`);
      }
    } catch (error) {
      console.error('Upload error:', error);
    } finally {
      setUploading(false);
      // Reset input
      event.target.value = '';
    }
  };

  const removeMedia = (mediaToRemove: MediaFile, type: 'image' | 'video') => {
    if (type === 'image') {
      onImagesChange(images.filter(img => img.url !== mediaToRemove.url));
    } else {
      onVideosChange(videos.filter(vid => vid.url !== mediaToRemove.url));
    }
  };

  return (
    <div className="space-y-6">
      {/* Image Upload Section */}
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <Image className="h-4 w-4" />
          <Label className="text-base font-medium">Product Images</Label>
        </div>
        
        <div className="flex items-center gap-4">
          <Input
            type="file"
            accept="image/*"
            multiple
            onChange={(e) => handleFileUpload(e, 'image')}
            disabled={uploading}
            className="flex-1"
          />
          <Button 
            type="button"
            variant="outline" 
            disabled={uploading}
            onClick={() => document.querySelector<HTMLInputElement>('input[accept="image/*"]')?.click()}
          >
            <Upload className="h-4 w-4 mr-2" />
            {uploading ? 'Uploading...' : 'Add Images'}
          </Button>
        </div>
        
        {images.length > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {images.map((image, index) => (
              <div key={index} className="relative group">
                <img
                  src={image.url}
                  alt={`Product image ${index + 1}`}
                  className="w-full h-32 object-cover rounded-lg border"
                />
                <Button
                  type="button"
                  variant="destructive"
                  size="sm"
                  className="absolute top-1 right-1 h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => removeMedia(image, 'image')}
                >
                  <X className="h-3 w-3" />
                </Button>
                <div className="absolute bottom-1 left-1 right-1">
                  <div className="bg-black/50 text-white text-xs p-1 rounded truncate">
                    {image.name}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
        
        <p className="text-sm text-muted-foreground flex items-center gap-1">
          <FileImage className="h-3 w-3" />
          Upload multiple images (max 10MB each). Supported formats: JPG, PNG, WebP
        </p>
      </div>

      {/* Video Upload Section */}
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <Video className="h-4 w-4" />
          <Label className="text-base font-medium">Product Videos</Label>
        </div>
        
        <div className="flex items-center gap-4">
          <Input
            type="file"
            accept="video/*"
            multiple
            onChange={(e) => handleFileUpload(e, 'video')}
            disabled={uploading}
            className="flex-1"
          />
          <Button 
            type="button"
            variant="outline" 
            disabled={uploading}
            onClick={() => document.querySelector<HTMLInputElement>('input[accept="video/*"]')?.click()}
          >
            <Upload className="h-4 w-4 mr-2" />
            {uploading ? 'Uploading...' : 'Add Videos'}
          </Button>
        </div>
        
        {videos.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {videos.map((video, index) => (
              <div key={index} className="relative group">
                <video
                  src={video.url}
                  className="w-full h-48 object-cover rounded-lg border"
                  controls
                  preload="metadata"
                />
                <Button
                  type="button"
                  variant="destructive"
                  size="sm"
                  className="absolute top-1 right-1 h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => removeMedia(video, 'video')}
                >
                  <X className="h-3 w-3" />
                </Button>
                <div className="absolute bottom-1 left-1 right-1">
                  <div className="bg-black/50 text-white text-xs p-1 rounded truncate">
                    {video.name}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
        
        <p className="text-sm text-muted-foreground flex items-center gap-1">
          <FileVideo className="h-3 w-3" />
          Upload videos (max 50MB each). Supported formats: MP4, WebM, MOV
        </p>
      </div>
    </div>
  );
}