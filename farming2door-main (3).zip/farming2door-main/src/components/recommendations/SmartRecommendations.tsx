import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import ProductCard from '@/components/ProductCard';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Sparkles, TrendingUp, Calendar, Leaf } from 'lucide-react';
import { Json } from '@/integrations/supabase/types';

interface Product {
  id: string;
  name: string;
  price: number;
  image_url: string;
  farmer: string;
  category: string;
  is_organic: boolean;
  harvest_date: string;
  farmer_id: string;
  stock_quantity: number;
  images: Json;
  videos: Json;
  [key: string]: any;
}

interface RecommendationSection {
  title: string;
  icon: React.ReactNode;
  products: Product[];
  type: 'frequently_bought' | 'seasonal' | 'personalized' | 'trending';
}

interface SmartRecommendationsProps {
  currentProductId?: string;
  currentCategory?: string;
}

const SmartRecommendations: React.FC<SmartRecommendationsProps> = ({ 
  currentProductId, 
  currentCategory 
}) => {
  const { user } = useAuth();
  const [recommendations, setRecommendations] = useState<RecommendationSection[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRecommendations();
  }, [currentProductId, user]);

  const fetchRecommendations = async () => {
    try {
      setLoading(true);
      const sections: RecommendationSection[] = [];

      // 1. Frequently bought together (if viewing a product)
      if (currentProductId) {
        const frequentlyBought = await fetchFrequentlyBoughtTogether(currentProductId);
        if (frequentlyBought.length > 0) {
          sections.push({
            title: 'Customers who bought this also enjoyed',
            icon: <TrendingUp className="w-4 h-4" />,
            products: frequentlyBought,
            type: 'frequently_bought'
          });
        }
      }

      // 2. Seasonal/Harvest recommendations
      const seasonalProducts = await fetchSeasonalRecommendations();
      if (seasonalProducts.length > 0) {
        sections.push({
          title: 'Fresh Harvest - Available Now',
          icon: <Calendar className="w-4 h-4" />,
          products: seasonalProducts,
          type: 'seasonal'
        });
      }

      // 3. Personalized recommendations (for logged-in users)
      if (user) {
        const personalizedProducts = await fetchPersonalizedRecommendations();
        if (personalizedProducts.length > 0) {
          sections.push({
            title: 'Recommended for You',
            icon: <Sparkles className="w-4 h-4" />,
            products: personalizedProducts,
            type: 'personalized'
          });
        }
      }

      // 4. Trending organic products
      const trendingOrganic = await fetchTrendingOrganic();
      if (trendingOrganic.length > 0) {
        sections.push({
          title: 'Trending Organic Products',
          icon: <Leaf className="w-4 h-4" />,
          products: trendingOrganic,
          type: 'trending'
        });
      }

      setRecommendations(sections);
    } catch (error) {
      console.error('Error fetching recommendations:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchFrequentlyBoughtTogether = async (productId: string): Promise<Product[]> => {
    const { data, error } = await supabase.rpc('get_product_recommendations', {
      p_product_id: productId,
      p_limit: 4
    });

    if (error || !data) return [];

    // Get full product details
    const productIds = data.map((item: any) => item.product_id);
    const { data: products } = await supabase
      .from('products')
      .select('*')
      .in('id', productIds)
      .eq('is_available', true)
      .limit(4);

    return products || [];
  };

  const fetchSeasonalRecommendations = async (): Promise<Product[]> => {
    // Get products harvested in the last 7 days or with harvest dates in the near future
    const today = new Date();
    const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
    const weekAhead = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);

    const { data, error } = await supabase
      .from('products')
      .select('*')
      .eq('is_available', true)
      .gte('harvest_date', weekAgo.toISOString().split('T')[0])
      .lte('harvest_date', weekAhead.toISOString().split('T')[0])
      .order('harvest_date', { ascending: false })
      .limit(6);

    if (error) return [];
    return data || [];
  };

  const fetchPersonalizedRecommendations = async (): Promise<Product[]> => {
    if (!user) return [];

    // Get user's purchase history to understand preferences
    const { data: orderHistory } = await supabase
      .from('order_items')
      .select(`
        product_name,
        orders!inner(customer_id, created_at)
      `)
      .eq('orders.customer_id', user.id)
      .order('orders.created_at', { ascending: false })
      .limit(20);

    if (!orderHistory || orderHistory.length === 0) {
      // New user - recommend popular products
      const { data } = await supabase
        .from('products')
        .select('*')
        .eq('is_available', true)
        .gte('average_rating', 4.0)
        .order('review_count', { ascending: false })
        .limit(4);
      return data || [];
    }

    // Get categories user has purchased from
    const purchasedCategories = [...new Set(orderHistory.map(item => 
      item.product_name.toLowerCase()
    ))];

    // Find similar products in those categories
    const { data } = await supabase
      .from('products')
      .select('*')
      .eq('is_available', true)
      .gte('stock_quantity', 1)
      .order('average_rating', { ascending: false })
      .limit(6);

    return data || [];
  };

  const fetchTrendingOrganic = async (): Promise<Product[]> => {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .eq('is_available', true)
      .eq('is_organic', true)
      .gte('stock_quantity', 1)
      .order('review_count', { ascending: false })
      .limit(4);

    if (error) return [];
    return data || [];
  };

  if (loading) {
    return (
      <div className="space-y-6">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader>
              <div className="h-6 bg-muted rounded w-1/3"></div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {[1, 2, 3, 4].map((j) => (
                  <div key={j} className="h-64 bg-muted rounded"></div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (recommendations.length === 0) {
    return null;
  }

  return (
    <div className="space-y-8">
      {recommendations.map((section, index) => (
        <Card key={index} className="overflow-hidden">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-lg">
              {section.icon}
              {section.title}
              {section.type === 'seasonal' && (
                <Badge variant="secondary" className="ml-2">
                  Fresh
                </Badge>
              )}
              {section.type === 'trending' && (
                <Badge variant="secondary" className="ml-2 bg-green-100 text-green-800">
                  Organic
                </Badge>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {section.products.map((product) => {
                // Parse JSON fields safely
                const images = Array.isArray(product.images) ? product.images : 
                  (typeof product.images === 'string' ? JSON.parse(product.images || '[]') : []);
                const videos = Array.isArray(product.videos) ? product.videos :
                  (typeof product.videos === 'string' ? JSON.parse(product.videos || '[]') : []);
                
                return (
                  <ProductCard
                    key={product.id}
                    id={product.id}
                    name={product.name}
                    farmer={product.farmer}
                    location="Local Area"
                    price={product.price.toString()}
                    rating={product.average_rating || 0}
                    reviewCount={product.review_count || 0}
                    image={product.image_url || (images[0]?.url || '')}
                    images={images}
                    videos={videos}
                    category={product.category}
                    isOrganic={product.is_organic}
                    inStock={product.stock_quantity > 0}
                    unit={product.unit || 'lb'}
                    certifications={
                      (() => {
                        if (!product.certifications) return [];
                        if (Array.isArray(product.certifications)) return product.certifications as string[];
                        if (typeof product.certifications === 'string') {
                          try {
                            return JSON.parse(product.certifications);
                          } catch {
                            return [];
                          }
                        }
                        return [];
                      })()
                    }
                    farmerId={product.farmer_id}
                  />
                );
              })}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default SmartRecommendations;