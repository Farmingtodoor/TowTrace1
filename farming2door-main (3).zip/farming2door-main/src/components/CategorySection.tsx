import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { ArrowRight, Beef, Carrot, Milk, Wheat } from "lucide-react";
import produceImage from "@/assets/produce-vegetables.jpg";
import livestockImage from "@/assets/meat-livestock.jpg";

const categories = [
  {
    id: 1,
    name: "Fresh Produce",
    description: "Seasonal fruits, vegetables, and herbs picked at peak freshness",
    icon: Carrot,
    image: produceImage,
    count: "150+ items",
    color: "accent-sage"
  },
  {
    id: 2,
    name: "Premium Livestock",
    description: "Grass-fed beef, free-range poultry, and custom processing options",
    icon: Beef,
    image: livestockImage,
    count: "50+ farmers",
    color: "accent-warm"
  },
  {
    id: 3,
    name: "Dairy & Eggs",
    description: "Fresh milk, artisanal cheese, and farm-fresh eggs",
    icon: Milk,
    image: produceImage,
    count: "25+ products",
    color: "primary"
  },
  {
    id: 4,
    name: "Grains & Pantry",
    description: "Freshly milled flour, ancient grains, and farm pantry staples",
    icon: Wheat,
    image: livestockImage,
    count: "40+ items",
    color: "accent-warm"
  }
];

const CategorySection = () => {
  const navigate = useNavigate();

  const handleCategoryClick = (categoryName: string) => {
    // Convert category name to URL-friendly format that Browse page can parse back
    const categoryParam = categoryName
      .toLowerCase()
      .replace(/\s+/g, '-')
      .replace('&', 'and');
    
    navigate(`/shop?category=${categoryParam}`);
  };

  return (
    <section className="py-20 bg-gradient-to-b from-background to-accent/10">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Shop by Category
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover fresh, high-quality products directly from local farmers and producers
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {categories.map((category) => {
            const IconComponent = category.icon;
            return (
              <Card key={category.id} className="group hover:shadow-xl transition-all duration-300 cursor-pointer border-0 shadow-soft" onClick={() => handleCategoryClick(category.name)}>
                <CardContent className="p-0">
                  <div className="relative overflow-hidden rounded-t-lg">
                    <img
                      src={category.image}
                      alt={category.name}
                      className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                    <div className="absolute bottom-4 left-4 text-white">
                      <IconComponent className="h-8 w-8 mb-2" />
                      <p className="text-sm font-medium">{category.count}</p>
                    </div>
                  </div>
                  
                  <div className="p-6 space-y-4">
                    <h3 className="text-xl font-semibold text-foreground group-hover:text-primary transition-colors">
                      {category.name}
                    </h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      {category.description}
                    </p>
                    <Button variant="ghost" className="w-full justify-between p-0 h-auto font-medium" onClick={(e) => {
                      e.stopPropagation();
                      handleCategoryClick(category.name);
                    }}>
                      Shop Category
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default CategorySection;