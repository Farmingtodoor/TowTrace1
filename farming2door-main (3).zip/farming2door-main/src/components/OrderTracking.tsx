import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { DeliveryMap } from './DeliveryMap';
import { Phone, MessageCircle, MapPin, Clock, User, Truck } from 'lucide-react';
import { toast } from 'sonner';

interface OrderTrackingProps {
  orderId: string;
  onClose?: () => void;
}

interface OrderDetails {
  id: string;
  status: string;
  delivery_address: string;
  customer_notes?: string;
  total_amount: number;
  delivery_fee: number;
  pickup_latitude?: number;
  pickup_longitude?: number;
  delivery_latitude?: number;
  delivery_longitude?: number;
  created_at: string;
}

interface DriverAssignment {
  id: string;
  driver_id: string;
  order_id: string;
  status: string;
  assigned_at: string;
  picked_up_at?: string;
  delivered_at?: string;
  driver_earnings: number;
}

interface DriverInfo {
  driver_id: string;
  first_name: string;
  vehicle_type: string;
  current_latitude?: number;
  current_longitude?: number;
  rating: number;
}

export function OrderTracking({ orderId, onClose }: OrderTrackingProps) {
  const [order, setOrder] = useState<OrderDetails | null>(null);
  const [assignment, setAssignment] = useState<DriverAssignment | null>(null);
  const [driverInfo, setDriverInfo] = useState<DriverInfo | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchOrderDetails();
    
    // Set up real-time subscription for order updates
    const orderSubscription = supabase
      .channel(`order-${orderId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'orders',
          filter: `id=eq.${orderId}`
        },
        (payload) => {
          setOrder(prev => prev ? { ...prev, ...payload.new } : null);
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'driver_order_assignments',
          filter: `order_id=eq.${orderId}`
        },
        (payload) => {
          setAssignment(prev => prev ? { ...prev, ...payload.new } : null);
        }
      )
      .subscribe();

    return () => {
      orderSubscription.unsubscribe();
    };
  }, [orderId]);

  const fetchOrderDetails = async () => {
    try {
      // Fetch order details
      const { data: orderData, error: orderError } = await supabase
        .from('orders')
        .select('*')
        .eq('id', orderId)
        .single();

      if (orderError) throw orderError;
      setOrder(orderData);

      // Get driver assignment for this order (basic info only)
      const { data: assignmentData, error: assignmentError } = await supabase
        .from('driver_order_assignments')
        .select('*')
        .eq('order_id', orderId)
        .maybeSingle();

      if (assignmentError && assignmentError.code !== 'PGRST116') {
        throw assignmentError;
      }

      if (assignmentData) {
        setAssignment(assignmentData as DriverAssignment);

        // Get secure driver info for customer order tracking
        try {
          const { data: driverData, error: driverError } = await supabase.rpc(
            'get_driver_info_for_customer_order',
            { order_id_param: orderId }
          );

          if (driverError) {
            console.warn('Could not fetch driver info:', driverError.message);
          } else if (driverData && driverData.length > 0) {
            setDriverInfo(driverData[0]);
          }
        } catch (error) {
          console.warn('Driver info access restricted or unavailable');
        }
      }
    } catch (error: any) {
      toast.error(error.message || 'Failed to load order details');
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'pending': return 'secondary';
      case 'assigned_driver':
      case 'assigned': return 'default';
      case 'picked_up': return 'default';
      case 'in_transit': return 'default';
      case 'delivered': return 'default';
      case 'cancelled': return 'destructive';
      default: return 'secondary';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'Order Placed';
      case 'assigned_driver': return 'Driver Assigned';
      case 'assigned': return 'Driver Assigned';
      case 'picked_up': return 'Picked Up';
      case 'in_transit': return 'In Transit';
      case 'delivered': return 'Delivered';
      case 'cancelled': return 'Cancelled';
      default: return status;
    }
  };

  const initiateCall = (phoneNumber: string) => {
    window.location.href = `tel:${phoneNumber}`;
  };

  const initiateChat = () => {
    // In a real app, this would open a chat interface
    toast.info('Chat feature coming soon!');
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center p-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </CardContent>
      </Card>
    );
  }

  if (!order) {
    return (
      <Card>
        <CardContent className="text-center p-8">
          <p>Order not found</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {onClose && (
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold">Order Tracking</h2>
          <Button variant="outline" onClick={onClose}>Close</Button>
        </div>
      )}

      {/* Order Status */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle>Order #{order.id.slice(-6)}</CardTitle>
              <CardDescription>
                Placed on {new Date(order.created_at).toLocaleDateString()}
              </CardDescription>
            </div>
            <Badge variant={getStatusBadgeVariant(assignment?.status || order.status)}>
              {getStatusText(assignment?.status || order.status)}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center space-x-2">
              <MapPin className="w-4 h-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">Delivery Address</p>
                <p className="text-sm text-muted-foreground">{order.delivery_address}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">Total Amount</p>
                <p className="text-sm text-muted-foreground">
                  ${order.total_amount} + ${order.delivery_fee} delivery
                </p>
              </div>
            </div>
            {order.customer_notes && (
              <div>
                <p className="text-sm font-medium">Notes</p>
                <p className="text-sm text-muted-foreground">{order.customer_notes}</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Driver Information */}
      {assignment && driverInfo && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Truck className="w-5 h-5" />
              <span>Your Driver</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-between items-start">
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <User className="w-4 h-4 text-muted-foreground" />
                  <span className="font-medium">{driverInfo.first_name}</span>
                  <Badge variant="outline">
                    ⭐ {driverInfo.rating.toFixed(1)}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  {driverInfo.vehicle_type}
                </p>
                {assignment.assigned_at && (
                  <p className="text-sm text-muted-foreground">
                    Assigned: {new Date(assignment.assigned_at).toLocaleString()}
                  </p>
                )}
                {assignment.picked_up_at && (
                  <p className="text-sm text-muted-foreground">
                    Picked up: {new Date(assignment.picked_up_at).toLocaleString()}
                  </p>
                )}
              </div>
              
              <div className="flex space-x-2">
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={initiateChat}
                  title="Contact driver through the app"
                >
                  <MessageCircle className="w-4 h-4 mr-1" />
                  Contact Driver
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Delivery Map */}
      <Card>
        <CardHeader>
          <CardTitle>Live Tracking</CardTitle>
          <CardDescription>Follow your delivery in real-time</CardDescription>
        </CardHeader>
        <CardContent>
          <DeliveryMap
            assignments={assignment ? [{
              id: assignment.id,
              order_id: order.id,
              status: assignment.status,
              order: {
                delivery_address: order.delivery_address
              },
              pickup_latitude: order.pickup_latitude,
              pickup_longitude: order.pickup_longitude,
              delivery_latitude: order.delivery_latitude,
              delivery_longitude: order.delivery_longitude
            }] : []}
            driverLocation={
              driverInfo?.current_latitude && driverInfo?.current_longitude
                ? {
                    lat: driverInfo.current_latitude,
                    lng: driverInfo.current_longitude
                  }
                : undefined
            }
            height="300px"
          />
        </CardContent>
      </Card>
    </div>
  );
}