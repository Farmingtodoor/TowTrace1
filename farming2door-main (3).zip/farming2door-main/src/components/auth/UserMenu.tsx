import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useAuth } from "@/contexts/AuthContext"
import { useAdmin } from "@/contexts/AdminContext"
import { useToast } from "@/hooks/use-toast"
import { User, LogOut, ShoppingBag, Settings, Shield, Package, FileText, ClipboardList, MessageCircle, Gift, Repeat, Tag, Clock, Truck } from "lucide-react"
import { useNavigate } from "react-router-dom"

export const UserMenu = () => {
  const { user, signOut } = useAuth()
  const { isAdmin, isFarmer } = useAdmin()
  const { toast } = useToast()
  const navigate = useNavigate()

  const handleSignOut = async () => {
    const { error } = await signOut()
    
    if (error) {
      toast({
        title: "Error signing out",
        description: error.message,
        variant: "destructive",
      })
    } else {
      toast({
        title: "Signed out",
        description: "You've been successfully signed out.",
      })
    }
  }

  const handleMyOrders = () => {
    navigate('/my-orders')
  }

  const handleAccountSettings = () => {
    navigate('/account-settings')
  }

  const handleAdminPanel = () => {
    navigate('/admin')
  }

  const handleMyProducts = () => {
    navigate('/farmer-products')
  }

  const handleCustomOrders = () => {
    navigate('/custom-orders')
  }

  const handleFarmerCustomOrders = () => {
    navigate('/farmer/custom-orders')
  }

  const handleFarmerOrders = () => {
    navigate('/farmer/orders')
  }

  const handleMessages = () => {
    navigate('/messages')
  }

  const handleReferrals = () => {
    navigate('/referrals')
  }

  const handleFarmerSubscriptions = () => {
    navigate('/farmer-subscriptions')
  }

  const handleFarmerPromotions = () => {
    navigate('/farmer-promotions')
  }

  const handlePickupAvailability = () => {
    navigate('/farmer-pickup-availability')
  }

  const handleDeliverySettings = () => {
    navigate('/farmer-delivery-settings')
  }


  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon">
          <User className="h-5 w-5" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56" align="end">
        <DropdownMenuLabel>
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium">My Account</p>
            <p className="text-xs text-muted-foreground">{user?.email}</p>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={handleMyOrders}>
          <ShoppingBag className="mr-2 h-4 w-4" />
          <span>My Orders</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleCustomOrders}>
          <FileText className="mr-2 h-4 w-4" />
          <span>Custom Orders</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleMessages}>
          <MessageCircle className="mr-2 h-4 w-4" />
          <span>Messages</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleReferrals}>
          <Gift className="mr-2 h-4 w-4" />
          <span>Referrals</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleAccountSettings}>
          <Settings className="mr-2 h-4 w-4" />
          <span>Account Settings</span>
        </DropdownMenuItem>
        {isFarmer && (
          <>
            <DropdownMenuItem onClick={handleMyProducts}>
              <Package className="mr-2 h-4 w-4" />
              <span>My Products</span>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handleFarmerOrders}>
              <Package className="mr-2 h-4 w-4" />
              <span>Customer Orders</span>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handleFarmerCustomOrders}>
              <ClipboardList className="mr-2 h-4 w-4" />
              <span>Custom Requests</span>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handleFarmerSubscriptions}>
              <Repeat className="mr-2 h-4 w-4" />
              <span>Subscription Plans</span>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handleFarmerPromotions}>
              <Tag className="mr-2 h-4 w-4" />
              <span>Promotions & Discounts</span>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handlePickupAvailability}>
              <Clock className="mr-2 h-4 w-4" />
              <span>Pickup Availability</span>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handleDeliverySettings}>
              <Truck className="mr-2 h-4 w-4" />
              <span>Delivery Settings</span>
            </DropdownMenuItem>
          </>
        )}
        {(isAdmin || isFarmer) && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleAdminPanel}>
              <Shield className="mr-2 h-4 w-4" />
              <span>Admin Panel</span>
            </DropdownMenuItem>
          </>
        )}
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={handleSignOut}>
          <LogOut className="mr-2 h-4 w-4" />
          <span>Sign Out</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}