import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Separator } from "@/components/ui/separator";
import { Menu, X, Leaf, User, ShoppingBag } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate, useLocation } from "react-router-dom";
import { useAdmin } from "@/contexts/AdminContext";
import { AuthDialog } from "@/components/auth/AuthDialog";
import { UserMenu } from "@/components/auth/UserMenu";
import { supabase } from "@/integrations/supabase/client";

interface Category {
  id: string;
  name: string;
}

export const MobileMenu = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { user, loading } = useAuth();
  const { isFarmer } = useAdmin();
  const navigate = useNavigate();
  const location = useLocation();
  const [categories, setCategories] = useState<Category[]>([]);

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('categories')
        .select('id, name')
        .eq('is_active', true)
        .order('display_order');

      if (error) throw error;
      setCategories(data || []);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const handleNavClick = (path: string) => {
    navigate(path);
    setIsOpen(false);
  };

  const handleSellClick = () => {
    navigate('/farmer-onboarding');
    setIsOpen(false);
  };

  const navItems = [
    { label: "Shop", path: "/shop" },
    { label: "Breeding Stock", path: "/breeding-stock" },
    { label: "Farmers", path: "/farmers" },
    { label: "About", path: "/about" },
    { label: "How it Works", path: "/how-it-works" },
  ];

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden">
          <Menu className="h-5 w-5" />
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="w-[300px] sm:w-[400px]">
        <SheetHeader className="text-left">
          <SheetTitle className="flex items-center gap-2">
            <Leaf className="h-6 w-6 text-primary" />
            Farming2Door
          </SheetTitle>
        </SheetHeader>

        <div className="flex flex-col h-full">
          {/* Navigation */}
          <nav className="flex-1 py-6">
            <div className="space-y-1">
              {navItems.map((item) => (
                <Button
                  key={item.path}
                  variant="ghost"
                  className={`w-full justify-start text-base h-12 ${
                    location.pathname === item.path ? 'bg-primary/10 text-primary' : ''
                  }`}
                  onClick={() => handleNavClick(item.path)}
                >
                  {item.label}
                </Button>
              ))}
            </div>

            <Separator className="my-6" />

            {/* Categories */}
            <div className="space-y-1">
              <h4 className="text-sm font-medium text-muted-foreground px-3 py-2">
                Shop Categories
              </h4>
              {categories.map((category) => (
                <Button
                  key={category.id}
                  variant="ghost"
                  className="w-full justify-start text-sm h-10"
                  onClick={() => {
                    const categorySlug = category.name.toLowerCase().replace(/\s+/g, '-').replace('&', 'and');
                    navigate(`/shop?category=${categorySlug}`);
                    setIsOpen(false);
                  }}
                >
                  {category.name}
                </Button>
              ))}
            </div>
          </nav>

          {/* Bottom Actions */}
          <div className="border-t pt-4 space-y-3">
            {isFarmer ? (
              <Button 
                className="w-full"
                onClick={() => {
                  navigate('/farmer-products');
                  setIsOpen(false);
                }}
              >
                <ShoppingBag className="w-4 h-4 mr-2" />
                My Products
              </Button>
            ) : (
              <Button 
                className="w-full"
                onClick={handleSellClick}
              >
                <User className="w-4 h-4 mr-2" />
                Sell on Farming2Door
              </Button>
            )}
            
            {!loading && (
              <div className="flex justify-center">
                {user ? <UserMenu /> : <AuthDialog />}
              </div>
            )}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};