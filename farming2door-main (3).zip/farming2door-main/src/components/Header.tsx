import { Button } from "@/components/ui/button";
import { Menu, Leaf } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate, useLocation } from "react-router-dom";
import { useAdmin } from "@/contexts/AdminContext";
import { AuthDialog } from "@/components/auth/AuthDialog";
import { UserMenu } from "@/components/auth/UserMenu";
import { CartButton } from "@/components/cart/CartButton";
import { MobileMenu } from "@/components/MobileMenu";
import { NotificationBell } from "@/components/notifications/NotificationBell";

const Header = () => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { isFarmer } = useAdmin();

  const handleNavClick = (path: string) => {
    navigate(path);
  };

  const handleSellClick = () => {
    navigate('/farmer-onboarding');
  };

  const handleLogoClick = () => {
    navigate('/');
  };
  
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2 cursor-pointer" onClick={handleLogoClick}>
          <Leaf className="h-8 w-8 text-primary" />
          <span className="text-2xl font-bold text-primary">Farming2Door</span>
        </div>
        
        <nav className="hidden md:flex items-center gap-6">
          <button 
            onClick={() => handleNavClick('/shop')} 
            className={`text-foreground hover:text-primary transition-colors ${location.pathname === '/shop' ? 'text-primary font-medium' : ''}`}
          >
            Shop
          </button>
          <button 
            onClick={() => handleNavClick('/farmers')} 
            className={`text-foreground hover:text-primary transition-colors ${location.pathname === '/farmers' ? 'text-primary font-medium' : ''}`}
          >
            Farmers
          </button>
          <button 
            onClick={() => handleNavClick('/about')} 
            className={`text-foreground hover:text-primary transition-colors ${location.pathname === '/about' ? 'text-primary font-medium' : ''}`}
          >
            About
          </button>
          <button 
            onClick={() => handleNavClick('/how-it-works')} 
            className={`text-foreground hover:text-primary transition-colors ${location.pathname === '/how-it-works' ? 'text-primary font-medium' : ''}`}
          >
            How it Works
          </button>
          <button 
            onClick={() => handleNavClick('/breeding-stock')} 
            className={`text-foreground hover:text-primary transition-colors ${location.pathname === '/breeding-stock' ? 'text-primary font-medium' : ''}`}
          >
            Breeding Stock
          </button>
          <button 
            onClick={() => handleNavClick('/custom-orders/new')} 
            className={`text-foreground hover:text-primary transition-colors ${location.pathname === '/custom-orders/new' ? 'text-primary font-medium' : ''}`}
          >
            Custom Order
          </button>
        </nav>

        <div className="flex items-center gap-2">
          <CartButton />
          <NotificationBell />
          {!loading && (user ? <UserMenu /> : <AuthDialog />)}
          {isFarmer && (
            <Button variant="hero" className="hidden sm:inline-flex" onClick={() => navigate('/farmer-products')}>
              My Products
            </Button>
          )}
          {!isFarmer && (
            <Button variant="hero" className="hidden sm:inline-flex" onClick={handleSellClick}>
              Sell on Farming2Door
            </Button>
          )}
          <MobileMenu />
        </div>
      </div>
    </header>
  );
};

export default Header;