import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { ChevronLeft, ChevronRight, Play, X } from "lucide-react";

interface MediaFile {
  url: string;
  type: 'image' | 'video';
  name: string;
}

interface ProductMediaGalleryProps {
  images: MediaFile[];
  videos: MediaFile[];
  productName: string;
  className?: string;
}

export default function ProductMediaGallery({ 
  images, 
  videos, 
  productName, 
  className = "" 
}: ProductMediaGalleryProps) {
  const [selectedMedia, setSelectedMedia] = useState<MediaFile | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  
  const allMedia = [...images, ...videos];
  const hasMedia = allMedia.length > 0;

  if (!hasMedia) {
    return (
      <div className={`w-full h-64 bg-muted rounded-lg flex items-center justify-center ${className}`}>
        <div className="text-center text-muted-foreground">
          <div className="text-4xl mb-2">📦</div>
          <p>No media available</p>
        </div>
      </div>
    );
  }

  const currentMedia = allMedia[currentIndex];

  const nextMedia = () => {
    setCurrentIndex((prev) => (prev + 1) % allMedia.length);
  };

  const prevMedia = () => {
    setCurrentIndex((prev) => (prev - 1 + allMedia.length) % allMedia.length);
  };

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Carousel Media Display */}
      {allMedia.length === 1 ? (
        /* Single media item */
        <Dialog>
          <DialogTrigger asChild>
            <div className="cursor-pointer relative overflow-hidden rounded-lg">
              {currentMedia.type === 'image' ? (
                <img
                  src={currentMedia.url}
                  alt={`${productName} - ${currentMedia.name}`}
                  className="w-full h-64 md:h-96 object-cover transition-transform hover:scale-105"
                />
              ) : (
                <div className="relative">
                  <video
                    src={currentMedia.url}
                    className="w-full h-64 md:h-96 object-cover"
                    preload="metadata"
                  />
                  <div className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/30 transition-colors">
                    <Play className="h-12 w-12 text-white drop-shadow-lg" />
                  </div>
                </div>
              )}
            </div>
          </DialogTrigger>

          <DialogContent className="max-w-4xl max-h-[90vh] p-0">
            <div className="relative">
              <Button
                variant="ghost"
                size="sm"
                className="absolute top-2 right-2 z-10 bg-black/50 text-white hover:bg-black/70"
                onClick={() => setSelectedMedia(null)}
              >
                <X className="h-4 w-4" />
              </Button>

              {currentMedia.type === 'image' ? (
                <img
                  src={currentMedia.url}
                  alt={`${productName} - ${currentMedia.name}`}
                  className="w-full h-auto max-h-[80vh] object-contain"
                />
              ) : (
                <video
                  src={currentMedia.url}
                  className="w-full h-auto max-h-[80vh]"
                  controls
                  autoPlay
                />
              )}
            </div>
          </DialogContent>
        </Dialog>
      ) : (
        /* Multiple media items - Use Carousel */
        <Carousel className="w-full">
          <CarouselContent>
            {allMedia.map((media, index) => (
              <CarouselItem key={index}>
                <Dialog>
                  <DialogTrigger asChild>
                    <div className="cursor-pointer relative overflow-hidden rounded-lg">
                      {media.type === 'image' ? (
                        <img
                          src={media.url}
                          alt={`${productName} - ${media.name}`}
                          className="w-full h-64 md:h-96 object-cover transition-transform hover:scale-105"
                        />
                      ) : (
                        <div className="relative">
                          <video
                            src={media.url}
                            className="w-full h-64 md:h-96 object-cover"
                            preload="metadata"
                          />
                          <div className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/30 transition-colors">
                            <Play className="h-12 w-12 text-white drop-shadow-lg" />
                          </div>
                        </div>
                      )}
                      
                      {/* Media counter */}
                      <div className="absolute bottom-2 right-2 bg-black/70 text-white px-2 py-1 rounded text-sm">
                        {index + 1} / {allMedia.length}
                      </div>
                    </div>
                  </DialogTrigger>

                  <DialogContent className="max-w-4xl max-h-[90vh] p-0">
                    <div className="relative">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="absolute top-2 right-2 z-10 bg-black/50 text-white hover:bg-black/70"
                        onClick={() => setSelectedMedia(null)}
                      >
                        <X className="h-4 w-4" />
                      </Button>

                      {media.type === 'image' ? (
                        <img
                          src={media.url}
                          alt={`${productName} - ${media.name}`}
                          className="w-full h-auto max-h-[80vh] object-contain"
                        />
                      ) : (
                        <video
                          src={media.url}
                          className="w-full h-auto max-h-[80vh]"
                          controls
                          autoPlay
                        />
                      )}

                      {/* Navigation in modal */}
                      {allMedia.length > 1 && (
                        <>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 text-white hover:bg-black/70"
                            onClick={() => {
                              const prevIndex = (index - 1 + allMedia.length) % allMedia.length;
                              setCurrentIndex(prevIndex);
                            }}
                          >
                            <ChevronLeft className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 text-white hover:bg-black/70"
                            onClick={() => {
                              const nextIndex = (index + 1) % allMedia.length;
                              setCurrentIndex(nextIndex);
                            }}
                          >
                            <ChevronRight className="h-4 w-4" />
                          </Button>
                        </>
                      )}
                    </div>
                  </DialogContent>
                </Dialog>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious className="left-2" />
          <CarouselNext className="right-2" />
        </Carousel>
      )}

      {/* Thumbnail Grid for quick navigation */}
      {allMedia.length > 1 && (
        <div className="grid grid-cols-4 md:grid-cols-6 gap-2">
          {allMedia.map((media, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`relative aspect-square rounded-lg overflow-hidden border-2 transition-all ${
                index === currentIndex 
                  ? 'border-primary ring-2 ring-primary/20' 
                  : 'border-transparent hover:border-muted-foreground/50'
              }`}
            >
              {media.type === 'image' ? (
                <img
                  src={media.url}
                  alt={`${productName} thumbnail ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="relative w-full h-full bg-black">
                  <video
                    src={media.url}
                    className="w-full h-full object-cover"
                    preload="metadata"
                  />
                  <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                    <Play className="h-4 w-4 text-white" />
                  </div>
                </div>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}