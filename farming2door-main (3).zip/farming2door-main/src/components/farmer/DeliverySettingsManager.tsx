import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Truck, MapPin, Info } from "lucide-react";

const MAX_RADIUS = 50;

interface DeliverySettings {
  offers_delivery: boolean;
  delivery_radius_miles: number;
  offers_pickup: boolean;
  delivery_minimum_order: number;
  origin_zip: string;
  delivery_notes: string;
}

const DEFAULTS: DeliverySettings = {
  offers_delivery: false,
  delivery_radius_miles: 15,
  offers_pickup: true,
  delivery_minimum_order: 0,
  origin_zip: "",
  delivery_notes: "",
};

export const DeliverySettingsManager = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [settings, setSettings] = useState<DeliverySettings>(DEFAULTS);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const load = async () => {
      if (!user) return;
      setLoading(true);

      const [{ data: row }, { data: profile }] = await Promise.all([
        supabase
          .from("farmer_delivery_settings")
          .select("*")
          .eq("farmer_id", user.id)
          .maybeSingle(),
        supabase.from("profiles").select("zip_code").eq("id", user.id).maybeSingle(),
      ]);

      if (row) {
        setSettings({
          offers_delivery: row.offers_delivery,
          delivery_radius_miles: Number(row.delivery_radius_miles),
          offers_pickup: row.offers_pickup,
          delivery_minimum_order: Number(row.delivery_minimum_order),
          origin_zip: row.origin_zip || profile?.zip_code || "",
          delivery_notes: row.delivery_notes || "",
        });
      } else {
        setSettings({ ...DEFAULTS, origin_zip: profile?.zip_code || "" });
      }
      setLoading(false);
    };

    load();
  }, [user]);

  const update = <K extends keyof DeliverySettings>(key: K, value: DeliverySettings[K]) =>
    setSettings((prev) => ({ ...prev, [key]: value }));

  const handleSave = async () => {
    if (!user) return;

    if (!settings.offers_delivery && !settings.offers_pickup) {
      toast({
        title: "Choose at least one option",
        description: "Customers need either pickup or delivery to place an order.",
        variant: "destructive",
      });
      return;
    }

    if (settings.offers_delivery && !/^\d{5}$/.test(settings.origin_zip.trim())) {
      toast({
        title: "Farm ZIP code required",
        description: "Enter the 5-digit ZIP you deliver from so we can measure distance.",
        variant: "destructive",
      });
      return;
    }

    setSaving(true);
    const { error } = await supabase.from("farmer_delivery_settings").upsert(
      {
        farmer_id: user.id,
        offers_delivery: settings.offers_delivery,
        delivery_radius_miles: settings.delivery_radius_miles,
        offers_pickup: settings.offers_pickup,
        delivery_minimum_order: settings.delivery_minimum_order,
        origin_zip: settings.origin_zip.trim() || null,
        delivery_notes: settings.delivery_notes.trim() || null,
      },
      { onConflict: "farmer_id" }
    );
    setSaving(false);

    if (error) {
      toast({ title: "Could not save", description: error.message, variant: "destructive" });
      return;
    }

    toast({
      title: "Delivery settings saved",
      description: settings.offers_delivery
        ? `Customers within ${settings.delivery_radius_miles} miles can choose delivery.`
        : "Delivery is turned off — customers will only see pickup.",
    });
  };

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-muted-foreground py-10">
        <Loader2 className="h-4 w-4 animate-spin" />
        Loading your delivery settings…
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between gap-4">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Truck className="h-5 w-5" />
                In-House Delivery
              </CardTitle>
              <CardDescription>
                Opt in to deliver your own orders and keep the delivery revenue.
              </CardDescription>
            </div>
            <Switch
              checked={settings.offers_delivery}
              onCheckedChange={(v) => update("offers_delivery", v)}
              aria-label="Offer delivery"
            />
          </div>
        </CardHeader>

        {settings.offers_delivery && (
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Serviceable radius</Label>
                <Badge variant="secondary">{settings.delivery_radius_miles} miles</Badge>
              </div>
              <Slider
                min={1}
                max={MAX_RADIUS}
                step={1}
                value={[settings.delivery_radius_miles]}
                onValueChange={([v]) => update("delivery_radius_miles", v)}
              />
              <p className="text-xs text-muted-foreground">
                Platform maximum is {MAX_RADIUS} miles. Customers outside your radius only see pickup.
              </p>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="origin-zip" className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  Delivery origin ZIP
                </Label>
                <Input
                  id="origin-zip"
                  inputMode="numeric"
                  maxLength={5}
                  placeholder="e.g. 60614"
                  value={settings.origin_zip}
                  onChange={(e) => update("origin_zip", e.target.value.replace(/\D/g, ""))}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="min-order">Delivery minimum order ($)</Label>
                <Input
                  id="min-order"
                  type="number"
                  min={0}
                  step="1"
                  value={settings.delivery_minimum_order}
                  onChange={(e) => update("delivery_minimum_order", Math.max(0, Number(e.target.value) || 0))}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="delivery-notes">Note for customers (optional)</Label>
              <Textarea
                id="delivery-notes"
                rows={3}
                placeholder="e.g. We deliver Tuesdays and Fridays, refrigerated van."
                value={settings.delivery_notes}
                onChange={(e) => update("delivery_notes", e.target.value)}
              />
            </div>
          </CardContent>
        )}
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-start justify-between gap-4">
            <div>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                Farm Pickup
              </CardTitle>
              <CardDescription>
                Let customers collect their order at your farm during your published windows.
              </CardDescription>
            </div>
            <Switch
              checked={settings.offers_pickup}
              onCheckedChange={(v) => update("offers_pickup", v)}
              aria-label="Offer pickup"
            />
          </div>
        </CardHeader>
      </Card>

      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          Checkout only shows the options you enable here. If you turn delivery off, nearby
          Farming2Door drivers aren't dispatched for your orders either.
        </AlertDescription>
      </Alert>

      <Button onClick={handleSave} disabled={saving} className="w-full sm:w-auto">
        {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
        Save delivery settings
      </Button>
    </div>
  );
};
