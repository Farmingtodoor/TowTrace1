import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Clock, Plus, Trash2, CalendarDays } from "lucide-react";

const DAYS = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];

interface PickupSlot {
  id: string;
  day_of_week: number;
  start_time: string;
  end_time: string;
  capacity: number;
  location_note: string | null;
  is_active: boolean;
}

const formatTime = (t: string) => {
  const [h, m] = t.split(":").map(Number);
  const period = h >= 12 ? "PM" : "AM";
  const hour = h % 12 === 0 ? 12 : h % 12;
  return `${hour}:${String(m).padStart(2, "0")} ${period}`;
};

export function PickupAvailabilityManager() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [slots, setSlots] = useState<PickupSlot[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [dayOfWeek, setDayOfWeek] = useState("1");
  const [startTime, setStartTime] = useState("09:00");
  const [endTime, setEndTime] = useState("12:00");
  const [capacity, setCapacity] = useState("5");
  const [locationNote, setLocationNote] = useState("");

  useEffect(() => {
    if (user) fetchSlots();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const fetchSlots = async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await supabase
      .from("farmer_pickup_slots")
      .select("id, day_of_week, start_time, end_time, capacity, location_note, is_active")
      .eq("farmer_id", user.id)
      .order("day_of_week", { ascending: true })
      .order("start_time", { ascending: true });

    if (error) {
      console.error("Error loading pickup slots:", error);
      toast({
        title: "Error",
        description: "Could not load your pickup windows.",
        variant: "destructive",
      });
    } else {
      setSlots(data ?? []);
    }
    setLoading(false);
  };

  const handleAdd = async () => {
    if (!user) return;

    if (endTime <= startTime) {
      toast({
        title: "Invalid time window",
        description: "The end time must be after the start time.",
        variant: "destructive",
      });
      return;
    }

    const cap = parseInt(capacity, 10);
    if (!Number.isFinite(cap) || cap < 1 || cap > 500) {
      toast({
        title: "Invalid capacity",
        description: "Capacity must be between 1 and 500 orders.",
        variant: "destructive",
      });
      return;
    }

    setSaving(true);
    const { error } = await supabase.from("farmer_pickup_slots").insert({
      farmer_id: user.id,
      day_of_week: parseInt(dayOfWeek, 10),
      start_time: startTime,
      end_time: endTime,
      capacity: cap,
      location_note: locationNote.trim().slice(0, 200) || null,
    });
    setSaving(false);

    if (error) {
      console.error("Error adding pickup slot:", error);
      toast({
        title: "Could not add window",
        description:
          error.code === "23505"
            ? "You already have this exact pickup window."
            : "Please try again.",
        variant: "destructive",
      });
      return;
    }

    toast({ title: "Pickup window added" });
    setLocationNote("");
    fetchSlots();
  };

  const toggleActive = async (slot: PickupSlot) => {
    const { error } = await supabase
      .from("farmer_pickup_slots")
      .update({ is_active: !slot.is_active })
      .eq("id", slot.id);

    if (error) {
      toast({ title: "Update failed", variant: "destructive" });
      return;
    }
    setSlots((prev) =>
      prev.map((s) => (s.id === slot.id ? { ...s, is_active: !s.is_active } : s))
    );
  };

  const updateCapacity = async (slot: PickupSlot, value: number) => {
    if (!Number.isFinite(value) || value < 1 || value > 500) return;
    const { error } = await supabase
      .from("farmer_pickup_slots")
      .update({ capacity: value })
      .eq("id", slot.id);

    if (error) {
      toast({ title: "Update failed", variant: "destructive" });
      return;
    }
    setSlots((prev) =>
      prev.map((s) => (s.id === slot.id ? { ...s, capacity: value } : s))
    );
  };

  const removeSlot = async (id: string) => {
    const { error } = await supabase
      .from("farmer_pickup_slots")
      .delete()
      .eq("id", id);

    if (error) {
      toast({ title: "Could not remove window", variant: "destructive" });
      return;
    }
    setSlots((prev) => prev.filter((s) => s.id !== id));
    toast({ title: "Pickup window removed" });
  };

  const grouped = DAYS.map((label, index) => ({
    label,
    index,
    slots: slots.filter((s) => s.day_of_week === index),
  }));

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Plus className="w-5 h-5 text-primary" />
            Add a pickup window
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="space-y-2">
              <Label>Day</Label>
              <Select value={dayOfWeek} onValueChange={setDayOfWeek}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {DAYS.map((d, i) => (
                    <SelectItem key={d} value={String(i)}>
                      {d}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="start-time">Start</Label>
              <Input
                id="start-time"
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="end-time">End</Label>
              <Input
                id="end-time"
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="capacity">Orders per window</Label>
              <Input
                id="capacity"
                type="number"
                min={1}
                max={500}
                value={capacity}
                onChange={(e) => setCapacity(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="note">Pickup note (optional)</Label>
              <Input
                id="note"
                placeholder="Barn gate, north entrance…"
                maxLength={200}
                value={locationNote}
                onChange={(e) => setLocationNote(e.target.value)}
              />
            </div>
          </div>
          <Button className="mt-4" onClick={handleAdd} disabled={saving}>
            <Plus className="w-4 h-4 mr-2" />
            {saving ? "Adding…" : "Add window"}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <CalendarDays className="w-5 h-5 text-primary" />
            Weekly pickup schedule
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-12 bg-muted rounded animate-pulse" />
              ))}
            </div>
          ) : slots.length === 0 ? (
            <div className="text-center py-8">
              <Clock className="w-10 h-10 mx-auto mb-3 text-muted-foreground" />
              <p className="text-muted-foreground">
                No pickup windows yet. Add your first one above so customers can
                schedule a time.
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {grouped
                .filter((g) => g.slots.length > 0)
                .map((group) => (
                  <div key={group.label} className="space-y-2">
                    <h3 className="font-semibold">{group.label}</h3>
                    {group.slots.map((slot) => (
                      <div
                        key={slot.id}
                        className="flex flex-wrap items-center gap-4 rounded-lg border p-3"
                      >
                        <div className="flex items-center gap-2 min-w-[190px]">
                          <Clock className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm font-medium">
                            {formatTime(slot.start_time)} –{" "}
                            {formatTime(slot.end_time)}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <Label
                            htmlFor={`cap-${slot.id}`}
                            className="text-xs text-muted-foreground"
                          >
                            Capacity
                          </Label>
                          <Input
                            id={`cap-${slot.id}`}
                            type="number"
                            min={1}
                            max={500}
                            className="w-20 h-8"
                            defaultValue={slot.capacity}
                            onBlur={(e) =>
                              updateCapacity(slot, parseInt(e.target.value, 10))
                            }
                          />
                        </div>

                        {slot.location_note && (
                          <span className="text-xs text-muted-foreground max-w-[220px] truncate">
                            {slot.location_note}
                          </span>
                        )}

                        <div className="flex items-center gap-2 ml-auto">
                          <Badge variant={slot.is_active ? "default" : "secondary"}>
                            {slot.is_active ? "Active" : "Paused"}
                          </Badge>
                          <Switch
                            checked={slot.is_active}
                            onCheckedChange={() => toggleActive(slot)}
                            aria-label="Toggle pickup window"
                          />
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeSlot(slot.id)}
                            aria-label="Remove pickup window"
                          >
                            <Trash2 className="w-4 h-4 text-destructive" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

export default PickupAvailabilityManager;
