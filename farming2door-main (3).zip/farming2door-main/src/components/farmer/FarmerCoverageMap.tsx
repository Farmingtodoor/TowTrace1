import { useEffect, useRef, useState, useCallback } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import { MapPin, Truck, Store, Loader2, CheckCircle2, XCircle, Info } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { geocodeZipCode, haversineDistance, type GeocodedLocation } from '@/services/geocodingService';

const MAPBOX_TOKEN =
  'pk.eyJ1IjoiZmFybWluMmRvb3IiLCJhIjoiY21mZWNvdXVyMDVjczJpb2dueDcwaGhudSJ9.oeIZtg-WQnD382BjP8Swqw';

interface DeliverySettings {
  offers_delivery: boolean;
  offers_pickup: boolean;
  delivery_radius_miles: number;
  delivery_minimum_order: number;
  origin_zip: string | null;
  delivery_notes: string | null;
}

interface FarmerCoverageMapProps {
  farmerId: string;
  farmName?: string;
  /** Fallback ZIP taken from the farm address when no origin ZIP is configured */
  fallbackZip?: string | null;
  height?: string;
}

/** Build a GeoJSON polygon approximating a circle of `radiusMiles` around a point. */
function circlePolygon(lat: number, lng: number, radiusMiles: number, steps = 96) {
  const coords: [number, number][] = [];
  const distanceX = radiusMiles / (69.172 * Math.cos((lat * Math.PI) / 180));
  const distanceY = radiusMiles / 69.172;
  for (let i = 0; i < steps; i++) {
    const theta = (i / steps) * (2 * Math.PI);
    coords.push([lng + distanceX * Math.cos(theta), lat + distanceY * Math.sin(theta)]);
  }
  coords.push(coords[0]);
  return {
    type: 'Feature' as const,
    properties: {},
    geometry: { type: 'Polygon' as const, coordinates: [coords] },
  };
}

export function FarmerCoverageMap({
  farmerId,
  farmName = 'this farm',
  fallbackZip,
  height = '380px',
}: FarmerCoverageMapProps) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const customerMarker = useRef<mapboxgl.Marker | null>(null);

  const [loading, setLoading] = useState(true);
  const [settings, setSettings] = useState<DeliverySettings | null>(null);
  const [origin, setOrigin] = useState<GeocodedLocation | null>(null);
  const [zipInput, setZipInput] = useState('');
  const [checking, setChecking] = useState(false);
  const [result, setResult] = useState<
    { inRange: boolean; distance: number; city: string; state: string } | null
  >(null);
  const [zipError, setZipError] = useState<string | null>(null);

  // Load the farm's delivery settings + geocode its origin
  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      const { data } = await supabase
        .from('farmer_delivery_settings')
        .select('offers_delivery, offers_pickup, delivery_radius_miles, delivery_minimum_order, origin_zip, delivery_notes')
        .eq('farmer_id', farmerId)
        .maybeSingle();

      if (cancelled) return;
      setSettings(data as DeliverySettings | null);

      const zip = data?.origin_zip || fallbackZip;
      if (zip) {
        const geo = await geocodeZipCode(zip);
        if (!cancelled && geo.success) setOrigin(geo);
      }
      if (!cancelled) setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [farmerId, fallbackZip]);

  // Initialize the map once we know where the farm is
  useEffect(() => {
    if (!mapContainer.current || !origin || map.current) return;

    mapboxgl.accessToken = MAPBOX_TOKEN;
    const radius = settings?.delivery_radius_miles ?? 0;
    const instance = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/streets-v12',
      center: [origin.longitude, origin.latitude],
      zoom: radius > 30 ? 8 : radius > 15 ? 9 : 10,
      attributionControl: false,
    });
    instance.addControl(new mapboxgl.NavigationControl({ showCompass: false }), 'top-right');
    map.current = instance;

    instance.on('load', () => {
      // Coverage circle
      if (settings?.offers_delivery && radius > 0) {
        instance.addSource('coverage', {
          type: 'geojson',
          data: circlePolygon(origin.latitude, origin.longitude, radius),
        });
        instance.addLayer({
          id: 'coverage-fill',
          type: 'fill',
          source: 'coverage',
          paint: { 'fill-color': '#16A34A', 'fill-opacity': 0.15 },
        });
        instance.addLayer({
          id: 'coverage-outline',
          type: 'line',
          source: 'coverage',
          paint: { 'line-color': '#16A34A', 'line-width': 2, 'line-dasharray': [2, 1] },
        });
      }

      // Farm marker
      const el = document.createElement('div');
      el.innerHTML = `
        <div style="width:38px;height:38px;border-radius:50% 50% 50% 0;background:#16A34A;border:3px solid white;box-shadow:0 4px 12px rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;transform:rotate(-45deg);">
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" style="transform:rotate(45deg);"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>
        </div>`;
      new mapboxgl.Marker({ element: el, anchor: 'bottom' })
        .setLngLat([origin.longitude, origin.latitude])
        .setPopup(
          new mapboxgl.Popup({ offset: 24 }).setHTML(
            `<div style="font-size:13px;"><strong>${farmName}</strong><br/><span style="color:#666;">${origin.city}, ${origin.state}</span></div>`
          )
        )
        .addTo(instance);

      if (settings?.offers_delivery && radius > 0) {
        const bounds = new mapboxgl.LngLatBounds();
        const poly = circlePolygon(origin.latitude, origin.longitude, radius);
        poly.geometry.coordinates[0].forEach((c) => bounds.extend(c as [number, number]));
        instance.fitBounds(bounds, { padding: 40, duration: 0 });
      }
    });

    return () => {
      customerMarker.current?.remove();
      customerMarker.current = null;
      instance.remove();
      map.current = null;
    };
  }, [origin, settings, farmName]);

  const checkZip = useCallback(async () => {
    if (!origin || !settings) return;
    const normalized = zipInput.replace(/\D/g, '').slice(0, 5);
    if (normalized.length !== 5) {
      setZipError('Enter a valid 5-digit ZIP code');
      setResult(null);
      return;
    }

    setZipError(null);
    setChecking(true);
    const geo = await geocodeZipCode(normalized);
    setChecking(false);

    if (!geo.success) {
      setZipError(geo.error || 'We could not find that ZIP code');
      setResult(null);
      return;
    }

    const distance =
      Math.round(haversineDistance(origin.latitude, origin.longitude, geo.latitude, geo.longitude) * 10) / 10;
    const inRange = settings.offers_delivery && distance <= settings.delivery_radius_miles;
    setResult({ inRange, distance, city: geo.city, state: geo.state });

    // Drop / move the customer marker and frame both points
    if (map.current) {
      customerMarker.current?.remove();
      const el = document.createElement('div');
      el.innerHTML = `
        <div style="width:34px;height:34px;border-radius:50% 50% 50% 0;background:${inRange ? '#2563EB' : '#EF4444'};border:3px solid white;box-shadow:0 4px 12px rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;transform:rotate(-45deg);">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" style="transform:rotate(45deg);"><circle cx="12" cy="10" r="3"/><path d="M12 2a8 8 0 0 0-8 8c0 5 8 12 8 12s8-7 8-12a8 8 0 0 0-8-8z"/></svg>
        </div>`;
      customerMarker.current = new mapboxgl.Marker({ element: el, anchor: 'bottom' })
        .setLngLat([geo.longitude, geo.latitude])
        .setPopup(
          new mapboxgl.Popup({ offset: 24 }).setHTML(
            `<div style="font-size:13px;"><strong>${geo.city}, ${geo.state}</strong><br/><span style="color:#666;">${distance} mi from the farm</span></div>`
          )
        )
        .addTo(map.current);

      const bounds = new mapboxgl.LngLatBounds()
        .extend([origin.longitude, origin.latitude])
        .extend([geo.longitude, geo.latitude]);
      map.current.fitBounds(bounds, { padding: 70, maxZoom: 11, duration: 700 });
    }
  }, [origin, settings, zipInput]);

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Delivery Area</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Skeleton className="h-6 w-48" />
          <Skeleton style={{ height }} className="w-full rounded-lg" />
        </CardContent>
      </Card>
    );
  }

  const offersNothing = !settings || (!settings.offers_delivery && !settings.offers_pickup);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="h-5 w-5 text-primary" />
          Delivery Area
        </CardTitle>
        <CardDescription>
          See how far {farmName} delivers and check whether your neighborhood is covered.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-wrap gap-2">
          {settings?.offers_delivery && (
            <Badge variant="secondary" className="gap-1">
              <Truck className="h-3.5 w-3.5" />
              Delivers up to {settings.delivery_radius_miles} miles
            </Badge>
          )}
          {settings?.offers_pickup && (
            <Badge variant="secondary" className="gap-1">
              <Store className="h-3.5 w-3.5" />
              Farm pickup available
            </Badge>
          )}
          {settings?.offers_delivery && settings.delivery_minimum_order > 0 && (
            <Badge variant="outline">${settings.delivery_minimum_order.toFixed(2)} delivery minimum</Badge>
          )}
        </div>

        {offersNothing && (
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              This farm hasn't published its fulfillment options yet. Message the farmer to arrange delivery or pickup.
            </AlertDescription>
          </Alert>
        )}

        {!origin ? (
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              This farm hasn't set a service location yet, so we can't show a coverage map.
            </AlertDescription>
          </Alert>
        ) : (
          <>
            <div className="relative overflow-hidden rounded-lg border">
              <div ref={mapContainer} style={{ height }} className="w-full" />
              {settings?.offers_delivery && (
                <div className="pointer-events-none absolute bottom-3 left-3 rounded-md bg-background/90 px-3 py-2 text-xs shadow-sm backdrop-blur">
                  <div className="flex items-center gap-2">
                    <span className="inline-block h-3 w-3 rounded-sm border border-primary bg-primary/20" />
                    Covered delivery zone
                  </div>
                </div>
              )}
            </div>

            {settings?.offers_delivery && (
              <div className="space-y-3">
                <div className="flex flex-col gap-2 sm:flex-row">
                  <Input
                    value={zipInput}
                    onChange={(e) => setZipInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && checkZip()}
                    placeholder="Enter your ZIP code"
                    inputMode="numeric"
                    maxLength={5}
                    aria-label="Your ZIP code"
                    className="sm:max-w-[200px]"
                  />
                  <Button onClick={checkZip} disabled={checking}>
                    {checking ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                    Check my address
                  </Button>
                </div>

                {zipError && <p className="text-sm text-destructive">{zipError}</p>}

                {result && (
                  <Alert variant={result.inRange ? 'default' : 'destructive'}>
                    {result.inRange ? (
                      <CheckCircle2 className="h-4 w-4" />
                    ) : (
                      <XCircle className="h-4 w-4" />
                    )}
                    <AlertDescription>
                      {result.inRange ? (
                        <>
                          Good news — {result.city}, {result.state} is <strong>{result.distance} miles</strong> away and
                          inside this farm's delivery zone.
                        </>
                      ) : (
                        <>
                          {result.city}, {result.state} is <strong>{result.distance} miles</strong> away, just outside the{' '}
                          {settings.delivery_radius_miles}-mile delivery zone.
                          {settings.offers_pickup && ' Farm pickup is still available.'}
                        </>
                      )}
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            )}

            {settings?.delivery_notes && (
              <p className="text-sm text-muted-foreground">{settings.delivery_notes}</p>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}

export default FarmerCoverageMap;
