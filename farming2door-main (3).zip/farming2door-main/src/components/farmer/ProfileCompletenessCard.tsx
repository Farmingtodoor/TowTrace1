import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Circle, AlertTriangle, Loader2, ChevronDown, ChevronUp } from "lucide-react";

type ChecklistItem = {
  label: string;
  hint: string;
  done: boolean;
  required: boolean;
  fixTo: string;
  fixLabel: string;
};

function hasText(value: unknown): boolean {
  return typeof value === "string" && value.trim().length > 0;
}

function hasItems(value: unknown): boolean {
  if (Array.isArray(value)) return value.length > 0;
  if (value && typeof value === "object") return Object.keys(value).length > 0;
  return false;
}

export default function ProfileCompletenessCard() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState<ChecklistItem[]>([]);
  const [status, setStatus] = useState<string | null>(null);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;

    const load = async () => {
      setLoading(true);
      const [appRes, profileRes] = await Promise.all([
        supabase
          .from("farmer_applications")
          .select(
            "status, phone, farm_name, farm_address, farm_size, farming_experience, farm_description, certifications, categories, subcategories, processing_methods"
          )
          .eq("user_id", user.id)
          .maybeSingle(),
        supabase
          .from("profiles")
          .select("full_name, phone, city, state, zip_code, profile_picture_url")
          .eq("id", user.id)
          .maybeSingle(),
      ]);

      if (cancelled) return;

      const app = appRes.data;
      const profile = profileRes.data;

      if (!app) {
        setItems([]);
        setStatus(null);
        setLoading(false);
        return;
      }

      const onboarding = (step: string, focus: string) => ({
        to: `/farmer-onboarding?step=${step}&focus=${focus}`,
        label: "Go to field",
      });
      const account = (focus: string) => ({
        to: `/account-settings?focus=${focus}`,
        label: "Go to field",
      });

      const list: ChecklistItem[] = [
        {
          label: "Farm name",
          hint: "The name customers will see on your listings.",
          done: hasText(app.farm_name),
          required: true,
          fixTo: onboarding("farm", "farmName").to,
          fixLabel: onboarding("farm", "farmName").label,
        },
        {
          label: "Farm address",
          hint: "Used for pickup directions and delivery distance.",
          done: hasText(app.farm_address),
          required: true,
          fixTo: onboarding("farm", "farmAddress").to,
          fixLabel: onboarding("farm", "farmAddress").label,
        },
        {
          label: "City & state",
          hint: "Required before your farm can be approved or listed publicly.",
          done: hasText(profile?.city) && hasText(profile?.state),
          required: true,
          fixTo: account("city").to,
          fixLabel: account("city").label,
        },
        {
          label: "ZIP code",
          hint: "Powers delivery radius and coverage maps.",
          done: hasText(profile?.zip_code),
          required: true,
          fixTo: account("zipCode").to,
          fixLabel: account("zipCode").label,
        },
        {
          label: "Contact phone",
          hint: "So we and your customers can reach you about orders.",
          done: hasText(app.phone) || hasText(profile?.phone),
          required: true,
          fixTo: onboarding("personal", "phone").to,
          fixLabel: onboarding("personal", "phone").label,
        },
        {
          label: "Product categories",
          hint: "Pick at least one category you plan to sell.",
          done: hasItems(app.categories),
          required: true,
          fixTo: onboarding("products", "productCategories").to,
          fixLabel: onboarding("products", "productCategories").label,
        },
        {
          label: "Farm description",
          hint: "Tell customers how you farm — this drives trust.",
          done: hasText(app.farm_description),
          required: true,
          fixTo: onboarding("farm", "description").to,
          fixLabel: onboarding("farm", "description").label,
        },
        {
          label: "Farm size",
          hint: "Optional, but helps buyers gauge your capacity.",
          done: hasText(app.farm_size),
          required: false,
          fixTo: onboarding("farm", "farmSize").to,
          fixLabel: onboarding("farm", "farmSize").label,
        },
        {
          label: "Farming experience",
          hint: "Optional background that strengthens your application.",
          done: hasText(app.farming_experience),
          required: false,
          fixTo: onboarding("farm", "farmType").to,
          fixLabel: onboarding("farm", "farmType").label,
        },
        {
          label: "Certifications",
          hint: "Optional — organic, pasture-raised, and similar badges.",
          done: hasItems(app.certifications),
          required: false,
          fixTo: onboarding("products", "organic").to,
          fixLabel: onboarding("products", "organic").label,
        },
        {
          label: "Profile photo",
          hint: "Optional headshot or farm logo for your public page.",
          done: hasText(profile?.profile_picture_url),
          required: false,
          fixTo: account("profilePicture").to,
          fixLabel: account("profilePicture").label,
        },
      ];

      setItems(list);
      setStatus(app.status ?? null);
      setLoading(false);
    };

    load().catch(() => {
      if (!cancelled) setLoading(false);
    });

    return () => {
      cancelled = true;
    };
  }, [user]);

  if (!user || loading) {
    return loading && user ? (
      <Card>
        <CardContent className="flex items-center gap-2 py-6 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" />
          Checking your profile completeness…
        </CardContent>
      </Card>
    ) : null;
  }

  if (items.length === 0) return null;

  const completed = items.filter((i) => i.done).length;
  const percent = Math.round((completed / items.length) * 100);
  const missingRequired = items.filter((i) => i.required && !i.done);
  const missingOptional = items.filter((i) => !i.required && !i.done);
  const visibleItems = expanded ? items : [...missingRequired, ...missingOptional].slice(0, 4);

  return (
    <Card className={missingRequired.length > 0 ? "border-destructive/40" : undefined}>
      <CardHeader className="pb-3">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <CardTitle className="flex items-center gap-2 text-lg">
              Profile completeness
              <Badge variant={missingRequired.length > 0 ? "destructive" : "secondary"}>{percent}%</Badge>
            </CardTitle>
            <CardDescription>
              {missingRequired.length > 0
                ? `${missingRequired.length} required ${missingRequired.length === 1 ? "field is" : "fields are"} still missing before your farm can be approved.`
                : status === "approved"
                  ? "All required details are on file. Optional items below make your listing stronger."
                  : "All required details are on file — your application is ready for review."}
            </CardDescription>
          </div>
          {status && (
            <Badge variant="outline" className="capitalize">
              {status}
            </Badge>
          )}
        </div>
        <Progress value={percent} className="mt-3 h-2" />
        <p className="mt-1 text-xs text-muted-foreground">
          {completed} of {items.length} details complete
        </p>
      </CardHeader>
      <CardContent className="space-y-3">
        {missingRequired.length > 0 && (
          <div className="flex items-start gap-2 rounded-md border border-destructive/30 bg-destructive/5 p-3 text-sm">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
            <span>
              Farms without a city and state can't be approved or shown to customers. Finish the items marked
              &ldquo;Required&rdquo; to move forward.
            </span>
          </div>
        )}

        <ul className="space-y-2">
          {visibleItems.map((item) => (
            <li key={item.label} className="flex items-start justify-between gap-3 rounded-md border p-3">
              <div className="flex items-start gap-2">
                {item.done ? (
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                ) : (
                  <Circle className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
                )}
                <div>
                  <div className="flex items-center gap-2">
                    <span className={`text-sm font-medium ${item.done ? "text-muted-foreground line-through" : ""}`}>
                      {item.label}
                    </span>
                    {!item.done && (
                      <Badge variant={item.required ? "destructive" : "outline"} className="text-[10px]">
                        {item.required ? "Required" : "Optional"}
                      </Badge>
                    )}
                  </div>
                  {!item.done && <p className="mt-0.5 text-xs text-muted-foreground">{item.hint}</p>}
                </div>
              </div>
              {!item.done && (
                <Button asChild size="sm" variant="outline" className="shrink-0">
                  <Link to={item.fixTo}>{item.fixLabel}</Link>
                </Button>
              )}
            </li>
          ))}
        </ul>

        {items.length > visibleItems.length || expanded ? (
          <Button variant="ghost" size="sm" onClick={() => setExpanded((v) => !v)}>
            {expanded ? (
              <>
                <ChevronUp className="mr-1 h-4 w-4" /> Show only what's missing
              </>
            ) : (
              <>
                <ChevronDown className="mr-1 h-4 w-4" /> Show all {items.length} items
              </>
            )}
          </Button>
        ) : null}
      </CardContent>
    </Card>
  );
}
