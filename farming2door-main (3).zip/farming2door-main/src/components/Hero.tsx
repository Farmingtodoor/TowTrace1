import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import * as React from "react";
import { useAdmin } from "@/contexts/AdminContext";
import heroImage1 from "@/assets/hero-farm.jpg";
import heroImage2 from "@/assets/hero-farm-2.jpg";
import heroImage3 from "@/assets/hero-farm-3.jpg";
import heroImage4 from "@/assets/hero-farm-4.jpg";
import heroFowls from "@/assets/hero-fowls.jpg";
import heroEggs from "@/assets/hero-eggs.jpg";
import heroGoats from "@/assets/hero-goats.jpg";
import heroPigs from "@/assets/hero-pigs.jpg";
import heroTurkeys from "@/assets/hero-turkeys.jpg";
import heroOnions from "@/assets/hero-onions.jpg";
import heroMilkingCows from "@/assets/hero-milking-cows.jpg";
import heroDelivery1 from "@/assets/hero-delivery-1.jpg";
import heroDelivery2 from "@/assets/hero-delivery-2.jpg";
import heroDelivery3 from "@/assets/hero-delivery-3.jpg";
import heroDelivery4 from "@/assets/hero-delivery-4.jpg";
import SearchBar from "@/components/SearchBar";
import { Carousel, CarouselContent, CarouselItem, type CarouselApi } from "@/components/ui/carousel";

const Hero = () => {
  const navigate = useNavigate();
  const [api, setApi] = React.useState<CarouselApi>();
  const { isFarmer } = useAdmin();

  const heroImages = [
    { src: heroImage1, alt: "Fresh farm produce and livestock" },
    { src: heroDelivery1, alt: "Delivery agent handing fresh produce to smiling customer" },
    { src: heroImage2, alt: "Beautiful farm landscape with rolling hills" },
    { src: heroDelivery2, alt: "Happy delivery person with fresh farm produce crate" },
    { src: heroImage3, alt: "Fresh organic vegetables being harvested" },
    { src: heroDelivery3, alt: "Customer receiving organic produce basket with joy" },
    { src: heroImage4, alt: "Modern greenhouse with fresh produce" },
    { src: heroDelivery4, alt: "Delivery team presenting fresh vegetables to excited family" },
    { src: heroFowls, alt: "Free-range fowls and chickens on farm" },
    { src: heroEggs, alt: "Fresh farm eggs in basket" },
    { src: heroGoats, alt: "Goats grazing in green meadow" },
    { src: heroPigs, alt: "Farm pigs in clean pen" },
    { src: heroTurkeys, alt: "Free-range turkeys on farm" },
    { src: heroOnions, alt: "Fresh onions growing in field" },
    { src: heroMilkingCows, alt: "Dairy cows in milking parlor" }
  ];

  useEffect(() => {
    if (!api) return;

    const interval = setInterval(() => {
      // Only auto-scroll if user hasn't interacted recently
      if (document.visibilityState === 'visible') {
        api.scrollNext();
      }
    }, 5000); // Increased from 3000 to 5000ms

    return () => clearInterval(interval);
  }, [api]);

  const handleStartShopping = () => {
    document.getElementById('featured-products')?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleJoinAsFarmer = () => {
    navigate('/farmer-onboarding');
  };

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-background via-accent/20 to-secondary">
      <div className="container mx-auto px-4 py-20 lg:py-28">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl md:text-6xl font-bold text-foreground leading-tight">
                Fresh from
                <span className="text-primary"> Farm </span>
                to Your
                <span className="text-accent-warm"> Door</span>
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
                Connect directly with local farmers. Get the freshest produce, premium livestock, 
                and custom processing options delivered straight to your doorstep.
              </p>
            </div>

            <div className="space-y-6">
              <SearchBar />
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button variant="hero" size="lg" className="text-lg px-8" onClick={handleStartShopping}>
                  Start Shopping
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <Button variant="outline" size="lg" className="text-lg px-8" onClick={() => navigate('/subscriptions?tab=my-subscriptions')}>
                  My Subscriptions
                </Button>
                {!isFarmer && (
                  <Button variant="ghost" size="lg" className="text-lg px-8" onClick={handleJoinAsFarmer}>
                    Join as Farmer
                  </Button>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 pt-8">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-primary" />
                <span className="text-sm font-medium">Fresh & Local</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-primary" />
                <span className="text-sm font-medium">Direct from Farmers</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-primary" />
                <span className="text-sm font-medium">Custom Processing</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-primary" />
                <span className="text-sm font-medium">On-Time Delivery</span>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-accent-warm/20 rounded-3xl blur-3xl"></div>
            <Carousel
              setApi={setApi}
              className="relative w-full"
              opts={{
                align: "start",
                loop: true,
                duration: 20, // Faster transitions
                skipSnaps: false,
                containScroll: "trimSnaps",
              }}
            >
              <CarouselContent>
                {heroImages.map((image, index) => (
                  <CarouselItem key={index}>
                    <img
                      src={image.src}
                      alt={image.alt}
                      className="relative w-full h-[400px] lg:h-[500px] object-cover rounded-3xl shadow-2xl"
                    />
                  </CarouselItem>
                ))}
              </CarouselContent>
            </Carousel>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;