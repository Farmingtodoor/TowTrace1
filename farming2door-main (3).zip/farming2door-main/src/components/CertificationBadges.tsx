import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Leaf, ShieldCheck, Droplet, TreePine, Award, CheckCircle } from "lucide-react";

interface CertificationBadgesProps {
  certifications: string[];
  size?: 'sm' | 'md';
  maxDisplay?: number;
  variant?: 'full' | 'icons-only';
}

const certificationConfig: Record<string, {
  icon: any;
  color: string;
  description: string;
  shortLabel: string;
}> = {
  'USDA Organic': {
    icon: Leaf,
    color: 'bg-green-600 text-white',
    description: 'Certified organic by USDA - no synthetic pesticides or fertilizers',
    shortLabel: 'Organic',
  },
  'Non-GMO': {
    icon: ShieldCheck,
    color: 'bg-blue-600 text-white',
    description: 'Non-GMO verified - no genetically modified organisms',
    shortLabel: 'Non-GMO',
  },
  'Grass-Fed': {
    icon: TreePine,
    color: 'bg-emerald-600 text-white',
    description: 'Animals raised on pasture with grass diet',
    shortLabel: 'Grass-Fed',
  },
  'Pasture-Raised': {
    icon: TreePine,
    color: 'bg-teal-600 text-white',
    description: 'Animals raised outdoors with access to pasture',
    shortLabel: 'Pasture',
  },
  'Hormone-Free': {
    icon: CheckCircle,
    color: 'bg-purple-600 text-white',
    description: 'No added hormones or antibiotics',
    shortLabel: 'Hormone-Free',
  },
  'Certified Humane': {
    icon: Award,
    color: 'bg-pink-600 text-white',
    description: 'Meets humane animal treatment standards',
    shortLabel: 'Humane',
  },
  'Rainforest Alliance': {
    icon: Droplet,
    color: 'bg-cyan-600 text-white',
    description: 'Sustainable farming practices certified',
    shortLabel: 'Sustainable',
  },
};

function getCertificationInfo(cert: string) {
  // Try exact match first
  if (certificationConfig[cert]) {
    return certificationConfig[cert];
  }
  
  // Try partial match for variations
  const normalizedCert = cert.toLowerCase();
  for (const [key, value] of Object.entries(certificationConfig)) {
    if (normalizedCert.includes(key.toLowerCase()) || key.toLowerCase().includes(normalizedCert)) {
      return value;
    }
  }
  
  // Default fallback
  return {
    icon: Award,
    color: 'bg-gray-600 text-white',
    description: cert,
    shortLabel: cert.length > 15 ? cert.substring(0, 12) + '...' : cert,
  };
}

export function CertificationBadges({ 
  certifications, 
  size = 'md',
  maxDisplay = 3,
  variant = 'full'
}: CertificationBadgesProps) {
  if (!certifications || certifications.length === 0) {
    return null;
  }

  const displayCerts = certifications.slice(0, maxDisplay);
  const remainingCount = certifications.length - maxDisplay;
  const sizeClass = size === 'sm' ? 'text-xs px-2 py-0.5' : 'text-sm px-3 py-1';
  const iconSize = size === 'sm' ? 'h-3 w-3' : 'h-4 w-4';

  return (
    <TooltipProvider>
      <div className="flex flex-wrap gap-1.5">
        {displayCerts.map((cert, index) => {
          const config = getCertificationInfo(cert);
          const Icon = config.icon;
          
          return (
            <Tooltip key={index}>
              <TooltipTrigger asChild>
                <Badge 
                  className={`${config.color} ${sizeClass} flex items-center gap-1 shadow-sm hover:shadow-md transition-shadow cursor-help border-0`}
                >
                  <Icon className={iconSize} />
                  {variant === 'full' && <span>{config.shortLabel}</span>}
                </Badge>
              </TooltipTrigger>
              <TooltipContent>
                <div className="space-y-1">
                  <p className="font-semibold">{cert}</p>
                  <p className="text-xs text-muted-foreground max-w-xs">{config.description}</p>
                </div>
              </TooltipContent>
            </Tooltip>
          );
        })}
        
        {remainingCount > 0 && (
          <Tooltip>
            <TooltipTrigger asChild>
              <Badge 
                variant="secondary" 
                className={`${sizeClass} cursor-help`}
              >
                +{remainingCount} more
              </Badge>
            </TooltipTrigger>
            <TooltipContent>
              <div className="space-y-1">
                <p className="font-semibold">Additional Certifications:</p>
                <ul className="text-xs space-y-0.5">
                  {certifications.slice(maxDisplay).map((cert, idx) => (
                    <li key={idx}>• {cert}</li>
                  ))}
                </ul>
              </div>
            </TooltipContent>
          </Tooltip>
        )}
      </div>
    </TooltipProvider>
  );
}
