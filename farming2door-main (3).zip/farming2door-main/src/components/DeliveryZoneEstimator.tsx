import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, MapPin, Truck, Clock, Mail, CheckCircle, Info } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { calculateDeliveryFee as calcDeliveryFee, formatFeeBreakdown, DeliveryFeeBreakdown } from "@/services/deliveryFeeService";

interface DeliveryZoneEstimatorProps {
  farmerId?: string;
  farmerLocation?: string;
}

export default function DeliveryZoneEstimator({ farmerId, farmerLocation }: DeliveryZoneEstimatorProps) {
  const [zipCode, setZipCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [notFound, setNotFound] = useState(false);
  const [waitlistEmail, setWaitlistEmail] = useState("");
  const [waitlistLoading, setWaitlistLoading] = useState(false);
  const [deliveryInfo, setDeliveryInfo] = useState<{
    available: boolean;
    distance: number;
    feeBreakdown: DeliveryFeeBreakdown;
  } | null>(null);
  const [farmerCoordinates, setFarmerCoordinates] = useState<{lat: number; lng: number} | null>(null);
  const [showFeeBreakdown, setShowFeeBreakdown] = useState(false);

  useEffect(() => {
    const fetchFarmerLocation = async () => {
      if (!farmerId) return;
      
      try {
        const { data: locations, error } = await supabase
          .rpc('get_farmer_public_locations', { _user_ids: [farmerId] });

        if (error) throw error;

        const data = locations?.[0];

        
        // Try to geocode the farmer's ZIP code
        if (data?.zip_code) {
          try {
            const zipCode = data.zip_code.replace(/\D/g, '').slice(0, 5);
            const response = await fetch(`https://api.zippopotam.us/us/${zipCode}`);
            if (response.ok) {
              const zipData = await response.json();
              setFarmerCoordinates({
                lat: parseFloat(zipData.places[0].latitude),
                lng: parseFloat(zipData.places[0].longitude)
              });
            }
          } catch (zipError) {
            console.error('Error geocoding farmer ZIP:', zipError);
          }
        }
      } catch (error) {
        console.error('Error fetching farmer location:', error);
      }
    };
    
    fetchFarmerLocation();
  }, [farmerId]);

  const normalizeZipCode = (zip: string): string => {
    return zip.replace(/\D/g, '').slice(0, 5);
  };

  const isValidZipCode = (zip: string): boolean => {
    const normalized = normalizeZipCode(zip);
    return normalized.length === 5;
  };

  const formatZipCode = (zip: string): string => {
    const normalized = normalizeZipCode(zip);
    return normalized;
  };

  const handleZipCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatZipCode(e.target.value);
    setZipCode(formatted);
    if (deliveryInfo || notFound) {
      setDeliveryInfo(null);
      setNotFound(false);
    }
  };

  // Calculate distance using Haversine formula
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 3959; // Earth's radius in miles
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  const checkDeliveryZone = async () => {
    const normalizedZip = normalizeZipCode(zipCode);
    
    if (!normalizedZip) {
      toast.error("Please enter a ZIP code");
      return;
    }

    if (!isValidZipCode(normalizedZip)) {
      toast.error("Please enter a valid 5-digit ZIP code");
      return;
    }

    if (!farmerCoordinates && !farmerLocation) {
      toast.error("Farmer location not available");
      return;
    }

    setLoading(true);
    setNotFound(false);
    setDeliveryInfo(null);

    try {
      // Use free ZIP code geocoding API
      const response = await fetch(`https://api.zippopotam.us/us/${normalizedZip}`);
      
      if (!response.ok) {
        setNotFound(true);
        setLoading(false);
        return;
      }

      const zipData = await response.json();
      const customerLat = parseFloat(zipData.places[0].latitude);
      const customerLng = parseFloat(zipData.places[0].longitude);

      if (!farmerCoordinates) {
        toast.error("Unable to calculate distance - farmer coordinates not available");
        setLoading(false);
        return;
      }

      // Calculate distance
      const distance = calculateDistance(
        farmerCoordinates.lat,
        farmerCoordinates.lng,
        customerLat,
        customerLng
      );

      const maxDistance = 50; // 50 miles
      const isAvailable = distance <= maxDistance;

      if (isAvailable) {
        // Calculate fee using industry-standard tiered pricing
        const feeBreakdown = calcDeliveryFee({
          distanceMiles: distance,
          orderSubtotal: 50, // Default estimate for display
          isPeakHours: undefined // Auto-detect
        });
        
        setDeliveryInfo({
          available: true,
          distance: Math.round(distance * 10) / 10,
          feeBreakdown
        });
        toast.success(`Delivery available! ${Math.round(distance)} miles away`);
      } else {
        setNotFound(true);
        toast.error(`Sorry, you're ${Math.round(distance)} miles away. We deliver within 50 miles.`);
      }
    } catch (error) {
      console.error('Error checking delivery zone:', error);
      toast.error("Failed to check delivery zone. Please try again.");
      setNotFound(true);
    } finally {
      setLoading(false);
    }
  };

  const joinWaitlist = async () => {
    const email = waitlistEmail.trim();
    if (!email) {
      toast.error("Please enter your email");
      return;
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      toast.error("Please enter a valid email address");
      return;
    }

    setWaitlistLoading(true);

    try {
      const { error } = await supabase
        .from('app_notifications')
        .insert([{
          email: email,
          notified: false
        }]);

      if (error) throw error;

      toast.success("Thanks! We'll notify you when we expand to your area.");
      setWaitlistEmail("");
    } catch (error: any) {
      console.error('Error joining waitlist:', error);
      if (error.message?.includes('duplicate key')) {
        toast.error("This email is already on our waitlist!");
      } else {
        toast.error("Failed to join waitlist. Please try again.");
      }
    } finally {
      setWaitlistLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      if (e.currentTarget.placeholder.includes('ZIP')) {
        checkDeliveryZone();
      } else if (e.currentTarget.placeholder.includes('email')) {
        joinWaitlist();
      }
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="h-5 w-5" />
          Delivery Zone Estimator
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Enter your ZIP code to check delivery availability and fees
        </p>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            placeholder="Enter ZIP code (e.g., 12345)"
            value={zipCode}
            onChange={handleZipCodeChange}
            onKeyPress={handleKeyPress}
            maxLength={5}
            disabled={loading}
          />
          <Button onClick={checkDeliveryZone} disabled={loading || !zipCode.trim()}>
            {loading ? "Checking..." : "Check"}
          </Button>
        </div>

        {deliveryInfo && deliveryInfo.available && (
          <div className="space-y-4 p-4 border rounded-lg bg-green-50 border-green-200">
            <div className="flex items-center justify-between">
              <h4 className="font-medium flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-600" />
                Delivery Available
              </h4>
              <Badge className="bg-green-100 text-green-800 border-green-300">
                Within Range
              </Badge>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-green-600" />
                  <span className="text-sm font-medium">Distance</span>
                </div>
                <p className="text-lg font-bold text-green-700">
                  {deliveryInfo.distance} miles
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Truck className="h-4 w-4 text-green-600" />
                  <span className="text-sm font-medium">Estimated Delivery Fee</span>
                </div>
                <p className="text-lg font-bold text-green-700">
                  ${deliveryInfo.feeBreakdown.totalFee.toFixed(2)}
                </p>
                <button 
                  onClick={() => setShowFeeBreakdown(!showFeeBreakdown)}
                  className="text-xs text-green-600 underline flex items-center gap-1 hover:text-green-800"
                >
                  <Info className="h-3 w-3" />
                  {showFeeBreakdown ? 'Hide' : 'View'} fee breakdown
                </button>
              </div>
            </div>

            {showFeeBreakdown && (
              <div className="bg-white p-3 rounded border text-sm space-y-1">
                <p className="font-medium text-green-800 mb-2">Fee Breakdown:</p>
                <div className="grid grid-cols-2 gap-1 text-muted-foreground">
                  <span>Base fee:</span>
                  <span className="text-right">${deliveryInfo.feeBreakdown.baseFee.toFixed(2)}</span>
                  <span>Distance fee ({deliveryInfo.distance} mi):</span>
                  <span className="text-right">${deliveryInfo.feeBreakdown.distanceFee.toFixed(2)}</span>
                  <span>Service fee (10%):</span>
                  <span className="text-right">${deliveryInfo.feeBreakdown.serviceFee.toFixed(2)}</span>
                  {deliveryInfo.feeBreakdown.smallOrderFee > 0 && (
                    <>
                      <span>Small order fee:</span>
                      <span className="text-right">${deliveryInfo.feeBreakdown.smallOrderFee.toFixed(2)}</span>
                    </>
                  )}
                  {deliveryInfo.feeBreakdown.peakFee > 0 && (
                    <>
                      <span>Peak hours fee:</span>
                      <span className="text-right">${deliveryInfo.feeBreakdown.peakFee.toFixed(2)}</span>
                    </>
                  )}
                  <span className="font-medium text-green-800 pt-1 border-t">Total:</span>
                  <span className="text-right font-medium text-green-800 pt-1 border-t">${deliveryInfo.feeBreakdown.totalFee.toFixed(2)}</span>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-green-600" />
                <span className="text-sm font-medium">Estimated Delivery Time</span>
              </div>
              <p className="text-sm text-green-700">
                {deliveryInfo.feeBreakdown.estimatedDeliveryTime}
              </p>
            </div>

            <div className="text-xs text-muted-foreground bg-white p-2 rounded border">
              <strong>Pricing:</strong> $2.99 base + tiered distance rates + 10% service fee
              {deliveryInfo.feeBreakdown.peakFee > 0 && " • Peak hours pricing applied"}
            </div>
          </div>
        )}

        {notFound && (
          <div className="space-y-4 p-4 border border-orange-200 rounded-lg bg-orange-50">
            <div className="flex items-start gap-2">
              <AlertCircle className="h-5 w-5 text-orange-500 mt-0.5" />
              <div className="flex-1">
                <h4 className="font-medium text-orange-800">Out of Delivery Range</h4>
                <p className="text-sm text-orange-700">
                  ZIP code {zipCode} is outside our 50-mile delivery radius. Join our waitlist to be notified when we expand to your area!
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <p className="text-sm font-medium text-orange-800">Alternative options:</p>
              <p className="text-sm text-orange-700">
                📍 Contact us about farm pickup options
                <br />
                🚚 Check if other nearby farmers deliver to your area
              </p>
            </div>

            <div className="flex gap-2">
              <Input
                placeholder="Enter your email"
                value={waitlistEmail}
                onChange={(e) => setWaitlistEmail(e.target.value)}
                onKeyPress={handleKeyPress}
                type="email"
                disabled={waitlistLoading}
              />
              <Button 
                onClick={joinWaitlist} 
                variant="outline" 
                size="sm"
                disabled={waitlistLoading || !waitlistEmail.trim()}
              >
                <Mail className="h-4 w-4 mr-1" />
                {waitlistLoading ? "Joining..." : "Join Waitlist"}
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}