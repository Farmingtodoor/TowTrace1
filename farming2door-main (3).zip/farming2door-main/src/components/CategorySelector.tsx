import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, ChevronRight, Leaf, Wheat, Beef, Milk, Carrot, Hexagon } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Category {
  id: string;
  name: string;
  description: string;
  icon: string;
  display_order: number;
}

interface Subcategory {
  id: string;
  category_id: string;
  name: string;
  description: string;
  display_order: number;
}

interface CategorySelectorProps {
  selectedCategories: string[];
  selectedSubcategories: string[];
  onCategoriesChange: (categories: string[]) => void;
  onSubcategoriesChange: (subcategories: string[]) => void;
  farmerId?: string;
}

const iconMap: { [key: string]: any } = {
  Carrot,
  Beef, 
  Milk,
  Wheat,
  Leaf,
  Hexagon,
};

export default function CategorySelector({
  selectedCategories,
  selectedSubcategories,
  onCategoriesChange,
  onSubcategoriesChange,
  farmerId
}: CategorySelectorProps) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [subcategories, setSubcategories] = useState<Subcategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      // Fetch categories
      const { data: categoriesData, error: categoriesError } = await supabase
        .from("categories")
        .select("*")
        .eq("is_active", true)
        .order("display_order");

      if (categoriesError) throw categoriesError;

      // Fetch subcategories
      const { data: subcategoriesData, error: subcategoriesError } = await supabase
        .from("subcategories")
        .select("*")
        .eq("is_active", true)
        .order("display_order");

      if (subcategoriesError) throw subcategoriesError;

      setCategories(categoriesData || []);
      setSubcategories(subcategoriesData || []);
    } catch (error) {
      console.error("Error fetching categories:", error);
      toast.error("Failed to load categories");
    } finally {
      setLoading(false);
    }
  };

  const handleCategoryToggle = (categoryId: string) => {
    const isSelected = selectedCategories.includes(categoryId);
    
    if (isSelected) {
      // Remove category and all its subcategories
      const newCategories = selectedCategories.filter(id => id !== categoryId);
      const categorySubcategories = subcategories
        .filter(sub => sub.category_id === categoryId)
        .map(sub => sub.id);
      const newSubcategories = selectedSubcategories.filter(id => 
        !categorySubcategories.includes(id)
      );
      
      onCategoriesChange(newCategories);
      onSubcategoriesChange(newSubcategories);
    } else {
      // Add category
      onCategoriesChange([...selectedCategories, categoryId]);
      // Expand category to show subcategories
      setExpandedCategories(prev => new Set([...prev, categoryId]));
    }
  };

  const handleSubcategoryToggle = (subcategoryId: string, categoryId: string) => {
    const isSelected = selectedSubcategories.includes(subcategoryId);
    
    if (isSelected) {
      // Remove subcategory
      onSubcategoriesChange(
        selectedSubcategories.filter(id => id !== subcategoryId)
      );
    } else {
      // Add subcategory and ensure parent category is selected
      if (!selectedCategories.includes(categoryId)) {
        onCategoriesChange([...selectedCategories, categoryId]);
      }
      onSubcategoriesChange([...selectedSubcategories, subcategoryId]);
    }
  };

  const toggleCategoryExpansion = (categoryId: string) => {
    setExpandedCategories(prev => {
      const newSet = new Set(prev);
      if (newSet.has(categoryId)) {
        newSet.delete(categoryId);
      } else {
        newSet.add(categoryId);
      }
      return newSet;
    });
  };

  const getSelectedSubcategoriesForCategory = (categoryId: string) => {
    return subcategories
      .filter(sub => sub.category_id === categoryId && selectedSubcategories.includes(sub.id))
      .length;
  };

  const clearSelections = () => {
    onCategoriesChange([]);
    onSubcategoriesChange([]);
    setExpandedCategories(new Set());
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">Loading categories...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Product Categories & Specialties</CardTitle>
          {(selectedCategories.length > 0 || selectedSubcategories.length > 0) && (
            <Button variant="outline" size="sm" onClick={clearSelections}>
              Clear All
            </Button>
          )}
        </div>
        <p className="text-sm text-muted-foreground">
          Select the main categories and specific subcategories that match your farm products.
          This helps customers find exactly what you offer.
        </p>
        {selectedCategories.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-4">
            <span className="text-sm font-medium">Selected:</span>
            {selectedCategories.map(categoryId => {
              const category = categories.find(c => c.id === categoryId);
              const subcategoryCount = getSelectedSubcategoriesForCategory(categoryId);
              return category ? (
                <Badge key={categoryId} variant="default">
                  {category.name}
                  {subcategoryCount > 0 && (
                    <span className="ml-1 px-1 bg-white/20 rounded-sm text-xs">
                      {subcategoryCount}
                    </span>
                  )}
                </Badge>
              ) : null;
            })}
          </div>
        )}
      </CardHeader>
      <CardContent className="space-y-4">
        {categories.map((category) => {
          const isSelected = selectedCategories.includes(category.id);
          const isExpanded = expandedCategories.has(category.id);
          const categorySubcategories = subcategories.filter(sub => sub.category_id === category.id);
          const selectedSubcategoryCount = getSelectedSubcategoriesForCategory(category.id);
          const IconComponent = iconMap[category.icon] || Carrot;

          return (
            <div key={category.id} className="border rounded-lg overflow-hidden">
              <div className="flex items-center space-x-3 p-4 bg-muted/50">
                <Checkbox
                  checked={isSelected}
                  onCheckedChange={() => handleCategoryToggle(category.id)}
                />
                <IconComponent className="h-5 w-5 text-primary" />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{category.name}</span>
                    {selectedSubcategoryCount > 0 && (
                      <Badge variant="outline" className="text-xs">
                        {selectedSubcategoryCount} selected
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">{category.description}</p>
                </div>
                {categorySubcategories.length > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleCategoryExpansion(category.id)}
                  >
                    {isExpanded ? (
                      <ChevronDown className="h-4 w-4" />
                    ) : (
                      <ChevronRight className="h-4 w-4" />
                    )}
                  </Button>
                )}
              </div>
              
              <Collapsible open={isExpanded}>
                <CollapsibleContent>
                  {categorySubcategories.length > 0 && (
                    <div className="p-4 pt-0">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {categorySubcategories.map((subcategory) => (
                          <div
                            key={subcategory.id}
                            className="flex items-center space-x-2 p-2 hover:bg-muted/50 rounded"
                          >
                            <Checkbox
                              checked={selectedSubcategories.includes(subcategory.id)}
                              onCheckedChange={() => handleSubcategoryToggle(subcategory.id, category.id)}
                            />
                            <span className="text-sm">{subcategory.name}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CollapsibleContent>
              </Collapsible>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}