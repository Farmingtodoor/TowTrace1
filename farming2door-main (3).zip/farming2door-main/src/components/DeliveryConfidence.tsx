import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, Shield, Truck, CheckCircle, Users } from "lucide-react";

const DeliveryConfidence = () => {
  const deliveryFeatures = [
    {
      icon: Clock,
      title: "On-Time Delivery",
      description: "Professional drivers ensure your fresh produce arrives exactly when promised"
    },
    {
      icon: Shield,
      title: "Secure Handling",
      description: "Trained professionals handle your farm-fresh items with care from pickup to doorstep"
    },
    {
      icon: Truck,
      title: "Real-Time Tracking",
      description: "Track your order every step of the way with live updates and delivery notifications"
    }
  ];

  return (
    <section className="py-16 bg-gradient-to-b from-background to-muted/20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <CheckCircle className="h-6 w-6 text-primary" />
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">
              Guaranteed Fresh Delivery
            </h2>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
Our own delivery network and the farmers themselves bring your order straight to your door
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {deliveryFeatures.map((feature, index) => (
            <Card key={index} className="border-0 bg-card/50 backdrop-blur-sm">
              <CardContent className="p-6 text-center">
                <feature.icon className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="bg-card rounded-2xl p-8 shadow-lg">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-foreground mb-2">
              Delivered In-House
            </h3>
            <p className="text-muted-foreground">
              No third-party apps — your farmer or one of our own drivers handles every delivery
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch max-w-3xl mx-auto">
            <Card className="relative overflow-hidden border-primary/20">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Truck className="h-8 w-8 text-primary" />
                </div>
                <h4 className="font-semibold text-lg mb-2">Farm Direct</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  Delivered personally by your farmer
                </p>
                <div className="flex items-center justify-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">1-2 days</span>
                </div>
                <Badge className="mt-3" variant="secondary">Most Personal</Badge>
              </CardContent>
            </Card>

            <Card className="relative overflow-hidden border-primary/20">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-primary" />
                </div>
                <h4 className="font-semibold text-lg mb-2">Farming2Door Drivers</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  Our vetted local drivers, tracked live end to end
                </p>
                <div className="flex items-center justify-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">Same-day in your area</span>
                </div>
                <Badge className="mt-3" variant="secondary">Live Tracking</Badge>
              </CardContent>
            </Card>
          </div>

          <div className="mt-8 text-center">
            <div className="inline-flex items-center gap-2 text-sm text-muted-foreground">
              <Shield className="h-4 w-4" />
              <span>All deliveries are insured and tracked for your peace of mind</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DeliveryConfidence;