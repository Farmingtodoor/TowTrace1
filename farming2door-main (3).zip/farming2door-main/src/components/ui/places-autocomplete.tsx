import React, { useState, useEffect, useRef } from 'react'
import { Input } from './input'
import { Label } from './label'
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from './command'
import { Popover, PopoverContent, PopoverTrigger } from './popover'
import { MapPin } from 'lucide-react'

interface PlacesAutocompleteProps {
  id: string
  label: string
  placeholder: string
  value: string
  onChange: (value: string) => void
  type?: 'country' | 'city' | 'state' | 'postal_code'
}

// Predefined suggestions for different location types
const locationSuggestions = {
  country: [
    'United States', 'Canada', 'United Kingdom', 'Australia', 'Germany', 
    'France', 'Italy', 'Spain', 'Netherlands', 'Belgium', 'Switzerland',
    'Austria', 'Sweden', 'Norway', 'Denmark', 'Finland', 'Poland',
    'Czech Republic', 'Hungary', 'Portugal', 'Ireland', 'New Zealand'
  ],
  state: [
    'Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado',
    'Connecticut', 'Delaware', 'Florida', 'Georgia', 'Hawaii', 'Idaho',
    'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana',
    'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota',
    'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada',
    'New Hampshire', 'New Jersey', 'New Mexico', 'New York',
    'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon',
    'Pennsylvania', 'Rhode Island', 'South Carolina', 'South Dakota',
    'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington',
    'West Virginia', 'Wisconsin', 'Wyoming'
  ],
  city: [
    'New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix', 'Philadelphia',
    'San Antonio', 'San Diego', 'Dallas', 'San Jose', 'Austin', 'Jacksonville',
    'Fort Worth', 'Columbus', 'Charlotte', 'San Francisco', 'Indianapolis',
    'Seattle', 'Denver', 'Washington DC', 'Boston', 'El Paso', 'Nashville',
    'Detroit', 'Oklahoma City', 'Portland', 'Las Vegas', 'Memphis', 'Louisville',
    'Baltimore', 'Milwaukee', 'Albuquerque', 'Tucson', 'Fresno', 'Sacramento',
    'Kansas City', 'Mesa', 'Atlanta', 'Omaha', 'Colorado Springs', 'Raleigh',
    'Miami', 'Cleveland', 'Tulsa', 'Oakland', 'Minneapolis', 'Wichita',
    'Arlington', 'Bakersfield', 'New Orleans', 'Honolulu', 'Anaheim',
    'Tampa', 'Aurora', 'Santa Ana', 'St. Louis', 'Riverside', 'Corpus Christi',
    'Lexington', 'Pittsburgh', 'Anchorage', 'Stockton', 'Cincinnati',
    'St. Paul', 'Toledo', 'Greensboro', 'Newark', 'Plano', 'Henderson',
    'Lincoln', 'Buffalo', 'Jersey City', 'Chula Vista', 'Orlando', 'Norfolk'
  ]
}

const PlacesAutocomplete: React.FC<PlacesAutocompleteProps> = ({
  id,
  label,
  placeholder,
  value,
  onChange,
  type = 'city'
}) => {
  const [open, setOpen] = useState(false)
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [loading, setLoading] = useState(false)

  const getSuggestions = (query: string) => {
    if (!query.trim()) return []
    
    const predefinedSuggestions = locationSuggestions[type] || []
    
    // Filter predefined suggestions based on input
    const filtered = predefinedSuggestions
      .filter(suggestion => 
        suggestion.toLowerCase().includes(query.toLowerCase())
      )
      .slice(0, 8) // Limit to 8 suggestions
    
    return filtered
  }

  const handleInputChange = (inputValue: string) => {
    onChange(inputValue)
    
    if (inputValue.trim()) {
      const newSuggestions = getSuggestions(inputValue)
      setSuggestions(newSuggestions)
      setOpen(newSuggestions.length > 0)
    } else {
      setSuggestions([])
      setOpen(false)
    }
  }

  const handleSelect = (selectedValue: string) => {
    onChange(selectedValue)
    setOpen(false)
    setSuggestions([])
  }

  return (
    <div className="space-y-2">
      <Label htmlFor={id}>{label}</Label>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              id={id}
              placeholder={placeholder}
              value={value}
              onChange={(e) => handleInputChange(e.target.value)}
              onFocus={() => {
                if (value.trim()) {
                  const newSuggestions = getSuggestions(value)
                  setSuggestions(newSuggestions)
                  setOpen(newSuggestions.length > 0)
                }
              }}
              className="pl-10"
            />
          </div>
        </PopoverTrigger>
        <PopoverContent className="w-full p-0" align="start">
          <Command>
            <CommandInput 
              placeholder={`Search ${type}...`} 
              value={value}
              onValueChange={handleInputChange}
            />
            <CommandList>
              <CommandEmpty>No locations found.</CommandEmpty>
              <CommandGroup>
                {suggestions.map((suggestion, index) => (
                  <CommandItem
                    key={`${suggestion}-${index}`}
                    value={suggestion}
                    onSelect={() => handleSelect(suggestion)}
                    className="flex items-center gap-2"
                  >
                    <MapPin className="h-4 w-4" />
                    {suggestion}
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
    </div>
  )
}

export default PlacesAutocomplete