import {
  BarChart3,
  Package,
  ShoppingCart,
  Users,
  Settings,
  Mail,
  Shield,
  Home,
  Store,
  UserCheck,
  DollarSign,
  BellRing,
  Sprout,
  Rows3,
  Tags,
  Rows4,
} from "lucide-react";
import { NavLink, useLocation } from "react-router-dom";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarSeparator,
  useSidebar,
} from "@/components/ui/sidebar";
import { useAdmin } from "@/contexts/AdminContext";
import { useSidebarDensity } from "@/hooks/useSidebarDensity";
import { cn } from "@/lib/utils";

interface MenuItem {
  title: string;
  url: string;
  icon: React.ComponentType<{ className?: string }>;
  roles: string[];
  end?: boolean;
}

const overviewItems: MenuItem[] = [
  { title: "Dashboard", url: "/admin", icon: BarChart3, roles: ["admin", "super_admin", "farmer"], end: true },
];

const operationsItems: MenuItem[] = [
  { title: "Orders", url: "/admin/orders", icon: ShoppingCart, roles: ["admin", "super_admin"] },
  { title: "Customer Orders", url: "/farmer/orders", icon: ShoppingCart, roles: ["farmer"] },
  { title: "Custom Requests", url: "/farmer/custom-orders", icon: UserCheck, roles: ["farmer"] },
  { title: "Products", url: "/admin/products", icon: Package, roles: ["admin", "super_admin"] },
  { title: "Categories", url: "/admin/categories", icon: Tags, roles: ["admin", "super_admin"] },
  { title: "Products", url: "/farmer-products", icon: Package, roles: ["farmer"] },
  { title: "Payouts", url: "/admin/payouts", icon: DollarSign, roles: ["admin", "super_admin"] },
  { title: "Payout Reports", url: "/admin/reports", icon: BarChart3, roles: ["admin", "super_admin"] },
  { title: "Payouts", url: "/farmer-payouts", icon: DollarSign, roles: ["farmer"] },
  { title: "Delivery Waitlist", url: "/admin/waitlist", icon: BellRing, roles: ["admin", "super_admin", "farmer"] },
];

const managementItems: MenuItem[] = [
  { title: "Users", url: "/admin/users", icon: Users, roles: ["admin", "super_admin"] },
  { title: "Farmers", url: "/admin/farmers", icon: Store, roles: ["admin", "super_admin"] },
  { title: "Notifications", url: "/admin/notifications", icon: Mail, roles: ["admin", "super_admin"] },
];

const systemItems: MenuItem[] = [
  { title: "Roles", url: "/admin/roles", icon: Shield, roles: ["super_admin"] },
  { title: "Fix Farmer Roles", url: "/admin/fix-roles", icon: UserCheck, roles: ["super_admin"] },
  { title: "Settings", url: "/admin/settings", icon: Settings, roles: ["admin", "super_admin"] },
];

export function AdminSidebar() {
  const { state } = useSidebar();
  const location = useLocation();
  const { isSuperAdmin, isAdmin, isFarmer } = useAdmin();
  const { isCompact, toggleDensity } = useSidebarDensity();
  const collapsed = state === "collapsed";

  const role = isSuperAdmin ? "super_admin" : isAdmin ? "admin" : isFarmer ? "farmer" : null;

  const visible = (items: MenuItem[]) =>
    role ? items.filter((item) => item.roles.includes(role)) : [];

  const renderGroup = (label: string, items: MenuItem[]) => {
    const filtered = visible(items);
    if (filtered.length === 0) return null;
    return (
      <SidebarGroup className={cn(isCompact && "py-1")}>
        <SidebarGroupLabel
          className={cn(
            "text-sidebar-foreground/50 uppercase tracking-widest text-[10px]",
            isCompact && "h-6 text-[9px]"
          )}
        >
          {label}
        </SidebarGroupLabel>
        <SidebarGroupContent>
          <SidebarMenu className={cn(isCompact && "gap-0.5")}>
            {filtered.map((item) => {
              const active = item.end
                ? location.pathname === item.url
                : location.pathname.startsWith(item.url);
              return (
                <SidebarMenuItem key={`${item.title}-${item.url}`}>
                  <SidebarMenuButton
                    asChild
                    isActive={active}
                    tooltip={item.title}
                    size={isCompact ? "sm" : "default"}
                    className={cn(
                      "transition-colors",
                      isCompact && "h-7 text-[13px]",
                      active
                        ? "bg-sidebar-accent text-sidebar-accent-foreground font-medium shadow-[inset_2px_0_0_0_hsl(var(--sidebar-primary))]"
                        : "text-sidebar-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground"
                    )}
                  >
                    <NavLink to={item.url} end={item.end}>
                      <item.icon className={cn("h-4 w-4", active && "text-sidebar-primary")} />
                      {!collapsed && <span>{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              );
            })}
          </SidebarMenu>
        </SidebarGroupContent>
      </SidebarGroup>
    );
  };

  return (
    <Sidebar collapsible="icon" className="border-r border-sidebar-border">
      <SidebarHeader className={cn("px-4", isCompact ? "py-2.5" : "py-4")}>
        <NavLink to="/admin" className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-sidebar-primary">
            <Sprout className="h-5 w-5 text-sidebar-primary-foreground" />
          </div>
          {!collapsed && (
            <div className="leading-tight">
              <p className="text-sm font-semibold text-sidebar-accent-foreground">Farming2Door</p>
              <p className="text-[11px] text-sidebar-foreground/60">
                {isSuperAdmin ? "Super Admin" : isAdmin ? "Admin Console" : "Farmer Console"}
              </p>
            </div>
          )}
        </NavLink>
      </SidebarHeader>

      <SidebarSeparator className="bg-sidebar-border" />

      <SidebarContent>
        {renderGroup("Overview", overviewItems)}
        {renderGroup("Operations", operationsItems)}
        {renderGroup("Management", managementItems)}
        {renderGroup("System", systemItems)}
      </SidebarContent>

      <SidebarFooter>
        <SidebarSeparator className="bg-sidebar-border" />
        <SidebarMenu className={cn(isCompact && "gap-0.5")}>
          <SidebarMenuItem>
            <SidebarMenuButton
              onClick={toggleDensity}
              size={isCompact ? "sm" : "default"}
              tooltip={isCompact ? "Comfortable spacing" : "Compact spacing"}
              aria-label={isCompact ? "Switch to comfortable spacing" : "Switch to compact spacing"}
              className={cn(
                "text-sidebar-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground",
                isCompact && "h-7 text-[13px]"
              )}
            >
              {isCompact ? <Rows3 className="h-4 w-4" /> : <Rows4 className="h-4 w-4" />}
              {!collapsed && <span>{isCompact ? "Comfortable" : "Compact"}</span>}
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton
              asChild
              tooltip="Back to Site"
              className="text-sidebar-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-accent-foreground"
            >
              <NavLink to="/">
                <Home className="h-4 w-4" />
                {!collapsed && <span>Back to Site</span>}
              </NavLink>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}
