import { useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ChevronLeft, ChevronRight, Store, Truck, CalendarDays } from "lucide-react";
import { cn } from "@/lib/utils";

export interface CalendarOrder {
  id: string;
  customer: string;
  total: string;
  status: string;
  fulfillment: "pickup" | "delivery";
  scheduledAt?: string | null;
  scheduleLabel?: string | null;
}

interface Props {
  orders: CalendarOrder[];
  onOpenOrder: (orderId: string) => void;
}

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

/** Local YYYY-MM-DD key so grouping matches the viewer's timezone. */
const dayKey = (iso: string) => {
  const d = new Date(iso);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
    d.getDate()
  ).padStart(2, "0")}`;
};

const hourLabel = (iso: string) =>
  new Date(iso).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });

const slotKey = (iso: string) => {
  const d = new Date(iso);
  d.setMinutes(0, 0, 0);
  return d.toISOString();
};

/**
 * Month calendar of scheduled pickup/delivery windows.
 * Clicking a day reveals its time slots; clicking a slot lists the orders inside it.
 */
export function OrdersCalendar({ orders, onOpenOrder }: Props) {
  const [cursor, setCursor] = useState(() => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth(), 1);
  });
  const [selectedDay, setSelectedDay] = useState<string | null>(null);
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);

  const scheduled = useMemo(
    () => orders.filter((o) => Boolean(o.scheduledAt)),
    [orders]
  );

  const byDay = useMemo(() => {
    const map = new Map<string, CalendarOrder[]>();
    for (const order of scheduled) {
      const key = dayKey(order.scheduledAt!);
      const list = map.get(key) ?? [];
      list.push(order);
      map.set(key, list);
    }
    for (const list of map.values()) {
      list.sort(
        (a, b) => new Date(a.scheduledAt!).getTime() - new Date(b.scheduledAt!).getTime()
      );
    }
    return map;
  }, [scheduled]);

  const cells = useMemo(() => {
    const year = cursor.getFullYear();
    const month = cursor.getMonth();
    const first = new Date(year, month, 1);
    const start = new Date(year, month, 1 - first.getDay());
    return Array.from({ length: 42 }, (_, i) => {
      const date = new Date(start.getFullYear(), start.getMonth(), start.getDate() + i);
      return {
        date,
        key: dayKey(date.toISOString()),
        inMonth: date.getMonth() === month,
      };
    });
  }, [cursor]);

  const daySlots = useMemo(() => {
    if (!selectedDay) return [];
    const list = byDay.get(selectedDay) ?? [];
    const map = new Map<string, CalendarOrder[]>();
    for (const order of list) {
      const key = slotKey(order.scheduledAt!);
      map.set(key, [...(map.get(key) ?? []), order]);
    }
    return [...map.entries()].sort((a, b) => a[0].localeCompare(b[0]));
  }, [byDay, selectedDay]);

  const slotOrders = useMemo(() => {
    if (!selectedSlot) return [];
    return daySlots.find(([key]) => key === selectedSlot)?.[1] ?? [];
  }, [daySlots, selectedSlot]);

  const todayKey = dayKey(new Date().toISOString());
  const monthLabel = cursor.toLocaleDateString(undefined, { month: "long", year: "numeric" });

  const shiftMonth = (delta: number) => {
    setCursor((c) => new Date(c.getFullYear(), c.getMonth() + delta, 1));
    setSelectedDay(null);
    setSelectedSlot(null);
  };

  const unscheduledCount = orders.length - scheduled.length;

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <div>
            <CardTitle className="flex items-center gap-2 text-base">
              <CalendarDays className="h-4 w-4 text-primary" /> {monthLabel}
            </CardTitle>
            <CardDescription>
              {scheduled.length} scheduled window{scheduled.length === 1 ? "" : "s"}
              {unscheduledCount > 0 && ` • ${unscheduledCount} not scheduled yet`}
            </CardDescription>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="outline" size="icon" aria-label="Previous month" onClick={() => shiftMonth(-1)}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                const now = new Date();
                setCursor(new Date(now.getFullYear(), now.getMonth(), 1));
                setSelectedDay(todayKey);
                setSelectedSlot(null);
              }}
            >
              Today
            </Button>
            <Button variant="outline" size="icon" aria-label="Next month" onClick={() => shiftMonth(1)}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-1 text-center text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
            {WEEKDAYS.map((d) => (
              <div key={d} className="py-1">
                {d}
              </div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {cells.map(({ date, key, inMonth }) => {
              const dayOrders = byDay.get(key) ?? [];
              const pickups = dayOrders.filter((o) => o.fulfillment === "pickup").length;
              const deliveries = dayOrders.length - pickups;
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => {
                    setSelectedDay(key);
                    setSelectedSlot(null);
                  }}
                  disabled={dayOrders.length === 0}
                  className={cn(
                    "min-h-[74px] rounded-md border p-1.5 text-left transition-colors",
                    inMonth ? "bg-background" : "bg-muted/30 text-muted-foreground",
                    dayOrders.length > 0 ? "hover:border-primary/60 hover:bg-primary/5" : "cursor-default",
                    key === todayKey && "border-primary",
                    key === selectedDay && "border-primary bg-primary/10"
                  )}
                >
                  <span className="text-xs font-medium">{date.getDate()}</span>
                  <div className="mt-1 space-y-0.5">
                    {deliveries > 0 && (
                      <span className="flex items-center gap-1 text-[10px] text-muted-foreground">
                        <Truck className="h-3 w-3" /> {deliveries}
                      </span>
                    )}
                    {pickups > 0 && (
                      <span className="flex items-center gap-1 text-[10px] text-muted-foreground">
                        <Store className="h-3 w-3" /> {pickups}
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {selectedDay && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">
              {new Date(`${selectedDay}T00:00:00`).toLocaleDateString(undefined, {
                weekday: "long",
                month: "long",
                day: "numeric",
              })}
            </CardTitle>
            <CardDescription>Pick a time slot to see the orders scheduled inside it.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-wrap gap-2">
              {daySlots.map(([key, list]) => (
                <Button
                  key={key}
                  size="sm"
                  variant={selectedSlot === key ? "default" : "outline"}
                  onClick={() => setSelectedSlot(selectedSlot === key ? null : key)}
                >
                  {hourLabel(key)}
                  <Badge variant="secondary" className="ml-2">
                    {list.length}
                  </Badge>
                </Button>
              ))}
            </div>

            <div className="space-y-2">
              {(selectedSlot ? slotOrders : daySlots.flatMap(([, list]) => list)).map((order) => (
                <div
                  key={order.id}
                  className="flex flex-wrap items-center justify-between gap-3 rounded-lg border p-3"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-medium">Order #{String(order.id).slice(0, 8)}</p>
                    <p className="text-xs text-muted-foreground">{order.customer}</p>
                    <p className="mt-0.5 flex items-center gap-1.5 text-xs text-muted-foreground">
                      {order.fulfillment === "pickup" ? (
                        <Store className="h-3 w-3" />
                      ) : (
                        <Truck className="h-3 w-3" />
                      )}
                      {order.scheduleLabel}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant="outline" className="capitalize">
                      {String(order.status).replace(/_/g, " ")}
                    </Badge>
                    <span className="text-sm font-semibold">{order.total}</span>
                    <Button size="sm" variant="outline" onClick={() => onOpenOrder(order.id)}>
                      Open
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
