import { Link } from "react-router-dom";
import { Bell, BellOff, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useAdminNotifications } from "@/hooks/useAdminNotifications";
import { cn } from "@/lib/utils";
import { toast } from "sonner";


export function AdminNotificationCenter() {
  const {
    notifications,
    unreadCount,
    mutedAll,
    setMutedAll,
    emailEnabled,
    setEmailEnabled,
    pushEnabled,
    setPushEnabled,
    pushPermission,
    dismiss,
    dismissAll,
    markAllRead,
    markRead,
    isOrderMuted,
    toggleOrderMute,
  } = useAdminNotifications();

  const handlePushToggle = async (enabled: boolean) => {
    const permission = await setPushEnabled(enabled);
    if (!enabled) return;
    if (permission === "unsupported") {
      toast.error("This browser doesn't support desktop notifications");
    } else if (permission === "denied") {
      toast.error("Notifications are blocked", {
        description: "Allow notifications for this site in your browser settings, then try again.",
      });
    } else if (permission === "granted") {
      toast.success("Desktop notifications enabled");
    }
  };


  return (
    <Popover onOpenChange={(open) => open && markAllRead()}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative" aria-label="Admin updates">
          {mutedAll ? <BellOff className="h-5 w-5" /> : <Bell className="h-5 w-5" />}
          {unreadCount > 0 && !mutedAll && (
            <span className="absolute -top-0.5 -right-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-medium text-destructive-foreground">
              {unreadCount > 9 ? "9+" : unreadCount}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-96 p-0">
        <div className="flex items-center justify-between px-4 py-3">
          <div>
            <p className="text-sm font-semibold">Admin updates</p>
            <p className="text-xs text-muted-foreground">Live order activity</p>
          </div>
          <div className="flex items-center gap-2">
            <Label htmlFor="mute-all" className="text-xs text-muted-foreground">
              Mute all
            </Label>
            <Switch id="mute-all" checked={mutedAll} onCheckedChange={setMutedAll} />
          </div>
        </div>
        <Separator />

        <div className="space-y-2 px-4 py-3">
          <p className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
            Delivery
          </p>
          <div className="flex items-center justify-between">
            <Label htmlFor="notify-email" className="text-xs font-normal">
              Email me these updates
            </Label>
            <Switch
              id="notify-email"
              checked={emailEnabled && !mutedAll}
              disabled={mutedAll}
              onCheckedChange={setEmailEnabled}
            />
          </div>
          <div className="flex items-center justify-between">
            <Label htmlFor="notify-push" className="text-xs font-normal">
              Desktop push notifications
              {pushPermission === "denied" && (
                <span className="ml-1 text-muted-foreground">(blocked in browser)</span>
              )}
            </Label>
            <Switch
              id="notify-push"
              checked={pushEnabled && !mutedAll}
              disabled={mutedAll || pushPermission === "unsupported"}
              onCheckedChange={handlePushToggle}
            />
          </div>
          <p className="text-[11px] text-muted-foreground">
            Muted orders and “Mute all” always win — nothing is emailed or pushed for them.
          </p>
        </div>

        <Separator />



        <ScrollArea className="max-h-80">
          {notifications.length === 0 ? (
            <p className="px-4 py-8 text-center text-sm text-muted-foreground">
              No updates yet. New orders and status changes will appear here.
            </p>
          ) : (
            <ul className="divide-y">
              {notifications.map((n) => (
                <li
                  key={n.id}
                  className={cn("flex items-start gap-2 px-4 py-3", !n.read && "bg-muted/40")}
                  onMouseEnter={() => markRead(n.id)}
                >
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium truncate">{n.title}</p>
                    {n.description && (
                      <p className="text-xs text-muted-foreground truncate">{n.description}</p>
                    )}
                    <div className="mt-1 flex items-center gap-2">
                      <span className="text-[11px] text-muted-foreground">
                        {new Date(n.createdAt).toLocaleTimeString()}
                      </span>
                      {n.status && (
                        <Badge variant="outline" className="text-[10px] capitalize">
                          {n.status.replace(/_/g, " ")}
                        </Badge>
                      )}
                      {n.orderId && (
                        <Link
                          to={`/admin/orders/${n.orderId}`}
                          className="text-[11px] text-primary hover:underline"
                        >
                          View order
                        </Link>
                      )}
                    </div>
                  </div>
                  <div className="flex shrink-0 items-center gap-1">
                    {n.orderId && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        aria-label={isOrderMuted(n.orderId) ? "Unmute this order" : "Mute this order"}
                        title={isOrderMuted(n.orderId) ? "Unmute this order" : "Mute this order"}
                        onClick={() => toggleOrderMute(n.orderId!)}
                      >
                        {isOrderMuted(n.orderId) ? (
                          <BellOff className="h-3.5 w-3.5 text-muted-foreground" />
                        ) : (
                          <Bell className="h-3.5 w-3.5" />
                        )}
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-7 w-7"
                      aria-label="Dismiss"
                      onClick={() => dismiss(n.id)}
                    >
                      <X className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </ScrollArea>

        {notifications.length > 0 && (
          <>
            <Separator />
            <div className="flex items-center justify-between px-3 py-2">
              <Button variant="ghost" size="sm" onClick={markAllRead}>
                <Check className="mr-1.5 h-3.5 w-3.5" /> Mark all read
              </Button>
              <Button variant="ghost" size="sm" onClick={dismissAll}>
                Clear all
              </Button>
            </div>
          </>
        )}
      </PopoverContent>
    </Popover>
  );
}
