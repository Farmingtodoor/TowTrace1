import { Outlet, Navigate, useLocation } from "react-router-dom";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AdminSidebar } from "./AdminSidebar";
import { useAdmin } from "@/contexts/AdminContext";
import { useAuth } from "@/contexts/AuthContext";
import { Loader2 } from "lucide-react";
import { UserMenu } from "@/components/auth/UserMenu";
import { SidebarDensityProvider } from "@/hooks/useSidebarDensity";
import { useAdminOrderRealtime } from "@/hooks/useAdminOrderRealtime";
import { AdminNotificationsProvider, useAdminNotifications } from "@/hooks/useAdminNotifications";
import { AdminNotificationCenter } from "./AdminNotificationCenter";


const pageTitles: Record<string, string> = {
  "/admin": "Dashboard",
  "/admin/orders": "Orders",
  "/farmer/orders": "Customer Orders",
  "/farmer/custom-orders": "Custom Requests",
  "/admin/products": "Products",
  "/admin/categories": "Product Categories",
  "/farmer-products": "Products",
  "/admin/payouts": "Payouts",
  "/farmer-payouts": "Payouts",
  "/admin/users": "Users",
  "/admin/farmers": "Farmers",
  "/admin/fix-roles": "Fix Farmer Roles",
  "/admin/notifications": "Notifications",
  "/admin/roles": "Roles",
  "/admin/waitlist": "Delivery Waitlist",
  "/admin/settings": "Settings",
};

/** Feeds realtime order events into the admin notification center (respects mute rules). */
function AdminRealtimeBridge() {
  const { push } = useAdminNotifications();
  useAdminOrderRealtime({
    notify: false,
    onOrderEvent: (event) =>
      push({
        orderId: event.orderId,
        title: event.title,
        description: event.description,
        status: event.status,
      }),
  });
  return null;
}

export function AdminLayout() {
  const { user, loading: authLoading } = useAuth();
  const { isAdmin, isFarmer, loading: adminLoading } = useAdmin();
  const location = useLocation();


  if (authLoading || adminLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const redirectTo = `${location.pathname}${location.search}`;

  if (!user) {
    return (
      <Navigate
        to={`/admin/login?reason=unauthenticated&from=${encodeURIComponent(redirectTo)}`}
        state={{ from: redirectTo }}
        replace
      />
    );
  }

  if (!isAdmin && !isFarmer) {
    return (
      <Navigate
        to={`/admin/login?reason=forbidden&from=${encodeURIComponent(redirectTo)}`}
        state={{ from: redirectTo }}
        replace
      />
    );
  }

  const pageTitle =
    pageTitles[location.pathname] ??
    (location.pathname.startsWith("/admin") || location.pathname.startsWith("/farmer")
      ? "Admin Panel"
      : "Admin Panel");

  return (
    <SidebarDensityProvider>
      <AdminNotificationsProvider>
        <AdminRealtimeBridge />
      <SidebarProvider>
        <div className="min-h-screen flex w-full">
          <AdminSidebar />

          <div className="flex-1 flex flex-col min-w-0">
            <header className="sticky top-0 z-10 h-14 flex items-center justify-between border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
              <div className="flex items-center gap-1">
                <SidebarTrigger className="ml-3" />
                <div className="h-5 w-px bg-border mx-2" />
                <div className="flex items-center gap-2 text-sm">
                  <span className="text-muted-foreground">Admin</span>
                  <span className="text-muted-foreground/50">/</span>
                  <h1 className="font-semibold">{pageTitle}</h1>
                </div>
              </div>
              <div className="flex items-center gap-2 mr-4">
                <AdminNotificationCenter />
                <UserMenu />
              </div>
            </header>

            <main className="flex-1 p-6 bg-muted/30">
              <div className="mx-auto max-w-7xl">
                <Outlet />
              </div>
            </main>
          </div>
        </div>
      </SidebarProvider>
      </AdminNotificationsProvider>
    </SidebarDensityProvider>
  );
}

