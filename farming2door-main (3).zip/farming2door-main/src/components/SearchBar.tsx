import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, MapPin } from "lucide-react";

const SearchBar = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [searchType, setSearchType] = useState("products"); // products, city, zipcode
  const navigate = useNavigate();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      const params = new URLSearchParams();
      
      if (searchType === "products") {
        params.set('search', searchTerm.trim());
      } else if (searchType === "city") {
        params.set('city', searchTerm.trim());
      } else if (searchType === "zipcode") {
        params.set('zipcode', searchTerm.trim());
      }
      
      navigate(`/shop?${params.toString()}`);
    }
  };

  const getPlaceholder = () => {
    switch (searchType) {
      case "city":
        return "Search by city (e.g., Austin, Dallas)...";
      case "zipcode":
        return "Search by zip code (e.g., 78701)...";
      default:
        return "Search for products, farmers, or categories...";
    }
  };

  const getIcon = () => {
    return searchType === "products" ? Search : MapPin;
  };

  const Icon = getIcon();

  return (
    <form onSubmit={handleSearch} className="w-full max-w-2xl mx-auto">
      <div className="relative flex gap-2">
        <div className="w-48">
          <Select value={searchType} onValueChange={setSearchType}>
            <SelectTrigger className="h-12 bg-background/80 backdrop-blur-sm border-border/50">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="products">
                <div className="flex items-center gap-2">
                  <Search className="h-4 w-4" />
                  Products
                </div>
              </SelectItem>
              <SelectItem value="city">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  City
                </div>
              </SelectItem>
              <SelectItem value="zipcode">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  Zip Code
                </div>
              </SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="relative flex-1">
          <Icon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
          <Input
            placeholder={getPlaceholder()}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 h-12 text-base bg-background/80 backdrop-blur-sm border-border/50 focus:border-primary"
          />
        </div>
        <Button type="submit" variant="hero" className="h-12 px-6">
          Search
        </Button>
      </div>
    </form>
  );
};

export default SearchBar;