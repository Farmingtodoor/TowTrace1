import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Loader2, Plus, Package, Users, Calendar, Edit, Trash2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

interface SubscriptionPlan {
  id: string;
  name: string;
  description: string;
  price: number;
  interval_type: string;
  interval_count: number;
  max_items: number;
  is_active: boolean;
}

interface Subscription {
  id: string;
  status: string;
  customer_id: string;
  delivery_address: string;
  next_delivery_date: string;
  profiles?: {
    full_name: string;
    email: string;
  };
}

export const FarmerSubscriptionManager = () => {
  const [plans, setPlans] = useState<SubscriptionPlan[]>([]);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [editingPlan, setEditingPlan] = useState<SubscriptionPlan | null>(null);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();

  const [newPlan, setNewPlan] = useState({
    name: '',
    description: '',
    price: '',
    interval_type: 'weekly',
    interval_count: 1,
    max_items: 5
  });

  useEffect(() => {
    if (user) {
      fetchData();
    }
  }, [user]);

  const fetchData = async () => {
    if (!user) return;
    
    try {
      // Fetch subscription plans
      const { data: plansData, error: plansError } = await supabase
        .from('subscription_plans')
        .select('*')
        .eq('farmer_id', user.id)
        .order('created_at', { ascending: false });

      if (plansError) throw plansError;

      // Fetch subscriptions
      const { data: subscriptionsData, error: subscriptionsError } = await supabase
        .from('subscriptions')
        .select('*')
        .eq('farmer_id', user.id)
        .order('created_at', { ascending: false });

      if (subscriptionsError) throw subscriptionsError;

      setPlans(plansData || []);
      setSubscriptions(subscriptionsData || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast({
        title: "Error",
        description: "Failed to load subscription data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreatePlan = async () => {
    if (!user || !newPlan.name || !newPlan.price) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    setCreating(true);
    try {
      const { error } = await supabase
        .from('subscription_plans')
        .insert({
          farmer_id: user.id,
          name: newPlan.name,
          description: newPlan.description,
          price: parseFloat(newPlan.price),
          interval_type: newPlan.interval_type,
          interval_count: newPlan.interval_count,
          max_items: newPlan.max_items,
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Subscription plan created successfully",
      });

      setNewPlan({
        name: '',
        description: '',
        price: '',
        interval_type: 'weekly',
        interval_count: 1,
        max_items: 5
      });
      setShowCreateDialog(false);
      await fetchData();
    } catch (error) {
      console.error('Error creating plan:', error);
      toast({
        title: "Error",
        description: "Failed to create subscription plan",
        variant: "destructive",
      });
    } finally {
      setCreating(false);
    }
  };

  const handleTogglePlan = async (planId: string, isActive: boolean) => {
    try {
      const { error } = await supabase
        .from('subscription_plans')
        .update({ is_active: !isActive })
        .eq('id', planId)
        .eq('farmer_id', user?.id);

      if (error) throw error;

      toast({
        title: "Success",
        description: `Plan ${!isActive ? 'activated' : 'deactivated'} successfully`,
      });

      await fetchData();
    } catch (error) {
      console.error('Error updating plan:', error);
      toast({
        title: "Error",
        description: "Failed to update plan status",
        variant: "destructive",
      });
    }
  };

  const formatInterval = (intervalType: string, intervalCount: number) => {
    const unit = intervalCount === 1 ? intervalType.slice(0, -2) : intervalType;
    return intervalCount === 1 ? `Every ${unit}` : `Every ${intervalCount} ${unit}s`;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'paused':
        return 'bg-yellow-100 text-yellow-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Subscription Plans</h2>
          <p className="text-muted-foreground">Manage your subscription offerings</p>
        </div>
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Create Plan
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Create Subscription Plan</DialogTitle>
              <DialogDescription>
                Create a new subscription plan for your customers.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Plan Name *</Label>
                <Input
                  id="name"
                  value={newPlan.name}
                  onChange={(e) => setNewPlan({ ...newPlan, name: e.target.value })}
                  placeholder="Weekly Veggie Box"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={newPlan.description}
                  onChange={(e) => setNewPlan({ ...newPlan, description: e.target.value })}
                  placeholder="Fresh seasonal vegetables delivered weekly"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="price">Price ($) *</Label>
                  <Input
                    id="price"
                    type="number"
                    step="0.01"
                    value={newPlan.price}
                    onChange={(e) => setNewPlan({ ...newPlan, price: e.target.value })}
                    placeholder="29.99"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="max_items">Max Items</Label>
                  <Input
                    id="max_items"
                    type="number"
                    value={newPlan.max_items}
                    onChange={(e) => setNewPlan({ ...newPlan, max_items: parseInt(e.target.value) })}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="interval">Delivery Frequency</Label>
                <Select
                  value={newPlan.interval_type}
                  onValueChange={(value) => setNewPlan({ ...newPlan, interval_type: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
                Cancel
              </Button>
              <Button onClick={handleCreatePlan} disabled={creating}>
                {creating ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                Create Plan
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Subscription Plans */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {plans.map((plan) => (
          <Card key={plan.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg">{plan.name}</CardTitle>
                  <CardDescription>{plan.description}</CardDescription>
                </div>
                <Badge variant={plan.is_active ? "default" : "secondary"}>
                  {plan.is_active ? 'Active' : 'Inactive'}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold">${plan.price}</span>
                  <span className="text-sm text-muted-foreground">
                    {formatInterval(plan.interval_type, plan.interval_count)}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Package className="h-4 w-4" />
                  <span>Up to {plan.max_items} items</span>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleTogglePlan(plan.id, plan.is_active)}
              >
                {plan.is_active ? 'Deactivate' : 'Activate'}
              </Button>
              <Button variant="outline" size="sm">
                <Edit className="h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {plans.length === 0 && (
        <Card className="text-center py-8">
          <CardContent>
            <Package className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Subscription Plans</h3>
            <p className="text-muted-foreground mb-4">
              Create your first subscription plan to start offering recurring deliveries.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Active Subscriptions */}
      <div className="space-y-4">
        <h3 className="text-xl font-semibold flex items-center gap-2">
          <Users className="h-5 w-5" />
          Active Subscriptions ({subscriptions.filter(s => s.status === 'active').length})
        </h3>
        
        {subscriptions.length > 0 ? (
          <div className="space-y-3">
            {subscriptions.map((subscription) => (
              <Card key={subscription.id}>
                <CardContent className="flex items-center justify-between p-4">
                  <div className="flex items-center gap-4">
                    <div>
                      <p className="font-medium">{subscription.profiles?.full_name || 'Customer'}</p>
                      <p className="text-sm text-muted-foreground">{subscription.profiles?.email || subscription.customer_id}</p>
                    </div>
                    <div className="text-sm">
                      <p>Next delivery: {subscription.next_delivery_date}</p>
                      <p className="text-muted-foreground">{subscription.delivery_address}</p>
                    </div>
                  </div>
                  <Badge className={getStatusColor(subscription.status)}>
                    {subscription.status}
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="text-center py-6">
            <CardContent>
              <Users className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-muted-foreground">No active subscriptions yet</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};