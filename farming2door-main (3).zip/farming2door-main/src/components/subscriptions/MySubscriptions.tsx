import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useAdmin } from '@/contexts/AdminContext';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Calendar, MapPin, Package, AlertCircle, Play, Pause, Users } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { format } from 'date-fns';

interface Subscription {
  id: string;
  status: string;
  current_period_end: string;
  next_delivery_date: string;
  delivery_address: string;
  special_instructions: string;
  customer_id?: string;
  farmer_id?: string;
  subscription_plans: {
    name: string;
    description: string;
    price: number;
    interval_type: string;
    interval_count: number;
    max_items: number;
  };
  profiles?: {
    full_name: string;
    email: string;
  };
}

export const MySubscriptions = () => {
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState<string | null>(null);
  const { user } = useAuth();
  const { isFarmer } = useAdmin();
  const { toast } = useToast();

  useEffect(() => {
    if (user) {
      fetchSubscriptions();
    }
  }, [user]);

  const fetchSubscriptions = async () => {
    if (!user) return;
    
    try {
      let data, error;

      if (isFarmer) {
        // Farmers see subscriptions to their plans with customer info
        const result = await supabase
          .from('subscriptions')
          .select(`
            *,
            subscription_plans (
              name,
              description,
              price,
              interval_type,
              interval_count,
              max_items
            ),
            profiles!customer_id (
              full_name,
              email
            )
          `)
          .eq('farmer_id', user.id)
          .order('created_at', { ascending: false });
        
        data = result.data;
        error = result.error;
      } else {
        // Customers see their own subscriptions
        const result = await supabase
          .from('subscriptions')
          .select(`
            *,
            subscription_plans (
              name,
              description,
              price,
              interval_type,
              interval_count,
              max_items
            )
          `)
          .eq('customer_id', user.id)
          .order('created_at', { ascending: false });
        
        data = result.data;
        error = result.error;
      }

      if (error) throw error;
      setSubscriptions(data || []);
    } catch (error) {
      console.error('Error fetching subscriptions:', error);
      toast({
        title: "Error",
        description: "Failed to load your subscriptions",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (subscriptionId: string, action: 'pause' | 'resume' | 'cancel') => {
    setUpdating(subscriptionId);
    try {
      const newStatus = action === 'pause' ? 'paused' : action === 'resume' ? 'active' : 'cancelled';
      
      let updateQuery = supabase
        .from('subscriptions')
        .update({ status: newStatus })
        .eq('id', subscriptionId);

      // Add the appropriate user ID check based on role
      if (isFarmer) {
        updateQuery = updateQuery.eq('farmer_id', user?.id);
      } else {
        updateQuery = updateQuery.eq('customer_id', user?.id);
      }

      const { error } = await updateQuery;

      if (error) throw error;

      await fetchSubscriptions();
      toast({
        title: "Success",
        description: `Subscription ${action}d successfully`,
      });
    } catch (error) {
      console.error('Error updating subscription:', error);
      toast({
        title: "Error",
        description: `Failed to ${action} subscription`,
        variant: "destructive",
      });
    } finally {
      setUpdating(null);
    }
  };

  const formatInterval = (intervalType: string, intervalCount: number) => {
    const unit = intervalCount === 1 ? intervalType.slice(0, -2) : intervalType;
    return intervalCount === 1 ? `Every ${unit}` : `Every ${intervalCount} ${unit}s`;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'paused':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'cancelled':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'past_due':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (subscriptions.length === 0) {
    return (
      <Card className="text-center py-8">
        <CardContent>
          <Package className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">
            {isFarmer ? "No Customer Subscriptions" : "No Active Subscriptions"}
          </h3>
          <p className="text-muted-foreground mb-4">
            {isFarmer 
              ? "You don't have any customers subscribed to your plans yet. Create subscription plans and promote them to attract customers."
              : "You don't have any active subscriptions yet."
            }
          </p>
          <Button onClick={() => window.location.href = isFarmer ? '/farmer-subscriptions' : '/shop'}>
            {isFarmer ? "Manage Subscription Plans" : "Shop Subscription Plans"}
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2 flex items-center gap-2">
          {isFarmer ? <Users className="h-6 w-6" /> : <Package className="h-6 w-6" />}
          {isFarmer ? "Customer Subscriptions" : "My Subscriptions"}
        </h2>
        <p className="text-muted-foreground">
          {isFarmer 
            ? "View and manage subscriptions to your farm plans"
            : "Manage your active farm subscriptions"
          }
        </p>
      </div>

      <div className="grid gap-6">
        {subscriptions.map((subscription) => (
          <Card key={subscription.id} className="overflow-hidden">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-xl">{subscription.subscription_plans.name}</CardTitle>
                  <CardDescription>{subscription.subscription_plans.description}</CardDescription>
                </div>
                <Badge className={getStatusColor(subscription.status)}>
                  {subscription.status.replace('_', ' ').toUpperCase()}
                </Badge>
              </div>
            </CardHeader>

            <CardContent className="space-y-4">
              {/* Customer info for farmers */}
              {isFarmer && subscription.profiles && (
                <div className="bg-muted/50 p-3 rounded-lg">
                  <div className="flex items-center gap-2 text-sm">
                    <Users className="h-4 w-4" />
                    <span className="font-medium">{subscription.profiles.full_name}</span>
                    <span className="text-muted-foreground">({subscription.profiles.email})</span>
                  </div>
                </div>
              )}
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <Package className="h-4 w-4" />
                    <span className="font-medium">${subscription.subscription_plans.price}</span>
                    <span className="text-muted-foreground">
                      / {formatInterval(subscription.subscription_plans.interval_type, subscription.subscription_plans.interval_count)}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4" />
                    <span className="text-muted-foreground">
                      Next delivery: {format(new Date(subscription.next_delivery_date), 'MMM dd, yyyy')}
                    </span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-start gap-2 text-sm">
                    <MapPin className="h-4 w-4 mt-0.5" />
                    <span className="text-muted-foreground">{subscription.delivery_address}</span>
                  </div>
                  {subscription.special_instructions && (
                    <div className="flex items-start gap-2 text-sm">
                      <AlertCircle className="h-4 w-4 mt-0.5" />
                      <span className="text-muted-foreground">{subscription.special_instructions}</span>
                    </div>
                  )}
                </div>
              </div>

              {subscription.status === 'past_due' && (
                <div className="bg-red-50 border border-red-200 p-3 rounded-lg">
                  <div className="flex items-center gap-2 text-red-800">
                    <AlertCircle className="h-4 w-4" />
                    <span className="text-sm font-medium">
                      Payment failed. Please update your payment method.
                    </span>
                  </div>
                </div>
              )}
            </CardContent>

            <CardFooter className="flex gap-2">
              {/* Only show management controls to customers or allow farmers to pause/resume for customers */}
              {subscription.status === 'active' && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleStatusChange(subscription.id, 'pause')}
                  disabled={updating === subscription.id}
                >
                  {updating === subscription.id ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <>
                      <Pause className="h-4 w-4 mr-2" />
                      {isFarmer ? 'Pause Customer' : 'Pause'}
                    </>
                  )}
                </Button>
              )}

              {subscription.status === 'paused' && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleStatusChange(subscription.id, 'resume')}
                  disabled={updating === subscription.id}
                >
                  {updating === subscription.id ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <>
                      <Play className="h-4 w-4 mr-2" />
                      {isFarmer ? 'Resume Customer' : 'Resume'}
                    </>
                  )}
                </Button>
              )}

              {(subscription.status === 'active' || subscription.status === 'paused') && (
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => handleStatusChange(subscription.id, 'cancel')}
                  disabled={updating === subscription.id}
                >
                  {isFarmer ? 'Cancel Customer Subscription' : 'Cancel Subscription'}
                </Button>
              )}

              {subscription.status === 'past_due' && !isFarmer && (
                <Button size="sm" className="bg-orange-600 hover:bg-orange-700">
                  Update Payment Method
                </Button>
              )}
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
};