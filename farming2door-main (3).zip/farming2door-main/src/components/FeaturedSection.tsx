import { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { Crown, Star, Package, Calendar, MapPin } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface FeaturedItem {
  purchase_id: string;
  farmer_id: string;
  item_id: string;
  feature_type: string;
  expires_at: string;
  farm_name: string;
  product_name: string;
}

interface Product {
  id: string;
  name: string;
  price: number;
  image_url: string;
  farmer: string;
  category: string;
  unit: string;
}

export const FeaturedSection = () => {
  const navigate = useNavigate();
  const [featuredItems, setFeaturedItems] = useState<FeaturedItem[]>([]);
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadFeaturedItems();
  }, []);

  const loadFeaturedItems = async () => {
    try {
      setLoading(true);
      
      // Get featured items
      const { data: featuredData, error: featuredError } = await supabase
        .rpc('get_featured_items');

      if (featuredError) {
        console.error('Error loading featured items:', featuredError);
        return;
      }

      const items = featuredData || [];
      setFeaturedItems(items);

      // Get product details for featured products
      const productIds = items
        .filter(item => item.feature_type === 'product' && item.item_id)
        .map(item => item.item_id);

      if (productIds.length > 0) {
        const { data: productsData, error: productsError } = await supabase
          .from('products')
          .select('*')
          .in('id', productIds)
          .eq('is_available', true);

        if (!productsError) {
          setFeaturedProducts(productsData || []);
        }
      }

    } catch (error) {
      console.error('Error loading featured items:', error);
    } finally {
      setLoading(false);
    }
  };

  const getFeaturedIcon = (featureType: string) => {
    switch (featureType) {
      case 'top_spot':
        return <Crown className="w-4 h-4 text-yellow-500" />;
      case 'farm':
        return <Star className="w-4 h-4 text-blue-500" />;
      case 'product':
        return <Package className="w-4 h-4 text-green-500" />;
      default:
        return <Star className="w-4 h-4" />;
    }
  };

  const handleProductClick = (productId: string) => {
    navigate(`/products/${productId}`);
  };

  const handleFarmClick = (farmerId: string, farmName: string) => {
    const farmerSlug = farmName.toLowerCase().replace(/\s+/g, '-');
    navigate(`/farmers/${farmerSlug}?farmer=${encodeURIComponent(farmName)}`);
  };

  if (loading) {
    return (
      <div className="animate-pulse space-y-4">
        <div className="h-6 bg-muted rounded w-1/4"></div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-48 bg-muted rounded"></div>
          ))}
        </div>
      </div>
    );
  }

  const topSpotItems = featuredItems.filter(item => item.feature_type === 'top_spot');
  const featuredFarms = featuredItems.filter(item => item.feature_type === 'farm');
  const featuredProductItems = featuredItems.filter(item => item.feature_type === 'product');

  if (featuredItems.length === 0) {
    return null; // Don't show section if no featured items
  }

  return (
    <section className="py-12 bg-gradient-to-br from-primary/5 to-secondary/10">
      <div className="container mx-auto px-4">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-4">Featured This Week</h2>
          <p className="text-lg text-muted-foreground">
            Discover our top farmers and premium products
          </p>
        </div>

        {/* Top Spot Hero Items */}
        {topSpotItems.length > 0 && (
          <div className="mb-12">
            <div className="grid gap-6">
              {topSpotItems.map((item) => (
                <Card key={item.purchase_id} className="relative overflow-hidden border-2 border-yellow-200 bg-gradient-to-r from-yellow-50 to-orange-50">
                  <CardContent className="p-8">
                    <div className="flex items-center justify-between mb-4">
                      <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 border-yellow-300">
                        <Crown className="w-3 h-3 mr-1" />
                        Premium Featured
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        <Calendar className="w-3 h-3 mr-1" />
                        Until {new Date(item.expires_at).toLocaleDateString()}
                      </Badge>
                    </div>
                    <div className="text-center">
                      <h3 className="text-2xl font-bold mb-2">{item.farm_name}</h3>
                      <p className="text-muted-foreground mb-4">Premium local farm</p>
                      <Button 
                        onClick={() => handleFarmClick(item.farmer_id, item.farm_name)}
                        size="lg"
                        className="bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600"
                      >
                        Visit Farm Store
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Featured Products */}
        {featuredProducts.length > 0 && (
          <div className="mb-8">
            <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Package className="w-5 h-5 text-green-500" />
              Featured Products
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {featuredProducts.map((product) => (
                <Card key={product.id} className="relative overflow-hidden border-green-200 hover:shadow-lg transition-shadow cursor-pointer" onClick={() => handleProductClick(product.id)}>
                  <Badge className="absolute top-2 right-2 z-10 bg-green-500">
                    <Package className="w-3 h-3 mr-1" />
                    Featured
                  </Badge>
                  <div className="aspect-video bg-muted rounded-t-lg overflow-hidden">
                    {product.image_url ? (
                      <img 
                        src={product.image_url} 
                        alt={product.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Package className="w-12 h-12 text-muted-foreground" />
                      </div>
                    )}
                  </div>
                  <CardContent className="p-4">
                    <h4 className="font-semibold mb-1">{product.name}</h4>
                    <p className="text-sm text-muted-foreground mb-2">by {product.farmer}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-bold text-primary">
                        ${product.price}/{product.unit}
                      </span>
                      <Badge variant="outline" className="text-xs">
                        {product.category}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Featured Farms */}
        {featuredFarms.length > 0 && (
          <div>
            <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Star className="w-5 h-5 text-blue-500" />
              Featured Farms
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredFarms.map((item) => (
                <Card key={item.purchase_id} className="border-blue-200 hover:shadow-lg transition-shadow cursor-pointer" onClick={() => handleFarmClick(item.farmer_id, item.farm_name)}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                        <Star className="w-3 h-3 mr-1" />
                        Featured Farm
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        <Calendar className="w-3 h-3 mr-1" />
                        Until {new Date(item.expires_at).toLocaleDateString()}
                      </Badge>
                    </div>
                    <h4 className="text-lg font-semibold mb-2">{item.farm_name}</h4>
                    <p className="text-sm text-muted-foreground mb-4 flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      Local farm
                    </p>
                    <Button variant="outline" size="sm" className="w-full">
                      Visit Farm
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};