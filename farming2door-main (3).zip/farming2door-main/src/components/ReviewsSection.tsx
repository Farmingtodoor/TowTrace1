import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Star, ThumbsUp, Camera, ShieldCheck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface Review {
  id: string;
  customer_id: string;
  rating: number;
  title?: string;
  comment?: string;
  photos: string[];
  is_verified: boolean;
  is_helpful_count: number;
  created_at: string;
  customer_name?: string;
}

interface ReviewsSectionProps {
  productId: string;
  averageRating: number;
  reviewCount: number;
}

export default function ReviewsSection({ productId, averageRating, reviewCount }: ReviewsSectionProps) {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [showWriteReview, setShowWriteReview] = useState(false);
  const [canWriteReview, setCanWriteReview] = useState(false);
  const [checkingEligibility, setCheckingEligibility] = useState(false);
  const [newReview, setNewReview] = useState({
    rating: 5,
    title: "",
    comment: ""
  });
  const { user } = useAuth();

  useEffect(() => {
    fetchReviews();
    if (user) {
      checkReviewEligibility();
    }
  }, [productId, user]);

  const checkReviewEligibility = async () => {
    if (!user) {
      setCanWriteReview(false);
      return;
    }

    setCheckingEligibility(true);
    try {
      // Check if user has purchased this product and it was delivered
      const { data: eligibleOrders, error } = await supabase
        .from('orders')
        .select(`
          id,
          order_items (
            product_name
          )
        `)
        .eq('customer_id', user.id)
        .eq('status', 'delivered');

      if (error) throw error;

      // Check if any of these orders contain the specific product
      let hasOrderedProduct = false;
      if (eligibleOrders) {
        for (const order of eligibleOrders) {
          const { data: orderItems } = await supabase
            .from('order_items')
            .select('*')
            .eq('order_id', order.id);
          
          const { data: product } = await supabase
            .from('products')
            .select('name')
            .eq('id', productId)
            .single();

          if (orderItems && product && orderItems.some(item => item.product_name === product.name)) {
            hasOrderedProduct = true;
            break;
          }
        }
      }

      // Check if user already wrote a review for this product
      const { data: existingReview } = await supabase
        .from('reviews')
        .select('id')
        .eq('customer_id', user.id)
        .eq('product_id', productId)
        .single();

      // User can write review if they have delivered orders for this product and haven't reviewed it yet
      setCanWriteReview(hasOrderedProduct && !existingReview);
    } catch (error) {
      console.error('Error checking review eligibility:', error);
      setCanWriteReview(false);
    } finally {
      setCheckingEligibility(false);
    }
  };

  const fetchReviews = async () => {
    try {
      // First get reviews
      const { data: reviewsData, error: reviewsError } = await supabase
        .from('reviews')
        .select('*')
        .eq('product_id', productId)
        .order('created_at', { ascending: false });

      if (reviewsError) throw reviewsError;

      // Get customer names for each review
      const reviewsWithNames = await Promise.all(
        (reviewsData || []).map(async (review) => {
          const { data: profile } = await supabase
            .from('profiles')
            .select('full_name')
            .eq('id', review.customer_id)
            .single();

          return {
            ...review,
            photos: (review.photos as string[]) || [],
            customer_name: profile?.full_name || 'Anonymous'
          };
        })
      );

      setReviews(reviewsWithNames);
    } catch (error) {
      console.error('Error fetching reviews:', error);
    } finally {
      setLoading(false);
    }
  };

  const submitReview = async () => {
    if (!user) {
      toast.error("Please log in to write a review");
      return;
    }

    if (!canWriteReview) {
      toast.error("You can only review products you have purchased and received");
      return;
    }

    if (!newReview.comment.trim()) {
      toast.error("Please write a review comment");
      return;
    }

    try {
      // Find an eligible order for this product to include in the review
      const { data: eligibleOrder } = await supabase
        .from('orders')
        .select('id')
        .eq('customer_id', user.id)
        .eq('status', 'delivered')
        .limit(1);

      const { error } = await supabase
        .from('reviews')
        .insert({
          product_id: productId,
          customer_id: user.id,
          rating: newReview.rating,
          title: newReview.title,
          comment: newReview.comment,
          order_id: eligibleOrder?.[0]?.id || null
        });

      if (error) throw error;

      toast.success("Review submitted successfully!");
      setNewReview({ rating: 5, title: "", comment: "" });
      setShowWriteReview(false);
      setCanWriteReview(false);
      fetchReviews();
    } catch (error) {
      console.error('Error submitting review:', error);
      toast.error("Failed to submit review. You can only review products you have purchased and received.");
    }
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${
          i < rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
        }`}
      />
    ));
  };

  const getTopPositiveReview = () => {
    return reviews.find(r => r.rating >= 4) || reviews[0];
  };

  const getCriticalReview = () => {
    return reviews.find(r => r.rating <= 3 && r.comment);
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">Loading reviews...</div>
        </CardContent>
      </Card>
    );
  }

  const topReview = getTopPositiveReview();
  const criticalReview = getCriticalReview();

  return (
    <Card>
      <CardHeader>
        <CardTitle>Customer Reviews</CardTitle>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="flex">
              {renderStars(Math.round(averageRating))}
            </div>
            <span className="font-medium">{averageRating.toFixed(1)}</span>
            <span className="text-muted-foreground">({reviewCount} reviews)</span>
          </div>
          {user && canWriteReview && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowWriteReview(!showWriteReview)}
            >
              Write Review
            </Button>
          )}
          {user && !canWriteReview && !checkingEligibility && (
            <p className="text-sm text-muted-foreground">
              You can only review products you have purchased and received
            </p>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Write Review Form */}
        {showWriteReview && (
          <div className="p-4 border rounded-lg space-y-4">
            <h4 className="font-medium">Write a Review</h4>
            
            <div className="space-y-2">
              <label className="text-sm font-medium">Rating</label>
              <div className="flex gap-1">
                {Array.from({ length: 5 }, (_, i) => (
                  <button
                    key={i}
                    onClick={() => setNewReview({ ...newReview, rating: i + 1 })}
                    className="p-1"
                  >
                    <Star
                      className={`h-6 w-6 ${
                        i < newReview.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Title (optional)</label>
              <Input
                placeholder="Summary of your experience"
                value={newReview.title}
                onChange={(e) => setNewReview({ ...newReview, title: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Review</label>
              <Textarea
                placeholder="Tell us about your experience with this product"
                value={newReview.comment}
                onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
                rows={4}
              />
            </div>

            <div className="flex gap-2">
              <Button onClick={submitReview}>Submit Review</Button>
              <Button variant="outline" onClick={() => setShowWriteReview(false)}>
                Cancel
              </Button>
            </div>
          </div>
        )}

        {/* Featured Reviews */}
        {(topReview || criticalReview) && (
          <div className="space-y-4">
            <h4 className="font-medium">Featured Reviews</h4>
            
            {topReview && (
              <div className="p-4 border rounded-lg bg-green-50 border-green-200">
                <div className="flex items-start gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>
                      {topReview.customer_name?.[0]?.toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium">{topReview.customer_name}</span>
                      <div className="flex">
                        {renderStars(topReview.rating)}
                      </div>
                      {topReview.is_verified && (
                        <Badge className="bg-green-100 text-green-800 text-xs">
                          <ShieldCheck className="h-3 w-3 mr-1" />
                          Verified
                        </Badge>
                      )}
                    </div>
                    {topReview.title && (
                      <h5 className="font-medium mb-1">{topReview.title}</h5>
                    )}
                    <p className="text-sm text-gray-700">{topReview.comment}</p>
                    <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                      <span>{new Date(topReview.created_at).toLocaleDateString()}</span>
                      <Button variant="ghost" size="sm" className="h-6 px-2">
                        <ThumbsUp className="h-3 w-3 mr-1" />
                        Helpful ({topReview.is_helpful_count})
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {criticalReview && (
              <div className="p-4 border rounded-lg bg-orange-50 border-orange-200">
                <div className="flex items-start gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>
                      {criticalReview.customer_name?.[0]?.toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium">{criticalReview.customer_name}</span>
                      <div className="flex">
                        {renderStars(criticalReview.rating)}
                      </div>
                      {criticalReview.is_verified && (
                        <Badge className="bg-green-100 text-green-800 text-xs">
                          <ShieldCheck className="h-3 w-3 mr-1" />
                          Verified
                        </Badge>
                      )}
                    </div>
                    {criticalReview.title && (
                      <h5 className="font-medium mb-1">{criticalReview.title}</h5>
                    )}
                    <p className="text-sm text-gray-700">{criticalReview.comment}</p>
                    <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                      <span>{new Date(criticalReview.created_at).toLocaleDateString()}</span>
                      <span className="text-orange-600">Most helpful critical review</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* All Reviews */}
        {reviews.length > 2 && (
          <div className="space-y-4">
            <h4 className="font-medium">All Reviews ({reviewCount})</h4>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {reviews.slice(2).map((review) => (
                <div key={review.id} className="p-3 border rounded-lg">
                  <div className="flex items-start gap-3">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback>
                        {review.customer_name?.[0]?.toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium">{review.customer_name}</span>
                        <div className="flex">
                          {renderStars(review.rating)}
                        </div>
                        {review.is_verified && (
                          <Badge variant="outline" className="text-xs">
                            Verified
                          </Badge>
                        )}
                      </div>
                      {review.title && (
                        <h5 className="font-medium mb-1">{review.title}</h5>
                      )}
                      <p className="text-sm">{review.comment}</p>
                      <div className="text-xs text-muted-foreground mt-1">
                        {new Date(review.created_at).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {reviews.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            <Star className="h-12 w-12 mx-auto mb-2 text-gray-300" />
            <p>No reviews yet. Be the first to review this product!</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}