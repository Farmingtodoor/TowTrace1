import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { ShoppingCart, Plus } from "lucide-react";

interface ProcessingAddon {
  name: string;
  price: number;
  description?: string;
}

interface AnimalProcessingOptionsProps {
  productName: string;
  basePrice: number;
  portionOptions: string[];
  processingAddons: ProcessingAddon[];
  onAddToCart: (options: {
    portion: string;
    addons: ProcessingAddon[];
    totalPrice: number;
  }) => void;
}

const portionLabels: { [key: string]: string } = {
  whole: "Whole Animal",
  half: "Half Animal", 
  quarter: "Quarter Animal"
};

export default function AnimalProcessingOptions({
  productName,
  basePrice,
  portionOptions,
  processingAddons,
  onAddToCart
}: AnimalProcessingOptionsProps) {
  const [selectedPortion, setSelectedPortion] = useState(portionOptions[0] || "whole");
  const [selectedAddons, setSelectedAddons] = useState<ProcessingAddon[]>([]);

  const handleAddonToggle = (addon: ProcessingAddon, checked: boolean) => {
    if (checked) {
      setSelectedAddons([...selectedAddons, addon]);
    } else {
      setSelectedAddons(selectedAddons.filter(a => a.name !== addon.name));
    }
  };

  const getPortionMultiplier = (portion: string) => {
    switch (portion) {
      case "half": return 0.5;
      case "quarter": return 0.25;
      default: return 1;
    }
  };

  const portionPrice = basePrice * getPortionMultiplier(selectedPortion);
  const addonsPrice = selectedAddons.reduce((sum, addon) => sum + addon.price, 0);
  const totalPrice = portionPrice + addonsPrice;

  const handleAddToCart = () => {
    onAddToCart({
      portion: selectedPortion,
      addons: selectedAddons,
      totalPrice
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Processing Options</CardTitle>
        <p className="text-sm text-muted-foreground">
          Choose your preferred portion size and processing add-ons for {productName}
        </p>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Portion Selector */}
        <div className="space-y-3">
          <h4 className="font-medium">Portion Size</h4>
          <RadioGroup value={selectedPortion} onValueChange={setSelectedPortion}>
            <div className="grid gap-3">
              {portionOptions.map((portion) => (
                <div key={portion} className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-muted/50">
                  <RadioGroupItem value={portion} id={portion} />
                  <Label htmlFor={portion} className="flex-1 cursor-pointer">
                    <div className="flex justify-between items-center">
                      <span>{portionLabels[portion] || portion}</span>
                      <span className="font-medium">
                        ${(basePrice * getPortionMultiplier(portion)).toFixed(2)}
                      </span>
                    </div>
                  </Label>
                </div>
              ))}
            </div>
          </RadioGroup>
        </div>

        <Separator />

        {/* Processing Add-ons */}
        {processingAddons.length > 0 && (
          <div className="space-y-3">
            <h4 className="font-medium">Processing Add-ons</h4>
            <div className="space-y-2">
              {processingAddons.map((addon) => (
                <div key={addon.name} className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50">
                  <div className="flex items-center space-x-3">
                    <Checkbox
                      checked={selectedAddons.some(a => a.name === addon.name)}
                      onCheckedChange={(checked) => handleAddonToggle(addon, checked as boolean)}
                    />
                    <div>
                      <span className="font-medium">{addon.name}</span>
                      {addon.description && (
                        <p className="text-sm text-muted-foreground">{addon.description}</p>
                      )}
                    </div>
                  </div>
                  <Badge variant="outline">+${addon.price}</Badge>
                </div>
              ))}
            </div>
          </div>
        )}

        <Separator />

        {/* Order Summary */}
        <div className="space-y-3">
          <h4 className="font-medium">Order Summary</h4>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span>{portionLabels[selectedPortion]} ({selectedPortion})</span>
              <span>${portionPrice.toFixed(2)}</span>
            </div>
            {selectedAddons.map((addon) => (
              <div key={addon.name} className="flex justify-between text-muted-foreground">
                <span>{addon.name}</span>
                <span>+${addon.price.toFixed(2)}</span>
              </div>
            ))}
            <Separator />
            <div className="flex justify-between font-medium text-lg">
              <span>Total</span>
              <span>${totalPrice.toFixed(2)}</span>
            </div>
          </div>
        </div>

        <Button onClick={handleAddToCart} className="w-full" size="lg">
          <ShoppingCart className="h-4 w-4 mr-2" />
          Add to Cart - ${totalPrice.toFixed(2)}
        </Button>
      </CardContent>
    </Card>
  );
}