import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { toast } from "sonner";
import { Upload, Camera, X } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

interface ProfilePictureUploadProps {
  currentPictureUrl?: string;
  onPictureChange: (url: string | null) => void;
  userName?: string;
}

export default function ProfilePictureUpload({ 
  currentPictureUrl, 
  onPictureChange, 
  userName 
}: ProfilePictureUploadProps) {
  const [uploading, setUploading] = useState(false);
  const { user } = useAuth();

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !user) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast.error('Please select an image file');
      return;
    }

    // Validate file size (2MB max)
    if (file.size > 2 * 1024 * 1024) {
      toast.error('Image must be smaller than 2MB');
      return;
    }

    setUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}/profile-picture.${fileExt}`;

      // Upload to Supabase storage
      const { error: uploadError } = await supabase.storage
        .from('product-images')  // Using existing bucket
        .upload(fileName, file, {
          upsert: true // Replace if exists
        });

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('product-images')
        .getPublicUrl(fileName);

      // Update profile in database
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ profile_picture_url: publicUrl })
        .eq('id', user.id);

      if (updateError) throw updateError;

      onPictureChange(publicUrl);
      toast.success('Profile picture updated successfully!');
    } catch (error: any) {
      console.error('Error uploading profile picture:', error);
      toast.error(`Failed to upload profile picture: ${error.message}`);
    } finally {
      setUploading(false);
      // Reset input
      event.target.value = '';
    }
  };

  const handleRemovePicture = async () => {
    if (!user) return;

    try {
      // Update profile in database to remove picture
      const { error } = await supabase
        .from('profiles')
        .update({ profile_picture_url: null })
        .eq('id', user.id);

      if (error) throw error;

      onPictureChange(null);
      toast.success('Profile picture removed successfully!');
    } catch (error: any) {
      console.error('Error removing profile picture:', error);
      toast.error(`Failed to remove profile picture: ${error.message}`);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <Avatar className="h-24 w-24">
          <AvatarImage 
            src={currentPictureUrl} 
            alt={userName || 'Profile picture'} 
          />
          <AvatarFallback className="text-2xl">
            {userName ? userName.charAt(0).toUpperCase() : <Camera className="h-8 w-8" />}
          </AvatarFallback>
        </Avatar>

        <div className="space-y-2">
          <Label>Profile Picture</Label>
          <div className="flex gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={uploading}
              onClick={() => document.getElementById('profile-picture-input')?.click()}
            >
              <Upload className="h-4 w-4 mr-2" />
              {uploading ? 'Uploading...' : 'Change Photo'}
            </Button>
            
            {currentPictureUrl && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleRemovePicture}
                className="text-destructive hover:text-destructive"
              >
                <X className="h-4 w-4 mr-2" />
                Remove
              </Button>
            )}
          </div>
          
          <p className="text-xs text-muted-foreground">
            Upload a profile picture (max 2MB). JPG, PNG, or WebP format.
          </p>
        </div>
      </div>

      <Input
        id="profile-picture-input"
        type="file"
        accept="image/*"
        onChange={handleFileUpload}
        disabled={uploading}
        className="hidden"
      />
    </div>
  );
}