import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useCart } from "@/contexts/CartContext";
import { useNavigate } from "react-router-dom";
import { Star, MapPin, ShoppingCart, Truck, Calendar, ShieldCheck, Play, Image as ImageIcon, Heart, Share2, User, Leaf } from "lucide-react";
import { useFavorites } from "@/hooks/useFavorites";
import { useToast } from "@/hooks/use-toast";
import { ChatButton } from "@/components/chat/ChatButton";
import { useProductDiscounts } from "@/hooks/useProductDiscounts";
import LiveInventoryStatus from "@/components/realtime/LiveInventoryStatus";
import { CertificationBadges } from "@/components/CertificationBadges";

interface MediaFile {
  url: string;
  type: 'image' | 'video';
  name: string;
}

interface ProductCardProps {
  id: string;
  name: string;
  farmer: string;
  location: string;
  price: string;
  originalPrice?: string;
  rating: number;
  reviewCount: number;
  image: string;
  images?: MediaFile[];
  videos?: MediaFile[];
  category: string;
  isOrganic?: boolean;
  inStock: boolean;
  distance?: number;
  nextDeliveryDay?: string;
  unit?: string;
  certifications?: string[];
  deliveryAvailable?: boolean;
  farmerId?: string;
  sustainabilityScore?: number; // 0-100
}

const ProductCard = ({ 
  id,
  name, 
  farmer, 
  location, 
  price, 
  originalPrice, 
  rating, 
  reviewCount, 
  image, 
  images = [],
  videos = [],
  category,
  isOrganic = false,
  inStock = true,
  distance,
  nextDeliveryDay,
  unit = "lb",
  certifications = [],
  deliveryAvailable = false,
  farmerId,
  sustainabilityScore = 75 // default score
}: ProductCardProps) => {
  const { addItem } = useCart();
  const navigate = useNavigate();
  const { toggleFavorite, isFavorited } = useFavorites();
  const { toast } = useToast();
  
  // Parse price to number for discount calculations
  const numericPrice = typeof price === 'string' ? parseFloat(price.replace('$', '')) : price;
  const { discountInfo } = useProductDiscounts(id, numericPrice, farmerId);

  // Use images from media array if available, otherwise fallback to image prop
  const displayImage = (images && images.length > 0) ? images[0].url : image;
  const hasMultipleImages = images && images.length > 1;
  const hasVideos = videos && videos.length > 0;

  const handleCardClick = () => {
    navigate(`/products/${id}`);
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (!inStock) {
      return;
    }
    
    addItem({
      id,
      name,
      farmer,
      price,
      image,
      category,
      isOrganic
    });
  };

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleFavorite(id);
  };

  const handleShareClick = async (e: React.MouseEvent) => {
    e.stopPropagation();
    
    const productUrl = `${window.location.origin}/products/${id}`;
    const shareData = {
      title: name,
      text: `Check out this fresh ${name} from ${farmer} on Farming2Door!`,
      url: productUrl,
    };

    try {
      if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
        await navigator.share(shareData);
      } else {
        // Fallback to copying URL to clipboard
        await navigator.clipboard.writeText(productUrl);
        toast({
          title: "Link Copied!",
          description: "Product link has been copied to your clipboard.",
        });
      }
    } catch (error) {
      console.error('Error sharing:', error);
      toast({
        title: "Share Failed",
        description: "Unable to share this product. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <Card className="group hover:shadow-xl transition-all duration-300 cursor-pointer border-0 shadow-soft" onClick={handleCardClick}>
      <CardContent className="p-0">
        <div className="relative overflow-hidden rounded-t-lg">
          <img
            src={displayImage}
            alt={name}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
          />
          
          {/* Media indicators, share and favorite buttons */}
          <div className="absolute top-3 right-3 flex flex-col gap-1">
            <Button
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0 bg-black/20 hover:bg-black/40 rounded-full"
              onClick={handleShareClick}
            >
              <Share2 className="h-4 w-4 fill-white text-white" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0 bg-black/20 hover:bg-black/40 rounded-full"
              onClick={handleFavoriteClick}
            >
              <Heart 
                className={`h-4 w-4 ${
                  isFavorited(id) 
                    ? 'fill-red-500 text-red-500' 
                    : 'fill-white text-white'
                }`} 
              />
            </Button>
            {hasMultipleImages && (
              <div className="bg-black/70 text-white px-2 py-1 rounded-full text-xs flex items-center gap-1">
                <ImageIcon className="h-3 w-3" />
                {images!.length}
              </div>
            )}
            {hasVideos && (
              <div className="bg-black/70 text-white px-2 py-1 rounded-full text-xs flex items-center gap-1">
                <Play className="h-3 w-3" />
                {videos!.length}
              </div>
            )}
          </div>
          
          <div className="absolute top-3 left-3 flex flex-col gap-1.5">
            <div className="flex gap-2">
              <Badge variant="secondary" className="text-xs shadow-sm">
                {category}
              </Badge>
              {deliveryAvailable && (
                <Badge className="bg-primary text-primary-foreground text-xs flex items-center gap-1 shadow-sm">
                  <Truck className="h-2 w-2" />
                  Delivery
                </Badge>
              )}
            </div>
            {certifications.length > 0 && (
              <CertificationBadges 
                certifications={certifications} 
                size="sm" 
                maxDisplay={2}
                variant="icons-only"
              />
            )}
            {sustainabilityScore >= 70 && (
              <Badge className="bg-gradient-to-r from-green-600 to-emerald-600 text-white text-xs flex items-center gap-1 shadow-sm border-0">
                <Leaf className="h-2 w-2" />
                Sustainable
              </Badge>
            )}
          </div>
          {!inStock && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <Badge variant="destructive">Out of Stock</Badge>
            </div>
          )}
        </div>
        
        <div className="p-4 space-y-3">
          <div>
            <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors line-clamp-2">
              {name}
            </h3>
            <p className="text-sm text-muted-foreground">
              by{' '}
              <Button
                variant="link"
                className="p-0 h-auto text-sm font-medium text-muted-foreground hover:text-primary underline"
                onClick={(e) => {
                  e.stopPropagation();
                  if (farmerId) {
                    navigate(`/farmers/${farmerId}`);
                  } else {
                    toast({ title: "Farmer profile not available", variant: "destructive" });
                  }
                }}
              >
                {farmer}
              </Button>
            </p>
          </div>

          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <MapPin className="h-3 w-3" />
              <span>{location}</span>
            </div>
            {distance && (
              <span>{distance.toFixed(1)}mi away</span>
            )}
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1">
              <Star className="h-4 w-4 fill-accent-warm text-accent-warm" />
              <span className="text-sm font-medium">{rating.toFixed(1)}</span>
              <span className="text-sm text-muted-foreground">({reviewCount})</span>
            </div>
            {nextDeliveryDay && (
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Calendar className="h-3 w-3" />
                <span>Next: {nextDeliveryDay}</span>
              </div>
            )}
          </div>

          {/* Live Inventory Status */}
          <div className="mb-2">
            <LiveInventoryStatus 
              productId={id}
              stockQuantity={inStock ? 15 : 0}
              harvestDate={nextDeliveryDay}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex flex-col">
              {discountInfo.hasDiscount ? (
                <>
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-bold text-primary">
                      ${discountInfo.discountedPrice.toFixed(2)}
                    </span>
                    <Badge variant="destructive" className="text-xs">
                      -{discountInfo.discountPercentage.toFixed(0)}%
                    </Badge>
                  </div>
                  <span className="text-sm text-muted-foreground line-through">
                    ${discountInfo.originalPrice.toFixed(2)}
                  </span>
                  <span className="text-xs text-muted-foreground">per {unit}</span>
                </>
              ) : (
                <>
                  <span className="text-lg font-bold text-primary">{price}</span>
                  <span className="text-xs text-muted-foreground">per {unit}</span>
                  {originalPrice && (
                    <span className="text-sm text-muted-foreground line-through">{originalPrice}</span>
                  )}
                </>
              )}
            </div>
            <div className="flex gap-2">
              {farmerId && (
                <ChatButton 
                  farmerId={farmerId} 
                  farmerName={farmer}
                  size="sm"
                  variant="outline"
                />
              )}
              <Button 
                variant="sage" 
                size="sm" 
                disabled={!inStock}
                className="gap-1"
                onClick={handleAddToCart}
              >
                <ShoppingCart className="h-4 w-4" />
                Add
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProductCard;