import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Leaf, 
  Droplet, 
  Wind, 
  Recycle, 
  TreePine,
  Sprout,
  Sun,
  Factory,
  TrendingDown,
  Award,
  Heart
} from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface SustainabilityMetrics {
  carbonFootprint?: number; // kg CO2 per year
  waterUsage?: number; // gallons per year
  landSize?: number; // acres
  organicPercentage?: number; // 0-100
  renewableEnergy?: number; // 0-100 percentage
  wasteReduction?: number; // 0-100 percentage
  biodiversityScore?: number; // 0-100
  soilHealth?: 'excellent' | 'good' | 'fair' | 'needs-improvement';
  practices?: string[];
}

interface SustainabilityDashboardProps {
  metrics?: SustainabilityMetrics;
  farmName: string;
}

const soilHealthConfig = {
  'excellent': { color: 'text-green-600', bgColor: 'bg-green-100', label: 'Excellent', score: 95 },
  'good': { color: 'text-blue-600', bgColor: 'bg-blue-100', label: 'Good', score: 80 },
  'fair': { color: 'text-yellow-600', bgColor: 'bg-yellow-100', label: 'Fair', score: 60 },
  'needs-improvement': { color: 'text-orange-600', bgColor: 'bg-orange-100', label: 'Needs Improvement', score: 40 },
};

export function SustainabilityDashboard({ metrics, farmName }: SustainabilityDashboardProps) {
  // Default values if no metrics provided
  const defaultMetrics: SustainabilityMetrics = {
    carbonFootprint: 2500,
    waterUsage: 50000,
    landSize: 10,
    organicPercentage: 80,
    renewableEnergy: 45,
    wasteReduction: 70,
    biodiversityScore: 75,
    soilHealth: 'good',
    practices: [
      'Crop Rotation',
      'Cover Cropping',
      'Integrated Pest Management',
      'Composting',
      'Rainwater Harvesting',
    ],
  };

  const data = metrics || defaultMetrics;
  const soilConfig = data.soilHealth ? soilHealthConfig[data.soilHealth] : soilHealthConfig['good'];

  const sustainabilityScore = Math.round(
    ((data.organicPercentage || 0) * 0.3 +
    (data.renewableEnergy || 0) * 0.2 +
    (data.wasteReduction || 0) * 0.2 +
    (data.biodiversityScore || 0) * 0.3)
  );

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-blue-600';
    if (score >= 40) return 'text-yellow-600';
    return 'text-orange-600';
  };

  const getScoreBadgeVariant = (score: number) => {
    if (score >= 80) return 'default';
    if (score >= 60) return 'secondary';
    return 'outline';
  };

  return (
    <div className="space-y-6">
      {/* Overall Sustainability Score */}
      <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-emerald-50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Leaf className="h-5 w-5 text-green-600" />
                Sustainability Score
              </CardTitle>
              <CardDescription>
                Overall environmental impact rating for {farmName}
              </CardDescription>
            </div>
            <div className="text-right">
              <div className={`text-4xl font-bold ${getScoreColor(sustainabilityScore)}`}>
                {sustainabilityScore}
              </div>
              <Badge variant={getScoreBadgeVariant(sustainabilityScore)} className="mt-1">
                {sustainabilityScore >= 80 ? 'Excellent' : sustainabilityScore >= 60 ? 'Good' : 'Fair'}
              </Badge>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Key Metrics Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Carbon Footprint */}
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Card className="hover:shadow-lg transition-shadow cursor-help">
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between">
                    <div className="space-y-2 flex-1">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Wind className="h-4 w-4" />
                        <span className="text-sm font-medium">Carbon Footprint</span>
                      </div>
                      <div className="text-2xl font-bold text-foreground">
                        {data.carbonFootprint?.toLocaleString()}
                      </div>
                      <div className="text-xs text-muted-foreground">kg CO₂/year</div>
                      <div className="flex items-center gap-1 text-green-600">
                        <TrendingDown className="h-3 w-3" />
                        <span className="text-xs font-medium">30% below average</span>
                      </div>
                    </div>
                    <div className="p-2 bg-green-100 rounded-lg">
                      <Wind className="h-5 w-5 text-green-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TooltipTrigger>
            <TooltipContent className="max-w-xs">
              <p className="font-semibold mb-1">Low Carbon Farming</p>
              <p className="text-xs">This farm produces 30% less carbon emissions than conventional farms of similar size through sustainable practices.</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>

        {/* Water Usage */}
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Card className="hover:shadow-lg transition-shadow cursor-help">
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between">
                    <div className="space-y-2 flex-1">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Droplet className="h-4 w-4" />
                        <span className="text-sm font-medium">Water Conservation</span>
                      </div>
                      <div className="text-2xl font-bold text-foreground">
                        {data.waterUsage?.toLocaleString()}
                      </div>
                      <div className="text-xs text-muted-foreground">gallons/year</div>
                      <div className="flex items-center gap-1 text-blue-600">
                        <Droplet className="h-3 w-3" />
                        <span className="text-xs font-medium">Efficient irrigation</span>
                      </div>
                    </div>
                    <div className="p-2 bg-blue-100 rounded-lg">
                      <Droplet className="h-5 w-5 text-blue-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TooltipTrigger>
            <TooltipContent className="max-w-xs">
              <p className="font-semibold mb-1">Water-Smart Farming</p>
              <p className="text-xs">Uses drip irrigation, rainwater harvesting, and drought-resistant crop varieties to minimize water usage.</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>

        {/* Farm Size */}
        <Card className="hover:shadow-lg transition-shadow">
          <CardContent className="pt-6">
            <div className="flex items-start justify-between">
              <div className="space-y-2 flex-1">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <TreePine className="h-4 w-4" />
                  <span className="text-sm font-medium">Farm Size</span>
                </div>
                <div className="text-2xl font-bold text-foreground">
                  {data.landSize}
                </div>
                <div className="text-xs text-muted-foreground">acres</div>
                <div className="flex items-center gap-1 text-green-600">
                  <TreePine className="h-3 w-3" />
                  <span className="text-xs font-medium">Small-scale farming</span>
                </div>
              </div>
              <div className="p-2 bg-emerald-100 rounded-lg">
                <TreePine className="h-5 w-5 text-emerald-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Progress Metrics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sprout className="h-5 w-5 text-green-600" />
            Sustainable Practices Impact
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Organic Percentage */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Leaf className="h-4 w-4 text-green-600" />
                <span className="text-sm font-medium">Organic Production</span>
              </div>
              <span className="text-sm font-bold">{data.organicPercentage}%</span>
            </div>
            <Progress value={data.organicPercentage} className="h-2" />
            <p className="text-xs text-muted-foreground">
              {data.organicPercentage}% of production uses certified organic methods
            </p>
          </div>

          {/* Renewable Energy */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sun className="h-4 w-4 text-amber-600" />
                <span className="text-sm font-medium">Renewable Energy</span>
              </div>
              <span className="text-sm font-bold">{data.renewableEnergy}%</span>
            </div>
            <Progress value={data.renewableEnergy} className="h-2" />
            <p className="text-xs text-muted-foreground">
              Solar and wind energy powers {data.renewableEnergy}% of operations
            </p>
          </div>

          {/* Waste Reduction */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Recycle className="h-4 w-4 text-blue-600" />
                <span className="text-sm font-medium">Waste Reduction</span>
              </div>
              <span className="text-sm font-bold">{data.wasteReduction}%</span>
            </div>
            <Progress value={data.wasteReduction} className="h-2" />
            <p className="text-xs text-muted-foreground">
              Composting and recycling reduces waste by {data.wasteReduction}%
            </p>
          </div>

          {/* Biodiversity */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Heart className="h-4 w-4 text-pink-600" />
                <span className="text-sm font-medium">Biodiversity Protection</span>
              </div>
              <span className="text-sm font-bold">{data.biodiversityScore}%</span>
            </div>
            <Progress value={data.biodiversityScore} className="h-2" />
            <p className="text-xs text-muted-foreground">
              Native habitats and wildlife corridors protected
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Soil Health */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Factory className="h-5 w-5 text-amber-600" />
            Soil Health Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className={`p-4 rounded-lg ${soilConfig.bgColor} flex-shrink-0`}>
              <Sprout className={`h-8 w-8 ${soilConfig.color}`} />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-lg font-semibold">{soilConfig.label}</span>
                <Badge variant="secondary">{soilConfig.score}%</Badge>
              </div>
              <p className="text-sm text-muted-foreground">
                Regular soil testing and regenerative practices maintain healthy, nutrient-rich soil that supports robust crop growth.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Sustainable Practices */}
      {data.practices && data.practices.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="h-5 w-5 text-green-600" />
              Sustainable Farming Practices
            </CardTitle>
            <CardDescription>
              Active methods used to minimize environmental impact
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-3">
              {data.practices.map((practice, index) => (
                <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors">
                  <div className="p-1.5 bg-green-100 rounded">
                    <Leaf className="h-4 w-4 text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">{practice}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Environmental Impact Summary */}
      <Card className="bg-gradient-to-br from-blue-50 to-green-50 border-green-200">
        <CardContent className="pt-6">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-white rounded-lg shadow-sm">
              <TreePine className="h-6 w-6 text-green-600" />
            </div>
            <div className="flex-1">
              <h4 className="font-semibold mb-2 text-foreground">Environmental Commitment</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">
                This farm is committed to sustainable agriculture practices that protect the environment, 
                conserve natural resources, and produce healthy food for the community. By choosing products 
                from this farm, you're supporting regenerative agriculture and a healthier planet.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
