import { useState, useEffect } from "react";
import ProductCard from "./ProductCard";
import { supabase } from "@/integrations/supabase/client";
import { Loader2 } from "lucide-react";

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  farmer: string;
  farmer_id: string;
  image_url: string | null;
  unit: string;
  stock_quantity: number;
  is_available: boolean;
  is_organic: boolean;
  harvest_date: string | null;
  expiration_date: string | null;
  created_at: string;
  images?: Array<{
    url: string;
    name: string;
    type: string;
  }>;
}

interface FarmerApplication {
  user_id: string;
  farm_name: string;
  farm_description?: string;
  general_location?: string;
}

interface Profile {
  id: string;
  city: string | null;
  state: string | null;
  country?: string | null;
  zip_code?: string | null;
}

const FeaturedProducts = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [farmerApplications, setFarmerApplications] = useState<FarmerApplication[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchLatestProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('is_available', true)
        .order('created_at', { ascending: false })
        .limit(4);

      if (error) throw error;
      setProducts((data as any) || []);
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  const fetchProfiles = async () => {
    try {
      const { data: approved, error: approvedError } = await supabase
        .rpc('get_approved_farmers_public');

      if (approvedError) throw approvedError;

      const farmerIds = (approved || []).map((f: any) => f.user_id).filter(Boolean);
      if (farmerIds.length === 0) {
        setProfiles([]);
        return;
      }

      const { data, error } = await supabase
        .rpc('get_farmer_public_locations', { _user_ids: farmerIds });

      if (error) throw error;
      setProfiles((data as any) || []);
    } catch (error) {
      console.error('Error fetching farm locations:', error);
    }
  };

  const fetchFarmerApplications = async () => {
    try {
      const { data, error } = await supabase
        .rpc('get_approved_farmers_public');

      if (error) throw error;
      
      // Map the function result to the expected format
      const mappedData = data?.map((farmer: any) => ({
        user_id: farmer.user_id,
        farm_name: farmer.farm_name,
        farm_description: farmer.farm_description || '',
        general_location: farmer.general_location
      })) || [];
      
      setFarmerApplications(mappedData);
    } catch (error) {
      console.error('Error fetching farmer applications:', error);
    }
  };

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await Promise.all([fetchLatestProducts(), fetchProfiles(), fetchFarmerApplications()]);
      setLoading(false);
    };

    loadData();
  }, []);

  const getFarmName = (farmerId: string) => {
    const farmerApp = farmerApplications.find(app => app.user_id === farmerId);
    if (farmerApp) {
      return farmerApp.farm_name;
    }
    return 'Local Farm';
  };

  const getFarmerLocation = (farmerId: string) => {
    // First try to get location from profile
    const profile = profiles.find(p => p.id === farmerId);
    if (profile?.city && profile?.state) {
      return `${profile.city}, ${profile.state}`;
    } else if (profile?.city) {
      return profile.city;
    } else if (profile?.state) {
      return profile.state;
    }
    
    // Try to extract city and state from farmer application data
    const farmerApp = farmerApplications.find(app => app.user_id === farmerId);
    if (farmerApp) {
      // First check if general_location has useful info (not generic)
      if (farmerApp.general_location && farmerApp.general_location !== 'General Area' && farmerApp.general_location !== 'Local Area') {
        return farmerApp.general_location;
      }
      
      // Try to extract location from farm description
      if (farmerApp.farm_description) {
        // Look for state code patterns like TX-123456
        const stateCodeMatch = farmerApp.farm_description.match(/([A-Z]{2})-\d+/);
        if (stateCodeMatch) {
          return stateCodeMatch[1];
        }
        
        // Look for "City, State" patterns
        const cityStateMatch = farmerApp.farm_description.match(/([A-Za-z\s]+),\s*([A-Z]{2})/);
        if (cityStateMatch) {
          const city = cityStateMatch[1].trim();
          const state = cityStateMatch[2].trim();
          return `${city}, ${state}`;
        }
        
        // Look for standalone state abbreviations
        const stateMatch = farmerApp.farm_description.match(/\b([A-Z]{2})\b/);
        if (stateMatch) {
          return stateMatch[1];
        }
      }
    }
    
    return 'Location not specified';
  };

  return (
    <section id="featured-products" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Latest Products
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Newest additions from our trusted farmers and producers
          </p>
        </div>

        {loading ? (
          <div className="flex items-center justify-center min-h-96">
            <Loader2 className="h-8 w-8 animate-spin" />
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {products.map((product) => (
              <ProductCard 
                key={product.id}
                id={product.id}
                name={product.name}
                farmer={getFarmName(product.farmer_id)}
                location={getFarmerLocation(product.farmer_id)}
                price={`$${product.price}`}
                rating={4.5}
                reviewCount={Math.floor(Math.random() * 100) + 10}
                image={product.image_url || (product.images && product.images.length > 0 ? product.images[0].url : "/placeholder.svg")}
                category={product.category}
                isOrganic={product.is_organic}
                inStock={product.stock_quantity > 0}
                farmerId={product.farmer_id}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default FeaturedProducts;