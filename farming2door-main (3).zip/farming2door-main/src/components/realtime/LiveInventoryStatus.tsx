import React, { useState, useEffect } from 'react';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { AlertTriangle, Clock, CheckCircle, Zap } from 'lucide-react';
import { cn } from '@/lib/utils';

interface LiveInventoryStatusProps {
  productId: string;
  stockQuantity: number;
  harvestDate?: string;
}

interface InventoryUpdate {
  stock_quantity: number;
  harvest_date?: string;
  updated_at: string;
}

const LiveInventoryStatus: React.FC<LiveInventoryStatusProps> = ({
  productId,
  stockQuantity: initialStock,
  harvestDate
}) => {
  const [currentStock, setCurrentStock] = useState(initialStock);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [recentlyUpdated, setRecentlyUpdated] = useState(false);

  useEffect(() => {
    setCurrentStock(initialStock);
  }, [initialStock]);

  useEffect(() => {
    // Set up real-time subscription for inventory updates
    const channel = supabase
      .channel('product-inventory-changes')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'products',
          filter: `id=eq.${productId}`
        },
        (payload) => {
          const newData = payload.new as InventoryUpdate;
          setCurrentStock(newData.stock_quantity);
          setLastUpdated(new Date());
          setRecentlyUpdated(true);
          
          // Reset the recently updated indicator after 3 seconds
          setTimeout(() => setRecentlyUpdated(false), 3000);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [productId]);

  const getStockStatus = () => {
    if (currentStock === 0) {
      return {
        text: 'Out of stock',
        variant: 'destructive' as const,
        icon: <AlertTriangle className="w-3 h-3" />,
        showIcon: true
      };
    }
    
    if (currentStock <= 3) {
      return {
        text: `Only ${currentStock} left!`,
        variant: 'destructive' as const,
        icon: <AlertTriangle className="w-3 h-3" />,
        showIcon: true
      };
    }
    
    if (currentStock <= 10) {
      return {
        text: `${currentStock} available`,
        variant: 'secondary' as const,
        icon: <Clock className="w-3 h-3" />,
        showIcon: false
      };
    }
    
    return {
      text: 'In stock',
      variant: 'secondary' as const,
      icon: <CheckCircle className="w-3 h-3" />,
      showIcon: false
    };
  };

  const getHarvestStatus = () => {
    if (!harvestDate) return null;
    
    const harvest = new Date(harvestDate);
    const now = new Date();
    const diffDays = Math.floor((now.getTime() - harvest.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffDays <= 1) {
      return {
        text: 'Just harvested!',
        variant: 'default' as const,
        className: 'bg-green-100 text-green-800 border-green-200'
      };
    }
    
    if (diffDays <= 3) {
      return {
        text: 'Fresh harvest',
        variant: 'secondary' as const,
        className: 'bg-green-50 text-green-700 border-green-200'
      };
    }
    
    return null;
  };

  const stockStatus = getStockStatus();
  const harvestStatus = getHarvestStatus();

  return (
    <div className="flex flex-wrap gap-2 items-center">
      <Badge
        variant={stockStatus.variant}
        className={cn(
          "flex items-center gap-1 transition-all duration-300",
          recentlyUpdated && "animate-pulse ring-2 ring-primary/50",
          stockStatus.variant === 'destructive' && "bg-red-100 text-red-800 border-red-200"
        )}
      >
        {stockStatus.showIcon && stockStatus.icon}
        {stockStatus.text}
        {recentlyUpdated && <Zap className="w-3 h-3 text-yellow-500" />}
      </Badge>
      
      {harvestStatus && (
        <Badge
          variant={harvestStatus.variant}
          className={harvestStatus.className}
        >
          {harvestStatus.text}
        </Badge>
      )}
      
      {lastUpdated && (
        <span className="text-xs text-muted-foreground">
          Updated {lastUpdated.toLocaleTimeString()}
        </span>
      )}
    </div>
  );
};

export default LiveInventoryStatus;