import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { supabase } from '@/integrations/supabase/client';
import { MapPin, Truck, Clock, CheckCircle2, Package, MessageSquare, Star, Phone } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { DeliveryMap } from '@/components/DeliveryMap';
import { formatETA, formatDuration } from '@/services/mapboxRoutingService';

interface OrderTrackerProps {
  orderId: string;
}

interface OrderStatus {
  id: string;
  status: string;
  delivery_address?: string;
  delivery_fee?: number;
  estimated_delivery_time?: string;
  pickup_latitude?: number;
  pickup_longitude?: number;
  delivery_latitude?: number;
  delivery_longitude?: number;
}

interface DriverInfo {
  driver_id: string;
  first_name: string;
  vehicle_type: string;
  rating: number;
  current_latitude?: number;
  current_longitude?: number;
}

const OrderTracker: React.FC<OrderTrackerProps> = ({ orderId }) => {
  const [orderStatus, setOrderStatus] = useState<OrderStatus | null>(null);
  const [driverInfo, setDriverInfo] = useState<DriverInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [liveDurationMin, setLiveDurationMin] = useState<number | null>(null);

  useEffect(() => {
    fetchOrderDetails();
    const cleanup = setupRealtimeSubscriptions();
    return cleanup;
  }, [orderId]);

  const fetchOrderDetails = async () => {
    try {
      const { data: order, error: orderError } = await supabase
        .from('orders').select('*').eq('id', orderId).single();
      if (orderError) throw orderError;
      setOrderStatus(order);

      const { data: assignment } = await supabase
        .from('driver_order_assignments')
        .select('driver_id').eq('order_id', orderId).single();

      if (assignment?.driver_id) {
        const { data: driver } = await supabase
          .rpc('get_driver_info_for_customer_order', { order_id_param: orderId });
        if (driver && driver.length > 0) setDriverInfo(driver[0]);

        const { data: driverLocation } = await supabase
          .rpc('get_driver_location_for_customer_order', { order_id_param: orderId });

        if (driverLocation && driverLocation.length > 0) {
          setDriverInfo(prev => prev ? {
            ...prev,
            current_latitude: driverLocation[0].current_latitude,
            current_longitude: driverLocation[0].current_longitude,
          } : null);
        }
      }
    } catch (error) {
      console.error('Error fetching order details:', error);
    } finally {
      setLoading(false);
    }
  };

  const setupRealtimeSubscriptions = () => {
    const orderChannel = supabase
      .channel(`order-${orderId}`)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'orders', filter: `id=eq.${orderId}` },
        (payload) => setOrderStatus(payload.new as OrderStatus))
      .subscribe();

    const assignmentChannel = supabase
      .channel(`assignment-${orderId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'driver_order_assignments', filter: `order_id=eq.${orderId}` },
        () => fetchOrderDetails())
      .subscribe();

    return () => {
      supabase.removeChannel(orderChannel);
      supabase.removeChannel(assignmentChannel);
    };
  };

  const getStatusStep = (status: string) => {
    const steps = ['pending', 'confirmed', 'preparing', 'ready', 'picked_up', 'out_for_delivery', 'delivered'];
    const idx = steps.indexOf(status);
    // Map in_transit -> out_for_delivery for driver-side parity
    if (status === 'in_transit') return steps.indexOf('out_for_delivery');
    return idx >= 0 ? idx : 0;
  };

  if (loading) {
    return (
      <Card><CardContent className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-48 bg-muted rounded-xl"></div>
          <div className="h-4 bg-muted rounded w-1/3"></div>
          <div className="h-20 bg-muted rounded"></div>
        </div>
      </CardContent></Card>
    );
  }

  if (!orderStatus) {
    return <Card><CardContent className="p-6"><p className="text-muted-foreground">Order not found</p></CardContent></Card>;
  }

  const currentStep = getStatusStep(orderStatus.status);

  // Big-picture phases (DoorDash style)
  const phases = [
    { key: 'placed', label: 'Order placed', desc: 'We received your order', minStep: 0 },
    { key: 'preparing', label: 'Farm preparing', desc: 'Your items are being packed', minStep: 1 },
    { key: 'pickup', label: 'Driver picking up', desc: 'Driver is at the farm', minStep: 4 },
    { key: 'transit', label: 'On the way', desc: 'Driver is heading to you', minStep: 5 },
    { key: 'delivered', label: 'Delivered', desc: 'Enjoy your fresh items!', minStep: 6 },
  ];
  const activePhaseIdx = phases.reduce((acc, p, i) => currentStep >= p.minStep ? i : acc, 0);

  const isActiveDelivery = ['picked_up', 'out_for_delivery', 'in_transit'].includes(orderStatus.status);
  const isDelivered = orderStatus.status === 'delivered';
  const driverLoc = driverInfo?.current_latitude && driverInfo?.current_longitude
    ? { lat: driverInfo.current_latitude, lng: driverInfo.current_longitude }
    : undefined;

  const mapAssignment = orderStatus.pickup_latitude ? [{
    id: orderId, order_id: orderId, status: orderStatus.status,
    order: {
      delivery_address: orderStatus.delivery_address || '',
      pickup_latitude: orderStatus.pickup_latitude,
      pickup_longitude: orderStatus.pickup_longitude,
      delivery_latitude: orderStatus.delivery_latitude,
      delivery_longitude: orderStatus.delivery_longitude,
    },
  }] : [];

  const showMap = mapAssignment.length > 0 && !isDelivered;
  const liveETA = liveDurationMin ? formatETA(liveDurationMin) : null;
  const liveDuration = liveDurationMin ? formatDuration(liveDurationMin) : null;

  return (
    <div className="space-y-4">
      {/* Hero ETA banner — DoorDash style */}
      {isActiveDelivery && (
        <div className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground rounded-2xl p-5 shadow-lg">
          <p className="text-xs uppercase tracking-wider opacity-80 font-semibold">Arriving</p>
          <p className="text-3xl font-extrabold mt-1">{liveETA || orderStatus.estimated_delivery_time || 'Calculating…'}</p>
          {liveDuration && <p className="text-sm opacity-90 mt-1">In about {liveDuration}</p>}
          <div className="mt-3 flex items-center gap-2 text-xs opacity-90">
            <Truck className="h-3.5 w-3.5" />
            <span>{orderStatus.status === 'out_for_delivery' || orderStatus.status === 'in_transit' ? 'Driver is on the way' : 'Driver is picking up your order'}</span>
          </div>
        </div>
      )}

      {/* Live map */}
      {showMap && (
        <Card className="overflow-hidden p-0">
          <DeliveryMap
            assignments={mapAssignment}
            driverLocation={driverLoc}
            height={isActiveDelivery ? "340px" : "220px"}
            showRoute={true}
            useRealRoute={true}
            onRouteCalculated={(min) => setLiveDurationMin(min)}
            compact={!isActiveDelivery}
          />
        </Card>
      )}

      {/* Driver card */}
      {driverInfo && isActiveDelivery && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Avatar className="h-14 w-14 border-2 border-primary/20">
                <AvatarFallback className="bg-primary/10 text-primary font-bold text-lg">
                  {driverInfo.first_name?.[0]?.toUpperCase() || 'D'}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="font-semibold">{driverInfo.first_name}</p>
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground mt-0.5">
                  <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
                  <span className="font-medium">{driverInfo.rating?.toFixed(1) || '5.0'}</span>
                  <span>•</span>
                  <span className="capitalize">{driverInfo.vehicle_type}</span>
                </div>
              </div>
              <Button size="icon" variant="outline" className="rounded-full"
                onClick={() => toast.info('Open the Messages page to chat with your driver')}>
                <MessageSquare className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Status timeline */}
      <Card>
        <CardContent className="p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-base">Order progress</h3>
            <Badge variant={isDelivered ? 'default' : 'secondary'} className="text-xs">
              {isDelivered ? '✓ Delivered' : phases[activePhaseIdx].label}
            </Badge>
          </div>

          <div className="relative">
            {phases.map((phase, index) => {
              const isCompleted = index < activePhaseIdx || isDelivered;
              const isCurrent = index === activePhaseIdx && !isDelivered;
              const isLast = index === phases.length - 1;

              return (
                <div key={phase.key} className="flex gap-3 relative">
                  {/* Connector line */}
                  {!isLast && (
                    <div className={cn(
                      "absolute left-[15px] top-8 w-0.5 h-[calc(100%-8px)]",
                      isCompleted ? "bg-primary" : "bg-muted"
                    )} />
                  )}

                  {/* Dot */}
                  <div className={cn(
                    "relative z-10 w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-all",
                    isCompleted && "bg-primary text-primary-foreground",
                    isCurrent && "bg-primary text-primary-foreground ring-4 ring-primary/20",
                    !isCompleted && !isCurrent && "bg-muted text-muted-foreground"
                  )}>
                    {isCompleted ? (
                      <CheckCircle2 className="w-4 h-4" />
                    ) : (
                      <div className={cn("w-2.5 h-2.5 rounded-full", isCurrent ? "bg-primary-foreground animate-pulse" : "bg-muted-foreground/40")} />
                    )}
                  </div>

                  {/* Content */}
                  <div className={cn("flex-1 pb-5", isLast && "pb-0")}>
                    <p className={cn(
                      "text-sm font-medium leading-tight",
                      !isCompleted && !isCurrent && "text-muted-foreground"
                    )}>
                      {phase.label}
                    </p>
                    {(isCurrent || isCompleted) && (
                      <p className="text-xs text-muted-foreground mt-0.5">{phase.desc}</p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Delivery details */}
      {orderStatus.delivery_address && (
        <Card>
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-full bg-muted flex items-center justify-center shrink-0">
                <MapPin className="h-4 w-4 text-muted-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs text-muted-foreground">Delivery address</p>
                <p className="text-sm font-medium mt-0.5">{orderStatus.delivery_address}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default OrderTracker;
