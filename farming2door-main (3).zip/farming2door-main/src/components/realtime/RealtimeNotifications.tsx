import React, { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Bell, Package, Truck, Star, ShoppingCart, Heart } from 'lucide-react';

interface NotificationData {
  id: string;
  type: string;
  title: string;
  message: string;
  order_id?: string;
  created_at: string;
}

const RealtimeNotifications: React.FC = () => {
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (!user) return;

    // Subscribe to new notifications
    const notificationChannel = supabase
      .channel('user-notifications')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'notifications',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          const notification = payload.new as NotificationData;
          showNotificationToast(notification);
        }
      )
      .subscribe();

    // Subscribe to order status updates
    const orderChannel = supabase
      .channel('user-orders')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'orders',
          filter: `customer_id=eq.${user.id}`
        },
        (payload) => {
          const order = payload.new as any;
          const oldOrder = payload.old as any;
          
          // Only show notification if status actually changed
          if (order.status !== oldOrder.status) {
            showOrderStatusToast(order);
          }
        }
      )
      .subscribe();

    // Subscribe to new products from favorited farmers
    const productChannel = supabase
      .channel('new-products')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'products'
        },
        async (payload) => {
          const product = payload.new as any;
          await checkAndNotifyFavoriteFarmer(product);
        }
      )
      .subscribe();

    // Subscribe to inventory updates for products in cart/wishlist
    const inventoryChannel = supabase
      .channel('inventory-alerts')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'products'
        },
        (payload) => {
          const product = payload.new as any;
          const oldProduct = payload.old as any;
          
          // Check if stock went from 0 to > 0 (back in stock)
          if (oldProduct.stock_quantity === 0 && product.stock_quantity > 0) {
            showBackInStockToast(product);
          }
          
          // Check if stock is getting low
          if (product.stock_quantity <= 3 && product.stock_quantity > 0 && 
              oldProduct.stock_quantity > 3) {
            showLowStockToast(product);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(notificationChannel);
      supabase.removeChannel(orderChannel);
      supabase.removeChannel(productChannel);
      supabase.removeChannel(inventoryChannel);
    };
  }, [user]);

  const showNotificationToast = (notification: NotificationData) => {
    const getIcon = (type: string) => {
      switch (type) {
        case 'order_status':
          return <Package className="w-4 h-4" />;
        case 'delivery_update':
          return <Truck className="w-4 h-4" />;
        case 'new_message':
          return <Bell className="w-4 h-4" />;
        case 'review_request':
          return <Star className="w-4 h-4" />;
        default:
          return <Bell className="w-4 h-4" />;
      }
    };

    toast({
      title: (
        <div className="flex items-center gap-2">
          {getIcon(notification.type)}
          {notification.title}
        </div>
      ) as any,
      description: notification.message,
      duration: 5000,
    });
  };

  const showOrderStatusToast = (order: any) => {
    const statusMessages: Record<string, string> = {
      confirmed: '✅ Your order has been confirmed!',
      preparing: '👨‍🍳 Your order is being prepared',
      ready: '📦 Your order is ready for pickup',
      picked_up: '🚚 Your order has been picked up',
      out_for_delivery: '🚛 Your order is out for delivery',
      delivered: '🎉 Your order has been delivered!'
    };

    const message = statusMessages[order.status];
    if (message) {
      toast({
        title: (
          <div className="flex items-center gap-2">
            <Package className="w-4 h-4" />
            Order Update
          </div>
        ) as any,
        description: message,
        duration: 6000,
      });
    }
  };

  const checkAndNotifyFavoriteFarmer = async (product: any) => {
    if (!user) return;

    // Check if this product is from a farmer the user has bought from before
    const { data: previousOrders } = await supabase
      .from('orders')
      .select('farmer_id')
      .eq('customer_id', user.id)
      .eq('farmer_id', product.farmer_id)
      .limit(1);

    if (previousOrders && previousOrders.length > 0) {
      toast({
        title: (
          <div className="flex items-center gap-2">
            <Heart className="w-4 h-4 text-red-500" />
            New Product from Your Farmer!
          </div>
        ) as any,
        description: `${product.name} is now available from ${product.farmer}`,
        duration: 8000,
      });
    }
  };

  const showBackInStockToast = (product: any) => {
    toast({
      title: (
        <div className="flex items-center gap-2">
          <ShoppingCart className="w-4 h-4 text-green-500" />
          Back in Stock!
        </div>
      ) as any,
      description: `${product.name} is available again with ${product.stock_quantity} items`,
      duration: 6000,
    });
  };

  const showLowStockToast = (product: any) => {
    toast({
      title: (
        <div className="flex items-center gap-2">
          <ShoppingCart className="w-4 h-4 text-orange-500" />
          Limited Stock Alert
        </div>
      ) as any,
      description: `Only ${product.stock_quantity} left of ${product.name}!`,
      duration: 5000,
    });
  };

  // This component doesn't render anything visible - it just handles notifications
  return null;
};

export default RealtimeNotifications;