import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { DollarSign, TrendingUp, Clock, CheckCircle, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

interface RevenueData {
  pendingRevenue: number;
  availableRevenue: number;
  totalRevenue: number;
  pendingOrders: number;
  deliveredOrders: number;
  totalOrders: number;
}

export const FarmerRevenueDashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [revenue, setRevenue] = useState<RevenueData>({
    pendingRevenue: 0,
    availableRevenue: 0,
    totalRevenue: 0,
    pendingOrders: 0,
    deliveredOrders: 0,
    totalOrders: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    fetchRevenueData();
  }, [user]);

  const fetchRevenueData = async () => {
    if (!user) return;
    
    try {
      // Fetch all orders for this farmer
      const { data: orders, error } = await supabase
        .from('orders')
        .select('id, status, total_amount')
        .eq('farmer_id', user.id);

      if (error) throw error;

      let pendingRevenue = 0;
      let availableRevenue = 0;
      let pendingOrders = 0;
      let deliveredOrders = 0;

      orders?.forEach(order => {
        const amount = parseFloat(order.total_amount.toString());
        
        if (order.status === 'delivered') {
          availableRevenue += amount;
          deliveredOrders++;
        } else if (['pending', 'confirmed', 'processing', 'ready', 'out_for_delivery'].includes(order.status)) {
          pendingRevenue += amount;
          pendingOrders++;
        }
      });

      setRevenue({
        pendingRevenue,
        availableRevenue,
        totalRevenue: pendingRevenue + availableRevenue,
        pendingOrders,
        deliveredOrders,
        totalOrders: orders?.length || 0,
      });
    } catch (error) {
      console.error('Error fetching revenue data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRequestPayout = () => {
    navigate('/farmer-payouts');
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin" />
          <span className="ml-2">Loading revenue data...</span>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
      {/* Available Revenue */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Available Revenue</CardTitle>
          <CheckCircle className="h-4 w-4 text-green-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-green-600">
            ${revenue.availableRevenue.toFixed(2)}
          </div>
          <p className="text-xs text-muted-foreground">
            From {revenue.deliveredOrders} delivered orders
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Ready for withdrawal
          </p>
        </CardContent>
      </Card>

      {/* Pending Revenue */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Pending Revenue</CardTitle>
          <Clock className="h-4 w-4 text-yellow-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-yellow-600">
            ${revenue.pendingRevenue.toFixed(2)}
          </div>
          <p className="text-xs text-muted-foreground">
            From {revenue.pendingOrders} active orders
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Available after delivery
          </p>
        </CardContent>
      </Card>

      {/* Total Revenue */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
          <TrendingUp className="h-4 w-4 text-primary" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">
            ${revenue.totalRevenue.toFixed(2)}
          </div>
          <p className="text-xs text-muted-foreground">
            From {revenue.totalOrders} total orders
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            All-time earnings
          </p>
        </CardContent>
      </Card>

      {/* Payout Action */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Payouts</CardTitle>
          <DollarSign className="h-4 w-4 text-primary" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold mb-2">
            ${revenue.availableRevenue.toFixed(2)}
          </div>
          <Button 
            onClick={handleRequestPayout}
            disabled={revenue.availableRevenue === 0}
            size="sm"
            className="w-full"
          >
            Request Payout
          </Button>
          <p className="text-xs text-muted-foreground mt-2">
            Only delivered orders
          </p>
        </CardContent>
      </Card>
    </div>
  );
};