import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Share2, Users, Gift, Copy, DollarSign } from "lucide-react";

interface Referral {
  id: string;
  referral_code: string;
  status: string;
  reward_amount: number;
  created_at: string;
  completed_at: string | null;
}

export const ReferralSystem = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [referralCode, setReferralCode] = useState("");
  const [referrals, setReferrals] = useState<Referral[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalEarnings, setTotalEarnings] = useState(0);

  useEffect(() => {
    if (user) {
      loadReferralData();
    }
  }, [user]);

  const loadReferralData = async () => {
    if (!user) return;
    
    try {
      // Load existing referral code or generate one
      const { data: existingReferrals } = await supabase
        .from('user_referrals')
        .select('referral_code')
        .eq('referrer_id', user.id)
        .limit(1);

      if (existingReferrals && existingReferrals.length > 0) {
        setReferralCode(existingReferrals[0].referral_code);
      } else {
        // Generate new referral code
        const { data: newCode } = await supabase.rpc('generate_referral_code', {
          user_id: user.id
        });
        
        if (newCode) {
          setReferralCode(newCode);
          
          // Create initial referral record
          await supabase.from('user_referrals').insert({
            referrer_id: user.id,
            referral_code: newCode,
            status: 'active'
          });
        }
      }

      // Load referral history
      const { data: referralHistory } = await supabase
        .from('user_referrals')
        .select('*')
        .eq('referrer_id', user.id)
        .order('created_at', { ascending: false });

      if (referralHistory) {
        setReferrals(referralHistory);
        
        // Calculate total earnings
        const earnings = referralHistory
          .filter(ref => ref.status === 'completed')
          .reduce((sum, ref) => sum + (ref.reward_amount || 0), 0);
        setTotalEarnings(earnings);
      }
    } catch (error) {
      console.error('Error loading referral data:', error);
      toast({
        title: "Error",
        description: "Failed to load referral information",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const copyReferralLink = () => {
    const referralLink = `${window.location.origin}?ref=${referralCode}`;
    navigator.clipboard.writeText(referralLink);
    
    toast({
      title: "Link Copied!",
      description: "Your referral link has been copied to clipboard",
    });
  };

  const shareReferral = () => {
    const referralLink = `${window.location.origin}?ref=${referralCode}`;
    const shareText = `Join Farm2Door and get fresh farm produce delivered! Use my referral code ${referralCode} for 10% off your first order. ${referralLink}`;
    
    if (navigator.share) {
      navigator.share({
        title: 'Join Farm2Door',
        text: shareText,
      });
    } else {
      navigator.clipboard.writeText(shareText);
      toast({
        title: "Share Text Copied!",
        description: "Share text has been copied to clipboard",
      });
    }
  };

  if (!user) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <p className="text-muted-foreground">Please sign in to access the referral program</p>
        </CardContent>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-3">
            <div className="h-4 bg-muted rounded w-1/3"></div>
            <div className="h-10 bg-muted rounded"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Referral Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Gift className="w-5 h-5" />
            Referral Program
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-3 bg-primary/5 rounded-lg">
              <div className="text-2xl font-bold text-primary">{referrals.length}</div>
              <div className="text-sm text-muted-foreground">Friends Invited</div>
            </div>
            <div className="text-center p-3 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">${totalEarnings.toFixed(2)}</div>
              <div className="text-sm text-muted-foreground">Total Earned</div>
            </div>
          </div>
          
          <Separator />
          
          <div className="space-y-3">
            <Label>Your Referral Code</Label>
            <div className="flex gap-2">
              <Input 
                value={referralCode} 
                readOnly 
                className="font-mono bg-muted"
              />
              <Button variant="outline" size="icon" onClick={copyReferralLink}>
                <Copy className="w-4 h-4" />
              </Button>
              <Button variant="outline" onClick={shareReferral}>
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </Button>
            </div>
          </div>

          <div className="text-sm text-muted-foreground bg-blue-50 p-3 rounded-lg">
            <strong>How it works:</strong>
            <ul className="mt-2 space-y-1">
              <li>• Share your code with friends</li>
              <li>• They get 10% off their first order</li>
              <li>• You earn $10 credit when they make their first purchase</li>
              <li>• No limit on referrals!</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Referral History */}
      {referrals.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Referral History
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {referrals.map((referral) => (
                <div key={referral.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <div className="font-medium">Code: {referral.referral_code}</div>
                    <div className="text-sm text-muted-foreground">
                      {new Date(referral.created_at).toLocaleDateString()}
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant={
                      referral.status === 'completed' ? 'default' : 
                      referral.status === 'pending' ? 'secondary' : 'outline'
                    }>
                      {referral.status}
                    </Badge>
                    {referral.status === 'completed' && (
                      <div className="text-sm text-green-600 flex items-center gap-1 mt-1">
                        <DollarSign className="w-3 h-3" />
                        ${referral.reward_amount.toFixed(2)}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};