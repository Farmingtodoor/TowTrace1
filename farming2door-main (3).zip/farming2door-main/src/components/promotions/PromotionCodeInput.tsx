import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Percent, Tag, AlertCircle, CheckCircle } from "lucide-react";

interface PromotionCodeInputProps {
  orderTotal: number;
  onDiscountApplied: (discount: { amount: number; code: string; promotionId: string }) => void;
  onDiscountRemoved: () => void;
  currentDiscount?: { amount: number; code: string; promotionId: string } | null;
}

export const PromotionCodeInput = ({
  orderTotal,
  onDiscountApplied,
  onDiscountRemoved,
  currentDiscount
}: PromotionCodeInputProps) => {
  const [code, setCode] = useState("");
  const [isValidating, setIsValidating] = useState(false);
  const { toast } = useToast();

  const validatePromotion = async () => {
    if (!code.trim()) {
      toast({
        title: "Invalid Code",
        description: "Please enter a promotion code",
        variant: "destructive",
      });
      return;
    }

    setIsValidating(true);
    
    try {
      const { data, error } = await supabase.rpc('validate_promotion', {
        promotion_code: code.toUpperCase(),
        user_id: (await supabase.auth.getUser()).data.user?.id || null,
        order_total: orderTotal
      });

      if (error) {
        console.error('Validation error:', error);
        throw new Error('Failed to validate promotion code');
      }

      if (data && data.length > 0) {
        const result = data[0];
        
        if (result.valid) {
          onDiscountApplied({
            amount: Number(result.discount_amount),
            code: code.toUpperCase(),
            promotionId: result.promotion_id
          });
          
          toast({
            title: "Promotion Applied!",
            description: `You saved $${Number(result.discount_amount).toFixed(2)}`,
          });
        } else {
          toast({
            title: "Invalid Promotion Code",
            description: result.error_message || "This promotion code is not valid",
            variant: "destructive",
          });
        }
      }
    } catch (error) {
      console.error('Error validating promotion:', error);
      toast({
        title: "Error",
        description: "Failed to apply promotion code. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsValidating(false);
    }
  };

  const removePromotion = () => {
    setCode("");
    onDiscountRemoved();
    toast({
      title: "Promotion Removed",
      description: "The promotion code has been removed from your order",
    });
  };

  if (currentDiscount) {
    return (
      <Card className="border-green-200 bg-green-50">
        <CardContent className="p-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <div>
                <div className="font-medium text-green-800">
                  Code: {currentDiscount.code}
                </div>
                <div className="text-sm text-green-600">
                  You save: ${currentDiscount.amount.toFixed(2)}
                </div>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={removePromotion}
              className="text-green-700 hover:text-green-800"
            >
              Remove
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      <Label htmlFor="promo-code" className="flex items-center gap-2">
        <Tag className="w-4 h-4" />
        Promotion Code
      </Label>
      <div className="flex gap-2">
        <Input
          id="promo-code"
          placeholder="Enter code (e.g., FIRST15)"
          value={code}
          onChange={(e) => setCode(e.target.value.toUpperCase())}
          className="flex-1"
          onKeyDown={(e) => e.key === 'Enter' && validatePromotion()}
        />
        <Button 
          onClick={validatePromotion}
          disabled={isValidating || !code.trim()}
          variant="outline"
        >
          {isValidating ? "..." : "Apply"}
        </Button>
      </div>

      {/* Show available promotions hint */}
      <div className="text-xs text-muted-foreground flex items-center gap-1">
        <AlertCircle className="w-3 h-3" />
        Try FIRST15 for 15% off your first order (min $25)
      </div>
    </div>
  );
};