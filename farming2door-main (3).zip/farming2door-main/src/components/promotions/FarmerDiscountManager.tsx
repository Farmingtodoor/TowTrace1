import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Plus, Edit, Trash2, Percent, DollarSign, Calendar, Package } from "lucide-react";

interface Product {
  id: string;
  name: string;
  price: number;
}

interface Promotion {
  id: string;
  code: string;
  name: string;
  description: string;
  discount_type: 'percentage' | 'fixed_amount';
  discount_value: number;
  minimum_order_amount: number;
  max_uses: number | null;
  uses_count: number;
  is_active: boolean;
  expires_at: string | null;
  applicable_products: any; // Json type from Supabase
  created_at: string;
}

export const FarmerDiscountManager = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [promotions, setPromotions] = useState<Promotion[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [isCreating, setIsCreating] = useState(false);
  
  // Form state
  const [formData, setFormData] = useState({
    code: '',
    name: '',
    description: '',
    discount_type: 'percentage',
    discount_value: 0,
    minimum_order_amount: 0,
    max_uses: '',
    expires_at: '',
    applicable_products: [] as string[]
  });

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    if (!user) return;
    
    try {
      // Load farmer's products
      const { data: productsData } = await supabase
        .from('products')
        .select('id, name, price')
        .eq('farmer_id', user.id);

      if (productsData) {
        setProducts(productsData);
      }

      // Load farmer's promotions
      const { data: promotionsData } = await supabase
        .from('promotions')
        .select('*')
        .eq('farmer_id', user.id)
        .order('created_at', { ascending: false });

      if (promotionsData) {
        setPromotions(promotionsData.map(p => ({
          ...p,
          applicable_products: Array.isArray(p.applicable_products) ? p.applicable_products : []
        })));
      }
    } catch (error) {
      console.error('Error loading data:', error);
      toast({
        title: "Error",
        description: "Failed to load discount data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const createPromotion = async () => {
    if (!user) return;

    if (!formData.code || !formData.name || formData.discount_value <= 0) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    setIsCreating(true);
    
    try {
      const promotionData = {
        code: formData.code.toUpperCase(),
        name: formData.name,
        description: formData.description,
        type: (formData.applicable_products.length > 0 ? 'product_specific' : 'general') as 'product_specific' | 'general',
        discount_type: formData.discount_type as 'percentage' | 'fixed_amount',
        discount_value: formData.discount_value,
        minimum_order_amount: formData.minimum_order_amount,
        max_uses: formData.max_uses ? parseInt(formData.max_uses) : null,
        expires_at: formData.expires_at || null,
        farmer_id: user.id,
        created_by: user.id,
        applicable_products: formData.applicable_products,
        is_active: true
      };

      const { error } = await supabase
        .from('promotions')
        .insert(promotionData);

      if (error) {
        throw error;
      }

      toast({
        title: "Success",
        description: "Discount created successfully",
      });

      // Reset form and reload data
      setFormData({
        code: '',
        name: '',
        description: '',
        discount_type: 'percentage',
        discount_value: 0,
        minimum_order_amount: 0,
        max_uses: '',
        expires_at: '',
        applicable_products: []
      });
      
      await loadData();
    } catch (error) {
      console.error('Error creating promotion:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to create discount",
        variant: "destructive",
      });
    } finally {
      setIsCreating(false);
    }
  };

  const togglePromotionStatus = async (promotionId: string, newStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('promotions')
        .update({ is_active: newStatus })
        .eq('id', promotionId);

      if (error) throw error;

      toast({
        title: "Success",
        description: `Promotion ${newStatus ? 'activated' : 'deactivated'}`,
      });

      await loadData();
    } catch (error) {
      console.error('Error updating promotion:', error);
      toast({
        title: "Error",
        description: "Failed to update promotion status",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return <div className="animate-pulse h-32 bg-muted rounded-lg"></div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Discount Management</h2>
          <p className="text-muted-foreground">Create and manage discounts for your products</p>
        </div>
        
        <Dialog>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Create Discount
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Discount</DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="code">Discount Code *</Label>
                  <Input
                    id="code"
                    placeholder="e.g., HARVEST20"
                    value={formData.code}
                    onChange={(e) => setFormData(prev => ({...prev, code: e.target.value.toUpperCase()}))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="name">Display Name *</Label>
                  <Input
                    id="name"
                    placeholder="e.g., Harvest Special"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({...prev, name: e.target.value}))}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Input
                  id="description"
                  placeholder="Describe this discount offer"
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({...prev, description: e.target.value}))}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Discount Type</Label>
                  <Select 
                    value={formData.discount_type} 
                    onValueChange={(value) => setFormData(prev => ({...prev, discount_type: value}))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="percentage">Percentage (%)</SelectItem>
                      <SelectItem value="fixed_amount">Fixed Amount ($)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="discount_value">
                    Discount Value * {formData.discount_type === 'percentage' ? '(%)' : '($)'}
                  </Label>
                  <Input
                    id="discount_value"
                    type="number"
                    min="0"
                    max={formData.discount_type === 'percentage' ? "100" : undefined}
                    value={formData.discount_value}
                    onChange={(e) => setFormData(prev => ({...prev, discount_value: parseFloat(e.target.value) || 0}))}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="min_order">Minimum Order Amount ($)</Label>
                  <Input
                    id="min_order"
                    type="number"
                    min="0"
                    value={formData.minimum_order_amount}
                    onChange={(e) => setFormData(prev => ({...prev, minimum_order_amount: parseFloat(e.target.value) || 0}))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="max_uses">Max Uses (optional)</Label>
                  <Input
                    id="max_uses"
                    type="number"
                    min="1"
                    placeholder="Unlimited"
                    value={formData.max_uses}
                    onChange={(e) => setFormData(prev => ({...prev, max_uses: e.target.value}))}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="expires_at">Expiration Date (optional)</Label>
                <Input
                  id="expires_at"
                  type="datetime-local"
                  value={formData.expires_at}
                  onChange={(e) => setFormData(prev => ({...prev, expires_at: e.target.value}))}
                />
              </div>

              <div className="space-y-2">
                <Label>Applicable Products (leave empty for all products)</Label>
                <Select onValueChange={(productId) => {
                  if (!formData.applicable_products.includes(productId)) {
                    setFormData(prev => ({
                      ...prev, 
                      applicable_products: [...prev.applicable_products, productId]
                    }));
                  }
                }}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select products" />
                  </SelectTrigger>
                  <SelectContent>
                    {products.map((product) => (
                      <SelectItem key={product.id} value={product.id}>
                        {product.name} - ${product.price}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                {formData.applicable_products.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {formData.applicable_products.map((productId) => {
                      const product = products.find(p => p.id === productId);
                      return (
                        <Badge key={productId} variant="secondary" className="cursor-pointer" onClick={() => {
                          setFormData(prev => ({
                            ...prev,
                            applicable_products: prev.applicable_products.filter(id => id !== productId)
                          }));
                        }}>
                          {product?.name} ×
                        </Badge>
                      );
                    })}
                  </div>
                )}
              </div>

              <Button onClick={createPromotion} disabled={isCreating} className="w-full">
                {isCreating ? "Creating..." : "Create Discount"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Promotions List */}
      <div className="grid gap-4">
        {promotions.length === 0 ? (
          <Card>
            <CardContent className="p-6 text-center text-muted-foreground">
              <Package className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No discounts created yet</p>
              <p className="text-sm">Create your first discount to attract more customers</p>
            </CardContent>
          </Card>
        ) : (
          promotions.map((promotion) => (
            <Card key={promotion.id}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{promotion.name}</CardTitle>
                  <div className="flex items-center gap-2">
                    <Badge variant={promotion.is_active ? "default" : "secondary"}>
                      {promotion.is_active ? "Active" : "Inactive"}
                    </Badge>
                    <Switch
                      checked={promotion.is_active}
                      onCheckedChange={(checked) => togglePromotionStatus(promotion.id, checked)}
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Code:</span> {promotion.code}
                  </div>
                  <div className="flex items-center gap-1">
                    {promotion.discount_type === 'percentage' ? (
                      <Percent className="w-3 h-3" />
                    ) : (
                      <DollarSign className="w-3 h-3" />
                    )}
                    <span className="font-medium">
                      {promotion.discount_type === 'percentage' 
                        ? `${promotion.discount_value}% off`
                        : `$${promotion.discount_value} off`
                      }
                    </span>
                  </div>
                  <div>
                    <span className="font-medium">Min Order:</span> ${promotion.minimum_order_amount}
                  </div>
                  <div>
                    <span className="font-medium">Used:</span> {promotion.uses_count}
                    {promotion.max_uses ? ` / ${promotion.max_uses}` : ' (unlimited)'}
                  </div>
                </div>
                
                {promotion.description && (
                  <p className="text-sm text-muted-foreground">{promotion.description}</p>
                )}
                
                {promotion.expires_at && (
                  <div className="flex items-center gap-1 text-sm text-orange-600">
                    <Calendar className="w-3 h-3" />
                    Expires: {new Date(promotion.expires_at).toLocaleDateString()}
                  </div>
                )}
                
                {promotion.applicable_products && Array.isArray(promotion.applicable_products) && promotion.applicable_products.length > 0 && (
                  <div className="text-sm">
                    <span className="font-medium">Applies to:</span> {promotion.applicable_products.length} specific product(s)
                  </div>
                )}
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};