import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Star, Crown, Zap, Calendar, DollarSign, Package, Sparkles } from "lucide-react";

interface FeaturedService {
  id: string;
  name: string;
  description: string;
  price: number;
  duration_days: number;
  feature_type: string;
}

interface Product {
  id: string;
  name: string;
}

interface Purchase {
  id: string;
  service_id: string;
  item_id: string;
  status: string;
  expires_at: string;
  created_at: string;
  featured_services: {
    name: string;
    feature_type: string;
  };
  products?: {
    name: string;
  } | null;
}

export const FeaturedServicesManager = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [services, setServices] = useState<FeaturedService[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState<string>("");

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      
      // Load featured services
      const { data: servicesData, error: servicesError } = await supabase
        .from('featured_services')
        .select('*')
        .eq('is_active', true)
        .order('price');

      if (servicesError) throw servicesError;
      setServices(servicesData || []);

      // Load farmer's products
      const { data: productsData, error: productsError } = await supabase
        .from('products')
        .select('id, name')
        .eq('farmer_id', user.id)
        .eq('is_available', true);

      if (productsError) throw productsError;
      setProducts(productsData || []);

      // Load farmer's purchases
      const { data: purchasesData, error: purchasesError } = await supabase
        .from('featured_purchases')
        .select(`
          *,
          featured_services(name, feature_type),
          products(name)
        `)
        .eq('farmer_id', user.id)
        .order('created_at', { ascending: false });

      if (purchasesError) throw purchasesError;
      setPurchases((purchasesData as any) || []);

    } catch (error) {
      console.error('Error loading data:', error);
      toast({
        title: "Error",
        description: "Failed to load featured services",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePurchase = async (serviceId: string, requiresProduct: boolean = false) => {
    if (!user) return;
    
    if (requiresProduct && !selectedProduct) {
      toast({
        title: "Product Required",
        description: "Please select a product to feature",
        variant: "destructive",
      });
      return;
    }

    try {
      setProcessing(serviceId);
      
      const { data, error } = await supabase.functions.invoke('purchase-featured-service', {
        body: {
          serviceId,
          itemId: requiresProduct ? selectedProduct : null,
        },
      });

      if (error) throw error;

      if (data?.url) {
        // Open Stripe checkout in a new tab
        window.open(data.url, '_blank');
        
        toast({
          title: "Redirecting to Payment",
          description: "Complete your payment to activate the featured service",
        });
      } else {
        throw new Error('No checkout URL returned');
      }

    } catch (error) {
      console.error('Purchase error:', error);
      toast({
        title: "Purchase Failed",
        description: error.message || "Failed to initiate purchase",
        variant: "destructive",
      });
    } finally {
      setProcessing("");
    }
  };

  const getServiceIcon = (featureType: string) => {
    switch (featureType) {
      case 'product':
        return <Package className="w-5 h-5" />;
      case 'farm':
        return <Star className="w-5 h-5" />;
      case 'top_spot':
        return <Crown className="w-5 h-5" />;
      default:
        return <Sparkles className="w-5 h-5" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'default';
      case 'pending':
        return 'secondary';
      case 'expired':
        return 'outline';
      default:
        return 'outline';
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-1/3"></div>
          <div className="grid gap-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-32 bg-muted rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Featured Services</h2>
        <p className="text-muted-foreground">
          Boost your visibility and sales by featuring your products and farm profile
        </p>
      </div>

      {/* Available Services - Organized by Type */}
      <div className="space-y-6">
        {/* Farm Featured Services */}
        {services.filter(s => s.feature_type === 'farm').length > 0 && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Star className="w-5 h-5 text-amber-500" />
              Featured Farm Profile
            </h3>
            <div className="grid gap-4 md:grid-cols-2">
              {services.filter(s => s.feature_type === 'farm').map((service) => (
                <Card key={service.id} className="border-amber-200 hover:border-amber-300 transition-colors">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center gap-2 text-amber-700">
                        {getServiceIcon(service.feature_type)}
                        {service.name}
                      </CardTitle>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-amber-600">
                          ${service.price}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {service.duration_days} days
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-muted-foreground">{service.description}</p>
                    <Button 
                      onClick={() => handlePurchase(service.id, false)}
                      disabled={processing === service.id}
                      className="w-full bg-amber-600 hover:bg-amber-700"
                      size="lg"
                    >
                      {processing === service.id ? (
                        <>
                          <Zap className="w-4 h-4 mr-2 animate-pulse" />
                          Processing...
                        </>
                      ) : (
                        <>
                          <Star className="w-4 h-4 mr-2" />
                          Feature My Farm
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Product Featured Services */}
        {services.filter(s => s.feature_type === 'product').length > 0 && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Package className="w-5 h-5 text-blue-500" />
              Featured Products
            </h3>
            <div className="grid gap-4 md:grid-cols-2">
              {services.filter(s => s.feature_type === 'product').map((service) => (
                <Card key={service.id} className="border-blue-200 hover:border-blue-300 transition-colors">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center gap-2 text-blue-700">
                        {getServiceIcon(service.feature_type)}
                        {service.name}
                      </CardTitle>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-blue-600">
                          ${service.price}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {service.duration_days} days
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-muted-foreground">{service.description}</p>
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Select Product to Feature:</label>
                      <Select value={selectedProduct} onValueChange={setSelectedProduct}>
                        <SelectTrigger className="border-blue-200">
                          <SelectValue placeholder="Choose a product" />
                        </SelectTrigger>
                        <SelectContent>
                          {products.map((product) => (
                            <SelectItem key={product.id} value={product.id}>
                              {product.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <Button 
                      onClick={() => handlePurchase(service.id, true)}
                      disabled={processing === service.id || products.length === 0 || !selectedProduct}
                      className="w-full bg-blue-600 hover:bg-blue-700"
                      size="lg"
                    >
                      {processing === service.id ? (
                        <>
                          <Zap className="w-4 h-4 mr-2 animate-pulse" />
                          Processing...
                        </>
                      ) : (
                        <>
                          <Package className="w-4 h-4 mr-2" />
                          Feature This Product
                        </>
                      )}
                    </Button>

                    {products.length === 0 && (
                      <p className="text-sm text-muted-foreground text-center p-3 bg-blue-50 rounded">
                        You need to have products listed to purchase this service
                      </p>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Top Spot Featured Services */}
        {services.filter(s => s.feature_type === 'top_spot').length > 0 && (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Crown className="w-5 h-5 text-purple-500" />
              Premium Top Spot
            </h3>
            <div className="grid gap-4 md:grid-cols-2">
              {services.filter(s => s.feature_type === 'top_spot').map((service) => (
                <Card key={service.id} className="border-purple-200 hover:border-purple-300 transition-colors relative overflow-hidden">
                  <div className="absolute top-0 right-0 bg-purple-500 text-white px-2 py-1 text-xs font-medium">
                    PREMIUM
                  </div>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center gap-2 text-purple-700">
                        {getServiceIcon(service.feature_type)}
                        {service.name}
                      </CardTitle>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-purple-600">
                          ${service.price}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {service.duration_days} days
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-muted-foreground">{service.description}</p>
                    <Button 
                      onClick={() => handlePurchase(service.id, false)}
                      disabled={processing === service.id}
                      className="w-full bg-purple-600 hover:bg-purple-700"
                      size="lg"
                    >
                      {processing === service.id ? (
                        <>
                          <Zap className="w-4 h-4 mr-2 animate-pulse" />
                          Processing...
                        </>
                      ) : (
                        <>
                          <Crown className="w-4 h-4 mr-2" />
                          Get Top Spot
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {services.length === 0 && (
          <Card className="text-center p-8">
            <CardContent>
              <Sparkles className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-lg font-semibold mb-2">No Featured Services Available</h3>
              <p className="text-muted-foreground">
                Featured services are currently being updated. Please check back later.
              </p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Active Featured Items */}
      {purchases.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Your Featured Services
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {purchases.map((purchase) => (
                <div key={purchase.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    {getServiceIcon(purchase.featured_services.feature_type)}
                    <div>
                      <div className="font-medium">
                        {purchase.featured_services.name}
                      </div>
                      {purchase.products && (
                        <div className="text-sm text-muted-foreground">
                          Product: {purchase.products.name}
                        </div>
                      )}
                      <div className="text-xs text-muted-foreground">
                        Expires: {new Date(purchase.expires_at).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                  <Badge variant={getStatusColor(purchase.status)}>
                    {purchase.status}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};