import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useCart } from "@/contexts/CartContext"
import { ShoppingCart } from "lucide-react"

export const CartButton = () => {
  const { getItemCount, setIsOpen } = useCart()
  const itemCount = getItemCount()

  return (
    <Button 
      variant="ghost" 
      size="icon" 
      className="relative"
      onClick={() => setIsOpen(true)}
    >
      <ShoppingCart className="h-5 w-5" />
      {itemCount > 0 && (
        <Badge 
          className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs"
          variant="default"
        >
          {itemCount > 99 ? '99+' : itemCount}
        </Badge>
      )}
    </Button>
  )
}