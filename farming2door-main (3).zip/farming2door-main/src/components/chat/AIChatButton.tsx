import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { MessageCircle } from 'lucide-react';
import { AIChatbot } from './AIChatbot';

export const AIChatButton = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <Button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 right-4 w-14 h-14 rounded-full shadow-lg z-40 bg-primary hover:bg-primary/90"
        size="sm"
      >
        <MessageCircle className="w-6 h-6" />
      </Button>

      <AIChatbot isOpen={isOpen} onClose={() => setIsOpen(false)} />
    </>
  );
};