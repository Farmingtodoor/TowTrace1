import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { MessageCircle, Clock } from 'lucide-react';
import { useChat, Conversation } from '@/hooks/useChat';
import { useAuth } from '@/contexts/AuthContext';
import { ChatDialog } from './ChatDialog';
import { format } from 'date-fns';
import { supabase } from '@/integrations/supabase/client';
import { useSearchParams } from 'react-router-dom';

export const ChatList = () => {
  const { user } = useAuth();
  const { conversations, loadConversations } = useChat();
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [searchParams] = useSearchParams();

  useEffect(() => {
    loadConversations();
  }, [loadConversations]);

  // Handle conversation parameter from URL (e.g., from email notifications)
  useEffect(() => {
    const conversationId = searchParams.get('conversation');
    if (conversationId && conversations.length > 0) {
      const conversation = conversations.find(c => c.id === conversationId);
      if (conversation) {
        setSelectedConversation(conversation);
        setIsDialogOpen(true);
        // Clear the URL parameter after opening
        const newSearchParams = new URLSearchParams(searchParams);
        newSearchParams.delete('conversation');
        window.history.replaceState({}, '', `${window.location.pathname}${newSearchParams.toString() ? '?' + newSearchParams.toString() : ''}`);
      }
    }
  }, [conversations, searchParams]);

  const handleConversationClick = (conversation: Conversation) => {
    setSelectedConversation(conversation);
    setIsDialogOpen(true);
  };

  const getOtherParticipantName = async (conversation: Conversation) => {
    const isCustomer = conversation.customer_id === user?.id;
    const otherUserId = isCustomer ? conversation.farmer_id : conversation.customer_id;
    
    try {
      const { data: profile } = await supabase
        .from('profiles')
        .select('full_name, email')
        .eq('id', otherUserId)
        .single();
        
      return profile?.full_name || profile?.email || (isCustomer ? 'Farmer' : 'Customer');
    } catch (error) {
      return isCustomer ? 'Farmer' : 'Customer';
    }
  };

  // Simplified version for display
  const getDisplayName = (conversation: Conversation) => {
    const isCustomer = conversation.customer_id === user?.id;
    return isCustomer ? 'Farmer' : 'Customer';
  };

  if (!user) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-8">
          <p className="text-muted-foreground">Please log in to view your conversations.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageCircle className="w-5 h-5" />
            My Conversations
          </CardTitle>
        </CardHeader>
        <CardContent>
          {conversations.length === 0 ? (
            <div className="text-center py-8">
              <MessageCircle className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground">No conversations yet.</p>
              <p className="text-sm text-muted-foreground mt-2">
                Start chatting with farmers by visiting their product pages.
              </p>
            </div>
          ) : (
            <ScrollArea className="h-[400px]">
              <div className="space-y-3">
                {conversations.map((conversation) => (
                  <div
                    key={conversation.id}
                    onClick={() => handleConversationClick(conversation)}
                    className="flex items-center gap-3 p-3 rounded-lg border hover:bg-muted/50 cursor-pointer transition-colors"
                  >
                    <Avatar>
                      <AvatarFallback>
                        {getDisplayName(conversation).charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                      <h4 className="font-medium truncate">
                        {getDisplayName(conversation)}
                        </h4>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Clock className="w-3 h-3" />
                          {format(new Date(conversation.last_message_at), 'MMM d')}
                        </div>
                      </div>
                      
                      {conversation.subject && (
                        <p className="text-sm text-muted-foreground truncate">
                          {conversation.subject}
                        </p>
                      )}
                      
                      <div className="flex items-center justify-between mt-1">
                        <Badge variant={conversation.status === 'active' ? 'default' : 'secondary'}>
                          {conversation.status}
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>

      {selectedConversation && (
        <ChatDialog
          isOpen={isDialogOpen}
          onClose={() => setIsDialogOpen(false)}
          conversationId={selectedConversation.id}
          recipientName={getDisplayName(selectedConversation)}
        />
      )}
    </>
  );
};