import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { MessageCircle } from 'lucide-react';
import { ChatDialog } from './ChatDialog';
import { useAuth } from '@/contexts/AuthContext';
import { useChat } from '@/hooks/useChat';
import { useToast } from '@/components/ui/use-toast';

interface ChatButtonProps {
  farmerId: string;
  farmerName: string;
  variant?: 'default' | 'outline' | 'ghost';
  size?: 'default' | 'sm' | 'lg';
  className?: string;
}

export const ChatButton = ({ farmerId, farmerName, variant = 'outline', size = 'sm', className }: ChatButtonProps) => {
  const { user } = useAuth();
  const { startConversation } = useChat();
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [conversationId, setConversationId] = useState<string | null>(null);

  // Don't render the button if user is not authenticated
  if (!user) {
    return null;
  }

  const handleStartChat = async (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent card click when clicking chat button
    if (!user) {
      toast({
        title: "Login Required",
        description: "Please log in to start a conversation with the farmer.",
        variant: "destructive",
      });
      return;
    }

    if (user.id === farmerId) {
      // Don't show error, just don't render the button
      return;
    }

    try {
      console.log('Starting conversation between:', user.id, 'and', farmerId);
      const conversation = await startConversation(user.id, farmerId, `Inquiry about your products`);
      console.log('Conversation result:', conversation);
      if (conversation) {
        setConversationId(conversation.id);
        setIsOpen(true);
      } else {
        toast({
          title: "Error",
          description: "Could not create conversation. Please try again.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Error starting chat:', error);
      toast({
        title: "Error",
        description: "Failed to start conversation. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Don't render if user is viewing their own products
  if (user?.id === farmerId) {
    return null;
  }

  return (
    <>
      <Button
        variant={variant}
        size={size}
        onClick={handleStartChat}
        className={className}
      >
        <MessageCircle className="w-4 h-4 mr-2" />
        Message Farmer
      </Button>

      <ChatDialog
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        conversationId={conversationId}
        recipientName={farmerName}
      />
    </>
  );
};