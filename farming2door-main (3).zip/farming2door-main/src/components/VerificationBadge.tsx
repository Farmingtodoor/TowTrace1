import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { ShieldCheck, Award, CheckCircle2, Star } from "lucide-react";

interface VerificationBadgeProps {
  type: 'verified' | 'certified' | 'featured' | 'top-rated';
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
  yearsInBusiness?: number;
}

const badgeConfig = {
  verified: {
    icon: ShieldCheck,
    label: 'Verified Farmer',
    description: 'Identity and farm credentials verified by Farm2Door',
    className: 'bg-gradient-to-r from-blue-500 to-blue-600 text-white border-0',
  },
  certified: {
    icon: Award,
    label: 'Certified',
    description: 'Holds valid agricultural certifications',
    className: 'bg-gradient-to-r from-green-600 to-emerald-600 text-white border-0',
  },
  featured: {
    icon: Star,
    label: 'Featured',
    description: 'Featured farmer with exceptional products',
    className: 'bg-gradient-to-r from-amber-500 to-orange-500 text-white border-0',
  },
  'top-rated': {
    icon: CheckCircle2,
    label: 'Top Rated',
    description: 'Consistently excellent customer reviews',
    className: 'bg-gradient-to-r from-purple-500 to-purple-600 text-white border-0',
  },
};

const sizeConfig = {
  sm: {
    badge: 'text-xs px-2 py-0.5',
    icon: 'h-3 w-3',
  },
  md: {
    badge: 'text-sm px-3 py-1',
    icon: 'h-4 w-4',
  },
  lg: {
    badge: 'text-base px-4 py-1.5',
    icon: 'h-5 w-5',
  },
};

export function VerificationBadge({ 
  type, 
  size = 'md', 
  showLabel = true,
  yearsInBusiness 
}: VerificationBadgeProps) {
  const config = badgeConfig[type];
  const sizeClasses = sizeConfig[size];
  const Icon = config.icon;

  const description = yearsInBusiness 
    ? `${config.description} • ${yearsInBusiness} years in business`
    : config.description;

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge className={`${config.className} ${sizeClasses.badge} flex items-center gap-1 shadow-md hover:shadow-lg transition-shadow cursor-help`}>
            <Icon className={sizeClasses.icon} />
            {showLabel && <span>{config.label}</span>}
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          <p className="max-w-xs">{description}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
