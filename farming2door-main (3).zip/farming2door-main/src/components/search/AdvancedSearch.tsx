import { useState, useEffect } from 'react';
import { Search, Filter, MapPin, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { supabase } from '@/integrations/supabase/client';

interface SearchFilters {
  searchTerm: string;
  category: string;
  subcategory: string;
  priceRange: [number, number];
  organicOnly: boolean;
  ratingRange: [number, number];
  inStockOnly: boolean;
  farmerId: string;
  sortBy: string;
  sortOrder: string;
}

interface AdvancedSearchProps {
  onSearch: (filters: SearchFilters) => void;
  onReset: () => void;
  loading?: boolean;
}

const AdvancedSearch = ({ onSearch, onReset, loading = false }: AdvancedSearchProps) => {
  const [filters, setFilters] = useState<SearchFilters>({
    searchTerm: '',
    category: '',
    subcategory: '',
    priceRange: [0, 100],
    organicOnly: false,
    ratingRange: [0, 5],
    inStockOnly: false,
    farmerId: '',
    sortBy: 'created_at',
    sortOrder: 'desc'
  });

  const [categories, setCategories] = useState<any[]>([]);
  const [farmers, setFarmers] = useState<any[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  const [activeFilters, setActiveFilters] = useState<string[]>([]);

  useEffect(() => {
    loadFilterOptions();
  }, []);

  useEffect(() => {
    updateActiveFilters();
  }, [filters]);

  const loadFilterOptions = async () => {
    try {
      // Load categories
      const { data: categoriesData } = await supabase
        .from('categories')
        .select('id, name')
        .eq('is_active', true)
        .order('display_order');

      // Load farmers
      const { data: farmersData } = await supabase
        .rpc('get_approved_farmers_public');

      setCategories(categoriesData || []);
      setFarmers(farmersData || []);
    } catch (error) {
      console.error('Error loading filter options:', error);
    }
  };

  const updateActiveFilters = () => {
    const active: string[] = [];
    
    if (filters.searchTerm) active.push(`Search: "${filters.searchTerm}"`);
    if (filters.category) active.push(`Category: ${filters.category}`);
    if (filters.subcategory) active.push(`Subcategory: ${filters.subcategory}`);
    if (filters.priceRange[0] > 0 || filters.priceRange[1] < 100) {
      active.push(`Price: $${filters.priceRange[0]} - $${filters.priceRange[1]}`);
    }
    if (filters.organicOnly) active.push('Organic Only');
    if (filters.ratingRange[0] > 0) active.push(`Rating: ${filters.ratingRange[0]}+ stars`);
    if (filters.inStockOnly) active.push('In Stock Only');
    if (filters.farmerId) {
      const farmer = farmers.find(f => f.user_id === filters.farmerId);
      if (farmer) active.push(`Farmer: ${farmer.display_name}`);
    }

    setActiveFilters(active);
  };

  const handleFilterChange = (key: keyof SearchFilters, value: any) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleSearch = () => {
    onSearch(filters);
  };

  const handleReset = () => {
    const resetFilters: SearchFilters = {
      searchTerm: '',
      category: '',
      subcategory: '',
      priceRange: [0, 100],
      organicOnly: false,
      ratingRange: [0, 5],
      inStockOnly: false,
      farmerId: '',
      sortBy: 'created_at',
      sortOrder: 'desc'
    };
    setFilters(resetFilters);
    onReset();
  };

  const removeFilter = (filterText: string) => {
    if (filterText.startsWith('Search:')) {
      handleFilterChange('searchTerm', '');
    } else if (filterText.startsWith('Category:')) {
      handleFilterChange('category', '');
    } else if (filterText.startsWith('Subcategory:')) {
      handleFilterChange('subcategory', '');
    } else if (filterText.startsWith('Price:')) {
      handleFilterChange('priceRange', [0, 100]);
    } else if (filterText === 'Organic Only') {
      handleFilterChange('organicOnly', false);
    } else if (filterText.startsWith('Rating:')) {
      handleFilterChange('ratingRange', [0, 5]);
    } else if (filterText === 'In Stock Only') {
      handleFilterChange('inStockOnly', false);
    } else if (filterText.startsWith('Farmer:')) {
      handleFilterChange('farmerId', '');
    }
  };

  return (
    <div className="space-y-4">
      {/* Main Search Bar */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            placeholder="Search products, farmers, or categories..."
            value={filters.searchTerm}
            onChange={(e) => handleFilterChange('searchTerm', e.target.value)}
            className="pl-10"
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
          />
        </div>
        <Button onClick={() => setShowFilters(!showFilters)} variant="outline">
          <Filter className="h-4 w-4 mr-2" />
          Filters
        </Button>
        <Button onClick={handleSearch} disabled={loading}>
          {loading ? 'Searching...' : 'Search'}
        </Button>
      </div>

      {/* Active Filters */}
      {activeFilters.length > 0 && (
        <div className="flex flex-wrap gap-2 items-center">
          <span className="text-sm text-muted-foreground">Active filters:</span>
          {activeFilters.map((filter, index) => (
            <Badge key={index} variant="secondary" className="cursor-pointer" onClick={() => removeFilter(filter)}>
              {filter}
              <span className="ml-1 text-xs">×</span>
            </Badge>
          ))}
          <Button variant="ghost" size="sm" onClick={handleReset}>
            Clear all
          </Button>
        </div>
      )}

      {/* Advanced Filters */}
      {showFilters && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Advanced Filters</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Category Filter */}
              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select value={filters.category} onValueChange={(value) => handleFilterChange('category', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="All categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All categories</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.name}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Farmer Filter */}
              <div className="space-y-2">
                <Label htmlFor="farmer">Farmer</Label>
                <Select value={filters.farmerId} onValueChange={(value) => handleFilterChange('farmerId', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="All farmers" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All farmers</SelectItem>
                    {farmers.map((farmer) => (
                      <SelectItem key={farmer.user_id} value={farmer.user_id}>
                        {farmer.display_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Sort Options */}
              <div className="space-y-2">
                <Label htmlFor="sort">Sort By</Label>
                <div className="flex gap-2">
                  <Select value={filters.sortBy} onValueChange={(value) => handleFilterChange('sortBy', value)}>
                    <SelectTrigger className="flex-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="created_at">Date Added</SelectItem>
                      <SelectItem value="price">Price</SelectItem>
                      <SelectItem value="rating">Rating</SelectItem>
                      <SelectItem value="name">Name</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={filters.sortOrder} onValueChange={(value) => handleFilterChange('sortOrder', value)}>
                    <SelectTrigger className="w-24">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="desc">Desc</SelectItem>
                      <SelectItem value="asc">Asc</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <Separator />

            {/* Price Range */}
            <div className="space-y-2">
              <Label>Price Range: ${filters.priceRange[0]} - ${filters.priceRange[1]}</Label>
              <Slider
                min={0}
                max={200}
                step={5}
                value={filters.priceRange}
                onValueChange={(value) => handleFilterChange('priceRange', value)}
                className="w-full"
              />
            </div>

            {/* Rating Range */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Star className="h-4 w-4" />
                Minimum Rating: {filters.ratingRange[0]} stars
              </Label>
              <Slider
                min={0}
                max={5}
                step={0.5}
                value={filters.ratingRange}
                onValueChange={(value) => handleFilterChange('ratingRange', value)}
                className="w-full"
              />
            </div>

            <Separator />

            {/* Checkboxes */}
            <div className="flex flex-wrap gap-6">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="organic"
                  checked={filters.organicOnly}
                  onCheckedChange={(checked) => handleFilterChange('organicOnly', checked)}
                />
                <Label htmlFor="organic">Organic Only</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="inStock"
                  checked={filters.inStockOnly}
                  onCheckedChange={(checked) => handleFilterChange('inStockOnly', checked)}
                />
                <Label htmlFor="inStock">In Stock Only</Label>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2 pt-4">
              <Button onClick={handleSearch} disabled={loading} className="flex-1">
                {loading ? 'Searching...' : 'Apply Filters'}
              </Button>
              <Button variant="outline" onClick={handleReset}>
                Reset
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default AdvancedSearch;