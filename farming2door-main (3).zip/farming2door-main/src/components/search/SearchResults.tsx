import { useState, useEffect } from 'react';
import { Grid, List, SortAsc, SortDesc, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import ProductCard from '@/components/ProductCard';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface Product {
  id: string;
  name: string;
  farmer: string;
  price: number;
  category: string;
  subcategory?: string;
  is_organic: boolean;
  description?: string;
  created_at: string;
  updated_at: string;
  farmer_id?: string;
  image_url?: string;
  unit?: string;
  stock_quantity?: number;
  is_available: boolean;
  harvest_date?: string;
  expiration_date?: string;
  portion_options?: any;
  processing_addons?: any;
  certifications?: any;
  animal_portion_type?: string;
  next_delivery_date?: string;
  farm_distance?: number;
  average_rating?: number;
  review_count?: number;
  images?: any;
  videos?: any;
  freshness_type?: string;
}

interface SearchFilters {
  searchTerm: string;
  category: string;
  subcategory: string;
  priceRange: [number, number];
  organicOnly: boolean;
  ratingRange: [number, number];
  inStockOnly: boolean;
  farmerId: string;
  sortBy: string;
  sortOrder: string;
}

interface SearchResultsProps {
  filters: SearchFilters;
  triggerSearch: boolean;
  onSearchComplete: () => void;
}

const SearchResults = ({ filters, triggerSearch, onSearchComplete }: SearchResultsProps) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [profiles, setProfiles] = useState<any[]>([]);
  const [farmerApplications, setFarmerApplications] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [totalResults, setTotalResults] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [hasMore, setHasMore] = useState(false);
  const { toast } = useToast();

  const ITEMS_PER_PAGE = 20;

  // Fetch profiles and farmer applications on component mount
  useEffect(() => {
    const fetchFarmerData = async () => {
      try {
        // Fetch approved farmers (public-safe)
        const { data: farmersData, error: farmersError } = await supabase
          .rpc('get_approved_farmers_public');

        if (farmersError) throw farmersError;
        setFarmerApplications(farmersData || []);

        // Fetch public location fields only (no PII) for those farmers
        const farmerIds = (farmersData || [])
          .map((f: any) => f.user_id)
          .filter(Boolean);

        if (farmerIds.length > 0) {
          const { data: locations, error: locationsError } = await supabase
            .rpc('get_farmer_public_locations', { _user_ids: farmerIds });

          if (locationsError) throw locationsError;
          setProfiles(locations || []);
        } else {
          setProfiles([]);
        }
      } catch (error) {
        console.error('Error fetching farmer data:', error);
      }
    };

    fetchFarmerData();
  }, []);

  const getFarmerLocation = (farmerId: string) => {
    // First try to get location from profile
    const profile = profiles.find(p => p.id === farmerId);
    if (profile?.city && profile?.state) {
      return `${profile.city}, ${profile.state}`;
    } else if (profile?.city) {
      return profile.city;
    } else if (profile?.state) {
      return profile.state;
    }
    
    // Try to extract city and state from farmer application data
    const farmerApp = farmerApplications.find(app => app.user_id === farmerId);
    if (farmerApp) {
      // First check if general_location has useful info (not generic)
      if (farmerApp.general_location && farmerApp.general_location !== 'General Area' && farmerApp.general_location !== 'Local Area') {
        return farmerApp.general_location;
      }
      
      // Try to extract location from farm description
      if (farmerApp.farm_description) {
        // Look for state code patterns like TX-123456
        const stateCodeMatch = farmerApp.farm_description.match(/([A-Z]{2})-\d+/);
        if (stateCodeMatch) {
          return stateCodeMatch[1];
        }
        
        // Look for "City, State" patterns
        const cityStateMatch = farmerApp.farm_description.match(/([A-Za-z\s]+),\s*([A-Z]{2})/);
        if (cityStateMatch) {
          const city = cityStateMatch[1].trim();
          const state = cityStateMatch[2].trim();
          return `${city}, ${state}`;
        }
        
        // Look for standalone state abbreviations
        const stateMatch = farmerApp.farm_description.match(/\b([A-Z]{2})\b/);
        if (stateMatch) {
          return stateMatch[1];
        }
      }
    }
    
    return 'Location not specified';
  };

  useEffect(() => {
    if (triggerSearch) {
      performSearch();
      onSearchComplete();
    }
  }, [triggerSearch]);

  const performSearch = async (page = 1, append = false) => {
    setLoading(true);

    try {
      // Track search analytics
      await supabase.rpc('track_analytics_event', {
        p_event_type: 'product_search',
        p_event_data: {
          search_term: filters.searchTerm,
          category: filters.category,
          filters_applied: {
            organic_only: filters.organicOnly,
            in_stock_only: filters.inStockOnly,
            price_range: filters.priceRange,
            rating_range: filters.ratingRange
          }
        }
      });

      // Perform advanced search
      const { data, error } = await supabase.rpc('search_products_advanced', {
        p_search_term: filters.searchTerm,
        p_category: filters.category,
        p_subcategory: filters.subcategory,
        p_min_price: filters.priceRange[0],
        p_max_price: filters.priceRange[1],
        p_organic_only: filters.organicOnly,
        p_min_rating: filters.ratingRange[0],
        p_in_stock_only: filters.inStockOnly,
        p_farmer_id: filters.farmerId || null,
        p_sort_by: filters.sortBy,
        p_sort_order: filters.sortOrder,
        p_limit: ITEMS_PER_PAGE,
        p_offset: (page - 1) * ITEMS_PER_PAGE
      });

      if (error) {
        console.error('Search error:', error);
        throw error;
      }

      const searchResults = data || [];
      
      if (append) {
        setProducts(prev => [...prev, ...searchResults]);
      } else {
        setProducts(searchResults);
        setCurrentPage(1);
      }

      setTotalResults(searchResults.length);
      setHasMore(searchResults.length === ITEMS_PER_PAGE);

      if (searchResults.length === 0 && !append) {
        toast({
          title: "No results found",
          description: "Try adjusting your search criteria or filters.",
        });
      }

    } catch (error) {
      console.error('Error performing search:', error);
      toast({
        title: "Search failed",
        description: "There was an error performing your search. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const loadMore = () => {
    const nextPage = currentPage + 1;
    setCurrentPage(nextPage);
    performSearch(nextPage, true);
  };

  const getResultsText = () => {
    if (loading && products.length === 0) return "Searching...";
    if (products.length === 0) return "No products found";
    if (hasMore) return `Showing ${products.length}+ results`;
    return `Found ${products.length} product${products.length === 1 ? '' : 's'}`;
  };

  const ListViewProduct = ({ product }: { product: Product }) => (
    <Card className="mb-4">
      <CardContent className="p-4">
        <div className="flex gap-4">
          <div className="w-24 h-24 bg-muted rounded-lg flex-shrink-0">
            {product.image_url && (
              <img 
                src={product.image_url} 
                alt={product.name}
                className="w-full h-full object-cover rounded-lg"
              />
            )}
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex justify-between items-start mb-2">
              <h3 className="font-semibold text-lg truncate">{product.name}</h3>
              <div className="text-right flex-shrink-0 ml-4">
                <div className="text-xl font-bold text-primary">${product.price}</div>
                <div className="text-sm text-muted-foreground">per {product.unit || 'item'}</div>
              </div>
            </div>
            
            <div className="flex flex-wrap gap-2 mb-2">
              <Badge variant="outline">{product.category}</Badge>
              {product.is_organic && <Badge variant="secondary">Organic</Badge>}
              {product.stock_quantity && product.stock_quantity > 0 && (
                <Badge variant="default">In Stock ({product.stock_quantity})</Badge>
              )}
            </div>
            
            <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
              {product.description || 'No description available'}
            </p>
            
            <div className="flex justify-between items-center">
              <div className="text-sm">
                <span className="text-muted-foreground">by </span>
                <span className="font-medium">{product.farmer}</span>
              </div>
              
              {product.average_rating && product.average_rating > 0 && (
                <div className="flex items-center gap-1">
                  <span className="text-sm">★</span>
                  <span className="text-sm">{product.average_rating.toFixed(1)}</span>
                  <span className="text-xs text-muted-foreground">({product.review_count || 0})</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-4">
      {/* Results Header */}
      <div className="flex justify-between items-center">
        <div className="text-lg font-medium">
          {getResultsText()}
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            variant={viewMode === 'grid' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('grid')}
          >
            <Grid className="h-4 w-4" />
          </Button>
          <Button
            variant={viewMode === 'list' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('list')}
          >
            <List className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Loading State */}
      {loading && products.length === 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {[...Array(8)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-4">
                <div className="space-y-3">
                  <div className="h-48 bg-muted rounded"></div>
                  <div className="h-4 bg-muted rounded w-3/4"></div>
                  <div className="h-4 bg-muted rounded w-1/2"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Results */}
      {!loading || products.length > 0 ? (
        <>
          {viewMode === 'grid' ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {products.map((product) => (
                <ProductCard
                  key={product.id}
                  id={product.id}
                  name={product.name}
                  farmer={product.farmer}
                  location={getFarmerLocation(product.farmer_id || '')}
                  price={`$${product.price}`}
                  rating={product.average_rating || 0}
                  reviewCount={product.review_count || 0}
                  image={product.image_url || ''}
                  images={product.images ? (Array.isArray(product.images) ? product.images : []) : []}
                  videos={product.videos ? (Array.isArray(product.videos) ? product.videos : []) : []}
                  category={product.category}
                  isOrganic={product.is_organic}
                  inStock={product.is_available && (product.stock_quantity || 0) > 0}
                  distance={product.farm_distance}
                  unit={product.unit}
                  certifications={product.certifications ? (Array.isArray(product.certifications) ? product.certifications : []) : []}
                  deliveryAvailable={true}
                  farmerId={product.farmer_id}
                />
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {products.map((product) => (
                <ListViewProduct key={product.id} product={product} />
              ))}
            </div>
          )}

          {/* Load More */}
          {hasMore && (
            <div className="text-center pt-6">
              <Button 
                onClick={loadMore} 
                disabled={loading}
                variant="outline"
              >
                {loading ? 'Loading...' : 'Load More Products'}
              </Button>
            </div>
          )}
        </>
      ) : null}

      {/* Empty State */}
      {!loading && products.length === 0 && (
        <div className="text-center py-12">
          <div className="text-muted-foreground mb-4">
            <Search className="h-12 w-12 mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">No products found</h3>
            <p>Try adjusting your search terms or filters to find what you're looking for.</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchResults;