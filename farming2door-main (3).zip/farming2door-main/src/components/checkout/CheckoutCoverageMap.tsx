import { useEffect, useRef } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';

const MAPBOX_TOKEN =
  'pk.eyJ1IjoiZmFybWluMmRvb3IiLCJhIjoiY21mZWNvdXVyMDVjczJpb2dueDcwaGhudSJ9.oeIZtg-WQnD382BjP8Swqw';

interface Point {
  lat: number;
  lng: number;
}

interface Props {
  origin: Point;
  customer: Point;
  radiusMiles: number;
  /** Colors the zone/pin to match the eligibility state */
  status: 'inside' | 'edge' | 'outside';
  height?: string;
}

/** GeoJSON polygon approximating a circle of `radiusMiles` around a point. */
function circlePolygon(lat: number, lng: number, radiusMiles: number, steps = 96) {
  const coords: [number, number][] = [];
  const dx = radiusMiles / (69.172 * Math.cos((lat * Math.PI) / 180));
  const dy = radiusMiles / 69.172;
  for (let i = 0; i < steps; i++) {
    const t = (i / steps) * (2 * Math.PI);
    coords.push([lng + dx * Math.cos(t), lat + dy * Math.sin(t)]);
  }
  coords.push(coords[0]);
  return {
    type: 'Feature' as const,
    properties: {},
    geometry: { type: 'Polygon' as const, coordinates: [coords] },
  };
}

const ZONE_COLORS = {
  inside: '#16a34a',
  edge: '#d97706',
  outside: '#dc2626',
} as const;

export const CheckoutCoverageMap = ({
  origin,
  customer,
  radiusMiles,
  status,
  height = '190px',
}: Props) => {
  const container = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const customerMarker = useRef<mapboxgl.Marker | null>(null);

  // Init once
  useEffect(() => {
    if (!container.current || map.current) return;
    mapboxgl.accessToken = MAPBOX_TOKEN;
    const instance = new mapboxgl.Map({
      container: container.current,
      style: 'mapbox://styles/mapbox/streets-v12',
      center: [origin.lng, origin.lat],
      zoom: 8,
      attributionControl: false,
      interactive: true,
      dragRotate: false,
});
    instance.scrollZoom.disable();
    map.current = instance;

    instance.on('load', () => {
      instance.addSource('zone', {
        type: 'geojson',
        data: circlePolygon(origin.lat, origin.lng, radiusMiles),
      });
      instance.addLayer({
        id: 'zone-fill',
        type: 'fill',
        source: 'zone',
        paint: { 'fill-color': ZONE_COLORS[status], 'fill-opacity': 0.12 },
      });
      instance.addLayer({
        id: 'zone-line',
        type: 'line',
        source: 'zone',
        paint: { 'line-color': ZONE_COLORS[status], 'line-width': 2, 'line-dasharray': [2, 1.5] },
      });

      // Farm marker
      const farmEl = document.createElement('div');
      farmEl.style.cssText =
        'width:22px;height:22px;border-radius:50%;background:#166534;border:3px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.35)';
      new mapboxgl.Marker({ element: farmEl })
        .setLngLat([origin.lng, origin.lat])
        .setPopup(new mapboxgl.Popup({ offset: 14 }).setText('Farm'))
        .addTo(instance);
    });

    return () => {
      instance.remove();
      map.current = null;
      customerMarker.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [origin.lat, origin.lng]);

  // Update zone radius/color
  useEffect(() => {
    const instance = map.current;
    if (!instance) return;
    const apply = () => {
      const src = instance.getSource('zone') as mapboxgl.GeoJSONSource | undefined;
      if (src) src.setData(circlePolygon(origin.lat, origin.lng, radiusMiles) as never);
      if (instance.getLayer('zone-fill')) {
        instance.setPaintProperty('zone-fill', 'fill-color', ZONE_COLORS[status]);
        instance.setPaintProperty('zone-line', 'line-color', ZONE_COLORS[status]);
      }
    };
    instance.isStyleLoaded() ? apply() : instance.once('load', apply);
  }, [radiusMiles, status, origin.lat, origin.lng]);

  // Customer pin + fit bounds
  useEffect(() => {
    const instance = map.current;
    if (!instance) return;

    if (!customerMarker.current) {
      const el = document.createElement('div');
      el.style.cssText =
        'width:16px;height:16px;border-radius:50%;background:#1d4ed8;border:3px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.35)';
      customerMarker.current = new mapboxgl.Marker({ element: el })
        .setLngLat([customer.lng, customer.lat])
        .setPopup(new mapboxgl.Popup({ offset: 12 }).setText('Your location'))
        .addTo(instance);
    } else {
      customerMarker.current.setLngLat([customer.lng, customer.lat]);
    }

    const bounds = new mapboxgl.LngLatBounds()
      .extend([origin.lng, origin.lat])
      .extend([customer.lng, customer.lat]);
    instance.fitBounds(bounds, { padding: 50, maxZoom: 11, duration: 500 });
  }, [customer.lat, customer.lng, origin.lat, origin.lng]);

  return (
    <div className="rounded-lg overflow-hidden border">
      <div ref={container} style={{ height }} className="w-full" />
      <div className="flex flex-wrap items-center gap-3 px-3 py-2 text-[11px] text-muted-foreground bg-muted/40">
        <span className="flex items-center gap-1.5">
          <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ background: '#166534' }} />
          Farm
        </span>
        <span className="flex items-center gap-1.5">
          <span className="inline-block h-2.5 w-2.5 rounded-full" style={{ background: '#1d4ed8' }} />
          Your ZIP area
        </span>
        <span className="flex items-center gap-1.5">
          <span
            className="inline-block h-2.5 w-2.5 rounded-sm border"
            style={{ borderColor: ZONE_COLORS[status], background: `${ZONE_COLORS[status]}22` }}
          />
          {radiusMiles} mi delivery zone
        </span>
      </div>
    </div>
  );
};
