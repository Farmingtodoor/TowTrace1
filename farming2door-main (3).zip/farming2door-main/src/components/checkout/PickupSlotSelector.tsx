import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, CalendarDays, AlertCircle, Loader2 } from "lucide-react";

export interface PickupSlotOption {
  slot_id: string;
  pickup_date: string;
  start_time: string;
  end_time: string;
  capacity: number;
  booked: number;
  remaining: number;
  location_note: string | null;
}

export interface SelectedPickupSlot {
  slotId: string;
  date: string;
  startTime: string;
  endTime: string;
  label: string;
}

interface Props {
  farmerId: string | null;
  selected: SelectedPickupSlot | null;
  onSelect: (slot: SelectedPickupSlot | null) => void;
  onAvailabilityChange?: (count: number) => void;
}

export const formatSlotTime = (t: string) => {
  const [h, m] = t.split(":").map(Number);
  const period = h >= 12 ? "PM" : "AM";
  const hour = h % 12 === 0 ? 12 : h % 12;
  return `${hour}:${String(m).padStart(2, "0")} ${period}`;
};

const formatDayLabel = (dateStr: string) => {
  const d = new Date(`${dateStr}T00:00:00`);
  return d.toLocaleDateString(undefined, {
    weekday: "short",
    month: "short",
    day: "numeric",
  });
};

export const PickupSlotSelector = ({
  farmerId,
  selected,
  onSelect,
  onAvailabilityChange,
}: Props) => {
  const [slots, setSlots] = useState<PickupSlotOption[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      if (!farmerId) {
        setSlots([]);
        return;
      }
      setLoading(true);
      const { data, error } = await supabase.rpc("get_available_pickup_slots", {
        _farmer_id: farmerId,
        _days: 14,
      });
      if (cancelled) return;
      if (error) {
        console.error("Error loading pickup slots:", error);
        setSlots([]);
      } else {
        setSlots((data ?? []) as PickupSlotOption[]);
      }
      setLoading(false);
    };

    load();
    return () => {
      cancelled = true;
    };
  }, [farmerId]);

  useEffect(() => {
    onAvailabilityChange?.(slots.length);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [slots]);

  // Clear a selection that is no longer offered
  useEffect(() => {
    if (
      selected &&
      slots.length > 0 &&
      !slots.some(
        (s) =>
          s.slot_id === selected.slotId &&
          s.pickup_date === selected.date &&
          s.remaining > 0
      )
    ) {
      onSelect(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [slots]);

  if (!farmerId) return null;

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-sm text-muted-foreground pl-6">
        <Loader2 className="h-4 w-4 animate-spin" />
        Loading pickup times…
      </div>
    );
  }

  if (slots.length === 0) {
    return (
      <div className="flex items-start gap-2 text-sm p-3 pl-3 ml-6 bg-muted/50 border rounded-lg text-muted-foreground">
        <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
        <span>
          This farm hasn't published pickup times yet. You can still place the
          order and arrange pickup by message.
        </span>
      </div>
    );
  }

  const byDate = slots.reduce<Record<string, PickupSlotOption[]>>((acc, s) => {
    (acc[s.pickup_date] ||= []).push(s);
    return acc;
  }, {});

  return (
    <div className="space-y-3 pl-6 border-l-2 border-muted">
      <Label className="flex items-center gap-2">
        <CalendarDays className="h-4 w-4" />
        Choose a pickup time
      </Label>

      <div className="max-h-64 overflow-y-auto space-y-4 pr-1">
        {Object.entries(byDate).map(([date, dateSlots]) => (
          <div key={date} className="space-y-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
              {formatDayLabel(date)}
            </p>
            <div className="flex flex-wrap gap-2">
              {dateSlots.map((slot) => {
                const isSelected =
                  selected?.slotId === slot.slot_id && selected?.date === date;
                const full = slot.remaining <= 0;
                const label = `${formatDayLabel(date)}, ${formatSlotTime(
                  slot.start_time
                )} – ${formatSlotTime(slot.end_time)}`;

                return (
                  <Button
                    key={`${slot.slot_id}-${date}`}
                    type="button"
                    size="sm"
                    variant={isSelected ? "default" : "outline"}
                    disabled={full}
                    onClick={() =>
                      onSelect(
                        isSelected
                          ? null
                          : {
                              slotId: slot.slot_id,
                              date,
                              startTime: slot.start_time,
                              endTime: slot.end_time,
                              label,
                            }
                      )
                    }
                    className="h-auto py-2 flex-col items-start gap-0.5"
                  >
                    <span className="flex items-center gap-1 text-xs font-medium">
                      <Clock className="h-3 w-3" />
                      {formatSlotTime(slot.start_time)} –{" "}
                      {formatSlotTime(slot.end_time)}
                    </span>
                    <span className="text-[10px] opacity-80">
                      {full ? "Full" : `${slot.remaining} spot${slot.remaining === 1 ? "" : "s"} left`}
                    </span>
                  </Button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {selected && (
        <div className="flex items-center gap-2 text-sm">
          <Badge variant="secondary">Selected</Badge>
          <span className="text-muted-foreground">{selected.label}</span>
        </div>
      )}
    </div>
  );
};

export default PickupSlotSelector;
