import { CheckCircle2, AlertCircle, AlertTriangle, MapPin, Loader2, Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  formatRange,
  formatDurationRange,
  type EligibilityResult,
} from "@/services/zipCoverageService";

interface Props {
  loading?: boolean;
  result: EligibilityResult | null;
  className?: string;
  /** Whether the farm offers pickup as a fallback when delivery isn't possible */
  offersPickup?: boolean;
  /** Optional label for the nearest pickup location (e.g. the farm name) */
  pickupLabel?: string;
  onSwitchToPickup?: () => void;
}


const STYLES = {
  inside: "bg-primary/10 border-primary/30 text-primary",
  edge: "bg-amber-500/10 border-amber-500/30 text-amber-700 dark:text-amber-400",
  outside: "bg-destructive/10 border-destructive/30 text-destructive",
  unknown: "bg-muted/40 border-border text-muted-foreground",
} as const;

const ICONS = {
  inside: CheckCircle2,
  edge: AlertTriangle,
  outside: AlertCircle,
  unknown: MapPin,
} as const;

const TITLES = {
  inside: "Inside the delivery zone",
  edge: "Near the edge of the zone",
  outside: "Outside the delivery zone",
  unknown: "Delivery availability",
} as const;

export const DeliveryEligibilityBadge = ({
  loading,
  result,
  className,
  offersPickup,
  pickupLabel,
  onSwitchToPickup,
}: Props) => {
  if (loading) {
    return (
      <div className={cn("flex items-center gap-2 text-sm p-3 rounded-lg border bg-muted/40 text-muted-foreground", className)}>
        <Loader2 className="h-4 w-4 animate-spin" />
        Checking delivery eligibility for this ZIP…
      </div>
    );
  }

  if (!result) return null;

  const Icon = ICONS[result.status];
  const overBy =
    result.status === 'outside' && result.range
      ? Math.max(0, Math.round((result.range.minMiles - result.radiusMiles) * 10) / 10)
      : null;

  return (
    <div className={cn("rounded-lg border p-3 space-y-2", STYLES[result.status], className)}>
      <div className="flex items-start gap-2">
        <Icon className="h-4 w-4 mt-0.5 shrink-0" />
        <div className="min-w-0">
          <p className="text-sm font-semibold">{TITLES[result.status]}</p>
          <p className="text-xs mt-0.5 opacity-90">{result.message}</p>
        </div>
      </div>

      {result.range && (
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs pl-6 opacity-90">
          <span className="flex items-center gap-1">
            <MapPin className="h-3 w-3" />
            Est. distance {formatRange(result.range)}
          </span>
          <span className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            Est. drive {formatDurationRange(result.range)}
          </span>
          <span>Zone limit {result.radiusMiles} mi</span>
        </div>
      )}

      {result.status === 'outside' && (
        <div className="pl-6 text-xs space-y-1">
          <p className="opacity-90">
            Why: this farm delivers up to <strong>{result.radiusMiles} mi</strong>
            {result.range ? (
              <>
                {" "}and your ZIP is about <strong>{formatRange(result.range)}</strong> away
                {overBy && overBy > 0 ? <> — roughly {overBy} mi past the limit</> : null}.
              </>
            ) : (
              <> and we couldn't place your ZIP inside it.</>
            )}
          </p>
          {offersPickup ? (
            <p className="opacity-90">
              Nearest eligible option: farm pickup{pickupLabel ? ` at ${pickupLabel}` : ""} — choose a
              scheduled time window at no delivery cost.
              {onSwitchToPickup && (
                <button
                  type="button"
                  onClick={onSwitchToPickup}
                  className="ml-1 underline underline-offset-2 font-medium"
                >
                  Switch to pickup
                </button>
              )}
            </p>
          ) : (
            <p className="opacity-90">
              This farm has no pickup option either, so joining the waitlist is the next step.
            </p>
          )}
        </div>
      )}

      {result.resolved?.approximate && (
        <p className="text-[11px] pl-6 opacity-75">
          Exact ZIP not found — estimated from the nearest known ZIP area.
        </p>
      )}
    </div>
  );

};
