import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { BellRing, CheckCircle, Loader2 } from "lucide-react";

interface DeliveryWaitlistFormProps {
  farmerId: string | null;
  zip: string | null;
  distanceMiles?: number;
  defaultEmail?: string;
  userId?: string | null;
}

export const DeliveryWaitlistForm = ({
  farmerId,
  zip,
  distanceMiles,
  defaultEmail,
  userId,
}: DeliveryWaitlistFormProps) => {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState(defaultEmail ?? "");
  const [notes, setNotes] = useState("");
  const [notifyDelivery, setNotifyDelivery] = useState(true);
  const [notifyPickup, setNotifyPickup] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async () => {
    if (!farmerId || !zip) {
      toast({
        title: "Missing details",
        description: "We need a valid ZIP code before we can add you to the waitlist.",
        variant: "destructive",
      });
      return;
    }
    if (!notifyDelivery && !notifyPickup) {
      toast({
        title: "Pick at least one alert",
        description: "Choose delivery coverage, pickup times, or both.",
        variant: "destructive",
      });
      return;
    }
    if (!email.trim()) {
      toast({ title: "Email required", description: "Add an email so the farm can reach you.", variant: "destructive" });
      return;
    }

    setSubmitting(true);
    const { data: inserted, error } = await supabase.from("delivery_waitlist").insert({
      farmer_id: farmerId,
      user_id: userId ?? null,
      email: email.trim(),
      zip_code: zip,
      distance_miles: distanceMiles ?? null,
      notes: notes.trim() || null,
      notify_delivery: notifyDelivery,
      notify_pickup: notifyPickup,
    }).select("id").single();
    setSubmitting(false);

    if (error) {
      console.error("Waitlist request failed:", error);
      toast({ title: "Could not join the waitlist", description: error.message, variant: "destructive" });
      return;
    }

    if (inserted?.id) {
      supabase.functions
        .invoke("send-waitlist-confirmation", { body: { waitlistId: inserted.id } })
        .catch((e) => console.error("Waitlist confirmation email failed:", e));
    }

    setSubmitted(true);
    toast({
      title: "You're on the waitlist",
      description: `We'll email you when ${notifyDelivery && notifyPickup ? "delivery reaches your ZIP or pickup times open" : notifyDelivery ? `delivery reaches ${zip}` : "pickup times open up"}.`,
    });
  };

  if (submitted) {
    return (
      <div className="flex items-start gap-2 text-sm text-foreground">
        <CheckCircle className="h-4 w-4 mt-0.5 shrink-0 text-primary" />
        <span>
          You're on the alert list for ZIP {zip}. We'll email you when
          {notifyDelivery ? " delivery coverage reaches you" : ""}
          {notifyDelivery && notifyPickup ? " or" : ""}
          {notifyPickup ? " pickup time slots become available" : ""}.
        </span>
      </div>
    );
  }

  if (!open) {
    return (
      <Button type="button" size="sm" variant="secondary" onClick={() => setOpen(true)}>
        <BellRing className="h-4 w-4 mr-1.5" />
        Notify me about delivery or pickup availability
      </Button>
    );
  }

  return (
    <div className="space-y-3 pt-1">
      <div className="space-y-1.5">
        <Label htmlFor="waitlist-email" className="text-xs">Email</Label>
        <Input
          id="waitlist-email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@example.com"
        />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="waitlist-notes" className="text-xs">Anything the farm should know? (optional)</Label>
        <Textarea
          id="waitlist-notes"
          rows={2}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="How often you'd order, preferred days, neighbors interested..."
        />
      </div>
      <div className="space-y-2 rounded-md border border-border/60 p-3">
        <p className="text-xs font-medium text-foreground">Email me when:</p>
        <div className="flex items-start gap-2">
          <Checkbox
            id="notify-delivery"
            checked={notifyDelivery}
            onCheckedChange={(v) => setNotifyDelivery(v === true)}
          />
          <Label htmlFor="notify-delivery" className="text-xs font-normal leading-snug">
            Delivery coverage expands to my ZIP{zip ? ` (${zip})` : ""}
          </Label>
        </div>
        <div className="flex items-start gap-2">
          <Checkbox
            id="notify-pickup"
            checked={notifyPickup}
            onCheckedChange={(v) => setNotifyPickup(v === true)}
          />
          <Label htmlFor="notify-pickup" className="text-xs font-normal leading-snug">
            Farm pickup time slots become available
          </Label>
        </div>
      </div>
      <div className="flex gap-2">
        <Button type="button" size="sm" onClick={handleSubmit} disabled={submitting}>
          {submitting ? <Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> : <BellRing className="h-4 w-4 mr-1.5" />}
          Join waitlist
        </Button>
        <Button type="button" size="sm" variant="ghost" onClick={() => setOpen(false)} disabled={submitting}>
          Cancel
        </Button>
      </div>
    </div>
  );
};
