import { useEffect, useRef, useState, useCallback } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { Clock, RefreshCw } from 'lucide-react';
import { getMultiStopRoute, getDrivingRoute, formatDuration, formatETA } from '@/services/mapboxRoutingService';
import { toast } from 'sonner';

const MAPBOX_TOKEN = 'pk.eyJ1IjoiZmFybWluMmRvb3IiLCJhIjoiY21mZWNvdXVyMDVjczJpb2dueDcwaGhudSJ9.oeIZtg-WQnD382BjP8Swqw';

interface DeliveryMapProps {
  assignments?: Array<{
    id: string;
    order_id: string;
    status: string;
    order: {
      delivery_address: string;
      pickup_latitude?: number;
      pickup_longitude?: number;
      delivery_latitude?: number;
      delivery_longitude?: number;
    };
    pickup_latitude?: number;
    pickup_longitude?: number;
    delivery_latitude?: number;
    delivery_longitude?: number;
  }>;
  driverLocation?: {
    lat: number;
    lng: number;
  };
  height?: string;
  showRoute?: boolean;
  eta?: string;
  compact?: boolean;
  /** When true, use Mapbox Directions API for real driving routes (slower, more accurate) */
  useRealRoute?: boolean;
  onRouteCalculated?: (durationMinutes: number, distanceMiles: number) => void;
}

export function DeliveryMap({
  assignments = [],
  driverLocation,
  height = "400px",
  showRoute = true,
  eta,
  compact = false,
  useRealRoute = true,
  onRouteCalculated,
}: DeliveryMapProps) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const markersRef = useRef<mapboxgl.Marker[]>([]);
  const [routeETA, setRouteETA] = useState<string | null>(null);
  const [refreshNonce, setRefreshNonce] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const refreshingRef = useRef(false);
  const clearMarkers = useCallback(() => {
    markersRef.current.forEach(m => m.remove());
    markersRef.current = [];
  }, []);

  useEffect(() => {
    if (!mapContainer.current) return;
    mapboxgl.accessToken = MAPBOX_TOKEN;
    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/streets-v12',
      center: [-95.7129, 37.0902],
      zoom: 4,
      attributionControl: false,
    });
    map.current.addControl(new mapboxgl.NavigationControl({ showCompass: false }), 'top-right');
    return () => {
      clearMarkers();
      map.current?.remove();
    };
  }, [clearMarkers]);

  useEffect(() => {
    if (!map.current) return;

    clearMarkers();
    const bounds = new mapboxgl.LngLatBounds();
    let hasBounds = false;

    // Remove existing route layer
    if (map.current.getSource('route')) {
      if (map.current.getLayer('route-casing')) map.current.removeLayer('route-casing');
      if (map.current.getLayer('route-line')) map.current.removeLayer('route-line');
      map.current.removeSource('route');
    }

    // Driver marker (green car icon, pulsing)
    if (driverLocation) {
      const driverEl = document.createElement('div');
      driverEl.innerHTML = `
        <div style="position:relative;width:40px;height:40px;">
          <div style="position:absolute;inset:0;border-radius:50%;background:rgba(16,185,129,0.25);animation:f2dpulse 2s ease-in-out infinite;"></div>
          <div style="position:absolute;inset:7px;border-radius:50%;background:#10B981;border:3px solid white;box-shadow:0 4px 12px rgba(16,185,129,0.5);display:flex;align-items:center;justify-content:center;">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="white"><path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11c-.66 0-1.21.42-1.42 1.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.85 7h10.29l1.04 3H5.81l1.04-3zM19 17H5v-5h14v5z"/><circle cx="7.5" cy="14.5" r="1.5"/><circle cx="16.5" cy="14.5" r="1.5"/></svg>
          </div>
        </div>
      `;
      const marker = new mapboxgl.Marker({ element: driverEl })
        .setLngLat([driverLocation.lng, driverLocation.lat])
        .setPopup(new mapboxgl.Popup({ offset: 25 }).setHTML('<strong>🚗 Your driver</strong>'))
        .addTo(map.current);
      markersRef.current.push(marker);
      bounds.extend([driverLocation.lng, driverLocation.lat]);
      hasBounds = true;
    }

    const routeStops: Array<{ lat: number; lng: number }> = [];
    if (driverLocation) routeStops.push(driverLocation);

    assignments.forEach((assignment) => {
      const pickupLat = assignment.pickup_latitude || assignment.order?.pickup_latitude;
      const pickupLng = assignment.pickup_longitude || assignment.order?.pickup_longitude;
      const deliveryLat = assignment.delivery_latitude || assignment.order?.delivery_latitude;
      const deliveryLng = assignment.delivery_longitude || assignment.order?.delivery_longitude;

      // Pickup marker (orange storefront)
      if (pickupLat && pickupLng) {
        const pickupEl = document.createElement('div');
        pickupEl.innerHTML = `
          <div style="width:36px;height:36px;border-radius:50% 50% 50% 0;background:#F59E0B;border:3px solid white;box-shadow:0 4px 12px rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;transform:rotate(-45deg);">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" style="transform:rotate(45deg);"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/></svg>
          </div>
        `;
        const marker = new mapboxgl.Marker({ element: pickupEl, anchor: 'bottom' })
          .setLngLat([pickupLng, pickupLat])
          .setPopup(new mapboxgl.Popup({ offset: 25 }).setHTML(`<div style="font-size:13px;"><strong>🏪 Pickup</strong><br/><span style="color:#666;">Order #${assignment.order_id.slice(-6)}</span></div>`))
          .addTo(map.current!);
        markersRef.current.push(marker);
        bounds.extend([pickupLng, pickupLat]);
        routeStops.push({ lat: pickupLat, lng: pickupLng });
        hasBounds = true;
      }

      // Drop-off marker (red pin)
      if (deliveryLat && deliveryLng) {
        const deliveryEl = document.createElement('div');
        deliveryEl.innerHTML = `
          <div style="width:36px;height:36px;border-radius:50% 50% 50% 0;background:#EF4444;border:3px solid white;box-shadow:0 4px 12px rgba(0,0,0,0.3);display:flex;align-items:center;justify-content:center;transform:rotate(-45deg);">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" style="transform:rotate(45deg);"><circle cx="12" cy="10" r="3"/><path d="M12 2a8 8 0 0 0-8 8c0 5 8 12 8 12s8-7 8-12a8 8 0 0 0-8-8z"/></svg>
          </div>
        `;
        const marker = new mapboxgl.Marker({ element: deliveryEl, anchor: 'bottom' })
          .setLngLat([deliveryLng, deliveryLat])
          .setPopup(new mapboxgl.Popup({ offset: 25 }).setHTML(`<div style="font-size:13px;"><strong>📍 Drop-off</strong><br/><span style="color:#666;">${assignment.order?.delivery_address || ''}</span></div>`))
          .addTo(map.current!);
        markersRef.current.push(marker);
        bounds.extend([deliveryLng, deliveryLat]);
        routeStops.push({ lat: deliveryLat, lng: deliveryLng });
        hasBounds = true;
      }
    });

    // Draw route
    if (showRoute && routeStops.length >= 2) {
      const drawWhenReady = async () => {
        if (!map.current) return;

        if (useRealRoute) {
          const force = refreshingRef.current;
          const result = routeStops.length === 2
            ? await getDrivingRoute(routeStops[0], routeStops[1], { force })
            : await getMultiStopRoute(routeStops, { force });

          if (result.success && result.geometry && map.current) {
            addRouteLine(result.geometry.coordinates as [number, number][]);
            setRouteETA(formatETA(result.durationMinutes));
            onRouteCalculated?.(result.durationMinutes, result.distanceMiles);
            if (refreshingRef.current) toast.success('Route refreshed');
          } else {
            // Fallback to straight lines
            addRouteLine(routeStops.map(s => [s.lng, s.lat]));
            if (refreshingRef.current) toast.error(result.error || 'Failed to refresh route');
          }
        } else {
          addRouteLine(routeStops.map(s => [s.lng, s.lat]));
        }
        refreshingRef.current = false;
        setIsRefreshing(false);
      };

      if (map.current.isStyleLoaded()) {
        drawWhenReady();
      } else {
        map.current.once('load', drawWhenReady);
      }
    }

    if (hasBounds) {
      map.current.fitBounds(bounds, { padding: compact ? 40 : 80, maxZoom: 14, duration: 800 });
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [assignments, driverLocation, showRoute, compact, clearMarkers, useRealRoute, refreshNonce]);

  const addRouteLine = (coords: [number, number][]) => {
    if (!map.current || map.current.getSource('route')) return;
    map.current.addSource('route', {
      type: 'geojson',
      data: { type: 'Feature', properties: {}, geometry: { type: 'LineString', coordinates: coords } },
    });
    // Casing (white outline)
    map.current.addLayer({
      id: 'route-casing',
      type: 'line',
      source: 'route',
      layout: { 'line-join': 'round', 'line-cap': 'round' },
      paint: { 'line-color': '#ffffff', 'line-width': 8 },
    });
    // Main route
    map.current.addLayer({
      id: 'route-line',
      type: 'line',
      source: 'route',
      layout: { 'line-join': 'round', 'line-cap': 'round' },
      paint: { 'line-color': '#3B82F6', 'line-width': 5 },
    });
  };

  // Pulse animation
  useEffect(() => {
    const id = 'f2d-pulse-style';
    if (document.getElementById(id)) return;
    const style = document.createElement('style');
    style.id = id;
    style.textContent = `@keyframes f2dpulse { 0%,100% { transform: scale(1); opacity: 0.6; } 50% { transform: scale(1.6); opacity: 0; } }`;
    document.head.appendChild(style);
  }, []);

  const displayETA = eta || routeETA;

  const canRefresh = showRoute && useRealRoute;
  const handleRefreshRoute = () => {
    if (refreshingRef.current) return;
    refreshingRef.current = true;
    setIsRefreshing(true);
    setRefreshNonce(n => n + 1);
  };

  return (
    <div className="relative rounded-xl overflow-hidden border border-border">
      <div ref={mapContainer} style={{ height }} />

      {canRefresh && (
        <button
          type="button"
          onClick={handleRefreshRoute}
          disabled={isRefreshing}
          className="absolute top-3 right-14 bg-background/95 backdrop-blur-md rounded-lg px-3 py-2 shadow-lg border text-xs font-medium flex items-center gap-1.5 hover:bg-background disabled:opacity-60"
          title="Force refresh route from Mapbox"
          aria-label="Refresh route"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
          Refresh route
        </button>
      )}

      {displayETA && (
        <div className="absolute top-3 left-3 bg-background/95 backdrop-blur-md rounded-xl px-4 py-2.5 shadow-lg border">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center">
              <Clock className="h-4 w-4 text-primary" />
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wide text-muted-foreground font-medium">Arriving</p>
              <p className="text-sm font-bold leading-tight">{displayETA}</p>
            </div>
          </div>
        </div>
      )}

      <div className="absolute bottom-3 left-3 bg-background/95 backdrop-blur-md rounded-lg px-3 py-1.5 shadow-lg border text-xs flex items-center gap-3">
        <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>Driver</span>
        <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>Pickup</span>
        <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-red-500"></span>Drop-off</span>
      </div>
    </div>
  );
}
