import { createContext, useContext, useState, useEffect } from 'react'
import { useToast } from '@/hooks/use-toast'
import { supabase } from "@/integrations/supabase/client"

export interface CartItem {
  id: string
  name: string
  farmer: string
  price: string
  image: string
  quantity: number
  category: string
  isOrganic?: boolean
}

interface CartContextType {
  items: CartItem[]
  addItem: (item: Omit<CartItem, 'quantity'>) => void
  removeItem: (id: string) => void
  updateQuantity: (id: string, quantity: number) => void
  clearCart: () => void
  getItemCount: () => number
  getTotalPrice: () => number
  isOpen: boolean
  setIsOpen: (open: boolean) => void
}

const CartContext = createContext<CartContextType>({} as CartContextType)

export const useCart = () => {
  const context = useContext(CartContext)
  if (!context) {
    throw new Error('useCart must be used within a CartProvider')
  }
  return context
}

export const CartProvider = ({ children }: { children: React.ReactNode }) => {
  const [items, setItems] = useState<CartItem[]>([])
  const [isOpen, setIsOpen] = useState(false)
  const { toast } = useToast()

  // Load cart from localStorage on mount
  useEffect(() => {
    const savedCart = localStorage.getItem('farm2door-cart')
    if (savedCart) {
      try {
        setItems(JSON.parse(savedCart))
      } catch (error) {
        console.error('Error loading cart:', error)
      }
    }
  }, [])

  // Save cart to localStorage whenever items change
  useEffect(() => {
    localStorage.setItem('farm2door-cart', JSON.stringify(items))
  }, [items])

  const addItem = async (newItem: Omit<CartItem, 'quantity'>) => {
    // Get current user
    const { data: { user } } = await supabase.auth.getUser();
    
    // Check product details including farmer_id and stock
    const { data: product, error } = await supabase
      .from('products')
      .select('stock_quantity, farmer_id')
      .eq('id', newItem.id)
      .single();

    if (error || !product) {
      toast({
        title: "Error",
        description: "Could not verify product availability",
      });
      return;
    }

    // Prevent farmers from adding their own products to cart
    if (user && product.farmer_id === user.id) {
      toast({
        title: "Cannot Add Own Product",
        description: "You cannot add your own products to cart",
      });
      return;
    }

    setItems(prevItems => {
      const existingItem = prevItems.find(item => item.id === newItem.id);
      const currentQuantity = existingItem ? existingItem.quantity : 0;
      
      if (currentQuantity >= product.stock_quantity) {
        toast({
          title: "Out of Stock",
          description: `Only ${product.stock_quantity} items available`,
        });
        return prevItems;
      }
      
      if (existingItem) {
        toast({
          title: "Updated Cart",
          description: `Increased ${newItem.name} quantity to ${existingItem.quantity + 1}`,
        });
        return prevItems.map(item =>
          item.id === newItem.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        toast({
          title: "Added to Cart",
          description: `${newItem.name} has been added to your cart!`,
        });
        return [...prevItems, { ...newItem, quantity: 1 }];
      }
    });
  };

  const removeItem = (id: string) => {
    setItems(prevItems => {
      const item = prevItems.find(item => item.id === id)
      if (item) {
        toast({
          title: "Removed from Cart",
          description: `${item.name} has been removed from your cart`,
        })
      }
      return prevItems.filter(item => item.id !== id)
    })
  }

  const updateQuantity = async (id: string, quantity: number) => {
    if (quantity <= 0) {
      removeItem(id);
      return;
    }

    // Check stock availability
    const { data: product, error } = await supabase
      .from('products')
      .select('stock_quantity')
      .eq('id', id)
      .single();

    if (error || !product) {
      toast({
        title: "Error",
        description: "Could not verify product availability",
      });
      return;
    }

    if (quantity > product.stock_quantity) {
      toast({
        title: "Insufficient Stock",
        description: `Only ${product.stock_quantity} items available`,
      });
      return;
    }
    
    setItems(prevItems =>
      prevItems.map(item =>
        item.id === id ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setItems([])
    toast({
      title: "Cart Cleared",
      description: "All items have been removed from your cart",
    })
  }

  const getItemCount = () => {
    return items.reduce((total, item) => total + item.quantity, 0)
  }

  const getTotalPrice = () => {
    return items.reduce((total, item) => {
      const price = parseFloat(item.price.replace(/[$,]/g, ''))
      return total + (price * item.quantity)
    }, 0)
  }

  const value = {
    items,
    addItem,
    removeItem,
    updateQuantity,
    clearCart,
    getItemCount,
    getTotalPrice,
    isOpen,
    setIsOpen,
  }

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>
}