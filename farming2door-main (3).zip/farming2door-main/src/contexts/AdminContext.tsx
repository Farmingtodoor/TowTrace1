import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './AuthContext';

type UserRole = 'super_admin' | 'admin' | 'farmer' | 'customer' | 'driver';

interface AdminContextType {
  userRole: UserRole | null;
  isAdmin: boolean;
  isSuperAdmin: boolean;
  isFarmer: boolean;
  loading: boolean;
  checkRole: (role: UserRole) => boolean;
  refreshRole: () => Promise<void>;
}

const AdminContext = createContext<AdminContextType | undefined>(undefined);

export const AdminProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [userRole, setUserRole] = useState<UserRole | null>(null);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  const checkRole = (role: UserRole) => userRole === role;
  const isAdmin = userRole === 'admin' || userRole === 'super_admin';
  const isSuperAdmin = userRole === 'super_admin';
  const isFarmer = userRole === 'farmer';

  const refreshRole = async () => {
    if (!user) {
      setUserRole(null);
      setLoading(false);
      return;
    }

    try {
      console.log('Refreshing role for user:', user.id);
      const { data, error } = await supabase.rpc('get_current_user_role');
      
      if (error) {
        console.error('Error fetching user role:', error);
        setUserRole('customer'); // Default fallback
      } else {
        console.log('User role returned:', data);
        setUserRole(data || 'customer');
      }
    } catch (error) {
      console.error('Error calling get_current_user_role:', error);
      setUserRole('customer');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshRole();
  }, [user]);

  const value = {
    userRole,
    isAdmin,
    isSuperAdmin,
    isFarmer,
    loading,
    checkRole,
    refreshRole,
  };

  return (
    <AdminContext.Provider value={value}>
      {children}
    </AdminContext.Provider>
  );
};

export const useAdmin = () => {
  const context = useContext(AdminContext);
  if (context === undefined) {
    throw new Error('useAdmin must be used within an AdminProvider');
  }
  return context;
};