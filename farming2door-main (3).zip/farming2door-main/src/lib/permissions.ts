export type AppRole = "super_admin" | "admin" | "farmer" | "customer" | "driver";

export type Permission =
  | "orders.view"
  | "orders.view_all"
  | "orders.update_status"
  | "orders.cancel"
  | "orders.edit_notes"
  | "products.manage"
  | "farmers.review"
  | "users.manage"
  | "roles.manage"
  | "payouts.view"
  | "payouts.approve"
  | "notifications.send"
  | "waitlist.view"
  | "settings.manage"
  | "audit.view";

const ROLE_PERMISSIONS: Record<AppRole, Permission[]> = {
  super_admin: [
    "orders.view",
    "orders.view_all",
    "orders.update_status",
    "orders.cancel",
    "orders.edit_notes",
    "products.manage",
    "farmers.review",
    "users.manage",
    "roles.manage",
    "payouts.view",
    "payouts.approve",
    "notifications.send",
    "waitlist.view",
    "settings.manage",
    "audit.view",
  ],
  admin: [
    "orders.view",
    "orders.view_all",
    "orders.update_status",
    "orders.edit_notes",
    "products.manage",
    "farmers.review",
    "users.manage",
    "payouts.view",
    "notifications.send",
    "waitlist.view",
    "settings.manage",
  ],
  farmer: ["orders.view", "orders.update_status", "orders.edit_notes", "products.manage", "waitlist.view"],
  customer: [],
  driver: [],
};

export function permissionsForRole(role: AppRole | null | undefined): Permission[] {
  if (!role) return [];
  return ROLE_PERMISSIONS[role] ?? [];
}

export function roleCan(role: AppRole | null | undefined, permission: Permission): boolean {
  return permissionsForRole(role).includes(permission);
}

export const PERMISSION_DENIED_MESSAGE: Record<string, string> = {
  "orders.cancel": "Only a Super Admin can cancel an order.",
  "payouts.approve": "Only a Super Admin can approve payouts.",
  "roles.manage": "Only a Super Admin can change user roles.",
};

export function deniedMessage(permission: Permission): string {
  return (
    PERMISSION_DENIED_MESSAGE[permission] ??
    "Your role doesn't allow this action. Contact a Super Admin if you need access."
  );
}
