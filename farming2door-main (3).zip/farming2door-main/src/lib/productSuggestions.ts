import type { CartItem } from "@/contexts/CartContext";

/**
 * Category helpers used to decide which checkout options apply to a cart.
 * Processing add-ons (cut & wrap, vacuum sealing, etc.) only make sense for
 * livestock / whole-animal purchases — never for produce, dairy or pantry items.
 */

const LIVESTOCK_KEYWORDS = [
  "livestock",
  "meat",
  "beef",
  "cattle",
  "cow",
  "cows",
  "goat",
  "goats",
  "lamb",
  "sheep",
  "pork",
  "pig",
  "hog",
  "poultry",
  "chicken",
  "turkey",
  "duck",
  "rabbit",
  "bison",
  "whole animal",
  "half animal",
  "quarter",
];

/**
 * Words/phrases that contain a livestock keyword but are NOT livestock
 * (produce, dairy, mushrooms, pantry items...). Checked first.
 */
const NON_LIVESTOCK_PHRASES = [
  "beefsteak",
  "beef steak tomato",
  "chicken of the woods",
  "goat cheese",
  "goat milk",
  "goat's milk",
  "goat yogurt",
  "goat soap",
  "sheep cheese",
  "sheep milk",
  "sheep's milk",
  "cow milk",
  "cow's milk",
  "cow cheese",
  "chicken egg",
  "duck egg",
  "turkey fig",
  "pig weed",
  "pigweed",
  "cattle panel",
  "meatless",
];

const NON_LIVESTOCK_CATEGORIES = [
  "produce",
  "vegetable",
  "fruit",
  "dairy",
  "eggs",
  "honey",
  "bakery",
  "pantry",
  "grain",
  "herb",
  "flower",
  "mushroom",
];

const normalize = (value?: string) => (value || "").toLowerCase();

/** Whole-word (or phrase) match so "beefsteak tomato" never matches "beef". */
const containsWord = (haystack: string, keyword: string) => {
  const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp(`(^|[^a-z])${escaped}(s|es)?([^a-z]|$)`, "i").test(haystack);
};

export const isLivestockItem = (item: Pick<CartItem, "category" | "name">) => {
  const category = normalize(item.category);
  const name = normalize(item.name);
  const haystack = `${category} ${name}`.replace(/[’']/g, "'");

  // Explicit non-livestock products that merely contain a meat word
  if (NON_LIVESTOCK_PHRASES.some((phrase) => haystack.includes(phrase))) return false;

  // Categories that can never require butchering
  if (NON_LIVESTOCK_CATEGORIES.some((c) => category.includes(c))) return false;

  return LIVESTOCK_KEYWORDS.some((keyword) => containsWord(haystack, keyword));
};

export const cartHasLivestock = (items: Pick<CartItem, "category" | "name">[]) =>
  items.some(isLivestockItem);


/**
 * CENTRALIZED ELIGIBILITY RULE.
 * This is the single source of truth for whether processing add-ons
 * (cut & wrap, vacuum sealing, smoking...) may be shown or charged.
 * Never check livestock keywords ad-hoc anywhere else in the checkout flow.
 */
export const canOfferProcessingAddOns = (
  items: Pick<CartItem, "category" | "name">[]
) => Array.isArray(items) && items.length > 0 && cartHasLivestock(items);

/** Strip any add-on selection that isn't allowed for the current cart. */
export const filterEligibleAddOns = <T extends { enabled?: boolean }>(
  items: Pick<CartItem, "category" | "name">[],
  addOns: T[]
): T[] => (canOfferProcessingAddOns(items) ? addOns : []);

export interface ProductSuggestion {
  id: string;
  title: string;
  description: string;
  /** Short "why am I seeing this?" explanation */
  reason: string;
  tone: "processing" | "storage" | "care" | "pairing" | "logistics";
}

export type FulfillmentMethod = "pickup" | "delivery";

export interface SuggestionContext {
  fulfillment: FulfillmentMethod;
  /** Optional scheduled pickup window label, e.g. "Sat 9:00 AM – 11:00 AM" */
  pickupWindowLabel?: string;
  /** Delivery distance in miles, when known */
  distanceMiles?: number;
}

type SuggestionRule = {
  id: string;
  match: (haystack: string, item: Pick<CartItem, "category" | "name">) => boolean;
  /** Human-friendly label for the matched cart category, used in the reason */
  matchedLabel: string;
  build: (ctx: SuggestionContext, matchedItemName: string) => ProductSuggestion;
};

const itemReason = (matchedLabel: string, itemName: string, ctx: SuggestionContext) =>
  `Shown because your cart includes ${matchedLabel} (“${itemName}”)` +
  (ctx.fulfillment === "pickup"
    ? ctx.pickupWindowLabel
      ? ` and you chose farm pickup ${ctx.pickupWindowLabel}.`
      : " and you chose farm pickup."
    : ctx.distanceMiles
      ? ` and you chose delivery (~${Math.round(ctx.distanceMiles)} mi).`
      : " and you chose delivery.");

const perishableHandling = (ctx: SuggestionContext) =>
  ctx.fulfillment === "pickup"
    ? `Bring a cooler with ice packs to your pickup${
        ctx.pickupWindowLabel ? ` (${ctx.pickupWindowLabel})` : ""
      } and refrigerate within 2 hours.`
    : `Your driver keeps this chilled${
        ctx.distanceMiles ? ` over the ~${Math.round(ctx.distanceMiles)} mile route` : ""
      } — plan to be home at drop-off and refrigerate right away.`;

const rules: SuggestionRule[] = [
  {
    id: "livestock",
    match: (_h, item) => isLivestockItem(item),
    matchedLabel: "livestock or a whole/half animal",
    build: (ctx, itemName) => ({
      id: "livestock",
      title: "Tell the farm how to process your animal",
      reason: itemReason("livestock or a whole/half animal", itemName, ctx),
      description:
        "Choose cut & wrap, vacuum sealing or smoking below, and add cut thickness and package sizes in the order notes — whole and half animals take 10-14 days at the processor. " +
        (ctx.fulfillment === "pickup"
          ? "Bring a large cooler or two; a half animal can fill 6-8 cubic feet of freezer space."
          : "Clear freezer space before your delivery window — a half animal can fill 6-8 cubic feet."),
      tone: "processing",
    }),
  },
  {
    id: "produce",
    match: (h) =>
      ["produce", "vegetable", "fruit", "tomato", "onion", "green", "herb", "berry", "melon", "pepper"].some((k) =>
        h.includes(k)
      ),
    matchedLabel: "fresh produce",
    build: (ctx, itemName) => ({
      id: "produce",
      title: "Keep your produce fresh longer",
      reason: itemReason("fresh produce", itemName, ctx),
      description:
        (ctx.fulfillment === "pickup"
          ? "Harvested to order for your pickup window — keep it out of a hot car on the way home. "
          : "Harvested the morning of your delivery — unpack as soon as it arrives. ") +
        "Refrigerate leafy greens and berries right away, but keep tomatoes, onions and potatoes at room temperature in a dry, dark spot. Wash only just before use.",
      tone: "storage",
    }),
  },
  {
    id: "dairy",
    match: (h) => ["dairy", "milk", "cheese", "butter", "yogurt", "cream"].some((k) => h.includes(k)),
    matchedLabel: "dairy",
    build: (ctx, itemName) => ({
      id: "dairy",
      title: "Keep dairy under 40°F",
      reason: itemReason("dairy", itemName, ctx),
      description: `${perishableHandling(ctx)} Use raw milk within 7-10 days.`,
      tone: "care",
    }),
  },
  {
    id: "eggs",
    match: (h) => h.includes("egg"),
    matchedLabel: "farm-fresh eggs",
    build: (ctx, itemName) => ({
      id: "eggs",
      title: "Farm-fresh eggs handling",
      reason: itemReason("farm-fresh eggs", itemName, ctx),
      description:
        (ctx.fulfillment === "delivery"
          ? "Bring the carton in promptly after drop-off. "
          : "Keep the carton flat and upright on the ride home. ") +
        "Unwashed farm eggs keep on the counter for up to 2 weeks, or refrigerate for 2-3 months. Don't wash them until you're ready to cook.",
      tone: "care",
    }),
  },
  {
    id: "pantry",
    match: (h) => ["grain", "flour", "pantry", "honey", "jam", "bean", "rice", "corn meal"].some((k) => h.includes(k)),
    matchedLabel: "pantry goods",
    build: (ctx, itemName) => ({
      id: "pantry",
      title: "Store pantry goods airtight",
      reason: itemReason("pantry goods", itemName, ctx),
      description:
        "Freshly milled flour and grains keep best in a sealed container — refrigerate or freeze whole-grain flour to protect the natural oils.",
      tone: "storage",
    }),
  },
];

const fulfillmentTip = (
  items: Pick<CartItem, "category" | "name">[],
  ctx: SuggestionContext
): ProductSuggestion => {
  if (ctx.fulfillment === "pickup") {
    return {
      id: "pickup-logistics",
      reason: ctx.pickupWindowLabel
        ? `Shown because you chose farm pickup and scheduled ${ctx.pickupWindowLabel}.`
        : "Shown because you chose farm pickup for this order.",
      title: ctx.pickupWindowLabel
        ? `Arriving ${ctx.pickupWindowLabel}`
        : "Pick a pickup window that works for you",
      description:
        "Bring your order confirmation (or the name on the order) to the farm. " +
        (cartHasLivestock(items)
          ? "Come with coolers or a truck bed — bulk meat orders are heavy and bulky."
          : "Reusable bags or a crate make loading easier at the farm stand."),
      tone: "logistics",
    };
  }

  return {
    id: "delivery-logistics",
    reason: ctx.distanceMiles
      ? `Shown because you chose delivery and you're about ${Math.round(ctx.distanceMiles)} miles from the farm.`
      : "Shown because you chose delivery for this order.",
    title: "Get ready for your delivery window",
    description:
      (ctx.distanceMiles
        ? `You're about ${Math.round(ctx.distanceMiles)} miles from the farm. `
        : "") +
      "Add gate codes or drop-off instructions in the order notes, and keep your phone handy — the driver texts on approach.",
    tone: "logistics",
  };
};

export const getCheckoutSuggestions = (
  items: Pick<CartItem, "category" | "name">[],
  context: SuggestionContext = { fulfillment: "pickup" }
): ProductSuggestion[] => {
  const seen = new Set<string>();
  const suggestions: ProductSuggestion[] = [];

  for (const item of items) {
    const haystack = `${normalize(item.category)} ${normalize(item.name)}`;
    for (const rule of rules) {
      if (!seen.has(rule.id) && rule.match(haystack, item)) {
        seen.add(rule.id);
        suggestions.push(rule.build(context, item.name));
      }
    }
  }

  if (items.length > 0) {
    suggestions.push(fulfillmentTip(items, context));
  }

  return suggestions;
};

