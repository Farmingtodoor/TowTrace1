/**
 * Shared onboarding-completeness rules for farmer applications.
 * Mirrors the required items shown to farmers in ProfileCompletenessCard,
 * so the admin console approves only farms that reached 100%.
 */

export interface FarmerApplicationLike {
  farm_name?: string | null;
  farm_address?: string | null;
  phone?: string | null;
  farm_description?: string | null;
  categories?: unknown;
}

const hasText = (value: unknown) => typeof value === "string" && value.trim().length > 0;

const hasItems = (value: unknown) => {
  if (Array.isArray(value)) return value.length > 0;
  if (value && typeof value === "object") return Object.keys(value).length > 0;
  return false;
};

export interface CompletenessResult {
  percent: number;
  missing: string[];
  complete: boolean;
}

/**
 * @param app         the farmer application row
 * @param hasLocation whether the farmer profile has a city and state on file
 */
export function evaluateFarmerCompleteness(
  app: FarmerApplicationLike,
  hasLocation: boolean
): CompletenessResult {
  const checks: { label: string; done: boolean }[] = [
    { label: "Farm name", done: hasText(app.farm_name) },
    { label: "Farm address", done: hasText(app.farm_address) },
    { label: "City & state", done: hasLocation },
    { label: "Contact phone", done: hasText(app.phone) },
    { label: "Product categories", done: hasItems(app.categories) },
    { label: "Farm description", done: hasText(app.farm_description) },
  ];

  const done = checks.filter((c) => c.done).length;
  const missing = checks.filter((c) => !c.done).map((c) => c.label);

  return {
    percent: Math.round((done / checks.length) * 100),
    missing,
    complete: missing.length === 0,
  };
}
