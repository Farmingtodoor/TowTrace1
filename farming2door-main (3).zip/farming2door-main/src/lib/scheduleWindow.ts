/**
 * Timezone-safe helpers for pickup/delivery schedule windows.
 *
 * `<input type="datetime-local">` speaks *local wall clock* while the database
 * stores UTC ISO strings, so every conversion goes through these helpers to
 * avoid off-by-hours bugs across timezones and DST boundaries.
 */

const pad = (n: number) => String(n).padStart(2, "0");

/** ISO timestamp -> value accepted by <input type="datetime-local"> in local time. */
export function toLocalInput(iso?: string | null): string {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(
    d.getMinutes()
  )}`;
}

/** Local datetime-local value -> UTC ISO string (or null when empty/invalid). */
export function fromLocalInput(value: string): string | null {
  if (!value) return null;
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}

/** Current local time formatted for a datetime-local `min` attribute. */
export function nowLocalInput(offsetMinutes = 0): string {
  const d = new Date(Date.now() + offsetMinutes * 60_000);
  return toLocalInput(d.toISOString());
}

export interface WindowValidation {
  ok: boolean;
  error?: string;
  start: string | null;
  end: string | null;
}

/**
 * Validates a schedule window: no past times, end strictly after start,
 * and an end always paired with a start.
 */
export function validateWindow(startLocal: string, endLocal: string): WindowValidation {
  const start = fromLocalInput(startLocal);
  const end = fromLocalInput(endLocal);

  if (!start && !end) return { ok: true, start: null, end: null };

  if (!start && end) {
    return { ok: false, error: "Set a start time before the window end", start, end };
  }

  // Allow a minute of slack so a form open for a while doesn't fail on the second.
  const floor = Date.now() - 60_000;
  if (start && new Date(start).getTime() < floor) {
    return { ok: false, error: "The window can't start in the past", start, end };
  }
  if (end && new Date(end).getTime() < floor) {
    return { ok: false, error: "The window can't end in the past", start, end };
  }
  if (start && end && new Date(end).getTime() <= new Date(start).getTime()) {
    return { ok: false, error: "The window end must be after the start", start, end };
  }

  return { ok: true, start, end };
}

/** "Sep 3, 2026, 9:00 AM – 11:00 AM" in the viewer's own timezone. */
export function formatWindow(start?: string | null, end?: string | null): string | null {
  if (!start) return null;
  const s = new Date(start);
  if (Number.isNaN(s.getTime())) return null;
  const base = s.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
  if (!end) return base;
  const e = new Date(end);
  if (Number.isNaN(e.getTime())) return base;
  const sameDay = s.toDateString() === e.toDateString();
  const endLabel = sameDay
    ? e.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })
    : e.toLocaleString(undefined, {
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
      });
  return `${base} – ${endLabel}`;
}
