import { jsPDF } from "jspdf";

export interface PayoutReceipt {
  id: string;
  payout_request_id: string;
  farmer_id: string;
  receipt_number: string;
  amount: number;
  currency: string;
  status: string;
  stripe_transfer_id: string | null;
  failure_reason: string | null;
  sent_at: string;
}

export function downloadPayoutReceiptPdf(
  receipt: PayoutReceipt,
  farmerName?: string | null,
) {
  const doc = new jsPDF({ unit: "pt", format: "letter" });
  const left = 56;
  let y = 72;

  doc.setFontSize(20);
  doc.text("Farming2Door", left, y);
  doc.setFontSize(12);
  y += 22;
  doc.text("Payout receipt", left, y);

  y += 34;
  doc.setDrawColor(200);
  doc.line(left, y, 556, y);

  const rows: [string, string][] = [
    ["Receipt number", receipt.receipt_number],
    ["Status", receipt.status === "sent" ? "Sent" : "Failed"],
    ["Paid to", farmerName || "Farm partner"],
    ["Amount", `$${Number(receipt.amount).toFixed(2)} ${receipt.currency.toUpperCase()}`],
    ["Date", new Date(receipt.sent_at).toLocaleString()],
    ["Transfer reference", receipt.stripe_transfer_id || "—"],
  ];

  if (receipt.failure_reason) rows.push(["Failure reason", receipt.failure_reason]);

  y += 28;
  doc.setFontSize(11);
  rows.forEach(([label, value]) => {
    doc.setTextColor(110);
    doc.text(label, left, y);
    doc.setTextColor(20);
    doc.text(String(value), left + 170, y);
    y += 24;
  });

  y += 16;
  doc.setDrawColor(200);
  doc.line(left, y, 556, y);
  y += 24;
  doc.setFontSize(9);
  doc.setTextColor(120);
  doc.text(
    "Funds are transferred to the farm's verified bank account and typically settle in 1–2 business days.",
    left,
    y,
    { maxWidth: 500 },
  );

  doc.save(`payout-receipt-${receipt.receipt_number}.pdf`);
}
