/**
 * Enhanced Security utilities for input validation, sanitization, and protection
 */

// Enhanced input validation patterns
export const VALIDATION_PATTERNS = {
  email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  phone: /^\+?[\d\s\-\(\)]+$/,
  zipCode: /^\d{5}(-\d{4})?$/,
  // Only allow alphanumeric, spaces, and basic punctuation
  safeName: /^[a-zA-Z0-9\s\-'\.]+$/,
  // Safe product names and descriptions
  safeText: /^[a-zA-Z0-9\s\-'\.,:;!?\n]+$/,
} as const;

/**
 * Sanitize user input to prevent XSS attacks
 */
export const sanitizeInput = (input: string): string => {
  if (!input) return '';
  
  return input
    .trim()
    // Remove HTML tags
    .replace(/<[^>]*>/g, '')
    // Remove potential script content
    .replace(/javascript:/gi, '')
    .replace(/on\w+=/gi, '')
    // Limit length
    .slice(0, 1000);
};

/**
 * Validate email format
 */
export const isValidEmail = (email: string): boolean => {
  return VALIDATION_PATTERNS.email.test(email);
};

/**
 * Validate phone number format
 */
export const isValidPhone = (phone: string): boolean => {
  return VALIDATION_PATTERNS.phone.test(phone);
};

/**
 * Validate and sanitize name input
 */
export const sanitizeName = (name: string): string => {
  const sanitized = sanitizeInput(name);
  // Only allow safe characters for names
  return sanitized.replace(/[^a-zA-Z0-9\s\-'\.]/g, '');
};

/**
 * Validate price input
 */
export const isValidPrice = (price: number): boolean => {
  return !isNaN(price) && price > 0 && price < 10000; // Max $10,000
};

/**
 * Validate quantity input
 */
export const isValidQuantity = (quantity: number): boolean => {
  return Number.isInteger(quantity) && quantity > 0 && quantity <= 1000;
};

/**
 * Rate limiting check (client-side helper)
 */
export const checkRateLimit = (action: string, maxAttempts = 5, windowMs = 60000): boolean => {
  const key = `rate_limit_${action}`;
  const now = Date.now();
  const stored = localStorage.getItem(key);
  
  if (stored) {
    const { count, timestamp } = JSON.parse(stored);
    
    // Reset if window expired
    if (now - timestamp > windowMs) {
      localStorage.setItem(key, JSON.stringify({ count: 1, timestamp: now }));
      return true;
    }
    
    // Check if limit exceeded
    if (count >= maxAttempts) {
      return false;
    }
    
    // Increment count
    localStorage.setItem(key, JSON.stringify({ count: count + 1, timestamp }));
  } else {
    // First attempt
    localStorage.setItem(key, JSON.stringify({ count: 1, timestamp: now }));
  }
  
  return true;
};

/**
 * Generate CSRF token for forms
 */
export const generateCSRFToken = (): string => {
  return crypto.randomUUID();
};

/**
 * Validate file uploads
 */
export const validateFileUpload = (file: File, allowedTypes: string[], maxSize: number): boolean => {
  // Check file type
  if (!allowedTypes.includes(file.type)) {
    return false;
  }
  
  // Check file size (in bytes)
  if (file.size > maxSize) {
    return false;
  }
  
  return true;
};

/**
 * Enhanced security validation for suspicious patterns
 */
export const detectSuspiciousActivity = (input: string): boolean => {
  const suspiciousPatterns = [
    /(?:union|select|insert|update|delete|drop|create|alter)[\s\+]/gi,
    /<script|javascript:|vbscript:|onload=|onerror=/gi,
    /eval\s*\(|setTimeout\s*\(|setInterval\s*\(/gi,
    /data:text\/html|data:image\/svg\+xml/gi,
  ];
  
  return suspiciousPatterns.some(pattern => pattern.test(input));
};

/**
 * Advanced input sanitization with security logging
 */
export const sanitizeSecurely = (input: string, context = 'general'): string => {
  if (!input) return '';
  
  // Log suspicious activity
  if (detectSuspiciousActivity(input)) {
    console.warn('🚨 Suspicious input detected:', { context, input: input.slice(0, 50) });
  }
  
  return sanitizeInput(input);
};

/**
 * Validate secure file uploads with enhanced checks
 */
export const validateSecureUpload = (file: File): { valid: boolean; error?: string } => {
  // Define allowed types inline to avoid order issues
  const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'] as const;
  
  // Check file type
  if (!(allowedTypes as readonly string[]).includes(file.type)) {
    return { valid: false, error: 'Invalid file type' };
  }
  
  // Check file size (5MB limit)
  if (file.size > 5 * 1024 * 1024) {
    return { valid: false, error: 'File too large' };
  }
  
  // Check for suspicious file names
  if (/[<>:"|?*]/.test(file.name) || file.name.includes('..')) {
    return { valid: false, error: 'Invalid file name' };
  }
  
  return { valid: true };
};

/**
 * Enhanced rate limiting with exponential backoff
 */
export const checkEnhancedRateLimit = (
  action: string, 
  maxAttempts = 5, 
  windowMs = 60000,
  blockDurationMs = 300000 // 5 minutes block
): { allowed: boolean; retryAfter?: number } => {
  const key = `rate_limit_${action}`;
  const blockKey = `blocked_${action}`;
  const now = Date.now();
  
  // Check if currently blocked
  const blockedUntil = localStorage.getItem(blockKey);
  if (blockedUntil && now < parseInt(blockedUntil)) {
    return { 
      allowed: false, 
      retryAfter: parseInt(blockedUntil) - now 
    };
  }
  
  const stored = localStorage.getItem(key);
  
  if (stored) {
    const { count, timestamp } = JSON.parse(stored);
    
    // Reset if window expired
    if (now - timestamp > windowMs) {
      localStorage.setItem(key, JSON.stringify({ count: 1, timestamp: now }));
      return { allowed: true };
    }
    
    // Check if limit exceeded
    if (count >= maxAttempts) {
      // Block for extended period
      localStorage.setItem(blockKey, (now + blockDurationMs).toString());
      localStorage.removeItem(key); // Reset counter
      return { allowed: false, retryAfter: blockDurationMs };
    }
    
    // Increment count
    localStorage.setItem(key, JSON.stringify({ count: count + 1, timestamp }));
  } else {
    // First attempt
    localStorage.setItem(key, JSON.stringify({ count: 1, timestamp: now }));
  }
  
  return { allowed: true };
};

/**
 * Security headers validation
 */
export const validateSecurityHeaders = (): string[] => {
  const warnings: string[] = [];
  
  // Check if running on HTTPS in production
  if (location.protocol !== 'https:' && location.hostname !== 'localhost') {
    warnings.push('Site not served over HTTPS');
  }
  
  return warnings;
};

/**
 * Constants for file upload validation
 */
export const FILE_UPLOAD_LIMITS = {
  image: {
    types: ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'],
    maxSize: 5 * 1024 * 1024, // 5MB
  },
  video: {
    types: ['video/mp4', 'video/webm'],
    maxSize: 50 * 1024 * 1024, // 50MB
  },
} as const;

/**
 * Security audit logger
 */
export const logSecurityEvent = (event: string, details?: any) => {
  console.log(`🔒 Security Event: ${event}`, details);
  // In production, this would send to your security monitoring service
};