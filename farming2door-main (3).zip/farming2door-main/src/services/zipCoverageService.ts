/**
 * ZIP coverage service
 *
 * Improves ZIP-based distance accuracy by:
 *  - resolving nearby/sibling ZIP codes when an exact ZIP lookup fails
 *  - using neighbouring ZIP centroids to estimate positional uncertainty
 *  - returning an estimated distance RANGE (min–max) instead of one number
 *  - deciding delivery eligibility (inside / edge of zone / outside)
 */

import { geocodeZipCode, haversineDistance, type GeocodedLocation } from './geocodingService';

export interface ResolvedZip {
  zip: string;
  location: GeocodedLocation;
  /** true when the exact ZIP was not found and a nearby ZIP was used instead */
  approximate: boolean;
  /** nearby ZIPs used to estimate positional uncertainty */
  nearbyZips: string[];
  success: boolean;
  error?: string;
}

export interface DistanceRange {
  minMiles: number;
  maxMiles: number;
  centerMiles: number;
  /** ± uncertainty derived from nearby ZIP centroid spread */
  uncertaintyMiles: number;
  durationMinRange: number;
  durationMaxRange: number;
}

export type EligibilityStatus = 'inside' | 'edge' | 'outside' | 'unknown';

export interface EligibilityResult {
  status: EligibilityStatus;
  range: DistanceRange | null;
  resolved: ResolvedZip | null;
  radiusMiles: number;
  message: string;
}

const ROAD_FACTOR_MIN = 1.15;
const ROAD_FACTOR_MAX = 1.35;
const AVG_MPH = 30;
const MAX_UNCERTAINTY_MILES = 3;

export function extractZip(input: string): string | null {
  const match = input.match(/\b(\d{5})(?:-\d{4})?\b/);
  return match ? match[1] : null;
}

/** Build candidate nearby ZIP codes sharing the same first 4 digits, closest first. */
function siblingZips(zip: string): string[] {
  const prefix = zip.slice(0, 4);
  const last = Number(zip[4]);
  const candidates: string[] = [];
  for (let delta = 1; delta <= 9; delta++) {
    for (const d of [last - delta, last + delta]) {
      if (d >= 0 && d <= 9) candidates.push(`${prefix}${d}`);
    }
  }
  return Array.from(new Set(candidates));
}

/**
 * Resolve a ZIP, falling back to the nearest sibling ZIP when the exact one is unknown.
 * Also collects nearby centroids used later for uncertainty estimation.
 */
export async function resolveZipWithNearby(rawZip: string): Promise<ResolvedZip> {
  const zip = (rawZip || '').replace(/\D/g, '').slice(0, 5);
  if (zip.length !== 5) {
    return {
      zip, location: emptyLocation(), approximate: false, nearbyZips: [],
      success: false, error: 'Enter a valid 5-digit ZIP code',
    };
  }

  const exact = await geocodeZipCode(zip);
  const siblings = siblingZips(zip);

  if (exact.success) {
    return { zip, location: exact, approximate: false, nearbyZips: siblings.slice(0, 4), success: true };
  }

  // Exact ZIP unknown — probe nearby ZIPs in order of numeric closeness
  for (const candidate of siblings.slice(0, 6)) {
    const geo = await geocodeZipCode(candidate);
    if (geo.success) {
      return {
        zip, location: geo, approximate: true,
        nearbyZips: siblings.filter(s => s !== candidate).slice(0, 4),
        success: true,
      };
    }
  }

  return {
    zip, location: emptyLocation(), approximate: false, nearbyZips: [],
    success: false, error: 'We could not locate that ZIP code',
  };
}

function emptyLocation(): GeocodedLocation {
  return { latitude: 0, longitude: 0, city: '', state: '', success: false };
}

/**
 * Estimate the distance range between an origin coordinate and a customer ZIP.
 * Uncertainty comes from how far apart neighbouring ZIP centroids sit, which
 * approximates the physical size of the ZIP area.
 */
export async function estimateDistanceRange(
  origin: { lat: number; lng: number },
  resolved: ResolvedZip,
  knownRoadMiles?: number,
): Promise<DistanceRange | null> {
  if (!resolved.success) return null;

  const straight = haversineDistance(
    origin.lat, origin.lng,
    resolved.location.latitude, resolved.location.longitude,
  );

  // Positional uncertainty from neighbouring ZIP centroids
  const neighbours = await Promise.all(resolved.nearbyZips.map(z => geocodeZipCode(z)));
  const spreads = neighbours
    .filter(n => n.success)
    .map(n => haversineDistance(
      resolved.location.latitude, resolved.location.longitude,
      n.latitude, n.longitude,
    ))
    .filter(d => d > 0 && d < 25)
    .sort((a, b) => a - b);

  let uncertainty = 1;
  if (spreads.length) uncertainty = spreads[Math.floor(spreads.length / 2)] / 2;
  if (resolved.approximate) uncertainty += 2;
  uncertainty = Math.min(Math.max(uncertainty, 0.5), MAX_UNCERTAINTY_MILES);

  const center = knownRoadMiles ?? straight * ((ROAD_FACTOR_MIN + ROAD_FACTOR_MAX) / 2);
  const lowBase = knownRoadMiles ?? straight * ROAD_FACTOR_MIN;
  const highBase = knownRoadMiles ?? straight * ROAD_FACTOR_MAX;

  const minMiles = Math.max(0.3, lowBase - uncertainty);
  const maxMiles = highBase + uncertainty;

  return {
    minMiles: round(minMiles),
    maxMiles: round(maxMiles),
    centerMiles: round(center),
    uncertaintyMiles: round(uncertainty),
    durationMinRange: Math.max(5, Math.round((minMiles / AVG_MPH) * 60)),
    durationMaxRange: Math.max(10, Math.round((maxMiles / AVG_MPH) * 60)),
  };
}

function round(n: number) {
  return Math.round(n * 10) / 10;
}

export function evaluateEligibility(
  range: DistanceRange | null,
  resolved: ResolvedZip | null,
  radiusMiles: number,
): EligibilityResult {
  if (!resolved || !resolved.success || !range) {
    return {
      status: 'unknown', range, resolved, radiusMiles,
      message: resolved?.error || 'Add a delivery ZIP code to check availability',
    };
  }

  const place = [resolved.location.city, resolved.location.state].filter(Boolean).join(', ');
  const rangeLabel = formatRange(range);

  if (range.maxMiles <= radiusMiles) {
    return {
      status: 'inside', range, resolved, radiusMiles,
      message: `${place} is inside the delivery zone — about ${rangeLabel} from the farm.`,
    };
  }
  if (range.minMiles <= radiusMiles) {
    return {
      status: 'edge', range, resolved, radiusMiles,
      message: `${place} sits near the edge of the ${radiusMiles}-mile zone (about ${rangeLabel} away). Delivery may be confirmed by the farm.`,
    };
  }
  return {
    status: 'outside', range, resolved, radiusMiles,
    message: `${place} is about ${rangeLabel} away — outside this farm's ${radiusMiles}-mile delivery zone.`,
  };
}

export function formatRange(range: DistanceRange): string {
  if (Math.abs(range.maxMiles - range.minMiles) < 0.6) return `${range.centerMiles} mi`;
  return `${range.minMiles}–${range.maxMiles} mi`;
}

export function formatDurationRange(range: DistanceRange): string {
  if (range.durationMaxRange - range.durationMinRange < 5) return `${range.durationMaxRange} min`;
  return `${range.durationMinRange}–${range.durationMaxRange} min`;
}
