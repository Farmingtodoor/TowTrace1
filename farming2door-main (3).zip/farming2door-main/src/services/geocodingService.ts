/**
 * Geocoding service using free Zippopotam.us API for ZIP code resolution
 * and Haversine formula for distance calculation.
 */

interface GeocodedLocation {
  latitude: number;
  longitude: number;
  city: string;
  state: string;
  success: boolean;
  error?: string;
}

interface DistanceResult {
  distanceMiles: number;
  durationMinutes: number;
  origin: GeocodedLocation;
  destination: GeocodedLocation;
  success: boolean;
  error?: string;
}

// Cache geocoded results to avoid repeat API calls
const geocodeCache = new Map<string, GeocodedLocation>();

/**
 * Extract ZIP code from an address string
 */
function extractZipCode(address: string): string | null {
  const match = address.match(/\b(\d{5})(?:-\d{4})?\b/);
  return match ? match[1] : null;
}

/**
 * Geocode a US ZIP code using Zippopotam.us (free, no API key needed)
 */
export async function geocodeZipCode(zipCode: string): Promise<GeocodedLocation> {
  const normalized = zipCode.replace(/\D/g, '').slice(0, 5);
  
  if (normalized.length !== 5) {
    return { latitude: 0, longitude: 0, city: '', state: '', success: false, error: 'Invalid ZIP code' };
  }

  // Check cache
  if (geocodeCache.has(normalized)) {
    return geocodeCache.get(normalized)!;
  }

  try {
    const response = await fetch(`https://api.zippopotam.us/us/${normalized}`);
    if (!response.ok) {
      return { latitude: 0, longitude: 0, city: '', state: '', success: false, error: 'ZIP code not found' };
    }

    const data = await response.json();
    const place = data.places[0];
    const result: GeocodedLocation = {
      latitude: parseFloat(place.latitude),
      longitude: parseFloat(place.longitude),
      city: place['place name'],
      state: place['state abbreviation'],
      success: true,
    };

    geocodeCache.set(normalized, result);
    return result;
  } catch (error) {
    return { latitude: 0, longitude: 0, city: '', state: '', success: false, error: 'Geocoding service unavailable' };
  }
}

/**
 * Geocode an address by extracting its ZIP code
 */
export async function geocodeAddress(address: string): Promise<GeocodedLocation> {
  const zip = extractZipCode(address);
  if (!zip) {
    return { latitude: 0, longitude: 0, city: '', state: '', success: false, error: 'No ZIP code found in address' };
  }
  return geocodeZipCode(zip);
}

/**
 * Calculate distance between two coordinates using Haversine formula
 */
export function haversineDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 3959; // Earth's radius in miles
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * Estimate driving duration from straight-line distance
 * Applies a 1.3x road-winding factor and assumes 30 mph average
 */
export function estimateDrivingMinutes(straightLineMiles: number): number {
  const roadMiles = straightLineMiles * 1.3;
  return Math.round((roadMiles / 30) * 60);
}

/**
 * Calculate distance between two ZIP codes
 */
export async function calculateDistanceBetweenZips(fromZip: string, toZip: string): Promise<DistanceResult> {
  const [origin, destination] = await Promise.all([
    geocodeZipCode(fromZip),
    geocodeZipCode(toZip),
  ]);

  if (!origin.success) {
    return { distanceMiles: 0, durationMinutes: 0, origin, destination, success: false, error: `Origin: ${origin.error}` };
  }
  if (!destination.success) {
    return { distanceMiles: 0, durationMinutes: 0, origin, destination, success: false, error: `Destination: ${destination.error}` };
  }

  const miles = haversineDistance(origin.latitude, origin.longitude, destination.latitude, destination.longitude);
  const minutes = estimateDrivingMinutes(miles);

  return {
    distanceMiles: Math.round(miles * 10) / 10,
    durationMinutes: minutes,
    origin,
    destination,
    success: true,
  };
}

/**
 * Calculate distance from coordinates to a ZIP code
 */
export async function calculateDistanceFromCoords(
  lat: number, lng: number,
  toZip: string
): Promise<{ distanceMiles: number; durationMinutes: number; success: boolean; error?: string }> {
  const destination = await geocodeZipCode(toZip);
  if (!destination.success) {
    return { distanceMiles: 0, durationMinutes: 0, success: false, error: destination.error };
  }

  const miles = haversineDistance(lat, lng, destination.latitude, destination.longitude);
  return {
    distanceMiles: Math.round(miles * 10) / 10,
    durationMinutes: estimateDrivingMinutes(miles),
    success: true,
  };
}

export type { GeocodedLocation, DistanceResult };
