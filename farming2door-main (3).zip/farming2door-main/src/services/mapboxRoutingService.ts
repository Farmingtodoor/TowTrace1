/**
 * Mapbox Directions API service for real driving routes.
 * Returns route geometry, distance (miles), and duration (minutes).
 *
 * Performance features:
 *  - TTL cache (default 60s) so repeated polls reuse recent routes
 *  - In-flight request deduplication so concurrent callers share one fetch
 *  - LRU eviction with a hard cap to bound memory
 *  - Per-key throttle window that returns the last cached value instead of
 *    issuing a new request when called too frequently
 *  - Coordinate rounding (~11m precision) so tiny GPS jitter still hits cache
 */

const MAPBOX_TOKEN = 'pk.eyJ1IjoiZmFybWluMmRvb3IiLCJhIjoiY21mZWNvdXVyMDVjczJpb2dueDcwaGhudSJ9.oeIZtg-WQnD382BjP8Swqw';

export interface RouteResult {
  success: boolean;
  geometry?: GeoJSON.LineString;
  distanceMiles: number;
  durationMinutes: number;
  error?: string;
}

interface CacheEntry {
  result: RouteResult;
  expiresAt: number;
  lastFetchedAt: number;
}

// Tunables
const CACHE_TTL_MS = 60_000;        // route considered fresh for 60s
const THROTTLE_MS = 15_000;         // min interval between real fetches per key
const MAX_CACHE_ENTRIES = 200;      // LRU cap
const COORD_PRECISION = 4;          // ~11m — absorbs GPS jitter

const routeCache = new Map<string, CacheEntry>();
const inFlight = new Map<string, Promise<RouteResult>>();

function roundCoord(n: number): string {
  return n.toFixed(COORD_PRECISION);
}

function buildKey(stops: Array<{ lat: number; lng: number }>): string {
  return stops.map(s => `${roundCoord(s.lat)},${roundCoord(s.lng)}`).join('|');
}

function readCache(key: string): CacheEntry | undefined {
  const entry = routeCache.get(key);
  if (!entry) return undefined;
  // Refresh LRU position
  routeCache.delete(key);
  routeCache.set(key, entry);
  return entry;
}

function writeCache(key: string, result: RouteResult): void {
  if (!result.success) return; // never cache failures
  const now = Date.now();
  routeCache.set(key, {
    result,
    expiresAt: now + CACHE_TTL_MS,
    lastFetchedAt: now,
  });
  // LRU eviction
  while (routeCache.size > MAX_CACHE_ENTRIES) {
    const oldest = routeCache.keys().next().value;
    if (oldest === undefined) break;
    routeCache.delete(oldest);
  }
}

async function fetchRoute(
  key: string,
  coordPath: string
): Promise<RouteResult> {
  const existing = inFlight.get(key);
  if (existing) return existing;

  const promise = (async (): Promise<RouteResult> => {
    try {
      const url = `https://api.mapbox.com/directions/v5/mapbox/driving-traffic/${coordPath}?geometries=geojson&overview=full&access_token=${MAPBOX_TOKEN}`;
      const response = await fetch(url);
      if (!response.ok) {
        return { success: false, distanceMiles: 0, durationMinutes: 0, error: 'Routing service unavailable' };
      }
      const data = await response.json();
      if (!data.routes || data.routes.length === 0) {
        return { success: false, distanceMiles: 0, durationMinutes: 0, error: 'No route found' };
      }
      const route = data.routes[0];
      const result: RouteResult = {
        success: true,
        geometry: route.geometry,
        distanceMiles: Math.round((route.distance / 1609.34) * 10) / 10,
        durationMinutes: Math.round(route.duration / 60),
      };
      writeCache(key, result);
      return result;
    } catch {
      return { success: false, distanceMiles: 0, durationMinutes: 0, error: 'Network error' };
    } finally {
      inFlight.delete(key);
    }
  })();

  inFlight.set(key, promise);
  return promise;
}

export interface RouteOptions {
  /** Bypass TTL cache and throttle to force a fresh Mapbox fetch. */
  force?: boolean;
}

/**
 * Get a real driving route between two coordinates using Mapbox Directions API.
 * Uses TTL cache + throttle + in-flight dedupe to minimize API usage.
 * Pass `{ force: true }` to bypass cache/throttle and force a refresh.
 */
export async function getDrivingRoute(
  from: { lat: number; lng: number },
  to: { lat: number; lng: number },
  options?: RouteOptions
): Promise<RouteResult> {
  return getMultiStopRoute([from, to], options);
}

/**
 * Get a multi-stop driving route (e.g. driver -> pickup -> dropoff).
 */
export async function getMultiStopRoute(
  stops: Array<{ lat: number; lng: number }>,
  options?: RouteOptions
): Promise<RouteResult> {
  if (stops.length < 2) {
    return { success: false, distanceMiles: 0, durationMinutes: 0, error: 'Need at least 2 stops' };
  }

  const key = buildKey(stops);
  const now = Date.now();
  const cached = readCache(key);
  const force = options?.force === true;

  if (force) {
    // Drop cache + any in-flight to guarantee a fresh request
    routeCache.delete(key);
    inFlight.delete(key);
  } else {
    // Fresh cache hit
    if (cached && cached.expiresAt > now) {
      return cached.result;
    }

    // Throttled: return stale cache instead of refetching
    if (cached && now - cached.lastFetchedAt < THROTTLE_MS) {
      return cached.result;
    }
  }

  const coordPath = stops.map(s => `${s.lng},${s.lat}`).join(';');
  const result = await fetchRoute(key, coordPath);

  // If fetch failed but we have stale cache, prefer the stale value
  if (!result.success && cached) {
    return cached.result;
  }
  return result;
}

/**
 * Clear the route cache (useful for tests or forced refresh).
 */
export function clearRouteCache(): void {
  routeCache.clear();
  inFlight.clear();
}

/**
 * Format driving duration as "Xh Ym" or "X min".
 */
export function formatDuration(minutes: number): string {
  if (minutes < 60) return `${minutes} min`;
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
}

/**
 * Format ETA as a clock time, e.g. "3:42 PM".
 */
export function formatETA(minutesFromNow: number): string {
  const eta = new Date(Date.now() + minutesFromNow * 60 * 1000);
  return eta.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
}
