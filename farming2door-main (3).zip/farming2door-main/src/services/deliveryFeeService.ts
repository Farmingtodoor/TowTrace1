/**
 * Industry-standard delivery fee calculation service
 * Based on pricing models from DoorDash, Uber Eats, Lyft, etc.
 * 
 * Formula breakdown:
 * - Base fee: Flat rate to cover fixed costs
 * - Distance fee: Tiered per-mile rate (higher rates for longer distances)
 * - Service fee: Percentage of order subtotal
 * - Small order fee: Applied when order is below minimum threshold
 * - Peak/busy fee: Optional surge pricing during high demand
 */

export interface DeliveryFeeBreakdown {
  baseFee: number;
  distanceFee: number;
  serviceFee: number;
  smallOrderFee: number;
  peakFee: number;
  totalFee: number;
  estimatedDeliveryTime: string;
}

export interface DeliveryFeeOptions {
  distanceMiles: number;
  orderSubtotal: number;
  isPeakHours?: boolean;
  deliveryType?: 'standard' | 'express' | 'scheduled';
}

// Distance tier rates (similar to DoorDash/Uber)
const DISTANCE_TIERS = [
  { maxMiles: 2, perMileRate: 0.50 },    // Short distance: $0.50/mile
  { maxMiles: 5, perMileRate: 0.75 },    // Medium distance: $0.75/mile
  { maxMiles: 10, perMileRate: 1.00 },   // Long distance: $1.00/mile
  { maxMiles: 20, perMileRate: 1.25 },   // Extended distance: $1.25/mile
  { maxMiles: 50, perMileRate: 1.50 },   // Far distance: $1.50/mile
  { maxMiles: Infinity, perMileRate: 2.00 } // Very far: $2.00/mile
];

// Base fees by delivery type
const BASE_FEES = {
  standard: 2.99,
  express: 4.99,
  scheduled: 1.99
};

// Service fee as percentage of order subtotal
const SERVICE_FEE_PERCENTAGE = 0.10; // 10% of subtotal
const MAX_SERVICE_FEE = 5.00; // Cap at $5
const MIN_SERVICE_FEE = 0.50; // Minimum $0.50

// Small order fee thresholds
const SMALL_ORDER_THRESHOLD = 15.00;
const SMALL_ORDER_FEE = 2.00;

// Peak hours surge pricing
const PEAK_HOURS_MULTIPLIER = 1.25;

/**
 * Calculate tiered distance fee based on miles
 * Uses progressive tiers similar to rideshare companies
 */
export function calculateDistanceFee(distanceMiles: number): number {
  if (distanceMiles <= 0) return 0;
  
  let totalFee = 0;
  let remainingDistance = distanceMiles;
  let previousMax = 0;

  for (const tier of DISTANCE_TIERS) {
    const tierDistance = Math.min(remainingDistance, tier.maxMiles - previousMax);
    if (tierDistance <= 0) break;
    
    totalFee += tierDistance * tier.perMileRate;
    remainingDistance -= tierDistance;
    previousMax = tier.maxMiles;
    
    if (remainingDistance <= 0) break;
  }

  return Math.round(totalFee * 100) / 100;
}

/**
 * Calculate service fee based on order subtotal
 * Capped between min and max values
 */
export function calculateServiceFee(orderSubtotal: number): number {
  const fee = orderSubtotal * SERVICE_FEE_PERCENTAGE;
  return Math.round(Math.max(MIN_SERVICE_FEE, Math.min(fee, MAX_SERVICE_FEE)) * 100) / 100;
}

/**
 * Calculate small order fee if order is below threshold
 */
export function calculateSmallOrderFee(orderSubtotal: number): number {
  return orderSubtotal < SMALL_ORDER_THRESHOLD ? SMALL_ORDER_FEE : 0;
}

/**
 * Check if current time is during peak hours
 * Peak hours: 11 AM - 2 PM (lunch) and 5 PM - 9 PM (dinner)
 */
export function isPeakHoursNow(): boolean {
  const hour = new Date().getHours();
  const isLunchPeak = hour >= 11 && hour < 14;
  const isDinnerPeak = hour >= 17 && hour < 21;
  return isLunchPeak || isDinnerPeak;
}

/**
 * Estimate delivery time based on distance
 */
export function estimateDeliveryTime(distanceMiles: number, deliveryType: 'standard' | 'express' | 'scheduled' = 'standard'): string {
  // Base time includes preparation and driver assignment
  const baseMinutes = deliveryType === 'express' ? 10 : 15;
  
  // Assume average speed of 25 mph in urban areas
  const travelMinutes = (distanceMiles / 25) * 60;
  
  const totalMinutes = Math.round(baseMinutes + travelMinutes);
  
  // Add buffer for variability
  const minTime = Math.max(15, totalMinutes - 5);
  const maxTime = totalMinutes + 10;
  
  if (maxTime < 60) {
    return `${minTime}-${maxTime} min`;
  } else {
    const minHours = Math.floor(minTime / 60);
    const maxHours = Math.ceil(maxTime / 60);
    if (minHours === maxHours) {
      return `~${minHours} hr`;
    }
    return `${minHours}-${maxHours} hrs`;
  }
}

/**
 * Calculate complete delivery fee breakdown
 * Uses industry-standard tiered pricing model
 */
export function calculateDeliveryFee(options: DeliveryFeeOptions): DeliveryFeeBreakdown {
  const { 
    distanceMiles, 
    orderSubtotal, 
    isPeakHours = isPeakHoursNow(),
    deliveryType = 'standard' 
  } = options;

  // Calculate individual fee components
  const baseFee = BASE_FEES[deliveryType];
  const distanceFee = calculateDistanceFee(distanceMiles);
  const serviceFee = calculateServiceFee(orderSubtotal);
  const smallOrderFee = calculateSmallOrderFee(orderSubtotal);
  
  // Calculate peak fee (only applies to base + distance)
  const peakFee = isPeakHours 
    ? Math.round((baseFee + distanceFee) * (PEAK_HOURS_MULTIPLIER - 1) * 100) / 100 
    : 0;

  // Calculate total
  const totalFee = Math.round((baseFee + distanceFee + serviceFee + smallOrderFee + peakFee) * 100) / 100;

  return {
    baseFee,
    distanceFee,
    serviceFee,
    smallOrderFee,
    peakFee,
    totalFee,
    estimatedDeliveryTime: estimateDeliveryTime(distanceMiles, deliveryType)
  };
}

/**
 * Get a simple delivery fee for display purposes
 * Used when full breakdown isn't needed
 */
export function getSimpleDeliveryFee(distanceMiles: number, orderSubtotal: number = 50): number {
  const breakdown = calculateDeliveryFee({ distanceMiles, orderSubtotal, isPeakHours: false });
  return breakdown.totalFee;
}

/**
 * Format fee breakdown for display
 */
export function formatFeeBreakdown(breakdown: DeliveryFeeBreakdown): string[] {
  const lines: string[] = [];
  
  lines.push(`Base fee: $${breakdown.baseFee.toFixed(2)}`);
  lines.push(`Distance fee: $${breakdown.distanceFee.toFixed(2)}`);
  lines.push(`Service fee: $${breakdown.serviceFee.toFixed(2)}`);
  
  if (breakdown.smallOrderFee > 0) {
    lines.push(`Small order fee: $${breakdown.smallOrderFee.toFixed(2)}`);
  }
  
  if (breakdown.peakFee > 0) {
    lines.push(`Peak hours fee: $${breakdown.peakFee.toFixed(2)}`);
  }
  
  return lines;
}

export default {
  calculateDeliveryFee,
  calculateDistanceFee,
  calculateServiceFee,
  calculateSmallOrderFee,
  getSimpleDeliveryFee,
  estimateDeliveryTime,
  isPeakHoursNow,
  formatFeeBreakdown,
  DISTANCE_TIERS,
  BASE_FEES,
  SERVICE_FEE_PERCENTAGE,
  SMALL_ORDER_THRESHOLD,
  SMALL_ORDER_FEE
};
