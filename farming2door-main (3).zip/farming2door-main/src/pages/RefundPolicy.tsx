import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SEOHead from "@/components/SEOHead";

const RefundPolicy = () => {
  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title="Refund & Dispute Policy"
        description="Farm2Door Refund and Dispute Policy - Learn about our refund process, quality guarantees, and how we resolve customer disputes."
        keywords="refund policy, dispute resolution, quality guarantee, farm2door returns"
      />
      
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto prose prose-lg">
          <h1 className="text-4xl font-bold text-foreground mb-8">Refund & Dispute Policy</h1>
          
          <p className="text-muted-foreground mb-6">
            <strong>Last updated:</strong> January 2024
          </p>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">1. Our Quality Guarantee</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              We stand behind the quality of products sold through our platform. While we don't directly produce the items, we work with farmers who maintain high standards and share our commitment to customer satisfaction.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              If you receive a product that doesn't meet your expectations, we're here to help resolve the issue fairly and quickly.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">2. Refund Eligibility</h2>
            
            <h3 className="text-lg font-semibold text-foreground mb-3">Full Refund Scenarios</h3>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2 mb-4">
              <li>Products arrive damaged or spoiled</li>
              <li>Missing items from your order</li>
              <li>Products significantly different from description</li>
              <li>Delivery failure due to farmer error</li>
              <li>Food safety concerns or contamination</li>
            </ul>

            <h3 className="text-lg font-semibold text-foreground mb-3">Partial Refund or Store Credit</h3>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2 mb-4">
              <li>Minor quality issues that don't affect safety</li>
              <li>Slight variations in product appearance</li>
              <li>Delivery delays beyond reasonable expectations</li>
            </ul>

            <h3 className="text-lg font-semibold text-foreground mb-3">No Refund Situations</h3>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Customer unavailable for scheduled delivery</li>
              <li>Product preference or taste dissatisfaction</li>
              <li>Normal variations in fresh, natural products</li>
              <li>Damage occurring after proper delivery</li>
              <li>Custom processed orders (special circumstances apply)</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibent text-foreground mb-4">3. Refund Process</h2>
            
            <h3 className="text-lg font-semibold text-foreground mb-3">Step 1: Report the Issue</h3>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Contact us within <strong>24 hours of delivery</strong> for perishable items, or within <strong>3 days</strong> for non-perishable items:
            </p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2 mb-4">
              <li>Email: support@farm2door.com</li>
              <li>Phone: (555) 123-4567</li>
              <li>Through your account dashboard</li>
            </ul>

            <h3 className="text-lg font-semibold text-foreground mb-3">Step 2: Provide Documentation</h3>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2 mb-4">
              <li>Clear photos of the issue</li>
              <li>Order number and delivery details</li>
              <li>Description of the problem</li>
            </ul>

            <h3 className="text-lg font-semibold text-foreground mb-3">Step 3: Resolution</h3>
            <p className="text-muted-foreground leading-relaxed mb-4">
              We typically respond within 24 hours and aim to resolve issues within 2-3 business days. Refunds are processed to the original payment method within 5-7 business days.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">4. Custom Orders & Processing</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Custom processed orders (such as specific meat cuts or bulk purchases) have special considerations:
            </p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2 mb-4">
              <li>Orders can typically be cancelled within 24 hours of placement</li>
              <li>Once processing begins, cancellations may incur fees</li>
              <li>Refunds for processing errors are handled case-by-case</li>
              <li>Customer processing preferences must be clearly specified</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">5. Dispute Resolution</h2>
            
            <h3 className="text-lg font-semibold text-foreground mb-3">Direct Resolution</h3>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Most issues are resolved directly between our customer service team, the customer, and the farmer. We facilitate communication and work toward fair solutions.
            </p>

            <h3 className="text-lg font-semibold text-foreground mb-3">Escalation Process</h3>
            <p className="text-muted-foreground leading-relaxed mb-4">
              If initial resolution attempts fail:
            </p>
            <ol className="list-decimal pl-6 text-muted-foreground space-y-2 mb-4">
              <li>Request escalation to our Customer Experience Manager</li>
              <li>Comprehensive review of the case with all parties</li>
              <li>Final decision based on our policies and fairness principles</li>
              <li>External mediation for unresolved disputes (rare cases)</li>
            </ol>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">6. Prevention Tips</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              To minimize issues and ensure the best experience:
            </p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Read product descriptions carefully before ordering</li>
              <li>Be available for scheduled deliveries</li>
              <li>Inspect products immediately upon delivery</li>
              <li>Store products properly according to instructions</li>
              <li>Communicate special requests clearly when ordering</li>
              <li>Contact farmers directly for questions about their products</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">7. Platform Fees</h2>
            <p className="text-muted-foreground leading-relaxed">
              Platform service fees are generally non-refundable unless the refund is due to our error or system failure. Processing fees for payment transactions may also be non-refundable depending on the payment processor's policies.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">8. Contact Information</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              For refund requests or dispute resolution, contact us at:
            </p>
            <div className="bg-muted/50 p-4 rounded-lg">
              <p className="text-muted-foreground">
                <strong>Customer Support:</strong> support@farm2door.com<br/>
                <strong>Phone:</strong> (555) 123-4567<br/>
                <strong>Hours:</strong> Monday-Friday 8AM-6PM, Saturday 9AM-4PM<br/>
                <strong>Emergency (food safety):</strong> (555) 123-SAFE
              </p>
            </div>
          </section>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default RefundPolicy;