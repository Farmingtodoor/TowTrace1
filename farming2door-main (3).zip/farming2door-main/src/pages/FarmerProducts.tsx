import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { Plus, Edit, Trash2, Package, Upload, Play, Image as ImageIcon, Calendar } from "lucide-react";
import Header from "@/components/Header";
import MediaUpload from "@/components/MediaUpload";
import ProfileCompletenessCard from "@/components/farmer/ProfileCompletenessCard";


interface MediaFile {
  url: string;
  type: 'image' | 'video';
  name: string;
}

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  subcategory?: string;
  farmer: string;
  farmer_id: string;
  image_url?: string;
  images?: MediaFile[];
  videos?: MediaFile[];
  unit: string;
  stock_quantity: number;
  is_available: boolean;
  is_organic: boolean;
  harvest_date?: string;
  expiration_date?: string;
  portion_options?: string[];
  freshness_type?: 'fresh' | 'frozen';
  created_at: string;
  updated_at: string;
}

export default function FarmerProducts() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [subcategories, setSubcategories] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [uploading, setUploading] = useState(false);
  const [nextHarvestDate, setNextHarvestDate] = useState<string>("");
  const [updatingHarvest, setUpdatingHarvest] = useState(false);
  
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    category: "",
    subcategory: "",
    unit: "lb",
    stock_quantity: "",
    is_available: true,
    is_organic: false,
    harvest_date: "",
    expiration_date: "",
    image_url: "",
    images: [] as MediaFile[],
    videos: [] as MediaFile[],
    portion_options: [] as string[],
    freshness_type: "fresh" as 'fresh' | 'frozen',
  });

  useEffect(() => {
    if (user) {
      fetchProducts();
      fetchCategories();
      fetchSubcategories();
      fetchNextHarvestDate();
    }
  }, [user]);

  // Helper function to determine if category is produce-related
  const isProduceCategory = (category: string): boolean => {
    const produceCategories = ['fruits', 'vegetables', 'produce', 'herbs', 'greens', 'berries'];
    return produceCategories.includes(category.toLowerCase());
  };

  const fetchNextHarvestDate = async () => {
    try {
      const { data, error } = await supabase
        .from('farmer_applications')
        .select('next_harvest_date')
        .eq('user_id', user?.id)
        .maybeSingle();

      if (error) throw error;
      if (data?.next_harvest_date) {
        setNextHarvestDate(data.next_harvest_date);
      }
    } catch (error) {
      console.error('Error fetching harvest date:', error);
    }
  };

  const updateNextHarvestDate = async () => {
    if (!user) return;

    try {
      setUpdatingHarvest(true);
      const { error } = await supabase
        .from('farmer_applications')
        .update({ next_harvest_date: nextHarvestDate || null })
        .eq('user_id', user.id);

      if (error) throw error;

      toast({
        title: "Success",
        description: nextHarvestDate 
          ? "Your next harvest date has been updated!"
          : "Your harvest date has been cleared.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update harvest date. Please try again.",
        variant: "destructive",
      });
    } finally {
      setUpdatingHarvest(false);
    }
  };

  const fetchProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('farmer_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      // Parse images, videos, and portion_options from JSON
      const productsWithMedia = (data || []).map(product => ({
        ...product,
        images: Array.isArray(product.images) ? (product.images as unknown as MediaFile[]) : [],
        videos: Array.isArray(product.videos) ? (product.videos as unknown as MediaFile[]) : [],
        portion_options: Array.isArray(product.portion_options) 
          ? (product.portion_options as unknown as string[]).filter((p): p is string => typeof p === 'string')
          : product.portion_options 
            ? [String(product.portion_options)]
            : ["whole"],
        freshness_type: product.freshness_type as 'fresh' | 'frozen' | undefined
      }));
      
      setProducts(productsWithMedia);
    } catch (error) {
      console.error('Error fetching products:', error);
      toast({
        title: "Error",
        description: "Failed to load products",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .eq('is_active', true)
        .order('display_order');

      if (error) throw error;
      setCategories(data || []);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const fetchSubcategories = async () => {
    try {
      const { data, error } = await supabase
        .from('subcategories')
        .select('*')
        .eq('is_active', true)
        .order('display_order');

      if (error) throw error;
      setSubcategories(data || []);
    } catch (error) {
      console.error('Error fetching subcategories:', error);
    }
  };

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !user) return;

    setUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}/${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('product-images')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('product-images')
        .getPublicUrl(fileName);

      setFormData(prev => ({ ...prev, image_url: publicUrl }));
      
      toast({
        title: "Image uploaded",
        description: "Product image uploaded successfully",
      });
    } catch (error: any) {
      console.error('Error uploading image:', error);
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    try {
      const productData = {
        name: formData.name,
        description: formData.description,
        price: parseFloat(formData.price),
        category: formData.category,
        subcategory: formData.subcategory || null,
        farmer: user.email || 'Unknown Farmer',
        farmer_id: user.id,
        image_url: formData.image_url,
        images: JSON.parse(JSON.stringify(formData.images)), // Convert to plain JSON
        videos: JSON.parse(JSON.stringify(formData.videos)), // Convert to plain JSON
        unit: formData.unit,
        stock_quantity: parseInt(formData.stock_quantity),
        is_available: formData.is_available,
        is_organic: formData.is_organic,
        harvest_date: formData.harvest_date || null,
        expiration_date: formData.expiration_date || null,
        portion_options: formData.portion_options.length > 0 ? formData.portion_options : ["whole"],
        freshness_type: isProduceCategory(formData.category) ? formData.freshness_type : null,
      };

      let error;
      if (editingProduct) {
        const result = await supabase
          .from('products')
          .update(productData)
          .eq('id', editingProduct.id);
        error = result.error;
      } else {
        const result = await supabase
          .from('products')
          .insert([productData]);
        error = result.error;
      }

      if (error) throw error;

      toast({
        title: editingProduct ? "Product updated" : "Product added",
        description: `${formData.name} has been ${editingProduct ? 'updated' : 'added'} successfully`,
      });

      setDialogOpen(false);
      resetForm();
      fetchProducts();
    } catch (error: any) {
      console.error('Error saving product:', error);
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleEdit = (product: Product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      description: product.description || "",
      price: product.price.toString(),
      category: product.category,
      subcategory: product.subcategory || "",
      unit: product.unit,
      stock_quantity: product.stock_quantity.toString(),
      is_available: product.is_available,
      is_organic: product.is_organic,
      harvest_date: product.harvest_date || "",
      expiration_date: product.expiration_date || "",
      image_url: product.image_url || "",
      images: product.images || [],
      videos: product.videos || [],
      portion_options: product.portion_options || [],
      freshness_type: product.freshness_type || "fresh",
    });
    setDialogOpen(true);
  };

  const handleDelete = async (productId: string) => {
    if (!confirm('Are you sure you want to delete this product?')) return;

    try {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', productId);

      if (error) throw error;

      toast({
        title: "Product deleted",
        description: "Product has been deleted successfully",
      });

      fetchProducts();
    } catch (error: any) {
      console.error('Error deleting product:', error);
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      price: "",
      category: "",
      subcategory: "",
      unit: "lb",
      stock_quantity: "",
      is_available: true,
      is_organic: false,
      harvest_date: "",
      expiration_date: "",
      image_url: "",
      images: [],
      videos: [],
      portion_options: [],
      freshness_type: "fresh",
    });
    setEditingProduct(null);
  };

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Reset subcategory when category changes
    if (field === 'category' && value !== 'Livestock') {
      setFormData(prev => ({ ...prev, subcategory: "" }));
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-16 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-16">
        <div className="mb-8">
          <ProfileCompletenessCard />
        </div>

        {/* Next Harvest Date Section */}

        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-green-600" />
              Next Harvest Date
            </CardTitle>
            <CardDescription>
              Let customers know when your next harvest will be ready. This helps them plan custom orders or know when to visit the marketplace.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 items-end">
              <div className="flex-1 max-w-xs">
                <Label htmlFor="next_harvest_date">Harvest Date (Optional)</Label>
                <Input
                  id="next_harvest_date"
                  type="date"
                  value={nextHarvestDate}
                  onChange={(e) => setNextHarvestDate(e.target.value)}
                  className="mt-1"
                />
              </div>
              <Button 
                onClick={updateNextHarvestDate}
                disabled={updatingHarvest}
              >
                {updatingHarvest ? "Updating..." : "Update"}
              </Button>
              {nextHarvestDate && (
                <Button 
                  variant="outline"
                  onClick={() => {
                    setNextHarvestDate("");
                    updateNextHarvestDate();
                  }}
                  disabled={updatingHarvest}
                >
                  Clear
                </Button>
              )}
            </div>
            {nextHarvestDate && (
              <div className="mt-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                <p className="text-sm text-green-800">
                  🌱 Your next harvest is scheduled for{' '}
                  <strong>
                    {new Date(nextHarvestDate).toLocaleDateString('en-US', { 
                      weekday: 'long', 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}
                  </strong>. 
                  This will be displayed on your farmer profile to help customers plan their orders.
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">My Products</h1>
            <p className="text-muted-foreground">
              Manage your product listings and inventory
            </p>
          </div>
          
          <Dialog open={dialogOpen} onOpenChange={(open) => {
            setDialogOpen(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Add Product
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingProduct ? 'Edit Product' : 'Add New Product'}
                </DialogTitle>
                <DialogDescription>
                  {editingProduct ? 'Update your product details' : 'Add a new product to your listings'}
                </DialogDescription>
              </DialogHeader>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Product Name *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => handleInputChange("name", e.target.value)}
                      placeholder="Fresh Organic Tomatoes"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category">Category *</Label>
                    <Select value={formData.category} onValueChange={(value) => {
                      handleInputChange("category", value);
                      // Reset subcategory when category changes
                      handleInputChange("subcategory", "");
                    }}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category.id} value={category.name}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Subcategory selection for Livestock */}
                {formData.category.toLowerCase() === 'livestock' && (
                  <div className="space-y-2">
                    <Label htmlFor="subcategory">Livestock Type *</Label>
                    <Select value={formData.subcategory} onValueChange={(value) => handleInputChange("subcategory", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select livestock type" />
                      </SelectTrigger>
                      <SelectContent>
                        {subcategories
                          .filter(sub => {
                            const livestockCategory = categories.find(cat => cat.name.toLowerCase() === 'livestock');
                            return livestockCategory && sub.category_id === livestockCategory.id;
                          })
                          .map((subcategory) => (
                            <SelectItem key={subcategory.id} value={subcategory.name}>
                              {subcategory.name}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => handleInputChange("description", e.target.value)}
                    placeholder="Describe your product, growing methods, taste, etc."
                    rows={3}
                  />
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="price">Price ($) *</Label>
                    <Input
                      id="price"
                      type="number"
                      step="0.01"
                      value={formData.price}
                      onChange={(e) => handleInputChange("price", e.target.value)}
                      placeholder="5.99"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="unit">Unit {formData.category.toLowerCase() !== 'livestock' ? '*' : ''}</Label>
                    <Select value={formData.unit} onValueChange={(value) => handleInputChange("unit", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder={formData.category.toLowerCase() === 'livestock' ? "Select unit (optional)" : "Select unit"} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="lb">per lb</SelectItem>
                        <SelectItem value="oz">per oz</SelectItem>
                        <SelectItem value="piece">per piece</SelectItem>
                        <SelectItem value="bunch">per bunch</SelectItem>
                        <SelectItem value="dozen">per dozen</SelectItem>
                        <SelectItem value="pint">per pint</SelectItem>
                        <SelectItem value="quart">per quart</SelectItem>
                        <SelectItem value="bag">per bag</SelectItem>
                        <SelectItem value="head">per head</SelectItem>
                        <SelectItem value="animal">per animal</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="stock_quantity">Stock Quantity</Label>
                    <Input
                      id="stock_quantity"
                      type="number"
                      value={formData.stock_quantity}
                      onChange={(e) => handleInputChange("stock_quantity", e.target.value)}
                      placeholder="100"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="harvest_date">Harvest Date</Label>
                    <Input
                      id="harvest_date"
                      type="date"
                      value={formData.harvest_date}
                      onChange={(e) => handleInputChange("harvest_date", e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="expiration_date">Best By Date</Label>
                    <Input
                      id="expiration_date"
                      type="date"
                      value={formData.expiration_date}
                      onChange={(e) => handleInputChange("expiration_date", e.target.value)}
                    />
                  </div>
                </div>

                {/* Freshness Type for Produce */}
                {isProduceCategory(formData.category) && (
                  <div className="space-y-2">
                    <Label htmlFor="freshness_type">Freshness Type *</Label>
                    <Select value={formData.freshness_type} onValueChange={(value) => handleInputChange("freshness_type", value as 'fresh' | 'frozen')}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select freshness type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="fresh">Fresh</SelectItem>
                        <SelectItem value="frozen">Frozen</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-sm text-muted-foreground">
                      Specify whether this produce is fresh or frozen
                    </p>
                  </div>
                )}

                <div className="space-y-2">
                  <MediaUpload
                    images={formData.images}
                    videos={formData.videos}
                    onImagesChange={(images) => handleInputChange("images", images)}
                    onVideosChange={(videos) => handleInputChange("videos", videos)}
                    userId={user?.id || ''}
                  />
                </div>

                {/* Livestock Portion Options */}
                {formData.category.toLowerCase() === 'livestock' && (
                  <div className="space-y-2">
                    <Label>Available Portions</Label>
                    <div className="flex flex-wrap gap-3">
                      {['Full', 'Half', 'Quarter'].map((portion) => (
                        <div key={portion} className="flex items-center space-x-2">
                          <Checkbox
                            id={`portion_${portion.toLowerCase()}`}
                            checked={formData.portion_options.includes(portion)}
                            onCheckedChange={(checked) => {
                              if (checked) {
                                handleInputChange("portion_options", [...formData.portion_options, portion]);
                              } else {
                                handleInputChange("portion_options", formData.portion_options.filter(p => p !== portion));
                              }
                            }}
                          />
                          <Label htmlFor={`portion_${portion.toLowerCase()}`}>{portion}</Label>
                        </div>
                      ))}
                      <div className="flex items-center space-x-2 ml-4">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            const allPortions = ['Full', 'Half', 'Quarter'];
                            const allSelected = allPortions.every(p => formData.portion_options.includes(p));
                            if (allSelected) {
                              handleInputChange("portion_options", []);
                            } else {
                              handleInputChange("portion_options", allPortions);
                            }
                          }}
                        >
                          {['Full', 'Half', 'Quarter'].every(p => formData.portion_options.includes(p)) ? 'Deselect All' : 'Select All'}
                        </Button>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Select which portions you can provide to customers (e.g., full animal, half, quarter)
                    </p>
                  </div>
                )}

                <div className="flex gap-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="is_available"
                      checked={formData.is_available}
                      onCheckedChange={(checked) => handleInputChange("is_available", checked)}
                    />
                    <Label htmlFor="is_available">Available for sale</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="is_organic"
                      checked={formData.is_organic}
                      onCheckedChange={(checked) => handleInputChange("is_organic", checked)}
                    />
                    <Label htmlFor="is_organic">Organic certified</Label>
                  </div>
                </div>

                <div className="flex gap-2 pt-4">
                  <Button type="submit" className="flex-1">
                    {editingProduct ? 'Update Product' : 'Add Product'}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {products.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <Package className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No products yet</h3>
              <p className="text-muted-foreground mb-4">
                Start selling by adding your first product
              </p>
              <Button onClick={() => setDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Product
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product) => (
              <Card key={product.id} className="overflow-hidden">
                <CardHeader className="pb-3">
                  {/* Display first image or fallback to legacy image_url */}
                  {(product.images && product.images.length > 0) ? (
                    <div className="w-full h-48 mb-3 relative">
                      <img
                        src={product.images[0].url}
                        alt={product.name}
                        className="w-full h-full object-cover rounded-lg"
                      />
                      {product.images.length > 1 && (
                        <div className="absolute top-2 right-2 bg-black/70 text-white px-2 py-1 rounded-full text-xs flex items-center gap-1">
                          <ImageIcon className="h-3 w-3" />
                          +{product.images.length - 1}
                        </div>
                      )}
                      {product.videos && product.videos.length > 0 && (
                        <div className="absolute top-2 left-2 bg-black/70 text-white px-2 py-1 rounded-full text-xs flex items-center gap-1">
                          <Play className="h-3 w-3" />
                          {product.videos.length}
                        </div>
                      )}
                    </div>
                  ) : product.image_url ? (
                    <div className="w-full h-48 mb-3">
                      <img
                        src={product.image_url}
                        alt={product.name}
                        className="w-full h-full object-cover rounded-lg"
                      />
                    </div>
                  ) : null}
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <CardTitle className="text-lg">{product.name}</CardTitle>
                      <CardDescription className="mt-1">
                        {product.category}
                        {product.subcategory && (
                          <span className="text-muted-foreground"> • {product.subcategory}</span>
                        )}
                      </CardDescription>
                    </div>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEdit(product)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDelete(product.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-bold text-primary">
                        ${product.price.toFixed(2)}
                      </span>
                      <span className="text-sm text-muted-foreground">
                        {product.unit}
                      </span>
                    </div>
                    
                    <div className="flex gap-2 flex-wrap">
                      <Badge variant={product.is_available ? "default" : "secondary"}>
                        {product.is_available ? "Available" : "Unavailable"}
                      </Badge>
                      {product.is_organic && (
                        <Badge variant="outline">Organic</Badge>
                      )}
                      {product.freshness_type && isProduceCategory(product.category) && (
                        <Badge variant="outline" className="capitalize">
                          {product.freshness_type}
                        </Badge>
                      )}
                      {product.portion_options && product.portion_options.length > 0 && 
                       product.category.toLowerCase() === 'livestock' && (
                        <div className="flex gap-1 flex-wrap">
                          {product.portion_options.filter(p => p !== 'whole').map((portion) => (
                            <Badge key={portion} variant="outline" className="text-xs">
                              {portion}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>

                    {product.description && (
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {product.description}
                      </p>
                    )}

                    <div className="text-xs text-muted-foreground">
                      Stock: {product.stock_quantity} {product.unit}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}