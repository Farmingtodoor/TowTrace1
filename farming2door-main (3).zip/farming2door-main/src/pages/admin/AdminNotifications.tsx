import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Bell, 
  Send, 
  Users, 
  Mail, 
  AlertCircle, 
  CheckCircle,
  Clock,
  Package,
  Truck,
  MapPin,
  Search,
  Filter
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAdmin } from "@/contexts/AdminContext";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";

interface Notification {
  id: string;
  user_id: string;
  type: string;
  title: string;
  message: string;
  read: boolean;
  sent_email: boolean;
  created_at: string;
  order_id?: string;
  profiles?: {
    full_name: string;
    email: string;
  };
}

interface NotificationStats {
  total: number;
  unread: number;
  today: number;
  emailsSent: number;
}

export default function AdminNotifications() {
  const { isAdmin, isSuperAdmin } = useAdmin();
  const { toast } = useToast();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [stats, setStats] = useState<NotificationStats>({
    total: 0,
    unread: 0,
    today: 0,
    emailsSent: 0
  });
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [filterRead, setFilterRead] = useState("all");

  // Send notification form state
  const [sendForm, setSendForm] = useState({
    userType: "all",
    title: "",
    message: "",
    type: "announcement"
  });

  // Access control
  if (!isAdmin && !isSuperAdmin) {
    return (
      <div className="p-8 text-center">
        <AlertCircle className="mx-auto h-12 w-12 text-destructive mb-4" />
        <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
        <p className="text-muted-foreground">
          You don't have permission to access notifications management.
        </p>
      </div>
    );
  }

  useEffect(() => {
    fetchNotifications();
    fetchStats();
  }, []);

  const fetchNotifications = async () => {
    try {
      const { data, error } = await supabase
        .from('notifications')
        .select(`
          *,
          profiles (
            full_name,
            email
          )
        `)
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) throw error;
      setNotifications(data || []);
    } catch (error) {
      console.error('Error fetching notifications:', error);
      toast({
        title: "Error",
        description: "Failed to load notifications",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const today = new Date().toISOString().split('T')[0];
      
      const { data: allNotifications, error } = await supabase
        .from('notifications')
        .select('read, sent_email, created_at');

      if (error) throw error;

      const todayNotifications = allNotifications?.filter(n => 
        n.created_at.startsWith(today)
      ) || [];

      setStats({
        total: allNotifications?.length || 0,
        unread: allNotifications?.filter(n => !n.read).length || 0,
        today: todayNotifications.length,
        emailsSent: allNotifications?.filter(n => n.sent_email).length || 0
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const sendBulkNotification = async () => {
    if (!sendForm.title || !sendForm.message) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    try {
      // Get target users based on userType
      let userQuery = supabase.from('profiles').select('id, email, full_name');
      
      if (sendForm.userType !== 'all') {
        userQuery = userQuery.eq('user_type', sendForm.userType);
      }

      const { data: users, error: userError } = await userQuery;
      if (userError) throw userError;

      // Create notifications for each user
      const notificationsToInsert = users?.map(user => ({
        user_id: user.id,
        type: sendForm.type,
        title: sendForm.title,
        message: sendForm.message,
        read: false,
        sent_email: false
      })) || [];

      const { error: insertError } = await supabase
        .from('notifications')
        .insert(notificationsToInsert);

      if (insertError) throw insertError;

      toast({
        title: "Success",
        description: `Sent ${notificationsToInsert.length} notifications successfully`
      });

      // Reset form
      setSendForm({
        userType: "all",
        title: "",
        message: "",
        type: "announcement"
      });

      // Refresh data
      fetchNotifications();
      fetchStats();
    } catch (error) {
      console.error('Error sending notifications:', error);
      const errorMessage = error instanceof Error ? error.message : 'Failed to send notifications';
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive"
      });
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'order_placed':
      case 'order_confirmed':
      case 'order_processing':
        return <Package className="h-4 w-4" />;
      case 'order_ready':
        return <MapPin className="h-4 w-4" />;
      case 'order_out_for_delivery':
        return <Truck className="h-4 w-4" />;
      case 'order_delivered':
        return <CheckCircle className="h-4 w-4" />;
      case 'announcement':
        return <Bell className="h-4 w-4" />;
      case 'farmer_application':
      case 'application_approved':
        return <Users className="h-4 w-4" />;
      default:
        return <Bell className="h-4 w-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'order_placed':
      case 'order_confirmed':
      case 'order_processing':
        return 'bg-blue-100 text-blue-800';
      case 'order_ready':
      case 'order_delivered':
        return 'bg-green-100 text-green-800';
      case 'order_out_for_delivery':
        return 'bg-orange-100 text-orange-800';
      case 'announcement':
        return 'bg-purple-100 text-purple-800';
      case 'farmer_application':
      case 'application_approved':
        return 'bg-indigo-100 text-indigo-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Filter notifications
  const filteredNotifications = notifications.filter(notification => {
    if (searchTerm && !notification.title.toLowerCase().includes(searchTerm.toLowerCase()) &&
        !notification.message.toLowerCase().includes(searchTerm.toLowerCase()) &&
        !notification.profiles?.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) &&
        !notification.profiles?.email?.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }
    
    if (filterType !== 'all' && notification.type !== filterType) {
      return false;
    }
    
    if (filterRead === 'read' && !notification.read) return false;
    if (filterRead === 'unread' && notification.read) return false;
    
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Notifications Management</h1>
          <p className="text-muted-foreground">
            Manage and send notifications to users
          </p>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Notifications</CardTitle>
            <Bell className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Unread</CardTitle>
            <AlertCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{stats.unread}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Sent Today</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.today}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Emails Sent</CardTitle>
            <Mail className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.emailsSent}</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">All Notifications</TabsTrigger>
          <TabsTrigger value="send">Send Notification</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle>Filter Notifications</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4 items-end">
                <div className="flex-1">
                  <Label htmlFor="search">Search</Label>
                  <div className="relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="search"
                      placeholder="Search notifications..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-8"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="type">Type</Label>
                  <Select value={filterType} onValueChange={setFilterType}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="order_placed">Order Placed</SelectItem>
                      <SelectItem value="order_confirmed">Order Confirmed</SelectItem>
                      <SelectItem value="order_delivered">Order Delivered</SelectItem>
                      <SelectItem value="announcement">Announcement</SelectItem>
                      <SelectItem value="farmer_application">Farmer Application</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="read">Status</Label>
                  <Select value={filterRead} onValueChange={setFilterRead}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All</SelectItem>
                      <SelectItem value="read">Read</SelectItem>
                      <SelectItem value="unread">Unread</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Notifications List */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Notifications</CardTitle>
              <CardDescription>
                {filteredNotifications.length} notifications found
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                {loading ? (
                  <div className="flex items-center justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  </div>
                ) : filteredNotifications.length === 0 ? (
                  <div className="text-center py-8">
                    <Bell className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">No notifications found</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {filteredNotifications.map((notification) => (
                      <div
                        key={notification.id}
                        className={`flex items-start gap-4 p-4 rounded-lg border ${
                          !notification.read ? 'bg-primary/5 border-primary/20' : 'border-border'
                        }`}
                      >
                        <div className="mt-0.5">
                          {getNotificationIcon(notification.type)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <h4 className="text-sm font-medium truncate">
                              {notification.title}
                            </h4>
                            <div className="flex items-center gap-2">
                              <Badge 
                                variant="secondary" 
                                className={getTypeColor(notification.type)}
                              >
                                {notification.type.replace('_', ' ')}
                              </Badge>
                              {!notification.read && (
                                <Badge variant="destructive">Unread</Badge>
                              )}
                              {notification.sent_email && (
                                <Mail className="h-3 w-3 text-green-600" />
                              )}
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">
                            {notification.message}
                          </p>
                          <div className="flex items-center justify-between text-xs text-muted-foreground">
                            <span>
                              To: {notification.profiles?.full_name || notification.profiles?.email}
                            </span>
                            <span>
                              {formatDistanceToNow(new Date(notification.created_at), { addSuffix: true })}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="send" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Send Bulk Notification</CardTitle>
              <CardDescription>
                Send notifications to multiple users at once
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label htmlFor="userType">Target Users</Label>
                  <Select 
                    value={sendForm.userType} 
                    onValueChange={(value) => setSendForm(prev => ({ ...prev, userType: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Users</SelectItem>
                      <SelectItem value="customer">Customers Only</SelectItem>
                      <SelectItem value="farmer">Farmers Only</SelectItem>
                      <SelectItem value="admin">Admins Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="notificationType">Notification Type</Label>
                  <Select 
                    value={sendForm.type} 
                    onValueChange={(value) => setSendForm(prev => ({ ...prev, type: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="announcement">Announcement</SelectItem>
                      <SelectItem value="system_update">System Update</SelectItem>
                      <SelectItem value="promotion">Promotion</SelectItem>
                      <SelectItem value="maintenance">Maintenance</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="title">Notification Title</Label>
                <Input
                  id="title"
                  placeholder="Enter notification title..."
                  value={sendForm.title}
                  onChange={(e) => setSendForm(prev => ({ ...prev, title: e.target.value }))}
                />
              </div>
              
              <div>
                <Label htmlFor="message">Message</Label>
                <Textarea
                  id="message"
                  placeholder="Enter your message..."
                  rows={4}
                  value={sendForm.message}
                  onChange={(e) => setSendForm(prev => ({ ...prev, message: e.target.value }))}
                />
              </div>
              
              <Button onClick={sendBulkNotification} className="w-full">
                <Send className="mr-2 h-4 w-4" />
                Send Notification
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}