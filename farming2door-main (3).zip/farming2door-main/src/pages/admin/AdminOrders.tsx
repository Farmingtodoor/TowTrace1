import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useMemo, useState, useEffect } from "react";
import { formatWindow } from "@/lib/scheduleWindow";

import { toast } from "sonner";
import { CalendarDays, List, Loader2, StickyNote, Store, Truck, X } from "lucide-react";
import { OrdersCalendar } from "@/components/admin/OrdersCalendar";
import { supabase } from "@/integrations/supabase/client";
import { useAdmin } from "@/contexts/AdminContext";
import { useNavigate } from "react-router-dom";
import { usePermissions } from "@/hooks/usePermissions";

const STATUS_OPTIONS = ["pending", "confirmed", "processing", "out_for_delivery", "delivered"];

export default function AdminOrders() {
  const [view, setView] = useState<"list" | "calendar">("list");
  const [filteredStatus, setFilteredStatus] = useState<string | null>(null);
  const [scheduleFilter, setScheduleFilter] = useState<"all" | "delivery" | "pickup" | "unscheduled">("all");
  const [sortBy, setSortBy] = useState<"newest" | "schedule_asc" | "schedule_desc">("newest");

  const [orderList, setOrderList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<string[]>([]);
  const [bulkStatus, setBulkStatus] = useState<string>("");
  const [bulkNote, setBulkNote] = useState("");
  const [noteDialogOpen, setNoteDialogOpen] = useState(false);
  const [bulkBusy, setBulkBusy] = useState(false);
  const { isAdmin, isFarmer } = useAdmin();
  const navigate = useNavigate();
  const { can, requirePermission } = usePermissions();

  useEffect(() => {
    fetchOrders();
  }, [isAdmin, isFarmer]);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const { data: orders, error } = await supabase
        .from('orders')
        .select(`
          id,
          status,
          total_amount,
          created_at,
          farmer_notes,
          delivery_type,
          payment_status,
          paid_at,
          amount_paid,
          platform_fee,
          farmer_earnings,
          pickup_scheduled_at,
          pickup_scheduled_end,
          delivery_scheduled_at,
          delivery_scheduled_end,
          profiles!orders_customer_id_fkey(full_name, email),
          order_items(quantity)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const formattedOrders = orders?.map((order: any) => {
        const isPickup = order.delivery_type === 'pickup';
        const scheduledAt = isPickup ? order.pickup_scheduled_at : order.delivery_scheduled_at;
        const scheduledEnd = isPickup ? order.pickup_scheduled_end : order.delivery_scheduled_end;
        return {
          id: order.id,
          customer: order.profiles?.full_name || order.profiles?.email || 'Unknown',
          total: `$${order.total_amount?.toFixed(2) || '0.00'}`,
          status: order.status,
          notes: order.farmer_notes ?? '',
          date: new Date(order.created_at).toLocaleDateString(),
          createdAt: order.created_at,
          fulfillment: isPickup ? 'pickup' : 'delivery',
          paymentStatus: order.payment_status || 'unpaid',
          paidAt: order.paid_at,
          amountPaid: order.amount_paid != null ? Number(order.amount_paid) : null,
          platformFee: Number(order.platform_fee ?? 0),
          farmerEarnings: Number(order.farmer_earnings ?? 0),
          scheduledAt,
          scheduleLabel: formatWindow(scheduledAt, scheduledEnd),
          items: order.order_items?.reduce((sum: number, item: any) => sum + item.quantity, 0) || 0,
        };
      }) || [];


      setOrderList(formattedOrders);
    } catch (error) {
      console.error('Error fetching orders:', error);
      toast.error('Failed to fetch orders');
    } finally {
      setLoading(false);
    }
  };

  const statusOrder = ['pending', 'confirmed', 'processing', 'delivered', 'cancelled'];

  const filteredOrders = useMemo(() => {
    let list = filteredStatus
      ? orderList.filter((order) => order.status === filteredStatus)
      : [...orderList];

    if (scheduleFilter === 'delivery') list = list.filter((o) => o.fulfillment === 'delivery' && o.scheduledAt);
    if (scheduleFilter === 'pickup') list = list.filter((o) => o.fulfillment === 'pickup' && o.scheduledAt);
    if (scheduleFilter === 'unscheduled') list = list.filter((o) => !o.scheduledAt);

    const time = (v?: string | null) => (v ? new Date(v).getTime() : null);
    if (sortBy === 'schedule_asc' || sortBy === 'schedule_desc') {
      list.sort((a, b) => {
        const at = time(a.scheduledAt);
        const bt = time(b.scheduledAt);
        if (at === null && bt === null) return 0;
        if (at === null) return 1; // unscheduled always last
        if (bt === null) return -1;
        return sortBy === 'schedule_asc' ? at - bt : bt - at;
      });
    } else {
      list.sort((a, b) => (time(b.createdAt) ?? 0) - (time(a.createdAt) ?? 0));
    }

    return list;
  }, [orderList, filteredStatus, scheduleFilter, sortBy]);


  const allVisibleSelected =
    filteredOrders.length > 0 && filteredOrders.every((o) => selected.includes(o.id));

  const toggleSelectAll = () => {
    setSelected(allVisibleSelected ? [] : filteredOrders.map((o) => o.id));
  };

  const toggleSelect = (orderId: string) => {
    setSelected((prev) =>
      prev.includes(orderId) ? prev.filter((id) => id !== orderId) : [...prev, orderId]
    );
  };

  const handleFilterByStatus = (status: string | null) => {
    setFilteredStatus(status);
    setSelected([]);
    toast.success(`Filtered orders by ${status || 'all'} status`);
  };

  /** Applies one status to every selected order. */
  const applyBulkStatus = async (status: string) => {
    if (!requirePermission(status === "cancelled" ? "orders.cancel" : "orders.update_status")) return;
    setBulkBusy(true);
    const { error } = await supabase.from("orders").update({ status }).in("id", selected);
    setBulkBusy(false);
    if (error) {
      toast.error("Could not update the selected orders", { description: error.message });
      return;
    }
    setOrderList((orders) =>
      orders.map((o) => (selected.includes(o.id) ? { ...o, status } : o))
    );
    toast.success(`${selected.length} order${selected.length === 1 ? "" : "s"} marked ${status.replace(/_/g, " ")}`);
    setBulkStatus("");
    setSelected([]);
  };

  /** Appends an internal note to every selected order (keeps existing notes). */
  const applyBulkNote = async () => {
    if (!requirePermission("orders.edit_notes")) return;
    const note = bulkNote.trim();
    if (!note) {
      toast.error("Write a note first");
      return;
    }
    setBulkBusy(true);
    const stamped = `[${new Date().toLocaleString()}] ${note}`;
    const targets = orderList.filter((o) => selected.includes(o.id));
    const results = await Promise.all(
      targets.map((o) =>
        supabase
          .from("orders")
          .update({ farmer_notes: o.notes ? `${o.notes}\n${stamped}` : stamped })
          .eq("id", o.id)
      )
    );
    setBulkBusy(false);
    if (results.some((r) => r.error)) {
      toast.error("Some notes could not be saved");
      fetchOrders();
      return;
    }
    setOrderList((orders) =>
      orders.map((o) =>
        selected.includes(o.id) ? { ...o, notes: o.notes ? `${o.notes}\n${stamped}` : stamped } : o
      )
    );
    toast.success(`Note added to ${selected.length} order${selected.length === 1 ? "" : "s"}`);
    setBulkNote("");
    setNoteDialogOpen(false);
    setSelected([]);
  };

  const handleStatusChange = async (orderId: string, currentStatus: string) => {
    if (!requirePermission("orders.update_status")) return;
    const currentIndex = statusOrder.indexOf(currentStatus);
    const nextIndex = (currentIndex + 1) % statusOrder.length;
    let newStatus = statusOrder[nextIndex];
    if (newStatus === 'cancelled' && !can("orders.cancel")) {
      requirePermission("orders.cancel");
      return;
    }
    
    try {
      const { error } = await supabase
        .from('orders')
        .update({ status: newStatus })
        .eq('id', orderId);

      if (error) throw error;

      setOrderList(orders => 
        orders.map(order => 
          order.id === orderId 
            ? { ...order, status: newStatus }
            : order
        )
      );
      toast.success(`Order status changed to ${newStatus}`);
    } catch (error) {
      console.error('Error updating order status:', error);
      toast.error('Failed to update order status');
    }
  };

  const handleViewOrder = (orderId: string) => {
    navigate(`/admin/orders/${orderId}`);
  };

  const handleUpdateOrder = (orderId: string) => {
    if (!requirePermission("orders.edit_notes")) return;
    navigate(`/admin/orders/${orderId}`);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'warning';
      case 'confirmed': return 'default';
      case 'processing': return 'secondary';
      case 'delivered': return 'success';
      case 'cancelled': return 'destructive';
      default: return 'outline';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Order Management</h1>
          <p className="text-muted-foreground">Track and manage all orders</p>
        </div>
        <div className="flex items-center gap-1 rounded-lg border p-1">
          <Button
            size="sm"
            variant={view === "list" ? "default" : "ghost"}
            onClick={() => setView("list")}
          >
            <List className="mr-1.5 h-3.5 w-3.5" /> List
          </Button>
          <Button
            size="sm"
            variant={view === "calendar" ? "default" : "ghost"}
            onClick={() => setView("calendar")}
          >
            <CalendarDays className="mr-1.5 h-3.5 w-3.5" /> Calendar
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card className="cursor-pointer hover:bg-muted/50 transition-colors" onClick={() => handleFilterByStatus(null)}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {loading ? '...' : orderList.length}
            </div>
            <p className="text-xs text-muted-foreground">Click to show all</p>
          </CardContent>
        </Card>
        <Card className="cursor-pointer hover:bg-muted/50 transition-colors" onClick={() => handleFilterByStatus('pending')}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Pending</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{orderList.filter(o => o.status === 'pending').length}</div>
            <p className="text-xs text-muted-foreground">Click to filter</p>
          </CardContent>
        </Card>
        <Card className="cursor-pointer hover:bg-muted/50 transition-colors" onClick={() => handleFilterByStatus('processing')}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Processing</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{orderList.filter(o => o.status === 'processing').length}</div>
            <p className="text-xs text-muted-foreground">Click to filter</p>
          </CardContent>
        </Card>
        <Card className="cursor-pointer hover:bg-muted/50 transition-colors" onClick={() => handleFilterByStatus('delivered')}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Delivered</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{orderList.filter(o => o.status === 'delivered').length}</div>
            <p className="text-xs text-muted-foreground">Click to filter</p>
          </CardContent>
        </Card>
      </div>

      {view === "calendar" ? (
        <OrdersCalendar orders={filteredOrders} onOpenOrder={handleViewOrder} />
      ) : (
      <Card>
        <CardHeader>
          <CardTitle>Recent Orders</CardTitle>
          <CardDescription>
            {filteredStatus ? `Showing ${filteredStatus} orders` : 'Latest orders in the system'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex flex-wrap items-center gap-2">
            <Select value={scheduleFilter} onValueChange={(v) => { setScheduleFilter(v as any); setSelected([]); }}>
              <SelectTrigger className="w-56">
                <SelectValue placeholder="Schedule filter" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All fulfillment types</SelectItem>
                <SelectItem value="delivery">Delivery scheduled</SelectItem>
                <SelectItem value="pickup">Pickup scheduled</SelectItem>
                <SelectItem value="unscheduled">Not scheduled yet</SelectItem>
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={(v) => setSortBy(v as any)}>
              <SelectTrigger className="w-56">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest orders first</SelectItem>
                <SelectItem value="schedule_asc">Schedule time: soonest</SelectItem>
                <SelectItem value="schedule_desc">Schedule time: latest</SelectItem>
              </SelectContent>
            </Select>

            <span className="text-xs text-muted-foreground">
              Showing {filteredOrders.length} order{filteredOrders.length === 1 ? "" : "s"}
            </span>
          </div>

          <div className="mb-4 flex flex-wrap items-center gap-3 rounded-lg border bg-muted/40 px-3 py-2">
            <label className="flex items-center gap-2 text-sm">
              <Checkbox
                checked={allVisibleSelected}
                onCheckedChange={toggleSelectAll}
                aria-label="Select all visible orders"
                disabled={filteredOrders.length === 0}
              />
              Select all
            </label>
            <span className="text-sm text-muted-foreground">
              {selected.length} selected
            </span>

            <div className="ml-auto flex flex-wrap items-center gap-2">
              <Select
                value={bulkStatus}
                onValueChange={(v) => {
                  setBulkStatus(v);
                  applyBulkStatus(v);
                }}
                disabled={selected.length === 0 || bulkBusy}
              >
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Set status for selected" />
                </SelectTrigger>
                <SelectContent>
                  {STATUS_OPTIONS.map((s) => (
                    <SelectItem key={s} value={s} className="capitalize">
                      {s.replace(/_/g, " ")}
                    </SelectItem>
                  ))}
                  {can("orders.cancel") && <SelectItem value="cancelled">Cancelled</SelectItem>}
                </SelectContent>
              </Select>

              <Button
                variant="outline"
                size="sm"
                disabled={selected.length === 0 || bulkBusy}
                onClick={() => setNoteDialogOpen(true)}
              >
                <StickyNote className="mr-2 h-3.5 w-3.5" /> Add internal note
              </Button>

              {selected.length > 0 && (
                <Button variant="ghost" size="sm" onClick={() => setSelected([])}>
                  <X className="mr-1 h-3.5 w-3.5" /> Clear
                </Button>
              )}
              {bulkBusy && <Loader2 className="h-4 w-4 animate-spin text-primary" />}
            </div>
          </div>

          <div className="space-y-4">
            {filteredOrders.map((order) => (
              <div key={order.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex flex-1 items-center gap-3">
                  <Checkbox
                    checked={selected.includes(order.id)}
                    onCheckedChange={() => toggleSelect(order.id)}
                    aria-label={`Select order ${String(order.id).slice(0, 8)}`}
                  />
                  <div className="flex items-center gap-3">
                    <div>
                      <p className="font-medium">Order #{String(order.id).slice(0, 8)}</p>
                      <p className="text-sm text-muted-foreground">
                        {order.customer} • {order.items} items • {order.date}
                      </p>
                      <p className="mt-0.5 flex items-center gap-1.5 text-xs text-muted-foreground">
                        {order.fulfillment === "pickup" ? (
                          <Store className="h-3 w-3" />
                        ) : (
                          <Truck className="h-3 w-3" />
                        )}
                        {order.scheduleLabel
                          ? `${order.fulfillment === "pickup" ? "Pickup" : "ETA"}: ${order.scheduleLabel}`
                          : `${order.fulfillment === "pickup" ? "Pickup" : "Delivery"} not scheduled`}
                      </p>
                    </div>

                    <Badge 
                      variant={getStatusColor(order.status) as any}
                      className="cursor-pointer hover:opacity-80 transition-opacity"
                      onClick={() => handleStatusChange(order.id, order.status)}
                      title="Click to change status"
                    >
                      {order.status}
                    </Badge>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <span className="font-semibold">{order.total}</span>
                    <p className="text-xs text-muted-foreground">
                      {order.paymentStatus === 'paid'
                        ? `Paid${order.paidAt ? ` • ${new Date(order.paidAt).toLocaleDateString()}` : ''}`
                        : 'Payment pending'}
                    </p>
                  </div>
                  <Badge variant={order.paymentStatus === 'paid' ? 'default' : 'secondary'}>
                    {order.paymentStatus === 'paid' ? 'Paid' : 'Unpaid'}
                  </Badge>
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleViewOrder(order.id)}
                    >
                      View
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleUpdateOrder(order.id)}
                    >
                      Update
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      )}

      <Dialog open={noteDialogOpen} onOpenChange={setNoteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add internal note</DialogTitle>
            <DialogDescription>
              The note is appended (with a timestamp) to the internal notes of{" "}
              {selected.length} selected order{selected.length === 1 ? "" : "s"}. Customers don't see it.
            </DialogDescription>
          </DialogHeader>
          <Textarea
            value={bulkNote}
            onChange={(e) => setBulkNote(e.target.value)}
            placeholder="e.g. Packed and staged for Saturday pickup run"
            rows={4}
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setNoteDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={applyBulkNote} disabled={bulkBusy}>
              {bulkBusy && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Add note
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
