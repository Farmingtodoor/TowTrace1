import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { useAdmin } from "@/contexts/AdminContext";
import { toast } from "sonner";
import { Save, Shield, Bell, Users, Settings as SettingsIcon, Globe } from "lucide-react";
import UserStatsCards from "@/components/UserStatsCards";

export default function AdminSettings() {
  const { isSuperAdmin } = useAdmin();
  const [loading, setLoading] = useState(false);

  // System Settings State
  const [systemSettings, setSystemSettings] = useState({
    siteName: "Farm2Door",
    siteDescription: "Fresh produce directly from local farmers",
    maintenanceMode: false,
    registrationEnabled: true,
    defaultUserRole: "customer",
    maxOrderAmount: 1000,
    deliveryRadius: 50,
  });

  // Notification Settings State
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    orderNotifications: true,
    marketingEmails: false,
    adminAlerts: true,
    notificationFrequency: "immediate",
  });

  // Security Settings State
  const [securitySettings, setSecuritySettings] = useState({
    requireEmailVerification: true,
    passwordMinLength: 8,
    sessionTimeout: 24,
    twoFactorEnabled: false,
    ipWhitelisting: false,
    whitelistedIPs: "",
  });

  const handleSaveSettings = async (section: string) => {
    setLoading(true);
    try {
      // Simulate API call - in real implementation, this would save to database
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success(`${section} settings saved successfully`);
    } catch (error) {
      toast.error(`Failed to save ${section} settings`);
    } finally {
      setLoading(false);
    }
  };

  if (!isSuperAdmin) {
    return (
      <div className="text-center py-12">
        <Shield className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
        <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
        <p className="text-muted-foreground">Only Super Admins can access system settings.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <SettingsIcon className="h-8 w-8" />
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Admin Settings</h1>
          <p className="text-muted-foreground">Configure system-wide settings and preferences</p>
        </div>
      </div>

      {/* System Configuration */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            System Configuration
          </CardTitle>
          <CardDescription>Basic application settings and configuration</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="siteName">Site Name</Label>
              <Input
                id="siteName"
                value={systemSettings.siteName}
                onChange={(e) => setSystemSettings({...systemSettings, siteName: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="defaultRole">Default User Role</Label>
              <Select
                value={systemSettings.defaultUserRole}
                onValueChange={(value) => setSystemSettings({...systemSettings, defaultUserRole: value})}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="customer">Customer</SelectItem>
                  <SelectItem value="farmer">Farmer</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="siteDescription">Site Description</Label>
            <Textarea
              id="siteDescription"
              value={systemSettings.siteDescription}
              onChange={(e) => setSystemSettings({...systemSettings, siteDescription: e.target.value})}
              rows={3}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="maxOrder">Maximum Order Amount ($)</Label>
              <Input
                id="maxOrder"
                type="number"
                value={systemSettings.maxOrderAmount}
                onChange={(e) => setSystemSettings({...systemSettings, maxOrderAmount: parseInt(e.target.value)})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="deliveryRadius">Delivery Radius (miles)</Label>
              <Input
                id="deliveryRadius"
                type="number"
                value={systemSettings.deliveryRadius}
                onChange={(e) => setSystemSettings({...systemSettings, deliveryRadius: parseInt(e.target.value)})}
              />
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Maintenance Mode</Label>
                <p className="text-sm text-muted-foreground">Temporarily disable access to the site</p>
              </div>
              <Switch
                checked={systemSettings.maintenanceMode}
                onCheckedChange={(checked) => setSystemSettings({...systemSettings, maintenanceMode: checked})}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>User Registration</Label>
                <p className="text-sm text-muted-foreground">Allow new users to register</p>
              </div>
              <Switch
                checked={systemSettings.registrationEnabled}
                onCheckedChange={(checked) => setSystemSettings({...systemSettings, registrationEnabled: checked})}
              />
            </div>
          </div>

          <div className="flex justify-end">
            <Button onClick={() => handleSaveSettings("System")} disabled={loading}>
              <Save className="h-4 w-4 mr-2" />
              Save System Settings
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Notification Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Notification Settings
          </CardTitle>
          <CardDescription>Configure notification preferences and delivery</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Email Notifications</Label>
                <p className="text-sm text-muted-foreground">Send email notifications to users</p>
              </div>
              <Switch
                checked={notificationSettings.emailNotifications}
                onCheckedChange={(checked) => setNotificationSettings({...notificationSettings, emailNotifications: checked})}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Order Notifications</Label>
                <p className="text-sm text-muted-foreground">Notify users about order status changes</p>
              </div>
              <Switch
                checked={notificationSettings.orderNotifications}
                onCheckedChange={(checked) => setNotificationSettings({...notificationSettings, orderNotifications: checked})}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Marketing Emails</Label>
                <p className="text-sm text-muted-foreground">Send promotional emails to users</p>
              </div>
              <Switch
                checked={notificationSettings.marketingEmails}
                onCheckedChange={(checked) => setNotificationSettings({...notificationSettings, marketingEmails: checked})}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Admin Alerts</Label>
                <p className="text-sm text-muted-foreground">Receive alerts about system events</p>
              </div>
              <Switch
                checked={notificationSettings.adminAlerts}
                onCheckedChange={(checked) => setNotificationSettings({...notificationSettings, adminAlerts: checked})}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Notification Frequency</Label>
            <Select
              value={notificationSettings.notificationFrequency}
              onValueChange={(value) => setNotificationSettings({...notificationSettings, notificationFrequency: value})}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="immediate">Immediate</SelectItem>
                <SelectItem value="hourly">Hourly Digest</SelectItem>
                <SelectItem value="daily">Daily Digest</SelectItem>
                <SelectItem value="weekly">Weekly Digest</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex justify-end">
            <Button onClick={() => handleSaveSettings("Notification")} disabled={loading}>
              <Save className="h-4 w-4 mr-2" />
              Save Notification Settings
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Security Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Security Settings
          </CardTitle>
          <CardDescription>Configure security and authentication settings</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Email Verification Required</Label>
                <p className="text-sm text-muted-foreground">Require email verification for new accounts</p>
              </div>
              <Switch
                checked={securitySettings.requireEmailVerification}
                onCheckedChange={(checked) => setSecuritySettings({...securitySettings, requireEmailVerification: checked})}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Two-Factor Authentication</Label>
                <p className="text-sm text-muted-foreground">Enable 2FA for admin accounts</p>
              </div>
              <Switch
                checked={securitySettings.twoFactorEnabled}
                onCheckedChange={(checked) => setSecuritySettings({...securitySettings, twoFactorEnabled: checked})}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>IP Whitelisting</Label>
                <p className="text-sm text-muted-foreground">Restrict admin access to specific IP addresses</p>
              </div>
              <Switch
                checked={securitySettings.ipWhitelisting}
                onCheckedChange={(checked) => setSecuritySettings({...securitySettings, ipWhitelisting: checked})}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="passwordLength">Minimum Password Length</Label>
              <Input
                id="passwordLength"
                type="number"
                min="6"
                max="20"
                value={securitySettings.passwordMinLength}
                onChange={(e) => setSecuritySettings({...securitySettings, passwordMinLength: parseInt(e.target.value)})}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="sessionTimeout">Session Timeout (hours)</Label>
              <Input
                id="sessionTimeout"
                type="number"
                min="1"
                max="168"
                value={securitySettings.sessionTimeout}
                onChange={(e) => setSecuritySettings({...securitySettings, sessionTimeout: parseInt(e.target.value)})}
              />
            </div>
          </div>

          {securitySettings.ipWhitelisting && (
            <div className="space-y-2">
              <Label htmlFor="whitelistedIPs">Whitelisted IP Addresses</Label>
              <Textarea
                id="whitelistedIPs"
                placeholder="Enter IP addresses, one per line (e.g., 192.168.1.1)"
                value={securitySettings.whitelistedIPs}
                onChange={(e) => setSecuritySettings({...securitySettings, whitelistedIPs: e.target.value})}
                rows={4}
              />
            </div>
          )}

          <div className="flex justify-end">
            <Button onClick={() => handleSaveSettings("Security")} disabled={loading}>
              <Save className="h-4 w-4 mr-2" />
              Save Security Settings
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* User Management Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            User Management
          </CardTitle>
          <CardDescription>Configure user-related settings and permissions</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <UserStatsCards />
          
          <div className="flex justify-between">
            <Button variant="outline">
              Export User Data
            </Button>
            <Button variant="outline">
              Bulk User Actions
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}