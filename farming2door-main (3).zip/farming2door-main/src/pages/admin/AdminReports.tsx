import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAdmin } from "@/contexts/AdminContext";
import { roleCan } from "@/lib/permissions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import {
  AlertTriangle, CheckCircle, Clock, DollarSign, Landmark, RefreshCw, TrendingUp, Wallet,
} from "lucide-react";

interface PayoutReport {
  total_paid: number;
  total_pending: number;
  total_approved: number;
  total_rejected: number;
  paid_count: number;
  pending_count: number;
  approved_count: number;
  rejected_count: number;
  receipts_sent: number;
  receipts_failed: number;
  success_rate: number | null;
}

interface FarmerEarnings {
  farmer_id: string;
  farm_name: string | null;
  farmer_email: string | null;
  is_approved: boolean | null;
  bank_verified: boolean | null;
  paid_orders: number;
  gross_earnings: number;
  total_paid_out: number;
  pending_amount: number;
  pending_requests: number;
  available_balance: number;
  last_payout_at: string | null;
}

const money = (value: number | null | undefined) => `$${Number(value ?? 0).toFixed(2)}`;

export default function AdminReports() {
  const { userRole } = useAdmin();
  const [loading, setLoading] = useState(true);
  const [report, setReport] = useState<PayoutReport | null>(null);
  const [farmers, setFarmers] = useState<FarmerEarnings[]>([]);
  const [search, setSearch] = useState("");

  const canView = roleCan(userRole as never, "payouts.view");

  const load = async () => {
    setLoading(true);
    try {
      const [summaryRes, farmerRes] = await Promise.all([
        supabase.rpc("get_admin_payout_report"),
        supabase.rpc("get_admin_farmer_earnings_report"),
      ]);
      if (summaryRes.error) throw summaryRes.error;
      if (farmerRes.error) throw farmerRes.error;
      setReport((summaryRes.data as PayoutReport[])?.[0] ?? null);
      setFarmers((farmerRes.data as FarmerEarnings[]) || []);
    } catch (error) {
      console.error("Error loading payout reports:", error);
      toast.error("Could not load payout reports");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (canView) load();
    else setLoading(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [canView]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return farmers;
    return farmers.filter(
      (f) =>
        (f.farm_name || "").toLowerCase().includes(q) ||
        (f.farmer_email || "").toLowerCase().includes(q),
    );
  }, [farmers, search]);

  const pendingByFarmer = useMemo(
    () => filtered.filter((f) => f.pending_requests > 0 || f.pending_amount > 0),
    [filtered],
  );

  if (!canView) {
    return (
      <Card>
        <CardContent className="py-12 text-center space-y-2">
          <AlertTriangle className="h-8 w-8 mx-auto text-amber-600" />
          <p className="font-medium">You don't have permission to view payout reports.</p>
        </CardContent>
      </Card>
    );
  }

  const successRate = report?.success_rate;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Payout reports</h1>
          <p className="text-muted-foreground text-sm">
            Totals, pending requests by farm, transfer success rate and per-farm earnings.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={load} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
            Refresh
          </Button>
          <Button asChild size="sm">
            <Link to="/admin/payouts">Manage payouts</Link>
          </Button>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { label: "Total paid out", value: money(report?.total_paid), sub: `${report?.paid_count ?? 0} payouts`, icon: Wallet },
          { label: "Pending requests", value: money(report?.total_pending), sub: `${report?.pending_count ?? 0} awaiting review`, icon: Clock },
          { label: "Approved, not sent", value: money(report?.total_approved), sub: `${report?.approved_count ?? 0} queued`, icon: DollarSign },
          { label: "Rejected", value: money(report?.total_rejected), sub: `${report?.rejected_count ?? 0} declined`, icon: AlertTriangle },
        ].map(({ label, value, sub, icon: Icon }) => (
          <Card key={label}>
            <CardContent className="py-4">
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">{label}</p>
                <Icon className="h-4 w-4 text-primary" />
              </div>
              <p className="text-2xl font-bold tabular-nums">{loading ? "—" : value}</p>
              <p className="text-xs text-muted-foreground">{sub}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <TrendingUp className="h-5 w-5" />
            Payout success rate
          </CardTitle>
          <CardDescription>Share of bank transfers that completed without failing.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {successRate === null || successRate === undefined ? (
            <p className="text-sm text-muted-foreground">No transfers have been attempted yet.</p>
          ) : (
            <>
              <div className="flex items-center justify-between text-sm">
                <span className="text-2xl font-bold tabular-nums">{Number(successRate).toFixed(1)}%</span>
                <span className="text-muted-foreground">
                  {report?.receipts_sent ?? 0} succeeded · {report?.receipts_failed ?? 0} failed
                </span>
              </div>
              <Progress value={Number(successRate)} />
            </>
          )}
        </CardContent>
      </Card>

      <Tabs defaultValue="earnings" className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <TabsList>
            <TabsTrigger value="earnings">Per-farm earnings ({filtered.length})</TabsTrigger>
            <TabsTrigger value="pending">Pending by farm ({pendingByFarmer.length})</TabsTrigger>
          </TabsList>
          <Input
            placeholder="Search farm or email…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="max-w-xs"
          />
        </div>

        <TabsContent value="earnings">
          <Card>
            <CardContent className="p-0 overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Farm</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Paid orders</TableHead>
                    <TableHead className="text-right">Gross earnings</TableHead>
                    <TableHead className="text-right">Paid out</TableHead>
                    <TableHead className="text-right">In review</TableHead>
                    <TableHead className="text-right">Available</TableHead>
                    <TableHead>Last payout</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loading ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                        Loading reports…
                      </TableCell>
                    </TableRow>
                  ) : filtered.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                        No farms match this search.
                      </TableCell>
                    </TableRow>
                  ) : (
                    filtered.map((f) => (
                      <TableRow key={f.farmer_id}>
                        <TableCell>
                          <p className="font-medium">{f.farm_name || "Unnamed farm"}</p>
                          <p className="text-xs text-muted-foreground">{f.farmer_email || "—"}</p>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            <Badge variant={f.is_approved ? "default" : "secondary"}>
                              {f.is_approved ? "Verified" : "Unverified"}
                            </Badge>
                            <Badge variant="outline" className={f.bank_verified ? "bg-green-50 text-green-700 border-green-200" : ""}>
                              <Landmark className="h-3 w-3 mr-1" />
                              {f.bank_verified ? "Bank ready" : "No bank"}
                            </Badge>
                          </div>
                        </TableCell>
                        <TableCell className="text-right tabular-nums">{f.paid_orders}</TableCell>
                        <TableCell className="text-right tabular-nums">{money(f.gross_earnings)}</TableCell>
                        <TableCell className="text-right tabular-nums">{money(f.total_paid_out)}</TableCell>
                        <TableCell className="text-right tabular-nums">{money(f.pending_amount)}</TableCell>
                        <TableCell className="text-right tabular-nums font-semibold">
                          {money(f.available_balance)}
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {f.last_payout_at ? new Date(f.last_payout_at).toLocaleDateString() : "—"}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pending">
          <Card>
            <CardContent className="p-0 overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Farm</TableHead>
                    <TableHead className="text-right">Open requests</TableHead>
                    <TableHead className="text-right">Amount awaiting</TableHead>
                    <TableHead>Bank status</TableHead>
                    <TableHead className="text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pendingByFarmer.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                        No pending payout requests.
                      </TableCell>
                    </TableRow>
                  ) : (
                    pendingByFarmer.map((f) => (
                      <TableRow key={f.farmer_id}>
                        <TableCell>
                          <p className="font-medium">{f.farm_name || "Unnamed farm"}</p>
                          <p className="text-xs text-muted-foreground">{f.farmer_email || "—"}</p>
                        </TableCell>
                        <TableCell className="text-right tabular-nums">{f.pending_requests}</TableCell>
                        <TableCell className="text-right tabular-nums font-semibold">
                          {money(f.pending_amount)}
                        </TableCell>
                        <TableCell>
                          {f.bank_verified ? (
                            <span className="inline-flex items-center text-sm text-green-700">
                              <CheckCircle className="h-3.5 w-3.5 mr-1" /> Ready to transfer
                            </span>
                          ) : (
                            <span className="inline-flex items-center text-sm text-amber-700">
                              <AlertTriangle className="h-3.5 w-3.5 mr-1" /> Bank not verified
                            </span>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button asChild size="sm" variant="outline">
                            <Link to="/admin/payouts">Review</Link>
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
