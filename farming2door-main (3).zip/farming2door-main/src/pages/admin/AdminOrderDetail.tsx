import { useCallback, useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {
  ArrowLeft,
  Bell,
  BellOff,
  Check,
  Clock,
  Loader2,
  MapPin,
  Package,
  Scissors,
  Truck,
  Store,
  Undo2,
} from "lucide-react";
import { usePermissions } from "@/hooks/usePermissions";
import { useAdminNotifications } from "@/hooks/useAdminNotifications";
import { cn } from "@/lib/utils";

const STATUS_FLOW = ["pending", "confirmed", "processing", "out_for_delivery", "delivered"] as const;

const statusStyles: Record<string, string> = {
  delivered: "bg-primary/10 text-primary border-primary/20",
  pending: "bg-muted text-muted-foreground",
  cancelled: "bg-destructive/10 text-destructive border-destructive/20",
};

import {
  formatWindow,
  nowLocalInput,
  toLocalInput,
  validateWindow,
} from "@/lib/scheduleWindow";



interface OrderItem {

  id: string;
  product_name: string;
  product_description: string | null;
  quantity: number;
  unit_price: number;
  total_price: number;
}

export default function AdminOrderDetail() {
  const { orderId } = useParams<{ orderId: string }>();
  const navigate = useNavigate();
  const { can, requirePermission } = usePermissions();
  const { isOrderMuted, toggleOrderMute, push: pushNotification } = useAdminNotifications();

  const [order, setOrder] = useState<any>(null);
  const [items, setItems] = useState<OrderItem[]>([]);
  const [addOnNames, setAddOnNames] = useState<string[]>([]);
  const [assignment, setAssignment] = useState<any>(null);
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [scheduleStart, setScheduleStart] = useState("");
  const [scheduleEnd, setScheduleEnd] = useState("");
  const [savingSchedule, setSavingSchedule] = useState(false);
  /** Window that was in place before the last save, so it can be restored. */
  const [previousWindow, setPreviousWindow] = useState<{
    start: string | null;
    end: string | null;
  } | null>(null);


  const load = useCallback(async () => {
    if (!orderId) return;
    setLoading(true);
    const [orderRes, itemsRes, addOnRes, assignmentRes] = await Promise.all([
      supabase
        .from("orders")
        .select(
          `*, customer:profiles!orders_customer_id_fkey(full_name, email, phone),
           farmer:profiles!orders_farmer_id_fkey(full_name, email),
           pickup_slot:farmer_pickup_slots(day_of_week, start_time, end_time, location_note)`
        )
        .eq("id", orderId)
        .maybeSingle(),
      supabase.from("order_items").select("*").eq("order_id", orderId),
      supabase.from("add_ons").select("name"),
      supabase
        .from("driver_order_assignments")
        .select("status, assigned_at, picked_up_at, delivered_at, driver_notes")
        .eq("order_id", orderId)
        .maybeSingle(),
    ]);

    if (orderRes.error || !orderRes.data) {
      toast.error("Order not found or you don't have access to it");
      setLoading(false);
      return;
    }

    setOrder(orderRes.data);
    setNotes(orderRes.data.farmer_notes ?? "");
    const o: any = orderRes.data;
    const pickup = o.delivery_type === "pickup";
    setScheduleStart(toLocalInput(pickup ? o.pickup_scheduled_at : o.delivery_scheduled_at));
    setScheduleEnd(toLocalInput(pickup ? o.pickup_scheduled_end : o.delivery_scheduled_end));

    setItems((itemsRes.data as OrderItem[]) ?? []);
    setAddOnNames((addOnRes.data ?? []).map((a: any) => String(a.name).toLowerCase()));
    setAssignment(assignmentRes.data ?? null);
    setLoading(false);
  }, [orderId]);

  useEffect(() => {
    load();
  }, [load]);

  // Live updates for this order
  useEffect(() => {
    if (!orderId) return;
    const channel = supabase
      .channel(`admin-order-${orderId}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "orders", filter: `id=eq.${orderId}` },
        () => load()
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [orderId, load]);

  const { productItems, processingItems } = useMemo(() => {
    const isAddOn = (item: OrderItem) => addOnNames.includes(item.product_name.toLowerCase());
    return {
      productItems: items.filter((i) => !isAddOn(i)),
      processingItems: items.filter(isAddOn),
    };
  }, [items, addOnNames]);

  const timeline = useMemo(() => {
    if (!order) return [];
    const entries: { label: string; at: string | null; note?: string }[] = [
      { label: "Order placed", at: order.created_at },
      { label: "Driver assigned", at: assignment?.assigned_at ?? null, note: assignment?.driver_notes ?? undefined },
      { label: "Picked up", at: assignment?.picked_up_at ?? null },
      {
        label: order.delivery_type === "pickup" ? "Pickup scheduled" : "Delivery scheduled",
        at:
          (order.delivery_type === "pickup"
            ? order.pickup_scheduled_at
            : order.delivery_scheduled_at) ?? null,
      },
      { label: "Delivered", at: assignment?.delivered_at ?? (order.status === "delivered" ? order.updated_at : null) },
      { label: "Last updated", at: order.updated_at },
    ];
    return entries.filter((e) => e.at);
  }, [order, assignment]);

  const scheduleValidation = useMemo(
    () => validateWindow(scheduleStart, scheduleEnd),
    [scheduleStart, scheduleEnd]
  );

  const updateStatus = async (status: string) => {

    if (!requirePermission(status === "cancelled" ? "orders.cancel" : "orders.update_status")) return;
    setSaving(true);
    const { error } = await supabase.from("orders").update({ status }).eq("id", orderId);
    setSaving(false);
    if (error) {
      toast.error("Could not update the order status");
      return;
    }
    toast.success(`Order marked ${status.replace(/_/g, " ")}`);
    load();
  };

  /** Notifies the farm and the customer that their window moved. */
  const notifyParties = async (windowLabel: string | null, isPickupOrder: boolean) => {
    const recipients = [order?.customer_id, order?.farmer_id].filter(
      (id, i, arr): id is string => Boolean(id) && arr.indexOf(id) === i
    );
    if (recipients.length === 0) return;

    const kind = isPickupOrder ? "pickup" : "delivery";
    const title = windowLabel
      ? `Your ${kind} window is set`
      : `Your ${kind} window was cleared`;
    const message = windowLabel
      ? `Order #${String(order.id).slice(0, 8)} is scheduled for ${windowLabel}.`
      : `Order #${String(order.id).slice(0, 8)} no longer has a scheduled ${kind} window. We'll confirm a new time shortly.`;

    const { error } = await supabase.from("notifications").insert(
      recipients.map((user_id) => ({
        user_id,
        order_id: order.id,
        type: "order_schedule",
        title,
        message,
      }))
    );
    if (error) console.error("Could not notify order parties:", error);
  };

  /** Writes a window to the order, notifies both parties and the admin feed. */
  const applyWindow = async (
    start: string | null,
    end: string | null,
    { isUndo = false }: { isUndo?: boolean } = {}
  ) => {
    const isPickupOrder = order?.delivery_type === "pickup";
    const payload = isPickupOrder
      ? { pickup_scheduled_at: start, pickup_scheduled_end: end }
      : { delivery_scheduled_at: start, delivery_scheduled_end: end };

    // Snapshot what we're replacing so it can be restored in one click.
    const prior = {
      start: (isPickupOrder ? order?.pickup_scheduled_at : order?.delivery_scheduled_at) ?? null,
      end: (isPickupOrder ? order?.pickup_scheduled_end : order?.delivery_scheduled_end) ?? null,
    };

    setSavingSchedule(true);
    const { error } = await supabase.from("orders").update(payload).eq("id", orderId);
    setSavingSchedule(false);
    if (error) {
      toast.error("Could not save the schedule");
      return;
    }

    const windowLabel = formatWindow(start, end);
    await notifyParties(windowLabel, isPickupOrder);

    // Admin feed entry — suppressed automatically when this order is muted.
    pushNotification({
      orderId: order.id,
      title: `Order #${String(order.id).slice(0, 8)} ${isPickupOrder ? "pickup" : "delivery"} window ${
        isUndo ? "reverted" : windowLabel ? "updated" : "cleared"
      }`,
      description: windowLabel ?? undefined,
      status: order.status,
    });

    setPreviousWindow(
      prior.start === start && prior.end === end ? previousWindow : prior
    );

    toast.success(
      isUndo
        ? "Previous window restored — farm and customer notified"
        : start
        ? "Schedule updated — farm and customer notified"
        : "Schedule cleared"
    );
    load();
  };

  const saveSchedule = async () => {
    if (!requirePermission("orders.update_status")) return;

    const validation = validateWindow(scheduleStart, scheduleEnd);
    if (!validation.ok) {
      toast.error(validation.error);
      return;
    }
    await applyWindow(validation.start, validation.end);
  };

  /** Restores the window that was in place before the last change. */
  const undoSchedule = async () => {
    if (!requirePermission("orders.update_status")) return;
    if (!previousWindow) return;
    await applyWindow(previousWindow.start, previousWindow.end, { isUndo: true });
  };


  const saveNotes = async () => {

    if (!requirePermission("orders.edit_notes")) return;
    setSaving(true);
    const { error } = await supabase.from("orders").update({ farmer_notes: notes }).eq("id", orderId);
    setSaving(false);
    error ? toast.error("Could not save notes") : toast.success("Notes saved");
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  if (!order) {
    return (
      <Card>
        <CardContent className="py-12 text-center space-y-4">
          <p className="text-sm text-muted-foreground">We couldn't load this order.</p>
          <Button variant="outline" onClick={() => navigate("/admin/orders")}>
            Back to orders
          </Button>
        </CardContent>
      </Card>
    );
  }

  const isPickup = order.delivery_type === "pickup";
  const muted = isOrderMuted(order.id);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" asChild aria-label="Back to orders">
            <Link to="/admin/orders">
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">
              Order #{String(order.id).slice(0, 8)}
            </h1>
            <p className="text-sm text-muted-foreground">
              Placed {new Date(order.created_at).toLocaleString()}
            </p>
          </div>
          <Badge
            variant="outline"
            className={cn("capitalize", statusStyles[order.status] ?? "bg-accent text-accent-foreground")}
          >
            {String(order.status).replace(/_/g, " ")}
          </Badge>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 rounded-lg border px-3 py-1.5">
            {muted ? (
              <BellOff className="h-4 w-4 text-muted-foreground" />
            ) : (
              <Bell className="h-4 w-4 text-primary" />
            )}
            <Label htmlFor="order-mute" className="text-xs text-muted-foreground">
              {muted ? "Muted" : "Notify me"}
            </Label>
            <Switch id="order-mute" checked={!muted} onCheckedChange={() => toggleOrderMute(order.id)} />
          </div>

          {can("orders.update_status") && (
            <Select value={order.status} onValueChange={updateStatus} disabled={saving}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Update status" />
              </SelectTrigger>
              <SelectContent>
                {STATUS_FLOW.map((s) => (
                  <SelectItem key={s} value={s} className="capitalize">
                    {s.replace(/_/g, " ")}
                  </SelectItem>
                ))}
                {can("orders.cancel") && <SelectItem value="cancelled">Cancelled</SelectItem>}
              </SelectContent>
            </Select>
          )}
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Package className="h-4 w-4 text-primary" /> Items
            </CardTitle>
            <CardDescription>
              {productItems.length} product{productItems.length === 1 ? "" : "s"} in this order
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {productItems.map((item) => (
              <div key={item.id} className="flex items-start justify-between gap-4">
                <div className="min-w-0">
                  <p className="text-sm font-medium">{item.product_name}</p>
                  {item.product_description && (
                    <p className="text-xs text-muted-foreground">{item.product_description}</p>
                  )}
                  <p className="text-xs text-muted-foreground">
                    {item.quantity} × ${Number(item.unit_price).toFixed(2)}
                  </p>
                </div>
                <span className="text-sm font-semibold tabular-nums">
                  ${Number(item.total_price).toFixed(2)}
                </span>
              </div>
            ))}
            {productItems.length === 0 && (
              <p className="text-sm text-muted-foreground">No line items recorded for this order.</p>
            )}

            <Separator />

            <div>
              <p className="mb-2 flex items-center gap-2 text-sm font-medium">
                <Scissors className="h-4 w-4 text-primary" /> Processing choices
              </p>
              {processingItems.length > 0 ? (
                <ul className="space-y-2">
                  {processingItems.map((item) => (
                    <li key={item.id} className="flex items-center justify-between text-sm">
                      <span className="flex items-center gap-2">
                        <Check className="h-3.5 w-3.5 text-primary" />
                        {item.product_name}
                      </span>
                      <span className="tabular-nums">${Number(item.total_price).toFixed(2)}</span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-muted-foreground">
                  No processing add-ons — these only apply to livestock orders.
                </p>
              )}
            </div>

            <Separator />

            <div className="space-y-1 text-sm">
              {order.delivery_fee != null && (
                <div className="flex justify-between text-muted-foreground">
                  <span>Delivery fee</span>
                  <span className="tabular-nums">${Number(order.delivery_fee).toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between font-semibold">
                <span>Total</span>
                <span className="tabular-nums">${Number(order.total_amount ?? 0).toFixed(2)}</span>
              </div>
            </div>

            <Separator />

            <div className="space-y-1 text-sm">
              <div className="flex items-center justify-between">
                <span className="font-semibold">Payment</span>
                <Badge variant={order.payment_status === "paid" ? "default" : "secondary"}>
                  {order.payment_status === "paid" ? "Paid" : "Unpaid"}
                </Badge>
              </div>
              {order.paid_at && (
                <div className="flex justify-between text-muted-foreground">
                  <span>Paid on</span>
                  <span>{new Date(order.paid_at).toLocaleString()}</span>
                </div>
              )}
              {order.amount_paid != null && (
                <div className="flex justify-between text-muted-foreground">
                  <span>Amount charged</span>
                  <span className="tabular-nums">
                    ${Number(order.amount_paid).toFixed(2)} {String(order.currency ?? "usd").toUpperCase()}
                  </span>
                </div>
              )}
              <div className="flex justify-between text-muted-foreground">
                <span>Platform fee</span>
                <span className="tabular-nums">${Number(order.platform_fee ?? 0).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-muted-foreground">
                <span>Farm earnings (payout eligible)</span>
                <span className="tabular-nums">${Number(order.farmer_earnings ?? 0).toFixed(2)}</span>
              </div>
              {order.stripe_payment_intent_id && (
                <div className="flex justify-between text-muted-foreground">
                  <span>Stripe reference</span>
                  <span className="font-mono text-xs">{order.stripe_payment_intent_id}</span>
                </div>
              )}
            </div>

          </CardContent>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                {isPickup ? <Store className="h-4 w-4 text-primary" /> : <Truck className="h-4 w-4 text-primary" />}
                {isPickup ? "Pickup details" : "Delivery details"}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <p className="capitalize">
                <span className="text-muted-foreground">Method: </span>
                {String(order.delivery_type ?? "—").replace(/_/g, " ")}
              </p>
              {isPickup ? (
                <>
                  <p>
                    <span className="text-muted-foreground">Window: </span>
                    {order.pickup_scheduled_at
                      ? `${new Date(order.pickup_scheduled_at).toLocaleString()}${
                          order.pickup_scheduled_end
                            ? ` – ${new Date(order.pickup_scheduled_end).toLocaleTimeString()}`
                            : ""
                        }`
                      : "Not scheduled"}
                  </p>
                  {order.pickup_slot?.location_note && (
                    <p className="flex items-start gap-1.5 text-muted-foreground">
                      <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                      {order.pickup_slot.location_note}
                    </p>
                  )}
                </>
              ) : (
                <>
                  <p className="flex items-start gap-1.5">
                    <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                    {order.delivery_address || "No address on file"}
                  </p>
                  <p>
                    <span className="text-muted-foreground">ETA: </span>
                    {order.delivery_scheduled_at
                      ? `${new Date(order.delivery_scheduled_at).toLocaleString()}${
                          order.delivery_scheduled_end
                            ? ` – ${new Date(order.delivery_scheduled_end).toLocaleTimeString()}`
                            : ""
                        }`
                      : order.estimated_delivery_time || "Not scheduled"}
                  </p>
                  {assignment && (
                    <p className="capitalize">
                      <span className="text-muted-foreground">Driver status: </span>
                      {String(assignment.status).replace(/_/g, " ")}
                    </p>
                  )}
                </>
              )}
              <Separator className="my-2" />
              <p>
                <span className="text-muted-foreground">Customer: </span>
                {order.customer?.full_name || order.customer?.email || "Unknown"}
              </p>
              <p>
                <span className="text-muted-foreground">Farm: </span>
                {order.farmer?.full_name || "—"}
              </p>
              {order.customer_notes && (
                <p className="text-muted-foreground">“{order.customer_notes}”</p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Clock className="h-4 w-4 text-primary" />
                {isPickup ? "Schedule pickup window" : "Schedule delivery window"}
              </CardTitle>
              <CardDescription>
                Times are in your timezone (
                {Intl.DateTimeFormat().resolvedOptions().timeZone}). Saving notifies the farm and
                customer instantly.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="schedule-start" className="text-xs">
                    Window starts
                  </Label>
                  <input
                    id="schedule-start"
                    type="datetime-local"
                    value={scheduleStart}
                    min={nowLocalInput()}
                    onChange={(e) => setScheduleStart(e.target.value)}
                    disabled={!can("orders.update_status")}
                    className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="schedule-end" className="text-xs">
                    Window ends
                  </Label>
                  <input
                    id="schedule-end"
                    type="datetime-local"
                    value={scheduleEnd}
                    min={scheduleStart || nowLocalInput()}
                    onChange={(e) => setScheduleEnd(e.target.value)}
                    disabled={!can("orders.update_status")}
                    className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-50"
                  />
                </div>
              </div>

              {scheduleValidation.error ? (
                <p className="text-xs text-destructive">{scheduleValidation.error}</p>
              ) : (
                scheduleValidation.start && (
                  <p className="text-xs text-muted-foreground">
                    Preview: {formatWindow(scheduleValidation.start, scheduleValidation.end)}
                  </p>
                )
              )}

              {can("orders.update_status") && (
                <div className="flex flex-wrap gap-2">
                  <Button
                    size="sm"
                    onClick={saveSchedule}
                    disabled={savingSchedule || !scheduleValidation.ok}
                  >
                    {savingSchedule && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Save window
                  </Button>
                  {(scheduleStart || scheduleEnd) && (
                    <Button
                      size="sm"
                      variant="ghost"
                      disabled={savingSchedule}
                      onClick={() => {
                        setScheduleStart("");
                        setScheduleEnd("");
                      }}
                    >
                      Clear
                    </Button>
                  )}
                  {previousWindow && (
                    <Button
                      size="sm"
                      variant="outline"
                      disabled={savingSchedule}
                      onClick={undoSchedule}
                    >
                      <Undo2 className="mr-2 h-3.5 w-3.5" />
                      Undo last change
                    </Button>
                  )}
                </div>
              )}

              {previousWindow && (
                <p className="text-xs text-muted-foreground">
                  Undo restores{" "}
                  {formatWindow(previousWindow.start, previousWindow.end) ?? "no scheduled window"} and
                  notifies the farm and customer again.
                </p>
              )}


            </CardContent>
          </Card>


          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Clock className="h-4 w-4 text-primary" /> Timeline
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ol className="relative space-y-4 border-l pl-4">
                {timeline.map((entry, i) => (
                  <li key={`${entry.label}-${i}`} className="relative">
                    <span className="absolute -left-[21px] top-1.5 h-2 w-2 rounded-full bg-primary" />
                    <p className="text-sm font-medium">{entry.label}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(entry.at as string).toLocaleString()}
                    </p>
                    {entry.note && <p className="text-xs text-muted-foreground">{entry.note}</p>}
                  </li>
                ))}
              </ol>
            </CardContent>
          </Card>
        </div>
      </div>

      {can("orders.edit_notes") && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Internal notes</CardTitle>
            <CardDescription>Visible to the farm and admins only.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              placeholder="Add packing, processing or handoff notes…"
            />
            <Button onClick={saveNotes} disabled={saving} size="sm">
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Save notes
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
