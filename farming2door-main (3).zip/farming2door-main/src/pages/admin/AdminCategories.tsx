import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { ArrowDown, ArrowUp, Loader2, Pencil, Plus, Trash2 } from "lucide-react";
import { usePermissions } from "@/hooks/usePermissions";

interface Category {
  id: string;
  name: string;
  description: string | null;
  icon: string | null;
  display_order: number | null;
  is_active: boolean | null;
}

const emptyDraft = { name: "", description: "", icon: "", is_active: true };

export default function AdminCategories() {
  const { can, requirePermission } = usePermissions();
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editing, setEditing] = useState<Category | null>(null);
  const [draft, setDraft] = useState(emptyDraft);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Category | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("categories")
      .select("id, name, description, icon, display_order, is_active")
      .order("display_order", { ascending: true, nullsFirst: false })
      .order("name");
    setLoading(false);
    if (error) {
      toast.error("Could not load categories");
      return;
    }
    setCategories((data as Category[]) ?? []);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const openCreate = () => {
    if (!requirePermission("products.manage")) return;
    setEditing(null);
    setDraft(emptyDraft);
    setDialogOpen(true);
  };

  const openEdit = (category: Category) => {
    if (!requirePermission("products.manage")) return;
    setEditing(category);
    setDraft({
      name: category.name,
      description: category.description ?? "",
      icon: category.icon ?? "",
      is_active: category.is_active ?? true,
    });
    setDialogOpen(true);
  };

  const save = async () => {
    if (!draft.name.trim()) {
      toast.error("Category name is required");
      return;
    }
    setSaving(true);
    const payload = {
      name: draft.name.trim(),
      description: draft.description.trim() || null,
      icon: draft.icon.trim() || null,
      is_active: draft.is_active,
    };

    const { error } = editing
      ? await supabase.from("categories").update(payload).eq("id", editing.id)
      : await supabase
          .from("categories")
          .insert({ ...payload, display_order: categories.length + 1 });

    setSaving(false);
    if (error) {
      toast.error(editing ? "Could not update the category" : "Could not create the category", {
        description: error.message,
      });
      return;
    }
    toast.success(editing ? "Category updated" : "Category created");
    setDialogOpen(false);
    load();
  };

  const toggleActive = async (category: Category) => {
    if (!requirePermission("products.manage")) return;
    const next = !(category.is_active ?? true);
    setCategories((prev) =>
      prev.map((c) => (c.id === category.id ? { ...c, is_active: next } : c))
    );
    const { error } = await supabase
      .from("categories")
      .update({ is_active: next })
      .eq("id", category.id);
    if (error) {
      toast.error("Could not change visibility");
      load();
    }
  };

  const move = async (index: number, direction: -1 | 1) => {
    if (!requirePermission("products.manage")) return;
    const target = index + direction;
    if (target < 0 || target >= categories.length) return;
    const reordered = [...categories];
    [reordered[index], reordered[target]] = [reordered[target], reordered[index]];
    setCategories(reordered);
    const updates = reordered.map((c, i) =>
      supabase.from("categories").update({ display_order: i + 1 }).eq("id", c.id)
    );
    const results = await Promise.all(updates);
    if (results.some((r) => r.error)) {
      toast.error("Could not save the new order");
      load();
    }
  };

  const remove = async () => {
    if (!deleteTarget) return;
    const { error } = await supabase.from("categories").delete().eq("id", deleteTarget.id);
    if (error) {
      toast.error("Could not delete the category", {
        description: "It may still be linked to farms or products — deactivate it instead.",
      });
    } else {
      toast.success("Category deleted");
      load();
    }
    setDeleteTarget(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Product Categories</h1>
          <p className="text-muted-foreground">
            These are the categories farmers pick from during onboarding.
          </p>
        </div>
        {can("products.manage") && (
          <Button onClick={openCreate}>
            <Plus className="mr-2 h-4 w-4" /> New category
          </Button>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All categories</CardTitle>
          <CardDescription>
            {categories.filter((c) => c.is_active !== false).length} active ·{" "}
            {categories.length} total
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
            </div>
          ) : categories.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted-foreground">
              No categories yet. Create the first one so farmers can complete onboarding.
            </p>
          ) : (
            <ul className="divide-y">
              {categories.map((category, index) => (
                <li key={category.id} className="flex items-center gap-3 py-3">
                  <div className="flex flex-col">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-5 w-6"
                      aria-label={`Move ${category.name} up`}
                      disabled={index === 0}
                      onClick={() => move(index, -1)}
                    >
                      <ArrowUp className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-5 w-6"
                      aria-label={`Move ${category.name} down`}
                      disabled={index === categories.length - 1}
                      onClick={() => move(index, 1)}
                    >
                      <ArrowDown className="h-3.5 w-3.5" />
                    </Button>
                  </div>

                  <div className="min-w-0 flex-1">
                    <p className="flex items-center gap-2 text-sm font-medium">
                      {category.icon && <span aria-hidden>{category.icon}</span>}
                      {category.name}
                      {category.is_active === false && (
                        <Badge variant="outline" className="text-[10px]">
                          Hidden
                        </Badge>
                      )}
                    </p>
                    {category.description && (
                      <p className="truncate text-xs text-muted-foreground">
                        {category.description}
                      </p>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <Switch
                      checked={category.is_active !== false}
                      onCheckedChange={() => toggleActive(category)}
                      aria-label={`Toggle ${category.name} visibility`}
                    />
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8"
                      aria-label={`Edit ${category.name}`}
                      onClick={() => openEdit(category)}
                    >
                      <Pencil className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8 text-destructive"
                      aria-label={`Delete ${category.name}`}
                      onClick={() => can("products.manage") && setDeleteTarget(category)}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? "Edit category" : "New category"}</DialogTitle>
            <DialogDescription>
              Categories appear in the farmer onboarding picker and in shop filters.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="category-name">Name</Label>
              <Input
                id="category-name"
                value={draft.name}
                onChange={(e) => setDraft((d) => ({ ...d, name: e.target.value }))}
                placeholder="e.g. Pasture-raised Poultry"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="category-description">Description</Label>
              <Textarea
                id="category-description"
                value={draft.description}
                onChange={(e) => setDraft((d) => ({ ...d, description: e.target.value }))}
                placeholder="Short explanation shown to farmers"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="category-icon">Icon (emoji or name)</Label>
              <Input
                id="category-icon"
                value={draft.icon}
                onChange={(e) => setDraft((d) => ({ ...d, icon: e.target.value }))}
                placeholder="🐔"
              />
            </div>
            <div className="flex items-center justify-between rounded-lg border px-3 py-2">
              <div>
                <p className="text-sm font-medium">Visible to farmers</p>
                <p className="text-xs text-muted-foreground">
                  Hidden categories stay on existing farms but can't be newly selected.
                </p>
              </div>
              <Switch
                checked={draft.is_active}
                onCheckedChange={(v) => setDraft((d) => ({ ...d, is_active: v }))}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={save} disabled={saving}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {editing ? "Save changes" : "Create category"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete "{deleteTarget?.name}"?</AlertDialogTitle>
            <AlertDialogDescription>
              Farms already using this category keep their selection, but it will disappear from the
              onboarding picker. Deactivating is usually safer.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={remove}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
