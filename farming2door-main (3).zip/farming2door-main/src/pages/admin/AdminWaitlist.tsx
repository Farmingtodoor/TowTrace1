import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { BellRing, Loader2, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface WaitlistRow {
  id: string;
  farmer_id: string;
  email: string;
  zip_code: string;
  distance_miles: number | null;
  notes: string | null;
  status: string;
  created_at: string;
}

const AdminWaitlist = () => {
  const { toast } = useToast();
  const [rows, setRows] = useState<WaitlistRow[]>([]);
  const [farmNames, setFarmNames] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [farmFilter, setFarmFilter] = useState<string>("all");
  const [zipFilter, setZipFilter] = useState("");

  const loadWaitlist = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("delivery_waitlist")
      .select("id, farmer_id, email, zip_code, distance_miles, notes, status, created_at")
      .order("created_at", { ascending: false })
      .limit(500);

    if (error) {
      console.error("Failed to load waitlist:", error);
      toast({ title: "Could not load waitlist", description: error.message, variant: "destructive" });
      setLoading(false);
      return;
    }

    const list = (data ?? []) as WaitlistRow[];
    setRows(list);

    const farmerIds = Array.from(new Set(list.map((r) => r.farmer_id)));
    if (farmerIds.length) {
      const { data: profiles } = await supabase
        .from("profiles")
        .select("id, full_name")
        .in("id", farmerIds);
      const map: Record<string, string> = {};
      (profiles ?? []).forEach((p: { id: string; full_name: string | null }) => {
        map[p.id] = p.full_name ?? "Unnamed farm";
      });
      setFarmNames(map);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadWaitlist();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const farms = useMemo(() => {
    const ids = Array.from(new Set(rows.map((r) => r.farmer_id)));
    return ids.map((id) => ({ id, name: farmNames[id] ?? "Unknown farm" }));
  }, [rows, farmNames]);

  const filtered = useMemo(() => {
    const zip = zipFilter.trim();
    return rows.filter((r) => {
      if (farmFilter !== "all" && r.farmer_id !== farmFilter) return false;
      if (zip && !r.zip_code.startsWith(zip)) return false;
      return true;
    });
  }, [rows, farmFilter, zipFilter]);

  const topZips = useMemo(() => {
    const counts: Record<string, number> = {};
    filtered.forEach((r) => {
      counts[r.zip_code] = (counts[r.zip_code] ?? 0) + 1;
    });
    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);
  }, [filtered]);

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <BellRing className="h-7 w-7" />
            Delivery Waitlist
          </h1>
          <p className="text-muted-foreground mt-1">
            Customers who wanted delivery but fell outside a farm's coverage area.
          </p>
        </div>
        <Button variant="outline" onClick={loadWaitlist} disabled={loading}>
          {loading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <RefreshCw className="h-4 w-4 mr-2" />}
          Refresh
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground">Total signups</CardTitle>
          </CardHeader>
          <CardContent className="text-3xl font-bold">{filtered.length}</CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground">Unique ZIPs</CardTitle>
          </CardHeader>
          <CardContent className="text-3xl font-bold">
            {new Set(filtered.map((r) => r.zip_code)).size}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground">Top requested ZIPs</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-1.5">
            {topZips.length === 0 && <span className="text-sm text-muted-foreground">No data yet</span>}
            {topZips.map(([zip, count]) => (
              <Badge key={zip} variant="secondary">
                {zip} · {count}
              </Badge>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Signups</CardTitle>
          <div className="flex flex-wrap gap-3 pt-2">
            <Select value={farmFilter} onValueChange={setFarmFilter}>
              <SelectTrigger className="w-[240px]">
                <SelectValue placeholder="All farms" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All farms</SelectItem>
                {farms.map((f) => (
                  <SelectItem key={f.id} value={f.id}>
                    {f.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Input
              className="w-[180px]"
              placeholder="Filter by ZIP"
              value={zipFilter}
              onChange={(e) => setZipFilter(e.target.value)}
            />
            {(farmFilter !== "all" || zipFilter) && (
              <Button
                variant="ghost"
                onClick={() => {
                  setFarmFilter("all");
                  setZipFilter("");
                }}
              >
                Clear filters
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-10 text-muted-foreground">
              <Loader2 className="h-5 w-5 animate-spin mr-2" /> Loading waitlist…
            </div>
          ) : filtered.length === 0 ? (
            <p className="py-10 text-center text-muted-foreground">No waitlist signups match these filters.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Farm</TableHead>
                    <TableHead>ZIP</TableHead>
                    <TableHead>Distance</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Notes</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((r) => (
                    <TableRow key={r.id}>
                      <TableCell className="whitespace-nowrap">
                        {new Date(r.created_at).toLocaleDateString()}
                      </TableCell>
                      <TableCell>{farmNames[r.farmer_id] ?? "Unknown farm"}</TableCell>
                      <TableCell className="font-medium">{r.zip_code}</TableCell>
                      <TableCell>
                        {r.distance_miles != null ? `${Math.round(r.distance_miles)} mi` : "—"}
                      </TableCell>
                      <TableCell className="max-w-[220px] truncate">{r.email}</TableCell>
                      <TableCell className="max-w-[280px] truncate text-muted-foreground">
                        {r.notes ?? "—"}
                      </TableCell>
                      <TableCell>
                        <Badge variant={r.status === "pending" ? "secondary" : "default"}>{r.status}</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminWaitlist;
