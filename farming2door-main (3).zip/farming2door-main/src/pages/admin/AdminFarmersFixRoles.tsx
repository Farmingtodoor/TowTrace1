import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAdmin } from '@/contexts/AdminContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, UserCheck, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';

interface ApprovedFarmerWithoutRole {
  id: string;
  full_name: string;
  email: string;
  farm_name: string;
  user_id: string;
  approved_at: string;
  has_role: boolean;
}

export default function AdminFarmersFixRoles() {
  const [approvedFarmers, setApprovedFarmers] = useState<ApprovedFarmerWithoutRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [fixing, setFixing] = useState<string[]>([]);
  const { isSuperAdmin } = useAdmin();

  const fetchApprovedFarmersWithoutRoles = async () => {
    try {
      const { data, error } = await supabase
        .from('farmer_applications')
        .select(`
          id,
          full_name,
          email,
          farm_name,
          user_id,
          reviewed_at
        `)
        .eq('status', 'approved');

      if (error) throw error;

      // Check which approved farmers don't have farmer roles
      const farmersWithRoleStatus = await Promise.all(
        (data || []).map(async (farmer) => {
          const { data: roleData, error: roleError } = await supabase
            .from('user_roles')
            .select('id')
            .eq('user_id', farmer.user_id)
            .eq('role', 'farmer')
            .single();

          return {
            ...farmer,
            approved_at: farmer.reviewed_at,
            has_role: !roleError && roleData !== null
          };
        })
      );

      setApprovedFarmers(farmersWithRoleStatus);
    } catch (error) {
      console.error('Error fetching approved farmers:', error);
      toast.error('Failed to load approved farmers');
    } finally {
      setLoading(false);
    }
  };

  const assignFarmerRole = async (userId: string, farmerName: string) => {
    setFixing(prev => [...prev, userId]);
    try {
      const { error } = await supabase
        .from('user_roles')
        .upsert({
          user_id: userId,
          role: 'farmer'
        }, {
          onConflict: 'user_id,role'
        });

      if (error) throw error;

      toast.success(`Farmer role assigned to ${farmerName}`);
      await fetchApprovedFarmersWithoutRoles();
    } catch (error) {
      console.error('Error assigning farmer role:', error);
      toast.error(`Failed to assign farmer role to ${farmerName}`);
    } finally {
      setFixing(prev => prev.filter(id => id !== userId));
    }
  };

  const fixAllMissingRoles = async () => {
    const farmersWithoutRoles = approvedFarmers.filter(f => !f.has_role);
    
    for (const farmer of farmersWithoutRoles) {
      await assignFarmerRole(farmer.user_id, farmer.full_name);
    }
  };

  useEffect(() => {
    if (isSuperAdmin) {
      fetchApprovedFarmersWithoutRoles();
    }
  }, [isSuperAdmin]);

  if (!isSuperAdmin) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
          <p className="text-muted-foreground">Only super admins can access this page.</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const farmersWithoutRoles = approvedFarmers.filter(f => !f.has_role);
  const farmersWithRoles = approvedFarmers.filter(f => f.has_role);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Fix Farmer Roles</h1>
          <p className="text-muted-foreground">
            Assign farmer roles to approved applications that are missing them
          </p>
        </div>
        {farmersWithoutRoles.length > 0 && (
          <Button onClick={fixAllMissingRoles}>
            <UserCheck className="w-4 h-4 mr-2" />
            Fix All Missing Roles ({farmersWithoutRoles.length})
          </Button>
        )}
      </div>

      {farmersWithoutRoles.length > 0 && (
        <Card className="border-orange-200 bg-orange-50">
          <CardHeader>
            <CardTitle className="flex items-center text-orange-800">
              <AlertTriangle className="w-5 h-5 mr-2" />
              Approved Farmers Missing Roles ({farmersWithoutRoles.length})
            </CardTitle>
            <CardDescription className="text-orange-700">
              These farmers have been approved but don't have the farmer role assigned
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {farmersWithoutRoles.map((farmer) => (
                <div key={farmer.id} className="flex items-center justify-between bg-white p-3 rounded-lg">
                  <div>
                    <p className="font-medium">{farmer.full_name}</p>
                    <p className="text-sm text-muted-foreground">{farmer.farm_name}</p>
                    <p className="text-xs text-muted-foreground">{farmer.email}</p>
                  </div>
                  <Button
                    onClick={() => assignFarmerRole(farmer.user_id, farmer.full_name)}
                    disabled={fixing.includes(farmer.user_id)}
                    size="sm"
                  >
                    {fixing.includes(farmer.user_id) ? (
                      <Loader2 className="w-4 h-4 animate-spin mr-1" />
                    ) : (
                      <UserCheck className="w-4 h-4 mr-1" />
                    )}
                    Assign Role
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {farmersWithRoles.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center text-green-700">
              <UserCheck className="w-5 h-5 mr-2" />
              Farmers with Correct Roles ({farmersWithRoles.length})
            </CardTitle>
            <CardDescription>
              These approved farmers have their roles correctly assigned
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {farmersWithRoles.map((farmer) => (
                <div key={farmer.id} className="flex items-center justify-between p-2 rounded">
                  <div>
                    <p className="font-medium">{farmer.full_name}</p>
                    <p className="text-sm text-muted-foreground">{farmer.farm_name}</p>
                  </div>
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                    <UserCheck className="w-3 h-3 mr-1" />
                    Role Assigned
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {approvedFarmers.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground">No approved farmer applications found</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}