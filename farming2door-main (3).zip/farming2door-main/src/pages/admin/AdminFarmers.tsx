import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAdmin } from '@/contexts/AdminContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, Eye, Check, X, Clock, MapPin } from 'lucide-react';
import { toast } from 'sonner';
import { geocodeZipCode } from '@/services/geocodingService';
import { evaluateFarmerCompleteness } from '@/lib/farmerCompleteness';
import { Progress } from '@/components/ui/progress';

interface MissingLocationFarm {
  application_id: string;
  user_id: string;
  farm_name: string;
  farm_address: string;
  status: string;
  city: string | null;
  state: string | null;
  zip_code: string | null;
  created_at: string;
}

function MissingLocationCard({ farm, onSaved }: { farm: MissingLocationFarm; onSaved: () => void }) {
  const [zip, setZip] = useState(farm.zip_code || '');
  const [city, setCity] = useState(farm.city || '');
  const [stateName, setStateName] = useState(farm.state || '');
  const [saving, setSaving] = useState(false);
  const [looking, setLooking] = useState(false);

  const handleZip = async (raw: string) => {
    const next = raw.replace(/\D/g, '').slice(0, 5);
    setZip(next);
    if (next.length !== 5) return;
    setLooking(true);
    const res = await geocodeZipCode(next);
    setLooking(false);
    if (res.success) {
      setCity(res.city);
      setStateName(res.state);
    } else {
      toast.error('ZIP code not found — enter city and state manually');
    }
  };

  const handleSave = async () => {
    if (!city.trim() || !stateName.trim()) {
      toast.error('City and state are required');
      return;
    }
    setSaving(true);
    const { error } = await supabase.rpc('admin_set_farmer_location', {
      _user_id: farm.user_id,
      _city: city.trim(),
      _state: stateName.trim(),
      _zip_code: zip || null,
    });
    setSaving(false);
    if (error) {
      toast.error(error.message || 'Failed to save location');
      return;
    }
    toast.success(`Location saved for ${farm.farm_name}`);
    onSaved();
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-start gap-4">
          <div>
            <CardTitle className="text-lg">{farm.farm_name}</CardTitle>
            <CardDescription>{farm.farm_address}</CardDescription>
          </div>
          <Badge variant="outline" className="shrink-0">
            <MapPin className="w-3 h-3 mr-1" />Missing location
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid md:grid-cols-3 gap-3">
          <div>
            <Label htmlFor={`zip-${farm.application_id}`}>ZIP Code</Label>
            <Input
              id={`zip-${farm.application_id}`}
              value={zip}
              inputMode="numeric"
              placeholder="75212"
              onChange={(e) => handleZip(e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor={`city-${farm.application_id}`}>City</Label>
            <Input
              id={`city-${farm.application_id}`}
              value={city}
              placeholder="Dallas"
              onChange={(e) => setCity(e.target.value)}
            />
          </div>
          <div>
            <Label htmlFor={`state-${farm.application_id}`}>State</Label>
            <Input
              id={`state-${farm.application_id}`}
              value={stateName}
              placeholder="Texas"
              onChange={(e) => setStateName(e.target.value)}
            />
          </div>
        </div>
        <div className="flex items-center justify-between">
          <p className="text-xs text-muted-foreground">
            {looking ? 'Looking up ZIP…' : 'Enter the ZIP code to auto-fill city and state.'}
          </p>
          <Button size="sm" onClick={handleSave} disabled={saving}>
            {saving ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Check className="w-4 h-4 mr-1" />}
            Save location
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}


interface FarmerApplication {
  id: string;
  full_name: string;
  email: string;
  phone?: string;
  farm_name: string;
  farm_address: string;
  farm_size?: string;
  farming_experience?: string;
  farm_description?: string;
  business_registration_number?: string;
  tax_id?: string;
  insurance_details?: string;
  certifications?: string[];
  categories: any;
  subcategories: any;
  processing_methods?: string[];
  status: 'pending' | 'approved' | 'rejected';
  admin_notes?: string;
  created_at: string;
}

export default function AdminFarmers() {
  const [applications, setApplications] = useState<FarmerApplication[]>([]);
  const [missingLocation, setMissingLocation] = useState<MissingLocationFarm[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedApplication, setSelectedApplication] = useState<FarmerApplication | null>(null);
  const [adminNotes, setAdminNotes] = useState('');
  const [updating, setUpdating] = useState(false);
  const { isAdmin, isSuperAdmin } = useAdmin();

  const fetchMissingLocation = async () => {
    const { data, error } = await supabase.rpc('get_farms_missing_location');
    if (error) {
      console.error('Error fetching farms missing location:', error);
      return;
    }
    setMissingLocation((data as MissingLocationFarm[]) || []);
  };

  const fetchApplications = async () => {
    try {
      // Use secure function with audit logging for admin access to sensitive farmer data
      const { data, error } = await supabase.rpc('get_farmer_applications_secure_admin');

      if (error) throw error;
      setApplications(data as FarmerApplication[] || []);
      await fetchMissingLocation();
    } catch (error) {
      console.error('Error fetching applications:', error);
      toast.error('Failed to load farmer applications - admin access required');
    } finally {
      setLoading(false);
    }
  };


  const completenessFor = (application: FarmerApplication) =>
    evaluateFarmerCompleteness(
      application,
      !missingLocation.some((f) => f.application_id === application.id)
    );

  const updateApplicationStatus = async (applicationId: string, status: 'approved' | 'rejected', notes: string) => {
    const target = applications.find((a) => a.id === applicationId);
    if (status === 'approved' && target) {
      const { complete, percent, missing } = completenessFor(target);
      if (!complete) {
        toast.error(`Onboarding is only ${percent}% complete`, {
          description: `Still missing: ${missing.join(', ')}. The farmer must finish these before approval.`,
        });
        return;
      }
    }

    setUpdating(true);
    try {
      // First, get the application to find the user_id (secure access)
      const { data: applications, error: fetchError } = await supabase.rpc(
        'get_farmer_application_secure_admin_only',
        { application_id: applicationId }
      );

      if (fetchError) throw fetchError;
      
      if (!applications || applications.length === 0) {
        throw new Error('Application not found or access denied');
      }

      const application = applications[0];

      // Update the application status (admins have update permissions via RLS)
      const { error: updateError } = await supabase
        .from('farmer_applications')
        .update({
          status,
          admin_notes: notes,
          reviewed_at: new Date().toISOString()
        })
        .eq('id', applicationId);

      if (updateError) throw updateError;

      // If approved, assign farmer role to the user
      if (status === 'approved' && application?.user_id) {
        const { error: roleError } = await supabase
          .from('user_roles')
          .upsert({
            user_id: application.user_id,
            role: 'farmer'
          }, {
            onConflict: 'user_id,role'
          });

        if (roleError) {
          console.error('Error assigning farmer role:', roleError);
          // Still show success for application approval even if role assignment fails
          toast.success(`Application approved successfully, but there was an issue assigning farmer role. Please contact support.`);
        } else {
          toast.success(`${application.farm_name || 'Farm'} approved`, {
            description: 'Onboarding is 100% complete — the farmer is now approved and can sell on Farming2Door.',
          });
        }
      } else {
        toast.success(`Application ${status} successfully`);
      }

      await fetchApplications();
      setSelectedApplication(null);
      setAdminNotes('');
    } catch (error: any) {
      console.error('Error updating application:', error);
      const message = String(error?.message || '');
      if (message.includes('city and a state')) {
        toast.error('This farm cannot be approved yet — the farmer must add a city and state to their profile first.');
      } else {
        toast.error('Failed to update application');
      }

    } finally {
      setUpdating(false);
    }
  };

  useEffect(() => {
    if (isAdmin || isSuperAdmin) {
      fetchApplications();
    }
  }, [isAdmin, isSuperAdmin]);

  if (!isAdmin && !isSuperAdmin) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
          <p className="text-muted-foreground">You don't have permission to view this page.</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      case 'approved':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200"><Check className="w-3 h-3 mr-1" />Approved</Badge>;
      case 'rejected':
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200"><X className="w-3 h-3 mr-1" />Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const pendingApplications = applications.filter(app => app.status === 'pending');
  const reviewedApplications = applications.filter(app => app.status !== 'pending');

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Farmer Applications</h1>
          <p className="text-muted-foreground">
            Review and manage farmer applications for platform access
          </p>
        </div>
      </div>

      <Tabs defaultValue="pending" className="space-y-4">
        <TabsList>
          <TabsTrigger value="pending">
            Pending ({pendingApplications.length})
          </TabsTrigger>
          <TabsTrigger value="reviewed">
            Reviewed ({reviewedApplications.length})
          </TabsTrigger>
          <TabsTrigger value="missing-location">
            Missing location ({missingLocation.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="missing-location" className="space-y-4">
          {missingLocation.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <p className="text-muted-foreground">Every farm has a city and state on file</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              <p className="text-sm text-muted-foreground">
                These farms are hidden from public listings and cannot be approved until a city and state are saved.
              </p>
              {missingLocation.map((farm) => (
                <MissingLocationCard
                  key={farm.application_id}
                  farm={farm}
                  onSaved={fetchMissingLocation}
                />
              ))}
            </div>
          )}
        </TabsContent>


        <TabsContent value="pending" className="space-y-4">
          {pendingApplications.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <p className="text-muted-foreground">No pending applications</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {pendingApplications.map((application) => (
                <Card key={application.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{application.full_name}</CardTitle>
                        <CardDescription>{application.farm_name}</CardDescription>
                      </div>
                      <div className="flex items-center gap-2">
                        {getStatusBadge(application.status)}
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setSelectedApplication(application);
                                setAdminNotes(application.admin_notes || '');
                              }}
                            >
                              <Eye className="w-4 h-4 mr-1" />
                              Review
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                            <DialogHeader>
                              <DialogTitle>Farmer Application Review</DialogTitle>
                              <DialogDescription>
                                Review the application details and approve or reject
                              </DialogDescription>
                            </DialogHeader>
                            
                            {selectedApplication && (
                              <div className="space-y-6">
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <label className="font-semibold">Full Name</label>
                                    <p>{selectedApplication.full_name}</p>
                                  </div>
                                  <div>
                                    <label className="font-semibold">Email</label>
                                    <p>{selectedApplication.email}</p>
                                  </div>
                                  <div>
                                    <label className="font-semibold">Phone</label>
                                    <p>{selectedApplication.phone || 'Not provided'}</p>
                                  </div>
                                  <div>
                                    <label className="font-semibold">Farm Name</label>
                                    <p>{selectedApplication.farm_name}</p>
                                  </div>
                                </div>

                                <div>
                                  <label className="font-semibold">Farm Address</label>
                                  <p>{selectedApplication.farm_address}</p>
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <label className="font-semibold">Farm Size</label>
                                    <p>{selectedApplication.farm_size || 'Not provided'}</p>
                                  </div>
                                  <div>
                                    <label className="font-semibold">Experience</label>
                                    <p>{selectedApplication.farming_experience || 'Not provided'}</p>
                                  </div>
                                </div>

                                {selectedApplication.farm_description && (
                                  <div>
                                    <label className="font-semibold">Farm Description</label>
                                    <p>{selectedApplication.farm_description}</p>
                                  </div>
                                )}

                                {selectedApplication.certifications && selectedApplication.certifications.length > 0 && (
                                  <div>
                                    <label className="font-semibold">Certifications</label>
                                    <div className="flex flex-wrap gap-2 mt-1">
                                      {selectedApplication.certifications.map((cert, index) => (
                                        <Badge key={index} variant="secondary">{cert}</Badge>
                                      ))}
                                    </div>
                                  </div>
                                )}

                                <div>
                                  <label className="font-semibold">Admin Notes</label>
                                  <Textarea
                                    value={adminNotes}
                                    onChange={(e) => setAdminNotes(e.target.value)}
                                    placeholder="Add notes about this application..."
                                    className="mt-1"
                                  />
                                </div>

                                <div className="flex gap-2 justify-end">
                                  <Button
                                    variant="destructive"
                                    onClick={() => updateApplicationStatus(selectedApplication.id, 'rejected', adminNotes)}
                                    disabled={updating}
                                  >
                                    {updating ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <X className="w-4 h-4 mr-1" />}
                                    Reject
                                  </Button>
                                  <Button
                                    onClick={() => updateApplicationStatus(selectedApplication.id, 'approved', adminNotes)}
                                    disabled={updating || !completenessFor(selectedApplication).complete}
                                    title={
                                      completenessFor(selectedApplication).complete
                                        ? 'Approve this farm'
                                        : `Onboarding incomplete: ${completenessFor(selectedApplication).missing.join(', ')}`
                                    }
                                  >
                                    {updating ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Check className="w-4 h-4 mr-1" />}
                                    Approve
                                  </Button>
                                </div>
                              </div>
                            )}
                          </DialogContent>
                        </Dialog>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="text-sm text-muted-foreground">
                      <p><strong>Farm:</strong> {application.farm_name}</p>
                      <p><strong>Location:</strong> {application.farm_address}</p>
                      <p><strong>Applied:</strong> {new Date(application.created_at).toLocaleDateString()}</p>
                    </div>
                    {(() => {
                      const { percent, complete, missing } = completenessFor(application);
                      return (
                        <div className="rounded-md border p-3">
                          <div className="mb-2 flex items-center justify-between text-sm">
                            <span className="font-medium">Onboarding completeness</span>
                            <Badge variant={complete ? 'secondary' : 'destructive'}>{percent}%</Badge>
                          </div>
                          <Progress value={percent} className="h-2" />
                          <p className="mt-2 text-xs text-muted-foreground">
                            {complete
                              ? 'All required details are on file — ready to approve.'
                              : `Missing: ${missing.join(', ')}`}
                          </p>
                        </div>
                      );
                    })()}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="reviewed" className="space-y-4">
          {reviewedApplications.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <p className="text-muted-foreground">No reviewed applications</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {reviewedApplications.map((application) => (
                <Card key={application.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{application.full_name}</CardTitle>
                        <CardDescription>{application.farm_name}</CardDescription>
                      </div>
                      {getStatusBadge(application.status)}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="text-sm text-muted-foreground space-y-1">
                      <p><strong>Farm:</strong> {application.farm_name}</p>
                      <p><strong>Location:</strong> {application.farm_address}</p>
                      <p><strong>Applied:</strong> {new Date(application.created_at).toLocaleDateString()}</p>
                      {application.admin_notes && (
                        <p><strong>Admin Notes:</strong> {application.admin_notes}</p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}