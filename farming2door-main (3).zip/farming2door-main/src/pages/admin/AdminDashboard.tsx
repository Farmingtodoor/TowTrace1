import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useAdmin } from "@/contexts/AdminContext";
import {
  BarChart3,
  Package,
  ShoppingCart,
  Users,
  Mail,
  TrendingUp,
  ArrowRight,
  Plus,
  Settings,
  Store,
  BellRing,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useCallback, useEffect, useState } from "react";
import { useAdminOrderRealtime } from "@/hooks/useAdminOrderRealtime";
import { Radio, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

const statusStyles: Record<string, string> = {
  delivered: "bg-primary/10 text-primary border-primary/20",
  pending: "bg-accent-warm/10 text-accent-warm border-accent-warm/20",
  confirmed: "bg-accent-sage/15 text-accent-foreground border-accent-sage/30",
};

export default function AdminDashboard() {
  const { userRole, isSuperAdmin, isAdmin, isFarmer } = useAdmin();
  const navigate = useNavigate();
  const [stats, setStats] = useState<any[]>([]);
  const [recentActivity, setRecentActivity] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const getRoleDisplay = (role: string) => {
    const roleMap = {
      super_admin: { label: "Super Admin", variant: "destructive" as const },
      admin: { label: "Admin", variant: "default" as const },
      farmer: { label: "Farmer", variant: "secondary" as const },
      customer: { label: "Customer", variant: "outline" as const },
    };
    return roleMap[role as keyof typeof roleMap] || { label: role, variant: "outline" as const };
  };

  const roleInfo = getRoleDisplay(userRole || "customer");

  const fetchDashboardData = useCallback(async () => {
    try {
      setLoading(true);

      const { count: ordersCount } = await supabase
        .from("orders")
        .select("*", { count: "exact", head: true });

      const { count: productsCount } = await supabase
        .from("products")
        .select("*", { count: "exact", head: true });

      const { count: usersCount } = await supabase
        .from("profiles")
        .select("*", { count: "exact", head: true });

      const { count: subscribersCount } = await supabase
        .from("app_notifications")
        .select("*", { count: "exact", head: true });

      const { data: orders } = await supabase
        .from("orders")
        .select("total_amount")
        .eq("status", "delivered");

      const totalRevenue = orders?.reduce((sum, order) => sum + (order.total_amount || 0), 0) || 0;

      const { data: recentOrders } = await supabase
        .from("orders")
        .select(`
          id, status, created_at,
          profiles!orders_customer_id_fkey(full_name, email)
        `)
        .order("created_at", { ascending: false })
        .limit(5);

      const activity =
        recentOrders?.map((order) => ({
          id: order.id,
          message: `Order for ${order.profiles?.full_name || order.profiles?.email || "Unknown customer"}`,
          time: new Date(order.created_at).toLocaleString(),
          status: order.status,
        })) || [];

      setRecentActivity(activity);

      const dashboardStats = [
        {
          title: "Total Orders",
          value: ordersCount?.toString() || "0",
          description: "All time orders",
          icon: ShoppingCart,
          show: isAdmin || isFarmer,
          path: isFarmer ? "/farmer/orders" : "/admin/orders",
        },
        {
          title: "Active Products",
          value: productsCount?.toString() || "0",
          description: "Products in catalog",
          icon: Package,
          show: isAdmin || isFarmer,
          path: isFarmer ? "/farmer-products" : "/admin/products",
        },
        {
          title: "Total Users",
          value: usersCount?.toString() || "0",
          description: "Registered users",
          icon: Users,
          show: isAdmin,
          path: "/admin/users",
        },
        {
          title: "Email Subscribers",
          value: subscribersCount?.toString() || "0",
          description: "Newsletter subscribers",
          icon: Mail,
          show: isAdmin,
          path: "/admin/settings",
        },
        {
          title: "Revenue",
          value: `$${totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
          description: "From delivered orders",
          icon: TrendingUp,
          show: isAdmin,
          path: "/admin/orders",
          highlight: true,
        },
      ].filter((stat) => stat.show);

      setStats(dashboardStats);
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
    } finally {
      setLoading(false);
    }
  }, [isAdmin, isFarmer]);

  useEffect(() => {
    fetchDashboardData();
  }, [fetchDashboardData]);

  const { isLive, lastEventAt } = useAdminOrderRealtime({
    onChange: () => fetchDashboardData(),
  });

  const quickActions = [
    ...(isFarmer
      ? [
          { title: "Add New Product", description: "Create a new product listing", icon: Plus, path: "/farmer-products" },
          { title: "Manage Orders", description: "Update order statuses", icon: ShoppingCart, path: "/farmer/orders" },
          { title: "Delivery Waitlist", description: "See out-of-zone demand", icon: BellRing, path: "/admin/waitlist" },
        ]
      : []),
    ...(isAdmin
      ? [
          { title: "Review Farmers", description: "Approve pending farm applications", icon: Store, path: "/admin/farmers" },
          { title: "User Management", description: "Manage user accounts", icon: Users, path: "/admin/users" },
          { title: "System Settings", description: "Configure application settings", icon: Settings, path: "/admin/settings" },
        ]
      : []),
  ];

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">
            {isFarmer ? "Farm overview" : "Platform overview"}
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Key metrics and recent activity at a glance
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge
            variant="outline"
            className={cn(
              "gap-1.5 text-xs",
              isLive ? "border-primary/30 text-primary" : "text-muted-foreground"
            )}
            title={
              lastEventAt
                ? `Last update ${lastEventAt.toLocaleTimeString()}`
                : isLive
                ? "Connected to live order updates"
                : "Polling for order updates"
            }
          >
            <Radio className={cn("h-3 w-3", isLive && "animate-pulse")} />
            {isLive ? "Live" : "Polling"}
          </Badge>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            aria-label="Refresh dashboard"
            onClick={() => fetchDashboardData()}
          >
            <RefreshCw className={cn("h-4 w-4", loading && "animate-spin")} />
          </Button>
          <Badge variant={roleInfo.variant} className="text-sm">
            {roleInfo.label}
          </Badge>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {loading
          ? Array.from({ length: 3 }).map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader className="pb-2">
                  <div className="h-4 bg-muted rounded w-1/2" />
                </CardHeader>
                <CardContent>
                  <div className="h-8 bg-muted rounded w-1/3 mb-2" />
                  <div className="h-3 bg-muted rounded w-2/3" />
                </CardContent>
              </Card>
            ))
          : stats.map((stat) => (
              <Card
                key={stat.title}
                onClick={() => navigate(stat.path)}
                className={cn(
                  "group cursor-pointer transition-all duration-200 hover:-translate-y-0.5 hover:shadow-[var(--shadow-soft)]",
                  stat.highlight && "border-primary/30 bg-primary/[0.03]"
                )}
              >
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    {stat.title}
                  </CardTitle>
                  <div
                    className={cn(
                      "flex h-8 w-8 items-center justify-center rounded-lg transition-colors",
                      stat.highlight
                        ? "bg-primary text-primary-foreground"
                        : "bg-accent text-accent-foreground group-hover:bg-primary group-hover:text-primary-foreground"
                    )}
                  >
                    <stat.icon className="h-4 w-4" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold tabular-nums">{stat.value}</div>
                  <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                    {stat.description}
                    <ArrowRight className="h-3 w-3 opacity-0 -translate-x-1 transition-all group-hover:opacity-100 group-hover:translate-x-0" />
                  </p>
                </CardContent>
              </Card>
            ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4 text-primary" />
              Recent Activity
            </CardTitle>
            <CardDescription>Latest orders in your system</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-1">
              {loading ? (
                Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="flex items-center space-x-4 p-2 animate-pulse">
                    <div className="w-16 h-5 bg-muted rounded-full" />
                    <div className="flex-1 space-y-1">
                      <div className="h-4 bg-muted rounded w-3/4" />
                      <div className="h-3 bg-muted rounded w-1/2" />
                    </div>
                  </div>
                ))
              ) : recentActivity.length > 0 ? (
                recentActivity.map((activity) => (
                  <div
                    key={activity.id}
                    className="flex items-center gap-3 cursor-pointer hover:bg-muted/60 p-2 rounded-lg transition-colors"
                    onClick={() => navigate(isFarmer ? "/farmer/orders" : "/admin/orders")}
                  >
                    <Badge
                      variant="outline"
                      className={cn(
                        "capitalize text-[11px] shrink-0 w-20 justify-center",
                        statusStyles[activity.status] ?? "bg-muted text-muted-foreground"
                      )}
                    >
                      {activity.status}
                    </Badge>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{activity.message}</p>
                      <p className="text-xs text-muted-foreground">{activity.time}</p>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-sm text-muted-foreground text-center py-6">No recent activity</p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Common administrative tasks</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {quickActions.map((action) => (
                <div
                  key={action.title}
                  className="group flex items-center gap-3 p-3 border rounded-lg hover:border-primary/40 hover:bg-accent/50 cursor-pointer transition-all"
                  onClick={() => navigate(action.path)}
                >
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-accent text-accent-foreground group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                    <action.icon className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{action.title}</p>
                    <p className="text-xs text-muted-foreground">{action.description}</p>
                  </div>
                  <ArrowRight className="h-4 w-4 text-muted-foreground opacity-0 -translate-x-1 transition-all group-hover:opacity-100 group-hover:translate-x-0" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
