import { useState, useEffect } from "react";
import { usePermissions } from "@/hooks/usePermissions";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { DollarSign, Calendar, Clock, CheckCircle, XCircle, User, CreditCard, Download } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { downloadPayoutReceiptPdf, type PayoutReceipt } from "@/lib/payoutReceipt";


interface PayoutRequest {
  id: string;
  farmer_id: string;
  amount: number;
  status: string;
  payment_method: string;
  account_holder_masked: string;  // Changed from bank_account_holder
  account_number_masked: string;  // Changed from bank_account_number  
  additional_notes: string;
  requested_at: string;
  reviewed_at: string | null;
  admin_notes: string | null;
}

interface PayoutRequestWithProfile extends PayoutRequest {
  farmer_name: string;
  farmer_email: string;
}

export default function AdminPayouts() {
  const { user } = useAuth();
  const [payoutRequests, setPayoutRequests] = useState<PayoutRequestWithProfile[]>([]);
  const { requirePermission } = usePermissions();
  const [loading, setLoading] = useState(true);
  const [selectedRequest, setSelectedRequest] = useState<PayoutRequestWithProfile | null>(null);
  const [adminNotes, setAdminNotes] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [sendingId, setSendingId] = useState<string | null>(null);
  const [receipts, setReceipts] = useState<Record<string, PayoutReceipt>>({});

  const fetchReceipts = async () => {
    const { data, error } = await supabase
      .from("payout_receipts")
      .select("*")
      .order("sent_at", { ascending: false });
    if (error) {
      console.error("Error loading payout receipts:", error);
      return;
    }
    const map: Record<string, PayoutReceipt> = {};
    (data || []).forEach((r) => {
      if (!map[r.payout_request_id]) map[r.payout_request_id] = r as unknown as PayoutReceipt;
    });
    setReceipts(map);
  };

  useEffect(() => {
    fetchPayoutRequests();
    fetchReceipts();
  }, []);


  const fetchPayoutRequests = async () => {
    try {
      // Get masked payout data for admin list view (more secure)
      const { data: payoutData, error: payoutError } = await supabase.rpc('get_admin_payout_list');

      if (payoutError) throw payoutError;

      // Get the profiles for all farmers
      const farmerIds = [...new Set(payoutData?.map(p => p.farmer_id) || [])];
      const { data: profileData, error: profileError } = await supabase
        .from("profiles")
        .select("id, full_name, email")
        .in("id", farmerIds);

      if (profileError) throw profileError;

      // Create a map of farmer profiles
      const profileMap = profileData?.reduce((acc, profile) => {
        acc[profile.id] = profile;
        return acc;
      }, {} as Record<string, any>) || {};

      // The payoutData already has masked fields, just add farmer names
      const requestsWithProfiles: PayoutRequestWithProfile[] = (payoutData || []).map(request => ({
        ...request,
        farmer_name: profileMap[request.farmer_id]?.full_name || "Unknown Farmer",
        farmer_email: profileMap[request.farmer_id]?.email || "Unknown Email"
      }));

      setPayoutRequests(requestsWithProfiles);
    } catch (error) {
      console.error("Error fetching payout requests:", error);
      toast.error("Failed to load payout requests");
    } finally {
      setLoading(false);
    }
  };

  const handleReviewRequest = (request: PayoutRequestWithProfile) => {
    setSelectedRequest(request);
    setAdminNotes(request.admin_notes || "");
    setIsDialogOpen(true);
  };

  const handleApprove = async () => {
    if (!requirePermission("payouts.approve")) return;
    if (!selectedRequest) return;

    try {
      const { data, error } = await supabase.rpc('admin_update_payout_status', {
        p_payout_id: selectedRequest.id,
        p_status: 'approved',
        p_admin_notes: adminNotes
      });

      if (error) throw error;

      toast.success("Payout approved", { description: "You can now send it and mark it as paid." });
      setIsDialogOpen(false);
      fetchPayoutRequests();
    } catch (error) {
      console.error("Error approving payout:", error);
      toast.error("Failed to approve payout");
    }
  };

  const handleReject = async () => {
    if (!requirePermission("payouts.approve")) return;
    if (!selectedRequest) return;

    try {
      const { data, error } = await supabase.rpc('admin_update_payout_status', {
        p_payout_id: selectedRequest.id,
        p_status: 'rejected',
        p_admin_notes: adminNotes
      });

      if (error) throw error;

      toast.success("Payout request rejected!");
      setIsDialogOpen(false);
      fetchPayoutRequests();
    } catch (error) {
      console.error("Error rejecting payout:", error);
      toast.error("Failed to reject payout");
    }
  };

  const sendPayout = async (requestId: string) => {
    if (!requirePermission("payouts.approve")) return;
    setSendingId(requestId);
    try {
      const { data, error } = await supabase.functions.invoke("send-farmer-payout", {
        body: { payoutId: requestId },
      });

      if (error || data?.error) {
        throw new Error(data?.error || error?.message || "Payout failed");
      }

      toast.success("Payout sent", {
        description: `Receipt ${data.receipt?.receipt_number} — the farmer has been emailed.`,
      });
      await Promise.all([fetchPayoutRequests(), fetchReceipts()]);
    } catch (error) {
      console.error("Error sending payout:", error);
      toast.error("Payout failed", {
        description: error instanceof Error ? error.message : "Please try again.",
      });
    } finally {
      setSendingId(null);
    }
  };


  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
      case "approved":
        return <Badge variant="default"><CheckCircle className="h-3 w-3 mr-1" />Approved</Badge>;
      case "rejected":
        return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" />Rejected</Badge>;
      case "paid":
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200"><CheckCircle className="h-3 w-3 mr-1" />Paid</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getStats = () => {
    const pending = payoutRequests.filter(r => r.status === "pending").length;
    const approved = payoutRequests.filter(r => r.status === "approved").length;
    const totalPending = payoutRequests
      .filter(r => r.status === "pending")
      .reduce((sum, r) => sum + r.amount, 0);
    
    return { pending, approved, totalPending };
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-32 bg-muted rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const stats = getStats();
  const pendingList = payoutRequests.filter((r) => r.status === "pending");
  const approvedList = payoutRequests.filter((r) => r.status === "approved");
  const historyList = payoutRequests.filter((r) => r.status === "paid" || r.status === "rejected");

  const renderRequest = (request: PayoutRequestWithProfile) => (
    <Card key={request.id}>
      <CardHeader>
        <div className="flex justify-between items-start">
          <div className="space-y-1">
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              ${request.amount.toFixed(2)}
            </CardTitle>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <User className="h-3 w-3" />
              {request.farmer_name || request.farmer_email || "Unknown Farmer"}
            </div>
          </div>
          <div className="flex flex-col items-end gap-2">
            {getStatusBadge(request.status)}
            {request.status === "approved" && (
              <Button
                size="sm"
                onClick={() => sendPayout(request.id)}
                disabled={sendingId === request.id}
                className="h-7"
              >
                <CreditCard className="h-3.5 w-3.5 mr-1" />
                {sendingId === request.id ? "Sending…" : "Send to bank"}
              </Button>
            )}
            {receipts[request.id] && (
              <Button
                size="sm"
                variant="outline"
                className="h-7"
                onClick={() => downloadPayoutReceiptPdf(receipts[request.id], request.farmer_name)}
              >
                <Download className="h-3.5 w-3.5 mr-1" /> Receipt
              </Button>
            )}

          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <div>
            <span className="font-medium">Account Holder:</span>
            <p className="text-muted-foreground">{request.account_holder_masked}</p>
          </div>
          <div>
            <span className="font-medium">Account Number:</span>
            <p className="text-muted-foreground">{request.account_number_masked}</p>
          </div>
          <div>
            <span className="font-medium">Payment Method:</span>
            <p className="text-muted-foreground capitalize">{request.payment_method.replace('_', ' ')}</p>
          </div>
          <div>
            <span className="font-medium">Requested:</span>
            <p className="text-muted-foreground flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              {new Date(request.requested_at).toLocaleDateString()}
            </p>
          </div>
        </div>

        {request.reviewed_at && (
          <p className="text-sm text-muted-foreground">
            Reviewed {new Date(request.reviewed_at).toLocaleString()}
          </p>
        )}

        {request.additional_notes && (
          <div>
            <span className="font-medium">Farmer Notes:</span>
            <p className="text-muted-foreground">{request.additional_notes}</p>
          </div>
        )}

        {request.admin_notes && (
          <div>
            <span className="font-medium">Admin Notes:</span>
            <p className="text-muted-foreground">{request.admin_notes}</p>
          </div>
        )}

        {receipts[request.id] && (
          <div className="rounded-lg border bg-muted/40 p-3 text-sm">
            <p className="font-medium">Receipt {receipts[request.id].receipt_number}</p>
            <p className="text-muted-foreground">
              {receipts[request.id].status === "sent" ? "Transferred" : "Failed"} on{" "}
              {new Date(receipts[request.id].sent_at).toLocaleString()}
              {receipts[request.id].stripe_transfer_id
                ? ` · Ref ${receipts[request.id].stripe_transfer_id}`
                : ""}
            </p>
            {receipts[request.id].failure_reason && (
              <p className="text-destructive">{receipts[request.id].failure_reason}</p>
            )}
          </div>
        )}


        {request.status === "pending" && (
          <div className="flex gap-2 pt-2">
            <Button onClick={() => handleReviewRequest(request)}>Review request</Button>
          </div>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-3xl font-bold">Payout Management</h1>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Requests</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.pending}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Approved Requests</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.approved}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Amount</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${stats.totalPending.toFixed(2)}</div>
          </CardContent>
        </Card>
      </div>

      {/* Payout Requests */}
      <Tabs defaultValue="pending" className="space-y-4">
        <TabsList>
          <TabsTrigger value="pending">Pending ({pendingList.length})</TabsTrigger>
          <TabsTrigger value="approved">Ready to send ({approvedList.length})</TabsTrigger>
          <TabsTrigger value="history">History ({historyList.length})</TabsTrigger>
        </TabsList>

        {([
          ["pending", pendingList, "No payout requests are waiting for review."],
          ["approved", approvedList, "No approved payouts are waiting to be sent."],
          ["history", historyList, "No payouts have been sent or rejected yet."],
        ] as const).map(([value, list, emptyText]) => (
          <TabsContent key={value} value={value} className="space-y-4">
            {list.length === 0 ? (
              <Card>
                <CardContent className="py-8 text-center">
                  <DollarSign className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-semibold mb-2">Nothing here</h3>
                  <p className="text-muted-foreground">{emptyText}</p>
                </CardContent>
              </Card>
            ) : (
              list.map(renderRequest)
            )}
          </TabsContent>
        ))}
      </Tabs>

      {/* Review Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Review Payout Request</DialogTitle>
          </DialogHeader>
          {selectedRequest && (
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium">Amount:</span>
                  <span className="text-lg font-bold">${selectedRequest.amount.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-medium">Farmer:</span>
                  <span>{selectedRequest.farmer_name || selectedRequest.farmer_email}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-medium">Account:</span>
                  <span>{selectedRequest.account_number_masked}</span>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="admin_notes">Admin Notes</Label>
                <Textarea
                  id="admin_notes"
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  placeholder="Add notes about this payout request..."
                  rows={3}
                />
              </div>
              
              <div className="flex gap-2 pt-4">
                <Button onClick={handleApprove} className="flex-1">
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Approve
                </Button>
                <Button onClick={handleReject} variant="destructive" className="flex-1">
                  <XCircle className="h-4 w-4 mr-2" />
                  Reject
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}