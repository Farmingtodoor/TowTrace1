import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useAdmin } from "@/contexts/AdminContext";
import { AddUserDialog } from "@/components/admin/AddUserDialog";
import { EditUserDialog } from "@/components/admin/EditUserDialog";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { UserX, UserCheck } from "lucide-react";

interface User {
  id: string;
  email: string;
  full_name: string | null;
  phone: string | null;
  role: string;
  status: string;
  created_at: string;
}

export default function AdminUsers() {
  const { isSuperAdmin } = useAdmin();
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchUsers = async () => {
    try {
      const { data, error } = await supabase
        .from("profiles")
        .select("id, email, full_name, phone, role, status, created_at")
        .order("created_at", { ascending: false });

      if (error) throw error;
      setUsers(data || []);
    } catch (error: any) {
      toast.error("Failed to fetch users");
      console.error("Error fetching users:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSuspendUser = async (userId: string, currentStatus: string) => {
    try {
      const newStatus = currentStatus === "suspended" ? "active" : "suspended";
      
      const { error } = await supabase
        .from("profiles")
        .update({ status: newStatus })
        .eq("id", userId);

      if (error) throw error;

      toast.success(`User ${newStatus === "suspended" ? "suspended" : "reactivated"} successfully`);
      fetchUsers();
    } catch (error: any) {
      toast.error("Failed to update user status");
      console.error("Error updating user status:", error);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  if (!isSuperAdmin) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
        <p className="text-muted-foreground">You don't have permission to view this page.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">User Management</h1>
          <p className="text-muted-foreground">Manage all system users</p>
        </div>
        <AddUserDialog onUserAdded={fetchUsers} />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Users</CardTitle>
          <CardDescription>View and manage all registered users</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Loading users...</p>
            </div>
          ) : users.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No users found.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {users.map((user) => (
                <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-3">
                      <div>
                        <p className="font-medium">{user.full_name || "No name set"}</p>
                        <p className="text-sm text-muted-foreground">{user.email}</p>
                        {user.phone && (
                          <p className="text-xs text-muted-foreground">{user.phone}</p>
                        )}
                      </div>
                      <Badge variant={
                        user.role === 'super_admin' ? 'default' : 
                        user.role === 'admin' ? 'default' : 
                        user.role === 'farmer' ? 'secondary' : 
                        'outline'
                      }>
                        {user.role.replace('_', ' ')}
                      </Badge>
                      <Badge variant={user.status === 'active' ? 'default' : 'destructive'}>
                        {user.status}
                      </Badge>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <EditUserDialog user={user} onUserUpdated={fetchUsers} />
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleSuspendUser(user.id, user.status)}
                      className={user.status === "suspended" ? "text-green-600 hover:text-green-700" : "text-red-600 hover:text-red-700"}
                    >
                      {user.status === "suspended" ? (
                        <>
                          <UserCheck className="h-4 w-4 mr-1" />
                          Reactivate
                        </>
                      ) : (
                        <>
                          <UserX className="h-4 w-4 mr-1" />
                          Suspend
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}