import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAdmin } from "@/contexts/AdminContext";
import { usePermissions } from "@/hooks/usePermissions";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Shield, Users, UserCog } from "lucide-react";

interface UserWithRole {
  id: string;
  email: string;
  full_name: string | null;
  current_role: string | null;
}

type AppRole = 'customer' | 'farmer' | 'admin' | 'super_admin';

const roleHierarchy: Record<AppRole, number> = {
  'customer': 1,
  'farmer': 2,
  'admin': 3,
  'super_admin': 4
};

const roleColors: Record<AppRole, string> = {
  'customer': 'outline',
  'farmer': 'secondary',
  'admin': 'default',
  'super_admin': 'destructive'
};

export default function AdminRoles() {
  const { isSuperAdmin } = useAdmin();
  const [users, setUsers] = useState<UserWithRole[]>([]);
  const { requirePermission } = usePermissions();
  const [loading, setLoading] = useState(true);
  const [updatingUser, setUpdatingUser] = useState<string | null>(null);

  const fetchUsersWithRoles = async () => {
    try {
      // Get all users with their current highest role
      const { data: usersData, error: usersError } = await supabase
        .from("profiles")
        .select("id, email, full_name")
        .order("created_at", { ascending: false });

      if (usersError) throw usersError;

      // Get roles for each user
      const usersWithRoles: UserWithRole[] = [];
      
      for (const user of usersData || []) {
        const { data: roleData } = await supabase
          .from("user_roles")
          .select("role")
          .eq("user_id", user.id)
          .order("created_at", { ascending: false })
          .limit(1)
          .single();

        usersWithRoles.push({
          ...user,
          current_role: roleData?.role || 'customer'
        });
      }

      setUsers(usersWithRoles);
    } catch (error: any) {
      toast.error("Failed to fetch users and roles");
      console.error("Error fetching users with roles:", error);
    } finally {
      setLoading(false);
    }
  };

  const updateUserRole = async (userId: string, newRole: AppRole) => {
    if (!requirePermission("roles.manage")) return;
    if (updatingUser) return;
    
    setUpdatingUser(userId);
    try {
      // Remove existing roles
      await supabase
        .from("user_roles")
        .delete()
        .eq("user_id", userId);

      // Add new role
      const { error } = await supabase
        .from("user_roles")
        .insert({
          user_id: userId,
          role: newRole
        });

      if (error) throw error;

      // Update profiles table role for consistency
      await supabase
        .from("profiles")
        .update({ role: newRole })
        .eq("id", userId);

      toast.success(`Role updated to ${newRole.replace('_', ' ')}`);
      fetchUsersWithRoles();
    } catch (error: any) {
      toast.error("Failed to update user role");
      console.error("Error updating user role:", error);
    } finally {
      setUpdatingUser(null);
    }
  };

  const getRoleStats = () => {
    const stats = {
      customer: 0,
      farmer: 0,
      admin: 0,
      super_admin: 0
    };

    users.forEach(user => {
      if (user.current_role) {
        stats[user.current_role as AppRole]++;
      }
    });

    return stats;
  };

  useEffect(() => {
    fetchUsersWithRoles();
  }, []);

  if (!isSuperAdmin) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
        <p className="text-muted-foreground">You don't have permission to view this page.</p>
      </div>
    );
  }

  const stats = getRoleStats();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Roles Management</h1>
          <p className="text-muted-foreground">Manage user roles and permissions</p>
        </div>
      </div>

      {/* Role Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Customers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.customer}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Farmers</CardTitle>
            <UserCog className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.farmer}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Admins</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.admin}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Super Admins</CardTitle>
            <Shield className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.super_admin}</div>
          </CardContent>
        </Card>
      </div>

      {/* Users and Roles Management */}
      <Card>
        <CardHeader>
          <CardTitle>User Roles</CardTitle>
          <CardDescription>View and modify user roles and permissions</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Loading users...</p>
            </div>
          ) : users.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No users found.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {users.map((user) => (
                <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-3">
                      <div>
                        <p className="font-medium">{user.full_name || "No name set"}</p>
                        <p className="text-sm text-muted-foreground">{user.email}</p>
                      </div>
                      <Badge variant={roleColors[user.current_role as AppRole] as any}>
                        {user.current_role?.replace('_', ' ')}
                      </Badge>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Select
                      value={user.current_role || 'customer'}
                      onValueChange={(value: AppRole) => updateUserRole(user.id, value)}
                      disabled={updatingUser === user.id}
                    >
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="customer">Customer</SelectItem>
                        <SelectItem value="farmer">Farmer</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                        <SelectItem value="super_admin">Super Admin</SelectItem>
                      </SelectContent>
                    </Select>
                    {updatingUser === user.id && (
                      <div className="text-sm text-muted-foreground">Updating...</div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}