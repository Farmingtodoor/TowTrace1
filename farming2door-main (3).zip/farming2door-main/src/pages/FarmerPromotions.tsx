import { useAuth } from "@/contexts/AuthContext";
import { FarmerDiscountManager } from "@/components/promotions/FarmerDiscountManager";
import { FeaturedServicesManager } from "@/components/FeaturedServicesManager";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Percent, Users, TrendingUp, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

const FarmerPromotions = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md w-full">
          <CardContent className="p-6 text-center">
            <h2 className="text-xl font-semibold mb-2">Access Denied</h2>
            <p className="text-muted-foreground">Please sign in to access promotions management.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="space-y-6">
          {/* Back Button */}
          <Button
            variant="outline"
            onClick={() => navigate(-1)}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>

          {/* Header */}
          <div className="border-b pb-4">
            <h1 className="text-3xl font-bold">Promotions & Discounts</h1>
            <p className="text-muted-foreground mt-2">
              Boost your sales with strategic discounts and promotional campaigns
            </p>
          </div>

          {/* Benefits Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Percent className="w-5 h-5 text-green-600" />
                  Increase Sales
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-sm text-muted-foreground">
                  Attract new customers and encourage larger orders with strategic discounts
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Users className="w-5 h-5 text-blue-600" />
                  Build Loyalty
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-sm text-muted-foreground">
                  Reward repeat customers and create incentives for bulk purchases
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <TrendingUp className="w-5 h-5 text-purple-600" />
                  Clear Inventory
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-sm text-muted-foreground">
                  Move seasonal produce and reduce waste with targeted promotions
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Tips */}
          <Card className="bg-blue-50 border-blue-200">
            <CardHeader>
              <CardTitle className="text-blue-800">💡 Promotion Tips</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-blue-700">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium">Percentage vs Fixed Amount:</h4>
                  <p>Use percentage discounts for higher-priced items, fixed amounts for smaller purchases.</p>
                </div>
                <div>
                  <h4 className="font-medium">Minimum Order Amounts:</h4>
                  <p>Set minimums to encourage larger basket sizes and improve profitability.</p>
                </div>
                <div>
                  <h4 className="font-medium">Limited Time Offers:</h4>
                  <p>Create urgency with expiration dates and limited usage counts.</p>
                </div>
                <div>
                  <h4 className="font-medium">Product-Specific Discounts:</h4>
                  <p>Target slow-moving inventory or promote seasonal items.</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Discount Manager */}
          <FarmerDiscountManager />

          {/* Featured Services Manager */}
          <div className="mt-12">
            <FeaturedServicesManager />
          </div>
        </div>
      </div>
    </div>
  );
};

export default FarmerPromotions;