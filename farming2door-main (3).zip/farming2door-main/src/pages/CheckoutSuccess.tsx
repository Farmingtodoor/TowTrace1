import { useEffect, useState } from "react";
import { useSearchParams, Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, ArrowRight, Home, Receipt } from "lucide-react";
import Header from "@/components/Header";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useCart } from "@/contexts/CartContext";
import { useToast } from "@/hooks/use-toast";

export default function CheckoutSuccess() {
  const [searchParams] = useSearchParams();
  const sessionId = searchParams.get("session_id");
  const [orderDetails, setOrderDetails] = useState<any>(null);
  const [processing, setProcessing] = useState(true);
  const { user } = useAuth();
  const { clearCart } = useCart();
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    if (sessionId && user) {
      processSuccessfulPayment(sessionId);
    } else if (!sessionId) {
      navigate('/');
    }
  }, [sessionId, user]);

  const processSuccessfulPayment = async (sessionId: string) => {
    try {
      setProcessing(true);
      console.log('Starting payment processing for session:', sessionId);
      
      // Call edge function to process the successful payment
      const { data, error } = await supabase.functions.invoke('process-payment-success', {
        body: { sessionId }
      });

      console.log('Payment processing response:', { data, error });

      if (error) throw error;

      setOrderDetails(data);
      
      // Clear cart after successful order processing
      clearCart();
      
      toast({
        title: "Order Created Successfully! 🌾",
        description: `Your order has been created and notifications sent. ${data?.customerNotified ? 'Confirmation email sent!' : 'Email pending...'}`
      });
      
    } catch (error: any) {
      console.error('Error processing payment:', error);
      toast({
        title: "Payment Processing Error",
        description: "There was an issue processing your order. Please contact support with this error: " + (error.message || 'Unknown error'),
        variant: "destructive"
      });
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-2xl mx-auto text-center">
          <Card className="border-green-200 bg-green-50">
            <CardHeader className="text-center">
              <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <CardTitle className="text-2xl text-green-800">
                Payment Successful!
              </CardTitle>
              <CardDescription className="text-green-600">
                Thank you for your order. Your payment has been processed successfully.
              </CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-6">
              {processing ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                  <p className="text-muted-foreground">Processing your order...</p>
                </div>
              ) : (
                <>
                  {sessionId && (
                    <div className="bg-white rounded-lg p-4 border">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                        <Receipt className="w-4 h-4" />
                        Order Confirmation
                      </div>
                      <p className="font-mono text-sm break-all">
                        {sessionId}
                      </p>
                      {orderDetails?.orderId && (
                        <p className="font-mono text-sm mt-2">
                          Order ID: #{orderDetails.orderId.slice(0, 8)}
                        </p>
                      )}
                    </div>
                  )}
                  
                  <div className="text-left space-y-4">
                    <h3 className="font-semibold text-green-800">What's Next?</h3>
                    <div className="space-y-3 text-sm">
                      <div className="flex items-start gap-3">
                        <div className="w-2 h-2 rounded-full bg-green-500 mt-2" />
                        <div>
                          <p className="font-medium">Order Created Successfully</p>
                          <p className="text-muted-foreground">Your order has been created and saved to your account.</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3">
                        <div className="w-2 h-2 rounded-full bg-green-500 mt-2" />
                        <div>
                          <p className="font-medium">Farmer Notification</p>
                          <p className="text-muted-foreground">The farmer has been notified via email and will prepare your order.</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3">
                        <div className="w-2 h-2 rounded-full bg-green-500 mt-2" />
                        <div>
                          <p className="font-medium">Order Status Updates</p>
                          <p className="text-muted-foreground">You can track your order status in "My Orders" and will be contacted for pickup/delivery details.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              )}
              
              <div className="flex flex-col sm:flex-row gap-3 pt-4">
                <Button asChild className="flex-1">
                  <Link to="/">
                    <Home className="w-4 h-4 mr-2" />
                    Back to Home
                  </Link>
                </Button>
                <Button asChild variant="outline" className="flex-1">
                  <Link to="/my-orders">
                    <Receipt className="w-4 h-4 mr-2" />
                    View My Orders
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}