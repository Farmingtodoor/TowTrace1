import { useState } from 'react';
import SEOHead from '@/components/SEOHead';
import AdvancedSearch from '@/components/search/AdvancedSearch';
import SearchResults from '@/components/search/SearchResults';

interface SearchFilters {
  searchTerm: string;
  category: string;
  subcategory: string;
  priceRange: [number, number];
  organicOnly: boolean;
  ratingRange: [number, number];
  inStockOnly: boolean;
  farmerId: string;
  sortBy: string;
  sortOrder: string;
}

const AdvancedBrowse = () => {
  const [searchFilters, setSearchFilters] = useState<SearchFilters>({
    searchTerm: '',
    category: '',
    subcategory: '',
    priceRange: [0, 100],
    organicOnly: false,
    ratingRange: [0, 5],
    inStockOnly: false,
    farmerId: '',
    sortBy: 'created_at',
    sortOrder: 'desc'
  });
  
  const [triggerSearch, setTriggerSearch] = useState(false);
  const [searchLoading, setSearchLoading] = useState(false);

  const handleSearch = (filters: SearchFilters) => {
    setSearchFilters(filters);
    setSearchLoading(true);
    setTriggerSearch(prev => !prev); // Toggle to trigger search
  };

  const handleReset = () => {
    const resetFilters: SearchFilters = {
      searchTerm: '',
      category: '',
      subcategory: '',
      priceRange: [0, 100],
      organicOnly: false,
      ratingRange: [0, 5],
      inStockOnly: false,
      farmerId: '',
      sortBy: 'created_at',
      sortOrder: 'desc'
    };
    setSearchFilters(resetFilters);
    setTriggerSearch(prev => !prev); // Trigger search with reset filters
  };

  const handleSearchComplete = () => {
    setSearchLoading(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title="Advanced Search - Farm2Door"
        description="Find the perfect fresh produce with our advanced search and filtering options. Search by category, price, location, and more."
        keywords="advanced search, fresh produce, farm products, organic food, local farmers, search filters"
      />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto">
          {/* Page Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-foreground mb-4">Advanced Product Search</h1>
            <p className="text-lg text-muted-foreground">
              Discover fresh, local produce with powerful search and filtering options. 
              Find exactly what you're looking for from our network of trusted farmers.
            </p>
          </div>

          {/* Search Interface */}
          <div className="space-y-8">
            <AdvancedSearch
              onSearch={handleSearch}
              onReset={handleReset}
              loading={searchLoading}
            />

            <SearchResults
              filters={searchFilters}
              triggerSearch={triggerSearch}
              onSearchComplete={handleSearchComplete}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdvancedBrowse;