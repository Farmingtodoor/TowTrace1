import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SEOHead from "@/components/SEOHead";

const Terms = () => {
  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title="Terms of Service"
        description="Farm2Door Terms of Service - Learn about our platform rules, user responsibilities, and service agreements for our farm-to-door marketplace."
        keywords="terms of service, user agreement, platform rules, farm2door legal"
      />
      
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto prose prose-lg">
          <h1 className="text-4xl font-bold text-foreground mb-8">Terms of Service</h1>
          
          <p className="text-muted-foreground mb-6">
            <strong>Last updated:</strong> January 2024
          </p>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">1. Acceptance of Terms</h2>
            <p className="text-muted-foreground leading-relaxed">
              By accessing and using Farm2Door, you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by the above, please do not use this service.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">2. Platform Description</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Farm2Door is a marketplace platform that connects consumers with local farmers and food producers. We facilitate transactions but are not directly involved in the production, processing, or delivery of food products.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              All products, services, and delivery arrangements are provided by independent farmers and producers who use our platform.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">3. User Responsibilities</h2>
            <h3 className="text-lg font-semibold text-foreground mb-3">For Customers:</h3>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2 mb-4">
              <li>Provide accurate delivery information and be available for scheduled deliveries</li>
              <li>Inspect products upon delivery and report issues within 24 hours</li>
              <li>Handle and store products according to food safety guidelines</li>
              <li>Pay for orders as agreed and on time</li>
            </ul>

            <h3 className="text-lg font-semibold text-foreground mb-3">For Farmers:</h3>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Maintain all required licenses, certifications, and insurance</li>
              <li>Provide accurate product descriptions and comply with food safety regulations</li>
              <li>Honor delivery commitments and communicate any delays promptly</li>
              <li>Ensure products meet quality standards advertised</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">4. Age Requirements</h2>
            <p className="text-muted-foreground leading-relaxed">
              Users must be at least 18 years old to place orders or register as farmers on our platform. By using our service, you represent that you meet this age requirement.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">5. Payment and Pricing</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              All prices are set by individual farmers and may change without notice. Payment is processed securely through our third-party payment processors.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Platform fees may apply to transactions and will be clearly disclosed during checkout.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">6. Cancellation and Refunds</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Cancellation and refund policies vary by farmer and product type. Generally:
            </p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Orders can typically be cancelled within 24 hours of placement</li>
              <li>Custom processing orders may have different cancellation terms</li>
              <li>Refunds for quality issues must be reported within 24 hours of delivery</li>
              <li>Perishable goods have limited return eligibility</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">7. Liability and Disclaimers</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Farm2Door acts as a marketplace platform and does not produce, process, or directly handle food products. We are not responsible for:
            </p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2 mb-4">
              <li>Product quality, safety, or compliance with regulations</li>
              <li>Delivery delays or issues beyond our direct control</li>
              <li>Farmer compliance with food safety or licensing requirements</li>
              <li>Health issues related to consumption of products</li>
            </ul>
            <p className="text-muted-foreground leading-relaxed">
              Users acknowledge that food products carry inherent risks and agree to use proper food handling and storage practices.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">8. Service Availability</h2>
            <p className="text-muted-foreground leading-relaxed">
              Our service is currently available in select geographic regions. Availability may change without notice, and not all farmers serve all areas.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">9. Intellectual Property</h2>
            <p className="text-muted-foreground leading-relaxed">
              The Farm2Door platform, including its design, functionality, and content, is protected by intellectual property laws. Users may not reproduce, modify, or distribute our content without permission.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">10. Modifications to Terms</h2>
            <p className="text-muted-foreground leading-relaxed">
              We reserve the right to modify these terms at any time. Users will be notified of significant changes, and continued use of the platform constitutes acceptance of modified terms.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">11. Contact Information</h2>
            <p className="text-muted-foreground leading-relaxed">
              For questions about these Terms of Service, please contact us at:
            </p>
            <div className="bg-muted/50 p-4 rounded-lg mt-4">
              <p className="text-muted-foreground">
                <strong>Email:</strong> legal@farm2door.com<br/>
                <strong>Address:</strong> Farm2Door Legal Department<br/>
                123 Agriculture Lane, Farm City, FC 12345
              </p>
            </div>
          </section>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Terms;