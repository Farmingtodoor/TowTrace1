import { ReferralSystem } from "@/components/promotions/ReferralSystem";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Gift, Users, DollarSign, Share2 } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const Referrals = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="py-8 bg-gray-50 min-h-[calc(100vh-64px)]">
        <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Header */}
          <div className="text-center space-y-3">
            <h1 className="text-4xl font-bold text-gray-900">
              Invite Friends, Earn Rewards
            </h1>
            <p className="text-xl text-gray-600">
              Share Farm2Door with friends and earn $10 for every successful referral!
            </p>
          </div>

          {/* How it Works */}
          <Card className="bg-gradient-to-r from-primary/5 to-blue-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gift className="w-6 h-6 text-primary" />
                How the Referral Program Works
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center space-y-3">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                    <Share2 className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">1. Share Your Code</h3>
                    <p className="text-sm text-muted-foreground">
                      Send your unique referral code to friends and family
                    </p>
                  </div>
                </div>

                <div className="text-center space-y-3">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                    <Users className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">2. Friends Get Discount</h3>
                    <p className="text-sm text-muted-foreground">
                      They get 10% off their first order when they use your code
                    </p>
                  </div>
                </div>

                <div className="text-center space-y-3">
                  <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto">
                    <DollarSign className="w-6 h-6 text-yellow-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">3. You Earn Rewards</h3>
                    <p className="text-sm text-muted-foreground">
                      Get $10 credit when they make their first purchase
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Benefits */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <DollarSign className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">No Limits on Earnings</h3>
                    <p className="text-sm text-muted-foreground">
                      Refer as many friends as you want. Each successful referral earns you $10!
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Users className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Help Your Community</h3>
                    <p className="text-sm text-muted-foreground">
                      Share access to fresh, local produce while supporting farmers in your area.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Terms */}
          <Card className="border-orange-200 bg-orange-50">
            <CardContent className="p-4">
              <h4 className="font-medium text-orange-800 mb-2">Terms & Conditions</h4>
              <ul className="text-sm text-orange-700 space-y-1">
                <li>• Referral rewards are credited after your friend's first successful purchase</li>
                <li>• Credits can be used on future orders and don't expire</li>
                <li>• Both you and your friend must be new to Farm2Door or have separate accounts</li>
                <li>• Referral codes are unique and can only be used once per person</li>
                <li>• Farm2Door reserves the right to modify this program at any time</li>
              </ul>
            </CardContent>
          </Card>

          {/* Referral System Component */}
          <ReferralSystem />
        </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Referrals;