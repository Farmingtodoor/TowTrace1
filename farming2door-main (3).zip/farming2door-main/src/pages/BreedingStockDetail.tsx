import { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { useParams, useNavigate } from 'react-router-dom';
import { AuthDialog } from '@/components/auth/AuthDialog';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { toast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { 
  ArrowLeft, 
  MapPin, 
  Calendar, 
  Weight, 
  Heart, 
  Share2, 
  AlertTriangle,
  CheckCircle,
  MessageCircle,
  DollarSign
} from 'lucide-react';

export default function BreedingStockDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  
  const [listing, setListing] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [inquiryMessage, setInquiryMessage] = useState('');
  const [sendingInquiry, setSendingInquiry] = useState(false);

  useEffect(() => {
    if (id) {
      fetchListing();
    }

    // Check for deposit payment success
    const urlParams = new URLSearchParams(window.location.search);
    const depositStatus = urlParams.get('deposit');
    const sessionId = urlParams.get('session_id');

    if (depositStatus === 'success' && sessionId) {
      processDepositSuccess(sessionId);
      // Clean up URL
      window.history.replaceState({}, '', `/breeding-stock/${id}`);
    } else if (depositStatus === 'cancelled') {
      toast({ 
        title: 'Deposit cancelled', 
        description: 'Your deposit payment was cancelled.',
        variant: 'destructive'
      });
      window.history.replaceState({}, '', `/breeding-stock/${id}`);
    }
  }, [id]);

  const processDepositSuccess = async (sessionId: string) => {
    try {
      // Call edge function to process the successful payment
      const { error } = await supabase.functions.invoke('process-breeding-stock-deposit', {
        body: { sessionId },
      });

      if (error) throw error;

      toast({ 
        title: 'Deposit received!', 
        description: 'Your deposit has been processed. The seller will contact you to arrange pickup or delivery.',
      });

      // Refresh listing to show reserved status
      fetchListing();
    } catch (error: any) {
      console.error('Error processing deposit:', error);
      toast({ 
        title: 'Payment received but processing error', 
        description: 'Please contact support if the listing is not reserved.',
        variant: 'destructive'
      });
    }
  };

  const fetchListing = async () => {
    const { data, error } = await supabase
      .from('breeding_stock_listings')
      .select(`
        *,
        breeding_stock_categories(name),
        breeding_stock_breeds(name, type)
      `)
      .eq('id', id)
      .single();

    if (error) {
      toast({ title: 'Error loading listing', variant: 'destructive' });
      navigate('/breeding-stock');
    } else {
      setListing(data);
      // Increment view count
      await supabase
        .from('breeding_stock_listings')
        .update({ views_count: (data.views_count || 0) + 1 })
        .eq('id', id);
    }
    
    setLoading(false);
  };

  const handleSendInquiry = async () => {
    if (!user) {
      toast({ title: 'Please log in to send inquiries', variant: 'destructive' });
      return;
    }

    if (!inquiryMessage.trim()) {
      toast({ title: 'Please enter a message', variant: 'destructive' });
      return;
    }

    setSendingInquiry(true);

    try {
      const { error } = await supabase
        .from('breeding_stock_inquiries')
        .insert({
          listing_id: id,
          buyer_id: user.id,
          seller_id: listing.farmer_id,
          message: inquiryMessage
        });

      if (error) throw error;

      toast({ title: 'Inquiry sent successfully' });
      setInquiryMessage('');
    } catch (error: any) {
      toast({ title: 'Error sending inquiry', description: error.message, variant: 'destructive' });
    } finally {
      setSendingInquiry(false);
    }
  };

  const handleReserveWithDeposit = async () => {
    if (!user) {
      toast({ title: 'Please log in to reserve', variant: 'destructive' });
      return;
    }

    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session) {
        toast({ title: 'Please log in to continue', variant: 'destructive' });
        return;
      }

      // Get user profile for email
      const { data: profile } = await supabase
        .from('profiles')
        .select('email')
        .eq('id', user.id)
        .single();

      const customerEmail = profile?.email || user.email;

      if (!customerEmail) {
        toast({ title: 'Email required', description: 'Please update your profile with an email address', variant: 'destructive' });
        return;
      }

      // Call edge function to create Stripe checkout
      const { data, error } = await supabase.functions.invoke('create-breeding-stock-deposit', {
        body: {
          listingId: id,
          customerEmail,
        },
      });

      if (error) throw error;

      if (data?.url) {
        window.location.href = data.url;
      } else {
        throw new Error('No checkout URL received');
      }
    } catch (error: any) {
      console.error('Deposit reservation error:', error);
      toast({ 
        title: 'Error', 
        description: error.message || 'Failed to process deposit payment',
        variant: 'destructive' 
      });
    }
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  if (!listing) {
    return null;
  }

  const depositAmount = listing.deposit_allowed && listing.deposit_percentage 
    ? (listing.price * listing.deposit_percentage / 100).toFixed(2)
    : null;

  return (
    <>
      <Helmet>
        <title>{listing.title} - Breeding Stock - Farming2Door</title>
      </Helmet>

      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-8 max-w-7xl">
          <Button variant="ghost" onClick={() => navigate('/breeding-stock')} className="mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Listings
          </Button>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Photos */}
              <Card>
                <CardContent className="p-0">
                  <div className="aspect-video bg-muted relative">
                    {listing.photos && listing.photos.length > 0 ? (
                      <img 
                        src={listing.photos[0]} 
                        alt={listing.title}
                        className="w-full h-full object-cover rounded-t-lg"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        No image available
                      </div>
                    )}
                    
                    {listing.registration_number && (
                      <Badge className="absolute top-4 left-4 bg-green-600">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Registered
                      </Badge>
                    )}
                  </div>
                  
                  {listing.photos && listing.photos.length > 1 && (
                    <div className="grid grid-cols-4 gap-2 p-4">
                      {listing.photos.slice(1, 5).map((photo: string, i: number) => (
                        <img 
                          key={i}
                          src={photo}
                          alt={`${listing.title} ${i + 2}`}
                          className="aspect-square object-cover rounded cursor-pointer hover:opacity-75"
                        />
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Details */}
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-2xl">{listing.title}</CardTitle>
                      <p className="text-muted-foreground mt-1">
                        {listing.breeding_stock_breeds?.name} 
                        {listing.breeding_stock_breeds?.type && ` - ${listing.breeding_stock_breeds.type}`}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-3xl font-bold text-primary">
                        ${listing.price.toLocaleString()}
                      </p>
                      {depositAmount && (
                        <p className="text-sm text-muted-foreground">
                          ${depositAmount} deposit
                        </p>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Quick Stats */}
                  <div className="flex flex-wrap gap-2">
                    <Badge variant="outline">{listing.type}</Badge>
                    {listing.sex && <Badge variant="outline">{listing.sex}</Badge>}
                    {listing.age_months && <Badge variant="outline">{listing.age_months} months old</Badge>}
                    {listing.weight_lbs && <Badge variant="outline">{listing.weight_lbs} lbs</Badge>}
                    {listing.breeding_status && (
                      <Badge variant="secondary" className="capitalize">
                        {listing.breeding_status.replace('_', ' ')}
                      </Badge>
                    )}
                  </div>

                  <Separator />

                  {/* Breeding Information */}
                  {(listing.heat_cycle_notes || listing.breeding_guarantee) && (
                    <>
                      <div>
                        <h3 className="font-semibold mb-2">Breeding Information</h3>
                        {listing.heat_cycle_notes && (
                          <p className="text-sm text-muted-foreground mb-2">{listing.heat_cycle_notes}</p>
                        )}
                        {listing.breeding_guarantee && (
                          <div className="bg-green-50 dark:bg-green-950 p-3 rounded-md">
                            <p className="text-sm font-medium text-green-900 dark:text-green-100">
                              Breeding Guarantee: {listing.breeding_guarantee}
                            </p>
                          </div>
                        )}
                      </div>
                      <Separator />
                    </>
                  )}

                  {/* Registration */}
                  {listing.registration_number && (
                    <>
                      <div>
                        <h3 className="font-semibold mb-2">Registration</h3>
                        <p className="text-sm">
                          <span className="text-muted-foreground">Registry:</span> {listing.registry_name}
                        </p>
                        <p className="text-sm">
                          <span className="text-muted-foreground">Number:</span> {listing.registration_number}
                        </p>
                      </div>
                      <Separator />
                    </>
                  )}

                  {/* Health & Handling */}
                  <div>
                    <h3 className="font-semibold mb-2">Health & Handling</h3>
                    {listing.temperament && (
                      <p className="text-sm mb-2">
                        <span className="text-muted-foreground">Temperament:</span> {listing.temperament}
                      </p>
                    )}
                    {listing.handling_notes && (
                      <p className="text-sm mb-2">{listing.handling_notes}</p>
                    )}
                    {listing.biosecurity_notes && (
                      <p className="text-sm text-muted-foreground">{listing.biosecurity_notes}</p>
                    )}
                  </div>

                  <Separator />

                  {/* Transport Options */}
                  <div>
                    <h3 className="font-semibold mb-2">Transport Options</h3>
                    <div className="space-y-1 text-sm">
                      {listing.transport_pickup && <p>✓ Pickup available</p>}
                      {listing.transport_delivery && (
                        <p>✓ Seller delivery available
                          {listing.delivery_mileage_rate && ` ($${listing.delivery_mileage_rate}/mile)`}
                        </p>
                      )}
                      {listing.transport_third_party && <p>✓ Third-party transport arranged</p>}
                    </div>
                  </div>

                  <Separator />

                  {/* Location */}
                  <div>
                    <h3 className="font-semibold mb-2">Location</h3>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="w-4 h-4" />
                      <span>{listing.location_city}, {listing.location_state}</span>
                    </div>
                  </div>

                  {/* Terms */}
                  {listing.return_refund_terms && (
                    <>
                      <Separator />
                      <div>
                        <h3 className="font-semibold mb-2">Return/Refund Terms</h3>
                        <p className="text-sm text-muted-foreground">{listing.return_refund_terms}</p>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              {/* Compliance Warning */}
              <Card className="border-yellow-200 dark:border-yellow-800">
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-yellow-600" />
                    <CardTitle className="text-lg">Compliance Requirements</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="text-sm space-y-2">
                  <p>Before purchasing, ensure you understand your state's requirements for livestock movement:</p>
                  <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                    <li>Certificate of Veterinary Inspection (CVI/health certificate)</li>
                    <li>Brand inspection (if applicable in your state)</li>
                    <li>Official identification tags</li>
                    <li>NPIP certification for poultry</li>
                    <li>Disease testing requirements (TB, Brucellosis, CAE, CL, etc.)</li>
                  </ul>
                  <p className="text-muted-foreground">
                    Buyers are responsible for compliance with all applicable regulations.
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Action Card */}
              <Card>
                <CardHeader>
                  <CardTitle>Interested?</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {listing.status === 'reserved' ? (
                    <div className="bg-yellow-50 dark:bg-yellow-950 p-4 rounded-md text-center">
                      <p className="font-semibold text-yellow-900 dark:text-yellow-100">
                        Currently Reserved
                      </p>
                      <p className="text-sm text-yellow-700 dark:text-yellow-300 mt-1">
                        Contact seller for availability
                      </p>
                    </div>
                  ) : user && user.id !== listing.farmer_id ? (
                    <>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button className="w-full" size="lg">
                            <MessageCircle className="w-4 h-4 mr-2" />
                            Send Inquiry
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Send Inquiry</DialogTitle>
                          </DialogHeader>
                          <div className="space-y-4">
                            <Textarea
                              value={inquiryMessage}
                              onChange={(e) => setInquiryMessage(e.target.value)}
                              placeholder="Ask about availability, health records, transport options..."
                              rows={6}
                            />
                            <Button 
                              onClick={handleSendInquiry}
                              disabled={sendingInquiry}
                              className="w-full"
                            >
                              {sendingInquiry ? 'Sending...' : 'Send Message'}
                            </Button>
                          </div>
                        </DialogContent>
                      </Dialog>

                      {listing.deposit_allowed && depositAmount && (
                        <Button 
                          variant="outline" 
                          className="w-full"
                          onClick={handleReserveWithDeposit}
                        >
                          <DollarSign className="w-4 h-4 mr-2" />
                          Reserve with ${depositAmount} Deposit
                        </Button>
                      )}
                    </>
                  ) : user && user.id === listing.farmer_id ? (
                    <div className="text-center text-muted-foreground">
                      This is your listing
                    </div>
                  ) : (
                    <div className="space-y-2 text-center">
                      <p className="text-sm text-muted-foreground">
                        Sign in to contact this seller
                      </p>
                      <AuthDialog />
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Seller Info */}
              <Card>
                <CardHeader>
                  <CardTitle>Seller Information</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">
                    Contact through the platform messaging system for security and record-keeping.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
