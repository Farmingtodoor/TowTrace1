import { useState, useEffect } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/integrations/supabase/client'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Plus, Calendar, User, Package, ArrowLeft, Home, Check, X, CreditCard } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { format } from 'date-fns'
import { useToast } from '@/hooks/use-toast'
import Header from '@/components/Header'

interface CustomOrder {
  id: string
  farmer_id: string
  status: string
  requested_products: any[]
  requested_delivery_date: string
  proposed_delivery_date: string | null
  customer_notes: string | null
  farmer_notes: string | null
  estimated_total: number | null
  delivery_method: string
  delivery_address: string | null
  delivery_fee: number | null
  created_at: string
  responded_at: string | null
  farmer_name?: string
}

export default function CustomOrders() {
  const { user } = useAuth()
  const { toast } = useToast()
  const navigate = useNavigate()
  const [orders, setOrders] = useState<CustomOrder[]>([])
  const [loading, setLoading] = useState(true)
  const [actionLoading, setActionLoading] = useState(false)

  useEffect(() => {
    if (user) {
      fetchCustomOrders()
    }
  }, [user])

  const fetchCustomOrders = async () => {
    if (!user) return

    const { data, error } = await supabase
      .from('custom_orders')
      .select(`
        id,
        farmer_id,
        status,
        requested_products,
        requested_delivery_date,
        proposed_delivery_date,
        customer_notes,
        farmer_notes,
        estimated_total,
        delivery_method,
        delivery_address,
        delivery_fee,
        created_at,
        responded_at
      `)
      .eq('customer_id', user.id)
      .order('created_at', { ascending: false })

    if (error) {
      console.error('Error fetching custom orders:', error)
      setLoading(false)
      return
    }

    // Fetch farmer names separately
    const farmerIds = [...new Set(data.map(order => order.farmer_id))]
    const { data: farmers } = await supabase
      .from('profiles')
      .select('id, full_name')
      .in('id', farmerIds)

    const farmerMap = farmers?.reduce((acc: any, farmer: any) => {
      acc[farmer.id] = farmer.full_name
      return acc
    }, {}) || {}

    const ordersWithFarmer = data.map(order => ({
      ...order,
      farmer_name: farmerMap[order.farmer_id] || 'Unknown Farmer',
      requested_products: typeof order.requested_products === 'string' 
        ? JSON.parse(order.requested_products) 
        : Array.isArray(order.requested_products) ? order.requested_products : []
    }))
    
    setOrders(ordersWithFarmer)
    setLoading(false)
  }

  const handleCounterProposalResponse = async (orderId: string, action: 'accept' | 'reject') => {
    setActionLoading(true)

    const updateData = {
      status: action === 'accept' ? 'accepted' : 'rejected',
      responded_at: new Date().toISOString()
    }

    const { error } = await supabase
      .from('custom_orders')
      .update(updateData)
      .eq('id', orderId)

    if (error) {
      console.error('Error updating custom order:', error)
      toast({
        title: "Error",
        description: "Failed to update order. Please try again.",
        variant: "destructive"
      })
    } else {
      toast({
        title: "Success",
        description: `Counter-proposal ${action}ed successfully!`,
      })
      fetchCustomOrders()
    }

    setActionLoading(false)
  }

  const handleProceedToPayment = async (order: CustomOrder) => {
    if (!order.estimated_total) {
      toast({
        title: "Error",
        description: "No estimated total available for payment.",
        variant: "destructive"
      })
      return
    }

    try {
      setActionLoading(true)
      
      // Create Stripe checkout session for custom order
      const { data, error } = await supabase.functions.invoke('create-custom-order-checkout', {
        body: {
          orderId: order.id,
          orderType: 'custom_order'
        }
      })

      if (error) throw error

      if (data?.url) {
        // Open Stripe checkout in a new tab
        window.open(data.url, '_blank')
      } else {
        throw new Error('No checkout URL received')
      }
    } catch (error) {
      console.error('Error creating checkout session:', error)
      toast({
        title: "Payment Error",
        description: "Failed to create payment session. Please try again.",
        variant: "destructive"
      })
    } finally {
      setActionLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800'
      case 'accepted':
        return 'bg-green-100 text-green-800'
      case 'rejected':
        return 'bg-red-100 text-red-800'
      case 'counter_proposed':
        return 'bg-blue-100 text-blue-800'
      case 'completed':
        return 'bg-gray-100 text-gray-800'
      case 'cancelled':
        return 'bg-gray-100 text-gray-600'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <p>Please sign in to view your custom orders.</p>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="animate-pulse space-y-4">
          {[1, 2, 3].map(i => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="h-4 bg-muted rounded w-1/4 mb-2"></div>
                <div className="h-4 bg-muted rounded w-1/2"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center gap-4 mb-8">
          <Button variant="outline" size="sm" onClick={() => navigate('/')}>
            <Home className="w-4 h-4 mr-2" />
            Home
          </Button>
          <h1 className="text-3xl font-bold flex-1">My Custom Orders</h1>
          <Button onClick={() => navigate('/custom-orders/new')}>
            <Plus className="w-4 h-4 mr-2" />
            New Custom Order
          </Button>
        </div>

      {orders.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <Package className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">No Custom Orders Yet</h3>
            <p className="text-muted-foreground mb-4">
              Submit your first custom order to a farmer you trust
            </p>
            <Button onClick={() => navigate('/custom-orders/new')}>
              <Plus className="w-4 h-4 mr-2" />
              Create Custom Order
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {orders.map(order => (
            <Card key={order.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="text-lg">
                    Order to {order.farmer_name}
                  </CardTitle>
                  <Badge className={getStatusColor(order.status)}>
                    {order.status.replace('_', ' ').toUpperCase()}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">
                        Requested: {format(new Date(order.requested_delivery_date), 'MMM dd, yyyy')}
                      </span>
                    </div>
                    {order.proposed_delivery_date && (
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-blue-500" />
                        <span className="text-sm text-blue-600">
                          Proposed: {format(new Date(order.proposed_delivery_date), 'MMM dd, yyyy')}
                        </span>
                      </div>
                    )}
                     {order.estimated_total && (
                       <div className="text-sm font-semibold">
                         Est. Total: ${order.estimated_total}
                         {order.delivery_fee && order.delivery_fee > 0 && (
                           <span className="text-xs text-muted-foreground ml-1">
                             (incl. ${order.delivery_fee} delivery)
                           </span>
                         )}
                       </div>
                     )}
                     <div className="text-sm">
                       <span className="font-medium">Delivery:</span> {order.delivery_method === 'pickup' ? 'Pickup at Farm' : 'Home Delivery'}
                     </div>
                  </div>

                  {order.requested_products.length > 0 && (
                    <div>
                      <h4 className="font-semibold mb-2">Requested Products:</h4>
                      <div className="space-y-2">
                        {order.requested_products.map((product: any, index: number) => (
                          <div key={index} className="flex justify-between items-center text-sm bg-muted p-2 rounded">
                            <span>{product.name}</span>
                            <span>{product.quantity} {product.unit || 'units'}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                   {order.delivery_method === 'delivery' && order.delivery_address && (
                     <div>
                       <h4 className="font-semibold mb-1">Delivery Address:</h4>
                       <p className="text-sm text-muted-foreground">{order.delivery_address}</p>
                     </div>
                   )}

                   {order.customer_notes && (
                     <div>
                       <h4 className="font-semibold mb-1">Your Notes:</h4>
                       <p className="text-sm text-muted-foreground">{order.customer_notes}</p>
                     </div>
                   )}

                  {order.farmer_notes && (
                    <div>
                      <h4 className="font-semibold mb-1">Farmer's Response:</h4>
                      <p className="text-sm text-muted-foreground">{order.farmer_notes}</p>
                    </div>
                  )}

                  {/* Counter-proposal actions for customers */}
                  {order.status === 'counter_proposed' && (
                    <div className="flex flex-wrap gap-3 pt-4 border-t">
                      <Button
                        onClick={() => {
                          handleCounterProposalResponse(order.id, 'accept')
                          if (order.estimated_total) {
                            setTimeout(() => handleProceedToPayment(order), 1000)
                          }
                        }}
                        disabled={actionLoading}
                        className="flex items-center gap-2"
                      >
                        <Check className="w-4 h-4" />
                        Accept & Pay
                        {order.estimated_total && ` ($${order.estimated_total})`}
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => handleCounterProposalResponse(order.id, 'reject')}
                        disabled={actionLoading}
                        className="flex items-center gap-2"
                      >
                        <X className="w-4 h-4" />
                        Reject Proposal
                      </Button>
                    </div>
                  )}

                  {/* Proceed to payment for accepted orders */}
                  {order.status === 'accepted' && order.estimated_total && (
                    <div className="flex gap-3 pt-4 border-t">
                      <Button
                        onClick={() => handleProceedToPayment(order)}
                        disabled={actionLoading}
                        className="flex items-center gap-2"
                      >
                        <CreditCard className="w-4 h-4" />
                        Pay Now (${order.estimated_total})
                      </Button>
                    </div>
                  )}

                  <div className="text-xs text-muted-foreground">
                     Submitted: {format(new Date(order.created_at), 'MMM dd, yyyy HH:mm')}
                     {order.responded_at && (
                       <> • Responded: {format(new Date(order.responded_at), 'MMM dd, yyyy HH:mm')}</>
                     )}
                   </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
      </div>
    </div>
  )
}