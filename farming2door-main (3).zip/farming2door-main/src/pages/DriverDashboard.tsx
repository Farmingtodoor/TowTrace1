import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { Truck, MapPin, Clock, DollarSign, Star, Navigation, Phone, ChevronRight, Package, Store, RefreshCw } from "lucide-react";
import { DeliveryMap } from "@/components/DeliveryMap";
import SEOHead from "@/components/SEOHead";
import { cn } from "@/lib/utils";
import { getDrivingRoute, formatDuration } from "@/services/mapboxRoutingService";

interface DriverProfile {
  id: string;
  full_name: string;
  vehicle_type: string;
  license_plate: string;
  is_verified: boolean;
  is_active: boolean;
  status: string;
  rating: number;
  total_deliveries: number;
  current_latitude?: number;
  current_longitude?: number;
}

interface OrderAssignment {
  id: string;
  order_id: string;
  status: string;
  assigned_at: string;
  pickup_latitude?: number;
  pickup_longitude?: number;
  delivery_latitude?: number;
  delivery_longitude?: number;
  driver_earnings: number;
  order: {
    customer_id: string;
    farmer_id: string;
    total_amount: number;
    delivery_address: string;
    customer_notes?: string;
    pickup_latitude?: number;
    pickup_longitude?: number;
    delivery_latitude?: number;
    delivery_longitude?: number;
  };
}

const statusConfig: Record<string, { label: string; color: string; next: string; nextLabel: string }> = {
  assigned: { label: 'New', color: 'bg-blue-100 text-blue-800', next: 'picked_up', nextLabel: 'Pick Up Order' },
  picked_up: { label: 'Picked Up', color: 'bg-amber-100 text-amber-800', next: 'in_transit', nextLabel: 'Start Delivery' },
  in_transit: { label: 'In Transit', color: 'bg-purple-100 text-purple-800', next: 'delivered', nextLabel: 'Complete Delivery' },
};

export default function DriverDashboard() {
  const { user } = useAuth();
  const [driverProfile, setDriverProfile] = useState<DriverProfile | null>(null);
  const [assignments, setAssignments] = useState<OrderAssignment[]>([]);
  const [loading, setLoading] = useState(true);
  const [locationWatch, setLocationWatch] = useState<number | null>(null);
  const [routeInfo, setRouteInfo] = useState<Record<string, { miles: number; minutes: number }>>({});
  const [refreshingRoute, setRefreshingRoute] = useState<Record<string, boolean>>({});

  const refreshRoute = async (a: OrderAssignment) => {
    const pLat = a.pickup_latitude || a.order?.pickup_latitude;
    const pLng = a.pickup_longitude || a.order?.pickup_longitude;
    const dLat = a.delivery_latitude || a.order?.delivery_latitude;
    const dLng = a.delivery_longitude || a.order?.delivery_longitude;
    if (!pLat || !pLng || !dLat || !dLng) {
      toast.error("Missing pickup or delivery coordinates");
      return;
    }
    setRefreshingRoute(prev => ({ ...prev, [a.id]: true }));
    try {
      const r = await getDrivingRoute({ lat: pLat, lng: pLng }, { lat: dLat, lng: dLng }, { force: true });
      if (r.success) {
        setRouteInfo(prev => ({ ...prev, [a.id]: { miles: r.distanceMiles, minutes: r.durationMinutes } }));
        toast.success("Route refreshed");
      } else {
        toast.error(r.error || "Failed to refresh route");
      }
    } finally {
      setRefreshingRoute(prev => ({ ...prev, [a.id]: false }));
    }
  };

  useEffect(() => {
    if (user) fetchDriverData();
  }, [user]);

  // Fetch real driving routes for active assignments
  useEffect(() => {
    assignments.forEach(async (a) => {
      if (routeInfo[a.id]) return;
      const pLat = a.pickup_latitude || a.order?.pickup_latitude;
      const pLng = a.pickup_longitude || a.order?.pickup_longitude;
      const dLat = a.delivery_latitude || a.order?.delivery_latitude;
      const dLng = a.delivery_longitude || a.order?.delivery_longitude;
      if (pLat && pLng && dLat && dLng) {
        const r = await getDrivingRoute({ lat: pLat, lng: pLng }, { lat: dLat, lng: dLng });
        if (r.success) {
          setRouteInfo(prev => ({ ...prev, [a.id]: { miles: r.distanceMiles, minutes: r.durationMinutes } }));
        }
      }
    });
  }, [assignments]);

  const fetchDriverData = async () => {
    try {
      const { data: profile, error: profileError } = await supabase
        .from('driver_profiles')
        .select('*')
        .eq('user_id', user?.id)
        .single();

      if (profileError) throw profileError;
      setDriverProfile(profile as DriverProfile);

      const { data: assignmentsData, error: assignmentsError } = await supabase
        .from('driver_order_assignments')
        .select(`
          *,
          order:orders (
            customer_id,
            farmer_id,
            total_amount,
            delivery_address,
            customer_notes,
            pickup_latitude,
            pickup_longitude,
            delivery_latitude,
            delivery_longitude
          )
        `)
        .eq('driver_id', user?.id)
        .in('status', ['assigned', 'picked_up', 'in_transit'])
        .order('assigned_at', { ascending: false });

      if (assignmentsError) throw assignmentsError;
      setAssignments(
        assignmentsData?.filter((a) => {
          if (!a.order || a.order === null || typeof a.order !== 'object') return false;
          if ('error' in a.order!) return false;
          return true;
        }) as unknown as OrderAssignment[] || []
      );
    } catch (error: any) {
      toast.error(error.message || "Failed to load driver data");
    } finally {
      setLoading(false);
    }
  };

  const updateDriverStatus = async (newStatus: 'online' | 'offline') => {
    if (!driverProfile) return;
    try {
      const { error } = await supabase
        .from('driver_profiles')
        .update({ status: newStatus })
        .eq('user_id', user?.id);
      if (error) throw error;
      setDriverProfile(prev => prev ? { ...prev, status: newStatus } : null);
      if (newStatus === 'online') {
        startLocationTracking();
        toast.success("You're now online and available for deliveries");
      } else {
        stopLocationTracking();
        toast.success("You're now offline");
      }
    } catch (error: any) {
      toast.error(error.message || "Failed to update status");
    }
  };

  const startLocationTracking = () => {
    if (!navigator.geolocation) return;
    const watchId = navigator.geolocation.watchPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        await supabase
          .from('driver_profiles')
          .update({
            current_latitude: latitude,
            current_longitude: longitude,
            last_location_update: new Date().toISOString()
          })
          .eq('user_id', user?.id);
      },
      (error) => {
        console.error("Location tracking error:", error);
        toast.error("Unable to track location. Please enable GPS.");
      },
      { enableHighAccuracy: true, maximumAge: 30000, timeout: 10000 }
    );
    setLocationWatch(watchId);
  };

  const stopLocationTracking = () => {
    if (locationWatch) {
      navigator.geolocation.clearWatch(locationWatch);
      setLocationWatch(null);
    }
  };

  const updateAssignmentStatus = async (assignmentId: string, newStatus: string) => {
    try {
      const updateData: Record<string, string> = { status: newStatus };
      if (newStatus === 'picked_up') updateData.picked_up_at = new Date().toISOString();
      else if (newStatus === 'delivered') updateData.delivered_at = new Date().toISOString();

      const { error } = await supabase
        .from('driver_order_assignments')
        .update(updateData)
        .eq('id', assignmentId);
      if (error) throw error;

      setAssignments(prev =>
        prev.map(a => a.id === assignmentId ? { ...a, status: newStatus } : a)
      );
      toast.success(`Order ${newStatus === 'delivered' ? 'delivered' : 'updated'} successfully!`);
      if (newStatus === 'delivered') fetchDriverData();
    } catch (error: any) {
      toast.error(error.message || "Failed to update order status");
    }
  };

  const openNavigation = (lat: number, lng: number) => {
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`, '_blank');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!driverProfile) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Driver Profile Not Found</CardTitle>
            <CardDescription>Please complete your driver registration first.</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  const isOnline = driverProfile.status === 'online';
  const todaysEarnings = assignments.reduce((sum, a) => sum + Number(a.driver_earnings), 0);

  return (
    <>
      <SEOHead
        title="Driver Dashboard - Farm2Door"
        description="Manage your delivery assignments and track your earnings as a Farm2Door driver."
        keywords="driver dashboard, delivery tracking, driver earnings"
      />
      <div className="min-h-screen bg-background">
        {/* Top Bar */}
        <div className={cn(
          "sticky top-0 z-20 border-b px-4 py-3 transition-colors",
          isOnline ? "bg-emerald-50 border-emerald-200" : "bg-muted border-border"
        )}>
          <div className="container mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={cn(
                "w-3 h-3 rounded-full",
                isOnline ? "bg-emerald-500 animate-pulse" : "bg-muted-foreground/40"
              )} />
              <div>
                <p className="font-semibold text-sm">{driverProfile.full_name}</p>
                <p className="text-xs text-muted-foreground">
                  {driverProfile.vehicle_type} • {driverProfile.license_plate}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              {driverProfile.is_verified ? (
                <Badge variant="secondary" className="text-xs">✓ Verified</Badge>
              ) : (
                <Badge variant="destructive" className="text-xs">Pending</Badge>
              )}
              <div className="flex items-center gap-2">
                <span className="text-xs font-medium">{isOnline ? 'Online' : 'Offline'}</span>
                <Switch
                  checked={isOnline}
                  onCheckedChange={(checked) => updateDriverStatus(checked ? 'online' : 'offline')}
                  disabled={!driverProfile.is_verified}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 py-6 space-y-6">
          {/* Stats Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Card className="bg-primary/5 border-primary/20">
              <CardContent className="p-4 text-center">
                <DollarSign className="h-5 w-5 text-primary mx-auto mb-1" />
                <p className="text-2xl font-bold">${todaysEarnings.toFixed(2)}</p>
                <p className="text-xs text-muted-foreground">Today's Earnings</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <Truck className="h-5 w-5 text-muted-foreground mx-auto mb-1" />
                <p className="text-2xl font-bold">{assignments.length}</p>
                <p className="text-xs text-muted-foreground">Active Orders</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <Star className="h-5 w-5 text-amber-500 mx-auto mb-1" />
                <p className="text-2xl font-bold">{driverProfile.rating?.toFixed(1) || '—'}</p>
                <p className="text-xs text-muted-foreground">Rating</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <Clock className="h-5 w-5 text-muted-foreground mx-auto mb-1" />
                <p className="text-2xl font-bold">{driverProfile.total_deliveries || 0}</p>
                <p className="text-xs text-muted-foreground">Total Deliveries</p>
              </CardContent>
            </Card>
          </div>

          {/* Map */}
          <DeliveryMap
            assignments={assignments}
            driverLocation={
              driverProfile.current_latitude && driverProfile.current_longitude
                ? { lat: driverProfile.current_latitude, lng: driverProfile.current_longitude }
                : undefined
            }
            height="350px"
            showRoute={true}
          />

          {/* Active Orders */}
          <div>
            <h2 className="text-lg font-bold mb-3">Active Deliveries</h2>
            {assignments.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <Truck className="h-10 w-10 text-muted-foreground/40 mx-auto mb-3" />
                  <p className="text-muted-foreground font-medium">
                    {isOnline ? 'Waiting for new orders...' : 'Go online to receive orders'}
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {assignments.map((assignment) => {
                  const config = statusConfig[assignment.status] || statusConfig.assigned;
                  const deliveryLat = assignment.delivery_latitude || assignment.order?.delivery_latitude;
                  const deliveryLng = assignment.delivery_longitude || assignment.order?.delivery_longitude;
                  const pickupLat = assignment.pickup_latitude || assignment.order?.pickup_latitude;
                  const pickupLng = assignment.pickup_longitude || assignment.order?.pickup_longitude;

                  // Determine which location to navigate to based on status
                  const navLat = assignment.status === 'assigned' ? pickupLat : deliveryLat;
                  const navLng = assignment.status === 'assigned' ? pickupLng : deliveryLng;

                  return (
                    <Card key={assignment.id} className="overflow-hidden">
                      <CardContent className="p-0">
                        {/* Order header */}
                        <div className="flex items-center justify-between p-4 pb-2">
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="font-bold">Order #{assignment.order_id.slice(-6)}</p>
                              <Badge className={config.color}>{config.label}</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                              <MapPin className="w-3.5 h-3.5" />
                              {assignment.order.delivery_address}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-lg font-bold text-primary">${Number(assignment.driver_earnings).toFixed(2)}</p>
                            <p className="text-xs text-muted-foreground">earnings</p>
                            {routeInfo[assignment.id] && (
                              <p className="text-[10px] text-muted-foreground mt-1">
                                {routeInfo[assignment.id].miles} mi • {formatDuration(routeInfo[assignment.id].minutes)}
                              </p>
                            )}
                          </div>
                        </div>

                        {assignment.order.customer_notes && (
                          <div className="mx-4 mb-2 p-2 bg-amber-50 border border-amber-200 rounded text-xs text-amber-800">
                            📝 {assignment.order.customer_notes}
                          </div>
                        )}

                        <Separator />

                        {/* Actions */}
                        <div className="flex gap-2 p-3">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => refreshRoute(assignment)}
                            disabled={refreshingRoute[assignment.id]}
                            title="Refresh route"
                            aria-label="Refresh route"
                          >
                            <RefreshCw className={cn("w-4 h-4", refreshingRoute[assignment.id] && "animate-spin")} />
                          </Button>
                          {navLat && navLng && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="flex-1"
                              onClick={() => openNavigation(navLat, navLng)}
                            >
                              <Navigation className="w-4 h-4 mr-1.5" />
                              Navigate
                            </Button>
                          )}
                          <Button
                            size="sm"
                            className="flex-1"
                            onClick={() => updateAssignmentStatus(assignment.id, config.next)}
                          >
                            {config.nextLabel}
                            <ChevronRight className="w-4 h-4 ml-1" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
