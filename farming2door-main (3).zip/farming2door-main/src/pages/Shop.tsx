import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";
import FilterSidebar from "@/components/FilterSidebar";
import SmartRecommendations from "@/components/recommendations/SmartRecommendations";
import { Search, Filter, Loader2, Grid, List, MapPin } from "lucide-react";
import { useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  farmer: string;
  farmer_id: string;
  image_url: string | null;
  unit: string;
  stock_quantity: number;
  is_available: boolean;
  is_organic: boolean;
  harvest_date: string | null;
  expiration_date: string | null;
  created_at: string;
  portion_options?: any;
  processing_addons?: any;
  certifications?: any;
  animal_portion_type?: string;
  next_delivery_date?: string | null;
  farm_distance?: number;
  average_rating?: number;
  review_count?: number;
}

interface Profile {
  id: string;
  city: string | null;
  state: string | null;
  country?: string | null;
  zip_code: string | null;
}

interface FarmerApplication {
  user_id: string;
  farm_name: string;
  farm_description: string;
  general_location: string;
}

import { FeaturedSection } from "@/components/FeaturedSection";

const Shop = () => {
  const [searchParams] = useSearchParams();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [products, setProducts] = useState<Product[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [farmerApplications, setFarmerApplications] = useState<FarmerApplication[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [filters, setFilters] = useState({
    distance: 30,
    deliveryAvailable: false,
    priceRange: [0, 10000] as [number, number],
    certifications: [] as string[],
    animalPortion: [] as string[],
    subcategories: [] as string[]
  });
  const { toast } = useToast();

  // Set initial search term, category, and farmer from URL params
  const [selectedFarmer, setSelectedFarmer] = useState<string | null>(null);
  const [citySearch, setCitySearch] = useState("");
  const [zipcodeSearch, setZipcodeSearch] = useState("");

  useEffect(() => {
    const searchParam = searchParams.get('search');
    const categoryParam = searchParams.get('category');
    const farmerParam = searchParams.get('farmer');
    const cityParam = searchParams.get('city');
    const zipcodeParam = searchParams.get('zipcode');
    
    console.log('URL params:', { searchParam, categoryParam, farmerParam, cityParam, zipcodeParam });
    
    if (searchParam) {
      setSearchTerm(searchParam);
    }
    if (cityParam) {
      setCitySearch(cityParam);
    }
    if (zipcodeParam) {
      setZipcodeSearch(zipcodeParam);
    }
    if (categoryParam) {
      // Convert URL-friendly category back to original format
      const originalCategory = categoryParam
        .split('-')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ')
        .replace('And', '&');
      
      console.log('Converted category:', originalCategory);
      setSelectedCategory(originalCategory.toLowerCase());
    }
    if (farmerParam) {
      setSelectedFarmer(decodeURIComponent(farmerParam));
    }
  }, [searchParams]);

  const fetchProducts = async () => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('is_available', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProducts(data || []);
    } catch (error) {
      console.error('Error fetching products:', error);
      toast({
        title: "Error",
        description: "Failed to load products",
        variant: "destructive",
      });
    }
  };

  const fetchProfiles = async () => {
    try {
      const { data: approved, error: approvedError } = await supabase
        .rpc('get_approved_farmers_public');

      if (approvedError) throw approvedError;

      const farmerIds = (approved || []).map((f: any) => f.user_id).filter(Boolean);
      if (farmerIds.length === 0) {
        setProfiles([]);
        return;
      }

      const { data, error } = await supabase
        .rpc('get_farmer_public_locations', { _user_ids: farmerIds });

      if (error) throw error;
      setProfiles((data as any) || []);
    } catch (error) {
      console.error('Error fetching farm locations:', error);
    }
  };

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('categories')
        .select('name')
        .eq('is_active', true)
        .order('display_order', { ascending: true });

      if (error) throw error;
      setCategories(data?.map(cat => cat.name) || []);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const fetchFarmerApplications = async () => {
    try {
      const { data, error } = await supabase
        .rpc('get_approved_farmers_public');

      if (error) throw error;
      
      // Map the function result to the expected format
      const mappedData = data?.map((farmer: any) => ({
        user_id: farmer.user_id,
        farm_name: farmer.farm_name,
        farm_description: farmer.farm_description || '',
        general_location: farmer.general_location
      })) || [];
      
      setFarmerApplications(mappedData);
    } catch (error) {
      console.error('Error fetching farmer applications:', error);
    }
  };

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await Promise.all([fetchProducts(), fetchProfiles(), fetchCategories(), fetchFarmerApplications()]);
      setLoading(false);
    };

    loadData();
  }, []);

  const getFarmName = (farmerId: string) => {
    const farmerApp = farmerApplications.find(app => app.user_id === farmerId);
    if (farmerApp) {
      return farmerApp.farm_name;
    }
    return 'Local Farm';
  };

  const getFarmerLocation = (farmerId: string) => {
    // First try to get location from profile
    const profile = profiles.find(p => p.id === farmerId);
    if (profile?.city && profile?.state) {
      return `${profile.city}, ${profile.state}`;
    } else if (profile?.city) {
      return profile.city;
    } else if (profile?.state) {
      return profile.state;
    }
    
    // Try to extract city and state from farmer application data
    const farmerApp = farmerApplications.find(app => app.user_id === farmerId);
    if (farmerApp) {
      // First check if general_location has useful info (not generic)
      if (farmerApp.general_location && farmerApp.general_location !== 'General Area' && farmerApp.general_location !== 'Local Area') {
        return farmerApp.general_location;
      }
      
      // Try to extract location from farm description - look for patterns like TX-7398476, "City, ST", etc.
      if (farmerApp.farm_description) {
        // Look for state code patterns like TX-123456
        const stateCodeMatch = farmerApp.farm_description.match(/([A-Z]{2})-\d+/);
        if (stateCodeMatch) {
          return stateCodeMatch[1];
        }
        
        // Look for "City, State" patterns
        const cityStateMatch = farmerApp.farm_description.match(/([A-Za-z\s]+),\s*([A-Z]{2})/);
        if (cityStateMatch) {
          const city = cityStateMatch[1].trim();
          const state = cityStateMatch[2].trim();
          return `${city}, ${state}`;
        }
        
        // Look for standalone state abbreviations
        const stateMatch = farmerApp.farm_description.match(/\b([A-Z]{2})\b/);
        if (stateMatch) {
          return stateMatch[1];
        }
      }
      
      // If farm name contains location info
      const farmNameStateMatch = farmerApp.farm_name?.match(/([A-Za-z\s]+),\s*([A-Z]{2})/);
      if (farmNameStateMatch) {
        const city = farmNameStateMatch[1].trim();
        const state = farmNameStateMatch[2].trim();
        return `${city}, ${state}`;
      }
    }
    
    return 'Location not specified';
  };

  const filteredProducts = products.filter(product => {
    const farmName = getFarmName(product.farmer_id);
    
    // Handle city search
    if (citySearch.trim()) {
      const profile = profiles.find(p => p.id === product.farmer_id);
      const farmerCity = profile?.city?.toLowerCase() || '';
      if (!farmerCity.includes(citySearch.toLowerCase())) {
        return false;
      }
    }
    
    // Handle zipcode search
    if (zipcodeSearch.trim()) {
      const profile = profiles.find(p => p.id === product.farmer_id);
      const farmerZip = profile?.zip_code || '';
      if (!farmerZip.includes(zipcodeSearch)) {
        return false;
      }
    }
    
    // If a specific farmer is selected, filter by that farmer first
    if (selectedFarmer) {
      const matchesFarmer = farmName.toLowerCase() === selectedFarmer.toLowerCase();
      if (!matchesFarmer) return false;
    }
    
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.farmer.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         farmName.toLowerCase().includes(searchTerm.toLowerCase());
    
    console.log('Filtering - Selected category:', selectedCategory, 'Product category:', product.category);
    const matchesCategory = selectedCategory === "all" || product.category.toLowerCase() === selectedCategory.toLowerCase();
    
    // Apply additional filters
    const matchesDistance = !product.farm_distance || (product.farm_distance * 0.621371) <= filters.distance;
    const matchesDelivery = !filters.deliveryAvailable || (product.next_delivery_date !== null);
    const matchesPrice = product.price >= filters.priceRange[0] && product.price <= filters.priceRange[1];
    
    let matchesCertifications = true;
    if (filters.certifications.length > 0) {
      const productCerts = (product.certifications as string[]) || [];
      matchesCertifications = filters.certifications.some(cert => 
        productCerts.includes(cert) || (cert === 'organic' && product.is_organic)
      );
    }
    
    let matchesPortion = true;
    if (filters.animalPortion.length > 0 && product.category.toLowerCase() === 'meat') {
      const portionOptions = (product.portion_options as string[]) || ['whole'];
      matchesPortion = filters.animalPortion.some(portion => portionOptions.includes(portion));
    }

    let matchesSubcategory = true;
    if (filters.subcategories.length > 0) {
      // Note: You may need to add subcategory info to the product data
      // For now, this assumes the product description or name contains subcategory info
      matchesSubcategory = filters.subcategories.some(subcategory => 
        product.name.toLowerCase().includes(subcategory.toLowerCase()) ||
        (product.description && product.description.toLowerCase().includes(subcategory.toLowerCase()))
      );
    }
    
    return matchesSearch && matchesCategory && matchesDistance && matchesDelivery && 
           matchesPrice && matchesCertifications && matchesPortion && matchesSubcategory;
  });

  // Separate featured and non-featured products for display
  const [featuredProductIds, setFeaturedProductIds] = useState<string[]>([]);
  
  useEffect(() => {
    const loadFeaturedProducts = async () => {
      try {
        const { data, error } = await supabase.rpc('get_featured_items', {
          feature_type_param: 'product'
        });
        
        if (!error && data) {
          const featuredIds = data.map((item: any) => item.item_id).filter(Boolean);
          setFeaturedProductIds(featuredIds);
        }
      } catch (error) {
        console.error('Error loading featured products:', error);
      }
    };

    loadFeaturedProducts();
  }, []);

  // Sort products to show featured ones first
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    const aIsFeatured = featuredProductIds.includes(a.id);
    const bIsFeatured = featuredProductIds.includes(b.id);
    if (aIsFeatured && !bIsFeatured) return -1;
    if (!aIsFeatured && bIsFeatured) return 1;
    return 0;
  });

  // Get suggestions - similar products from other farmers
  const suggestedProducts = selectedFarmer ? products.filter(product => {
    const farmName = getFarmName(product.farmer_id);
    const isDifferentFarmer = farmName.toLowerCase() !== selectedFarmer.toLowerCase();
    
    if (!isDifferentFarmer) return false;
    
    // Find products with similar names or same category from different farmers
    const farmerProducts = filteredProducts;
    const hasSimilarProduct = farmerProducts.some(fp => {
      const similarity = fp.name.toLowerCase().includes(product.name.toLowerCase().split(' ')[0]) ||
                        product.name.toLowerCase().includes(fp.name.toLowerCase().split(' ')[0]) ||
                        fp.category === product.category;
      return similarity;
    });
    
    return hasSimilarProduct && product.is_available && product.stock_quantity > 0;
  }).slice(0, 6) : [];

  const clearAllFilters = () => {
    setFilters({
      distance: 30,
      deliveryAvailable: false,
      priceRange: [0, 10000],
      certifications: [],
      animalPortion: [],
      subcategories: []
    });
    setSearchTerm("");
    setCitySearch("");
    setZipcodeSearch("");
    setSelectedCategory("all");
    setSelectedFarmer(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-center min-h-96">
            <Loader2 className="h-8 w-8 animate-spin" />
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Filters */}
          {showFilters && (
            <div className="lg:w-80">
              <FilterSidebar
                filters={filters}
                onFiltersChange={setFilters}
                onClearFilters={clearAllFilters}
              />
            </div>
          )}
          
          {/* Main Content */}
          <div className="flex-1">
            {/* Featured Section */}
            <div className="mb-8">
              <FeaturedSection />
            </div>

            <div className="mb-8">
              <h1 className="text-4xl font-bold text-foreground mb-4">
                {selectedFarmer ? `Products from ${selectedFarmer}` : 'Shop Products'}
              </h1>
              <p className="text-lg text-muted-foreground">
                {selectedFarmer 
                  ? `Fresh products directly from ${selectedFarmer}` 
                  : 'Discover fresh, high-quality products from local farmers and producers'
                }
              </p>
              {selectedFarmer && (
                <Button 
                  variant="outline" 
                  onClick={() => setSelectedFarmer(null)}
                  className="mt-2"
                >
                  View All Farmers
                </Button>
              )}
            </div>

            {/* Search and Filter Section */}
            <div className="bg-card rounded-lg p-6 mb-8 shadow-soft">
              <div className="flex flex-col md:flex-row gap-4 mb-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    placeholder="Search products or farmers..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <div className="relative flex-1">
                  <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    placeholder="Search by city..."
                    value={citySearch}
                    onChange={(e) => setCitySearch(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <div className="relative flex-1">
                  <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    placeholder="Search by zip code..."
                    value={zipcodeSearch}
                    onChange={(e) => setZipcodeSearch(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-full md:w-48">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map(category => (
                      <SelectItem key={category} value={category.toLowerCase()}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  variant={showFilters ? "default" : "outline"}
                  onClick={() => setShowFilters(!showFilters)}
                  className="flex items-center gap-2"
                >
                  <Filter className="h-4 w-4" />
                  {showFilters ? "Hide" : "Show"} Filters
                </Button>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex gap-2 flex-wrap">
                  {searchTerm && (
                    <Badge variant="default" className="flex items-center gap-2">
                      Search: {searchTerm}
                      <button onClick={() => setSearchTerm("")} className="ml-1 hover:bg-white/20 rounded-full p-0.5">
                        ×
                      </button>
                    </Badge>
                  )}
                  {citySearch && (
                    <Badge variant="default" className="flex items-center gap-2">
                      <MapPin className="h-3 w-3" />
                      City: {citySearch}
                      <button onClick={() => setCitySearch("")} className="ml-1 hover:bg-white/20 rounded-full p-0.5">
                        ×
                      </button>
                    </Badge>
                  )}
                  {zipcodeSearch && (
                    <Badge variant="default" className="flex items-center gap-2">
                      <MapPin className="h-3 w-3" />
                      Zip: {zipcodeSearch}
                      <button onClick={() => setZipcodeSearch("")} className="ml-1 hover:bg-white/20 rounded-full p-0.5">
                        ×
                      </button>
                    </Badge>
                  )}
                  {selectedFarmer && (
                    <Badge variant="default" className="flex items-center gap-2">
                      Farmer: {selectedFarmer}
                      <button onClick={() => setSelectedFarmer(null)} className="ml-1 hover:bg-white/20 rounded-full p-0.5">
                        ×
                      </button>
                    </Badge>
                  )}
                  {(searchTerm || citySearch || zipcodeSearch || selectedFarmer) && (
                    <Button variant="ghost" size="sm" onClick={clearAllFilters} className="h-6">
                      Clear All
                    </Button>
                  )}
                  {!searchTerm && !citySearch && !zipcodeSearch && !selectedFarmer && (
                    <>
                      <Badge variant="secondary">Fresh & Local</Badge>
                      <Badge variant="secondary">Organic Options</Badge>
                      <Badge variant="secondary">Free Delivery</Badge>
                    </>
                  )}
                </div>
                
                <div className="flex items-center gap-2">
                  <Button
                    variant={viewMode === 'grid' ? "default" : "outline"}
                    size="sm"
                    onClick={() => setViewMode('grid')}
                  >
                    <Grid className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewMode === 'list' ? "default" : "outline"}
                    size="sm"
                    onClick={() => setViewMode('list')}
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Results */}
            <div className="mb-6">
              <h2 className="text-2xl font-semibold text-foreground">
                {selectedFarmer 
                  ? `${filteredProducts.length} Products from ${selectedFarmer}`
                  : `${filteredProducts.length} Products Found`
                }
              </h2>
            </div>

            {/* Product Grid */}
            <div className={`grid gap-6 ${viewMode === 'grid' ? 'md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3' : 'grid-cols-1'}`}>
              {filteredProducts.map((product) => (
                <ProductCard 
                  key={product.id} 
                  id={product.id}
                  name={product.name}
                  farmer={getFarmName(product.farmer_id)}
                  location={getFarmerLocation(product.farmer_id)}
                  price={`$${product.price}`}
                  rating={product.average_rating || 4.5}
                  reviewCount={product.review_count || Math.floor(Math.random() * 100) + 10}
                  image={product.image_url || "/placeholder.svg"}
                  images={(product as any).images || []}
                  videos={(product as any).videos || []}
                  category={product.category}
                  isOrganic={product.is_organic}
                  inStock={product.stock_quantity > 0}
                  distance={product.farm_distance ? (product.farm_distance * 0.621371) : undefined}
                  nextDeliveryDay={product.next_delivery_date ? 
                    new Date(product.next_delivery_date).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }) : 
                    undefined}
                  unit={product.unit}
                  certifications={(product.certifications as string[]) || (product.is_organic ? ['Organic'] : [])}
                  deliveryAvailable={product.next_delivery_date !== null}
                  farmerId={product.farmer_id}
                />
              ))}
            </div>

            {sortedProducts.length === 0 && (
              <div className="text-center py-12">
                <p className="text-lg text-muted-foreground mb-4">
                  {selectedFarmer 
                    ? `No products available from ${selectedFarmer} at the moment.`
                    : 'No products found matching your criteria.'
                  }
                </p>
                <Button 
                  variant="outline" 
                  onClick={clearAllFilters}
                >
                  {selectedFarmer ? 'View All Products' : 'Clear All Filters'}
                </Button>
              </div>
            )}

            {/* Suggestions Section */}
            {selectedFarmer && suggestedProducts.length > 0 && (
              <div className="mt-12">
                <div className="mb-6">
                  <h2 className="text-2xl font-semibold text-foreground mb-2">
                    Similar Products from Other Farmers
                  </h2>
                  <p className="text-muted-foreground">
                    You might also like these products from other local farmers
                  </p>
                </div>
                
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3">
                  {suggestedProducts.map((product) => (
                    <ProductCard 
                      key={product.id} 
                      id={product.id}
                      name={product.name}
                      farmer={getFarmName(product.farmer_id)}
                      location={getFarmerLocation(product.farmer_id)}
                      price={`$${product.price}`}
                      rating={product.average_rating || 4.5}
                      reviewCount={product.review_count || Math.floor(Math.random() * 100) + 10}
                      image={product.image_url || "/placeholder.svg"}
                      images={(product as any).images || []}
                      videos={(product as any).videos || []}
                      category={product.category}
                      isOrganic={product.is_organic}
                      inStock={product.stock_quantity > 0}
                      distance={product.farm_distance ? (product.farm_distance * 0.621371) : undefined}
                      nextDeliveryDay={product.next_delivery_date ? 
                        new Date(product.next_delivery_date).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }) : 
                        undefined}
                      unit={product.unit}
                      certifications={(product.certifications as string[]) || (product.is_organic ? ['Organic'] : [])}
                      deliveryAvailable={product.next_delivery_date !== null}
                      farmerId={product.farmer_id}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Smart Recommendations */}
        <div className="mt-8">
          <SmartRecommendations />
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Shop;