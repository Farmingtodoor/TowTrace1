import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { XCircle, ArrowLeft, ShoppingCart } from "lucide-react";
import Header from "@/components/Header";

export default function CheckoutCancelled() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-2xl mx-auto text-center">
          <Card className="border-orange-200 bg-orange-50">
            <CardHeader className="text-center">
              <div className="mx-auto w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mb-4">
                <XCircle className="w-8 h-8 text-orange-600" />
              </div>
              <CardTitle className="text-2xl text-orange-800">
                Checkout Cancelled
              </CardTitle>
              <CardDescription className="text-orange-600">
                Your payment was cancelled. No charges were made to your account.
              </CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-6">
              <div className="text-left space-y-4">
                <h3 className="font-semibold text-orange-800">What Happened?</h3>
                <p className="text-sm text-muted-foreground">
                  You chose to cancel the checkout process. Your cart items are still saved 
                  and you can continue shopping or try checking out again when you're ready.
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-3 pt-4">
                <Button asChild className="flex-1">
                  <Link to="/shop">
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Continue Shopping
                  </Link>
                </Button>
                <Button asChild variant="outline" className="flex-1">
                  <Link to="/">
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    View Cart
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}