import { useAuth } from '@/contexts/AuthContext';
import { useAdmin } from '@/contexts/AdminContext';
import { AuthGuard } from '@/components/auth/AuthGuard';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { FarmerSubscriptionManager } from '@/components/subscriptions/FarmerSubscriptionManager';
import SEOHead from '@/components/SEOHead';

const FarmerSubscriptions = () => {
  const { user } = useAuth();
  const { isFarmer } = useAdmin();

  return (
    <>
      <SEOHead 
        title="Manage Subscription Plans - Farmer Dashboard"
        description="Create and manage subscription plans for your farm. Offer weekly or monthly produce boxes to customers."
      />
      <AuthGuard requireAuth={true}>
        <div className="min-h-screen flex flex-col">
          <Header />
          <main className="flex-1 bg-gradient-to-b from-green-50 to-white">
            <div className="container mx-auto px-4 py-8">
              {isFarmer ? (
                <FarmerSubscriptionManager />
              ) : (
                <div className="text-center py-8">
                  <h2 className="text-2xl font-bold mb-4">Access Denied</h2>
                  <p className="text-muted-foreground">
                    You need to be an approved farmer to access subscription management.
                  </p>
                </div>
              )}
            </div>
          </main>
          <Footer />
        </div>
      </AuthGuard>
    </>
  );
};

export default FarmerSubscriptions;