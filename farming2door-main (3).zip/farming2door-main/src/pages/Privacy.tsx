import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SEOHead from "@/components/SEOHead";

const Privacy = () => {
  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title="Privacy Policy"
        description="Farm2Door Privacy Policy - Learn how we collect, use, and protect your personal information on our farm-to-door marketplace platform."
        keywords="privacy policy, data protection, personal information, farm2door privacy"
      />
      
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto prose prose-lg">
          <h1 className="text-4xl font-bold text-foreground mb-8">Privacy Policy</h1>
          
          <p className="text-muted-foreground mb-6">
            <strong>Last updated:</strong> January 2024
          </p>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">1. Information We Collect</h2>
            
            <h3 className="text-lg font-semibold text-foreground mb-3">Personal Information</h3>
            <p className="text-muted-foreground leading-relaxed mb-4">
              We collect information you provide directly to us, including:
            </p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2 mb-4">
              <li>Name, email address, phone number, and delivery address</li>
              <li>Payment information (processed securely by third-party providers)</li>
              <li>Account preferences and communication settings</li>
              <li>Order history and product reviews</li>
            </ul>

            <h3 className="text-lg font-semibold text-foreground mb-3">Automatically Collected Information</h3>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Device information and IP address</li>
              <li>Browser type and operating system</li>
              <li>Pages visited and time spent on our platform</li>
              <li>Location data (with your permission) for delivery optimization</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">2. How We Use Your Information</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              We use your information to:
            </p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Process orders and facilitate transactions between you and farmers</li>
              <li>Provide customer support and respond to inquiries</li>
              <li>Send order confirmations, delivery updates, and important notices</li>
              <li>Improve our platform and develop new features</li>
              <li>Send marketing communications (with your consent)</li>
              <li>Ensure platform security and prevent fraud</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">3. Information Sharing</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              We may share your information with:
            </p>
            
            <h3 className="text-lg font-semibold text-foreground mb-3">Farmers and Producers</h3>
            <p className="text-muted-foreground leading-relaxed mb-4">
              We share necessary order and contact information with farmers to fulfill your orders, including name, phone number, delivery address, and product preferences.
            </p>

            <h3 className="text-lg font-semibold text-foreground mb-3">Service Providers</h3>
            <p className="text-muted-foreground leading-relaxed mb-4">
              We work with third-party services for payment processing, delivery logistics, email communications, and platform analytics.
            </p>

            <h3 className="text-lg font-semibold text-foreground mb-3">Legal Requirements</h3>
            <p className="text-muted-foreground leading-relaxed">
              We may disclose information when required by law or to protect our platform, users, or the public.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">4. Data Security</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              We implement appropriate security measures to protect your information:
            </p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Encryption of data in transit and at rest</li>
              <li>Secure payment processing through PCI-compliant providers</li>
              <li>Regular security audits and updates</li>
              <li>Limited access to personal information on a need-to-know basis</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">5. Your Rights and Choices</h2>
            
            <h3 className="text-lg font-semibold text-foreground mb-3">Account Management</h3>
            <p className="text-muted-foreground leading-relaxed mb-4">
              You can update your account information, communication preferences, and delivery details through your account settings.
            </p>

            <h3 className="text-lg font-semibold text-foreground mb-3">Marketing Communications</h3>
            <p className="text-muted-foreground leading-relaxed mb-4">
              You can opt out of marketing emails at any time using the unsubscribe link or by contacting us directly.
            </p>

            <h3 className="text-lg font-semibold text-foreground mb-3">Data Access and Deletion</h3>
            <p className="text-muted-foreground leading-relaxed">
              You can request access to your personal information or account deletion by contacting our support team. Some information may be retained for legal or business purposes.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">6. Cookies and Tracking</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              We use cookies and similar technologies to:
            </p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2 mb-4">
              <li>Remember your preferences and login status</li>
              <li>Analyze website usage and improve performance</li>
              <li>Provide personalized content and recommendations</li>
              <li>Enable social media features and advertising</li>
            </ul>
            <p className="text-muted-foreground leading-relaxed">
              You can control cookie preferences through your browser settings.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">7. Children's Privacy</h2>
            <p className="text-muted-foreground leading-relaxed">
              Our platform is not intended for children under 18. We do not knowingly collect personal information from children under 18. If you believe a child has provided us with personal information, please contact us immediately.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibent text-foreground mb-4">8. Changes to This Policy</h2>
            <p className="text-muted-foreground leading-relaxed">
              We may update this Privacy Policy periodically. We will notify users of significant changes via email or platform notifications. Your continued use of our service after changes constitutes acceptance.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">9. Contact Us</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              For questions about this Privacy Policy or your personal information, contact us at:
            </p>
            <div className="bg-muted/50 p-4 rounded-lg">
              <p className="text-muted-foreground">
                <strong>Email:</strong> privacy@farm2door.com<br/>
                <strong>Address:</strong> Farm2Door Privacy Officer<br/>
                123 Agriculture Lane, Farm City, FC 12345<br/>
                <strong>Phone:</strong> (555) 123-4567
              </p>
            </div>
          </section>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Privacy;