import { useState, useEffect } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/integrations/supabase/client'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { useToast } from '@/hooks/use-toast'
import { User, Mail, Save, Shield, Trash2, MapPin } from 'lucide-react'
import PlacesAutocomplete from '@/components/ui/places-autocomplete'
import ProfilePictureUpload from '@/components/ProfilePictureUpload'
import { useFocusField } from '@/hooks/useFocusField'

interface Profile {
  id: string
  email: string
  full_name: string | null
  phone: string | null
  user_type: string
  country: string | null
  state: string | null
  city: string | null
  zip_code: string | null
  profile_picture_url: string | null
}

const AccountSettings = () => {
  const { user, signOut } = useAuth()
  const { toast } = useToast()
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [deleting, setDeleting] = useState(false)

  // Deep-link support: /account-settings?focus=city
  useFocusField(!loading)

  useEffect(() => {
    if (user) {
      fetchProfile()
    }
  }, [user])

  const fetchProfile = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('email', user?.email)
        .single()

      if (error && error.code !== 'PGRST116') { // PGRST116 is "not found"
        throw error
      }

      if (data) {
        setProfile(data)
      } else {
        // Create a new profile
        setProfile({
          id: user?.id || '',
          email: user?.email || '',
          full_name: '',
          phone: '',
          user_type: 'customer',
          country: '',
          state: '',
          city: '',
          zip_code: '',
          profile_picture_url: null
        })
      }
    } catch (error) {
      console.error('Error fetching profile:', error)
      toast({
        title: "Error",
        description: "Failed to load profile data.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleSaveProfile = async () => {
    if (!profile || !user) return

    setSaving(true)
    try {
      const profileData = {
        id: user.id,
        email: user.email || '',
        full_name: profile.full_name,
        phone: profile.phone,
        user_type: profile.user_type,
        country: profile.country,
        state: profile.state,
        city: profile.city,
        zip_code: profile.zip_code
      }

      const { error } = await supabase
        .from('profiles')
        .upsert(profileData)

      if (error) throw error

      toast({
        title: "Success",
        description: "Profile updated successfully!",
      })
    } catch (error) {
      console.error('Error saving profile:', error)
      toast({
        title: "Error",
        description: "Failed to update profile.",
        variant: "destructive",
      })
    } finally {
      setSaving(false)
    }
  }

  const handleDeleteAccount = async () => {
    if (!user) return

    const confirmed = window.confirm(
      'Are you sure you want to delete your account? This action cannot be undone.'
    )

    if (!confirmed) return

    setDeleting(true)
    try {
      // Note: This would typically require admin privileges to delete from auth.users
      // For now, we'll just sign the user out and show a message
      await signOut()
      toast({
        title: "Account Deletion",
        description: "Please contact support to complete account deletion.",
        variant: "destructive",
      })
    } catch (error) {
      console.error('Error deleting account:', error)
      toast({
        title: "Error",
        description: "Failed to delete account. Please contact support.",
        variant: "destructive",
      })
    } finally {
      setDeleting(false)
    }
  }

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Please sign in to access account settings</h1>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <h1 className="text-3xl font-bold mb-8">Account Settings</h1>
          
          {loading ? (
            <div className="flex justify-center items-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Account Information */}
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <User className="h-5 w-5" />
                    <CardTitle>Account Information</CardTitle>
                  </div>
                  <CardDescription>
                    Update your personal information and preferences
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div id="profilePicture" tabIndex={-1} className="outline-none">
                  <ProfilePictureUpload
                    currentPictureUrl={profile?.profile_picture_url || undefined}
                    onPictureChange={(url) => setProfile(prev => prev ? {...prev, profile_picture_url: url} : null)}
                    userName={profile?.full_name || undefined}
                  />
                  </div>

                  <div>
                    <Label htmlFor="email">Email Address</Label>
                    <div className="flex items-center gap-2 mt-1">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <Input
                        id="email"
                        value={user.email || ''}
                        disabled
                        className="bg-muted"
                      />
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      Email cannot be changed. Contact support if needed.
                    </p>
                  </div>

                  <div>
                    <Label htmlFor="fullName">Full Name</Label>
                    <Input
                      id="fullName"
                      placeholder="Enter your full name"
                      value={profile?.full_name || ''}
                      onChange={(e) => setProfile(prev => prev ? {...prev, full_name: e.target.value} : null)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      placeholder="Enter your phone number"
                      value={profile?.phone || ''}
                      onChange={(e) => setProfile(prev => prev ? {...prev, phone: e.target.value} : null)}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Location Information */}
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-2">
                    <MapPin className="h-5 w-5" />
                    <CardTitle>Location Information</CardTitle>
                  </div>
                  <CardDescription>
                    Your location helps connect you with nearby farmers and customers
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <PlacesAutocomplete
                      id="country"
                      label="Country"
                      placeholder="Enter your country"
                      value={profile?.country || ''}
                      onChange={(value) => setProfile(prev => prev ? {...prev, country: value} : null)}
                      type="country"
                    />
                    
                    <PlacesAutocomplete
                      id="state"
                      label="State/Province"
                      placeholder="Enter your state or province"
                      value={profile?.state || ''}
                      onChange={(value) => setProfile(prev => prev ? {...prev, state: value} : null)}
                      type="state"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <PlacesAutocomplete
                      id="city"
                      label="City"
                      placeholder="Enter your city"
                      value={profile?.city || ''}
                      onChange={(value) => setProfile(prev => prev ? {...prev, city: value} : null)}
                      type="city"
                    />
                    
                    <div>
                      <Label htmlFor="zipCode">Zip/Postal Code</Label>
                      <div className="flex items-center gap-2 mt-1">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        <Input
                          id="zipCode"
                          placeholder="Enter your zip code"
                          value={profile?.zip_code || ''}
                          onChange={(e) => setProfile(prev => prev ? {...prev, zip_code: e.target.value} : null)}
                        />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>


              {/* Actions */}
              <div className="flex flex-col gap-4">
                <Button onClick={handleSaveProfile} disabled={saving} className="w-full">
                  <Save className="mr-2 h-4 w-4" />
                  {saving ? 'Saving...' : 'Save Changes'}
                </Button>

                <Separator />

                {/* Danger Zone */}
                <Card className="border-destructive">
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <Shield className="h-5 w-5 text-destructive" />
                      <CardTitle className="text-destructive">Danger Zone</CardTitle>
                    </div>
                    <CardDescription>
                      Irreversible actions that affect your account
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button
                      variant="destructive"
                      onClick={handleDeleteAccount}
                      disabled={deleting}
                      className="w-full"
                    >
                      <Trash2 className="mr-2 h-4 w-4" />
                      {deleting ? 'Processing...' : 'Delete Account'}
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  )
}

export default AccountSettings