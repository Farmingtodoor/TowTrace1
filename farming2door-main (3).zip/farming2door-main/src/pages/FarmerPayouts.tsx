import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  DollarSign, Calendar, Clock, CheckCircle, XCircle, ArrowLeft, Settings,
  Landmark, Download, ExternalLink, AlertTriangle,
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Link } from "react-router-dom";
import { downloadPayoutReceiptPdf, type PayoutReceipt } from "@/lib/payoutReceipt";

interface PayoutRequest {
  id: string;
  amount: number;
  status: string;
  payment_method: string;
  bank_account_holder: string;
  bank_account_number: string;
  routing_number: string;
  additional_notes: string;
  requested_at: string;
  reviewed_at: string | null;
  admin_notes: string | null;
}

interface PayoutAccountState {
  connected: boolean;
  payouts_enabled: boolean;
  details_submitted: boolean;
  farm_verified?: boolean;
  bank_last4?: string | null;
  bank_name?: string | null;
  requirements_due?: string[];
}

export default function FarmerPayouts() {
  const { user } = useAuth();
  const [payoutRequests, setPayoutRequests] = useState<PayoutRequest[]>([]);
  const [receipts, setReceipts] = useState<Record<string, PayoutReceipt>>({});
  const [account, setAccount] = useState<PayoutAccountState | null>(null);
  const [accountLoading, setAccountLoading] = useState(true);
  const [connecting, setConnecting] = useState(false);
  const [farmVerified, setFarmVerified] = useState<boolean | null>(null);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    amount: "",
    bank_account_holder: "",
    bank_account_number: "",
    routing_number: "",
    additional_notes: "",
  });

  const checkVerification = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from("farmer_applications")
      .select("status")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    setFarmVerified(data?.status === "approved");
  }, [user]);

  const loadAccount = useCallback(async () => {
    setAccountLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("farmer-payout-account", {
        body: { action: "status" },
      });
      if (error) throw error;
      setAccount(data as PayoutAccountState);
      if (typeof (data as PayoutAccountState)?.farm_verified === "boolean") {
        setFarmVerified(!!(data as PayoutAccountState).farm_verified);
      }
    } catch (error) {
      console.error("Error loading payout account:", error);
      setAccount({ connected: false, payouts_enabled: false, details_submitted: false });
    } finally {
      setAccountLoading(false);
    }
  }, []);


  const startOnboarding = async () => {
    if (farmVerified === false) {
      toast.error("Your farm must be approved before you can connect a bank account.");
      return;
    }
    setConnecting(true);
    try {
      const { data, error } = await supabase.functions.invoke("farmer-payout-account", {
        body: { action: "onboard" },
      });
      if (error) throw error;
      if ((data as { error?: string })?.error === "FARM_NOT_VERIFIED") {
        setFarmVerified(false);
        toast.error("Your farm must be approved before you can connect a bank account.");
        return;
      }
      if (data?.url) {
        window.location.href = data.url as string;
        return;
      }
      toast.error("Could not start bank verification. Please try again.");
    } catch (error) {
      console.error("Error starting onboarding:", error);
      toast.error("Could not start bank verification. Please try again.");
    } finally {
      setConnecting(false);
    }
  };


  const fetchReceipts = useCallback(async () => {
    if (!user) return;
    const { data, error } = await supabase
      .from("payout_receipts")
      .select("*")
      .eq("farmer_id", user.id)
      .order("sent_at", { ascending: false });
    if (error) {
      console.error("Error loading receipts:", error);
      return;
    }
    const map: Record<string, PayoutReceipt> = {};
    (data || []).forEach((r) => {
      if (!map[r.payout_request_id]) map[r.payout_request_id] = r as unknown as PayoutReceipt;
    });
    setReceipts(map);
  }, [user]);

  useEffect(() => {
    if (user) {
      fetchPayoutRequests();
      fetchReceipts();
      checkVerification();
      loadAccount();
    }
  }, [user, fetchReceipts, loadAccount, checkVerification]);



  const fetchPayoutRequests = async () => {
    try {
      const { data, error } = await supabase.rpc('get_decrypted_payout_requests', {
        p_farmer_id: user?.id
      });

      if (error) throw error;
      setPayoutRequests(data || []);
    } catch (error) {
      console.error("Error fetching payout requests:", error);
      toast.error("Failed to load payout requests");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.amount || !formData.bank_account_holder || !formData.bank_account_number || !formData.routing_number) {
      toast.error("Please fill in all required fields");
      return;
    }

    try {
      const { data, error } = await supabase.rpc('insert_encrypted_payout_request', {
        p_farmer_id: user?.id,
        p_amount: parseFloat(formData.amount),
        p_payment_method: 'bank_transfer',
        p_bank_account_holder: formData.bank_account_holder,
        p_bank_account_number: formData.bank_account_number,
        p_routing_number: formData.routing_number,
        p_additional_notes: formData.additional_notes || null
      });

      if (error) throw error;

      toast.success("Payout request submitted successfully!");
      setIsDialogOpen(false);
      setFormData({
        amount: "",
        bank_account_holder: "",
        bank_account_number: "",
        routing_number: "",
        additional_notes: "",
      });
      fetchPayoutRequests();
    } catch (error) {
      console.error("Error submitting payout request:", error);
      toast.error("Failed to submit payout request");
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
      case "approved":
        return <Badge variant="default"><CheckCircle className="h-3 w-3 mr-1" />Approved</Badge>;
      case "rejected":
        return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" />Rejected</Badge>;
      case "paid":
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200"><CheckCircle className="h-3 w-3 mr-1" />Paid</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto py-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-muted rounded w-1/4"></div>
          <div className="h-32 bg-muted rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Link 
          to="/admin" 
          className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Admin Portal
        </Link>
      </div>
      
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          <h1 className="text-3xl font-bold">Payout Requests</h1>
          <Link 
            to="/admin" 
            className="flex items-center gap-2 px-3 py-1 text-sm bg-muted hover:bg-muted/80 rounded-lg transition-colors"
          >
            <Settings className="h-3 w-3" />
            Admin Portal
          </Link>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button disabled={!farmVerified || !account?.payouts_enabled}>
              <DollarSign className="h-4 w-4 mr-2" />
              Request Payout
            </Button>
          </DialogTrigger>

          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Request Payout</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="amount">Amount ($) *</Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  placeholder="0.00"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="bank_account_holder">Account Holder Name *</Label>
                <Input
                  id="bank_account_holder"
                  value={formData.bank_account_holder}
                  onChange={(e) => setFormData({ ...formData, bank_account_holder: e.target.value })}
                  placeholder="John Doe"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="bank_account_number">Account Number *</Label>
                <Input
                  id="bank_account_number"
                  value={formData.bank_account_number}
                  onChange={(e) => setFormData({ ...formData, bank_account_number: e.target.value })}
                  placeholder="1234567890"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="routing_number">Routing Number *</Label>
                <Input
                  id="routing_number"
                  value={formData.routing_number}
                  onChange={(e) => setFormData({ ...formData, routing_number: e.target.value })}
                  placeholder="021000021"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="additional_notes">Additional Notes</Label>
                <Textarea
                  id="additional_notes"
                  value={formData.additional_notes}
                  onChange={(e) => setFormData({ ...formData, additional_notes: e.target.value })}
                  placeholder="Any additional information..."
                  rows={3}
                />
              </div>
              
              <div className="flex gap-2 pt-4">
                <Button type="submit" className="flex-1">Submit Request</Button>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Bank account connection */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Landmark className="h-5 w-5" />
            Bank account
          </CardTitle>
          <CardDescription>
            Payouts are transferred straight to your verified bank account. Verification is handled
            securely by Stripe — we never store your bank details.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {farmVerified === false ? (
            <div className="space-y-3">
              <div className="flex items-start gap-2 text-sm text-muted-foreground">
                <AlertTriangle className="h-4 w-4 mt-0.5 text-amber-600" />
                <p>
                  Bank connection and payouts unlock once your farm is verified. Complete your
                  onboarding profile and an admin will review it.
                </p>
              </div>
              <Button asChild variant="outline">
                <Link to="/farmer-onboarding">Complete farm onboarding</Link>
              </Button>
            </div>
          ) : accountLoading ? (

            <div className="h-10 bg-muted rounded animate-pulse" />
          ) : account?.payouts_enabled ? (
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-sm">
                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                  <CheckCircle className="h-3 w-3 mr-1" /> Verified
                </Badge>
                <span className="text-muted-foreground">
                  {account.bank_name || "Bank account"} ••••{account.bank_last4 || "----"}
                </span>
              </div>
              <Button variant="outline" size="sm" onClick={startOnboarding} disabled={connecting}>
                <ExternalLink className="h-3.5 w-3.5 mr-1" /> Update bank details
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-start gap-2 text-sm text-muted-foreground">
                <AlertTriangle className="h-4 w-4 mt-0.5 text-amber-600" />
                <p>
                  {account?.connected
                    ? "Your verification isn't finished yet, so payouts can't be sent. Pick up where you left off."
                    : "Connect a bank account to request and receive payouts."}
                </p>
              </div>
              <Button onClick={startOnboarding} disabled={connecting}>
                <Landmark className="h-4 w-4 mr-2" />
                {connecting
                  ? "Opening secure setup…"
                  : account?.connected
                    ? "Finish verification"
                    : "Connect bank account"}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>



      {payoutRequests.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center">
            <DollarSign className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">No payout requests yet</h3>
            <p className="text-muted-foreground mb-4">
              Request your first payout to get started
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {payoutRequests.map((request) => (
            <Card key={request.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5" />
                    ${request.amount.toFixed(2)}
                  </CardTitle>
                  {getStatusBadge(request.status)}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Account Holder:</span>
                    <p className="text-muted-foreground">{request.bank_account_holder}</p>
                  </div>
                  <div>
                    <span className="font-medium">Account Number:</span>
                    <p className="text-muted-foreground">****{request.bank_account_number ? request.bank_account_number.slice(-4) : '****'}</p>
                  </div>
                  <div>
                    <span className="font-medium">Requested:</span>
                    <p className="text-muted-foreground flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {new Date(request.requested_at).toLocaleDateString()}
                    </p>
                  </div>
                  {request.reviewed_at && (
                    <div>
                      <span className="font-medium">Reviewed:</span>
                      <p className="text-muted-foreground flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {new Date(request.reviewed_at).toLocaleDateString()}
                      </p>
                    </div>
                  )}
                </div>
                
                {request.additional_notes && (
                  <div>
                    <span className="font-medium">Your Notes:</span>
                    <p className="text-muted-foreground">{request.additional_notes}</p>
                  </div>
                )}
                
                {request.admin_notes && (
                  <div>
                    <span className="font-medium">Admin Notes:</span>
                    <p className="text-muted-foreground">{request.admin_notes}</p>
                  </div>
                )}

                {receipts[request.id] && (
                  <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border bg-muted/40 p-3">
                    <div className="text-sm">
                      <p className="font-medium">Receipt {receipts[request.id].receipt_number}</p>
                      <p className="text-muted-foreground">
                        {receipts[request.id].status === "sent" ? "Sent" : "Failed"} on{" "}
                        {new Date(receipts[request.id].sent_at).toLocaleString()}
                      </p>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => downloadPayoutReceiptPdf(receipts[request.id], request.bank_account_holder)}
                    >
                      <Download className="h-3.5 w-3.5 mr-1" /> Download PDF
                    </Button>
                  </div>
                )}

              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}