import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";
import Header from "@/components/Header";
import { DeliverySettingsManager } from "@/components/farmer/DeliverySettingsManager";

const FarmerDeliverySettings = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md w-full">
          <CardContent className="p-6 text-center">
            <h2 className="text-xl font-semibold mb-2">Access Denied</h2>
            <p className="text-muted-foreground">
              Please sign in to manage your delivery settings.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="container mx-auto px-4 py-8 space-y-6">
        <Button variant="outline" onClick={() => navigate(-1)}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>

        <div className="border-b pb-4">
          <h1 className="text-3xl font-bold">Delivery Settings</h1>
          <p className="text-muted-foreground mt-2">
            Opt into in-house delivery, set how far you'll travel, and control which
            fulfillment options customers see at checkout.
          </p>
        </div>

        <DeliverySettingsManager />
      </div>
    </div>
  );
};

export default FarmerDeliverySettings;
