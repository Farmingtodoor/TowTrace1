import { useState, useEffect } from 'react';
import SEOHead from '@/components/SEOHead';
import { AuthGuard } from '@/components/auth/AuthGuard';
import AnalyticsDashboard from '@/components/analytics/AnalyticsDashboard';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { RefreshCw, Download, TrendingUp } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

const FarmerAnalytics = () => {
  const [refreshing, setRefreshing] = useState(false);
  const { toast } = useToast();

  const refreshAnalytics = async () => {
    setRefreshing(true);
    try {
      // Update analytics tables
      await Promise.all([
        supabase.rpc('update_farmer_revenue_analytics'),
        supabase.rpc('update_customer_insights'),
        supabase.rpc('update_product_performance')
      ]);

      toast({
        title: "Analytics Updated",
        description: "Your analytics data has been refreshed with the latest information.",
      });
    } catch (error) {
      console.error('Error refreshing analytics:', error);
      toast({
        title: "Refresh Failed",
        description: "Failed to refresh analytics data. Please try again.",
        variant: "destructive"
      });
    } finally {
      setRefreshing(false);
    }
  };

  const exportData = async () => {
    toast({
      title: "Export Started",
      description: "Your analytics data export will begin shortly.",
    });
  };

  return (
    <AuthGuard requireAuth={true}>
      <div className="min-h-screen bg-background">
        <SEOHead
          title="Analytics Dashboard - Farm2Door"
          description="Track your farm's performance with detailed analytics and insights. Monitor sales, customer behavior, and product performance."
          keywords="farmer analytics, sales dashboard, performance metrics, farm insights, revenue tracking"
        />
        
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-7xl mx-auto">
            {/* Page Header */}
            <div className="flex justify-between items-start mb-8">
              <div>
                <h1 className="text-4xl font-bold text-foreground mb-4 flex items-center gap-3">
                  <TrendingUp className="h-8 w-8 text-primary" />
                  Analytics Dashboard
                </h1>
                <p className="text-lg text-muted-foreground">
                  Track your farm's performance with comprehensive analytics and insights.
                </p>
              </div>
              
              <div className="flex gap-2">
                <Button variant="outline" onClick={exportData}>
                  <Download className="h-4 w-4 mr-2" />
                  Export Data
                </Button>
                <Button onClick={refreshAnalytics} disabled={refreshing}>
                  <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
                  {refreshing ? 'Refreshing...' : 'Refresh'}
                </Button>
              </div>
            </div>

            {/* Info Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Real-time Insights</CardTitle>
                  <CardDescription>
                    Get up-to-date analytics on your sales performance and customer behavior.
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Performance Tracking</CardTitle>
                  <CardDescription>
                    Monitor which products perform best and identify growth opportunities.
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Customer Analytics</CardTitle>
                  <CardDescription>
                    Understand your customers better with detailed segmentation and insights.
                  </CardDescription>
                </CardHeader>
              </Card>
            </div>

            {/* Analytics Dashboard */}
            <AnalyticsDashboard />
          </div>
        </div>
      </div>
    </AuthGuard>
  );
};

export default FarmerAnalytics;