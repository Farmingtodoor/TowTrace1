import { useState, useEffect } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/integrations/supabase/client'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Calendar, User, Package, Clock, Home } from 'lucide-react'
import { format } from 'date-fns'
import { useToast } from '@/hooks/use-toast'
import Header from '@/components/Header'
import { useNavigate } from 'react-router-dom'

interface CustomOrder {
  id: string
  customer_id: string
  status: string
  requested_products: any[]
  requested_delivery_date: string
  proposed_delivery_date: string | null
  customer_notes: string | null
  farmer_notes: string | null
  estimated_total: number | null
  delivery_method: string
  delivery_address: string | null
  delivery_fee: number | null
  created_at: string
  responded_at: string | null
  customer_name?: string
  customer_email?: string
}

export default function FarmerCustomOrders() {
  const { user } = useAuth()
  const { toast } = useToast()
  const navigate = useNavigate()
  const [orders, setOrders] = useState<CustomOrder[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedOrder, setSelectedOrder] = useState<CustomOrder | null>(null)
  const [proposedDate, setProposedDate] = useState('')
  const [farmerNotes, setFarmerNotes] = useState('')
  const [estimatedTotal, setEstimatedTotal] = useState('')
  const [deliveryFee, setDeliveryFee] = useState('')
  const [actionLoading, setActionLoading] = useState(false)

  useEffect(() => {
    if (user) {
      fetchCustomOrders()
    }
  }, [user])

  const fetchCustomOrders = async () => {
    if (!user) return

    const { data, error } = await supabase
      .from('custom_orders')
      .select(`
        id,
        customer_id,
        status,
        requested_products,
        requested_delivery_date,
        proposed_delivery_date,
        customer_notes,
        farmer_notes,
        estimated_total,
        delivery_method,
        delivery_address,
        delivery_fee,
        created_at,
        responded_at
      `)
      .eq('farmer_id', user.id)
      .order('created_at', { ascending: false })

    if (error) {
      console.error('Error fetching custom orders:', error)
      setLoading(false)
      return
    }

    // Fetch customer names separately
    const customerIds = [...new Set(data.map(order => order.customer_id))]
    const { data: customers } = await supabase
      .from('profiles')
      .select('id, full_name, email')
      .in('id', customerIds)

    const customerMap = customers?.reduce((acc: any, customer: any) => {
      acc[customer.id] = { name: customer.full_name, email: customer.email }
      return acc
    }, {}) || {}

    const ordersWithCustomer = data.map(order => ({
      ...order,
      customer_name: customerMap[order.customer_id]?.name || 'Unknown Customer',
      customer_email: customerMap[order.customer_id]?.email || '',
      delivery_method: order.delivery_method || 'pickup',
      delivery_address: order.delivery_address || null,
      delivery_fee: order.delivery_fee || 0,
      requested_products: typeof order.requested_products === 'string' 
        ? JSON.parse(order.requested_products) 
        : Array.isArray(order.requested_products) ? order.requested_products : []
    }))
    
    setOrders(ordersWithCustomer)
    setLoading(false)
  }

  const handleOrderAction = async (orderId: string, action: 'accept' | 'reject' | 'counter_propose') => {
    setActionLoading(true)

    const updateData: any = {
      status: action === 'accept' ? 'accepted' : action === 'reject' ? 'rejected' : 'counter_proposed',
      responded_at: new Date().toISOString(),
    }

    if (farmerNotes.trim()) {
      updateData.farmer_notes = farmerNotes.trim()
    }

    if (action === 'counter_propose' && proposedDate) {
      updateData.proposed_delivery_date = proposedDate
    }

    if (estimatedTotal && !isNaN(parseFloat(estimatedTotal))) {
      updateData.estimated_total = parseFloat(estimatedTotal)
    }

    // Add delivery fee for delivery orders
    if (selectedOrder && selectedOrder.delivery_method === 'delivery' && deliveryFee && !isNaN(parseFloat(deliveryFee))) {
      updateData.delivery_fee = parseFloat(deliveryFee)
    }

    const { error } = await supabase
      .from('custom_orders')
      .update(updateData)
      .eq('id', orderId)

    if (error) {
      console.error('Error updating custom order:', error)
      toast({
        title: "Error",
        description: "Failed to update order. Please try again.",
      })
    } else {
      // If order is accepted, automatically send invoice
      if (action === 'accept') {
        try {
          const { data, error: checkoutError } = await supabase.functions.invoke('create-custom-order-checkout', {
            body: { orderId, orderType: 'custom_order' }
          })

          if (checkoutError) {
            console.error('Error creating checkout:', checkoutError)
            toast({
              title: "Order Accepted",
              description: "Order accepted successfully! Please ask customer to check their email for payment instructions.",
            })
          } else {
            // Send email notification to customer
            await supabase.functions.invoke('send-notification-email', {
              body: {
                notification: {
                  user_id: selectedOrder?.customer_id,
                  title: 'Custom Order Invoice Ready',
                  message: `Your custom order has been accepted! Please complete payment using this link: ${data.url}`,
                  type: 'custom_order_invoice'
                }
              }
            })

            toast({
              title: "Success",
              description: "Order accepted and invoice sent to customer!",
            })
          }
        } catch (invoiceError) {
          console.error('Error sending invoice:', invoiceError)
          toast({
            title: "Order Accepted",
            description: "Order accepted successfully, but there was an issue sending the invoice. Please contact the customer directly.",
          })
        }
      } else {
        toast({
          title: "Success",
          description: `Order ${action === 'reject' ? 'rejected' : 'counter-proposed'} successfully!`,
        })
      }
      
      fetchCustomOrders()
      setSelectedOrder(null)
      resetForm()
    }

    setActionLoading(false)
  }

  const resetForm = () => {
    setProposedDate('')
    setFarmerNotes('')
    setEstimatedTotal('')
    setDeliveryFee('')
  }

  const openOrderDialog = (order: CustomOrder) => {
    setSelectedOrder(order)
    setProposedDate(order.proposed_delivery_date || '')
    setFarmerNotes(order.farmer_notes || '')
    setEstimatedTotal(order.estimated_total?.toString() || '')
    setDeliveryFee(order.delivery_method === 'delivery' ? (order.delivery_fee?.toString() || '5.00') : '0')
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800'
      case 'accepted':
        return 'bg-green-100 text-green-800'
      case 'rejected':
        return 'bg-red-100 text-red-800'
      case 'counter_proposed':
        return 'bg-blue-100 text-blue-800'
      case 'completed':
        return 'bg-gray-100 text-gray-800'
      case 'cancelled':
        return 'bg-gray-100 text-gray-600'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <p>Please sign in to view custom orders.</p>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="animate-pulse space-y-4">
          {[1, 2, 3].map(i => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="h-4 bg-muted rounded w-1/4 mb-2"></div>
                <div className="h-4 bg-muted rounded w-1/2"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center gap-4 mb-8">
          <Button variant="outline" size="sm" onClick={() => navigate('/')}>
            <Home className="w-4 h-4 mr-2" />
            Home
          </Button>
          <h1 className="text-3xl font-bold">Custom Order Requests</h1>
        </div>

      {orders.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <Clock className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">No Custom Orders Yet</h3>
            <p className="text-muted-foreground">
              When customers submit custom orders, they'll appear here for you to review
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {orders.map(order => (
            <Card key={order.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="text-lg">
                    Order from {order.customer_name}
                  </CardTitle>
                  <Badge className={getStatusColor(order.status)}>
                    {order.status.replace('_', ' ').toUpperCase()}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">{order.customer_email}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">
                        Requested: {format(new Date(order.requested_delivery_date), 'MMM dd, yyyy')}
                      </span>
                    </div>
                  </div>

                  {order.requested_products.length > 0 && (
                    <div>
                      <h4 className="font-semibold mb-2">Requested Products:</h4>
                      <div className="space-y-2">
                        {order.requested_products.map((product: any, index: number) => (
                          <div key={index} className="flex justify-between items-center text-sm bg-muted p-2 rounded">
                            <span>{product.name}</span>
                            <span>{product.quantity} {product.unit || 'units'}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {order.delivery_method === 'delivery' && order.delivery_address && (
                    <div>
                      <h4 className="font-semibold mb-1">Delivery Address:</h4>
                      <p className="text-sm text-muted-foreground">{order.delivery_address}</p>
                    </div>
                  )}

                  {order.customer_notes && (
                    <div>
                      <h4 className="font-semibold mb-1">Customer Notes:</h4>
                      <p className="text-sm text-muted-foreground">{order.customer_notes}</p>
                    </div>
                  )}

                  <div className="flex gap-2">
                    {order.status === 'pending' && (
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button onClick={() => openOrderDialog(order)}>
                            Respond to Order
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-md">
                          <DialogHeader>
                            <DialogTitle>Respond to Custom Order</DialogTitle>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div className="space-y-2">
                              <Label htmlFor="proposedDate">Proposed Delivery Date</Label>
                              <Input
                                id="proposedDate"
                                type="date"
                                value={proposedDate}
                                onChange={(e) => setProposedDate(e.target.value)}
                                min={new Date().toISOString().split('T')[0]}
                              />
                            </div>

                            <div className="space-y-2">
                              <Label htmlFor="estimatedTotal">Estimated Total ($) *</Label>
                              <Input
                                id="estimatedTotal"
                                type="number"
                                step="0.01"
                                placeholder="0.00"
                                value={estimatedTotal}
                                onChange={(e) => setEstimatedTotal(e.target.value)}
                                required
                              />
                              <p className="text-xs text-muted-foreground">Required to accept the order</p>
                            </div>

                            {selectedOrder?.delivery_method === 'delivery' && (
                              <div className="space-y-2">
                                <Label htmlFor="deliveryFee">Delivery Fee ($)</Label>
                                <Input
                                  id="deliveryFee"
                                  type="number"
                                  step="0.01"
                                  placeholder="5.00"
                                  value={deliveryFee}
                                  onChange={(e) => setDeliveryFee(e.target.value)}
                                />
                                <p className="text-xs text-muted-foreground">Additional fee for delivery service</p>
                              </div>
                            )}

                            <div className="space-y-2">
                              <Label htmlFor="farmerNotes">Response Notes</Label>
                              <Textarea
                                id="farmerNotes"
                                placeholder="Add any comments or details about the order..."
                                value={farmerNotes}
                                onChange={(e) => setFarmerNotes(e.target.value)}
                                rows={3}
                              />
                            </div>

                            <div className="flex flex-col gap-2">
                              <Button
                                onClick={() => handleOrderAction(order.id, 'accept')}
                                disabled={actionLoading || !estimatedTotal || isNaN(parseFloat(estimatedTotal))}
                                className="w-full"
                              >
                                Accept Order
                              </Button>
                              <Button
                                variant="outline"
                                onClick={() => handleOrderAction(order.id, 'counter_propose')}
                                disabled={actionLoading || !proposedDate}
                                className="w-full"
                              >
                                Counter Propose
                              </Button>
                              <Button
                                variant="destructive"
                                onClick={() => handleOrderAction(order.id, 'reject')}
                                disabled={actionLoading}
                                className="w-full"
                              >
                                Reject Order
                              </Button>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                    )}
                  </div>

                  <div className="text-xs text-muted-foreground">
                    Submitted: {format(new Date(order.created_at), 'MMM dd, yyyy HH:mm')}
                    {order.responded_at && (
                      <> • Responded: {format(new Date(order.responded_at), 'MMM dd, yyyy HH:mm')}</>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
      </div>
    </div>
  )
}