import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowLeft, 
  Star, 
  MapPin, 
  Shield, 
  Heart,
  ShoppingCart,
  User,
  Award,
  Share2
} from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import AnimalProcessingOptions from "@/components/AnimalProcessingOptions";
import DeliveryZoneEstimator from "@/components/DeliveryZoneEstimator";
import ReviewsSection from "@/components/ReviewsSection";
import ProductMediaGallery from "@/components/ProductMediaGallery";
import { useCart } from "@/contexts/CartContext";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { ChatButton } from "@/components/chat/ChatButton";
import { useProductDiscounts } from "@/hooks/useProductDiscounts";
import SmartRecommendations from "@/components/recommendations/SmartRecommendations";
import { useProductTracking } from "@/hooks/useProductTracking";

interface MediaFile {
  url: string;
  type: 'image' | 'video';
  name: string;
}

export default function ProductDetail() {
  const { productId } = useParams();
  const navigate = useNavigate();
  const { addItem } = useCart();
  const [isFavorited, setIsFavorited] = useState(false);
  const [product, setProduct] = useState<any>(null);
  const [farmerName, setFarmerName] = useState<string>("");
  const [farmerLocation, setFarmerLocation] = useState<string>("");
  const [loading, setLoading] = useState(true);
  
  const { discountInfo } = useProductDiscounts(
    product?.id || '', 
    product?.price || 0, 
    product?.farmer_id
  );

  // Track product views for recommendations
  useProductTracking(product?.id, product?.category);

  useEffect(() => {
    const fetchProduct = async () => {
      if (!productId) return;
      
      try {
        const { data, error } = await supabase
          .from('products')
          .select('*')
          .eq('id', productId)
          .single();

        if (error) throw error;
        
        // Parse media from JSON
        const productWithMedia = {
          ...data,
          images: Array.isArray(data.images) ? (data.images as unknown as MediaFile[]) : [],
          videos: Array.isArray(data.videos) ? (data.videos as unknown as MediaFile[]) : []
        };
        
        setProduct(productWithMedia);

        // Fetch farmer name
        if (data.farmer_id) {
          await fetchFarmerName(data.farmer_id);
        } else {
          // Fallback to the farmer field if farmer_id is not available
          setFarmerName(data.farmer || "Unknown Farmer");
        }
      } catch (error) {
        console.error('Error fetching product:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchProduct();
  }, [productId]);

  const fetchFarmerName = async (farmerId: string) => {
    try {
      console.log('Fetching farmer name for ID:', farmerId);
      
      // Use secure function instead of direct table access
      const { data: allFarmers, error: farmerAppError } = await supabase
        .rpc('get_farmers_public_safe');
      
      // Find the specific farmer
      const farmerApp = allFarmers?.find((farmer: any) => farmer.user_id === farmerId) || null;

      console.log('Farmer application result:', { farmerApp, farmerAppError });

      if (farmerApp && !farmerAppError) {
        const name = farmerApp.farm_name || farmerApp.display_name;
        console.log('Using farmer application name:', name);
        setFarmerName(name);
        
        // Also get farmer location from the secure function that returns general location
        const { data: farmerDetails, error: detailsError } = await supabase
          .rpc('get_approved_farmers_public');
        
        const farmerWithLocation = farmerDetails?.find((f: any) => f.user_id === farmerId);
        if (farmerWithLocation && farmerWithLocation.general_location) {
          setFarmerLocation(farmerWithLocation.general_location);
        }
        
        return;
      }

      // No public farmer record available — avoid exposing private profile data
      setFarmerName("Local Farm");
    } catch (error) {
      console.error('Error fetching farmer name:', error);
      setFarmerName("Unknown Farmer");
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Loading...</h1>
        </div>
        <Footer />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Product Not Found</h1>
          <Button onClick={() => navigate("/shop")}>Back to Shop</Button>
        </div>
        <Footer />
      </div>
    );
  }

  const handleAddToCart = () => {
    if (product.stock_quantity <= 0) {
      toast.error("This product is out of stock");
      return;
    }

    addItem({
      id: product.id,
      name: product.name,
      price: `$${product.price}`,
      farmer: farmerName,
      image: (product.images && product.images.length > 0) 
        ? product.images[0].url 
        : product.image_url || "/placeholder.svg",
      category: product.category,
      isOrganic: product.is_organic
    });
    toast.success("Added to cart!");
  };

  const handleShareClick = async () => {
    const productUrl = `${window.location.origin}/products/${productId}`;
    const shareData = {
      title: product.name,
      text: `Check out this fresh ${product.name} from ${farmerName} on Farm2Door!`,
      url: productUrl,
    };

    try {
      if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
        await navigator.share(shareData);
      } else {
        // Fallback to copying URL to clipboard
        await navigator.clipboard.writeText(productUrl);
        toast.success("Product link copied to clipboard!");
      }
    } catch (error) {
      console.error('Error sharing:', error);
      toast.error("Unable to share this product. Please try again.");
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <Button
          variant="outline" 
          onClick={() => navigate("/shop")}
          className="mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Shop
        </Button>

        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          {/* Product Media Gallery */}
          <div className="space-y-4">
            <ProductMediaGallery
              images={product.images || []}
              videos={product.videos || []}
              productName={product.name}
            />
            
            {/* Fallback to legacy image_url if no new media */}
            {(!product.images || product.images.length === 0) && 
             (!product.videos || product.videos.length === 0) && 
             product.image_url && (
              <div className="aspect-square rounded-lg overflow-hidden bg-muted">
                <img
                  src={product.image_url}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                {product.is_organic && (
                  <Badge variant="secondary" className="bg-green-100 text-green-800">
                    <Shield className="h-3 w-3 mr-1" />
                    Organic
                  </Badge>
                )}
                <Badge variant="outline">{product.category}</Badge>
              </div>
              
              <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
              
              <div className="flex items-center gap-4 mb-4">
                <div className="flex items-center gap-1">
                  <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                  <span className="font-medium">4.8</span>
                  <span className="text-muted-foreground">(24 reviews)</span>
                </div>
                
                <div className="flex gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsFavorited(!isFavorited)}
                  >
                    <Heart className={`h-4 w-4 ${isFavorited ? 'fill-red-500 text-red-500' : ''}`} />
                  </Button>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleShareClick}
                  >
                    <Share2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <Button
                    variant="link"
                    className="p-0 h-auto font-medium text-primary"
                    onClick={() => {
                      if (product.farmer_id) {
                        navigate(`/farmers/${product.farmer_id}`);
                      } else {
                        toast.error("Farmer profile not available");
                      }
                    }}
                  >
                    {farmerName}
                  </Button>
                </div>
                
                {farmerLocation && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4" />
                    <span>{farmerLocation}</span>
                  </div>
                )}
                
                {product.harvest_date && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span>Harvested: {new Date(product.harvest_date).toLocaleDateString()}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-2">
              {discountInfo.hasDiscount ? (
                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl font-bold text-primary">
                      ${discountInfo.discountedPrice.toFixed(2)}
                    </span>
                    <span className="text-muted-foreground">per {product.unit}</span>
                    <Badge variant="destructive" className="text-lg px-3 py-1">
                      -{discountInfo.discountPercentage.toFixed(0)}% OFF
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xl text-muted-foreground line-through">
                      ${discountInfo.originalPrice.toFixed(2)}
                    </span>
                    {discountInfo.promotionName && (
                      <Badge variant="secondary" className="text-sm">
                        {discountInfo.promotionName}
                      </Badge>
                    )}
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-3">
                  <span className="text-3xl font-bold">${product.price}</span>
                  <span className="text-muted-foreground">per {product.unit}</span>
                </div>
              )}
              
              {product.stock_quantity > 0 ? (
                <p className="text-green-600 font-medium">✓ In Stock ({product.stock_quantity} available)</p>
              ) : (
                <p className="text-red-600 font-medium">Out of Stock</p>
              )}
            </div>

            <p className="text-muted-foreground leading-relaxed">
              {product.description}
            </p>

            <div className="space-y-3">
              <Button
                onClick={handleAddToCart}
                disabled={product.stock_quantity <= 0}
                className="w-full"
                size="lg"
              >
                <ShoppingCart className="h-4 w-4 mr-2" />
                Add to Cart
              </Button>
              
              {product.farmer_id && (
                <ChatButton 
                  farmerId={product.farmer_id} 
                  farmerName={farmerName}
                  size="lg"
                  variant="outline"
                  className="w-full"
                />
              )}
            </div>
          </div>
        </div>

        {/* Product Details */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Product Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Unit:</span>
                <span className="font-medium">{product.unit}</span>
              </div>
              {product.harvest_date && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Harvest Date:</span>
                  <span className="font-medium">{new Date(product.harvest_date).toLocaleDateString()}</span>
                </div>
              )}
              {product.expiration_date && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Best By:</span>
                  <span className="font-medium">{new Date(product.expiration_date).toLocaleDateString()}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-muted-foreground">Stock:</span>
                <span className="font-medium">{product.stock_quantity} {product.unit}</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Description</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed">
                {product.description}
              </p>
            </CardContent>
          </Card>

          {product.is_organic && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  Certifications
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">Organic Certified</Badge>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Additional Product Details and Reviews */}
        <div className="grid lg:grid-cols-2 gap-8 mt-8">
          {/* Animal Processing Options for Livestock */}
          {product.category.toLowerCase() === 'meat' && (
            <AnimalProcessingOptions
              productName={product.name}
              basePrice={product.price}
              portionOptions={(product.portion_options as string[]) || ['whole']}
              processingAddons={(product.processing_addons as any[]) || []}
              onAddToCart={(options) => {
                addItem({
                  id: product.id,
                  name: `${product.name} (${options.portion})`,
                  price: `$${options.totalPrice}`,
                  farmer: farmerName,
                  image: (product.images && product.images.length > 0) 
                    ? product.images[0].url 
                    : product.image_url || "/placeholder.svg",
                  category: product.category,
                  isOrganic: product.is_organic
                });
                toast.success(`Added ${options.portion} ${product.name} to cart!`);
              }}
            />
          )}

          {/* Delivery Zone Estimator */}
          <DeliveryZoneEstimator 
            farmerId={product.farmer_id} 
            farmerLocation={farmerLocation}
          />
        </div>

        {/* Reviews Section */}
        <div className="mt-8">
          <ReviewsSection
            productId={product.id}
            averageRating={product.average_rating || 0}
            reviewCount={product.review_count || 0}
          />
        </div>

        {/* Smart Recommendations */}
        <div className="mt-8">
          <SmartRecommendations 
            currentProductId={product.id}
            currentCategory={product.category}
          />
        </div>
      </main>
      
      <Footer />
    </div>
  );
}