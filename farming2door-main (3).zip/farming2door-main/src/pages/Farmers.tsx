import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useNavigate } from "react-router-dom";
import { MapPin, Star, Users, Leaf, Search, Calendar } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAdmin } from "@/contexts/AdminContext";
import heroImage from "@/assets/hero-farm.jpg";
import produceImage from "@/assets/produce-vegetables.jpg";
import livestockImage from "@/assets/meat-livestock.jpg";

interface Farmer {
  id: string;
  display_name: string;
  farm_name: string;
  farm_description: string;
  city: string;
  state: string;
  country: string;
  zip_code: string;
  categories: string[];
  certifications: string[];
  next_harvest_date?: string;
}

const Farmers = () => {
  const navigate = useNavigate();
  const { isFarmer } = useAdmin();
  const [farmers, setFarmers] = useState<Farmer[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCity, setSelectedCity] = useState("all");
  const [selectedState, setSelectedState] = useState("all");
  const [cities, setCities] = useState<string[]>([]);
  const [states, setStates] = useState<string[]>([]);

  useEffect(() => {
    fetchFarmers();
  }, []);

  const fetchFarmers = async () => {
    try {
      setLoading(true);
      
      // Use secure function for farmer applications
      const { data: applications, error: appError } = await supabase
        .rpc('get_farmers_public_safe');

      if (appError) {
        console.error('Error fetching farmer applications:', appError);
        return;
      }

      if (!applications || applications.length === 0) {
        setFarmers([]);
        return;
      }

      // Get the user IDs to fetch their profiles
      const userIds = applications.map(app => app.user_id);
      
      const { data: profiles, error: profileError } = await supabase
        .rpc('get_farmer_public_locations', { _user_ids: userIds });

      if (profileError) {
        console.error('Error fetching profiles:', profileError);
        // Proceed without profile data; we'll use fallbacks for location fields
      }

      // Combine the data (dedupe by farmer user_id — a user may have multiple approved applications)
      const uniqueApplications = Array.from(
        new Map(applications.map(app => [app.user_id, app])).values()
      );

      const farmersData = uniqueApplications.map(farmer => {
        const profile = profiles?.find(p => p.id === farmer.user_id);
        return {
          id: farmer.user_id,
          display_name: farmer.display_name,
          farm_name: farmer.farm_name,
          farm_description: farmer.farm_description || '',
          city: profile?.city || '',
          state: profile?.state || '',
          country: profile?.country || '',
          zip_code: profile?.zip_code || '',
          categories: Array.isArray(farmer.categories) ? farmer.categories.map(c => String(c)) : [],
          certifications: Array.isArray(farmer.certifications) ? farmer.certifications.map(c => String(c)) : [],
          next_harvest_date: farmer.next_harvest_date,
        };
      });

      setFarmers(farmersData);

      // Extract unique cities and states for filtering
      const uniqueCities = [...new Set(farmersData.map(f => f.city).filter(Boolean))];
      const uniqueStates = [...new Set(farmersData.map(f => f.state).filter(Boolean))];
      setCities(uniqueCities.sort());
      setStates(uniqueStates.sort());

    } catch (error) {
      console.error('Error fetching farmers:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleViewProducts = (farmer: Farmer) => {
    // Navigate to shop page filtered by farmer
    navigate(`/shop?farmer=${encodeURIComponent(farmer.farm_name)}`);
  };

  const filteredFarmers = farmers.filter(farmer => {
    const matchesSearch = searchTerm === "" || 
      farmer.farm_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      farmer.display_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      farmer.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
      farmer.zip_code.includes(searchTerm);
    
    const matchesCity = selectedCity === "all" || farmer.city === selectedCity;
    const matchesState = selectedState === "all" || farmer.state === selectedState;
    
    return matchesSearch && matchesCity && matchesState;
  });

  const getRandomImage = (index: number) => {
    const images = [heroImage, produceImage, livestockImage];
    return images[index % images.length];
  };
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="py-20 bg-gradient-to-br from-background via-accent/20 to-secondary">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6">
              Meet Our <span className="text-primary">Farmers</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
              Connect directly with passionate farmers and producers who are committed to 
              bringing you the freshest, highest-quality products from their land to your table.
            </p>
          </div>
        </section>

        {/* Search and Filter Section */}
        <section className="py-8 bg-gradient-to-br from-background via-accent/10 to-secondary/10">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-2xl font-bold text-foreground mb-6 text-center">Find Farmers Near You</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="md:col-span-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      placeholder="Search by farm name, farmer, city, or zip code..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                
                <div>
                  <Select value={selectedState} onValueChange={setSelectedState}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select State" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All States</SelectItem>
                      {states.map(state => (
                        <SelectItem key={state} value={state}>{state}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Select value={selectedCity} onValueChange={setSelectedCity}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select City" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Cities</SelectItem>
                      {cities.map(city => (
                        <SelectItem key={city} value={city}>{city}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Farmers Grid */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="mb-12 text-center">
              <h2 className="text-3xl font-bold text-foreground mb-4">
                {filteredFarmers.length > 0 ? `Found ${filteredFarmers.length} Approved Farmers` : 'No Farmers Found'}
              </h2>
              {filteredFarmers.length > 0 && (
                <p className="text-muted-foreground">
                  Trusted producers committed to quality and sustainability
                </p>
              )}
            </div>

            {loading ? (
              <div className="flex justify-center items-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : filteredFarmers.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground mb-4">No farmers found matching your criteria.</p>
                <Button onClick={() => {
                  setSearchTerm("");
                  setSelectedCity("all");
                  setSelectedState("all");
                }}>
                  Clear Filters
                </Button>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 gap-8">
                {filteredFarmers.map((farmer, index) => (
                  <Card key={farmer.id} className="group hover:shadow-xl transition-all duration-300 border-0 shadow-soft">
                    <CardContent className="p-0">
                      <div className="grid md:grid-cols-2 gap-0">
                        {/* Image */}
                        <div className="relative overflow-hidden rounded-l-lg">
                          <img
                            src={getRandomImage(index)}
                            alt={farmer.farm_name}
                            className="w-full h-64 md:h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                          <div className="absolute top-4 left-4">
                            <Badge className="bg-primary text-primary-foreground">
                              <Users className="h-3 w-3 mr-1" />
                              {farmer.categories.length} Categories
                            </Badge>
                          </div>
                        </div>

                        {/* Content */}
                        <div className="p-6 space-y-4">
                          <div>
                            <h3 className="text-xl font-bold text-foreground group-hover:text-primary transition-colors">
                              {farmer.farm_name}
                            </h3>
                          </div>

                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            <MapPin className="h-3 w-3" />
                            <span>
                              {[farmer.city, farmer.state].filter(Boolean).join(', ')}{farmer.zip_code && ` ${farmer.zip_code}`}
                            </span>
                          </div>

                          <p className="text-sm text-muted-foreground leading-relaxed line-clamp-3">
                            {farmer.farm_description || 'Local farm committed to providing fresh, quality products.'}
                          </p>

                          {farmer.categories.length > 0 && (
                            <div className="space-y-2">
                              <p className="text-xs font-medium text-muted-foreground">SPECIALIZES IN</p>
                              <div className="flex flex-wrap gap-1">
                                {farmer.categories.slice(0, 2).map((category) => (
                                  <Badge key={`${farmer.id}-cat-${category}`} variant="secondary" className="text-xs">
                                    {category}
                                  </Badge>
                                ))}
                                {farmer.categories.length > 2 && (
                                  <Badge variant="outline" className="text-xs">
                                    +{farmer.categories.length - 2} more
                                  </Badge>
                                )}
                              </div>
                            </div>
                          )}

                          {farmer.certifications.length > 0 && (
                            <div className="space-y-2">
                              <p className="text-xs font-medium text-muted-foreground">CERTIFICATIONS</p>
                              <div className="flex flex-wrap gap-1">
                                {farmer.certifications.slice(0, 3).map((cert) => (
                                  <Badge key={`${farmer.id}-cert-${cert}`} variant="outline" className="text-xs">
                                    <Leaf className="h-2 w-2 mr-1" />
                                    {cert}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}

                          {farmer.next_harvest_date && (
                            <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                              <div className="flex items-center gap-2 mb-1">
                                <Calendar className="h-3 w-3 text-green-600" />
                                <p className="text-xs font-medium text-green-700 uppercase tracking-wide">Next Harvest</p>
                              </div>
                              <p className="text-sm font-medium text-green-800">
                                {new Date(farmer.next_harvest_date).toLocaleDateString('en-US', {
                                  month: 'short',
                                  day: 'numeric',
                                  year: 'numeric'
                                })}
                              </p>
                              <p className="text-xs text-green-600 mt-1">
                                Fresh products coming soon!
                              </p>
                            </div>
                          )}

                          <Button 
                            variant="hero" 
                            className="w-full"
                            onClick={() => handleViewProducts(farmer)}
                          >
                            View Products
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* CTA Section - Only show if user is not already a farmer */}
        {!isFarmer && (
          <section className="py-20 bg-gradient-to-r from-primary/10 to-accent/10">
            <div className="container mx-auto px-4 text-center">
              <h2 className="text-3xl font-bold text-foreground mb-4">
                Want to Sell on Farm2Door?
              </h2>
              <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
                Join our community of trusted farmers and start selling your products 
                directly to customers who value fresh, local produce.
              </p>
              <Button 
                variant="hero" 
                size="lg"
                onClick={() => navigate("/farmer-onboarding")}
              >
                Apply to Become a Seller
              </Button>
            </div>
          </section>
        )}
      </main>
      
      <Footer />
    </div>
  );
};

export default Farmers;