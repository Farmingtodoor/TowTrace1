import { useCallback, useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import {
  AlertTriangle, CheckCircle, Clock, DollarSign, Download, ExternalLink,
  Landmark, Package, Wallet, XCircle,
} from "lucide-react";
import { downloadPayoutReceiptPdf, type PayoutReceipt } from "@/lib/payoutReceipt";

interface PayoutRequest {
  id: string;
  amount: number;
  status: string;
  requested_at: string;
  reviewed_at: string | null;
  admin_notes: string | null;
  bank_account_holder: string;
}

interface PayoutAccountState {
  connected: boolean;
  payouts_enabled: boolean;
  details_submitted: boolean;
  bank_last4?: string | null;
  bank_name?: string | null;
}

interface PaidOrder {
  id: string;
  created_at: string;
  paid_at: string | null;
  total_amount: number;
  farmer_earnings: number | null;
  payment_status: string | null;
}

const statusBadge = (status: string) => {
  switch (status) {
    case "pending":
      return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" />Pending review</Badge>;
    case "approved":
      return <Badge variant="default"><CheckCircle className="h-3 w-3 mr-1" />Approved</Badge>;
    case "rejected":
      return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" />Rejected</Badge>;
    case "paid":
      return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200"><CheckCircle className="h-3 w-3 mr-1" />Paid</Badge>;
    default:
      return <Badge variant="secondary">{status}</Badge>;
  }
};

export default function FarmerDashboard() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [approved, setApproved] = useState<boolean | null>(null);
  const [account, setAccount] = useState<PayoutAccountState | null>(null);
  const [accountLoading, setAccountLoading] = useState(true);
  const [connecting, setConnecting] = useState(false);
  const [requests, setRequests] = useState<PayoutRequest[]>([]);
  const [receipts, setReceipts] = useState<Record<string, PayoutReceipt>>({});
  const [orders, setOrders] = useState<PaidOrder[]>([]);

  const loadAccount = useCallback(async () => {
    setAccountLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("farmer-payout-account", {
        body: { action: "status" },
      });
      if (error) throw error;
      setAccount(data as PayoutAccountState);
    } catch (error) {
      console.error("Error loading payout account:", error);
      setAccount({ connected: false, payouts_enabled: false, details_submitted: false });
    } finally {
      setAccountLoading(false);
    }
  }, []);

  const loadData = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const [appRes, payoutRes, receiptRes, orderRes] = await Promise.all([
        supabase
          .from("farmer_applications")
          .select("status")
          .eq("user_id", user.id)
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle(),
        supabase.rpc("get_decrypted_payout_requests", { p_farmer_id: user.id }),
        supabase
          .from("payout_receipts")
          .select("*")
          .eq("farmer_id", user.id)
          .order("sent_at", { ascending: false }),
        supabase
          .from("orders")
          .select("id, created_at, paid_at, total_amount, farmer_earnings, payment_status")
          .eq("farmer_id", user.id)
          .eq("payment_status", "paid")
          .order("paid_at", { ascending: false })
          .limit(100),
      ]);

      setApproved(appRes.data?.status === "approved");
      setRequests((payoutRes.data as PayoutRequest[]) || []);

      const map: Record<string, PayoutReceipt> = {};
      (receiptRes.data || []).forEach((r: any) => {
        if (!map[r.payout_request_id]) map[r.payout_request_id] = r as PayoutReceipt;
      });
      setReceipts(map);
      setOrders((orderRes.data as PaidOrder[]) || []);
    } catch (error) {
      console.error("Error loading farmer dashboard:", error);
      toast.error("Could not load your dashboard");
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    if (user) {
      loadData();
      loadAccount();
    }
  }, [user, loadData, loadAccount]);

  const startOnboarding = async () => {
    if (approved === false) {
      toast.error("Your farm must be approved before you can connect a bank account.");
      return;
    }
    setConnecting(true);
    try {
      const { data, error } = await supabase.functions.invoke("farmer-payout-account", {
        body: { action: "onboard" },
      });
      if (error) throw error;
      if ((data as { error?: string })?.error === "FARM_NOT_VERIFIED") {
        toast.error("Your farm must be approved before you can connect a bank account.");
        return;
      }
      if (data?.url) {
        window.location.href = data.url as string;
        return;
      }
      toast.error("Could not start bank verification. Please try again.");
    } catch (error) {
      console.error("Error starting onboarding:", error);
      toast.error("Could not start bank verification. Please try again.");
    } finally {
      setConnecting(false);
    }
  };

  const totals = useMemo(() => {
    const earned = orders.reduce(
      (sum, o) => sum + Number(o.farmer_earnings ?? o.total_amount ?? 0),
      0,
    );
    const paidOut = requests
      .filter((r) => r.status === "paid")
      .reduce((sum, r) => sum + Number(r.amount || 0), 0);
    const pending = requests
      .filter((r) => r.status === "pending" || r.status === "approved")
      .reduce((sum, r) => sum + Number(r.amount || 0), 0);
    return { earned, paidOut, pending, available: Math.max(earned - paidOut - pending, 0) };
  }, [orders, requests]);

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <h1 className="text-2xl font-bold">Please sign in to view your farm dashboard</h1>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 container mx-auto px-4 py-8 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-3xl font-bold">Farm dashboard</h1>
            <p className="text-muted-foreground">
              Track earnings, verify your bank account, and download payout receipts.
            </p>
          </div>
          <div className="flex gap-2">
            <Button asChild variant="outline"><Link to="/farmer/orders">Orders</Link></Button>
            <Button asChild variant="outline" disabled={approved === false}><Link to="/farmer-payouts">Request payout</Link></Button>
          </div>
        </div>

        {approved === false && (
          <Card className="border-amber-200 bg-amber-50/60">
            <CardContent className="flex items-start gap-2 py-4 text-sm">
              <AlertTriangle className="h-4 w-4 mt-0.5 text-amber-600" />
              <p>
                Your farm isn't approved yet. Finish onboarding to start selling and receiving payouts.{" "}
                <Link to="/farmer-onboarding" className="underline font-medium">Complete onboarding</Link>
              </p>
            </CardContent>
          </Card>
        )}

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { label: "Total earned", value: totals.earned, icon: DollarSign },
            { label: "Paid out", value: totals.paidOut, icon: Wallet },
            { label: "In review", value: totals.pending, icon: Clock },
            { label: "Available", value: totals.available, icon: Package },
          ].map(({ label, value, icon: Icon }) => (
            <Card key={label}>
              <CardContent className="py-4">
                <div className="flex items-center justify-between">
                  <p className="text-sm text-muted-foreground">{label}</p>
                  <Icon className="h-4 w-4 text-primary" />
                </div>
                <p className="text-2xl font-bold tabular-nums">${value.toFixed(2)}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Landmark className="h-5 w-5" />
              Bank account
            </CardTitle>
            <CardDescription>
              Verification is handled securely by Stripe — we never store your bank details.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {approved === false ? (
              <div className="flex items-start gap-2 text-sm text-muted-foreground">
                <AlertTriangle className="h-4 w-4 mt-0.5 text-amber-600" />
                <p>Bank connection unlocks once your farm is verified by an admin.</p>
              </div>
            ) : accountLoading ? (
              <div className="h-10 bg-muted rounded animate-pulse" />
            ) : account?.payouts_enabled ? (
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2 text-sm">
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                    <CheckCircle className="h-3 w-3 mr-1" /> Verified
                  </Badge>
                  <span className="text-muted-foreground">
                    {account.bank_name || "Bank account"} ••••{account.bank_last4 || "----"}
                  </span>
                </div>
                <Button variant="outline" size="sm" onClick={startOnboarding} disabled={connecting}>
                  <ExternalLink className="h-3.5 w-3.5 mr-1" /> Update bank details
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-start gap-2 text-sm text-muted-foreground">
                  <AlertTriangle className="h-4 w-4 mt-0.5 text-amber-600" />
                  <p>
                    {account?.connected
                      ? "Your verification isn't finished yet, so payouts can't be sent."
                      : "Connect a bank account to receive payouts."}
                  </p>
                </div>
                <Button onClick={startOnboarding} disabled={connecting}>
                  <Landmark className="h-4 w-4 mr-2" />
                  {connecting
                    ? "Opening secure setup…"
                    : account?.connected
                      ? "Finish verification"
                      : "Connect bank account"}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Payout requests</CardTitle>
            <CardDescription>Status of every payout you've requested, with receipts.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {loading ? (
              <div className="h-16 bg-muted rounded animate-pulse" />
            ) : requests.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                No payout requests yet.{" "}
                <Link to="/farmer-payouts" className="underline">Request your first payout</Link>.
              </p>
            ) : (
              requests.map((request) => (
                <div key={request.id} className="rounded-lg border p-4 space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-semibold tabular-nums">${Number(request.amount).toFixed(2)}</span>
                    {statusBadge(request.status)}
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Requested {new Date(request.requested_at).toLocaleDateString()}
                    {request.reviewed_at && ` • Reviewed ${new Date(request.reviewed_at).toLocaleDateString()}`}
                  </p>
                  {request.admin_notes && (
                    <p className="text-sm text-muted-foreground">Admin note: {request.admin_notes}</p>
                  )}
                  {receipts[request.id] && (
                    <>
                      <Separator />
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div className="text-sm">
                          <p className="font-medium">Receipt {receipts[request.id].receipt_number}</p>
                          <p className="text-muted-foreground">
                            {receipts[request.id].status === "sent" ? "Sent" : "Failed"} on{" "}
                            {new Date(receipts[request.id].sent_at).toLocaleString()}
                          </p>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() =>
                            downloadPayoutReceiptPdf(receipts[request.id], request.bank_account_holder)
                          }
                        >
                          <Download className="h-3.5 w-3.5 mr-1" /> Download PDF
                        </Button>
                      </div>
                    </>
                  )}
                </div>
              ))
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent paid orders</CardTitle>
            <CardDescription>Customer payments that count toward your available balance.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {orders.length === 0 ? (
              <p className="text-sm text-muted-foreground">No paid orders yet.</p>
            ) : (
              orders.slice(0, 10).map((order) => (
                <div key={order.id} className="flex items-center justify-between text-sm border-b last:border-0 py-2">
                  <div>
                    <p className="font-medium">Order #{order.id.slice(0, 8)}</p>
                    <p className="text-muted-foreground">
                      Paid {new Date(order.paid_at || order.created_at).toLocaleDateString()}
                    </p>
                  </div>
                  <span className="tabular-nums font-semibold">
                    ${Number(order.farmer_earnings ?? order.total_amount ?? 0).toFixed(2)}
                  </span>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </main>
      <Footer />
    </div>
  );
}
