import { useState, useEffect } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/integrations/supabase/client'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { CalendarDays, ChevronRight, Clock, CreditCard, MapPin, Package, Truck, Store } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Link } from 'react-router-dom'
import { format } from 'date-fns'
import OrderTracker from '@/components/realtime/OrderTracker';

interface OrderItem {
  product_name: string
  quantity: number
  unit_price: number
  total_price: number
  product_description?: string
}

interface Order {
  id: string
  created_at: string
  status: string
  total_amount: number
  delivery_address: string | null
  delivery_type: string
  customer_notes: string | null
  farmer_notes: string | null
  payment_status?: string | null
  paid_at?: string | null
  amount_paid?: number | null
  currency?: string | null
  platform_fee?: number | null
  farmer_earnings?: number | null
  pickup_scheduled_at?: string | null
  pickup_scheduled_end?: string | null
  delivery_scheduled_at?: string | null
  delivery_scheduled_end?: string | null
  order_items?: OrderItem[]
}


const MyOrders = () => {
  const { user } = useAuth()
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (user) {
      fetchOrders()
    }
  }, [user])

  const fetchOrders = async () => {
    if (!user) return
    
    try {
      // First, get the user's profile to get their profile ID
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('id')
        .eq('email', user.email)
        .single()

      if (profileError) throw profileError

      // Then fetch orders for this customer
      const { data, error } = await supabase
        .from('orders')
        .select(`
          *,
          order_items (
            product_name,
            quantity,
            unit_price,
            total_price,
            product_description
          )
        `)
        .eq('customer_id', profile.id)
        .order('created_at', { ascending: false })

      if (error) throw error
      setOrders(data || [])
    } catch (error) {
      console.error('Error fetching orders:', error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800'
      case 'confirmed': return 'bg-blue-100 text-blue-800'
      case 'processing': return 'bg-orange-100 text-orange-800'
      case 'shipped': return 'bg-purple-100 text-purple-800'
      case 'delivered': return 'bg-green-100 text-green-800'
      case 'cancelled': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Please sign in to view your orders</h1>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  const formatWindow = (start?: string | null, end?: string | null) => {
    if (!start) return null
    const s = new Date(start).toLocaleString()
    return end ? `${s} – ${new Date(end).toLocaleTimeString()}` : s
  }

  const activeOrders = orders.filter((o) => !['delivered', 'cancelled'].includes(o.status))
  const pastOrders = orders.filter((o) => ['delivered', 'cancelled'].includes(o.status))

  const renderOrder = (order: Order) => {
    const isPickup = order.delivery_type === 'pickup'
    const eta = isPickup
      ? formatWindow(order.pickup_scheduled_at, order.pickup_scheduled_end)
      : formatWindow(order.delivery_scheduled_at, order.delivery_scheduled_end)

    return (
      <Card key={order.id}>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-lg">Order #{order.id.slice(0, 8)}</CardTitle>
              <CardDescription className="flex items-center gap-2 mt-1">
                <CalendarDays className="h-4 w-4" />
                {format(new Date(order.created_at), 'PPP')}
              </CardDescription>
            </div>
            <div className="flex flex-col items-end gap-2">
              <Badge className={getStatusColor(order.status)}>
                {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
              </Badge>
              <Button asChild size="sm" variant="outline" className="h-7">
                <Link to={`/my-orders/${order.id}`}>
                  Track order <ChevronRight className="h-3.5 w-3.5 ml-1" />
                </Link>
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
              <span className="flex items-center gap-2">
                {isPickup ? <Store className="h-4 w-4" /> : <Truck className="h-4 w-4" />}
                {isPickup ? 'Farm pickup' : 'Delivery'}
              </span>
              <span className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                {eta ? `${isPickup ? 'Pickup window' : 'ETA'}: ${eta}` : 'Not scheduled yet'}
              </span>
            </div>

            {order.delivery_address && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4" />
                {order.delivery_address}
              </div>
            )}

            <Separator />

            <div>
              <h4 className="font-medium mb-2">Items</h4>
              <div className="space-y-2">
                {order.order_items?.map((item: OrderItem, index: number) => (
                  <div key={index} className="flex justify-between text-sm">
                    <span>{item.product_name} x{item.quantity}</span>
                    <span>${item.total_price.toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </div>

            <Separator />

            {(order.status === 'confirmed' ||
              order.status === 'preparing' ||
              order.status === 'ready' ||
              order.status === 'picked_up' ||
              order.status === 'out_for_delivery') && (
              <div className="mt-4">
                <OrderTracker orderId={order.id} />
              </div>
            )}

            <div className="flex justify-between font-medium">
              <span>Total</span>
              <span>${order.total_amount.toFixed(2)}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  const emptyState = (message: string) => (
    <Card>
      <CardContent className="text-center py-12">
        <Package className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
        <h3 className="text-lg font-medium mb-2">Nothing here yet</h3>
        <p className="text-muted-foreground">{message}</p>
      </CardContent>
    </Card>
  )

  const paidOrders = orders.filter((o) => o.payment_status === 'paid')
  const totalPaid = paidOrders.reduce((sum, o) => sum + Number(o.amount_paid ?? o.total_amount ?? 0), 0)

  const renderPayment = (order: Order) => {
    const isPaid = order.payment_status === 'paid'
    const amount = Number(order.amount_paid ?? order.total_amount ?? 0)
    return (
      <Card key={order.id}>
        <CardContent className="py-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="font-medium">Order #{order.id.slice(0, 8)}</p>
              <p className="text-sm text-muted-foreground flex items-center gap-1.5">
                <CalendarDays className="h-3.5 w-3.5" />
                {isPaid && order.paid_at
                  ? `Paid on ${format(new Date(order.paid_at), 'PPp')}`
                  : `Placed ${format(new Date(order.created_at), 'PPP')}`}
              </p>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <p className="font-semibold tabular-nums">${amount.toFixed(2)}</p>
                <p className="text-xs text-muted-foreground uppercase">{order.currency || 'usd'}</p>
              </div>
              <Badge className={isPaid ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}>
                <CreditCard className="h-3 w-3 mr-1" />
                {isPaid ? 'Paid' : 'Payment pending'}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold mb-2">My Orders</h1>
          <p className="text-muted-foreground mb-6">
            Follow your order timeline, delivery ETA and pickup windows in one place.
          </p>

          {loading ? (
            <div className="flex justify-center items-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : (
            <Tabs defaultValue="active" className="space-y-6">
              <TabsList>
                <TabsTrigger value="active">In progress ({activeOrders.length})</TabsTrigger>
                <TabsTrigger value="past">Past orders ({pastOrders.length})</TabsTrigger>
                <TabsTrigger value="payments">Payments ({paidOrders.length})</TabsTrigger>
              </TabsList>

              <TabsContent value="active" className="space-y-6">
                {activeOrders.length === 0
                  ? emptyState('Your active orders will appear here once you place an order.')
                  : activeOrders.map(renderOrder)}
              </TabsContent>

              <TabsContent value="past" className="space-y-6">
                {pastOrders.length === 0
                  ? emptyState('Completed and cancelled orders will be listed here.')
                  : pastOrders.map(renderOrder)}
              </TabsContent>

              <TabsContent value="payments" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Payment summary</CardTitle>
                    <CardDescription>
                      Every charge for your orders, with the date each payment cleared.
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="flex flex-wrap gap-8">
                    <div>
                      <p className="text-sm text-muted-foreground">Total paid</p>
                      <p className="text-2xl font-bold tabular-nums">${totalPaid.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Paid orders</p>
                      <p className="text-2xl font-bold tabular-nums">{paidOrders.length}</p>
                    </div>
                  </CardContent>
                </Card>

                {orders.length === 0
                  ? emptyState('Payments will show up here as soon as you place your first order.')
                  : orders.map(renderPayment)}
              </TabsContent>
            </Tabs>
          )}
        </div>

      </main>
      <Footer />
    </div>
  )
}

export default MyOrders