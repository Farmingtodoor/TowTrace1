import { useState } from "react";
import { Link, Navigate, useLocation, useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useAuth } from "@/contexts/AuthContext";
import { useAdmin } from "@/contexts/AdminContext";
import { AlertCircle, Loader2, Sprout } from "lucide-react";

const reasonMessages: Record<string, { title: string; body: string }> = {
  unauthenticated: {
    title: "Sign in required",
    body: "The admin portal is restricted. Sign in with an administrator or farmer account to continue.",
  },
  forbidden: {
    title: "You don't have admin access",
    body: "Your account is signed in, but it doesn't carry an admin, super admin, or farmer role. Sign in with an authorized account or contact a super admin.",
  },
  expired: {
    title: "Session expired",
    body: "Your session is no longer valid. Please sign in again to return to the admin portal.",
  },
};

export default function AdminLogin() {
  const [params] = useSearchParams();
  const location = useLocation();
  const navigate = useNavigate();
  const { user, signIn, signOut } = useAuth();
  const { isAdmin, isFarmer, loading: roleLoading, refreshRole } = useAdmin();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const reason = params.get("reason") || "unauthenticated";
  const from = (location.state as { from?: string } | null)?.from || params.get("from") || "/admin";
  const message = reasonMessages[reason] ?? reasonMessages.unauthenticated;

  if (user && !roleLoading && (isAdmin || isFarmer)) {
    return <Navigate to={from} replace />;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    const { error: signInError } = await signIn(email, password);
    if (signInError) {
      setError(signInError.message || "Unable to sign in. Check your credentials and try again.");
      setSubmitting(false);
      return;
    }
    await refreshRole();
    setSubmitting(false);
    navigate(from, { replace: true });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 px-4 py-12">
      <div className="w-full max-w-md space-y-6">
        <div className="flex items-center justify-center gap-2.5">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary">
            <Sprout className="h-6 w-6 text-primary-foreground" />
          </div>
          <div className="leading-tight">
            <p className="font-semibold">Farming2Door</p>
            <p className="text-xs text-muted-foreground">Admin portal</p>
          </div>
        </div>

        <Alert variant={reason === "forbidden" ? "destructive" : "default"}>
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>{message.title}</AlertTitle>
          <AlertDescription>{message.body}</AlertDescription>
        </Alert>

        <Card>
          <CardHeader>
            <CardTitle>Admin sign in</CardTitle>
            <CardDescription>Use the email and password for your admin account.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="admin-email">Email</Label>
                <Input
                  id="admin-email"
                  type="email"
                  autoComplete="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@farm.com"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="admin-password">Password</Label>
                <Input
                  id="admin-password"
                  type="password"
                  autoComplete="current-password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              {error && <p className="text-sm text-destructive">{error}</p>}
              <Button type="submit" className="w-full" disabled={submitting}>
                {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Sign in
              </Button>
            </form>

            <div className="mt-4 flex items-center justify-between text-sm">
              <Link to="/" className="text-muted-foreground hover:text-foreground">
                Back to site
              </Link>
              {user && (
                <button
                  type="button"
                  className="text-muted-foreground hover:text-foreground"
                  onClick={async () => {
                    await signOut();
                  }}
                >
                  Sign out of current account
                </button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
