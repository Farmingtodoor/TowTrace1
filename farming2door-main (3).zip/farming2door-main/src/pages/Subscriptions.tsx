import SEOHead from '@/components/SEOHead';
import { SubscriptionPlansGrid } from '@/components/subscriptions/SubscriptionPlansGrid';
import { MySubscriptions } from '@/components/subscriptions/MySubscriptions';
import { FarmerSubscriptionManager } from '@/components/subscriptions/FarmerSubscriptionManager';
import { useAuth } from '@/contexts/AuthContext';
import { useAdmin } from '@/contexts/AdminContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

const Subscriptions = () => {
  const { user } = useAuth();
  const { isFarmer } = useAdmin();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const defaultTab = searchParams.get('tab') === 'my-subscriptions' ? 'my-subscriptions' : 'shop';

  return (
    <>
      <SEOHead 
        title="Farm Subscriptions - Fresh Produce Delivered Regularly"
        description="Subscribe to weekly or monthly farm boxes with fresh, seasonal produce delivered directly from local farmers to your door."
      />
      <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
        <div className="container mx-auto px-4 py-8">
          <Button
            variant="outline"
            onClick={() => navigate(-1)}
            className="mb-6 flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
          
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Farm Subscriptions
            </h1>
            <p className="text-xl text-gray-600">
              Get fresh, seasonal produce delivered regularly from local farms
            </p>
          </div>

          {user ? (
            <Tabs defaultValue={defaultTab} className="w-full">
              <TabsList className={`grid w-full ${isFarmer ? 'grid-cols-3' : 'grid-cols-2'} mb-6`}>
                <TabsTrigger value="shop">Shop Plans</TabsTrigger>
                <TabsTrigger value="my-subscriptions">
                  {isFarmer ? 'Customer Subscriptions' : 'My Subscriptions'}
                </TabsTrigger>
                {isFarmer && (
                  <TabsTrigger value="manage-plans">Manage Plans</TabsTrigger>
                )}
              </TabsList>
              <TabsContent value="shop" className="space-y-6">
                <SubscriptionPlansGrid />
              </TabsContent>
              <TabsContent value="my-subscriptions" className="space-y-6">
                <MySubscriptions />
              </TabsContent>
              {isFarmer && (
                <TabsContent value="manage-plans" className="space-y-6">
                  <FarmerSubscriptionManager />
                </TabsContent>
              )}
            </Tabs>
          ) : (
            <div className="space-y-6">
              <SubscriptionPlansGrid />
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default Subscriptions;