import { useCallback, useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { AuthGuard } from "@/components/auth/AuthGuard";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SEOHead from "@/components/SEOHead";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, Check, Clock, Loader2, MapPin, Package, RefreshCw, Store, Truck } from "lucide-react";
import { cn } from "@/lib/utils";

interface OrderItem {
  id: string;
  product_name: string;
  quantity: number;
  unit_price: number;
  total_price: number;
}

interface OrderRow {
  id: string;
  status: string;
  total_amount: number;
  delivery_type: string;
  delivery_address: string | null;
  customer_notes: string | null;
  pickup_scheduled_at: string | null;
  pickup_scheduled_end: string | null;
  delivery_scheduled_at: string | null;
  delivery_scheduled_end: string | null;
  created_at: string;
  updated_at: string;
}

const STATUS_FLOW = ["pending", "confirmed", "processing", "out_for_delivery", "delivered"] as const;

const statusStyles: Record<string, string> = {
  pending: "bg-amber-100 text-amber-900 border-amber-200",
  confirmed: "bg-blue-100 text-blue-900 border-blue-200",
  processing: "bg-purple-100 text-purple-900 border-purple-200",
  out_for_delivery: "bg-sky-100 text-sky-900 border-sky-200",
  delivered: "bg-emerald-100 text-emerald-900 border-emerald-200",
  cancelled: "bg-destructive/10 text-destructive border-destructive/20",
};

export const formatWindow = (start?: string | null, end?: string | null) => {
  if (!start) return "Not scheduled yet";
  const s = new Date(start).toLocaleString();
  return end ? `${s} – ${new Date(end).toLocaleTimeString()}` : s;
};

const pretty = (value?: string | null) => String(value ?? "").replace(/_/g, " ");

function CustomerOrderTimelineContent() {
  const { orderId } = useParams<{ orderId: string }>();
  const navigate = useNavigate();
  const [order, setOrder] = useState<OrderRow | null>(null);
  const [items, setItems] = useState<OrderItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [live, setLive] = useState(false);
  const [lastUpdateAt, setLastUpdateAt] = useState<Date | null>(null);

  const load = useCallback(async () => {
    if (!orderId) return;
    const [orderRes, itemsRes] = await Promise.all([
      supabase
        .from("orders")
        .select(
          "id, status, total_amount, delivery_type, delivery_address, customer_notes, pickup_scheduled_at, pickup_scheduled_end, delivery_scheduled_at, delivery_scheduled_end, created_at, updated_at"
        )
        .eq("id", orderId)
        .maybeSingle(),
      supabase
        .from("order_items")
        .select("id, product_name, quantity, unit_price, total_price")
        .eq("order_id", orderId),
    ]);

    setOrder((orderRes.data as OrderRow) ?? null);
    setItems((itemsRes.data as OrderItem[]) ?? []);
    setLoading(false);
  }, [orderId]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    if (!orderId) return;
    const channel = supabase
      .channel(`customer-order-${orderId}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "orders", filter: `id=eq.${orderId}` },
        (payload) => {
          setOrder((prev) => ({ ...(prev ?? ({} as OrderRow)), ...(payload.new as OrderRow) }));
          setLastUpdateAt(new Date());
        }
      )
      .subscribe((status) => setLive(status === "SUBSCRIBED"));

    return () => {
      supabase.removeChannel(channel);
    };
  }, [orderId]);

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="container mx-auto max-w-3xl px-4 py-16 text-center">
        <p className="mb-4 text-muted-foreground">We couldn't load this order.</p>
        <Button variant="outline" onClick={() => navigate("/my-orders")}>
          Back to my orders
        </Button>
      </div>
    );
  }

  const isPickup = order.delivery_type === "pickup";
  const cancelled = order.status === "cancelled";
  const currentIndex = STATUS_FLOW.indexOf(order.status as (typeof STATUS_FLOW)[number]);

  const steps = [
    { key: "pending", label: "Order placed", detail: new Date(order.created_at).toLocaleString() },
    { key: "confirmed", label: "Confirmed by the farm", detail: "The farm accepted your order" },
    { key: "processing", label: "Being prepared", detail: "Your farmer is getting the order ready" },
    {
      key: "out_for_delivery",
      label: isPickup ? "Ready for pickup" : "Out for delivery",
      detail: isPickup
        ? formatWindow(order.pickup_scheduled_at, order.pickup_scheduled_end)
        : order.delivery_scheduled_at
          ? `ETA ${formatWindow(order.delivery_scheduled_at, order.delivery_scheduled_end)}`
          : order.delivery_address ?? "On the way to you",
    },
    {
      key: "delivered",
      label: isPickup ? "Picked up" : "Delivered",
      detail: new Date(order.updated_at).toLocaleString(),
    },
  ];

  return (
    <div className="container mx-auto max-w-4xl space-y-6 px-4 py-8">
      <SEOHead
        title={`Order #${String(order.id).slice(0, 8)} tracking | Farming2Door`}
        description="Track your farm order status, delivery ETA and pickup window in real time."
      />

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" asChild aria-label="Back to my orders">
            <Link to="/my-orders">
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Order #{String(order.id).slice(0, 8)}</h1>
            <p className="text-sm text-muted-foreground">
              Placed {new Date(order.created_at).toLocaleString()}
            </p>
          </div>
          <Badge
            variant="outline"
            className={cn("capitalize", statusStyles[order.status] ?? "bg-accent text-accent-foreground")}
          >
            {pretty(order.status)}
          </Badge>
        </div>

        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <span
              className={cn("h-2 w-2 rounded-full", live ? "animate-pulse bg-emerald-500" : "bg-muted-foreground/40")}
            />
            {live ? "Live" : "Offline"}
            {lastUpdateAt && ` · updated ${lastUpdateAt.toLocaleTimeString()}`}
          </span>
          <Button variant="outline" size="sm" onClick={load}>
            <RefreshCw className="mr-2 h-3.5 w-3.5" /> Refresh
          </Button>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Clock className="h-4 w-4 text-primary" /> Order progress
            </CardTitle>
            <CardDescription>Updates from the farm appear here instantly.</CardDescription>
          </CardHeader>
          <CardContent>
            {cancelled ? (
              <p className="rounded-lg border border-destructive/20 bg-destructive/5 p-4 text-sm text-destructive">
                This order was cancelled on {new Date(order.updated_at).toLocaleString()}.
              </p>
            ) : (
              <ol className="space-y-4">
                {steps.map((step, index) => {
                  const done = currentIndex >= index && currentIndex >= 0;
                  const active = currentIndex === index;
                  return (
                    <li key={step.key} className="flex gap-3">
                      <div className="flex flex-col items-center">
                        <span
                          className={cn(
                            "flex h-6 w-6 items-center justify-center rounded-full border text-[11px]",
                            done
                              ? "border-primary bg-primary text-primary-foreground"
                              : "border-muted-foreground/30 text-muted-foreground"
                          )}
                        >
                          {done ? <Check className="h-3.5 w-3.5" /> : index + 1}
                        </span>
                        {index < steps.length - 1 && (
                          <span className={cn("mt-1 w-px flex-1", done ? "bg-primary/40" : "bg-muted-foreground/20")} />
                        )}
                      </div>
                      <div className="pb-2">
                        <p className={cn("text-sm", active ? "font-semibold" : "font-medium")}>{step.label}</p>
                        <p className="text-xs text-muted-foreground">{step.detail}</p>
                      </div>
                    </li>
                  );
                })}
              </ol>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              {isPickup ? <Store className="h-4 w-4 text-primary" /> : <Truck className="h-4 w-4 text-primary" />}
              {isPickup ? "Farm pickup" : "Delivery"}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            {isPickup ? (
              <p className="text-muted-foreground">
                {formatWindow(order.pickup_scheduled_at, order.pickup_scheduled_end)}
              </p>
            ) : (
              <>
                <p className="flex items-start gap-2 text-muted-foreground">
                  <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                  {order.delivery_address || "No delivery address on file."}
                </p>
                <p>
                  <span className="text-muted-foreground">ETA: </span>
                  {formatWindow(order.delivery_scheduled_at, order.delivery_scheduled_end)}
                </p>
              </>
            )}
            <Separator />
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Order total</span>
              <span className="font-semibold tabular-nums">${Number(order.total_amount).toFixed(2)}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Package className="h-4 w-4 text-primary" /> Items
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {items.map((item) => (
            <div key={item.id} className="flex items-start justify-between gap-4">
              <div className="min-w-0">
                <p className="text-sm font-medium">{item.product_name}</p>
                <p className="text-xs text-muted-foreground">
                  {item.quantity} × ${Number(item.unit_price).toFixed(2)}
                </p>
              </div>
              <span className="text-sm font-semibold tabular-nums">${Number(item.total_price).toFixed(2)}</span>
            </div>
          ))}
          {items.length === 0 && <p className="text-sm text-muted-foreground">No line items recorded.</p>}
        </CardContent>
      </Card>
    </div>
  );
}

export default function CustomerOrderTimeline() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">
        <AuthGuard>
          <CustomerOrderTimelineContent />
        </AuthGuard>
      </main>
      <Footer />
    </div>
  );
}
