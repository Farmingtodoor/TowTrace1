import { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, Loader2, Calendar, Package, MapPin } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { format, addDays } from 'date-fns';

interface SubscriptionDetails {
  id: string;
  status: string;
  next_delivery_date: string;
  delivery_address: string;
  subscription_plans: {
    name: string;
    description: string;
    price: number;
    interval_type: string;
    interval_count: number;
  };
}

const SubscriptionSuccess = () => {
  const [searchParams] = useSearchParams();
  const [subscription, setSubscription] = useState<SubscriptionDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();

  const sessionId = searchParams.get('session_id');

  useEffect(() => {
    if (!sessionId || !user) {
      setError('Invalid session or user not authenticated');
      setLoading(false);
      return;
    }

    handleSubscriptionSuccess();
  }, [sessionId, user]);

  const handleSubscriptionSuccess = async () => {
    try {
      console.log('Processing subscription success for session:', sessionId);

      // Call edge function to handle the successful subscription
      const { data, error } = await supabase.functions.invoke('handle-subscription-success', {
        body: { sessionId }
      });

      if (error) throw error;

      if (data.subscription) {
        setSubscription(data.subscription);
        toast({
          title: "Subscription Created Successfully!",
          description: "Your farm subscription is now active. You'll receive your first delivery soon.",
        });
      }
    } catch (error) {
      console.error('Error processing subscription:', error);
      setError('Failed to process subscription. Please contact support.');
      toast({
        title: "Error",
        description: "There was an issue processing your subscription. Please contact support.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const formatInterval = (intervalType: string, intervalCount: number) => {
    const unit = intervalCount === 1 ? intervalType.slice(0, -2) : intervalType;
    return intervalCount === 1 ? `Every ${unit}` : `Every ${intervalCount} ${unit}s`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-green-50 to-white flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="flex items-center justify-center py-8">
            <div className="text-center">
              <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
              <p className="text-muted-foreground">Processing your subscription...</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-red-50 to-white flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="text-center py-8">
            <div className="text-red-500 mb-4">
              <Package className="h-12 w-12 mx-auto" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Subscription Error</h3>
            <p className="text-muted-foreground mb-4">{error}</p>
            <Button onClick={() => navigate('/subscriptions')}>
              Back to Subscriptions
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <Card className="mb-6">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4">
                <CheckCircle className="h-16 w-16 text-green-500" />
              </div>
              <CardTitle className="text-2xl text-green-700">
                Subscription Confirmed!
              </CardTitle>
              <CardDescription className="text-lg">
                Welcome to your farm subscription. Fresh produce will be delivered regularly!
              </CardDescription>
            </CardHeader>
          </Card>

          {subscription && (
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="h-5 w-5" />
                  {subscription.subscription_plans.name}
                </CardTitle>
                <CardDescription>
                  {subscription.subscription_plans.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Package className="h-4 w-4 text-green-600" />
                      <span className="font-medium">${subscription.subscription_plans.price}</span>
                      <span className="text-muted-foreground">
                        / {formatInterval(subscription.subscription_plans.interval_type, subscription.subscription_plans.interval_count)}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-green-600" />
                      <span className="text-sm">
                        Next delivery: {format(new Date(subscription.next_delivery_date), 'MMMM dd, yyyy')}
                      </span>
                    </div>
                  </div>
                  {subscription.delivery_address && (
                    <div className="flex items-start gap-2">
                      <MapPin className="h-4 w-4 text-green-600 mt-0.5" />
                      <span className="text-sm text-muted-foreground">
                        {subscription.delivery_address}
                      </span>
                    </div>
                  )}
                </div>

                <div className="bg-green-50 border border-green-200 p-4 rounded-lg">
                  <h4 className="font-medium text-green-800 mb-2">What happens next?</h4>
                  <ul className="text-sm text-green-700 space-y-1">
                    <li>• You'll receive an email confirmation shortly</li>
                    <li>• The farmer will prepare your first delivery</li>
                    <li>• You'll be notified when your order is ready</li>
                    <li>• Automatic deliveries will continue based on your schedule</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="flex gap-4 justify-center">
            <Button variant="outline" onClick={() => navigate('/subscriptions')}>
              Manage Subscription
            </Button>
            <Button onClick={() => navigate('/shop')}>
              Continue Shopping
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SubscriptionSuccess;