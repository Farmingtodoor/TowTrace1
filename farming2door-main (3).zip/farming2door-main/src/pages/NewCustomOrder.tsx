import { useState, useEffect } from 'react'
import { useAuth } from '@/contexts/AuthContext'
import { supabase } from '@/integrations/supabase/client'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import { Check, ChevronsUpDown, Home } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useNavigate } from 'react-router-dom'
import { Plus, Minus, ArrowLeft } from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import Header from '@/components/Header'

interface Farmer {
  id: string
  farm_name: string
  email: string
}

interface ProductRequest {
  name: string
  quantity: number
  unit: string
  notes?: string
}

export default function NewCustomOrder() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const { toast } = useToast()
  const [farmers, setFarmers] = useState<Farmer[]>([])
  const [selectedFarmer, setSelectedFarmer] = useState('')
  const [open, setOpen] = useState(false)
  const [deliveryDate, setDeliveryDate] = useState('')
  const [customerNotes, setCustomerNotes] = useState('')
  const [deliveryMethod, setDeliveryMethod] = useState('pickup')
  const [deliveryAddress, setDeliveryAddress] = useState('')
  const [products, setProducts] = useState<ProductRequest[]>([
    { name: '', quantity: 1, unit: 'lb', notes: '' }
  ])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    fetchFarmers()
  }, [])

  const fetchFarmers = async () => {
    console.log('Fetching farmers...')
    const { data, error } = await supabase
      .rpc('get_farmer_contacts_for_orders')

    if (error) {
      console.error('Error fetching farmers:', error)
      toast({
        title: "Error",
        description: "Failed to load farmers. Please try again.",
        variant: "destructive"
      })
    } else {
      console.log('Fetched farmers:', data)
      const formattedFarmers = (data || []).map((farmer: any) => ({
        id: farmer.user_id,
        farm_name: farmer.farm_name,
        email: farmer.contact_email
      }))
      setFarmers(formattedFarmers)
    }
  }

  const addProduct = () => {
    setProducts([...products, { name: '', quantity: 1, unit: 'lb', notes: '' }])
  }

  const removeProduct = (index: number) => {
    if (products.length > 1) {
      setProducts(products.filter((_, i) => i !== index))
    }
  }

  const updateProduct = (index: number, field: keyof ProductRequest, value: string | number) => {
    const updatedProducts = [...products]
    updatedProducts[index] = { ...updatedProducts[index], [field]: value }
    setProducts(updatedProducts)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!user) {
      toast({
        title: "Error",
        description: "Please sign in to submit an order.",
      })
      return
    }

    if (!selectedFarmer || !deliveryDate || products.some(p => !p.name || p.quantity <= 0)) {
      toast({
        title: "Error",
        description: "Please fill in all required fields.",
      })
      return
    }

    if (deliveryMethod === 'delivery' && !deliveryAddress.trim()) {
      toast({
        title: "Error",
        description: "Please provide a delivery address.",
      })
      return
    }

    setLoading(true)

    const orderData = {
      customer_id: user.id,
      farmer_id: selectedFarmer,
      requested_products: JSON.stringify(products.filter(p => p.name.trim() !== '')),
      requested_delivery_date: deliveryDate,
      customer_notes: customerNotes.trim() || null,
      delivery_method: deliveryMethod,
      delivery_address: deliveryMethod === 'delivery' ? deliveryAddress.trim() : null,
      status: 'pending'
    }

    const { error } = await supabase
      .from('custom_orders')
      .insert(orderData)

    if (error) {
      console.error('Error creating custom order:', error)
      toast({
        title: "Error",
        description: "Failed to submit order. Please try again.",
      })
    } else {
      toast({
        title: "Success",
        description: "Custom order submitted successfully!",
      })
      navigate('/custom-orders')
    }

    setLoading(false)
  }

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <p>Please sign in to submit a custom order.</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <div className="flex items-center gap-4 mb-8">
          <Button variant="outline" size="sm" onClick={() => navigate('/')}>
            <Home className="w-4 h-4 mr-2" />
            Home
          </Button>
          <h1 className="text-3xl font-bold">New Custom Order</h1>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Submit Custom Order Request</CardTitle>
          </CardHeader>
          <CardContent className="max-h-[calc(100vh-16rem)] overflow-y-auto">
            <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="farmer">Select Farm *</Label>
              <Popover open={open} onOpenChange={setOpen}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    aria-expanded={open}
                    className="w-full justify-between"
                  >
                    {selectedFarmer
                      ? farmers.find((farmer) => farmer.id === selectedFarmer)?.farm_name
                      : "Choose a farm..."}
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-full p-0 z-[60] bg-popover border shadow-lg">
                  <Command>
                    <CommandInput placeholder="Search farms..." />
                    <CommandList>
                      <CommandEmpty>No farms found.</CommandEmpty>
                      <CommandGroup>
                        {farmers.map((farmer) => (
                          <CommandItem
                            key={farmer.id}
                            value={farmer.farm_name}
                            onSelect={() => {
                              setSelectedFarmer(farmer.id)
                              setOpen(false)
                            }}
                          >
                            <Check
                              className={cn(
                                "mr-2 h-4 w-4",
                                selectedFarmer === farmer.id ? "opacity-100" : "opacity-0"
                              )}
                            />
                            <div className="flex flex-col">
                              <span className="font-medium">{farmer.farm_name}</span>
                            </div>
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label htmlFor="deliveryDate">Requested Delivery Date *</Label>
              <Input
                id="deliveryDate"
                type="date"
                value={deliveryDate}
                onChange={(e) => setDeliveryDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="deliveryMethod">Delivery Method *</Label>
              <Select value={deliveryMethod} onValueChange={setDeliveryMethod}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pickup">Pickup at Farm</SelectItem>
                  <SelectItem value="delivery">Home Delivery</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {deliveryMethod === 'delivery' && (
              <div className="space-y-2">
                <Label htmlFor="deliveryAddress">Delivery Address *</Label>
                <Textarea
                  id="deliveryAddress"
                  placeholder="Enter your full delivery address..."
                  value={deliveryAddress}
                  onChange={(e) => setDeliveryAddress(e.target.value)}
                  rows={3}
                  required
                />
              </div>
            )}

            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <Label>Requested Products *</Label>
                <Button type="button" variant="outline" size="sm" onClick={addProduct}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Product
                </Button>
              </div>

              {products.map((product, index) => (
                <Card key={index} className="p-4">
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <h4 className="font-semibold">Product {index + 1}</h4>
                      {products.length > 1 && (
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => removeProduct(index)}
                        >
                          <Minus className="w-4 h-4" />
                        </Button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor={`product-name-${index}`}>Product Name *</Label>
                        <Input
                          id={`product-name-${index}`}
                          placeholder="e.g., Organic Tomatoes"
                          value={product.name}
                          onChange={(e) => updateProduct(index, 'name', e.target.value)}
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor={`product-quantity-${index}`}>Quantity *</Label>
                        <Input
                          id={`product-quantity-${index}`}
                          type="number"
                          min="1"
                          value={product.quantity}
                          onChange={(e) => updateProduct(index, 'quantity', parseInt(e.target.value) || 1)}
                          required
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor={`product-unit-${index}`}>Unit</Label>
                        <Select
                          value={product.unit}
                          onValueChange={(value) => updateProduct(index, 'unit', value)}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="lb">Pounds (lb)</SelectItem>
                            <SelectItem value="kg">Kilograms (kg)</SelectItem>
                            <SelectItem value="oz">Ounces (oz)</SelectItem>
                            <SelectItem value="bunch">Bunch</SelectItem>
                            <SelectItem value="dozen">Dozen</SelectItem>
                            <SelectItem value="piece">Piece</SelectItem>
                            <SelectItem value="box">Box</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor={`product-notes-${index}`}>Product Notes (optional)</Label>
                      <Input
                        id={`product-notes-${index}`}
                        placeholder="e.g., ripe, specific variety preferences..."
                        value={product.notes}
                        onChange={(e) => updateProduct(index, 'notes', e.target.value)}
                      />
                    </div>
                  </div>
                </Card>
              ))}
            </div>

            <div className="space-y-2">
              <Label htmlFor="customerNotes">Additional Notes (optional)</Label>
              <Textarea
                id="customerNotes"
                placeholder="Any special requests, delivery instructions, or other details..."
                value={customerNotes}
                onChange={(e) => setCustomerNotes(e.target.value)}
                rows={4}
              />
            </div>

            <div className="flex gap-4 pt-4 border-t bg-background sticky bottom-0">
              <Button type="submit" disabled={loading} className="flex-1">
                {loading ? 'Submitting...' : 'Submit Order Request'}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate('/')}
              >
                Cancel
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
      </div>
    </div>
  )
}