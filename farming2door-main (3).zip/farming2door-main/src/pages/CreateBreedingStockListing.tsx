import { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { ArrowLeft, Upload } from 'lucide-react';
import MediaUpload from '@/components/MediaUpload';

interface Category {
  id: string;
  name: string;
  slug: string;
}

interface Breed {
  id: string;
  name: string;
  type: string;
}

export default function CreateBreedingStockListing() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { register, handleSubmit, watch, setValue } = useForm();
  
  const [categories, setCategories] = useState<Category[]>([]);
  const [breeds, setBreeds] = useState<Breed[]>([]);
  const [loading, setLoading] = useState(false);
  const [photos, setPhotos] = useState<any[]>([]);
  const [videos, setVideos] = useState<any[]>([]);
  
  const selectedCategory = watch('category_id');

  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }
    fetchCategories();
  }, [user]);

  useEffect(() => {
    if (selectedCategory) {
      fetchBreeds(selectedCategory);
    }
  }, [selectedCategory]);

  const fetchCategories = async () => {
    const { data } = await supabase
      .from('breeding_stock_categories')
      .select('*')
      .eq('is_active', true)
      .order('display_order');
    
    if (data) setCategories(data);
  };

  const fetchBreeds = async (categoryId: string) => {
    const { data } = await supabase
      .from('breeding_stock_breeds')
      .select('*')
      .eq('category_id', categoryId)
      .eq('is_active', true)
      .order('name');
    
    if (data) setBreeds(data);
  };

  const onSubmit = async (data: any) => {
    if (!user) return;
    
    const photoUrls = photos.map(p => typeof p === 'string' ? p : p.url);
    const videoUrls = videos.map(v => typeof v === 'string' ? v : v.url);
    
    if (photoUrls.length < 4) {
      toast({
        title: 'Photos Required',
        description: 'Please upload at least 4 photos of the animal.',
        variant: 'destructive'
      });
      return;
    }

    setLoading(true);

    try {
      const { error } = await supabase
        .from('breeding_stock_listings')
        .insert({
          farmer_id: user.id,
          title: data.title,
          category_id: data.category_id,
          breed_id: data.breed_id || null,
          custom_breed: data.custom_breed || null,
          type: data.type,
          sex: data.sex,
          age_months: data.age_months ? parseInt(data.age_months) : null,
          date_of_birth: data.date_of_birth || null,
          weight_lbs: data.weight_lbs ? parseFloat(data.weight_lbs) : null,
          breeding_status: data.breeding_status,
          heat_cycle_notes: data.heat_cycle_notes || null,
          breeding_guarantee: data.breeding_guarantee || null,
          registration_number: data.registration_number || null,
          registry_name: data.registry_name || null,
          temperament: data.temperament,
          handling_notes: data.handling_notes || null,
          biosecurity_notes: data.biosecurity_notes || null,
          price: parseFloat(data.price),
          deposit_allowed: data.deposit_allowed || false,
          deposit_percentage: data.deposit_percentage ? parseFloat(data.deposit_percentage) : null,
          return_refund_terms: data.return_refund_terms || null,
          location_city: data.location_city,
          location_state: data.location_state,
          zip_code: data.zip_code,
          transport_pickup: data.transport_pickup || true,
          transport_delivery: data.transport_delivery || false,
          transport_third_party: data.transport_third_party || false,
          delivery_mileage_rate: data.delivery_mileage_rate ? parseFloat(data.delivery_mileage_rate) : null,
          photos: photoUrls,
          videos: videoUrls,
          contact_preferences: {
            chat: data.contact_chat || true,
            phone: data.contact_phone || false
          }
        });

      if (error) throw error;

      toast({
        title: 'Listing Created',
        description: 'Your breeding stock listing has been published successfully.'
      });

      navigate('/breeding-stock');
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>List Breeding Stock - Farming2Door</title>
      </Helmet>

      <div className="min-h-screen bg-background py-12">
        <div className="container mx-auto px-4 max-w-4xl">
          <Button variant="ghost" onClick={() => navigate('/breeding-stock')} className="mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Breeding Stock
          </Button>

          <h1 className="text-3xl font-bold mb-6">List Breeding Stock</h1>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="title">Listing Title *</Label>
                  <Input 
                    id="title" 
                    {...register('title', { required: true })}
                    placeholder="e.g., Registered Holstein Heifer - Bred"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="category_id">Category *</Label>
                    <Select onValueChange={(value) => setValue('category_id', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map(cat => (
                          <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="breed_id">Breed *</Label>
                    <Select onValueChange={(value) => setValue('breed_id', value)} disabled={!selectedCategory}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select breed" />
                      </SelectTrigger>
                      <SelectContent>
                        {breeds.map(breed => (
                          <SelectItem key={breed.id} value={breed.id}>
                            {breed.name} {breed.type && `(${breed.type})`}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="type">Type *</Label>
                    <Input 
                      id="type" 
                      {...register('type', { required: true })}
                      placeholder="e.g., Bred Heifer"
                    />
                  </div>

                  <div>
                    <Label htmlFor="sex">Sex</Label>
                    <Select onValueChange={(value) => setValue('sex', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select sex" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="M">Male</SelectItem>
                        <SelectItem value="F">Female</SelectItem>
                        <SelectItem value="Mixed">Mixed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="age_months">Age (months)</Label>
                    <Input 
                      id="age_months" 
                      type="number"
                      {...register('age_months')}
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="date_of_birth">Date of Birth</Label>
                    <Input 
                      id="date_of_birth" 
                      type="date"
                      {...register('date_of_birth')}
                    />
                  </div>

                  <div>
                    <Label htmlFor="weight_lbs">Weight (lbs)</Label>
                    <Input 
                      id="weight_lbs" 
                      type="number"
                      {...register('weight_lbs')}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Breeding Information */}
            <Card>
              <CardHeader>
                <CardTitle>Breeding Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="breeding_status">Breeding Status</Label>
                  <Select onValueChange={(value) => setValue('breeding_status', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="open">Open</SelectItem>
                      <SelectItem value="bred">Bred (Confirmed)</SelectItem>
                      <SelectItem value="in_milk">In Milk</SelectItem>
                      <SelectItem value="proven_sire">Proven Sire</SelectItem>
                      <SelectItem value="proven_dam">Proven Dam</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="heat_cycle_notes">Heat Cycle / Breeding Notes</Label>
                  <Textarea 
                    id="heat_cycle_notes"
                    {...register('heat_cycle_notes')}
                    placeholder="Any relevant breeding information..."
                  />
                </div>

                <div>
                  <Label htmlFor="breeding_guarantee">Breeding Guarantee Terms</Label>
                  <Textarea 
                    id="breeding_guarantee"
                    {...register('breeding_guarantee')}
                    placeholder="Optional guarantee terms..."
                  />
                </div>
              </CardContent>
            </Card>

            {/* Registration & Health */}
            <Card>
              <CardHeader>
                <CardTitle>Registration & Health</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="registry_name">Registry Name</Label>
                    <Input 
                      id="registry_name"
                      {...register('registry_name')}
                      placeholder="e.g., Holstein Association"
                    />
                  </div>

                  <div>
                    <Label htmlFor="registration_number">Registration Number</Label>
                    <Input 
                      id="registration_number"
                      {...register('registration_number')}
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="temperament">Temperament</Label>
                  <Input 
                    id="temperament"
                    {...register('temperament')}
                    placeholder="e.g., Gentle, halter-broke"
                  />
                </div>

                <div>
                  <Label htmlFor="handling_notes">Handling Notes</Label>
                  <Textarea 
                    id="handling_notes"
                    {...register('handling_notes')}
                  />
                </div>

                <div>
                  <Label htmlFor="biosecurity_notes">Biosecurity / Herd Health</Label>
                  <Textarea 
                    id="biosecurity_notes"
                    {...register('biosecurity_notes')}
                    placeholder="Closed herd, quarantine policy, testing protocols..."
                  />
                </div>
              </CardContent>
            </Card>

            {/* Pricing & Terms */}
            <Card>
              <CardHeader>
                <CardTitle>Pricing & Terms</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="price">Price ($) *</Label>
                  <Input 
                    id="price"
                    type="number"
                    step="0.01"
                    {...register('price', { required: true })}
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="deposit_allowed"
                    onCheckedChange={(checked) => setValue('deposit_allowed', checked)}
                  />
                  <Label htmlFor="deposit_allowed">Allow deposit to reserve</Label>
                </div>

                <div>
                  <Label htmlFor="deposit_percentage">Deposit Percentage (%)</Label>
                  <Input 
                    id="deposit_percentage"
                    type="number"
                    {...register('deposit_percentage')}
                    placeholder="e.g., 25"
                  />
                </div>

                <div>
                  <Label htmlFor="return_refund_terms">Return/Refund Terms</Label>
                  <Textarea 
                    id="return_refund_terms"
                    {...register('return_refund_terms')}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Location & Transport */}
            <Card>
              <CardHeader>
                <CardTitle>Location & Transport</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="location_city">City *</Label>
                    <Input 
                      id="location_city"
                      {...register('location_city', { required: true })}
                    />
                  </div>

                  <div>
                    <Label htmlFor="location_state">State *</Label>
                    <Input 
                      id="location_state"
                      {...register('location_state', { required: true })}
                    />
                  </div>

                  <div>
                    <Label htmlFor="zip_code">ZIP Code *</Label>
                    <Input 
                      id="zip_code"
                      {...register('zip_code', { required: true })}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="transport_pickup"
                      defaultChecked
                      onCheckedChange={(checked) => setValue('transport_pickup', checked)}
                    />
                    <Label htmlFor="transport_pickup">Pickup available</Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="transport_delivery"
                      onCheckedChange={(checked) => setValue('transport_delivery', checked)}
                    />
                    <Label htmlFor="transport_delivery">Seller delivery available</Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="transport_third_party"
                      onCheckedChange={(checked) => setValue('transport_third_party', checked)}
                    />
                    <Label htmlFor="transport_third_party">Third-party transport available</Label>
                  </div>
                </div>

                <div>
                  <Label htmlFor="delivery_mileage_rate">Delivery Rate ($ per mile)</Label>
                  <Input 
                    id="delivery_mileage_rate"
                    type="number"
                    step="0.01"
                    {...register('delivery_mileage_rate')}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Photos & Videos */}
            <Card>
              <CardHeader>
                <CardTitle>Photos & Videos (Min. 4 photos required)</CardTitle>
              </CardHeader>
              <CardContent>
                <MediaUpload
                  images={photos}
                  videos={videos}
                  onImagesChange={setPhotos}
                  onVideosChange={setVideos}
                  userId={user?.id || ''}
                />
              </CardContent>
            </Card>

            {/* Submit */}
            <div className="flex gap-4">
              <Button type="submit" size="lg" disabled={loading}>
                {loading ? 'Creating...' : 'Publish Listing'}
              </Button>
              <Button 
                type="button" 
                variant="outline" 
                size="lg"
                onClick={() => navigate('/breeding-stock')}
              >
                Cancel
              </Button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
}
