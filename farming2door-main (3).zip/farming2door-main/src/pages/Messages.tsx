import { ChatList } from '@/components/chat/ChatList';
import SEOHead from '@/components/SEOHead';
import { AuthGuard } from '@/components/auth/AuthGuard';

const Messages = () => {
  return (
    <AuthGuard requireAuth={true}>
      <div className="min-h-screen bg-background">
        <SEOHead
          title="Messages - Farm2Door"
          description="View and manage your conversations with farmers and customers on Farm2Door."
          keywords="messages, chat, conversations, farm2door"
        />
        
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-foreground">Messages</h1>
              <p className="text-muted-foreground mt-2">
                Communicate directly with farmers and customers
              </p>
            </div>

            <ChatList />
          </div>
        </div>
      </div>
    </AuthGuard>
  );
};

export default Messages;