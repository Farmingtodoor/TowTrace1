import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SEOHead from "@/components/SEOHead";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";

const Blog = () => {
  const navigate = useNavigate();

  const blogPosts = [
    {
      id: "how-buying-half-cow-works",
      title: "How Buying Half a Cow Works: A Complete Guide",
      excerpt: "Learn everything about purchasing bulk beef directly from farmers - from cost savings to processing options and storage tips.",
      readTime: "8 min read",
      category: "Education",
      publishDate: "2024-01-15",
      image: "/assets/meat-livestock.jpg"
    },
    {
      id: "farm-to-door-freshness",
      title: "Farm-to-Door Freshness: The Journey of Your Food",
      excerpt: "Discover how we maintain peak freshness from harvest to your doorstep, ensuring you get the highest quality produce and meat.",
      readTime: "6 min read", 
      category: "Quality",
      publishDate: "2024-01-10",
      image: "/assets/produce-vegetables.jpg"
    },
    {
      id: "halal-kosher-sourcing",
      title: "Understanding Halal and Kosher Sourcing: Quality Meets Faith",
      excerpt: "Learn about our certified Halal and Kosher processing options, ensuring your dietary requirements are met with the highest standards.",
      readTime: "7 min read",
      category: "Certification",
      publishDate: "2024-01-05", 
      image: "/assets/hero-farm.jpg"
    }
  ];

  const organizationSchema = {
    "@context": "https://schema.org",
    "@type": "Blog",
    "url": "https://farm2door.com/blog",
    "name": "Farm2Door Blog",
    "description": "Learn about farm-fresh food, sustainable agriculture, and direct-from-farmer purchasing",
    "publisher": {
      "@type": "Organization",
      "name": "Farm2Door",
      "logo": {
        "@type": "ImageObject",
        "url": "https://farm2door.com/logo.png"
      }
    },
    "mainEntity": blogPosts.map(post => ({
      "@type": "BlogPosting",
      "headline": post.title,
      "description": post.excerpt,
      "datePublished": post.publishDate,
      "url": `https://farm2door.com/blog/${post.id}`,
      "author": {
        "@type": "Organization",
        "name": "Farm2Door"
      }
    }))
  };

  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title="Farm2Door Blog - Fresh Insights on Farm-to-Table Living"
        description="Discover expert insights on buying directly from farmers, understanding food quality, processing options, and sustainable agriculture practices."
        keywords="farm to table blog, buying from farmers, sustainable agriculture, food quality, meat processing, organic farming"
        schemaData={organizationSchema}
      />
      
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <header className="text-center mb-12">
            <h1 className="text-4xl font-bold text-foreground mb-4">
              Farm2Door Blog
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Fresh insights on farm-to-table living, sustainable agriculture, and getting the most from direct farmer relationships
            </p>
          </header>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post) => (
              <Card 
                key={post.id} 
                className="cursor-pointer hover:shadow-lg transition-shadow group"
                onClick={() => navigate(`/blog/${post.id}`)}
              >
                <div className="aspect-video relative overflow-hidden rounded-t-lg">
                  <img 
                    src={post.image} 
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <CardHeader>
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="secondary">{post.category}</Badge>
                    <span className="text-sm text-muted-foreground">{post.readTime}</span>
                  </div>
                  <CardTitle className="group-hover:text-primary transition-colors">
                    {post.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">{post.excerpt}</p>
                  <p className="text-sm text-muted-foreground">
                    Published {new Date(post.publishDate).toLocaleDateString('en-US', {
                      year: 'numeric',
                      month: 'long', 
                      day: 'numeric'
                    })}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-12 text-center">
            <p className="text-muted-foreground mb-6">
              Want to stay updated with our latest insights and farm stories?
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <input 
                type="email" 
                placeholder="Enter your email"
                className="px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <button className="px-6 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors">
                Subscribe to Blog
              </button>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Blog;