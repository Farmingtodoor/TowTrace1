import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SEOHead from "@/components/SEOHead";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const FAQ = () => {
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "How does delivery work?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "We deliver fresh farm products directly to your door within our service areas. Delivery schedules vary by farmer and location, typically 2-5 business days. You'll receive notifications about delivery timing and can track your order status."
        }
      },
      {
        "@type": "Question", 
        "name": "What processing options are available?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "We offer various processing services including butchering, custom cuts, packaging, and specialty preparations like Halal or Kosher processing. Processing options vary by farmer and product type. All processing is done by licensed, certified facilities."
        }
      },
      {
        "@type": "Question",
        "name": "What is your refund policy?",
        "acceptedAnswer": {
          "@type": "Answer", 
          "text": "We offer full refunds for damaged or spoiled products within 24 hours of delivery. For other issues, we provide store credit or replacement items. Refund requests must be made within 3 days of delivery with photo documentation."
        }
      },
      {
        "@type": "Question",
        "name": "How do you ensure food safety?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "All our farmers and processors maintain proper certifications and follow strict food safety protocols. Products are temperature-controlled during transport and we work only with licensed facilities that meet USDA and state regulations."
        }
      }
    ]
  };

  const faqs = [
    {
      question: "How does delivery work?",
      answer: "We deliver fresh farm products directly to your door within our service areas. Delivery schedules vary by farmer and location, typically 2-5 business days. You'll receive notifications about delivery timing and can track your order status. Delivery fees vary by distance and order size."
    },
    {
      question: "What processing options are available?",
      answer: "We offer various processing services including butchering, custom cuts, packaging, and specialty preparations like Halal or Kosher processing. Processing options vary by farmer and product type. All processing is done by licensed, certified facilities that meet USDA standards."
    },
    {
      question: "What is your refund policy?",
      answer: "We offer full refunds for damaged or spoiled products within 24 hours of delivery. For quality issues, we provide store credit or replacement items. Refund requests must be made within 3 days of delivery with photo documentation. Custom processed orders have different return terms."
    },
    {
      question: "How do you ensure food safety?",
      answer: "All our farmers and processors maintain proper certifications and follow strict food safety protocols. Products are temperature-controlled during transport and we work only with licensed facilities that meet USDA and state regulations. We regularly audit our supply chain for compliance."
    },
    {
      question: "Can I buy in bulk or wholesale?",
      answer: "Yes! We offer bulk purchasing options for larger quantities like half or whole animals, CSA boxes, and wholesale orders for restaurants. Contact farmers directly through our platform or reach out to us for bulk pricing and availability."
    },
    {
      question: "What areas do you serve?",
      answer: "Our service area varies by farmer location. Use our delivery zone estimator on product pages to check availability in your area. We're continuously expanding our network of farmers to serve more regions."
    },
    {
      question: "How fresh are the products?",
      answer: "Products are harvested, processed, or prepared shortly before delivery. Most produce is picked within 24-48 hours, while meat products are processed weekly. Each product page shows harvest/processing dates and expected delivery times."
    },
    {
      question: "Do you offer organic or certified products?",
      answer: "Many of our farmers offer organic, grass-fed, pasture-raised, and other certified products. Look for certification badges on product listings. We work with farmers who maintain various certifications including USDA Organic, Animal Welfare Approved, and others."
    },
    {
      question: "How do I place a custom order?",
      answer: "Use our custom order feature to request specific cuts, quantities, or processing options. Submit your request with details and farmers will respond with availability and pricing. Custom orders typically require 1-2 weeks lead time."
    },
    {
      question: "What payment methods do you accept?",
      answer: "We accept all major credit cards, debit cards, and digital payment methods through our secure checkout process. Payment is processed when your order is confirmed and prepared for delivery."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title="Frequently Asked Questions"
        description="Get answers to common questions about Farm2Door delivery, processing, refunds, food safety, and more. Learn how our farm-to-door service works."
        keywords="farm2door faq, delivery questions, food safety, refund policy, processing options, bulk orders"
        schemaData={faqSchema}
      />
      
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <header className="text-center mb-8">
            <h1 className="text-4xl font-bold text-foreground mb-4">
              Frequently Asked Questions
            </h1>
            <p className="text-xl text-muted-foreground">
              Everything you need to know about Farm2Door
            </p>
          </header>

          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border border-border rounded-lg px-6">
                <AccordionTrigger className="text-left font-semibold text-lg hover:text-primary">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed pb-4">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          <div className="mt-12 p-6 bg-muted/50 rounded-lg">
            <h2 className="text-2xl font-semibold mb-4">Still have questions?</h2>
            <p className="text-muted-foreground mb-4">
              Can't find the answer you're looking for? Our customer support team is here to help.
            </p>
            <a 
              href="mailto:support@farm2door.com" 
              className="inline-flex items-center px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
            >
              Contact Support
            </a>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default FAQ;