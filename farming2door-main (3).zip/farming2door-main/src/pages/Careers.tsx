import { useState } from "react";
import { Briefcase, MapPin, Clock, TrendingUp } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SEOHead from "@/components/SEOHead";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import JobApplicationForm from "@/components/careers/JobApplicationForm";

const Careers = () => {
  const [isApplicationOpen, setIsApplicationOpen] = useState(false);
  const [selectedPosition, setSelectedPosition] = useState<string>("");

  const openApplicationForm = (position?: string) => {
    setSelectedPosition(position || "");
    setIsApplicationOpen(true);
  };

  const openPositions = [
    {
      title: "Senior Full-Stack Developer",
      department: "Engineering",
      location: "San Francisco, CA / Remote",
      type: "Full-time",
      description: "Join our engineering team to build scalable solutions connecting farmers with consumers. Work with React, Node.js, and modern cloud infrastructure.",
      requirements: [
        "5+ years of full-stack development experience",
        "Expertise in React, TypeScript, and Node.js",
        "Experience with cloud platforms (AWS/GCP)",
        "Passion for sustainable agriculture"
      ]
    },
    {
      title: "Farmer Success Manager",
      department: "Operations",
      location: "Multiple Locations",
      type: "Full-time",
      description: "Work directly with farmers to onboard them to our platform and ensure their success. Build relationships and provide ongoing support.",
      requirements: [
        "3+ years in customer success or account management",
        "Understanding of agriculture and farming practices",
        "Excellent communication skills",
        "Willingness to travel to farm locations"
      ]
    },
    {
      title: "Digital Marketing Specialist",
      department: "Marketing",
      location: "Remote",
      type: "Full-time",
      description: "Drive growth through digital marketing campaigns, SEO, content marketing, and social media strategies focused on sustainable food systems.",
      requirements: [
        "3+ years in digital marketing",
        "Experience with SEO, SEM, and social media advertising",
        "Strong analytical and creative skills",
        "Passion for local food and sustainability"
      ]
    },
    {
      title: "Logistics Coordinator",
      department: "Operations",
      location: "San Francisco, CA",
      type: "Full-time",
      description: "Optimize delivery routes and coordinate with farmers and delivery partners to ensure timely, fresh product delivery.",
      requirements: [
        "2+ years in logistics or supply chain",
        "Strong organizational skills",
        "Experience with logistics software",
        "Problem-solving mindset"
      ]
    }
  ];

  const benefits = [
    {
      icon: TrendingUp,
      title: "Competitive Compensation",
      description: "Market-rate salaries plus equity options for all full-time employees"
    },
    {
      icon: MapPin,
      title: "Flexible Work",
      description: "Remote-first culture with offices in major cities for collaboration"
    },
    {
      icon: Clock,
      title: "Work-Life Balance",
      description: "Generous PTO, flexible hours, and unlimited fresh produce from our farmers"
    },
    {
      icon: Briefcase,
      title: "Growth Opportunities",
      description: "Professional development budget and mentorship programs"
    }
  ];

  const values = [
    {
      title: "Sustainability First",
      description: "We're committed to building a more sustainable food system for future generations."
    },
    {
      title: "Farmer-Centric",
      description: "Every decision we make considers the impact on our farming partners."
    },
    {
      title: "Innovation",
      description: "We embrace new technologies and approaches to solve old problems."
    },
    {
      title: "Community",
      description: "We believe in strengthening local communities through fresh food access."
    }
  ];

  return (
    <>
      <SEOHead
        title="Careers at Farming2Door"
        description="Join the Farming2Door team and help revolutionize how communities access fresh, local food. View our open positions and benefits."
        keywords="Farming2Door careers, jobs, employment, sustainable agriculture jobs, farm tech careers"
      />
      <Header />
      
      <main className="min-h-screen bg-gradient-to-b from-background to-muted/20">
        {/* Hero Section */}
        <section className="bg-primary text-primary-foreground py-20">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <Briefcase className="h-16 w-16 mx-auto mb-6" />
              <h1 className="text-4xl md:text-5xl font-bold mb-4">Join Our Mission</h1>
              <p className="text-xl text-primary-foreground/90">
                Help us build a more sustainable and connected food system
              </p>
            </div>
          </div>
        </section>

        {/* Why Join Us */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">Why Join Farming2Door?</h2>
              <p className="text-lg text-muted-foreground">
                Be part of a team that's making a real difference in how people access fresh, local food while supporting sustainable farming practices.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
              {benefits.map((benefit, index) => (
                <Card key={index} className="p-6 text-center">
                  <benefit.icon className="h-12 w-12 mx-auto mb-4 text-primary" />
                  <h3 className="font-bold mb-2">{benefit.title}</h3>
                  <p className="text-sm text-muted-foreground">{benefit.description}</p>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Our Values */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold text-center mb-12">Our Values</h2>
              <div className="grid md:grid-cols-2 gap-8">
                {values.map((value, index) => (
                  <Card key={index} className="p-6">
                    <h3 className="text-xl font-bold mb-2">{value.title}</h3>
                    <p className="text-muted-foreground">{value.description}</p>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Open Positions */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold text-center mb-4">Open Positions</h2>
              <p className="text-center text-muted-foreground mb-12">
                Join our growing team and make an impact from day one
              </p>

              <div className="space-y-6">
                {openPositions.map((job, index) => (
                  <Card key={index} className="p-6 hover:shadow-lg transition-shadow">
                    <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-4">
                      <div>
                        <h3 className="text-2xl font-bold mb-2">{job.title}</h3>
                        <div className="flex flex-wrap gap-2 mb-3">
                          <Badge variant="secondary">{job.department}</Badge>
                          <Badge variant="outline" className="gap-1">
                            <MapPin className="h-3 w-3" />
                            {job.location}
                          </Badge>
                          <Badge variant="outline">{job.type}</Badge>
                        </div>
                      </div>
                      <Button onClick={() => openApplicationForm(job.title)}>Apply Now</Button>
                    </div>
                    
                    <p className="text-muted-foreground mb-4">{job.description}</p>
                    
                    <div>
                      <h4 className="font-semibold mb-2">Requirements:</h4>
                      <ul className="space-y-1">
                        {job.requirements.map((req, reqIndex) => (
                          <li key={reqIndex} className="text-sm text-muted-foreground flex items-start gap-2">
                            <span className="text-primary mt-1">•</span>
                            <span>{req}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </Card>
                ))}
              </div>

              {/* General Application */}
              <Card className="p-8 mt-12 text-center bg-muted/50">
                <h3 className="text-2xl font-bold mb-3">Don't See the Right Role?</h3>
                <p className="text-muted-foreground mb-6">
                  We're always looking for talented people who share our passion. Send us your resume and tell us how you'd like to contribute.
                </p>
                <Button size="lg" onClick={() => openApplicationForm()}>
                  Send General Application
                </Button>
              </Card>
            </div>
          </div>
        </section>
      </main>

      {/* Application Dialog */}
      <Dialog open={isApplicationOpen} onOpenChange={setIsApplicationOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {selectedPosition ? `Apply for ${selectedPosition}` : "General Application"}
            </DialogTitle>
          </DialogHeader>
          <JobApplicationForm
            positions={openPositions.map((p) => p.title)}
            selectedPosition={selectedPosition}
            onClose={() => setIsApplicationOpen(false)}
          />
        </DialogContent>
      </Dialog>

      <Footer />
    </>
  );
};

export default Careers;
