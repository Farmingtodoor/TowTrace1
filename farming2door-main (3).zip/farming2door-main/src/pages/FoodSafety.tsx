import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SEOHead from "@/components/SEOHead";
import { Shield, Thermometer, Users, FileCheck, AlertTriangle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const FoodSafety = () => {
  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title="Food Handling & Safety Disclaimer"
        description="Farm2Door Food Safety Information - Learn about our food safety standards, handling guidelines, certifications, and consumer responsibilities."
        keywords="food safety, USDA certified, food handling, farm safety standards, farm2door quality"
      />
      
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <header className="text-center mb-12">
            <h1 className="text-4xl font-bold text-foreground mb-4">
              Food Handling & Safety
            </h1>
            <p className="text-xl text-muted-foreground">
              Your safety is our priority. Learn about our standards and your responsibilities.
            </p>
          </header>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            <Card>
              <CardHeader>
                <Shield className="h-8 w-8 text-primary mb-2" />
                <CardTitle>USDA Certified</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  All meat processing facilities are USDA inspected and certified, ensuring federal food safety standards.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Thermometer className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Temperature Control</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Cold chain maintained from processing through delivery with temperature monitoring at all stages.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Users className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Trained Professionals</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Our farmers and processors maintain food safety certifications and follow strict hygiene protocols.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <FileCheck className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Regular Inspections</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Facilities undergo regular state and federal inspections to maintain licenses and certifications.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <AlertTriangle className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Traceability</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Full supply chain traceability from farm to your door for rapid response to safety concerns.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Shield className="h-8 w-8 text-primary mb-2" />
                <CardTitle>Quality Assurance</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Continuous monitoring and testing programs to ensure product quality and safety standards.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="prose prose-lg max-w-none">
            <section className="mb-8">
              <h2 className="text-3xl font-semibold text-foreground mb-4">Our Safety Standards</h2>
              
              <h3 className="text-xl font-semibold text-foreground mb-3">Processing Facilities</h3>
              <p className="text-muted-foreground leading-relaxed mb-4">
                All meat processing is performed at USDA-inspected facilities that maintain strict food safety protocols. These facilities are regularly audited and must maintain current licenses and certifications.
              </p>

              <h3 className="text-xl font-semibold text-foreground mb-3">Farm Standards</h3>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Our partner farms follow Good Agricultural Practices (GAP) and maintain appropriate certifications for their production methods. Many hold additional certifications such as:
              </p>
              <ul className="list-disc pl-6 text-muted-foreground space-y-2 mb-6">
                <li>USDA Organic</li>
                <li>Animal Welfare Approved</li>
                <li>Certified Humane</li>
                <li>Grass Fed Certified</li>
                <li>State Department of Agriculture licenses</li>
              </ul>

              <h3 className="text-xl font-semibold text-foreground mb-3">Transportation & Delivery</h3>
              <p className="text-muted-foreground leading-relaxed mb-6">
                Products requiring refrigeration are maintained at proper temperatures throughout transportation. Delivery vehicles are equipped with temperature monitoring systems, and delivery times are minimized to maintain product quality.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-3xl font-semibold text-foreground mb-4">Consumer Responsibilities</h2>
              
              <div className="bg-accent/10 border border-accent/20 rounded-lg p-6 mb-6">
                <h3 className="text-xl font-semibold text-foreground mb-4 flex items-center">
                  <AlertTriangle className="h-6 w-6 text-accent mr-2" />
                  Important Food Safety Notice
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  While we maintain high safety standards, consumers have important responsibilities for safe food handling upon delivery.
                </p>
              </div>

              <h3 className="text-xl font-semibold text-foreground mb-3">Upon Delivery</h3>
              <ul className="list-disc pl-6 text-muted-foreground space-y-2 mb-4">
                <li>Inspect products immediately upon delivery</li>
                <li>Refrigerate or freeze perishable items within 2 hours (1 hour if temperature is above 90°F)</li>
                <li>Check packaging integrity and temperature of cold items</li>
                <li>Report any concerns within 24 hours</li>
              </ul>

              <h3 className="text-xl font-semibold text-foreground mb-3">Storage Requirements</h3>
              <ul className="list-disc pl-6 text-muted-foreground space-y-2 mb-4">
                <li>Maintain refrigerated items at 40°F or below</li>
                <li>Keep frozen items at 0°F or below</li>
                <li>Use products within recommended timeframes</li>
                <li>Store raw meat separately from other foods</li>
                <li>Follow FIFO (First In, First Out) principles</li>
              </ul>

              <h3 className="text-xl font-semibold text-foreground mb-3">Preparation Guidelines</h3>
              <ul className="list-disc pl-6 text-muted-foreground space-y-2 mb-6">
                <li>Cook meat to safe internal temperatures (165°F for poultry, 160°F for ground meat, 145°F for whole cuts)</li>
                <li>Use separate cutting boards for raw meat and other foods</li>
                <li>Wash hands thoroughly before and after handling raw products</li>
                <li>Clean all surfaces and utensils after contact with raw meat</li>
              </ul>
            </section>

            <section className="mb-8">
              <h2 className="text-3xl font-semibold text-foreground mb-4">Special Populations</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Certain groups may be at higher risk for foodborne illness and should take extra precautions:
              </p>
              <ul className="list-disc pl-6 text-muted-foreground space-y-2 mb-6">
                <li>Pregnant women</li>
                <li>Young children (under 5 years)</li>
                <li>Adults 65 years and older</li>
                <li>Individuals with compromised immune systems</li>
                <li>People with chronic illnesses</li>
              </ul>
              <p className="text-muted-foreground leading-relaxed">
                These individuals should consult with healthcare providers about safe food handling and may want to avoid certain high-risk foods.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-3xl font-semibold text-foreground mb-4">Disclaimer</h2>
              <div className="bg-muted/50 border rounded-lg p-6">
                <p className="text-muted-foreground leading-relaxed mb-4">
                  <strong>IMPORTANT:</strong> While Farm2Door and our partner farmers maintain high food safety standards, we cannot guarantee that products are free from all potential contaminants or foodborne pathogens.
                </p>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  Consumers assume responsibility for proper handling, storage, and preparation of all food products. Farm2Door is not liable for illness or injury resulting from improper handling or preparation of products after delivery.
                </p>
                <p className="text-muted-foreground leading-relaxed">
                  Fresh, minimally processed foods from local farms may carry different risks than highly processed commercial products. Please handle all products with appropriate food safety practices.
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-3xl font-semibold text-foreground mb-4">Report Safety Concerns</h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                If you experience any food safety concerns or suspect foodborne illness:
              </p>
              <div className="bg-muted/50 p-4 rounded-lg">
                <p className="text-muted-foreground">
                  <strong>Immediate concerns:</strong> (555) 123-SAFE<br/>
                  <strong>General safety questions:</strong> safety@farm2door.com<br/>
                  <strong>Report to authorities:</strong> Contact your local health department<br/>
                  <strong>USDA Meat & Poultry Hotline:</strong> 1-888-MPHotline
                </p>
              </div>
            </section>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default FoodSafety;