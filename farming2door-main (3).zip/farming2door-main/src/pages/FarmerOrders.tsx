import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Package, 
  Search, 
  Filter, 
  Calendar, 
  TrendingUp,
  Clock,
  CheckCircle,
  X,
  Loader2,
  RefreshCw
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { FarmerRevenueDashboard } from '@/components/FarmerRevenueDashboard';
import { FarmerOrderCard } from '@/components/FarmerOrderCard';
import SEOHead from '@/components/SEOHead';
import { AuthGuard } from '@/components/auth/AuthGuard';

interface Order {
  id: string;
  customer_id: string;
  farmer_id: string;
  status: string;
  total_amount: number;
  delivery_type: string;
  delivery_address?: string;
  customer_notes?: string;
  farmer_notes?: string;
  created_at: string;
  updated_at: string;
  customer_name?: string;
  customer_email?: string;
}

const FarmerOrders = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [searchParams] = useSearchParams();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [refreshing, setRefreshing] = useState(false);
  const [highlightedOrderId, setHighlightedOrderId] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      fetchOrders();
    }
  }, [user]);

  useEffect(() => {
    // Check for highlighted order from URL params
    const highlightOrderId = searchParams.get('highlight');
    if (highlightOrderId) {
      setHighlightedOrderId(highlightOrderId);
      // Clear the highlight after 3 seconds
      setTimeout(() => setHighlightedOrderId(null), 3000);
    }
  }, [searchParams]);

  const fetchOrders = async () => {
    if (!user) return;
    
    try {
      // First get orders
      const { data: ordersData, error: ordersError } = await supabase
        .from('orders')
        .select('*')
        .eq('farmer_id', user.id)
        .order('created_at', { ascending: false });

      if (ordersError) throw ordersError;

      // Get customer profiles for each order
      const ordersWithCustomers = await Promise.all(
        (ordersData || []).map(async (order) => {
          const { data: profile } = await supabase
            .from('profiles')
            .select('full_name, email')
            .eq('id', order.customer_id)
            .single();

          return {
            ...order,
            customer_name: profile?.full_name,
            customer_email: profile?.email,
          };
        })
      );

      setOrders(ordersWithCustomers);
    } catch (error) {
      console.error('Error fetching orders:', error);
      toast({
        title: "Error",
        description: "Failed to load orders",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchOrders();
    setRefreshing(false);
    toast({
      title: "Refreshed",
      description: "Orders have been updated",
    });
  };

  const filteredOrders = orders.filter(order => {
    const matchesSearch = !searchTerm || 
      order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customer_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customer_email?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const getOrdersByStatus = (status: string) => {
    if (status === 'active') {
      return orders.filter(order => ['pending', 'confirmed', 'processing', 'ready', 'out_for_delivery'].includes(order.status));
    }
    return orders.filter(order => order.status === status);
  };

  const getStatusCount = (status: string) => {
    return getOrdersByStatus(status).length;
  };

  const orderStats = {
    total: orders.length,
    pending: getStatusCount('pending'),
    active: getStatusCount('active'),
    delivered: getStatusCount('delivered'),
    cancelled: getStatusCount('cancelled'),
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-center min-h-96">
            <Loader2 className="h-8 w-8 animate-spin" />
            <span className="ml-2">Loading orders...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <AuthGuard requireAuth={true}>
      <div className="min-h-screen bg-background">
        <SEOHead
          title="My Orders - Farm2Door"
          description="Manage your farm orders, track revenue, and update order status on Farm2Door."
          keywords="farmer orders, order management, farm revenue, delivery status"
        />
        
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-7xl mx-auto">
            {/* Header */}
            <div className="mb-8">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-foreground">Order Management</h1>
                  <p className="text-muted-foreground mt-2">
                    Track and manage your farm orders, monitor revenue, and update delivery status
                  </p>
                </div>
                <Button 
                  onClick={handleRefresh} 
                  disabled={refreshing}
                  variant="outline"
                  className="flex items-center gap-2"
                >
                  <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
                  Refresh
                </Button>
              </div>
            </div>

            {/* Revenue Dashboard */}
            <div className="mb-8">
              <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Revenue Dashboard
              </h2>
              <FarmerRevenueDashboard />
            </div>

            {/* Orders Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="h-5 w-5" />
                  Orders ({orderStats.total})
                </CardTitle>
                <CardDescription>
                  Manage your farm orders and update their status
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="all" className="space-y-6">
                  <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
                    <TabsList className="grid w-full sm:w-auto grid-cols-3 sm:grid-cols-5">
                      <TabsTrigger value="all" className="flex items-center gap-2">
                        All <Badge variant="secondary">{orderStats.total}</Badge>
                      </TabsTrigger>
                      <TabsTrigger value="pending" className="flex items-center gap-2">
                        <Clock className="h-4 w-4" />
                        Pending <Badge variant="secondary">{orderStats.pending}</Badge>
                      </TabsTrigger>
                      <TabsTrigger value="active" className="flex items-center gap-2">
                        <Package className="h-4 w-4" />
                        Active <Badge variant="secondary">{orderStats.active}</Badge>
                      </TabsTrigger>
                      <TabsTrigger value="delivered" className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4" />
                        Delivered <Badge variant="secondary">{orderStats.delivered}</Badge>
                      </TabsTrigger>
                      <TabsTrigger value="cancelled" className="flex items-center gap-2">
                        <X className="h-4 w-4" />
                        Cancelled <Badge variant="secondary">{orderStats.cancelled}</Badge>
                      </TabsTrigger>
                    </TabsList>

                    {/* Search and Filter */}
                    <div className="flex gap-2 w-full sm:w-auto">
                      <div className="relative flex-1 sm:w-64">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                        <Input
                          placeholder="Search orders..."
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="pl-10"
                        />
                      </div>
                      <Select value={statusFilter} onValueChange={setStatusFilter}>
                        <SelectTrigger className="w-32">
                          <Filter className="h-4 w-4 mr-2" />
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Status</SelectItem>
                          <SelectItem value="pending">Pending</SelectItem>
                          <SelectItem value="confirmed">Confirmed</SelectItem>
                          <SelectItem value="processing">Processing</SelectItem>
                          <SelectItem value="ready">Ready</SelectItem>
                          <SelectItem value="out_for_delivery">Out for Delivery</SelectItem>
                          <SelectItem value="delivered">Delivered</SelectItem>
                          <SelectItem value="cancelled">Cancelled</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                   <TabsContent value="all">
                     <OrdersList 
                       orders={filteredOrders} 
                       onOrderUpdate={fetchOrders}
                       emptyMessage="No orders found"
                       highlightedOrderId={highlightedOrderId}
                     />
                   </TabsContent>

                  <TabsContent value="pending">
                    <OrdersList 
                      orders={getOrdersByStatus('pending')} 
                      onOrderUpdate={fetchOrders}
                      emptyMessage="No pending orders"
                    />
                  </TabsContent>

                  <TabsContent value="active">
                    <OrdersList 
                      orders={getOrdersByStatus('active')} 
                      onOrderUpdate={fetchOrders}
                      emptyMessage="No active orders"
                    />
                  </TabsContent>

                  <TabsContent value="delivered">
                    <OrdersList 
                      orders={getOrdersByStatus('delivered')} 
                      onOrderUpdate={fetchOrders}
                      emptyMessage="No delivered orders"
                    />
                  </TabsContent>

                  <TabsContent value="cancelled">
                    <OrdersList 
                      orders={getOrdersByStatus('cancelled')} 
                      onOrderUpdate={fetchOrders}
                      emptyMessage="No cancelled orders"
                    />
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AuthGuard>
  );
};

interface OrdersListProps {
  orders: Order[];
  onOrderUpdate: () => void;
  emptyMessage: string;
  highlightedOrderId?: string | null;
}

const OrdersList = ({ orders, onOrderUpdate, emptyMessage, highlightedOrderId }: OrdersListProps) => {
  if (orders.length === 0) {
    return (
      <div className="text-center py-8">
        <Package className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
        <p className="text-muted-foreground">{emptyMessage}</p>
      </div>
    );
  }

  return (
    <ScrollArea className="h-[600px]">
      <div className="grid gap-4">
        {orders.map((order) => (
          <div
            key={order.id}
            className={highlightedOrderId === order.id ? 'ring-2 ring-primary rounded-lg' : ''}
          >
            <FarmerOrderCard
              order={order}
              onOrderUpdate={onOrderUpdate}
            />
          </div>
        ))}
      </div>
    </ScrollArea>
  );
};

export default FarmerOrders;