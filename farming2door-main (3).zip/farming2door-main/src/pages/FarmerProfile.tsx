import { useState, useEffect } from "react";
import { useParams, useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { toast } from "sonner";
import { 
  ArrowLeft, 
  MapPin, 
  Calendar, 
  Users, 
  Award, 
  Leaf,
  Star,
  Loader2,
  Share2,
  Copy,
  Facebook,
  Twitter,
  MessageCircle,
  Droplet,
  Sun
} from "lucide-react";
import { VerificationBadge } from "@/components/VerificationBadge";
import { CertificationBadges } from "@/components/CertificationBadges";
import { SustainabilityDashboard } from "@/components/SustainabilityDashboard";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";
import { FarmerCoverageMap } from "@/components/farmer/FarmerCoverageMap";

import { supabase } from "@/integrations/supabase/client";
import farmHeroImage from "@/assets/hero-farm.jpg";
import SEOHead from "@/components/SEOHead";

interface FarmerProfile {
  id: string;
  user_id: string;
  full_name: string;
  email: string;
  city?: string;
  state?: string;
  farm_name?: string;
  farm_description?: string;
  farm_address?: string;
  farm_size?: string;
  farming_experience?: string;
  certifications?: string[];
  processing_methods?: string[];
  categories?: any;
  subcategories?: any;
  created_at?: string;
  profile_picture_url?: string;
  next_harvest_date?: string;
}

interface Product {
  id: string;
  name: string;
  farmer: string;
  price: number;
  image_url?: string;
  images?: any;
  videos?: any;
  category: string;
  is_organic: boolean;
  is_available: boolean;
  stock_quantity: number;
  unit: string;
  average_rating?: number;
  review_count?: number;
}

export default function FarmerProfile() {
  const { farmerSlug } = useParams();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [activeTab, setActiveTab] = useState("about");
  const [farmer, setFarmer] = useState<FarmerProfile | null>(null);
  const [farmerProducts, setFarmerProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Check if we should open the products tab from URL params
  useEffect(() => {
    const tab = searchParams.get('tab');
    if (tab === 'products') {
      setActiveTab('products');
    }
  }, [searchParams]);

  useEffect(() => {
    const fetchFarmerData = async () => {
      if (!farmerSlug) return;
      
      try {
        setLoading(true);
        console.log('Fetching farmer data for ID:', farmerSlug);
        
        // Fetch farmer profile and application data
        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', farmerSlug)
          .maybeSingle();

        console.log('Profile fetch result:', { profile, profileError });

        // Also check if this farmer has any products to help debug
        const { data: farmerProducts, error: productsCheckError } = await supabase
          .from('products')
          .select('farmer_id, farmer')
          .eq('farmer_id', farmerSlug)
          .limit(1);
        
        console.log('Farmer products check:', { farmerProducts, productsCheckError });

        if (profileError) {
          console.warn('Profile fetch error (continuing with public application data):', profileError);
        }

        // Fetch farmer application data (contains farm details)
        const { data: allApplications, error: applicationError } = await supabase
          .rpc('get_farmers_public_safe');
        
        // Find the specific farmer's application
        const application = allApplications?.find((app: any) => app.user_id === farmerSlug) || null;

        console.log('Application fetch result:', { application, applicationError });

        // Check if we have either profile or application data
        if (!profile && !application) {
          console.error('No profile or application found for farmer ID:', farmerSlug);
          throw new Error('Farmer profile not found');
        }

        // Combine profile and application data
        const combinedData: FarmerProfile = {
          id: farmerSlug,
          user_id: profile?.id || farmerSlug,
          full_name: profile?.full_name || application?.display_name || 'Farmer',
          email: profile?.email || 'Contact via platform',
          city: profile?.city,
          state: profile?.state,
          farm_name: application?.farm_name,
          farm_description: application?.farm_description,
          certifications: application?.certifications || [],
          processing_methods: application?.processing_methods || [],
          categories: application?.categories,
          subcategories: application?.subcategories,
          created_at: application?.created_at,
          profile_picture_url: profile?.profile_picture_url,
          next_harvest_date: application?.next_harvest_date,
        };

        console.log('Combined farmer data:', combinedData);
        setFarmer(combinedData);

        // Fetch farmer's products
        const { data: products, error: productsError } = await supabase
          .from('products')
          .select('*')
          .eq('farmer_id', farmerSlug)
          .eq('is_available', true)
          .order('created_at', { ascending: false })
          .limit(6);

        console.log('Products fetch result:', { products, productsError });

        if (!productsError && products) {
          setFarmerProducts(products as Product[]);
        }
      } catch (error) {
        console.error('Error fetching farmer data:', error);
        setFarmer(null);
      } finally {
        setLoading(false);
      }
    };

    fetchFarmerData();
  }, [farmerSlug]);


  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-16 text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
          <h1 className="text-2xl font-bold mb-4">Loading Farmer Profile...</h1>
        </div>
        <Footer />
      </div>
    );
  }

  if (!farmer) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Farmer Not Found</h1>
          <p className="text-muted-foreground mb-6">
            The farmer profile you're looking for doesn't exist or may have been removed.
          </p>
          <div className="flex gap-4 justify-center">
            <Button onClick={() => navigate("/farmers")}>Browse All Farmers</Button>
            <Button variant="outline" onClick={() => navigate("/shop")}>Shop Products</Button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const farmerDisplayName = farmer.farm_name || farmer.full_name;
  const farmerLocation = farmer.city && farmer.state ? `${farmer.city}, ${farmer.state}` : farmer.city || farmer.state || 'Location not specified';

  const shareUrl = window.location.href;
  const shareTitle = `${farmerDisplayName} - Fresh Local Farm Products`;
  const shareDescription = `Check out ${farmerDisplayName} and their fresh local products on Farming2Door!`;

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      toast.success("Link copied to clipboard!");
    } catch (error) {
      toast.error("Failed to copy link");
    }
  };

  const handleSocialShare = (platform: string) => {
    const encodedUrl = encodeURIComponent(shareUrl);
    const encodedTitle = encodeURIComponent(shareTitle);
    const encodedDescription = encodeURIComponent(shareDescription);
    
    let shareLink = '';
    
    switch (platform) {
      case 'facebook':
        shareLink = `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`;
        break;
      case 'twitter':
        shareLink = `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedTitle}`;
        break;
      case 'whatsapp':
        shareLink = `https://wa.me/?text=${encodedTitle}%20${encodedUrl}`;
        break;
    }
    
    if (shareLink) {
      window.open(shareLink, '_blank', 'width=600,height=400');
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title={`${farmerDisplayName} - Fresh Local Farm Products`}
        description={`Learn about ${farmerDisplayName}, their farming practices, and shop their fresh local products. ${farmer.farm_description || 'Quality farm-fresh products delivered directly to your door.'}`}
        keywords={`${farmerDisplayName}, local farm, fresh produce, ${farmerLocation}, organic farming, farm to table`}
      />
      <Header />
      
      {/* Hero Section */}
      <div className="relative h-64 md:h-80 overflow-hidden">
        <img
          src={farmHeroImage}
          alt={`${farmerDisplayName} farm`}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        
        <div className="absolute bottom-6 left-6 text-white">
          <div className="flex items-center gap-4 mb-2">
            <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-white">
              {farmer.profile_picture_url ? (
                <img 
                  src={farmer.profile_picture_url} 
                  alt={`${farmerDisplayName} profile`}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-2xl font-bold bg-white/20">
                  {farmerDisplayName.charAt(0).toUpperCase()}
                </div>
              )}
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h1 className="text-3xl font-bold">{farmerDisplayName}</h1>
                <VerificationBadge type="verified" size="md" showLabel={false} />
              </div>
              <p className="text-lg opacity-90 mb-2">{farmer.full_name}</p>
              <div className="flex gap-2">
                {farmer.created_at && new Date().getFullYear() - new Date(farmer.created_at).getFullYear() >= 3 && (
                  <VerificationBadge 
                    type="top-rated" 
                    size="sm" 
                    yearsInBusiness={new Date().getFullYear() - new Date(farmer.created_at).getFullYear()}
                  />
                )}
                {farmer.certifications && farmer.certifications.length > 0 && (
                  <VerificationBadge type="certified" size="sm" />
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="absolute top-6 left-6 flex gap-2">
          <Button
            variant="outline" 
            onClick={() => navigate("/farmers")}
            className="bg-white/10 border-white/20 text-white hover:bg-white/20"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Farmers
          </Button>
          
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                size="icon"
                className="bg-white/10 border-white/20 text-white hover:bg-white/20"
              >
                <Share2 className="h-4 w-4" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-64">
              <div className="space-y-2">
                <h4 className="font-medium">Share Farmer Profile</h4>
                <div className="space-y-2">
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={handleCopyLink}
                  >
                    <Copy className="h-4 w-4 mr-2" />
                    Copy Link
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => handleSocialShare('facebook')}
                  >
                    <Facebook className="h-4 w-4 mr-2" />
                    Share on Facebook
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => handleSocialShare('twitter')}
                  >
                    <Twitter className="h-4 w-4 mr-2" />
                    Share on Twitter
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start"
                    onClick={() => handleSocialShare('whatsapp')}
                  >
                    <MessageCircle className="h-4 w-4 mr-2" />
                    Share on WhatsApp
                  </Button>
                </div>
              </div>
            </PopoverContent>
          </Popover>
        </div>
      </div>

      <main className="container mx-auto px-4 py-8">
        {/* Quick Info */}
        <Card className="mb-8">
          <CardContent className="pt-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="flex items-center gap-2">
                <MapPin className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">{farmerLocation}</p>
                  <p className="text-sm text-muted-foreground">Location</p>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">
                    {farmer.created_at ? `Est. ${new Date(farmer.created_at).getFullYear()}` : 'Member since signup'}
                  </p>
                  <p className="text-sm text-muted-foreground">Established</p>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <Leaf className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="font-medium">{farmerProducts.length} Products</p>
                  <p className="text-sm text-muted-foreground">Available</p>
                </div>
              </div>

              {farmer.next_harvest_date && (
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-green-600" />
                  <div>
                    <p className="font-medium text-green-600">
                      {new Date(farmer.next_harvest_date).toLocaleDateString()}
                    </p>
                    <p className="text-sm text-muted-foreground">Next Harvest</p>
                  </div>
                </div>
              )}
            </div>

            {farmer.next_harvest_date && (
              <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                <p className="text-sm text-green-800">
                  🌱 <strong>Upcoming Harvest:</strong> Fresh products will be available on{' '}
                  {new Date(farmer.next_harvest_date).toLocaleDateString('en-US', { 
                    weekday: 'long', 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}. Perfect time to place a custom order or check our marketplace!
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="about">About</TabsTrigger>
            <TabsTrigger value="products">Products</TabsTrigger>
            <TabsTrigger value="delivery">Delivery Area</TabsTrigger>
            <TabsTrigger value="sustainability">Sustainability</TabsTrigger>
          </TabsList>

          <TabsContent value="delivery" className="mt-6">
            <FarmerCoverageMap
              farmerId={farmer.user_id}
              farmName={farmerDisplayName}
              fallbackZip={farmer.farm_address?.match(/\b(\d{5})(?:-\d{4})?\b/)?.[1] ?? null}
            />
          </TabsContent>


          <TabsContent value="about" className="mt-6 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>About {farmerDisplayName}</CardTitle>
                <CardDescription>Learn more about this local farm</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground leading-relaxed">
                  {farmer.farm_description || 'This farmer is dedicated to providing quality, fresh products directly from their farm to your table.'}
                </p>
                
                <div className="grid md:grid-cols-2 gap-6">
                  {farmer.certifications && farmer.certifications.length > 0 && (
                    <div>
                      <h4 className="font-semibold mb-3 flex items-center gap-2">
                        <Award className="h-4 w-4" />
                        Certifications & Standards
                      </h4>
                      <CertificationBadges 
                        certifications={farmer.certifications} 
                        size="md" 
                        maxDisplay={6}
                        variant="full"
                      />
                    </div>
                  )}
                  
                  {farmer.processing_methods && farmer.processing_methods.length > 0 && (
                    <div>
                      <h4 className="font-semibold mb-3 flex items-center gap-2">
                        <Leaf className="h-4 w-4" />
                        Processing Methods
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {farmer.processing_methods.map((method: string, index: number) => (
                          <Badge key={index} variant="outline">{method}</Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {farmer.categories && (
                  <div>
                    <h4 className="font-semibold mb-3 flex items-center gap-2">
                      <Users className="h-4 w-4" />
                      Product Categories
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {Object.keys(farmer.categories).map((category: string, index: number) => (
                        <Badge key={index} variant="outline">{category}</Badge>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Sustainability Preview Card */}
            <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-emerald-50">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Leaf className="h-5 w-5 text-green-600" />
                      Sustainability Practices
                    </CardTitle>
                    <CardDescription>
                      Committed to environmental stewardship
                    </CardDescription>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setActiveTab('sustainability')}
                    className="bg-white/50 hover:bg-white"
                  >
                    View Full Dashboard
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="flex items-center gap-3 p-3 bg-white/50 rounded-lg">
                    <div className="p-2 bg-green-100 rounded">
                      <Leaf className="h-4 w-4 text-green-600" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-green-600">85%</p>
                      <p className="text-xs text-muted-foreground">Organic Production</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-white/50 rounded-lg">
                    <div className="p-2 bg-blue-100 rounded">
                      <Droplet className="h-4 w-4 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-blue-600">75%</p>
                      <p className="text-xs text-muted-foreground">Waste Reduction</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-white/50 rounded-lg">
                    <div className="p-2 bg-amber-100 rounded">
                      <Sun className="h-4 w-4 text-amber-600" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-amber-600">50%</p>
                      <p className="text-xs text-muted-foreground">Renewable Energy</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="products" className="mt-6">
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-semibold mb-4">Available Products</h3>
                {farmerProducts.length > 0 ? (
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {farmerProducts.map((product) => (
                      <ProductCard 
                        key={product.id} 
                        id={product.id}
                        name={product.name}
                        farmer={farmerDisplayName}
                        location={farmerLocation}
                        price={`$${product.price}`}
                        rating={product.average_rating || 0}
                        reviewCount={product.review_count || 0}
                        image={(product.images && product.images.length > 0) ? product.images[0].url : product.image_url}
                        category={product.category}
                        isOrganic={product.is_organic}
                        inStock={product.is_available && product.stock_quantity > 0}
                      />
                    ))}
                  </div>
                ) : (
                  <Card>
                    <CardContent className="pt-6">
                      <p className="text-center text-muted-foreground">
                        This farmer hasn't listed any products yet. Check back soon!
                      </p>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="sustainability" className="mt-6">
            <SustainabilityDashboard 
              farmName={farmerDisplayName}
              metrics={{
                carbonFootprint: 2200,
                waterUsage: 45000,
                landSize: farmer.farm_size ? parseFloat(farmer.farm_size) : 10,
                organicPercentage: 85,
                renewableEnergy: 50,
                wasteReduction: 75,
                biodiversityScore: 80,
                soilHealth: 'excellent',
                practices: [
                  'Crop Rotation',
                  'Cover Cropping',
                  'Integrated Pest Management',
                  'Composting',
                  'Rainwater Harvesting',
                  'No-Till Farming',
                  'Native Pollinator Habitats',
                  'Organic Fertilization',
                ],
              }}
            />
          </TabsContent>
        </Tabs>
      </main>
      
      <Footer />
    </div>
  );
}