import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import CategorySection from "@/components/CategorySection";
import DeliveryConfidence from "@/components/DeliveryConfidence";
import FeaturedProducts from "@/components/FeaturedProducts";
import { FeaturedSection } from "@/components/FeaturedSection";
import Footer from "@/components/Footer";
import SEOHead from "@/components/SEOHead";
import { useToast } from "@/components/ui/use-toast";

const Index = () => {
  const location = useLocation();
  const { toast } = useToast();

  // Show login message if redirected from protected page
  useEffect(() => {
    if (location.state?.message) {
      toast({
        title: "Authentication Required",
        description: location.state.message,
        variant: "destructive",
      });
    }
  }, [location.state, toast]);

  const organizationSchema = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "Farming2Door",
    "description": "Connect directly with local farmers for fresh produce, premium livestock, and custom processing options",
    "url": "https://farm2door.com",
    "logo": "https://farm2door.com/logo.png",
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+1-555-123-4567",
      "contactType": "customer service",
      "email": "support@farm2door.com"
    },
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "123 Agriculture Lane",
      "addressLocality": "Farm City",
      "postalCode": "12345",
      "addressCountry": "US"
    },
    "sameAs": [
      "https://facebook.com/farm2door",
      "https://twitter.com/farm2door",
      "https://instagram.com/farm2door"
    ]
  };

  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title="Farming2Door - Fresh from Farm to Your Door"
        description="Connect directly with local farmers. Get the freshest produce, premium livestock, and custom processing options delivered straight to your doorstep."
        keywords="farm to door, local farmers, fresh produce, grass-fed beef, organic vegetables, farm direct, sustainable agriculture"
        schemaData={organizationSchema}
      />
      
      <Header />
      <main>
        <Hero />
        <FeaturedSection />
        <CategorySection />
        <DeliveryConfidence />
        <FeaturedProducts />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
