import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { ContactSupportDialog } from "@/components/support/ContactSupportDialog";
import { Search, ShoppingCart, Truck, Star, UserCheck, Package, CreditCard, Heart } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAdmin } from "@/contexts/AdminContext";
import heroImage from "@/assets/hero-farm.jpg";
import produceImage from "@/assets/produce-vegetables.jpg";

const customerSteps = [
  {
    icon: Search,
    title: "Shop & Discover",
    description: "Search through hundreds of fresh products from local farmers in your area.",
    details: "Use our filters to find exactly what you're looking for - organic produce, grass-fed meat, or seasonal specialties."
  },
  {
    icon: ShoppingCart,
    title: "Add to Cart",
    description: "Select your items and choose processing options for livestock and custom cuts.",
    details: "Specify quantities, processing preferences, and any special instructions for your order."
  },
  {
    icon: CreditCard,
    title: "Secure Checkout",
    description: "Complete your purchase with our secure payment system and choose delivery options.",
    details: "We accept all major credit cards and offer flexible delivery and pickup options."
  },
  {
    icon: Truck,
    title: "Fast Delivery",
    description: "Receive your fresh products delivered straight to your door or pick up at the farm.",
    details: "Track your order in real-time and get notifications when your fresh food is on its way."
  }
];

const farmerSteps = [
  {
    icon: UserCheck,
    title: "Apply & Get Verified",
    description: "Submit your application and get verified as a trusted Farm2Door seller.",
    details: "Our team reviews your farming practices, certifications, and ensures quality standards."
  },
  {
    icon: Package,
    title: "List Your Products",
    description: "Upload photos and descriptions of your products with pricing and availability.",
    details: "Set up processing options, delivery zones, and inventory management for your listings."
  },
  {
    icon: ShoppingCart,
    title: "Receive Orders",
    description: "Get notified when customers place orders and manage them through your dashboard.",
    details: "View order details, customer preferences, and processing requirements all in one place."
  },
  {
    icon: Heart,
    title: "Fulfill & Earn",
    description: "Prepare orders according to customer specifications and get paid directly.",
    details: "Build relationships with customers, receive reviews, and grow your farming business."
  }
];

const benefits = [
  {
    title: "For Customers",
    items: [
      "Fresh products directly from farmers",
      "Know exactly where your food comes from",
      "Support local agriculture and economy",
      "Custom processing options available",
      "Competitive prices without middlemen",
      "Convenient delivery to your door"
    ]
  },
  {
    title: "For Farmers",
    items: [
      "Reach customers beyond local markets",
      "Set your own prices and keep more profit",
      "Build direct relationships with customers",
      "Manage orders through easy dashboard",
      "Get paid quickly and securely",
      "Grow your business with our support"
    ]
  }
];

const HowItWorks = () => {
  const navigate = useNavigate();
  const { isFarmer } = useAdmin();

  const handleCustomerClick = () => {
    document.getElementById('customer-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleFarmerClick = () => {
    navigate('/farmer-onboarding');
  };

  const handleStartShopping = () => {
    navigate('/shop');
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="py-20 bg-gradient-to-br from-background via-accent/20 to-secondary">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6">
              How <span className="text-primary">Farm2Door</span> Works
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
              Connecting farmers and customers has never been easier. 
              Here's how our platform works for both buyers and sellers.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="hero" size="lg" onClick={handleCustomerClick}>I'm a Customer</Button>
              <Button variant="outline" size="lg" onClick={handleFarmerClick}>I'm a Farmer</Button>
            </div>
          </div>
        </section>

        {/* Customer Journey */}
        <section id="customer-section" className="py-20">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <Badge className="mb-4">For Customers</Badge>
              <h2 className="text-3xl font-bold text-foreground mb-4">
                From Farm to Your Table in 4 Easy Steps
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Getting fresh, local food delivered has never been simpler
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {customerSteps.map((step, index) => {
                const IconComponent = step.icon;
                return (
                  <Card key={index} className="border-0 shadow-soft text-center relative">
                    <CardContent className="p-6">
                      <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                        <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">
                          {index + 1}
                        </div>
                      </div>
                      <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4 mt-2">
                        <IconComponent className="h-8 w-8 text-primary" />
                      </div>
                      <h3 className="text-xl font-semibold text-foreground mb-3">
                        {step.title}
                      </h3>
                      <p className="text-muted-foreground text-sm mb-3">
                        {step.description}
                      </p>
                      <p className="text-xs text-muted-foreground/80">
                        {step.details}
                      </p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        {/* Farmer Journey */}
        <section className="py-20 bg-gradient-to-b from-background to-accent/10">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <Badge className="mb-4 bg-accent-sage">For Farmers</Badge>
              <h2 className="text-3xl font-bold text-foreground mb-4">
                Start Selling Your Products in 4 Simple Steps
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Join hundreds of farmers already growing their business with Farm2Door
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {farmerSteps.map((step, index) => {
                const IconComponent = step.icon;
                return (
                  <Card key={index} className="border-0 shadow-soft text-center relative">
                    <CardContent className="p-6">
                      <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                        <div className="w-8 h-8 rounded-full bg-accent-sage text-primary-foreground flex items-center justify-center font-bold text-sm">
                          {index + 1}
                        </div>
                      </div>
                      <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-accent-sage/10 mb-4 mt-2">
                        <IconComponent className="h-8 w-8 text-accent-sage" />
                      </div>
                      <h3 className="text-xl font-semibold text-foreground mb-3">
                        {step.title}
                      </h3>
                      <p className="text-muted-foreground text-sm mb-3">
                        {step.description}
                      </p>
                      <p className="text-xs text-muted-foreground/80">
                        {step.details}
                      </p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        {/* Benefits Section */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-foreground mb-4">
                Why Choose Farm2Door?
              </h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                Benefits that matter for both customers and farmers
              </p>
            </div>

            <div className="grid lg:grid-cols-2 gap-12">
              {benefits.map((benefit, index) => (
                <Card key={index} className="border-0 shadow-soft">
                  <CardContent className="p-8">
                    <h3 className="text-2xl font-bold text-foreground mb-6">
                      {benefit.title}
                    </h3>
                    <ul className="space-y-3">
                      {benefit.items.map((item, itemIndex) => (
                        <li key={itemIndex} className="flex items-start gap-3">
                          <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0"></div>
                          <span className="text-muted-foreground">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ Preview */}
        <section className="py-20 bg-card">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold text-foreground mb-4">
              Still Have Questions?
            </h2>
            <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
              Check out our comprehensive FAQ section or contact our support team
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="outline" size="lg">
                View FAQ
              </Button>
              <ContactSupportDialog>
                <Button variant="hero" size="lg">
                  Contact Support
                </Button>
              </ContactSupportDialog>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-r from-primary/10 to-accent/10">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold text-foreground mb-4">
              Ready to Get Started?
            </h2>
            <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
              Join thousands of customers and farmers already using Farm2Door
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="hero" size="lg" onClick={handleStartShopping}>
                Start Shopping Now
              </Button>
              {!isFarmer && (
                <Button variant="outline" size="lg" onClick={handleFarmerClick}>
                  Apply as Farmer
                </Button>
              )}
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default HowItWorks;