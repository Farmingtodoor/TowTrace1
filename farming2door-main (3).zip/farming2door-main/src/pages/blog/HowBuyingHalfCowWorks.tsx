import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SEOHead from "@/components/SEOHead";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const HowBuyingHalfCowWorks = () => {
  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": "How Buying Half a Cow Works: A Complete Guide",
    "description": "Complete guide to purchasing bulk beef directly from farmers including cost savings, processing options, and storage requirements",
    "image": "/assets/meat-livestock.jpg",
    "datePublished": "2024-01-15",
    "dateModified": "2024-01-15",
    "author": {
      "@type": "Organization",
      "name": "Farm2Door"
    },
    "publisher": {
      "@type": "Organization", 
      "name": "Farm2Door",
      "logo": {
        "@type": "ImageObject",
        "url": "https://farm2door.com/logo.png"
      }
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title="How Buying Half a Cow Works: Complete Guide"
        description="Learn everything about purchasing bulk beef directly from farmers - cost savings, processing options, storage tips, and what to expect when buying half a cow."
        keywords="buy half cow, bulk beef, direct from farmer, meat processing, beef cuts, grass fed beef"
        type="article"
        schemaData={articleSchema}
      />
      
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <article className="max-w-4xl mx-auto">
          <header className="mb-8">
            <div className="flex items-center gap-4 mb-4">
              <Badge variant="secondary">Education</Badge>
              <span className="text-muted-foreground">8 min read</span>
              <span className="text-muted-foreground">Published Jan 15, 2024</span>
            </div>
            <h1 className="text-4xl font-bold text-foreground mb-4">
              How Buying Half a Cow Works: A Complete Guide
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Discover the benefits, process, and practical considerations of purchasing bulk beef directly from local farmers
            </p>
          </header>

          <div className="aspect-video mb-8 rounded-lg overflow-hidden">
            <img 
              src="/assets/meat-livestock.jpg" 
              alt="Grass-fed cattle on farm"
              className="w-full h-full object-cover"
            />
          </div>

          <div className="prose prose-lg max-w-none">
            <Card className="mb-8 p-6 bg-accent/10">
              <CardContent className="p-0">
                <h2 className="text-2xl font-semibold mb-4">Quick Summary</h2>
                <ul className="space-y-2 text-muted-foreground">
                  <li>• Half a cow typically yields 200-250 lbs of packaged meat</li>
                  <li>• Cost savings of 20-40% compared to retail prices</li>
                  <li>• Requires significant freezer space (8-10 cubic feet)</li>
                  <li>• Processing takes 2-3 weeks from farm to freezer</li>
                  <li>• Perfect for families who consume 4+ lbs of beef weekly</li>
                </ul>
              </CardContent>
            </Card>

            <h2 className="text-3xl font-semibold mb-4 text-foreground">What You Get When Buying Half a Cow</h2>
            
            <p className="mb-6 text-muted-foreground leading-relaxed">
              When you purchase half a cow (also called a "beef half" or "side of beef"), you're buying approximately half of a whole processed animal. This typically includes a variety of cuts that would cost significantly more if purchased individually at retail.
            </p>

            <h3 className="text-2xl font-semibold mb-4 text-foreground">Typical Cut Breakdown:</h3>
            <div className="grid md:grid-cols-2 gap-6 mb-8">
              <Card className="p-4">
                <h4 className="font-semibold mb-3">Premium Steaks (25-30%)</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Ribeye</li>
                  <li>• New York Strip</li>
                  <li>• Filet Mignon/Tenderloin</li>
                  <li>• T-bone & Porterhouse</li>
                </ul>
              </Card>
              <Card className="p-4">
                <h4 className="font-semibold mb-3">Roasts & Large Cuts (35-40%)</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Chuck Roast</li>
                  <li>• Sirloin Tip Roast</li>
                  <li>• Eye of Round</li>
                  <li>• Brisket</li>
                </ul>
              </Card>
              <Card className="p-4">
                <h4 className="font-semibold mb-3">Ground Beef (30-35%)</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Various fat percentages</li>
                  <li>• Typically 85/15 or 90/10</li>
                  <li>• Custom blends available</li>
                </ul>
              </Card>
              <Card className="p-4">
                <h4 className="font-semibold mb-3">Specialty Items</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Short Ribs</li>
                  <li>• Soup Bones</li>
                  <li>• Organ Meat (optional)</li>
                </ul>
              </Card>
            </div>

            <h2 className="text-3xl font-semibold mb-4 text-foreground">The Process: From Farm to Freezer</h2>
            
            <div className="space-y-6 mb-8">
              <Card className="p-4">
                <h4 className="font-semibold mb-2">Step 1: Place Your Order</h4>
                <p className="text-muted-foreground text-sm">
                  Reserve your half cow with the farmer. You'll typically pay a deposit and schedule processing.
                </p>
              </Card>
              
              <Card className="p-4">
                <h4 className="font-semibold mb-2">Step 2: Choose Your Processing Options</h4>
                <p className="text-muted-foreground text-sm">
                  Work with the processor to specify cuts, thickness, packaging preferences, and any special requests.
                </p>
              </Card>
              
              <Card className="p-4">
                <h4 className="font-semibold mb-2">Step 3: Processing & Aging</h4>
                <p className="text-muted-foreground text-sm">
                  The beef is dry-aged for 14-21 days to enhance flavor and tenderness, then cut and packaged.
                </p>
              </Card>
              
              <Card className="p-4">
                <h4 className="font-semibold mb-2">Step 4: Pickup or Delivery</h4>
                <p className="text-muted-foreground text-sm">
                  Your packaged, frozen beef is ready for pickup or delivery to your home.
                </p>
              </Card>
            </div>

            <h2 className="text-3xl font-semibold mb-4 text-foreground">Cost Analysis: Is It Worth It?</h2>
            
            <p className="mb-4 text-muted-foreground leading-relaxed">
              The financial benefits of buying in bulk can be substantial, but it's important to understand the full cost structure:
            </p>

            <Card className="mb-6 p-6 bg-primary/5">
              <h4 className="font-semibold mb-4">Example Cost Breakdown (Half Cow)</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Live weight (400-500 lbs) × $4.50/lb</span>
                  <span>$1,800-$2,250</span>
                </div>
                <div className="flex justify-between">
                  <span>Processing fees</span>
                  <span>$400-$600</span>
                </div>
                <div className="flex justify-between border-t pt-2 font-semibold">
                  <span>Total Cost</span>
                  <span>$2,200-$2,850</span>
                </div>
                <div className="flex justify-between text-primary">
                  <span>Cost per pound (packaged weight)</span>
                  <span>$9-$12/lb</span>
                </div>
              </div>
            </Card>

            <h2 className="text-3xl font-semibold mb-4 text-foreground">Storage Requirements</h2>
            
            <p className="mb-4 text-muted-foreground leading-relaxed">
              Before committing to a half cow, ensure you have adequate freezer space:
            </p>

            <ul className="list-disc pl-6 mb-6 text-muted-foreground space-y-2">
              <li>You'll need 8-10 cubic feet of freezer space</li>
              <li>A standard refrigerator freezer (3-4 cu ft) is not sufficient</li>
              <li>Consider investing in a chest freezer or upright freezer</li>
              <li>Properly wrapped beef can be stored 6-12 months</li>
            </ul>

            <h2 className="text-3xl font-semibold mb-4 text-foreground">Getting Started with Farm2Door</h2>
            
            <p className="mb-6 text-muted-foreground leading-relaxed">
              Ready to experience the quality and savings of buying directly from farmers? Our platform makes it easy to connect with local farmers offering bulk beef options. Shop our selection of grass-fed, pasture-raised cattle from verified farms in your area.
            </p>

            <Card className="p-6 bg-accent/10">
              <h4 className="font-semibold mb-4">Next Steps:</h4>
              <ol className="list-decimal pl-6 space-y-2 text-muted-foreground">
                <li>Shop farmers offering bulk beef in your area</li>
                <li>Contact farmers directly to discuss availability and pricing</li>
                <li>Schedule a farm visit if desired</li>
                <li>Place your order and arrange processing</li>
                <li>Prepare your freezer space</li>
                <li>Enjoy premium, farm-fresh beef for months to come</li>
              </ol>
            </Card>
          </div>
        </article>
      </main>
      
      <Footer />
    </div>
  );
};

export default HowBuyingHalfCowWorks;