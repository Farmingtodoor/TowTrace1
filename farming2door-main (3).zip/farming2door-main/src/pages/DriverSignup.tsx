import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import SEOHead from "@/components/SEOHead";
import { AuthDialog } from "@/components/auth/AuthDialog";

export default function DriverSignup() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    full_name: "",
    email: user?.email || "",
    phone: "",
    vehicle_type: "",
    license_plate: "",
    driver_license_number: ""
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast.error("Please sign in to register as a driver");
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase
        .from('driver_profiles')
        .insert({
          user_id: user.id,
          ...formData
        });

      if (error) throw error;

      await supabase
        .from('user_roles')
        .insert({
          user_id: user.id,
          role: 'driver'
        });

      toast.success("Driver application submitted successfully! Awaiting verification.");
      navigate("/driver-dashboard");
    } catch (error: any) {
      toast.error(error.message || "Failed to submit application");
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  if (!user) {
    return (

      <>
        <SEOHead
          title="Become a Driver - Farm2Door"
          description="Sign in to join the Farming2Door delivery network and start earning by delivering fresh farm products."
        />
        <div className="min-h-screen flex items-center justify-center bg-background px-4">
          <Card className="w-full max-w-md">
            <CardHeader>
              <h1 className="text-2xl font-bold tracking-tight">Become a Farm2Door Driver</h1>
              <CardDescription>
                Sign in or create an account to start your driver application — it takes about 2 minutes.
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-3">
              <AuthDialog />
              <Button variant="ghost" onClick={() => navigate("/")}>Back to home</Button>
            </CardContent>
          </Card>
        </div>
      </>
    );
  }

  return (
    <>
      <SEOHead 
        title="Become a Driver - Farm2Door" 
        description="Join our delivery network and start earning by delivering fresh farm products to customers."
        keywords="driver signup, delivery jobs, farm delivery, earn money"
      />
      <div className="min-h-screen bg-background py-8">
        <div className="container mx-auto px-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate(-1)} 
            className="mb-6 flex items-center gap-2 hover:bg-muted"
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-center">
                Become a Farm2Door Driver
              </CardTitle>
              <CardDescription className="text-center">
                Join our delivery network and start earning by delivering fresh farm products
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="full_name">Full Name *</Label>
                    <Input
                      id="full_name"
                      value={formData.full_name}
                      onChange={(e) => handleInputChange("full_name", e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => handleInputChange("phone", e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="vehicle_type">Vehicle Type *</Label>
                  <Select value={formData.vehicle_type} onValueChange={(value) => handleInputChange("vehicle_type", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select your vehicle type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="car">Car</SelectItem>
                      <SelectItem value="suv">SUV</SelectItem>
                      <SelectItem value="pickup_truck">Pickup Truck</SelectItem>
                      <SelectItem value="van">Van</SelectItem>
                      <SelectItem value="motorcycle">Motorcycle</SelectItem>
                      <SelectItem value="bicycle">Bicycle</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="license_plate">License Plate *</Label>
                    <Input
                      id="license_plate"
                      value={formData.license_plate}
                      onChange={(e) => handleInputChange("license_plate", e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="driver_license_number">Driver License Number *</Label>
                    <Input
                      id="driver_license_number"
                      value={formData.driver_license_number}
                      onChange={(e) => handleInputChange("driver_license_number", e.target.value)}
                      required
                    />
                  </div>
                </div>

                <div className="bg-muted p-4 rounded-lg">
                  <h3 className="font-semibold mb-2">Driver Requirements:</h3>
                  <ul className="text-sm space-y-1 text-muted-foreground">
                    <li>• Valid driver's license and vehicle registration</li>
                    <li>• Clean driving record</li>
                    <li>• Smartphone with GPS capability</li>
                    <li>• Ability to lift up to 50 pounds</li>
                    <li>• Professional and courteous attitude</li>
                  </ul>
                </div>

                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={loading}
                >
                  {loading ? "Submitting..." : "Submit Driver Application"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}