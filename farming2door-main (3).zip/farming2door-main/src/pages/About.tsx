import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Heart, Users, Leaf, Truck, Shield, Award } from "lucide-react";
import heroImage from "@/assets/hero-farm.jpg";

const values = [
  {
    icon: Heart,
    title: "Community First",
    description: "We believe in strengthening local communities by connecting neighbors with their local farmers and producers."
  },
  {
    icon: Leaf,
    title: "Sustainable Practices",
    description: "Supporting environmentally responsible farming methods that protect our planet for future generations."
  },
  {
    icon: Shield,
    title: "Quality Assurance",
    description: "Every farmer is vetted and every product is guaranteed to meet our high standards for freshness and quality."
  },
  {
    icon: Users,
    title: "Direct Relationships",
    description: "Eliminating the middleman to ensure farmers get fair prices and customers get the best value."
  }
];

const stats = [
  { number: "500+", label: "Local Farmers" },
  { number: "50,000+", label: "Happy Customers" },
  { number: "25+", label: "Cities Served" },
  { number: "1M+", label: "Products Delivered" }
];

const About = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main>
        {/* Hero Section */}
        <section className="py-20 bg-gradient-to-br from-background via-accent/20 to-secondary">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <h1 className="text-4xl md:text-6xl font-bold text-foreground leading-tight">
                  Connecting <span className="text-primary">Communities</span> Through 
                  <span className="text-accent-warm"> Fresh Food</span>
                </h1>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  Farm2Door was founded with a simple mission: to make fresh, local, 
                  high-quality food accessible to everyone while supporting the farmers 
                  who grow it with passion and care.
                </p>
              </div>
              <div className="relative">
                <img
                  src={heroImage}
                  alt="Farm2Door mission"
                  className="w-full h-[400px] object-cover rounded-3xl shadow-2xl"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-16 bg-card">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
              {stats.map((stat, index) => (
                <div key={index}>
                  <div className="text-3xl md:text-4xl font-bold text-primary mb-2">
                    {stat.number}
                  </div>
                  <div className="text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Our Story */}
        <section className="py-20">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold text-foreground mb-8 text-center">Our Story</h2>
              
              <div className="prose prose-lg mx-auto text-muted-foreground">
                <p className="mb-6">
                  Farm2Door began in 2020 when our founders realized how difficult it was 
                  for both farmers and consumers to connect directly. Farmers struggled 
                  to reach customers beyond local farmers' markets, while families wanted 
                  access to fresh, local produce but didn't always have the time to visit 
                  multiple farms and markets.
                </p>
                
                <p className="mb-6">
                  We saw an opportunity to bridge this gap using technology, creating a 
                  platform that would benefit everyone in the food supply chain. By 
                  connecting customers directly with local farmers, we eliminate unnecessary 
                  middlemen, ensure farmers receive fair compensation, and guarantee 
                  customers get the freshest products possible.
                </p>
                
                <p>
                  Today, Farm2Door serves hundreds of farming families and thousands of 
                  households across the country, creating a sustainable ecosystem that 
                  supports local agriculture and strengthens communities.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-20 bg-gradient-to-b from-background to-accent/10">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-foreground mb-4">Our Values</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto">
                These core principles guide everything we do at Farm2Door
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {values.map((value, index) => {
                const IconComponent = value.icon;
                return (
                  <Card key={index} className="border-0 shadow-soft text-center">
                    <CardContent className="p-6">
                      <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                        <IconComponent className="h-8 w-8 text-primary" />
                      </div>
                      <h3 className="text-xl font-semibold text-foreground mb-3">
                        {value.title}
                      </h3>
                      <p className="text-muted-foreground text-sm leading-relaxed">
                        {value.description}
                      </p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        {/* Team Section - Real team members to be added */}
        <section className="py-20">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold text-foreground mb-8">Meet Our Team</h2>
            <p className="text-muted-foreground mb-12 max-w-2xl mx-auto">
              We're a passionate team of food lovers, technology enthusiasts, and 
              community builders working to revolutionize how we think about local food.
            </p>
            
            <div className="text-center py-8">
              <p className="text-muted-foreground">Team profiles coming soon!</p>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-r from-primary/10 to-accent/10">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold text-foreground mb-4">
              Join the Farm2Door Community
            </h2>
            <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
              Whether you're a farmer looking to reach new customers or a family 
              wanting access to fresh, local food, we'd love to have you join us.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="hero" size="lg">
                Start Shopping
              </Button>
              <Button variant="outline" size="lg">
                Become a Seller
              </Button>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default About;