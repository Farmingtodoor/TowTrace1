import { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Plus, Search, MapPin, Heart, Home } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/components/ui/use-toast';

interface BreedingStockListing {
  id: string;
  title: string;
  type: string;
  sex: string;
  age_months: number;
  breeding_status: string;
  price: number;
  photos: any;
  location_city: string;
  location_state: string;
  status: string;
  farmer_id: string;
  category_id: string;
  breed_id: string;
  registration_number: string;
  transport_delivery: boolean;
}

interface Category {
  id: string;
  name: string;
  slug: string;
}

export default function BreedingStock() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { user } = useAuth();
  
  const [listings, setListings] = useState<BreedingStockListing[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  
  const categoryFilter = searchParams.get('category') || 'all';
  const searchQuery = searchParams.get('search') || '';
  const sortBy = searchParams.get('sort') || 'newest';

  useEffect(() => {
    fetchCategories();
    fetchListings();
  }, [categoryFilter, searchQuery, sortBy]);

  const fetchCategories = async () => {
    const { data } = await supabase
      .from('breeding_stock_categories')
      .select('*')
      .eq('is_active', true)
      .order('display_order');
    
    if (data) setCategories(data);
  };

  const fetchListings = async () => {
    setLoading(true);
    
    let query = supabase
      .from('breeding_stock_listings')
      .select('*')
      .in('status', ['active', 'reserved']);
    
    if (categoryFilter !== 'all') {
      const category = categories.find(c => c.slug === categoryFilter);
      if (category) {
        query = query.eq('category_id', category.id);
      }
    }
    
    if (searchQuery) {
      query = query.ilike('title', `%${searchQuery}%`);
    }
    
    switch (sortBy) {
      case 'price-low':
        query = query.order('price', { ascending: true });
        break;
      case 'price-high':
        query = query.order('price', { ascending: false });
        break;
      case 'newest':
      default:
        query = query.order('created_at', { ascending: false });
    }
    
    const { data, error } = await query;
    
    if (error) {
      toast({ title: 'Error loading listings', variant: 'destructive' });
    } else {
      setListings(data || []);
    }
    
    setLoading(false);
  };

  const handleSearch = (value: string) => {
    const params = new URLSearchParams(searchParams);
    if (value) {
      params.set('search', value);
    } else {
      params.delete('search');
    }
    setSearchParams(params);
  };

  const handleCategoryChange = (value: string) => {
    const params = new URLSearchParams(searchParams);
    params.set('category', value);
    setSearchParams(params);
  };

  const handleSortChange = (value: string) => {
    const params = new URLSearchParams(searchParams);
    params.set('sort', value);
    setSearchParams(params);
  };

  return (
    <>
      <Helmet>
        <title>Breeding Stock Marketplace - Farming2Door</title>
        <meta name="description" content="Find quality breeding livestock from verified farmers. Cattle, goats, sheep, pigs, poultry, and more." />
      </Helmet>

      <div className="min-h-screen bg-background">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-primary/10 via-primary/5 to-background py-12 border-b">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl">
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate('/')}
                className="mb-4 gap-2"
              >
                <Home className="w-4 h-4" />
                Home
              </Button>
              <h1 className="text-4xl font-bold mb-4">Breeding Stock Marketplace</h1>
              <p className="text-lg text-muted-foreground mb-6">
                Find quality breeding livestock from verified farmers. All animals come with health records, registration papers, and breeding guarantees.
              </p>
              
              {user && (
                <Button onClick={() => navigate('/breeding-stock/create')} size="lg">
                  <Plus className="w-4 h-4 mr-2" />
                  List Breeding Stock
                </Button>
              )}
            </div>
          </div>
        </section>

        {/* Filters */}
        <section className="border-b bg-card">
          <div className="container mx-auto px-4 py-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                  <Input
                    placeholder="Search breeding stock..."
                    value={searchQuery}
                    onChange={(e) => handleSearch(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              
              <Select value={categoryFilter} onValueChange={handleCategoryChange}>
                <SelectTrigger className="w-full md:w-[200px]">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map(cat => (
                    <SelectItem key={cat.id} value={cat.slug}>{cat.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select value={sortBy} onValueChange={handleSortChange}>
                <SelectTrigger className="w-full md:w-[200px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Newest First</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </section>

        {/* Listings Grid */}
        <section className="container mx-auto px-4 py-12">
          {loading ? (
            <div className="text-center py-12">Loading...</div>
          ) : listings.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No breeding stock found matching your criteria.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {listings.map(listing => (
                <Card 
                  key={listing.id} 
                  className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
                  onClick={() => navigate(`/breeding-stock/${listing.id}`)}
                >
                  <div className="aspect-video relative bg-muted">
                    {listing.photos && Array.isArray(listing.photos) && listing.photos.length > 0 ? (
                      <img 
                        src={listing.photos[0]} 
                        alt={listing.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                        No image
                      </div>
                    )}
                    {listing.status === 'reserved' && (
                      <Badge className="absolute top-2 right-2" variant="secondary">
                        Reserved
                      </Badge>
                    )}
                    {listing.registration_number && (
                      <Badge className="absolute top-2 left-2 bg-green-600">
                        Registered
                      </Badge>
                    )}
                  </div>
                  
                  <div className="p-4">
                    <h3 className="font-semibold text-lg mb-2 line-clamp-1">{listing.title}</h3>
                    
                    <div className="flex gap-2 mb-3 flex-wrap">
                      <Badge variant="outline">{listing.type}</Badge>
                      {listing.sex && <Badge variant="outline">{listing.sex}</Badge>}
                      {listing.age_months && (
                        <Badge variant="outline">{listing.age_months} months</Badge>
                      )}
                    </div>
                    
                    {listing.breeding_status && (
                      <p className="text-sm text-muted-foreground mb-2 capitalize">
                        {listing.breeding_status.replace('_', ' ')}
                      </p>
                    )}
                    
                    <div className="flex items-center gap-1 text-sm text-muted-foreground mb-3">
                      <MapPin className="w-4 h-4" />
                      <span>{listing.location_city}, {listing.location_state}</span>
                    </div>
                    
                    <div className="flex items-center justify-between pt-3 border-t">
                      <div>
                        <p className="text-2xl font-bold text-primary">
                          ${listing.price.toLocaleString()}
                        </p>
                        {listing.transport_delivery && (
                          <p className="text-xs text-muted-foreground">Delivery available</p>
                        )}
                      </div>
                      <Button variant="outline" size="sm">
                        View Details
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </section>

        {/* Compliance Notice */}
        <section className="bg-muted/30 border-t py-8">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h3 className="font-semibold mb-2">⚠️ Important Compliance Information</h3>
              <p className="text-sm text-muted-foreground">
                Livestock purchases may require health certificates (CVI), brand inspection, ID tags, and other documentation based on your state's regulations. 
                Buyers are responsible for understanding and complying with all applicable interstate and intrastate movement requirements.
              </p>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}
