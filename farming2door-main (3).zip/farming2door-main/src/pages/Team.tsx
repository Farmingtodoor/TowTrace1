import { Users, Linkedin, Mail } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SEOHead from "@/components/SEOHead";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const Team = () => {
  const executives = [
    {
      name: "Sarah Johnson",
      role: "Chief Executive Officer",
      bio: "With over 15 years of experience in agricultural technology, Sarah leads Farming2Door's vision to revolutionize farm-to-consumer connections.",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop",
      linkedin: "#",
      email: "sarah@farming2door.com"
    },
    {
      name: "Michael Chen",
      role: "Chief Technology Officer",
      bio: "Michael brings deep expertise in platform development and logistics optimization, ensuring seamless experiences for farmers and consumers.",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop",
      linkedin: "#",
      email: "michael@farming2door.com"
    },
    {
      name: "Emily Rodriguez",
      role: "Chief Operations Officer",
      bio: "Emily's background in supply chain management and farmer relations helps build strong partnerships with our farming community.",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop",
      linkedin: "#",
      email: "emily@farming2door.com"
    }
  ];

  const leadership = [
    {
      name: "David Thompson",
      role: "VP of Farmer Relations",
      bio: "David works directly with farmers to ensure they have the tools and support needed for success on our platform.",
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop"
    },
    {
      name: "Lisa Park",
      role: "VP of Marketing",
      bio: "Lisa leads our marketing efforts to connect conscious consumers with local, sustainable food sources.",
      image: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=400&h=400&fit=crop"
    },
    {
      name: "James Wilson",
      role: "VP of Customer Success",
      bio: "James ensures every customer has an exceptional experience discovering and purchasing from local farms.",
      image: "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=400&h=400&fit=crop"
    }
  ];

  return (
    <>
      <SEOHead
        title="Meet Our Team"
        description="Get to know the dedicated team behind Farming2Door who are working to connect farmers and consumers for a more sustainable food future."
        keywords="Farming2Door team, leadership, executives, about our team"
      />
      <Header />
      
      <main className="min-h-screen bg-gradient-to-b from-background to-muted/20">
        {/* Hero Section */}
        <section className="bg-primary text-primary-foreground py-20">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <Users className="h-16 w-16 mx-auto mb-6" />
              <h1 className="text-4xl md:text-5xl font-bold mb-4">Meet Our Team</h1>
              <p className="text-xl text-primary-foreground/90">
                The passionate people working to revolutionize how communities access fresh, local food
              </p>
            </div>
          </div>
        </section>

        {/* Executive Team */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-3xl font-bold text-center mb-4">Executive Team</h2>
              <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
                Our leadership team brings decades of combined experience in technology, agriculture, and sustainable business practices.
              </p>
              
              <div className="grid md:grid-cols-3 gap-8">
                {executives.map((exec, index) => (
                  <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="aspect-square overflow-hidden">
                      <img 
                        src={exec.image} 
                        alt={exec.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="p-6">
                      <h3 className="text-xl font-bold mb-1">{exec.name}</h3>
                      <p className="text-primary font-medium mb-3">{exec.role}</p>
                      <p className="text-muted-foreground text-sm mb-4">{exec.bio}</p>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" asChild>
                          <a href={exec.linkedin} target="_blank" rel="noopener noreferrer">
                            <Linkedin className="h-4 w-4 mr-2" />
                            LinkedIn
                          </a>
                        </Button>
                        <Button variant="outline" size="sm" asChild>
                          <a href={`mailto:${exec.email}`}>
                            <Mail className="h-4 w-4" />
                          </a>
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Leadership Team */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="max-w-6xl mx-auto">
              <h2 className="text-3xl font-bold text-center mb-4">Leadership Team</h2>
              <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
                Our department leaders are committed to delivering excellence in every aspect of the Farming2Door experience.
              </p>
              
              <div className="grid md:grid-cols-3 gap-8">
                {leadership.map((member, index) => (
                  <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="aspect-square overflow-hidden">
                      <img 
                        src={member.image} 
                        alt={member.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="p-6">
                      <h3 className="text-xl font-bold mb-1">{member.name}</h3>
                      <p className="text-primary font-medium mb-3">{member.role}</p>
                      <p className="text-muted-foreground text-sm">{member.bio}</p>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Join Our Team CTA */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-3xl font-bold mb-4">Join Our Team</h2>
              <p className="text-lg text-muted-foreground mb-8">
                We're always looking for talented individuals who share our passion for sustainable agriculture and local food systems.
              </p>
              <Button size="lg" asChild>
                <a href="/careers">View Open Positions</a>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default Team;
