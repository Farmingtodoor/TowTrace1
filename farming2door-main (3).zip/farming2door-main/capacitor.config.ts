import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.c2f2638b64d54701ac8948a04d6451b0',
  appName: 'fresh-finds-connection',
  webDir: 'dist',
  server: {
    url: 'https://c2f2638b-64d5-4701-ac89-48a04d6451b0.lovableproject.com?forceHideBadge=true',
    cleartext: true
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 0
    }
  }
};

export default config;