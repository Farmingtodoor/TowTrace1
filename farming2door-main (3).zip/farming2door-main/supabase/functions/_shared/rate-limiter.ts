// Rate limiting utility for Stripe payment functions to combat card testing
// Uses in-memory store with IP-based tracking

interface RateLimitEntry {
  count: number;
  firstRequest: number;
  lastRequest: number;
}

// In-memory rate limit store (resets on function cold start)
const rateLimitStore = new Map<string, RateLimitEntry>();

// Clean up old entries every 5 minutes
const CLEANUP_INTERVAL = 5 * 60 * 1000;
const WINDOW_SIZE = 60 * 1000; // 1 minute window
const MAX_REQUESTS_PER_WINDOW = 5; // Max 5 payment attempts per minute per IP
const BLOCK_DURATION = 15 * 60 * 1000; // Block for 15 minutes after exceeding limit

let lastCleanup = Date.now();

function cleanupOldEntries() {
  const now = Date.now();
  if (now - lastCleanup < CLEANUP_INTERVAL) return;
  
  for (const [key, entry] of rateLimitStore.entries()) {
    if (now - entry.lastRequest > BLOCK_DURATION) {
      rateLimitStore.delete(key);
    }
  }
  lastCleanup = now;
}

export function checkRateLimit(identifier: string): { allowed: boolean; retryAfter?: number } {
  cleanupOldEntries();
  
  const now = Date.now();
  const entry = rateLimitStore.get(identifier);
  
  if (!entry) {
    rateLimitStore.set(identifier, {
      count: 1,
      firstRequest: now,
      lastRequest: now,
    });
    return { allowed: true };
  }
  
  // Check if window has expired
  if (now - entry.firstRequest > WINDOW_SIZE) {
    // Reset window
    rateLimitStore.set(identifier, {
      count: 1,
      firstRequest: now,
      lastRequest: now,
    });
    return { allowed: true };
  }
  
  // Check if blocked
  if (entry.count >= MAX_REQUESTS_PER_WINDOW) {
    const blockEnds = entry.lastRequest + BLOCK_DURATION;
    if (now < blockEnds) {
      return { 
        allowed: false, 
        retryAfter: Math.ceil((blockEnds - now) / 1000) 
      };
    }
    // Block period ended, reset
    rateLimitStore.set(identifier, {
      count: 1,
      firstRequest: now,
      lastRequest: now,
    });
    return { allowed: true };
  }
  
  // Increment count
  entry.count++;
  entry.lastRequest = now;
  rateLimitStore.set(identifier, entry);
  
  return { allowed: true };
}

export function getClientIdentifier(req: Request): string {
  // Get IP from various headers (Cloudflare, standard, etc.)
  const forwardedFor = req.headers.get('x-forwarded-for');
  const realIp = req.headers.get('x-real-ip');
  const cfConnectingIp = req.headers.get('cf-connecting-ip');
  
  // Use the first available IP
  const ip = cfConnectingIp || realIp || forwardedFor?.split(',')[0]?.trim() || 'unknown';
  
  return ip;
}

// Additional fraud detection helpers
export function isDisposableEmail(email: string): boolean {
  const disposableDomains = [
    'tempmail.com', 'throwaway.email', 'guerrillamail.com', 
    'mailinator.com', '10minutemail.com', 'yopmail.com',
    'temp-mail.org', 'fakeinbox.com', 'trashmail.com',
    'getnada.com', 'discard.email', 'sharklasers.com'
  ];
  
  const domain = email.split('@')[1]?.toLowerCase();
  return disposableDomains.some(d => domain?.includes(d));
}

export function validateEmailFormat(email: string): boolean {
  // More strict email validation
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return emailRegex.test(email) && email.length <= 254;
}

export function detectSuspiciousPatterns(req: Request): { suspicious: boolean; reason?: string } {
  const userAgent = req.headers.get('user-agent') || '';
  
  // Check for missing or suspicious user agents
  if (!userAgent || userAgent.length < 10) {
    return { suspicious: true, reason: 'Invalid user agent' };
  }
  
  // Check for known bot patterns
  const botPatterns = ['curl', 'wget', 'python-requests', 'scrapy', 'bot', 'crawler'];
  if (botPatterns.some(pattern => userAgent.toLowerCase().includes(pattern))) {
    return { suspicious: true, reason: 'Bot-like user agent' };
  }
  
  return { suspicious: false };
}
