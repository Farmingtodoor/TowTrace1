import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.0";
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const supabase = createClient(
  Deno.env.get("SUPABASE_URL") ?? "",
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
);

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
const FROM_EMAIL = Deno.env.get("FROM_EMAIL") || "noreply@resend.dev";
const SITE_URL = Deno.env.get("SITE_URL") || "https://farming2door.com";

type AlertType = "delivery_coverage" | "pickup_slots";

interface WaitlistRow {
  id: string;
  farmer_id: string;
  email: string;
  zip_code: string;
  distance_miles: number | null;
  notify_delivery: boolean;
  notify_pickup: boolean;
}

const emailBody = (
  type: AlertType,
  farmName: string,
  zip: string,
  detail: string,
  waitlistId: string,
) => {
  const heading =
    type === "delivery_coverage"
      ? `Good news — ${farmName} now delivers to ${zip}`
      : `Pickup times just opened up at ${farmName}`;

  return `
  <div style="font-family:system-ui,-apple-system,Segoe UI,sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#1f2a24">
    <h1 style="font-size:20px;margin:0 0 12px">${heading}</h1>
    <p style="font-size:15px;line-height:1.6;margin:0 0 16px">${detail}</p>
    <a href="${SITE_URL}/farmers"
       style="display:inline-block;background:#2f6f4f;color:#fff;text-decoration:none;padding:12px 20px;border-radius:8px;font-weight:600">
      Start your order
    </a>
    <p style="font-size:12px;color:#6b7770;margin-top:28px">
      You're receiving this because you asked to be notified for ZIP ${zip}.
      <a href="${SITE_URL}/waitlist/unsubscribe?id=${waitlistId}" style="color:#6b7770">Unsubscribe</a>
    </p>
  </div>`;
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { data: waitlist, error } = await supabase
      .from("delivery_waitlist")
      .select("id, farmer_id, email, zip_code, distance_miles, notify_delivery, notify_pickup")
      .eq("status", "pending")
      .limit(1000);

    if (error) throw error;

    const rows = (waitlist ?? []) as WaitlistRow[];
    const farmerIds = [...new Set(rows.map((r) => r.farmer_id))];
    if (farmerIds.length === 0) {
      return new Response(JSON.stringify({ checked: 0, sent: 0 }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const [settingsRes, slotsRes, profilesRes] = await Promise.all([
      supabase
        .from("farmer_delivery_settings")
        .select("farmer_id, offers_delivery, delivery_radius_miles, offers_pickup")
        .in("farmer_id", farmerIds),
      supabase
        .from("farmer_pickup_slots")
        .select("farmer_id, is_active")
        .in("farmer_id", farmerIds)
        .eq("is_active", true),
      supabase.from("profiles").select("id, full_name").in("id", farmerIds),
    ]);

    const settings = new Map(
      (settingsRes.data ?? []).map((s: Record<string, unknown>) => [s.farmer_id as string, s]),
    );
    const hasSlots = new Set((slotsRes.data ?? []).map((s: Record<string, unknown>) => s.farmer_id as string));
    const farmNames = new Map(
      (profilesRes.data ?? []).map((p: Record<string, unknown>) => [
        p.id as string,
        (p.full_name as string) || "Your farm",
      ]),
    );

    let sent = 0;

    for (const row of rows) {
      const setting = settings.get(row.farmer_id) as
        | { offers_delivery: boolean; delivery_radius_miles: number; offers_pickup: boolean }
        | undefined;
      const farmName = farmNames.get(row.farmer_id) ?? "The farm";
      const alerts: { type: AlertType; detail: string }[] = [];

      const coversZip =
        !!setting?.offers_delivery &&
        row.distance_miles != null &&
        Number(row.distance_miles) <= Number(setting.delivery_radius_miles);

      if (row.notify_delivery && coversZip) {
        alerts.push({
          type: "delivery_coverage",
          detail: `${farmName} expanded its delivery area to ${setting!.delivery_radius_miles} miles, which now reaches ZIP ${row.zip_code} (about ${Number(row.distance_miles).toFixed(1)} mi away). You can place a delivery order right away.`,
        });
      }

      if (row.notify_pickup && hasSlots.has(row.farmer_id)) {
        alerts.push({
          type: "pickup_slots",
          detail: `${farmName} has published pickup time windows you can book at checkout. Choose a window that works for you and pick your order up straight from the farm.`,
        });
      }

      for (const alert of alerts) {
        // Idempotency claim: unique(waitlist_id, alert_type)
        const { error: claimError } = await supabase
          .from("waitlist_alerts_sent")
          .insert({ waitlist_id: row.id, alert_type: alert.type });
        if (claimError) continue;

        try {
          await resend.emails.send({
            from: `Farming2Door <${FROM_EMAIL}>`,
            to: [row.email],
            subject:
              alert.type === "delivery_coverage"
                ? `Delivery is now available in ${row.zip_code}`
                : `Pickup times are open at ${farmName}`,
            html: emailBody(alert.type, farmName, row.zip_code, alert.detail, row.id),
          });
          sent += 1;
        } catch (e) {
          console.error("Waitlist alert email failed", e instanceof Error ? e.message : e);
          await supabase
            .from("waitlist_alerts_sent")
            .delete()
            .eq("waitlist_id", row.id)
            .eq("alert_type", alert.type);
        }
      }
    }

    return new Response(JSON.stringify({ checked: rows.length, sent }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("notify-waitlist-availability error", e instanceof Error ? e.message : e);
    return new Response(JSON.stringify({ error: "Failed to process waitlist alerts" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
