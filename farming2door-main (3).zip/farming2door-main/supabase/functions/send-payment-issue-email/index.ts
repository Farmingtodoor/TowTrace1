import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface PaymentIssueEmailRequest {
  customerEmail: string;
  customerName: string;
  planName: string;
  subscriptionId: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log("Sending payment issue email");

    const { customerEmail, customerName, planName, subscriptionId }: PaymentIssueEmailRequest = await req.json();

    if (!customerEmail || !planName) {
      throw new Error("Missing required email parameters");
    }

    const emailHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Payment Issue - Action Required</title>
          <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); color: white; padding: 30px 20px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #ffffff; padding: 30px; border: 1px solid #e5e7eb; }
            .footer { background: #f9fafb; padding: 20px; text-align: center; border-radius: 0 0 8px 8px; }
            .alert { background: #fef2f2; border-left: 4px solid #ef4444; padding: 15px; margin: 20px 0; }
            .button { display: inline-block; background: #ef4444; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 15px 0; }
            .button-secondary { background: #6b7280; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>⚠️ Payment Issue with Your Subscription</h1>
              <p>Action required to continue your deliveries</p>
            </div>
            
            <div class="content">
              <h2>Hello ${customerName || 'Customer'},</h2>
              
              <p>We've encountered an issue processing the payment for your <strong>${planName}</strong> subscription.</p>
              
              <div class="alert">
                <h3>🚨 Immediate Action Required</h3>
                <p>To avoid interruption of your fresh produce deliveries, please update your payment method as soon as possible.</p>
              </div>
              
              <h3>What happened?</h3>
              <p>The payment for your most recent delivery couldn't be processed. This could be due to:</p>
              <ul>
                <li>Expired or outdated payment method</li>
                <li>Insufficient funds</li>
                <li>Bank declined the transaction</li>
                <li>Changes to your card or billing address</li>
              </ul>
              
              <h3>How to resolve this:</h3>
              <ol>
                <li>Click the button below to update your payment method</li>
                <li>Verify your billing information is current</li>
                <li>Confirm your subscription will resume automatically</li>
              </ol>
              
              <div style="text-align: center; margin: 30px 0;">
                <a href="${Deno.env.get("SUPABASE_URL")?.replace('/rest/v1', '')}/subscriptions" class="button">
                  Update Payment Method
                </a>
              </div>
              
              <p><strong>Don't want to miss your next delivery?</strong> Update your payment method within 3 days to ensure uninterrupted service.</p>
              
              <p>If you're experiencing issues or have questions, please don't hesitate to contact our support team. We're here to help!</p>
              
              <div style="text-align: center; margin: 20px 0;">
                <a href="mailto:support@farming2door.com" class="button button-secondary">
                  Contact Support
                </a>
              </div>
            </div>
            
            <div class="footer">
              <p><strong>Farming2Door</strong> - Connecting local farms to your table</p>
              <p style="font-size: 12px; color: #6b7280;">
                This email was sent because there was an issue with your subscription payment. 
                Please address this promptly to continue receiving deliveries.
              </p>
            </div>
          </div>
        </body>
      </html>
    `;

    const emailResponse = await resend.emails.send({
      from: "Farming2Door <billing@resend.dev>",
      to: [customerEmail],
      subject: "⚠️ Payment Issue - Update Required for Your Farm Subscription",
      html: emailHtml,
    });

    console.log("Payment issue email sent successfully:", emailResponse);

    return new Response(JSON.stringify(emailResponse), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });
  } catch (error: any) {
    console.error("Error sending payment issue email:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
});