import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface Database {
  public: {
    Functions: {
      generate_order_based_recommendations: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      generate_seasonal_recommendations: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      get_trending_products: {
        Args: {
          p_limit?: number
        }
        Returns: Array<{
          product_id: string
          name: string
          price: number
          image_url: string
          farmer_name: string
          category: string
          is_organic: boolean
          order_count: number
          avg_rating: number
        }>
      }
    }
  }
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient<Database>(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        },
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    const { recommendation_type = 'all' } = await req.json().catch(() => ({}));

    console.log('Starting recommendation update process for type:', recommendation_type);

    // 1. Update order-based recommendations (frequently bought together)
    if (recommendation_type === 'all' || recommendation_type === 'order_based') {
      console.log('Updating order-based recommendations...');
      const { error: orderError } = await supabaseClient.rpc('generate_order_based_recommendations');
      if (orderError) {
        console.error('Error updating order-based recommendations:', orderError);
        throw orderError;
      }
      console.log('✅ Order-based recommendations updated');
    }

    // 2. Update seasonal recommendations
    if (recommendation_type === 'all' || recommendation_type === 'seasonal') {
      console.log('Updating seasonal recommendations...');
      const { error: seasonalError } = await supabaseClient.rpc('generate_seasonal_recommendations');
      if (seasonalError) {
        console.error('Error updating seasonal recommendations:', seasonalError);
        throw seasonalError;
      }
      console.log('✅ Seasonal recommendations updated');
    }

    // 3. Update trending products cache
    if (recommendation_type === 'all' || recommendation_type === 'trending') {
      console.log('Fetching trending products...');
      const { data: trendingProducts, error: trendingError } = await supabaseClient
        .rpc('get_trending_products') as { data: any[] | null, error: any };
        
      if (trendingError) {
        console.error('Error fetching trending products:', trendingError);
        throw trendingError;
      }
      
      console.log(`✅ Found ${trendingProducts?.length || 0} trending products`);
    }

    // 4. Clean up old recommendations (older than 30 days)
    if (recommendation_type === 'all' || recommendation_type === 'cleanup') {
      console.log('Cleaning up old recommendations...');
      const { error: cleanupError } = await supabaseClient
        .from('product_recommendations')
        .delete()
        .lt('created_at', new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString());
        
      if (cleanupError) {
        console.error('Error cleaning up old recommendations:', cleanupError);
        // Don't throw - cleanup failures shouldn't break the process
      } else {
        console.log('✅ Old recommendations cleaned up');
      }
    }

    console.log('Recommendation update process completed successfully');

    return new Response(JSON.stringify({
      success: true,
      message: 'Recommendations updated successfully',
      type: recommendation_type,
      timestamp: new Date().toISOString()
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (err) {
    console.error('Error in update-recommendations function:', err);
    const message = (err as Error)?.message ?? 'Unknown error';
    return new Response(JSON.stringify({
      success: false,
      error: message,
      timestamp: new Date().toISOString()
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});