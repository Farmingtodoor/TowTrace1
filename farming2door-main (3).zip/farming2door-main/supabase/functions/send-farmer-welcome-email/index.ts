import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { Resend } from 'https://esm.sh/resend@2.0.0'
import React from 'https://esm.sh/react@18.3.1'
import { renderAsync } from 'https://esm.sh/@react-email/components@0.0.22'
import { FarmerWelcomeEmail } from './_templates/farmer-welcome-email.tsx'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

const resend = new Resend(Deno.env.get('RESEND_API_KEY') as string)

interface WelcomeEmailRequest {
  farmer_name: string
  farmer_email: string
  farm_name: string
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const { farmer_name, farmer_email, farm_name }: WelcomeEmailRequest = await req.json()

    console.log(`Sending welcome email to farmer: ${farmer_email}`)

    const html = await renderAsync(
      React.createElement(FarmerWelcomeEmail, {
        farmer_name,
        farm_name,
        app_url: 'https://yourapp.com' // Replace with actual app URL
      })
    )

    const { error } = await resend.emails.send({
      from: Deno.env.get('FROM_EMAIL') || 'Farm2Door <onboarding@resend.dev>',
      to: [farmer_email],
      subject: 'Welcome to Farm2Door - Your Application is Approved!',
      html,
    })
    
    if (error) {
      throw error
    }

    console.log(`Welcome email sent successfully to: ${farmer_email}`)

    return new Response(
      JSON.stringify({ success: true, message: 'Welcome email sent successfully' }),
      {
        status: 200,
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders,
        },
      }
    )
  } catch (error: any) {
    console.error('Error in send-farmer-welcome-email function:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { 'Content-Type': 'application/json', ...corsHeaders },
      }
    )
  }
}

serve(handler)