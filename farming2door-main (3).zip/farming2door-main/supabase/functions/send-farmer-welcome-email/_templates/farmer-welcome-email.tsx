import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Link,
  Preview,
  Section,
  Text,
  Hr,
  Button,
} from 'https://esm.sh/@react-email/components@0.0.22'
import * as React from 'https://esm.sh/react@18.3.1'

interface FarmerWelcomeEmailProps {
  farmer_name: string
  farm_name: string
  app_url?: string
}

export const FarmerWelcomeEmail = ({
  farmer_name,
  farm_name,
  app_url = 'https://c2f2638b-64d5-4701-ac89-48a04d6451b0.lovableproject.com',
}: FarmerWelcomeEmailProps) => (
  <Html>
    <Head />
    <Preview>Welcome to Farming2Door - Your Application is Approved! 🌾</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <Text style={headerText}>Welcome to the Farming2Door Family!</Text>
        </Section>
        
        <Section style={content}>
          <Text style={greeting}>Hi {farmer_name},</Text>
          
          <Heading style={h2}>🎉 Congratulations! Your Application is Approved</Heading>
          
          <Text style={text}>
            We're thrilled to welcome <strong>{farm_name}</strong> to the Farming2Door marketplace! 
            Your application has been approved and you can now start selling your fresh produce directly to local customers.
          </Text>
          
          <Section style={actionSection}>
            <Text style={actionText}>Ready to get started?</Text>
            <Button style={button} href={`${app_url}/farmer-onboarding`}>
              Complete Your Profile
            </Button>
          </Section>
          
          <Section style={stepsSection}>
            <Heading style={h3}>Next Steps:</Heading>
            <Text style={stepText}>1. ✅ Complete your farmer profile</Text>
            <Text style={stepText}>2. 📸 Add photos of your farm and products</Text>
            <Text style={stepText}>3. 🌱 List your first products</Text>
            <Text style={stepText}>4. 🚚 Set up your delivery preferences</Text>
          </Section>
          
          <Hr style={hr} />
          
          <Section style={supportSection}>
            <Heading style={h3}>Need Help?</Heading>
            <Text style={supportText}>
              Our team is here to help you succeed! If you have any questions about setting up your profile 
              or listing products, don't hesitate to reach out.
            </Text>
            <Button style={supportButton} href={`${app_url}/support`}>
              Contact Support
            </Button>
          </Section>
          
          <Text style={footerMessage}>
            🌱 Welcome to the family,<br/>
            The Farming2Door Team
          </Text>
        </Section>
        
        <Section style={footer}>
          <Text style={footerBrand}>
            From Our Farms to Your Table – Always Fresh.
          </Text>
        </Section>
      </Container>
    </Body>
  </Html>
)

export default FarmerWelcomeEmail

const main = {
  backgroundColor: '#ffffff',
  fontFamily: 'Poppins, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
}

const container = {
  margin: '0 auto',
  padding: '0',
  maxWidth: '600px',
}

const header = {
  backgroundColor: '#4CAF50',
  padding: '24px',
  textAlign: 'center' as const,
}

const headerText = {
  color: '#ffffff',
  fontSize: '24px',
  fontWeight: 'bold',
  margin: '0',
}

const content = {
  padding: '32px 40px',
  backgroundColor: '#ffffff',
}

const greeting = {
  color: '#333333',
  fontSize: '18px',
  fontWeight: '600',
  margin: '0 0 16px 0',
}

const h2 = {
  color: '#333333',
  fontSize: '20px',
  fontWeight: 'bold',
  margin: '24px 0 16px 0',
}

const h3 = {
  color: '#333333',
  fontSize: '18px',
  fontWeight: '600',
  margin: '24px 0 12px 0',
}

const text = {
  color: '#555555',
  fontSize: '16px',
  lineHeight: '1.6',
  margin: '16px 0 24px 0',
}

const actionSection = {
  backgroundColor: '#f8f9fa',
  borderRadius: '12px',
  padding: '24px',
  margin: '24px 0',
  textAlign: 'center' as const,
}

const actionText = {
  color: '#333333',
  fontSize: '16px',
  margin: '0 0 16px 0',
  fontWeight: '600',
}

const button = {
  backgroundColor: '#4CAF50',
  borderRadius: '25px',
  color: '#ffffff',
  fontSize: '16px',
  fontWeight: 'bold',
  textDecoration: 'none',
  padding: '14px 28px',
  display: 'inline-block',
}

const stepsSection = {
  margin: '32px 0',
}

const stepText = {
  color: '#555555',
  fontSize: '16px',
  lineHeight: '1.8',
  margin: '8px 0',
}

const hr = {
  borderColor: '#e5e7eb',
  margin: '32px 0',
}

const supportSection = {
  margin: '32px 0',
}

const supportText = {
  color: '#555555',
  fontSize: '16px',
  lineHeight: '1.6',
  margin: '12px 0 20px 0',
}

const supportButton = {
  backgroundColor: '#6B4F2A',
  borderRadius: '25px',
  color: '#ffffff',
  fontSize: '16px',
  fontWeight: 'bold',
  textDecoration: 'none',
  padding: '12px 24px',
  display: 'inline-block',
}

const footerMessage = {
  color: '#666666',
  fontSize: '16px',
  lineHeight: '1.6',
  margin: '40px 0 24px 0',
  textAlign: 'center' as const,
}

const footer = {
  backgroundColor: '#6B4F2A',
  padding: '24px',
  textAlign: 'center' as const,
}

const footerBrand = {
  color: '#ffffff',
  fontSize: '16px',
  fontWeight: '600',
  margin: '0',
}