import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Link,
  Preview,
  Text,
  Section,
  Img,
} from 'https://esm.sh/@react-email/components@0.0.22'
import * as React from 'https://esm.sh/react@18.3.1'

interface WelcomeEmailProps {
  supabase_url: string
  email_action_type: string
  redirect_to: string
  token_hash: string
  token: string
  user_email: string
}

export const WelcomeEmail = ({
  token,
  supabase_url,
  email_action_type,
  redirect_to,
  token_hash,
  user_email,
}: WelcomeEmailProps) => (
  <Html>
    <Head />
    <Preview>Welcome to Farming2Door – Fresh from Farm to You 🌾</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <Text style={headerText}>Welcome to the Farming2Door Family!</Text>
        </Section>
        
        <Section style={logoSection}>
          <Img
            src="https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=200&h=80&fit=crop&crop=center"
            alt="Farming2Door Logo"
            style={logo}
          />
        </Section>
        
        <Section style={content}>
          <Text style={greeting}>Hi there,</Text>
          
          <Text style={text}>
            You're officially part of a community that believes in fresh, local, and healthy produce delivered straight to your door.
          </Text>
          
          <Section style={confirmSection}>
            <Link
              href={`${supabase_url}/auth/v1/verify?token=${token_hash}&type=${email_action_type}&redirect_to=${redirect_to}`}
              target="_blank"
              style={button}
            >
              Start Exploring Today
            </Link>
          </Section>
          
          <Text style={codeText}>
            Or copy and paste this verification code if the button doesn't work:
          </Text>
          <code style={code}>{token}</code>
          
          <Section style={benefitsSection}>
            <Text style={bulletText}>🛒 Fresh produce directly from local farms</Text>
            <Text style={bulletText}>🚚 Convenient doorstep delivery</Text>
            <Text style={bulletText}>🌱 Support sustainable farming practices</Text>
            <Text style={bulletText}>👨‍🌾 Connect with your local farming community</Text>
          </Section>
        </Section>
        
        <Section style={footer}>
          <Text style={footerBrand}>
            From Our Farms to Your Table – Always Fresh.
          </Text>
        </Section>
      </Container>
    </Body>
  </Html>
)

export default WelcomeEmail

const main = {
  backgroundColor: '#ffffff',
  fontFamily: 'Poppins, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
}

const container = {
  margin: '0 auto',
  padding: '0',
  maxWidth: '600px',
}

const header = {
  backgroundColor: '#4CAF50',
  padding: '24px',
  textAlign: 'center' as const,
}

const headerText = {
  color: '#ffffff',
  fontSize: '24px',
  fontWeight: 'bold',
  margin: '0',
}

const logoSection = {
  textAlign: 'center' as const,
  padding: '20px 0',
  backgroundColor: '#ffffff',
}

const logo = {
  width: '120px',
  height: '48px',
  borderRadius: '8px',
}

const content = {
  padding: '0 40px 32px 40px',
  backgroundColor: '#ffffff',
}

const greeting = {
  color: '#333333',
  fontSize: '18px',
  fontWeight: '600',
  margin: '24px 0 16px 0',
}

const text = {
  color: '#333333',
  fontSize: '16px',
  lineHeight: '1.6',
  margin: '16px 0 24px 0',
}

const confirmSection = {
  textAlign: 'center' as const,
  margin: '32px 0',
}

const button = {
  backgroundColor: '#4CAF50',
  borderRadius: '25px',
  color: '#ffffff',
  fontSize: '16px',
  textDecoration: 'none',
  textAlign: 'center' as const,
  display: 'inline-block',
  padding: '14px 32px',
  fontWeight: '600',
}

const codeText = {
  color: '#666666',
  fontSize: '14px',
  textAlign: 'center' as const,
  margin: '24px 0 8px 0',
}

const code = {
  display: 'inline-block',
  padding: '16px',
  width: '100%',
  backgroundColor: '#f8f9fa',
  borderRadius: '8px',
  border: '1px solid #e9ecef',
  color: '#495057',
  fontSize: '14px',
  fontFamily: 'monospace',
  textAlign: 'center' as const,
  margin: '8px 0 32px 0',
}

const benefitsSection = {
  backgroundColor: '#f8f9fa',
  borderRadius: '12px',
  padding: '24px',
  margin: '32px 0',
}

const bulletText = {
  color: '#333333',
  fontSize: '16px',
  lineHeight: '1.6',
  margin: '12px 0',
}

const footer = {
  backgroundColor: '#6B4F2A',
  padding: '24px',
  textAlign: 'center' as const,
}

const footerBrand = {
  color: '#ffffff',
  fontSize: '16px',
  fontWeight: '600',
  margin: '0',
}