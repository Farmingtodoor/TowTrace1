import React from 'https://esm.sh/react@18.3.1'
import { Webhook } from 'https://esm.sh/standardwebhooks@1.0.0'
import { Resend } from 'https://esm.sh/resend@2.0.0'
import { renderAsync } from 'https://esm.sh/@react-email/components@0.0.22'
import { WelcomeEmail } from './_templates/welcome-email.tsx'

const resend = new Resend(Deno.env.get('RESEND_API_KEY') as string)
const hookSecret = Deno.env.get('SEND_EMAIL_HOOK_SECRET') as string

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return new Response('not allowed', { status: 400 })
  }

  // Enforce signature verification - fail closed if secret is missing
  if (!hookSecret) {
    console.error('SEND_EMAIL_HOOK_SECRET not configured - rejecting request')
    return new Response(
      JSON.stringify({
        error: {
          http_code: 500,
          message: 'Server configuration error',
        },
      }),
      {
        status: 500,
        headers: { 'Content-Type': 'application/json' },
      }
    )
  }

  const payload = await req.text()
  const headers = Object.fromEntries(req.headers)
  const wh = new Webhook(hookSecret)
  try {
    const { user, email_data } = wh.verify(payload, headers) as {
      user: {
        email: string
        user_metadata: {
          full_name?: string
        }
      }
      email_data: {
        token: string
        token_hash: string
        redirect_to: string
        email_action_type: string
        site_url: string
        token_new: string
        token_hash_new: string
      }
    }

    const html = await renderAsync(
      React.createElement(WelcomeEmail, {
        supabase_url: Deno.env.get('SUPABASE_URL') ?? '',
        token: email_data.token,
        token_hash: email_data.token_hash,
        redirect_to: email_data.redirect_to,
        email_action_type: email_data.email_action_type,
        user_email: user.email,
      })
    )

    const { error } = await resend.emails.send({
      from: Deno.env.get('FROM_EMAIL') || 'Farm2Door <onboarding@resend.dev>',
      to: [user.email],
      subject: 'Welcome to Farm2Door!',
      html,
    })
    
    if (error) {
      throw error
    }
  } catch (error) {
    console.log(error)
    return new Response(
      JSON.stringify({
        error: {
          http_code: (error as any)?.code ?? 500,
          message: (error as Error)?.message ?? 'Unknown error',
        },
      }),
      {
        status: 401,
        headers: { 'Content-Type': 'application/json' },
      }
    )
  }

  const responseHeaders = new Headers()
  responseHeaders.set('Content-Type', 'application/json')
  return new Response(JSON.stringify({}), {
    status: 200,
    headers: responseHeaders,
  })
})