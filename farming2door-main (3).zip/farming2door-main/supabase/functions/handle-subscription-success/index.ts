import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@14.21.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  // Create Supabase client with service role for writes
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
    { auth: { persistSession: false } }
  );

  try {
    console.log("Processing subscription success");

    const { sessionId } = await req.json();
    
    if (!sessionId) {
      throw new Error("Session ID is required");
    }

    // Initialize Stripe
    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
      apiVersion: "2023-10-16",
    });

    // Get checkout session details
    const session = await stripe.checkout.sessions.retrieve(sessionId, {
      expand: ['subscription', 'customer']
    });

    console.log("Retrieved session:", session.id, "Status:", session.payment_status);

    if (session.payment_status !== 'paid') {
      throw new Error("Payment not completed");
    }

    if (!session.subscription || typeof session.subscription === 'string') {
      throw new Error("No subscription found in session");
    }

    const stripeSubscription = session.subscription;
    const metadata = session.metadata || {};

    console.log("Processing subscription:", stripeSubscription.id);
    console.log("Metadata:", metadata);

    // Calculate next delivery date (start from next week/month)
    const now = new Date();
    const nextDeliveryDate = new Date();
    
    if (metadata.plan_id) {
      // Get plan details to calculate next delivery
      const { data: plan } = await supabase
        .from('subscription_plans')
        .select('interval_type, interval_count')
        .eq('id', metadata.plan_id)
        .single();
        
      if (plan) {
        if (plan.interval_type === 'weekly') {
          nextDeliveryDate.setDate(now.getDate() + (7 * plan.interval_count));
        } else if (plan.interval_type === 'monthly') {
          nextDeliveryDate.setMonth(now.getMonth() + plan.interval_count);
        }
      }
    } else {
      // Default to next week
      nextDeliveryDate.setDate(now.getDate() + 7);
    }

    // Create or update subscription record
    const subscriptionData = {
      customer_id: metadata.user_id,
      plan_id: metadata.plan_id,
      farmer_id: metadata.farmer_id,
      stripe_subscription_id: stripeSubscription.id,
      status: stripeSubscription.status,
      current_period_start: new Date(stripeSubscription.current_period_start * 1000).toISOString(),
      current_period_end: new Date(stripeSubscription.current_period_end * 1000).toISOString(),
      next_delivery_date: nextDeliveryDate.toISOString().split('T')[0], // Date only
      delivery_address: metadata.delivery_address || 'Address to be confirmed',
      special_instructions: metadata.special_instructions || null,
    };

    // Insert subscription record
    const { data: newSubscription, error: insertError } = await supabase
      .from('subscriptions')
      .insert(subscriptionData)
      .select(`
        *,
        subscription_plans (
          name,
          description,
          price,
          interval_type,
          interval_count
        )
      `)
      .single();

    if (insertError) {
      console.error("Error inserting subscription:", insertError);
      throw insertError;
    }

    console.log("Created subscription record:", newSubscription.id);

    // Create first delivery record
    const firstDeliveryDate = nextDeliveryDate.toISOString().split('T')[0];
    
    const { error: deliveryError } = await supabase
      .from('subscription_deliveries')
      .insert({
        subscription_id: newSubscription.id,
        delivery_date: firstDeliveryDate,
        status: 'scheduled',
        items: [],
        total_amount: newSubscription.subscription_plans.price
      });

    if (deliveryError) {
      console.error("Error creating delivery record:", deliveryError);
      // Don't throw here, subscription is still valid
    }

    // Send welcome email notification (async)
    try {
      await supabase.functions.invoke('send-subscription-welcome-email', {
        body: {
          subscriptionId: newSubscription.id,
          customerEmail: session.customer_email || metadata.customer_email,
          planName: newSubscription.subscription_plans.name,
          nextDeliveryDate: firstDeliveryDate
        }
      });
    } catch (emailError) {
      console.error("Error sending welcome email:", emailError);
      // Don't fail the whole process if email fails
    }

    return new Response(JSON.stringify({ 
      success: true, 
      subscription: newSubscription 
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });

  } catch (err) {
    console.error("Error in handle-subscription-success:", err);
    const message = (err as Error)?.message ?? 'Unknown error';
    return new Response(JSON.stringify({ 
      success: false, 
      error: message
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});