import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface CustomerConfirmationRequest {
  customerName: string;
  customerEmail: string;
  orderId: string;
  totalAmount: number;
  deliveryType: string;
  deliveryAddress: string;
  farmerName: string;
  items: Array<{
    name: string;
    quantity: number;
    price: number;
  }>;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const {
      customerName,
      customerEmail,
      orderId,
      totalAmount,
      deliveryType,
      deliveryAddress,
      farmerName,
      items
    }: CustomerConfirmationRequest = await req.json();

    console.log('Sending customer confirmation email to:', customerEmail);

    const orderItems = items.map(item => 
      `<tr style="border-bottom: 1px solid #e5e5e5;">
        <td style="padding: 12px; text-align: left;">${item.name}</td>
        <td style="padding: 12px; text-align: center;">${item.quantity}</td>
        <td style="padding: 12px; text-align: right;">$${item.price.toFixed(2)}</td>
        <td style="padding: 12px; text-align: right;">$${(item.price * item.quantity).toFixed(2)}</td>
      </tr>`
    ).join('');

    const orderLink = `https://njheralnbmbblwqhrncm.supabase.co/my-orders`;

    console.log('Attempting to send customer email to:', customerEmail);
    
    const emailResponse = await resend.emails.send({
      from: "Farm2Door <noreply@resend.dev>",
      to: [customerEmail],
      subject: `Order Confirmation #${orderId.slice(0, 8)} - Your Farm Fresh Order is Confirmed! 🌾`,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Order Confirmation</title>
        </head>
        <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; margin: 0; padding: 0; background-color: #f8f9fa;">
          <div style="max-width: 600px; margin: 0 auto; background-color: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            
            <!-- Header -->
            <div style="background: linear-gradient(135deg, #22c55e, #16a34a); padding: 40px 30px; text-align: center;">
              <h1 style="color: white; margin: 0; font-size: 28px; font-weight: bold;">🌾 Farm2Door</h1>
              <p style="color: rgba(255,255,255,0.9); margin: 10px 0 0 0; font-size: 16px;">Fresh from farm to your door</p>
            </div>

            <!-- Main Content -->
            <div style="padding: 40px 30px;">
              <!-- Success Message -->
              <div style="background-color: #f0fdf4; border: 2px solid #22c55e; border-radius: 8px; padding: 20px; margin-bottom: 30px; text-align: center;">
                <div style="font-size: 48px; margin-bottom: 10px;">✅</div>
                <h2 style="color: #16a34a; margin: 0 0 10px 0; font-size: 24px;">Order Confirmed!</h2>
                <p style="color: #15803d; margin: 0; font-size: 16px;">Thank you for your order, ${customerName}!</p>
              </div>

              <!-- Order Details -->
              <div style="margin-bottom: 30px;">
                <h3 style="color: #1f2937; border-bottom: 2px solid #22c55e; padding-bottom: 10px; margin: 0 0 20px 0;">Order Details</h3>
                
                <div style="background-color: #f9fafb; border-radius: 6px; padding: 20px; margin-bottom: 20px;">
                  <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                    <span style="color: #6b7280;">Order Number:</span>
                    <span style="font-weight: bold; color: #1f2937;">#${orderId.slice(0, 8)}</span>
                  </div>
                  <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                    <span style="color: #6b7280;">Farmer:</span>
                    <span style="color: #1f2937;">${farmerName}</span>
                  </div>
                  <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                    <span style="color: #6b7280;">Total Amount:</span>
                    <span style="font-weight: bold; color: #16a34a; font-size: 18px;">$${totalAmount.toFixed(2)}</span>
                  </div>
                  <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                    <span style="color: #6b7280;">Delivery Method:</span>
                    <span style="color: #1f2937;">${deliveryType === 'pickup' ? 'Farm Pickup' : 'Home Delivery'}</span>
                  </div>
                  ${deliveryType === 'delivery' && deliveryAddress ? `
                  <div style="display: flex; justify-content: space-between;">
                    <span style="color: #6b7280;">Delivery Address:</span>
                    <span style="color: #1f2937; text-align: right; max-width: 200px;">${deliveryAddress}</span>
                  </div>
                  ` : ''}
                </div>
              </div>

              <!-- Items Ordered -->
              <div style="margin-bottom: 30px;">
                <h3 style="color: #1f2937; border-bottom: 2px solid #22c55e; padding-bottom: 10px; margin: 0 0 20px 0;">Items Ordered</h3>
                
                <table style="width: 100%; border-collapse: collapse; background-color: white; border: 1px solid #e5e5e5; border-radius: 6px; overflow: hidden;">
                  <thead>
                    <tr style="background-color: #f9fafb;">
                      <th style="padding: 15px; text-align: left; color: #374151; font-weight: 600;">Item</th>
                      <th style="padding: 15px; text-align: center; color: #374151; font-weight: 600;">Qty</th>
                      <th style="padding: 15px; text-align: right; color: #374151; font-weight: 600;">Price</th>
                      <th style="padding: 15px; text-align: right; color: #374151; font-weight: 600;">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${orderItems}
                  </tbody>
                  <tfoot>
                    <tr style="background-color: #f0fdf4; font-weight: bold;">
                      <td colspan="3" style="padding: 15px; text-align: right; color: #16a34a;">Grand Total:</td>
                      <td style="padding: 15px; text-align: right; color: #16a34a; font-size: 18px;">$${totalAmount.toFixed(2)}</td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              <!-- What's Next -->
              <div style="background-color: #eff6ff; border-left: 4px solid #3b82f6; padding: 20px; margin-bottom: 30px;">
                <h3 style="color: #1e40af; margin: 0 0 15px 0; font-size: 18px;">What's Next? 📋</h3>
                <div style="color: #1e40af;">
                  <p style="margin: 8px 0;"><strong>✓ Order Confirmed:</strong> Your order has been received and confirmed</p>
                  <p style="margin: 8px 0;"><strong>🚚 Farmer Notification:</strong> ${farmerName} has been notified and will prepare your fresh produce</p>
                  <p style="margin: 8px 0;"><strong>📧 Updates:</strong> You'll receive email updates as your order status changes</p>
                  <p style="margin: 8px 0;"><strong>🎯 ${deliveryType === 'pickup' ? 'Pickup Information' : 'Delivery Updates'}:</strong> ${deliveryType === 'pickup' ? 'The farmer will contact you with pickup details and timing' : 'We\'ll notify you when your order is out for delivery'}</p>
                </div>
              </div>

              <!-- Track Order Button -->
              <div style="text-align: center; margin: 30px 0;">
                <a href="${orderLink}" style="display: inline-block; background: linear-gradient(135deg, #22c55e, #16a34a); color: white; text-decoration: none; padding: 15px 30px; border-radius: 8px; font-weight: bold; font-size: 16px;">
                  Track Your Order 📦
                </a>
              </div>

              <!-- Support -->
              <div style="border-top: 1px solid #e5e5e5; padding-top: 20px; text-align: center;">
                <p style="color: #6b7280; margin: 0 0 10px 0;">Questions about your order?</p>
                <p style="color: #6b7280; margin: 0;">Contact us or reach out to your farmer directly through our platform.</p>
              </div>
            </div>

            <!-- Footer -->
            <div style="background-color: #f9fafb; padding: 20px 30px; text-align: center; border-top: 1px solid #e5e5e5;">
              <p style="color: #6b7280; margin: 0; font-size: 14px;">
                Thank you for supporting local farmers! 🌱<br>
                <strong>Farm2Door</strong> - Fresh, Local, Sustainable
              </p>
            </div>
          </div>
        </body>
        </html>
      `,
    });

    console.log("Customer confirmation email sent successfully:", emailResponse);
    console.log('Resend response details:', emailResponse);

    return new Response(JSON.stringify({
      success: true,
      emailId: emailResponse.data?.id
    }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });

  } catch (error: any) {
    console.error("Error sending customer confirmation email:", error);
    return new Response(
      JSON.stringify({ 
        error: error.message,
        success: false 
      }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);