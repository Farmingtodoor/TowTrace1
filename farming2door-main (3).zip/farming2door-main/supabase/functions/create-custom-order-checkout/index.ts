import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@14.21.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// ============= ANTI-CARD-TESTING RATE LIMITER =============
interface RateLimitEntry {
  count: number;
  firstRequest: number;
  lastRequest: number;
}

const rateLimitStore = new Map<string, RateLimitEntry>();
const WINDOW_SIZE = 60 * 1000;
const MAX_REQUESTS_PER_WINDOW = 5;
const BLOCK_DURATION = 15 * 60 * 1000;

function getClientIP(req: Request): string {
  return req.headers.get('cf-connecting-ip') || 
         req.headers.get('x-real-ip') || 
         req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 
         'unknown';
}

function checkRateLimit(ip: string): { allowed: boolean; retryAfter?: number } {
  const now = Date.now();
  const entry = rateLimitStore.get(ip);
  
  if (!entry) {
    rateLimitStore.set(ip, { count: 1, firstRequest: now, lastRequest: now });
    return { allowed: true };
  }
  
  if (now - entry.firstRequest > WINDOW_SIZE) {
    rateLimitStore.set(ip, { count: 1, firstRequest: now, lastRequest: now });
    return { allowed: true };
  }
  
  if (entry.count >= MAX_REQUESTS_PER_WINDOW) {
    const blockEnds = entry.lastRequest + BLOCK_DURATION;
    if (now < blockEnds) {
      return { allowed: false, retryAfter: Math.ceil((blockEnds - now) / 1000) };
    }
    rateLimitStore.set(ip, { count: 1, firstRequest: now, lastRequest: now });
    return { allowed: true };
  }
  
  entry.count++;
  entry.lastRequest = now;
  return { allowed: true };
}

function detectSuspiciousRequest(req: Request): { suspicious: boolean; reason?: string } {
  const userAgent = req.headers.get('user-agent') || '';
  if (!userAgent || userAgent.length < 10) {
    return { suspicious: true, reason: 'Invalid user agent' };
  }
  const botPatterns = ['curl', 'wget', 'python-requests', 'scrapy', 'bot', 'crawler', 'postman'];
  if (botPatterns.some(p => userAgent.toLowerCase().includes(p))) {
    return { suspicious: true, reason: 'Automated request detected' };
  }
  return { suspicious: false };
}
// ============= END RATE LIMITER =============

interface CustomOrderCheckoutRequest {
  orderId: string;
  orderType: 'custom_order';
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // ====== ANTI-CARD-TESTING CHECKS ======
    const clientIP = getClientIP(req);
    console.log('[ANTI-FRAUD] Request from IP:', clientIP);
    
    const rateLimitResult = checkRateLimit(clientIP);
    if (!rateLimitResult.allowed) {
      console.log('[ANTI-FRAUD] Rate limit exceeded for IP:', clientIP);
      return new Response(JSON.stringify({ 
        error: "Too many payment attempts. Please try again later.",
        retryAfter: rateLimitResult.retryAfter 
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json", "Retry-After": String(rateLimitResult.retryAfter) },
        status: 429,
      });
    }
    
    const suspiciousCheck = detectSuspiciousRequest(req);
    if (suspiciousCheck.suspicious) {
      console.log('[ANTI-FRAUD] Suspicious request blocked:', suspiciousCheck.reason);
      return new Response(JSON.stringify({ error: "Request blocked for security reasons" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 403,
      });
    }
    // ====== END ANTI-FRAUD CHECKS ======

    const { orderId, orderType }: CustomOrderCheckoutRequest = await req.json();

    if (!orderId || orderType !== 'custom_order') {
      return new Response(JSON.stringify({ error: "Invalid request parameters" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      });
    }

    // Create Supabase client with service role for secure operations
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") || "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || ""
    );

    // Get order details
    const { data: order, error: orderError } = await supabase
      .from('custom_orders')
      .select('id, customer_id, farmer_id, estimated_total, requested_products, delivery_fee')
      .eq('id', orderId)
      .maybeSingle();

    if (orderError || !order) {
      console.error('Error fetching custom order:', orderError);
      return new Response(JSON.stringify({ error: "Order not found" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 404,
      });
    }

    // Get customer info separately
    const { data: customer, error: customerError } = await supabase
      .from('profiles')
      .select('email, full_name')
      .eq('id', order.customer_id)
      .maybeSingle();

    if (customerError || !customer) {
      console.error('Error fetching customer:', customerError);
      return new Response(JSON.stringify({ error: "Customer not found" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 404,
      });
    }

    // Calculate amount server-side from the database (security fix)
    const totalAmount = (order.estimated_total || 0) + (order.delivery_fee || 0);
    const amount = Math.round(totalAmount * 100); // Convert to cents

    // Validate that the order has a valid amount
    if (!amount || amount <= 0) {
      return new Response(JSON.stringify({ error: "Invalid order amount" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      });
    }

    const customerEmail = customer.email;
    if (!customerEmail) {
      return new Response(JSON.stringify({ error: "Customer email not found" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      });
    }

    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
      apiVersion: "2023-10-16",
    });

    // Check if a Stripe customer already exists
    const customers = await stripe.customers.list({ email: customerEmail, limit: 1 });
    let customerId;
    if (customers.data.length > 0) {
      customerId = customers.data[0].id;
    }

    // Create line items for the custom order
    const lineItems: Stripe.Checkout.SessionCreateParams.LineItem[] = [
      {
        price_data: {
          currency: "usd",
          product_data: {
            name: "Custom Order",
            description: `Custom order with ${order.requested_products?.length || 0} items`,
          },
          unit_amount: amount,
        },
        quantity: 1,
        
      }
    ];

    // Create Stripe checkout session
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      customer_email: customerId ? undefined : customerEmail,
      payment_method_types: ['card'],
      line_items: lineItems,
      mode: "payment",
      success_url: `${req.headers.get("origin")}/checkout-success?session_id={CHECKOUT_SESSION_ID}&order_type=custom&order_id=${orderId}`,
      cancel_url: `${req.headers.get("origin")}/custom-orders`,
      automatic_tax: {
        enabled: true,
      },
      metadata: {
        custom_order_id: orderId,
        order_type: 'custom_order',
      },
    });

    return new Response(JSON.stringify({ url: session.url }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });

  } catch (err) {
    console.error('Custom order checkout error:', err);
    const message = (err as Error)?.message ?? 'Unknown error';
    return new Response(JSON.stringify({ error: message }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});