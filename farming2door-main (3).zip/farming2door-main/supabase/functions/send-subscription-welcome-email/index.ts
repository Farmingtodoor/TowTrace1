import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@2.0.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface WelcomeEmailRequest {
  subscriptionId: string;
  customerEmail: string;
  planName: string;
  nextDeliveryDate: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log("Sending subscription welcome email");

    const { subscriptionId, customerEmail, planName, nextDeliveryDate }: WelcomeEmailRequest = await req.json();

    if (!customerEmail || !planName) {
      throw new Error("Missing required email parameters");
    }

    // Create Supabase client
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { persistSession: false } }
    );

    // Get additional subscription details if needed
    const { data: subscription } = await supabase
      .from('subscriptions')
      .select(`
        *,
        subscription_plans (
          name,
          description,
          price,
          interval_type,
          interval_count,
          max_items
        )
      `)
      .eq('id', subscriptionId)
      .single();

    const formatDate = (dateString: string) => {
      return new Date(dateString).toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    };

    const formatInterval = (intervalType: string, intervalCount: number) => {
      const unit = intervalCount === 1 ? intervalType.slice(0, -2) : intervalType;
      return intervalCount === 1 ? `every ${unit}` : `every ${intervalCount} ${unit}s`;
    };

    const emailHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Welcome to Your Farm Subscription!</title>
          <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 30px 20px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #ffffff; padding: 30px; border: 1px solid #e5e7eb; }
            .footer { background: #f9fafb; padding: 20px; text-align: center; border-radius: 0 0 8px 8px; }
            .highlight { background: #f0fdf4; border-left: 4px solid #10b981; padding: 15px; margin: 20px 0; }
            .button { display: inline-block; background: #10b981; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin: 15px 0; }
            .details { background: #f9fafb; padding: 20px; border-radius: 6px; margin: 20px 0; }
            .icon { width: 20px; height: 20px; vertical-align: middle; margin-right: 8px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🌿 Welcome to Your Farm Subscription!</h1>
              <p>Fresh, local produce delivered right to your door</p>
            </div>
            
            <div class="content">
              <h2>Thank you for subscribing to ${planName}!</h2>
              
              <p>We're excited to start delivering fresh, seasonal produce from local farms directly to your door. Your subscription is now active and your farmer is preparing your first delivery.</p>
              
              <div class="details">
                <h3>📦 Your Subscription Details:</h3>
                <ul>
                  <li><strong>Plan:</strong> ${planName}</li>
                  ${subscription?.subscription_plans ? `
                    <li><strong>Price:</strong> $${subscription.subscription_plans.price} ${formatInterval(subscription.subscription_plans.interval_type, subscription.subscription_plans.interval_count)}</li>
                    <li><strong>Max Items:</strong> Up to ${subscription.subscription_plans.max_items} fresh items per delivery</li>
                  ` : ''}
                  <li><strong>Next Delivery:</strong> ${formatDate(nextDeliveryDate)}</li>
                  ${subscription?.delivery_address ? `<li><strong>Delivery Address:</strong> ${subscription.delivery_address}</li>` : ''}
                </ul>
              </div>
              
              <div class="highlight">
                <h3>🚚 What to expect:</h3>
                <ul>
                  <li>Fresh, seasonal produce selected by your farmer</li>
                  <li>Delivery notifications before each shipment</li>
                  <li>Flexible subscription management (pause, modify, or cancel anytime)</li>
                  <li>Direct support from local farmers</li>
                </ul>
              </div>
              
              <p>You'll receive an email notification when your farmer prepares your delivery and another when it's out for delivery.</p>
              
              <div style="text-align: center; margin: 30px 0;">
                <a href="${Deno.env.get("SUPABASE_URL")?.replace('/rest/v1', '')}/subscriptions" class="button">
                  Manage Your Subscription
                </a>
              </div>
              
              <p>Questions about your subscription? Feel free to reach out to us or your farmer directly through our platform.</p>
            </div>
            
            <div class="footer">
              <p><strong>Farming2Door</strong> - Connecting local farms to your table</p>
              <p style="font-size: 12px; color: #6b7280;">
                This email was sent because you subscribed to a farm delivery service. 
                You can manage your subscription preferences anytime.
              </p>
            </div>
          </div>
        </body>
      </html>
    `;

    const emailResponse = await resend.emails.send({
      from: "Farming2Door <subscriptions@resend.dev>",
      to: [customerEmail],
      subject: `🌿 Welcome to ${planName} - Your Farm Subscription is Active!`,
      html: emailHtml,
    });

    console.log("Welcome email sent successfully:", emailResponse);

    return new Response(JSON.stringify(emailResponse), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });
  } catch (error: any) {
    console.error("Error sending subscription welcome email:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
});