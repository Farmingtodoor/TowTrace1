import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Link,
  Preview,
  Text,
} from 'https://esm.sh/@react-email/components@0.0.22'
import * as React from 'https://esm.sh/react@18.3.1'

interface MessageNotificationEmailProps {
  recipientName: string
  senderName: string
  messagePreview: string
  conversationUrl: string
}

export const MessageNotificationEmail = ({
  recipientName,
  senderName,
  messagePreview,
  conversationUrl,
}: MessageNotificationEmailProps) => (
  <Html>
    <Head />
    <Preview>New message from {senderName} on Farm2Door</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={h1}>New Message</Heading>
        <Text style={text}>
          Hi {recipientName},
        </Text>
        <Text style={text}>
          You have received a new message from <strong>{senderName}</strong> on Farm2Door.
        </Text>
        <div style={messagePreviewContainer}>
          <Text style={messagePreviewText}>
            "{messagePreview}..."
          </Text>
        </div>
        <Link
          href={conversationUrl}
          target="_blank"
          style={{
            ...button,
            display: 'block',
            textAlign: 'center',
          }}
        >
          View Message
        </Link>
        <Text style={text}>
          You can also log in to your Farm2Door account to view and reply to this message.
        </Text>
        <Text style={footer}>
          <Link
            href="https://c2f2638b-64d5-4701-ac89-48a04d6451b0.lovableproject.com"
            target="_blank"
            style={{ ...link, color: '#898989' }}
          >
            Farm2Door
          </Link>
          <br />
          Connecting farms directly to your door
        </Text>
      </Container>
    </Body>
  </Html>
)

export default MessageNotificationEmail

const main = {
  backgroundColor: '#ffffff',
}

const container = {
  paddingLeft: '12px',
  paddingRight: '12px',
  margin: '0 auto',
}

const h1 = {
  color: '#2D5016',
  fontFamily:
    "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif",
  fontSize: '24px',
  fontWeight: 'bold',
  margin: '40px 0',
  padding: '0',
}

const button = {
  backgroundColor: '#2D5016',
  borderRadius: '8px',
  color: '#ffffff',
  fontSize: '16px',
  fontWeight: 'bold',
  textDecoration: 'none',
  textAlign: 'center' as const,
  display: 'block',
  padding: '12px 24px',
  margin: '24px 0',
}

const link = {
  color: '#2D5016',
  fontFamily:
    "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif",
  fontSize: '14px',
  textDecoration: 'underline',
}

const text = {
  color: '#333',
  fontFamily:
    "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif",
  fontSize: '14px',
  margin: '24px 0',
}

const messagePreviewContainer = {
  backgroundColor: '#f8f9fa',
  border: '1px solid #e9ecef',
  borderRadius: '8px',
  padding: '16px',
  margin: '16px 0',
}

const messagePreviewText = {
  color: '#495057',
  fontFamily:
    "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif",
  fontSize: '14px',
  fontStyle: 'italic',
  margin: '0',
}

const footer = {
  color: '#898989',
  fontFamily:
    "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif",
  fontSize: '12px',
  lineHeight: '22px',
  marginTop: '12px',
  marginBottom: '24px',
}