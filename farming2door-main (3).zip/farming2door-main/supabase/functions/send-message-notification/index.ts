import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@2.0.0";
import { renderAsync } from 'https://esm.sh/@react-email/components@0.0.22';
import React from 'https://esm.sh/react@18.3.1';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.0';
import { MessageNotificationEmail } from './_templates/message-notification-email.tsx';

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface MessageNotificationRequest {
  recipient_id: string;
  sender_name: string;
  message_preview: string;
  conversation_id: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    
    const {
      recipient_id,
      sender_name,
      message_preview,
      conversation_id,
    }: MessageNotificationRequest = await req.json();

    console.log('Sending message notification:', {
      recipient_id,
      sender_name,
      message_preview: message_preview.substring(0, 50),
      conversation_id,
    });

    // Get recipient profile
    const { data: recipientProfile, error: profileError } = await supabase
      .from('profiles')
      .select('email, full_name')
      .eq('id', recipient_id)
      .single();

    if (profileError || !recipientProfile) {
      console.error('Error fetching recipient profile:', profileError);
      throw new Error('Could not find recipient profile');
    }

    const recipientName = recipientProfile.full_name || recipientProfile.email;
    const recipientEmail = recipientProfile.email;

    // Create conversation URL
    const conversationUrl = `https://c2f2638b-64d5-4701-ac89-48a04d6451b0.lovableproject.com/messages?conversation=${conversation_id}`;

    // Render email template
    const html = await renderAsync(
      React.createElement(MessageNotificationEmail, {
        recipientName,
        senderName: sender_name,
        messagePreview: message_preview,
        conversationUrl,
      })
    );

    // Send email
    const emailResponse = await resend.emails.send({
      from: "Farm2Door <notifications@resend.dev>",
      to: [recipientEmail],
      subject: `New message from ${sender_name} on Farm2Door`,
      html,
    });

    console.log("Message notification email sent successfully:", emailResponse);

    return new Response(JSON.stringify({ success: true, emailResponse }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });
  } catch (error: any) {
    console.error("Error in send-message-notification function:", error);
    return new Response(
      JSON.stringify({ 
        error: error.message,
        success: false 
      }),
      {
        status: 500,
        headers: { 
          "Content-Type": "application/json", 
          ...corsHeaders 
        },
      }
    );
  }
};

serve(handler);