import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.0";
import Stripe from "https://esm.sh/stripe@14.21.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SITE_URL = Deno.env.get("SITE_URL") || "https://farming2door.com";

const admin = createClient(
  Deno.env.get("SUPABASE_URL") ?? "",
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
);

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey) return json({ error: "Payouts are not configured yet." }, 500);
    const stripe = new Stripe(stripeKey, { apiVersion: "2023-10-16" });

    // --- Auth: farmer must be signed in ---
    const authHeader = req.headers.get("Authorization") ?? "";
    const token = authHeader.replace("Bearer ", "");
    if (!token) return json({ error: "Unauthorized" }, 401);

    const { data: userData, error: userError } = await admin.auth.getUser(token);
    const user = userData?.user;
    if (userError || !user) return json({ error: "Unauthorized" }, 401);

    const body = await req.json().catch(() => ({}));
    const action = body?.action === "onboard" ? "onboard" : "status";

    // --- Only approved (verified) farms may connect a bank account ---
    const { data: approvedApp } = await admin
      .from("farmer_applications")
      .select("id")
      .eq("user_id", user.id)
      .eq("status", "approved")
      .limit(1)
      .maybeSingle();

    const isApprovedFarmer = !!approvedApp;
    if (!isApprovedFarmer) {
      return json(
        {
          error: "FARM_NOT_VERIFIED",
          message:
            "Bank connection is available once your farm is approved. Finish onboarding and wait for verification.",
          connected: false,
          payouts_enabled: false,
          details_submitted: false,
          farm_verified: false,
        },
        403,
      );
    }


    // --- Load or create the connected account ---
    const { data: existing } = await admin
      .from("farmer_payout_accounts")
      .select("*")
      .eq("farmer_id", user.id)
      .maybeSingle();

    let accountId = existing?.stripe_account_id as string | undefined;

    if (!accountId) {
      if (action !== "onboard") {
        return json({ connected: false, payouts_enabled: false, details_submitted: false, farm_verified: true });
      }
      const account = await stripe.accounts.create({
        type: "express",
        email: user.email ?? undefined,
        business_type: "individual",
        capabilities: { transfers: { requested: true } },
        metadata: { farmer_id: user.id },
      });
      accountId = account.id;
      await admin.from("farmer_payout_accounts").insert({
        farmer_id: user.id,
        stripe_account_id: accountId,
        country: account.country ?? null,
      });
    }

    // --- Sync latest verification state from Stripe ---
    const account = await stripe.accounts.retrieve(accountId);
    const externalAccount = (account.external_accounts?.data?.[0] ?? null) as
      | { last4?: string; bank_name?: string }
      | null;

    const state = {
      charges_enabled: !!account.charges_enabled,
      payouts_enabled: !!account.payouts_enabled,
      details_submitted: !!account.details_submitted,
      requirements_due: account.requirements?.currently_due ?? [],
      bank_last4: externalAccount?.last4 ?? null,
      bank_name: externalAccount?.bank_name ?? null,
      country: account.country ?? null,
    };

    await admin.from("farmer_payout_accounts").update(state).eq("stripe_account_id", accountId);

    if (action === "onboard") {
      const link = await stripe.accountLinks.create({
        account: accountId,
        refresh_url: `${SITE_URL}/farmer-payouts?connect=refresh`,
        return_url: `${SITE_URL}/farmer-payouts?connect=done`,
        type: "account_onboarding",
      });
      return json({ connected: true, farm_verified: true, url: link.url, ...state });
    }

    return json({ connected: true, farm_verified: true, ...state });
  } catch (error) {
    console.error("farmer-payout-account error:", error instanceof Error ? error.message : error);
    return json({ error: "Could not load your payout account." }, 500);
  }
});
