import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@14.21.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// ============= ANTI-CARD-TESTING RATE LIMITER =============
interface RateLimitEntry {
  count: number;
  firstRequest: number;
  lastRequest: number;
}

const rateLimitStore = new Map<string, RateLimitEntry>();
const WINDOW_SIZE = 60 * 1000;
const MAX_REQUESTS_PER_WINDOW = 5;
const BLOCK_DURATION = 15 * 60 * 1000;

function getClientIP(req: Request): string {
  return req.headers.get('cf-connecting-ip') || 
         req.headers.get('x-real-ip') || 
         req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 
         'unknown';
}

function checkRateLimit(ip: string): { allowed: boolean; retryAfter?: number } {
  const now = Date.now();
  const entry = rateLimitStore.get(ip);
  
  if (!entry) {
    rateLimitStore.set(ip, { count: 1, firstRequest: now, lastRequest: now });
    return { allowed: true };
  }
  
  if (now - entry.firstRequest > WINDOW_SIZE) {
    rateLimitStore.set(ip, { count: 1, firstRequest: now, lastRequest: now });
    return { allowed: true };
  }
  
  if (entry.count >= MAX_REQUESTS_PER_WINDOW) {
    const blockEnds = entry.lastRequest + BLOCK_DURATION;
    if (now < blockEnds) {
      return { allowed: false, retryAfter: Math.ceil((blockEnds - now) / 1000) };
    }
    rateLimitStore.set(ip, { count: 1, firstRequest: now, lastRequest: now });
    return { allowed: true };
  }
  
  entry.count++;
  entry.lastRequest = now;
  return { allowed: true };
}

function detectSuspiciousRequest(req: Request): { suspicious: boolean; reason?: string } {
  const userAgent = req.headers.get('user-agent') || '';
  if (!userAgent || userAgent.length < 10) {
    return { suspicious: true, reason: 'Invalid user agent' };
  }
  const botPatterns = ['curl', 'wget', 'python-requests', 'scrapy', 'bot', 'crawler', 'postman'];
  if (botPatterns.some(p => userAgent.toLowerCase().includes(p))) {
    return { suspicious: true, reason: 'Automated request detected' };
  }
  return { suspicious: false };
}
// ============= END RATE LIMITER =============

const logStep = (step: string, details?: any) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[PURCHASE-FEATURED-SERVICE] ${step}${detailsStr}`);
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseClient = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
    { auth: { persistSession: false } }
  );

  try {
    logStep("Function started");

    // ====== ANTI-CARD-TESTING CHECKS ======
    const clientIP = getClientIP(req);
    logStep("Request from IP", { ip: clientIP });
    
    const rateLimitResult = checkRateLimit(clientIP);
    if (!rateLimitResult.allowed) {
      logStep("Rate limit exceeded", { ip: clientIP });
      return new Response(JSON.stringify({ 
        error: "Too many payment attempts. Please try again later.",
        retryAfter: rateLimitResult.retryAfter 
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json", "Retry-After": String(rateLimitResult.retryAfter) },
        status: 429,
      });
    }
    
    const suspiciousCheck = detectSuspiciousRequest(req);
    if (suspiciousCheck.suspicious) {
      logStep("Suspicious request blocked", { reason: suspiciousCheck.reason });
      return new Response(JSON.stringify({ error: "Request blocked for security reasons" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 403,
      });
    }
    // ====== END ANTI-FRAUD CHECKS ======

    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey) throw new Error("STRIPE_SECRET_KEY is not set");
    
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("No authorization header provided");

    const token = authHeader.replace("Bearer ", "");
    const { data: userData, error: userError } = await supabaseClient.auth.getUser(token);
    if (userError) throw new Error(`Authentication error: ${userError.message}`);
    
    const user = userData.user;
    if (!user?.email) throw new Error("User not authenticated or email not available");
    logStep("User authenticated", { userId: user.id, email: user.email });

    // Parse request body
    const body = await req.json();
    const { serviceId, itemId } = body;
    
    if (!serviceId) throw new Error("Service ID is required");
    logStep("Request data", { serviceId, itemId });

    // Get service details
    const { data: service, error: serviceError } = await supabaseClient
      .from('featured_services')
      .select('*')
      .eq('id', serviceId)
      .eq('is_active', true)
      .single();

    if (serviceError || !service) {
      throw new Error("Featured service not found or inactive");
    }
    logStep("Service found", service);

    // Validate farmer status
    const { data: farmerApp } = await supabaseClient
      .from('farmer_applications')
      .select('status')
      .eq('user_id', user.id)
      .single();

    if (!farmerApp || farmerApp.status !== 'approved') {
      throw new Error("Only approved farmers can purchase featured services");
    }
    logStep("Farmer validated");

    // If it's a product feature, validate the product belongs to the farmer
    if (service.feature_type === 'product' && itemId) {
      const { data: product } = await supabaseClient
        .from('products')
        .select('farmer_id')
        .eq('id', itemId)
        .single();

      if (!product || product.farmer_id !== user.id) {
        throw new Error("Product not found or doesn't belong to you");
      }
      logStep("Product validated");
    }

    // Initialize Stripe
    const stripe = new Stripe(stripeKey, { apiVersion: "2023-10-16" });

    // Check if customer exists
    const customers = await stripe.customers.list({ email: user.email, limit: 1 });
    let customerId;
    if (customers.data.length > 0) {
      customerId = customers.data[0].id;
    }

    // Calculate expiration date
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + service.duration_days);

    // Create Stripe checkout session
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      customer_email: customerId ? undefined : user.email,
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: { 
              name: service.name,
              description: service.description 
            },
            unit_amount: Math.round(service.price * 100), // Convert to cents
          },
          quantity: 1,
        },
      ],
      mode: "payment",
      success_url: `${req.headers.get("origin")}/farmer-promotions?success=true`,
      cancel_url: `${req.headers.get("origin")}/farmer-promotions?cancelled=true`,
      metadata: {
        serviceId: serviceId,
        farmerId: user.id,
        itemId: itemId || "",
        expiresAt: expiresAt.toISOString(),
      }
    });

    // Create pending purchase record
    const { error: purchaseError } = await supabaseClient
      .from('featured_purchases')
      .insert({
        farmer_id: user.id,
        service_id: serviceId,
        item_id: itemId,
        stripe_session_id: session.id,
        amount: service.price,
        status: 'pending',
        expires_at: expiresAt.toISOString(),
      });

    if (purchaseError) {
      logStep("Error creating purchase record", purchaseError);
      throw new Error("Failed to create purchase record");
    }

    logStep("Checkout session created", { sessionId: session.id });

    return new Response(JSON.stringify({ url: session.url }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    logStep("ERROR", { message: errorMessage });
    return new Response(JSON.stringify({ error: errorMessage }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});