import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface NotifyDriversRequest {
  orderId: string;
  farmLatitude: number;
  farmLongitude: number;
  customerLatitude?: number;
  customerLongitude?: number;
  deliveryAddress: string;
  orderTotal: number;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Authenticate the caller
    const authHeader = req.headers.get('Authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const supabaseAuth = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: claimsData, error: claimsError } = await supabaseAuth.auth.getClaims(
      authHeader.replace('Bearer ', '')
    );
    if (claimsError || !claimsData?.claims) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }
    const userId = claimsData.claims.sub;

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { 
      orderId, farmLatitude, farmLongitude, 
      customerLatitude, customerLongitude, deliveryAddress, orderTotal 
    }: NotifyDriversRequest = await req.json();

    // Verify the caller owns or is the farmer for this order
    const { data: order, error: orderError } = await supabase
      .from('orders')
      .select('customer_id, farmer_id')
      .eq('id', orderId)
      .single();

    if (orderError || !order) {
      return new Response(JSON.stringify({ success: false, error: 'Order not found' }), {
        status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    if (order.customer_id !== userId && order.farmer_id !== userId) {
      return new Response(JSON.stringify({ success: false, error: 'Forbidden' }), {
        status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const { data: nearbyDrivers, error: driversError } = await supabase
      .rpc('find_nearby_drivers', {
        farm_lat: farmLatitude,
        farm_lng: farmLongitude,
        radius_km: 10
      });

    if (driversError) {
      throw new Error(`Failed to find nearby drivers: ${driversError.message}`);
    }

    if (!nearbyDrivers || nearbyDrivers.length === 0) {
      return new Response(
        JSON.stringify({ success: false, message: 'No drivers available in the area', driversFound: 0 }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    let deliveryFee = 0;
    if (customerLatitude && customerLongitude) {
      const { data: feeData, error: feeError } = await supabase
        .rpc('calculate_delivery_fee', {
          farm_lat: farmLatitude, farm_lng: farmLongitude,
          customer_lat: customerLatitude, customer_lng: customerLongitude
        });
      if (!feeError && feeData) deliveryFee = feeData;
    }

    const driverEarnings = Math.max(deliveryFee * 0.7, 3.00);
    const closestDriver = nearbyDrivers[0];
    
    const { error: assignmentError } = await supabase
      .from('driver_order_assignments')
      .insert({
        order_id: orderId, driver_id: closestDriver.driver_id,
        driver_earnings: driverEarnings, status: 'assigned'
      });

    if (assignmentError) {
      throw new Error(`Failed to assign driver: ${assignmentError.message}`);
    }

    await supabase.from('notifications').insert({
      user_id: closestDriver.driver_id, type: 'new_delivery',
      title: 'New Delivery Assignment',
      message: `You have been assigned a new delivery to ${deliveryAddress}. Earnings: $${driverEarnings.toFixed(2)}`,
      order_id: orderId
    });

    const backupDrivers = nearbyDrivers.slice(1, 4);
    for (const driver of backupDrivers) {
      await supabase.from('notifications').insert({
        user_id: driver.driver_id, type: 'delivery_available',
        title: 'Delivery Available Nearby',
        message: `A delivery is available ${driver.distance_km.toFixed(1)}km away. Potential earnings: $${driverEarnings.toFixed(2)}`,
        order_id: orderId
      });
    }

    await supabase.from('orders').update({
      delivery_fee: deliveryFee, pickup_latitude: farmLatitude, pickup_longitude: farmLongitude,
      delivery_latitude: customerLatitude, delivery_longitude: customerLongitude, status: 'assigned_driver'
    }).eq('id', orderId);

    return new Response(
      JSON.stringify({ 
        success: true, 
        assignedDriver: {
          id: closestDriver.driver_id, name: closestDriver.driver_name,
          vehicle: closestDriver.vehicle_type, rating: closestDriver.rating,
          distance: closestDriver.distance_km
        },
        deliveryFee, driverEarnings,
        backupDriversNotified: backupDrivers.length, totalDriversFound: nearbyDrivers.length
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error: any) {
    console.error('Error in notify-nearby-drivers function:', error);
    return new Response(
      JSON.stringify({ success: false, error: 'An internal error occurred' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
};

serve(handler);
