import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const supabase = createClient(
  Deno.env.get("SUPABASE_URL") ?? "",
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
);

type ReminderType = "pickup_24h" | "pickup_2h";

const formatWindow = (startIso: string, endIso: string | null) => {
  const start = new Date(startIso);
  const date = start.toLocaleDateString("en-US", {
    weekday: "long",
    month: "short",
    day: "numeric",
  });
  const time = start.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
  if (!endIso) return `${date} at ${time}`;
  const endTime = new Date(endIso).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
  });
  return `${date}, ${time} – ${endTime}`;
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const now = Date.now();
    const in24h = new Date(now + 24 * 60 * 60 * 1000).toISOString();
    const nowIso = new Date(now).toISOString();

    // All upcoming scheduled pickups within the next 24 hours
    const { data: orders, error } = await supabase
      .from("orders")
      .select("id, customer_id, farmer_id, status, pickup_scheduled_at, pickup_scheduled_end")
      .not("pickup_scheduled_at", "is", null)
      .gt("pickup_scheduled_at", nowIso)
      .lte("pickup_scheduled_at", in24h)
      .not("status", "in", "(cancelled,rejected,delivered,completed)");

    if (error) throw error;

    let sent = 0;

    for (const order of orders ?? []) {
      const startsAt = new Date(order.pickup_scheduled_at as string).getTime();
      const hoursAway = (startsAt - now) / (60 * 60 * 1000);
      const reminderType: ReminderType = hoursAway <= 2 ? "pickup_2h" : "pickup_24h";

      // Idempotency: unique(order_id, reminder_type)
      const { error: claimError } = await supabase
        .from("pickup_reminders")
        .insert({ order_id: order.id, reminder_type: reminderType });

      if (claimError) continue; // already sent (or transient) — skip

      const windowLabel = formatWindow(
        order.pickup_scheduled_at as string,
        (order.pickup_scheduled_end as string) ?? null,
      );
      const when = reminderType === "pickup_2h" ? "in about 2 hours" : "tomorrow";

      const payloads = [
        {
          user_id: order.customer_id,
          type: reminderType,
          title: `Pickup reminder — ${when}`,
          message: `Your farm pickup is scheduled for ${windowLabel}. Please arrive within your selected window.`,
          order_id: order.id,
        },
        {
          user_id: order.farmer_id,
          type: reminderType,
          title: `Customer pickup ${when}`,
          message: `A customer is scheduled to pick up their order ${windowLabel}. Please have it ready.`,
          order_id: order.id,
        },
      ];

      const { error: notifyError } = await supabase.from("notifications").insert(payloads);
      if (notifyError) {
        console.error("Failed to insert notifications", notifyError.message);
        continue;
      }

      for (const notification of payloads) {
        try {
          await supabase.functions.invoke("send-notification-email", {
            body: { notification },
          });
        } catch (e) {
          console.error("Reminder email failed", e instanceof Error ? e.message : e);
        }
      }

      sent += 1;
    }

    return new Response(JSON.stringify({ processed: orders?.length ?? 0, reminders_sent: sent }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("send-pickup-reminders error", e instanceof Error ? e.message : e);
    return new Response(JSON.stringify({ error: "Failed to send pickup reminders" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
