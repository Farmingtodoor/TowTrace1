import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@14.21.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
  apiVersion: "2023-10-16",
});

const supabase = createClient(
  Deno.env.get("SUPABASE_URL") ?? "",
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
  { auth: { persistSession: false } }
);

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, stripe-signature",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.text();
    const signature = req.headers.get("stripe-signature");
    
    if (!signature) {
      throw new Error("No Stripe signature found");
    }

    // Verify webhook signature
    const webhookSecret = Deno.env.get("STRIPE_WEBHOOK_SECRET");
    if (!webhookSecret) {
      throw new Error("Webhook secret not configured");
    }

    const event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
    
    console.log("Processing webhook event:", event.type);

    switch (event.type) {
      case 'customer.subscription.created':
        await handleSubscriptionCreated(event.data.object);
        break;
      
      case 'customer.subscription.updated':
        await handleSubscriptionUpdated(event.data.object);
        break;
      
      case 'customer.subscription.deleted':
        await handleSubscriptionDeleted(event.data.object);
        break;
      
      case 'invoice.payment_succeeded':
        await handlePaymentSucceeded(event.data.object);
        break;
      
      case 'invoice.payment_failed':
        await handlePaymentFailed(event.data.object);
        break;
      
      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    return new Response(JSON.stringify({ received: true }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (err) {
    console.error("Webhook error:", err);
    const message = (err as Error)?.message ?? 'Unknown error';
    return new Response(JSON.stringify({ error: message }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

async function handleSubscriptionCreated(subscription: Stripe.Subscription) {
  console.log("Handling subscription created:", subscription.id);
  
  // This is usually handled by the success page, but we can update status if needed
  const { error } = await supabase
    .from('subscriptions')
    .update({
      status: subscription.status,
      current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
      current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
    })
    .eq('stripe_subscription_id', subscription.id);

  if (error) {
    console.error("Error updating subscription:", error);
  }
}

async function handleSubscriptionUpdated(subscription: Stripe.Subscription) {
  console.log("Handling subscription updated:", subscription.id, subscription.status);
  
  const { error } = await supabase
    .from('subscriptions')
    .update({
      status: subscription.status,
      current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
      current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
    })
    .eq('stripe_subscription_id', subscription.id);

  if (error) {
    console.error("Error updating subscription:", error);
  }

  // Notify customer of status changes
  if (subscription.status === 'past_due' || subscription.status === 'unpaid') {
    // Send payment failure notification
    await notifyPaymentIssue(subscription.id);
  }
}

async function handleSubscriptionDeleted(subscription: Stripe.Subscription) {
  console.log("Handling subscription deleted:", subscription.id);
  
  const { error } = await supabase
    .from('subscriptions')
    .update({
      status: 'cancelled'
    })
    .eq('stripe_subscription_id', subscription.id);

  if (error) {
    console.error("Error cancelling subscription:", error);
  }
}

async function handlePaymentSucceeded(invoice: Stripe.Invoice) {
  console.log("Handling payment succeeded for subscription:", invoice.subscription);
  
  if (!invoice.subscription) return;

  // Update subscription status to active if it was past due
  const { error } = await supabase
    .from('subscriptions')
    .update({
      status: 'active'
    })
    .eq('stripe_subscription_id', invoice.subscription)
    .eq('status', 'past_due');

  if (error) {
    console.error("Error updating subscription after payment:", error);
  }

  // Create delivery record for successful payment
  await createNextDelivery(invoice.subscription as string);
}

async function handlePaymentFailed(invoice: Stripe.Invoice) {
  console.log("Handling payment failed for subscription:", invoice.subscription);
  
  if (!invoice.subscription) return;

  // Update subscription status to past_due
  const { error } = await supabase
    .from('subscriptions')
    .update({
      status: 'past_due'
    })
    .eq('stripe_subscription_id', invoice.subscription);

  if (error) {
    console.error("Error updating subscription after payment failure:", error);
  }
}

async function createNextDelivery(stripeSubscriptionId: string) {
  try {
    // Get subscription details
    const { data: subscription } = await supabase
      .from('subscriptions')
      .select(`
        *,
        subscription_plans (
          price,
          interval_type,
          interval_count
        )
      `)
      .eq('stripe_subscription_id', stripeSubscriptionId)
      .single();

    if (!subscription) {
      console.error("Subscription not found for delivery creation");
      return;
    }

    // Calculate next delivery date
    const currentDate = new Date(subscription.next_delivery_date);
    const nextDate = new Date(currentDate);
    
    if (subscription.subscription_plans.interval_type === 'weekly') {
      nextDate.setDate(currentDate.getDate() + (7 * subscription.subscription_plans.interval_count));
    } else if (subscription.subscription_plans.interval_type === 'monthly') {
      nextDate.setMonth(currentDate.getMonth() + subscription.subscription_plans.interval_count);
    }

    // Create new delivery record
    const { error: deliveryError } = await supabase
      .from('subscription_deliveries')
      .insert({
        subscription_id: subscription.id,
        delivery_date: nextDate.toISOString().split('T')[0],
        status: 'scheduled',
        items: [],
        total_amount: subscription.subscription_plans.price
      });

    if (deliveryError) {
      console.error("Error creating next delivery:", deliveryError);
      return;
    }

    // Update subscription with next delivery date
    await supabase
      .from('subscriptions')
      .update({
        next_delivery_date: nextDate.toISOString().split('T')[0]
      })
      .eq('id', subscription.id);

    console.log("Created next delivery for subscription:", subscription.id);
    
  } catch (error) {
    console.error("Error in createNextDelivery:", error);
  }
}

async function notifyPaymentIssue(stripeSubscriptionId: string) {
  try {
    // Get subscription and customer details
    const { data: subscription } = await supabase
      .from('subscriptions')
      .select(`
        *,
        profiles!subscriptions_customer_id_fkey (
          email,
          full_name
        ),
        subscription_plans (
          name
        )
      `)
      .eq('stripe_subscription_id', stripeSubscriptionId)
      .single();

    if (!subscription?.profiles?.email) {
      console.error("Could not find customer email for payment issue notification");
      return;
    }

    // Send payment issue email
    await supabase.functions.invoke('send-payment-issue-email', {
      body: {
        customerEmail: subscription.profiles.email,
        customerName: subscription.profiles.full_name,
        planName: subscription.subscription_plans.name,
        subscriptionId: subscription.id
      }
    });

    console.log("Sent payment issue notification");
    
  } catch (error) {
    console.error("Error sending payment issue notification:", error);
  }
}