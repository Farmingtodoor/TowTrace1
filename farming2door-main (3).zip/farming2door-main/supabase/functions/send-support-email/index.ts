import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { SmtpClient } from "https://deno.land/x/smtp@v0.7.0/mod.ts";

const smtpConfig = {
  hostname: Deno.env.get('SMTP_HOST') as string,
  port: parseInt(Deno.env.get('SMTP_PORT') as string),
  username: Deno.env.get('SMTP_USER') as string,
  password: Deno.env.get('SMTP_PASSWORD') as string,
};

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface SupportEmailRequest {
  name: string;
  email: string;
  category: string;
  subject: string;
  message: string;
  userId?: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { name, email, category, subject, message, userId }: SupportEmailRequest = await req.json();

    const client = new SmtpClient()
    await client.connectTLS(smtpConfig)

    // Send email to support team
    await client.send({
      from: smtpConfig.username,
      to: "support@farm2door.com", // Replace with your actual support email
      subject: `[${category.toUpperCase()}] ${subject}`,
      content: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #2563eb; border-bottom: 2px solid #f3f4f6; padding-bottom: 10px;">
            New Support Request
          </h2>
          
          <div style="background-color: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="margin: 0 0 15px 0; color: #374151;">Contact Information</h3>
            <p><strong>Name:</strong> ${name}</p>
            <p><strong>Email:</strong> ${email}</p>
            <p><strong>Category:</strong> ${category}</p>
            ${userId ? `<p><strong>User ID:</strong> ${userId}</p>` : ''}
          </div>

          <div style="margin: 20px 0;">
            <h3 style="color: #374151;">Subject</h3>
            <p style="background-color: #f3f4f6; padding: 15px; border-radius: 6px;">${subject}</p>
          </div>

          <div style="margin: 20px 0;">
            <h3 style="color: #374151;">Message</h3>
            <div style="background-color: #ffffff; padding: 20px; border: 1px solid #e5e7eb; border-radius: 6px; white-space: pre-wrap;">${message}</div>
          </div>

          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb; color: #6b7280; font-size: 12px;">
            <p>This message was sent via the Farm2Door support form on ${new Date().toLocaleString()}.</p>
          </div>
        </div>
      `,
    });

    // Send confirmation email to user
    await client.send({
      from: smtpConfig.username,
      to: email,
      subject: "We received your support request",
      content: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #2563eb; border-bottom: 2px solid #f3f4f6; padding-bottom: 10px;">
            Thank you for contacting Farm2Door Support
          </h2>
          
          <p>Hi ${name},</p>
          
          <p>We've received your support request and wanted to let you know that our team is on it!</p>
          
          <div style="background-color: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="margin: 0 0 15px 0; color: #374151;">Your Request Summary</h3>
            <p><strong>Category:</strong> ${category}</p>
            <p><strong>Subject:</strong> ${subject}</p>
            <p><strong>Submitted:</strong> ${new Date().toLocaleString()}</p>
          </div>

          <p><strong>What happens next?</strong></p>
          <ul style="color: #6b7280;">
            <li>Our support team will review your request</li>
            <li>We typically respond within 24 hours during business days</li>
            <li>For urgent matters, we may reach out sooner</li>
            <li>You'll receive our response at this email address: ${email}</li>
          </ul>

          <div style="background-color: #dbeafe; padding: 15px; border-radius: 6px; margin: 20px 0;">
            <p style="margin: 0; color: #1e40af;"><strong>💡 Tip:</strong> Check your spam folder if you don't see our response in your inbox.</p>
          </div>

          <p>Thank you for choosing Farm2Door!</p>
          
          <p style="color: #6b7280;">
            Best regards,<br>
            The Farm2Door Support Team
          </p>

          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb; color: #9ca3af; font-size: 12px;">
            <p>If you have any additional questions, please don't hesitate to contact us again or visit our FAQ section on our website.</p>
          </div>
        </div>
      `,
    });

    await client.close()

    console.log("Support email sent successfully");
    console.log("Confirmation email sent successfully");

    return new Response(JSON.stringify({ 
      success: true,
      message: "Support emails sent successfully"
    }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        ...corsHeaders,
      },
    });
  } catch (error: any) {
    console.error("Error in send-support-email function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);