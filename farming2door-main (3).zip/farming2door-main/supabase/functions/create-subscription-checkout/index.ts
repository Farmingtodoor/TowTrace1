import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@14.21.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// ============= ANTI-CARD-TESTING RATE LIMITER =============
interface RateLimitEntry {
  count: number;
  firstRequest: number;
  lastRequest: number;
}

const rateLimitStore = new Map<string, RateLimitEntry>();
const WINDOW_SIZE = 60 * 1000;
const MAX_REQUESTS_PER_WINDOW = 5;
const BLOCK_DURATION = 15 * 60 * 1000;

function getClientIP(req: Request): string {
  return req.headers.get('cf-connecting-ip') || 
         req.headers.get('x-real-ip') || 
         req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 
         'unknown';
}

function checkRateLimit(ip: string): { allowed: boolean; retryAfter?: number } {
  const now = Date.now();
  const entry = rateLimitStore.get(ip);
  
  if (!entry) {
    rateLimitStore.set(ip, { count: 1, firstRequest: now, lastRequest: now });
    return { allowed: true };
  }
  
  if (now - entry.firstRequest > WINDOW_SIZE) {
    rateLimitStore.set(ip, { count: 1, firstRequest: now, lastRequest: now });
    return { allowed: true };
  }
  
  if (entry.count >= MAX_REQUESTS_PER_WINDOW) {
    const blockEnds = entry.lastRequest + BLOCK_DURATION;
    if (now < blockEnds) {
      return { allowed: false, retryAfter: Math.ceil((blockEnds - now) / 1000) };
    }
    rateLimitStore.set(ip, { count: 1, firstRequest: now, lastRequest: now });
    return { allowed: true };
  }
  
  entry.count++;
  entry.lastRequest = now;
  return { allowed: true };
}

function detectSuspiciousRequest(req: Request): { suspicious: boolean; reason?: string } {
  const userAgent = req.headers.get('user-agent') || '';
  if (!userAgent || userAgent.length < 10) {
    return { suspicious: true, reason: 'Invalid user agent' };
  }
  const botPatterns = ['curl', 'wget', 'python-requests', 'scrapy', 'bot', 'crawler', 'postman'];
  if (botPatterns.some(p => userAgent.toLowerCase().includes(p))) {
    return { suspicious: true, reason: 'Automated request detected' };
  }
  return { suspicious: false };
}
// ============= END RATE LIMITER =============

interface CheckoutRequest {
  planId: string;
  deliveryAddress?: string;
  specialInstructions?: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  // Create Supabase client using anon key for authentication
  const supabaseClient = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_ANON_KEY") ?? ""
  );

  try {
    console.log("Starting subscription checkout process");

    // ====== ANTI-CARD-TESTING CHECKS ======
    const clientIP = getClientIP(req);
    console.log("[ANTI-FRAUD] Request from IP:", clientIP);
    
    const rateLimitResult = checkRateLimit(clientIP);
    if (!rateLimitResult.allowed) {
      console.log("[ANTI-FRAUD] Rate limit exceeded for IP:", clientIP);
      return new Response(JSON.stringify({ 
        error: "Too many payment attempts. Please try again later.",
        retryAfter: rateLimitResult.retryAfter 
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json", "Retry-After": String(rateLimitResult.retryAfter) },
        status: 429,
      });
    }
    
    const suspiciousCheck = detectSuspiciousRequest(req);
    if (suspiciousCheck.suspicious) {
      console.log("[ANTI-FRAUD] Suspicious request blocked:", suspiciousCheck.reason);
      return new Response(JSON.stringify({ error: "Request blocked for security reasons" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 403,
      });
    }
    // ====== END ANTI-FRAUD CHECKS ======

    // Get authenticated user
    const authHeader = req.headers.get("Authorization")!;
    const token = authHeader.replace("Bearer ", "");
    const { data } = await supabaseClient.auth.getUser(token);
    const user = data.user;
    if (!user?.email) throw new Error("User not authenticated or email not available");
    
    console.log("User authenticated:", user.id);

    // Parse request body
    const { planId, deliveryAddress, specialInstructions }: CheckoutRequest = await req.json();
    console.log("Checkout request for plan:", planId);

    // Get subscription plan details
    const { data: plan, error: planError } = await supabaseClient
      .from('subscription_plans')
      .select('*')
      .eq('id', planId)
      .eq('is_active', true)
      .single();

    if (planError || !plan) {
      throw new Error("Subscription plan not found or inactive");
    }

    console.log("Found subscription plan:", plan.name, plan.price);

    // Initialize Stripe
    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
      apiVersion: "2023-10-16",
    });

    // Check if customer exists in Stripe
    const customers = await stripe.customers.list({ email: user.email, limit: 1 });
    let customerId;
    if (customers.data.length > 0) {
      customerId = customers.data[0].id;
      console.log("Found existing Stripe customer:", customerId);
    } else {
      console.log("Creating new Stripe customer");
    }

    // Create Stripe product and price if not exists
    let stripeProductId = plan.stripe_product_id;
    let stripePriceId = plan.stripe_price_id;

    if (!stripeProductId || !stripePriceId) {
      console.log("Creating Stripe product and price");
      
      // Create product
      const product = await stripe.products.create({
        name: plan.name,
        description: plan.description,
        metadata: {
          supabase_plan_id: plan.id,
          farmer_id: plan.farmer_id
        }
      });

      // Create price
      const price = await stripe.prices.create({
        currency: 'usd',
        unit_amount: Math.round(plan.price * 100), // Convert to cents
        recurring: {
          interval: plan.interval_type as 'week' | 'month',
          interval_count: plan.interval_count
        },
        product: product.id,
        metadata: {
          supabase_plan_id: plan.id
        }
      });

      stripeProductId = product.id;
      stripePriceId = price.id;

      // Update the plan with Stripe IDs
      await supabaseClient
        .from('subscription_plans')
        .update({
          stripe_product_id: stripeProductId,
          stripe_price_id: stripePriceId
        })
        .eq('id', plan.id);

      console.log("Created Stripe product and price:", stripeProductId, stripePriceId);
    }

    // Create checkout session
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      customer_email: customerId ? undefined : user.email,
      line_items: [
        {
          price: stripePriceId,
          quantity: 1,
        },
      ],
      mode: "subscription",
      success_url: `${req.headers.get("origin")}/subscription-success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${req.headers.get("origin")}/browse`,
      metadata: {
        plan_id: planId,
        user_id: user.id,
        farmer_id: plan.farmer_id,
        delivery_address: deliveryAddress || '',
        special_instructions: specialInstructions || ''
      },
      subscription_data: {
        metadata: {
          plan_id: planId,
          user_id: user.id,
          farmer_id: plan.farmer_id
        }
      }
    });

    console.log("Created checkout session:", session.id);

    return new Response(JSON.stringify({ url: session.url }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });

  } catch (err) {
    console.error("Error in create-subscription-checkout:", err);
    const message = (err as Error)?.message ?? 'Unknown error';
    return new Response(JSON.stringify({ error: message }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});