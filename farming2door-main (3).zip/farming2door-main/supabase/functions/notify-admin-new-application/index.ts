import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-webhook-signature",
};

interface NotificationRequest {
  farmer_name: string;
  farm_name: string;
  application_id: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Verify webhook signature to prevent unauthorized calls
    const webhookSecret = Deno.env.get("DB_WEBHOOK_SECRET");
    const signature = req.headers.get("x-webhook-signature");
    const rawBody = await req.text();
    
    if (!webhookSecret || !signature) {
      console.error("Missing webhook signature or secret");
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    // Validate webhook signature using HMAC-SHA256
    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey(
      "raw",
      encoder.encode(webhookSecret),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"]
    );
    
    const signature_buffer = await crypto.subtle.sign("HMAC", key, encoder.encode(rawBody));
    const expectedSignature = Array.from(new Uint8Array(signature_buffer))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');

    if (signature !== `sha256=${expectedSignature}`) {
      console.error("Invalid webhook signature");
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    // Parse the validated payload
    const { farmer_name, farm_name, application_id }: NotificationRequest = JSON.parse(rawBody);

    console.log("Processing notification for new farmer application:", { farmer_name, farm_name, application_id });

    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

    // Get all admin users
    const { data: adminUsers, error: adminError } = await supabaseClient
      .from('user_roles')
      .select(`
        user_id,
        profiles!inner(email, full_name)
      `)
      .in('role', ['admin', 'super_admin']);

    if (adminError) {
      console.error("Error fetching admin users:", adminError);
      throw new Error("Failed to fetch admin users");
    }

    if (!adminUsers || adminUsers.length === 0) {
      console.log("No admin users found");
      return new Response(JSON.stringify({ message: "No admin users to notify" }), {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    // Send email to each admin
    const emailPromises = adminUsers.map((adminUser: any) => {
      const adminEmail = adminUser.profiles.email;
      const adminName = adminUser.profiles.full_name || 'Admin';

      console.log(`Sending email to admin: ${adminEmail}`);

      return resend.emails.send({
        from: "Farm2Door <notifications@resend.dev>",
        to: [adminEmail],
        subject: "New Farmer Application - Action Required",
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h1 style="color: #16a34a; margin-bottom: 20px;">New Farmer Application Submitted</h1>
            
            <p>Hello ${adminName},</p>
            
            <p>A new farmer application has been submitted on Farm2Door and requires your review.</p>
            
            <div style="background-color: #f3f4f6; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <h3 style="margin-top: 0; color: #374151;">Application Details:</h3>
              <p><strong>Farmer Name:</strong> ${farmer_name}</p>
              <p><strong>Farm Name:</strong> ${farm_name}</p>
              <p><strong>Status:</strong> Pending Review</p>
            </div>
            
            <p>Please log in to the admin dashboard to review and approve or reject this application.</p>
            
            <div style="margin: 30px 0;">
              <a href="https://njheralnbmbblwqhrncm.supabase.co" 
                 style="background-color: #16a34a; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
                Review Application
              </a>
            </div>
            
            <p style="color: #6b7280; font-size: 14px; margin-top: 30px;">
              This is an automated notification from Farm2Door. Please do not reply to this email.
            </p>
          </div>
        `,
      });
    });

    const emailResults = await Promise.allSettled(emailPromises);
    
    // Log results
    emailResults.forEach((result, index) => {
      if (result.status === 'fulfilled') {
        console.log(`Email sent successfully to admin ${index + 1}:`, result.value);
      } else {
        console.error(`Failed to send email to admin ${index + 1}:`, result.reason);
      }
    });

    const successCount = emailResults.filter(r => r.status === 'fulfilled').length;
    const failureCount = emailResults.filter(r => r.status === 'rejected').length;

    return new Response(JSON.stringify({ 
      message: `Notifications sent to ${successCount} admins`,
      success_count: successCount,
      failure_count: failureCount
    }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });

  } catch (error: any) {
    console.error("Error in notify-admin-new-application function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);