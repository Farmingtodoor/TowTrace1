import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.0";
import Stripe from "https://esm.sh/stripe@14.21.0";
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const admin = createClient(
  Deno.env.get("SUPABASE_URL") ?? "",
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
);

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
const FROM_EMAIL = Deno.env.get("FROM_EMAIL") || "noreply@resend.dev";
const SITE_URL = Deno.env.get("SITE_URL") || "https://farming2door.com";

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const receiptNumber = () =>
  `F2D-${new Date().toISOString().slice(0, 10).replace(/-/g, "")}-${crypto
    .randomUUID()
    .slice(0, 6)
    .toUpperCase()}`;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey) return json({ error: "Payouts are not configured yet." }, 500);
    const stripe = new Stripe(stripeKey, { apiVersion: "2023-10-16" });

    const token = (req.headers.get("Authorization") ?? "").replace("Bearer ", "");
    if (!token) return json({ error: "Unauthorized" }, 401);

    const { data: userData, error: userError } = await admin.auth.getUser(token);
    const caller = userData?.user;
    if (userError || !caller) return json({ error: "Unauthorized" }, 401);

    const { data: isSuperAdmin } = await admin.rpc("has_role", {
      _user_id: caller.id,
      _role: "super_admin",
    });
    if (!isSuperAdmin) return json({ error: "Only a Super Admin can send payouts." }, 403);

    const body = await req.json().catch(() => ({}));
    const payoutId = typeof body?.payoutId === "string" ? body.payoutId : null;
    if (!payoutId) return json({ error: "payoutId is required" }, 400);

    // Source of truth is the stored request, never the client payload
    const { data: payout, error: payoutError } = await admin
      .from("payout_requests")
      .select("id, farmer_id, amount, status")
      .eq("id", payoutId)
      .maybeSingle();

    if (payoutError || !payout) return json({ error: "Payout request not found." }, 404);
    if (payout.status !== "approved") {
      return json({ error: "Only approved payout requests can be sent." }, 400);
    }
    if (!(payout.amount > 0)) return json({ error: "Invalid payout amount." }, 400);

    const { data: existingReceipt } = await admin
      .from("payout_receipts")
      .select("id")
      .eq("payout_request_id", payout.id)
      .eq("status", "sent")
      .maybeSingle();
    if (existingReceipt) return json({ error: "This payout has already been sent." }, 409);

    const { data: account } = await admin
      .from("farmer_payout_accounts")
      .select("stripe_account_id, payouts_enabled")
      .eq("farmer_id", payout.farmer_id)
      .maybeSingle();

    if (!account?.stripe_account_id || !account.payouts_enabled) {
      return json(
        { error: "This farmer has not finished connecting a verified bank account yet." },
        400,
      );
    }

    const number = receiptNumber();
    let transferId: string;

    try {
      const transfer = await stripe.transfers.create(
        {
          amount: Math.round(Number(payout.amount) * 100),
          currency: "usd",
          destination: account.stripe_account_id,
          description: `Farming2Door payout ${number}`,
          metadata: { payout_request_id: payout.id, receipt_number: number },
        },
        { idempotencyKey: `payout_${payout.id}` },
      );
      transferId = transfer.id;
    } catch (err) {
      const reason = err instanceof Error ? err.message : "Transfer failed";
      await admin.from("payout_receipts").insert({
        payout_request_id: payout.id,
        farmer_id: payout.farmer_id,
        receipt_number: number,
        amount: payout.amount,
        status: "failed",
        stripe_account_id: account.stripe_account_id,
        failure_reason: reason,
        sent_by: caller.id,
      });
      console.error("Transfer failed for payout", payout.id);
      return json({ error: `Transfer failed: ${reason}` }, 502);
    }

    const { data: receipt } = await admin
      .from("payout_receipts")
      .insert({
        payout_request_id: payout.id,
        farmer_id: payout.farmer_id,
        receipt_number: number,
        amount: payout.amount,
        status: "sent",
        stripe_account_id: account.stripe_account_id,
        stripe_transfer_id: transferId,
        sent_by: caller.id,
      })
      .select()
      .single();

    await admin.rpc("admin_update_payout_status", {
      p_payout_id: payout.id,
      p_status: "paid",
    }).catch(async () => {
      await admin
        .from("payout_requests")
        .update({ status: "paid", reviewed_at: new Date().toISOString() })
        .eq("id", payout.id);
    });

    // Email the farmer their receipt
    try {
      const { data: profile } = await admin
        .from("profiles")
        .select("email, full_name")
        .eq("id", payout.farmer_id)
        .maybeSingle();

      if (profile?.email) {
        await resend.emails.send({
          from: `Farming2Door <${FROM_EMAIL}>`,
          to: [profile.email],
          subject: `Payout sent — $${Number(payout.amount).toFixed(2)} (${number})`,
          html: `
            <h2>Your payout is on its way</h2>
            <p>Hi ${profile.full_name || "there"},</p>
            <p>We've sent <strong>$${Number(payout.amount).toFixed(2)}</strong> to your connected bank account.</p>
            <ul>
              <li><strong>Receipt number:</strong> ${number}</li>
              <li><strong>Sent:</strong> ${new Date().toLocaleString("en-US")}</li>
              <li><strong>Reference:</strong> ${transferId}</li>
            </ul>
            <p>Funds usually land in 1–2 business days depending on your bank.</p>
            <p><a href="${SITE_URL}/farmer-payouts">View and download your receipt</a></p>
          `,
        });
      }
    } catch (emailError) {
      console.error("Payout receipt email failed:", emailError instanceof Error ? emailError.message : emailError);
    }

    return json({ success: true, receipt });
  } catch (error) {
    console.error("send-farmer-payout error:", error instanceof Error ? error.message : error);
    return json({ error: "Could not send the payout." }, 500);
  }
});
