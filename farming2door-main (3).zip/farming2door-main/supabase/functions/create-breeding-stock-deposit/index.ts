import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import Stripe from "https://esm.sh/stripe@14.21.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// ============= ANTI-CARD-TESTING RATE LIMITER =============
interface RateLimitEntry {
  count: number;
  firstRequest: number;
  lastRequest: number;
}

const rateLimitStore = new Map<string, RateLimitEntry>();
const WINDOW_SIZE = 60 * 1000;
const MAX_REQUESTS_PER_WINDOW = 5;
const BLOCK_DURATION = 15 * 60 * 1000;

function getClientIP(req: Request): string {
  return req.headers.get('cf-connecting-ip') || 
         req.headers.get('x-real-ip') || 
         req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 
         'unknown';
}

function checkRateLimit(ip: string): { allowed: boolean; retryAfter?: number } {
  const now = Date.now();
  const entry = rateLimitStore.get(ip);
  
  if (!entry) {
    rateLimitStore.set(ip, { count: 1, firstRequest: now, lastRequest: now });
    return { allowed: true };
  }
  
  if (now - entry.firstRequest > WINDOW_SIZE) {
    rateLimitStore.set(ip, { count: 1, firstRequest: now, lastRequest: now });
    return { allowed: true };
  }
  
  if (entry.count >= MAX_REQUESTS_PER_WINDOW) {
    const blockEnds = entry.lastRequest + BLOCK_DURATION;
    if (now < blockEnds) {
      return { allowed: false, retryAfter: Math.ceil((blockEnds - now) / 1000) };
    }
    rateLimitStore.set(ip, { count: 1, firstRequest: now, lastRequest: now });
    return { allowed: true };
  }
  
  entry.count++;
  entry.lastRequest = now;
  return { allowed: true };
}

function detectSuspiciousRequest(req: Request): { suspicious: boolean; reason?: string } {
  const userAgent = req.headers.get('user-agent') || '';
  if (!userAgent || userAgent.length < 10) {
    return { suspicious: true, reason: 'Invalid user agent' };
  }
  const botPatterns = ['curl', 'wget', 'python-requests', 'scrapy', 'bot', 'crawler', 'postman'];
  if (botPatterns.some(p => userAgent.toLowerCase().includes(p))) {
    return { suspicious: true, reason: 'Automated request detected' };
  }
  return { suspicious: false };
}
// ============= END RATE LIMITER =============

interface DepositRequest {
  listingId: string;
  customerEmail: string;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Starting breeding stock deposit checkout...');

    // ====== ANTI-CARD-TESTING CHECKS ======
    const clientIP = getClientIP(req);
    console.log('[ANTI-FRAUD] Request from IP:', clientIP);
    
    const rateLimitResult = checkRateLimit(clientIP);
    if (!rateLimitResult.allowed) {
      console.log('[ANTI-FRAUD] Rate limit exceeded for IP:', clientIP);
      return new Response(JSON.stringify({ 
        error: "Too many payment attempts. Please try again later.",
        retryAfter: rateLimitResult.retryAfter 
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json", "Retry-After": String(rateLimitResult.retryAfter) },
        status: 429,
      });
    }
    
    const suspiciousCheck = detectSuspiciousRequest(req);
    if (suspiciousCheck.suspicious) {
      console.log('[ANTI-FRAUD] Suspicious request blocked:', suspiciousCheck.reason);
      return new Response(JSON.stringify({ error: "Request blocked for security reasons" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 403,
      });
    }
    // ====== END ANTI-FRAUD CHECKS ======

    const requestBody = await req.json();
    const { listingId, customerEmail }: DepositRequest = requestBody;

    // Get authorization header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 401,
      });
    }

    // Enhanced email validation
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!listingId || !customerEmail || !emailRegex.test(customerEmail)) {
      return new Response(JSON.stringify({ error: "Invalid request data" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      });
    }

    // Create Supabase client
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") || "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || ""
    );

    // Get user from auth header
    const { data: { user }, error: userError } = await supabase.auth.getUser(
      authHeader.replace('Bearer ', '')
    );

    if (userError || !user) {
      console.error('Auth error:', userError);
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 401,
      });
    }

    // Fetch listing details
    const { data: listing, error: listingError } = await supabase
      .from('breeding_stock_listings')
      .select('*, breeding_stock_breeds(name)')
      .eq('id', listingId)
      .eq('status', 'active')
      .single();

    if (listingError || !listing) {
      console.error('Listing error:', listingError);
      return new Response(JSON.stringify({ error: "Listing not found or not available" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 404,
      });
    }

    // Check if deposit is allowed
    if (!listing.deposit_allowed || !listing.deposit_percentage) {
      return new Response(JSON.stringify({ error: "Deposit not available for this listing" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      });
    }

    // Calculate deposit amount
    const depositAmount = (parseFloat(listing.price) * listing.deposit_percentage / 100);
    const balanceAmount = parseFloat(listing.price) - depositAmount;

    // Validate Stripe key
    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    if (!stripeKey) {
      return new Response(JSON.stringify({ error: "Payment service not configured" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500,
      });
    }

    // Create Stripe client
    const stripe = new Stripe(stripeKey, {
      apiVersion: "2023-10-16",
    });

    // Create Stripe checkout session for deposit
    const session = await stripe.checkout.sessions.create({
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: `Deposit: ${listing.title}`,
              description: `${listing.deposit_percentage}% deposit for ${listing.breeding_stock_breeds?.name || 'breeding stock'}`,
            },
            unit_amount: Math.round(depositAmount * 100),
          },
          quantity: 1,
        },
      ],
      mode: "payment",
      success_url: `${req.headers.get("origin")}/breeding-stock/${listingId}?deposit=success`,
      cancel_url: `${req.headers.get("origin")}/breeding-stock/${listingId}?deposit=cancelled`,
      customer_email: customerEmail,
      metadata: {
        listing_id: listingId,
        buyer_id: user.id,
        seller_id: listing.farmer_id,
        deposit_amount: depositAmount.toString(),
        balance_amount: balanceAmount.toString(),
        total_price: listing.price.toString(),
        payment_type: 'breeding_stock_deposit',
      },
    });

    // Create pending transaction record
    const { error: transactionError } = await supabase
      .from('breeding_stock_transactions')
      .insert({
        listing_id: listingId,
        buyer_id: user.id,
        seller_id: listing.farmer_id,
        total_price: parseFloat(listing.price),
        deposit_amount: depositAmount,
        balance_amount: balanceAmount,
        status: 'deposit_pending',
        stripe_deposit_session_id: session.id,
      });

    if (transactionError) {
      console.error('Transaction creation error:', transactionError);
      // Continue anyway as payment session is already created
    }

    return new Response(JSON.stringify({ url: session.url }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });

  } catch (err) {
    console.error('Deposit checkout error:', err);
    const message = (err as Error)?.message ?? 'Unknown error';
    return new Response(JSON.stringify({ error: message }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});
