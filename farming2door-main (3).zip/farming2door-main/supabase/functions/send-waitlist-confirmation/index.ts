import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.0";
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const supabase = createClient(
  Deno.env.get("SUPABASE_URL") ?? "",
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
);

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));
const FROM_EMAIL = Deno.env.get("FROM_EMAIL") || "noreply@resend.dev";
const SITE_URL = Deno.env.get("SITE_URL") || "https://farming2door.com";

const isEmail = (v: unknown) => typeof v === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const isZip = (v: unknown) => typeof v === "string" && /^\d{5}$/.test(v.trim());

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const body = await req.json().catch(() => ({}));
    const waitlistId = typeof body.waitlistId === "string" ? body.waitlistId : null;

    if (!waitlistId) {
      return new Response(JSON.stringify({ error: "waitlistId is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Source of truth is the stored row, never the client payload
    const { data: row, error } = await supabase
      .from("delivery_waitlist")
      .select("id, farmer_id, email, zip_code, distance_miles, notify_delivery, notify_pickup")
      .eq("id", waitlistId)
      .maybeSingle();

    if (error) throw error;
    if (!row || !isEmail(row.email) || !isZip(row.zip_code)) {
      return new Response(JSON.stringify({ error: "Waitlist request not found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: farmer } = await supabase
      .from("profiles")
      .select("full_name")
      .eq("id", row.farmer_id)
      .maybeSingle();

    const farmName = farmer?.full_name || "the farm";
    const zip = row.zip_code;

    const alerts: string[] = [];
    if (row.notify_delivery) alerts.push(`delivery coverage expands to ${zip}`);
    if (row.notify_pickup) alerts.push("farm pickup time slots become available");

    const distanceLine =
      row.distance_miles != null
        ? `<li style="margin-bottom:6px"><strong>Estimated distance:</strong> about ${Number(row.distance_miles).toFixed(1)} miles from the farm</li>`
        : "";

    const html = `
    <div style="font-family:system-ui,-apple-system,Segoe UI,sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#1f2a24">
      <h1 style="font-size:20px;margin:0 0 12px">You're on the list for ${farmName}</h1>
      <p style="font-size:15px;line-height:1.6;margin:0 0 16px">
        Thanks for letting us know you'd like orders from <strong>${farmName}</strong> in
        <strong>ZIP ${zip}</strong>. That ZIP is currently outside their delivery zone, so we've saved your request.
      </p>
      <ul style="font-size:14px;line-height:1.6;padding-left:18px;margin:0 0 16px">
        <li style="margin-bottom:6px"><strong>Farm:</strong> ${farmName}</li>
        <li style="margin-bottom:6px"><strong>Your ZIP:</strong> ${zip}</li>
        ${distanceLine}
        <li style="margin-bottom:6px"><strong>We'll email you when:</strong> ${alerts.join(" or ") || "there's an update for your area"}</li>
      </ul>
      <a href="${SITE_URL}/farmers"
         style="display:inline-block;background:#2f6f4f;color:#fff;text-decoration:none;padding:12px 20px;border-radius:8px;font-weight:600">
        Browse farms that deliver to you
      </a>
      <p style="font-size:12px;color:#6b7770;margin-top:28px">
        You're receiving this because you requested delivery updates for ZIP ${zip}.
        <a href="${SITE_URL}/waitlist/unsubscribe?id=${row.id}" style="color:#6b7770">Unsubscribe</a>
      </p>
    </div>`;

    const { error: sendError } = await resend.emails.send({
      from: `Farming2Door <${FROM_EMAIL}>`,
      to: [row.email],
      subject: `We saved your request for ${farmName} — ZIP ${zip}`,
      html,
    });

    if (sendError) {
      console.error("Waitlist confirmation send failed", sendError);
      return new Response(JSON.stringify({ error: "Failed to send confirmation" }), {
        status: 502,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ sent: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("send-waitlist-confirmation error", e instanceof Error ? e.message : e);
    return new Response(JSON.stringify({ error: "Failed to send confirmation" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
