import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Link,
  Preview,
  Section,
  Text,
  Img,
} from 'https://esm.sh/@react-email/components@0.0.22'
import * as React from 'https://esm.sh/react@18.3.1'

interface NotificationEmailProps {
  user_name: string
  notification_title: string
  notification_message: string
  notification_type: string
  order_id?: string
  app_url?: string
}

export const NotificationEmail = ({
  user_name,
  notification_title,
  notification_message,
  notification_type,
  order_id,
  app_url = 'https://c2f2638b-64d5-4701-ac89-48a04d6451b0.lovableproject.com'
}: NotificationEmailProps) => (
  <Html>
    <Head />
    <Preview>{notification_title}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Section style={header}>
          <Text style={headerText}>Farming2Door</Text>
        </Section>
        
        <Section style={content}>
          <Text style={greeting}>Hi {user_name || 'there'},</Text>
          
          <Heading style={h2}>{notification_title}</Heading>
          
          <Text style={message}>{notification_message}</Text>
          
          {order_id && (
            <Section style={orderSection}>
              <Text style={orderText}>📦 Order ID: <strong>#{order_id.slice(-8)}</strong></Text>
              <Link
                href={`${app_url}/orders/${order_id}`}
                style={button}
              >
                View Order Details
              </Link>
            </Section>
          )}
          
          {notification_type === 'order_delivered' && (
            <Section style={orderSection}>
              <Text style={feedbackText}>💬 Tell us how we did:</Text>
              <Link
                href={`${app_url}/feedback`}
                style={feedbackButton}
              >
                Share Feedback
              </Link>
            </Section>
          )}
          
          <Text style={footerMessage}>
            🌱 Enjoy the freshness,<br/>
            The Farming2Door Team
          </Text>
        </Section>
        
        <Section style={footer}>
          <Text style={footerBrand}>
            From Our Farms to Your Table – Always Fresh.
          </Text>
        </Section>
      </Container>
    </Body>
  </Html>
)

export default NotificationEmail

const main = {
  backgroundColor: '#ffffff',
  fontFamily: 'Poppins, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
}

const container = {
  margin: '0 auto',
  padding: '0',
  maxWidth: '600px',
}

const header = {
  backgroundColor: '#4CAF50',
  padding: '24px',
  textAlign: 'center' as const,
}

const headerText = {
  color: '#ffffff',
  fontSize: '24px',
  fontWeight: 'bold',
  margin: '0',
}

const h2 = {
  color: '#333333',
  fontSize: '20px',
  fontWeight: 'bold',
  margin: '24px 0 16px 0',
}

const content = {
  padding: '32px 40px',
  backgroundColor: '#ffffff',
}

const greeting = {
  color: '#333333',
  fontSize: '16px',
  lineHeight: '1.6',
  margin: '0 0 16px 0',
}

const message = {
  color: '#555555',
  fontSize: '16px',
  lineHeight: '1.6',
  margin: '16px 0 24px 0',
}

const orderSection = {
  backgroundColor: '#f8f9fa',
  borderRadius: '12px',
  padding: '24px',
  margin: '24px 0',
  textAlign: 'center' as const,
}

const orderText = {
  color: '#333333',
  fontSize: '14px',
  margin: '0 0 16px 0',
}

const button = {
  backgroundColor: '#4CAF50',
  borderRadius: '25px',
  color: '#ffffff',
  fontSize: '16px',
  fontWeight: 'bold',
  textDecoration: 'none',
  padding: '12px 24px',
  display: 'inline-block',
}

const feedbackText = {
  color: '#333333',
  fontSize: '14px',
  margin: '16px 0 8px 0',
}

const feedbackButton = {
  backgroundColor: '#6B4F2A',
  borderRadius: '25px',
  color: '#ffffff',
  fontSize: '16px',
  fontWeight: 'bold',
  textDecoration: 'none',
  padding: '12px 24px',
  display: 'inline-block',
}

const footerMessage = {
  color: '#666666',
  fontSize: '16px',
  lineHeight: '1.6',
  margin: '32px 0 24px 0',
  textAlign: 'center' as const,
}

const footer = {
  backgroundColor: '#6B4F2A',
  padding: '24px',
  textAlign: 'center' as const,
}

const footerBrand = {
  color: '#ffffff',
  fontSize: '16px',
  fontWeight: '600',
  margin: '0',
}