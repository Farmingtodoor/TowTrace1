import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface OrderNotificationRequest {
  farmerName: string;
  farmerEmail: string;
  customerName: string;
  customerEmail: string;
  orderId: string;
  totalAmount: number;
  deliveryType: string;
  deliveryAddress: string;
  items: Array<{
    name: string;
    quantity: number;
    price: number;
  }>;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const {
      farmerName,
      farmerEmail, 
      customerName,
      customerEmail,
      orderId,
      totalAmount,
      deliveryType,
      deliveryAddress,
      items
    }: OrderNotificationRequest = await req.json();

    console.log(`Sending order notification to farmer: ${farmerEmail}`);

    const itemsHtml = items.map(item => `
      <tr>
        <td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${item.name}</td>
        <td style="padding: 8px; border-bottom: 1px solid #e5e7eb; text-align: center;">${item.quantity}</td>
        <td style="padding: 8px; border-bottom: 1px solid #e5e7eb; text-align: right;">$${item.price.toFixed(2)}</td>
        <td style="padding: 8px; border-bottom: 11px solid #e5e7eb; text-align: right;">$${(item.quantity * item.price).toFixed(2)}</td>
      </tr>
    `).join('');

    const emailHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>New Order Received - Farm2Door</title>
        </head>
        <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          
          <div style="text-align: center; margin-bottom: 30px;">
            <h1 style="color: #16a34a; margin: 0;">🌾 New Order Received!</h1>
            <p style="color: #666; font-size: 14px; margin: 5px 0 0 0;">Farm2Door Order Notification</p>
          </div>

          <div style="background: #f8fafc; padding: 20px; border-radius: 8px; border-left: 4px solid #16a34a; margin-bottom: 25px;">
            <p style="margin: 0 0 10px 0;"><strong>Hello ${farmerName},</strong></p>
            <p style="margin: 0;">Great news! You've received a new order through Farm2Door. Please review the details below and prepare the order for your customer.</p>
          </div>

          <div style="margin-bottom: 25px;">
            <h3 style="color: #16a34a; margin-bottom: 15px; border-bottom: 2px solid #e5e7eb; padding-bottom: 8px;">📋 Order Details</h3>
            
            <table style="width: 100%; margin-bottom: 15px;">
              <tr>
                <td style="padding: 8px 0; font-weight: bold; width: 30%;">Order ID:</td>
                <td style="padding: 8px 0;">#${orderId.slice(0, 8)}</td>
              </tr>
              <tr>
                <td style="padding: 8px 0; font-weight: bold;">Customer:</td>
                <td style="padding: 8px 0;">${customerName}</td>
              </tr>
              <tr>
                <td style="padding: 8px 0; font-weight: bold;">Contact:</td>
                <td style="padding: 8px 0;">${customerEmail}</td>
              </tr>
              <tr>
                <td style="padding: 8px 0; font-weight: bold;">${deliveryType === 'pickup' ? 'Pickup' : 'Delivery'}:</td>
                <td style="padding: 8px 0;">${deliveryAddress}</td>
              </tr>
            </table>
          </div>

          <div style="margin-bottom: 25px;">
            <h3 style="color: #16a34a; margin-bottom: 15px; border-bottom: 2px solid #e5e7eb; padding-bottom: 8px;">🛒 Order Items</h3>
            
            <table style="width: 100%; border-collapse: collapse; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden;">
              <thead>
                <tr style="background: #f8fafc;">
                  <th style="padding: 12px 8px; text-align: left; font-weight: bold;">Product</th>
                  <th style="padding: 12px 8px; text-align: center; font-weight: bold;">Qty</th>
                  <th style="padding: 12px 8px; text-align: right; font-weight: bold;">Unit Price</th>
                  <th style="padding: 12px 8px; text-align: right; font-weight: bold;">Total</th>
                </tr>
              </thead>
              <tbody>
                ${itemsHtml}
                <tr style="background: #f8fafc; font-weight: bold;">
                  <td style="padding: 12px 8px;" colspan="3">Order Total</td>
                  <td style="padding: 12px 8px; text-align: right;">$${totalAmount.toFixed(2)}</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div style="background: #fff7ed; padding: 20px; border-radius: 8px; border-left: 4px solid #f59e0b; margin-bottom: 25px;">
            <h4 style="color: #f59e0b; margin: 0 0 10px 0;">⏰ Next Steps:</h4>
            <ol style="margin: 0; padding-left: 20px;">
              <li style="margin-bottom: 8px;"><strong>Review and confirm</strong> the order details above</li>
              <li style="margin-bottom: 8px;"><strong>Prepare the products</strong> ensuring freshness and quality</li>
              <li style="margin-bottom: 8px;"><strong>Contact the customer</strong> at ${customerEmail} to arrange ${deliveryType === 'pickup' ? 'pickup time' : 'delivery scheduling'}</li>
              <li style="margin-bottom: 8px;"><strong>Update the order status</strong> in your Farm2Door dashboard as you progress</li>
            </ol>
          </div>

          <div style="background: #ecfdf5; padding: 20px; border-radius: 8px; border-left: 4px solid #10b981; margin-bottom: 25px;">
            <h4 style="color: #10b981; margin: 0 0 10px 0;">💡 Helpful Tips:</h4>
            <ul style="margin: 0; padding-left: 20px;">
              <li style="margin-bottom: 8px;">Reach out to the customer within 24 hours to confirm the order</li>
              <li style="margin-bottom: 8px;">Provide clear ${deliveryType === 'pickup' ? 'pickup instructions and location details' : 'delivery timeframes and any special instructions'}</li>
              <li style="margin-bottom: 8px;">Keep your Farm2Door profile updated with current availability and contact information</li>
            </ul>
          </div>

          <div style="text-align: center; padding: 20px; background: #f8fafc; border-radius: 8px;">
            <p style="margin: 0 0 15px 0; color: #666;">Questions about this order?</p>
            <p style="margin: 0; font-size: 14px;">
              <a href="mailto:support@farm2door.com" style="color: #16a34a; text-decoration: none;">Contact Farm2Door Support</a>
            </p>
          </div>

          <div style="margin-top: 30px; text-align: center; color: #999; font-size: 12px; border-top: 1px solid #e5e7eb; padding-top: 20px;">
            <p style="margin: 0;">This email was sent by Farm2Door</p>
            <p style="margin: 5px 0 0 0;">Connecting farmers and customers for fresh, local produce</p>
          </div>

        </body>
      </html>
    `;

    console.log('Attempting to send email to:', farmerEmail);
    
    const { data, error } = await resend.emails.send({
      from: "Farm2Door <noreply@resend.dev>",
      to: [farmerEmail],
      subject: `🌾 New Order Received - Order #${orderId.slice(0, 8)}`,
      html: emailHtml,
    });

    console.log('Resend response - data:', data, 'error:', error);

    if (error) {
      console.error("Failed to send farmer notification email:", error);
      throw error;
    }

    console.log("Farmer notification email sent successfully:", data);

    return new Response(JSON.stringify({ 
      success: true, 
      emailId: data?.id
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });

  } catch (error) {
    console.error("Error in send-order-notification-email:", error);
    
    return new Response(JSON.stringify({ 
      error: (error as Error)?.message ?? 'Unknown error',
      success: false 
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});