-- Fix critical security vulnerabilities by implementing proper RLS policies

-- 1. Secure customer_insights table (CRITICAL)
ALTER TABLE public.customer_insights ENABLE ROW LEVEL SECURITY;

-- Only allow customers to see their own insights and admins to see all
CREATE POLICY "Users can view own customer insights" ON public.customer_insights
FOR SELECT USING (customer_id = auth.uid());

CREATE POLICY "Admins can view all customer insights" ON public.customer_insights  
FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- 2. Secure driver_profiles table (CRITICAL)  
ALTER TABLE public.driver_profiles ENABLE ROW LEVEL SECURITY;

-- Only allow drivers to manage their own profiles
CREATE POLICY "Drivers can manage own profiles" ON public.driver_profiles
FOR ALL USING (user_id = auth.uid());

-- Allow customers to see limited driver info for their orders only
CREATE POLICY "Customers can view assigned driver basic info" ON public.driver_profiles
FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.orders o 
    WHERE o.customer_id = auth.uid() 
    AND o.driver_id = driver_profiles.user_id
  )
);

-- Admins can view all driver profiles
CREATE POLICY "Admins can view all driver profiles" ON public.driver_profiles
FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- 3. Secure payout_requests table (CRITICAL - Financial data)
ALTER TABLE public.payout_requests ENABLE ROW LEVEL SECURITY;

-- Only allow farmers to see their own payout requests
CREATE POLICY "Farmers can view own payout requests" ON public.payout_requests
FOR SELECT USING (farmer_id = auth.uid());

CREATE POLICY "Farmers can create own payout requests" ON public.payout_requests
FOR INSERT WITH CHECK (farmer_id = auth.uid());

-- Only admins can view all payout requests
CREATE POLICY "Admins can view all payout requests" ON public.payout_requests
FOR ALL USING (
  EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- 4. Enhance farmer_applications security
-- Add missing policy for farmers to view their own application
CREATE POLICY "Farmers can view own applications" ON public.farmer_applications
FOR SELECT USING (user_id = auth.uid());

-- 5. Secure other sensitive tables
ALTER TABLE public.security_audit_log ENABLE ROW LEVEL SECURITY;

-- Only super admins can view audit logs
CREATE POLICY "Super admins can view audit logs" ON public.security_audit_log
FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() 
    AND role = 'super_admin'
  )
);

-- 6. Secure notifications table
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Users can only see their own notifications
CREATE POLICY "Users can view own notifications" ON public.notifications
FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Users can update own notifications" ON public.notifications
FOR UPDATE USING (user_id = auth.uid());