-- Create subscription plans table for farmers to define their offerings
CREATE TABLE public.subscription_plans (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  farmer_id UUID NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  price NUMERIC NOT NULL,
  interval_type TEXT NOT NULL CHECK (interval_type IN ('weekly', 'monthly')),
  interval_count INTEGER NOT NULL DEFAULT 1,
  max_items INTEGER DEFAULT 5,
  is_active BOOLEAN NOT NULL DEFAULT true,
  stripe_product_id TEXT,
  stripe_price_id TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create customer subscriptions table
CREATE TABLE public.subscriptions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  customer_id UUID NOT NULL,
  plan_id UUID NOT NULL REFERENCES public.subscription_plans(id) ON DELETE CASCADE,
  farmer_id UUID NOT NULL,
  stripe_subscription_id TEXT UNIQUE,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'paused', 'cancelled', 'past_due')),
  current_period_start TIMESTAMP WITH TIME ZONE,
  current_period_end TIMESTAMP WITH TIME ZONE,
  next_delivery_date DATE,
  delivery_address TEXT NOT NULL,
  special_instructions TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create subscription deliveries table to track individual deliveries
CREATE TABLE public.subscription_deliveries (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  subscription_id UUID NOT NULL REFERENCES public.subscriptions(id) ON DELETE CASCADE,
  delivery_date DATE NOT NULL,
  status TEXT NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'preparing', 'delivered', 'skipped', 'cancelled')),
  items JSONB NOT NULL DEFAULT '[]'::jsonb,
  total_amount NUMERIC,
  farmer_notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.subscription_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscription_deliveries ENABLE ROW LEVEL SECURITY;

-- Subscription Plans Policies
CREATE POLICY "Anyone can view active subscription plans" 
ON public.subscription_plans 
FOR SELECT 
USING (is_active = true);

CREATE POLICY "Farmers can manage their own subscription plans" 
ON public.subscription_plans 
FOR ALL 
USING (auth.uid() = farmer_id);

-- Subscriptions Policies  
CREATE POLICY "Customers can view their own subscriptions" 
ON public.subscriptions 
FOR SELECT 
USING (auth.uid() = customer_id);

CREATE POLICY "Farmers can view subscriptions to their plans" 
ON public.subscriptions 
FOR SELECT 
USING (auth.uid() = farmer_id);

CREATE POLICY "Customers can create their own subscriptions" 
ON public.subscriptions 
FOR INSERT 
WITH CHECK (auth.uid() = customer_id);

CREATE POLICY "Customers can update their own subscriptions" 
ON public.subscriptions 
FOR UPDATE 
USING (auth.uid() = customer_id);

CREATE POLICY "Farmers can update subscriptions to their plans" 
ON public.subscriptions 
FOR UPDATE 
USING (auth.uid() = farmer_id);

-- Subscription Deliveries Policies
CREATE POLICY "Customers can view their subscription deliveries" 
ON public.subscription_deliveries 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM public.subscriptions s 
  WHERE s.id = subscription_deliveries.subscription_id 
  AND s.customer_id = auth.uid()
));

CREATE POLICY "Farmers can view deliveries for their subscriptions" 
ON public.subscription_deliveries 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM public.subscriptions s 
  WHERE s.id = subscription_deliveries.subscription_id 
  AND s.farmer_id = auth.uid()
));

CREATE POLICY "System can manage subscription deliveries" 
ON public.subscription_deliveries 
FOR ALL 
USING (true);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.handle_subscription_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for updated_at
CREATE TRIGGER subscription_plans_updated_at
  BEFORE UPDATE ON public.subscription_plans
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_subscription_updated_at();

CREATE TRIGGER subscriptions_updated_at
  BEFORE UPDATE ON public.subscriptions
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_subscription_updated_at();

CREATE TRIGGER subscription_deliveries_updated_at
  BEFORE UPDATE ON public.subscription_deliveries
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_subscription_updated_at();

-- Create function to generate next delivery dates
CREATE OR REPLACE FUNCTION public.calculate_next_delivery_date(
  start_date DATE,
  interval_type TEXT,
  interval_count INTEGER
) RETURNS DATE AS $$
BEGIN
  CASE interval_type
    WHEN 'weekly' THEN
      RETURN start_date + (interval_count * INTERVAL '1 week')::INTERVAL;
    WHEN 'monthly' THEN
      RETURN start_date + (interval_count * INTERVAL '1 month')::INTERVAL;
    ELSE
      RETURN start_date + INTERVAL '1 week';
  END CASE;
END;
$$ LANGUAGE plpgsql;