-- Add delivery method and delivery fee columns to custom_orders table
ALTER TABLE custom_orders 
ADD COLUMN IF NOT EXISTS delivery_method TEXT DEFAULT 'pickup',
ADD COLUMN IF NOT EXISTS delivery_fee NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS delivery_address TEXT;