-- Create the trigger for farmer application notifications
CREATE TRIGGER farmer_application_notification_trigger
    AFTER INSERT ON public.farmer_applications
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_new_farmer_application();