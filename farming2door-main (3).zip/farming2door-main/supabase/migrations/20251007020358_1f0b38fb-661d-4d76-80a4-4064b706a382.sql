-- Drop existing functions first
DROP FUNCTION IF EXISTS public.log_pii_access(text, text, text);
DROP FUNCTION IF EXISTS public.get_driver_info_for_customer_order(uuid);

-- 1. Create terms acceptance tracking table for legal compliance
CREATE TABLE IF NOT EXISTS public.terms_acceptances (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  accepted_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  ip_address INET,
  user_agent TEXT,
  terms_version TEXT NOT NULL DEFAULT 'v1.0',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on terms acceptances
ALTER TABLE public.terms_acceptances ENABLE ROW LEVEL SECURITY;

-- Drop policies if they exist
DROP POLICY IF EXISTS "Users can view their own terms acceptances" ON public.terms_acceptances;
DROP POLICY IF EXISTS "Users can record their own terms acceptance" ON public.terms_acceptances;
DROP POLICY IF EXISTS "Admins can view all terms acceptances" ON public.terms_acceptances;

-- Policy: Users can view their own terms acceptances
CREATE POLICY "Users can view their own terms acceptances"
ON public.terms_acceptances
FOR SELECT
USING (auth.uid() = user_id);

-- Policy: Only authenticated users can insert their own acceptance
CREATE POLICY "Users can record their own terms acceptance"
ON public.terms_acceptances
FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- Policy: Admins can view all terms acceptances
CREATE POLICY "Admins can view all terms acceptances"
ON public.terms_acceptances
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM user_roles
    WHERE user_id = auth.uid()
    AND role IN ('admin', 'super_admin')
  )
);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_terms_acceptances_user_id ON public.terms_acceptances(user_id);
CREATE INDEX IF NOT EXISTS idx_terms_acceptances_created_at ON public.terms_acceptances(created_at DESC);

-- 2. Enhanced audit logging function for PII access
CREATE OR REPLACE FUNCTION public.log_pii_access(
  table_ref TEXT,
  record_ref TEXT,
  access_type TEXT
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  client_ip TEXT;
  user_agent TEXT;
BEGIN
  -- Safely get request metadata
  BEGIN
    client_ip := COALESCE(
      current_setting('request.headers', true)::json->>'x-forwarded-for',
      'unknown'
    );
    user_agent := COALESCE(
      current_setting('request.headers', true)::json->>'user-agent',
      'unknown'
    );
  EXCEPTION
    WHEN OTHERS THEN
      client_ip := 'unknown';
      user_agent := 'unknown';
  END;

  -- Insert audit log
  INSERT INTO public.security_audit_log (
    user_id,
    action,
    table_name,
    record_id,
    ip_address,
    user_agent,
    created_at
  ) VALUES (
    auth.uid(),
    'PII_ACCESS: ' || access_type,
    table_ref,
    record_ref,
    CASE WHEN client_ip = 'unknown' THEN NULL ELSE client_ip::inet END,
    user_agent,
    now()
  );
EXCEPTION
  WHEN OTHERS THEN
    -- Don't fail if logging fails
    NULL;
END;
$$;

-- 3. Update get_driver_info_for_customer_order to only return limited info
CREATE OR REPLACE FUNCTION public.get_driver_info_for_customer_order(order_id_param UUID)
RETURNS TABLE(
  driver_id UUID,
  first_name TEXT,
  vehicle_type TEXT,
  rating NUMERIC,
  current_latitude NUMERIC,
  current_longitude NUMERIC
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  -- Verify customer owns this order
  IF NOT EXISTS (
    SELECT 1 FROM orders 
    WHERE id = order_id_param 
    AND customer_id = auth.uid()
  ) THEN
    RAISE EXCEPTION 'Access denied: order not found or not owned by user';
  END IF;
  
  -- Log the limited driver info access
  PERFORM log_pii_access(
    'driver_profiles',
    order_id_param::text,
    'customer_limited_driver_view'
  );
  
  -- Return ONLY limited driver info (first name from full_name, vehicle type)
  RETURN QUERY
  SELECT 
    dp.user_id as driver_id,
    -- Extract first name only from full_name
    SPLIT_PART(dp.full_name, ' ', 1) as first_name,
    dp.vehicle_type,
    dp.rating,
    dp.current_latitude,
    dp.current_longitude
  FROM driver_profiles dp
  JOIN driver_order_assignments doa ON dp.user_id = doa.driver_id
  WHERE doa.order_id = order_id_param
  LIMIT 1;
END;
$$;

-- 4. Add audit logging to existing admin secure functions
-- Update get_user_profiles_secure_admin to log access
CREATE OR REPLACE FUNCTION public.get_user_profiles_secure_admin()
RETURNS TABLE(
  id UUID,
  full_name TEXT,
  email TEXT,
  phone TEXT,
  user_type TEXT,
  status TEXT,
  city TEXT,
  state TEXT,
  zip_code TEXT,
  country TEXT,
  profile_picture_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE,
  updated_at TIMESTAMP WITH TIME ZONE
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  -- Verify admin access
  IF NOT EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  ) THEN
    RAISE EXCEPTION 'Access denied: admin role required to view all user profiles';
  END IF;
  
  -- Log the PII access
  PERFORM log_pii_access('profiles', 'bulk_access', 'admin_view_all_profiles');
  
  -- Return all profile data for verified admins
  RETURN QUERY
  SELECT 
    p.id,
    p.full_name,
    p.email,
    p.phone,
    p.user_type,
    p.status,
    p.city,
    p.state,
    p.zip_code,
    p.country,
    p.profile_picture_url,
    p.created_at,
    p.updated_at
  FROM profiles p
  ORDER BY p.created_at DESC;
END;
$$;

-- Update get_all_driver_profiles_secure_admin to log access
CREATE OR REPLACE FUNCTION public.get_all_driver_profiles_secure_admin()
RETURNS TABLE(
  id UUID,
  user_id UUID,
  full_name TEXT,
  email TEXT,
  phone TEXT,
  driver_license_number TEXT,
  vehicle_type TEXT,
  license_plate TEXT,
  is_verified BOOLEAN,
  is_active BOOLEAN,
  current_latitude NUMERIC,
  current_longitude NUMERIC,
  last_location_update TIMESTAMP WITH TIME ZONE,
  rating NUMERIC,
  total_deliveries INTEGER,
  status TEXT,
  created_at TIMESTAMP WITH TIME ZONE,
  updated_at TIMESTAMP WITH TIME ZONE
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  -- Verify admin access
  IF NOT EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  ) THEN
    RAISE EXCEPTION 'Access denied: admin role required to view all driver profiles';
  END IF;
  
  -- Log the PII access
  PERFORM log_pii_access('driver_profiles', 'bulk_access', 'admin_view_all_drivers');
  
  -- Return complete driver profile data for verified admins
  RETURN QUERY
  SELECT 
    dp.id,
    dp.user_id,
    dp.full_name,
    dp.email,
    dp.phone,
    dp.driver_license_number,
    dp.vehicle_type,
    dp.license_plate,
    dp.is_verified,
    dp.is_active,
    dp.current_latitude,
    dp.current_longitude,
    dp.last_location_update,
    dp.rating,
    dp.total_deliveries,
    dp.status,
    dp.created_at,
    dp.updated_at
  FROM driver_profiles dp
  ORDER BY dp.created_at DESC;
END;
$$;