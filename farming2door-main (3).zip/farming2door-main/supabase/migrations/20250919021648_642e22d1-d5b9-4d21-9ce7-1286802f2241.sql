-- Enable real-time functionality for key tables
-- This allows clients to subscribe to real-time changes

-- Add tables to realtime publication
ALTER PUBLICATION supabase_realtime ADD TABLE products;
ALTER PUBLICATION supabase_realtime ADD TABLE orders;
ALTER PUBLICATION supabase_realtime ADD TABLE notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE driver_order_assignments;
ALTER PUBLICATION supabase_realtime ADD TABLE driver_location_history;

-- Set replica identity for real-time updates (to include all column data in updates)
ALTER TABLE products REPLICA IDENTITY FULL;
ALTER TABLE orders REPLICA IDENTITY FULL;
ALTER TABLE notifications REPLICA IDENTITY FULL;
ALTER TABLE driver_order_assignments REPLICA IDENTITY FULL;
ALTER TABLE driver_location_history REPLICA IDENTITY FULL;

-- Create enhanced recommendation functions
CREATE OR REPLACE FUNCTION public.generate_seasonal_recommendations()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Clear old seasonal recommendations
  DELETE FROM product_recommendations 
  WHERE recommendation_type = 'seasonal';
  
  -- Generate seasonal recommendations based on harvest dates
  INSERT INTO product_recommendations (product_id, recommended_product_id, recommendation_type, score)
  WITH seasonal_products AS (
    SELECT 
      p1.id as product1_id,
      p2.id as product2_id,
      -- Score based on how recent the harvest and category similarity
      CASE 
        WHEN p1.category = p2.category THEN 0.8
        WHEN p1.is_organic = p2.is_organic THEN 0.6
        ELSE 0.4
      END as base_score,
      -- Boost score for recently harvested items
      CASE 
        WHEN p2.harvest_date >= CURRENT_DATE - INTERVAL '7 days' THEN 0.3
        WHEN p2.harvest_date >= CURRENT_DATE - INTERVAL '14 days' THEN 0.2
        ELSE 0.1
      END as freshness_boost
    FROM products p1
    CROSS JOIN products p2
    WHERE p1.id != p2.id
    AND p1.is_available = true
    AND p2.is_available = true
    AND p2.harvest_date IS NOT NULL
    AND p2.harvest_date >= CURRENT_DATE - INTERVAL '30 days'
    AND p2.stock_quantity > 0
  )
  SELECT 
    product1_id,
    product2_id,
    'seasonal',
    (base_score + freshness_boost) as final_score
  FROM seasonal_products
  WHERE (base_score + freshness_boost) >= 0.5
  ON CONFLICT (product_id, recommended_product_id, recommendation_type) 
  DO UPDATE SET score = EXCLUDED.score;
END;
$function$;

-- Create function to track user preferences for personalized recommendations
CREATE OR REPLACE FUNCTION public.update_user_preferences(
  p_user_id uuid,
  p_category text,
  p_is_organic boolean DEFAULT null,
  p_price_range text DEFAULT null
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Create or update user preferences table if it doesn't exist
  CREATE TABLE IF NOT EXISTS user_preferences (
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id uuid NOT NULL,
    preferred_categories jsonb DEFAULT '[]'::jsonb,
    prefers_organic boolean DEFAULT null,
    price_preference text DEFAULT null,
    updated_at timestamp with time zone DEFAULT now(),
    UNIQUE(user_id)
  );
  
  -- Enable RLS on user preferences
  ALTER TABLE user_preferences ENABLE ROW LEVEL SECURITY;
  
  -- Create policy for user preferences
  DROP POLICY IF EXISTS "Users can manage their own preferences" ON user_preferences;
  CREATE POLICY "Users can manage their own preferences" ON user_preferences
    FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
  
  -- Update or insert user preferences
  INSERT INTO user_preferences (user_id, preferred_categories, prefers_organic, price_preference)
  VALUES (
    p_user_id,
    jsonb_build_array(p_category),
    p_is_organic,
    p_price_range
  )
  ON CONFLICT (user_id) DO UPDATE SET
    preferred_categories = CASE 
      WHEN user_preferences.preferred_categories ? p_category 
      THEN user_preferences.preferred_categories
      ELSE user_preferences.preferred_categories || jsonb_build_array(p_category)
    END,
    prefers_organic = COALESCE(p_is_organic, user_preferences.prefers_organic),
    price_preference = COALESCE(p_price_range, user_preferences.price_preference),
    updated_at = now();
END;
$function$;

-- Create function to get personalized recommendations based on user behavior
CREATE OR REPLACE FUNCTION public.get_personalized_recommendations(p_user_id uuid, p_limit integer DEFAULT 6)
RETURNS TABLE(
  product_id uuid,
  name text,
  price numeric,
  image_url text,
  farmer_name text,
  category text,
  is_organic boolean,
  recommendation_score numeric
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  RETURN QUERY
  WITH user_behavior AS (
    -- Get user's purchase history
    SELECT 
      oi.product_name,
      p.category,
      p.is_organic,
      p.farmer_id,
      COUNT(*) as purchase_count
    FROM order_items oi
    JOIN orders o ON oi.order_id = o.id
    LEFT JOIN products p ON oi.product_name = p.name
    WHERE o.customer_id = p_user_id
    AND o.status = 'delivered'
    GROUP BY oi.product_name, p.category, p.is_organic, p.farmer_id
  ),
  user_categories AS (
    -- Get most purchased categories
    SELECT category, SUM(purchase_count) as total_purchases
    FROM user_behavior
    WHERE category IS NOT NULL
    GROUP BY category
    ORDER BY total_purchases DESC
    LIMIT 3
  ),
  recommendation_candidates AS (
    SELECT 
      p.id,
      p.name,
      p.price,
      p.image_url,
      p.farmer,
      p.category,
      p.is_organic,
      -- Base score calculation
      CASE 
        WHEN EXISTS (SELECT 1 FROM user_categories uc WHERE uc.category = p.category) THEN 0.7
        ELSE 0.3
      END +
      -- Boost for organic if user tends to buy organic
      CASE 
        WHEN p.is_organic AND (
          SELECT COUNT(*) FROM user_behavior WHERE is_organic = true
        ) > (
          SELECT COUNT(*) FROM user_behavior WHERE is_organic = false
        ) THEN 0.2
        ELSE 0.0
      END +
      -- Boost for high-rated products
      CASE 
        WHEN p.average_rating >= 4.5 THEN 0.2
        WHEN p.average_rating >= 4.0 THEN 0.1
        ELSE 0.0
      END +
      -- Boost for recently harvested
      CASE 
        WHEN p.harvest_date >= CURRENT_DATE - INTERVAL '7 days' THEN 0.1
        ELSE 0.0
      END as score
    FROM products p
    WHERE p.is_available = true
    AND p.stock_quantity > 0
    -- Exclude products user has already bought recently
    AND NOT EXISTS (
      SELECT 1 FROM order_items oi
      JOIN orders o ON oi.order_id = o.id
      WHERE o.customer_id = p_user_id
      AND oi.product_name = p.name
      AND o.created_at >= CURRENT_DATE - INTERVAL '30 days'
    )
  )
  SELECT 
    rc.id as product_id,
    rc.name,
    rc.price,
    rc.image_url,
    rc.farmer as farmer_name,
    rc.category,
    rc.is_organic,
    rc.score as recommendation_score
  FROM recommendation_candidates rc
  WHERE rc.score >= 0.4
  ORDER BY rc.score DESC, rc.price ASC
  LIMIT p_limit;
END;
$function$;

-- Create trigger to automatically update recommendations when orders are delivered
CREATE OR REPLACE FUNCTION public.trigger_recommendation_update()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Only trigger when order status changes to delivered
  IF NEW.status = 'delivered' AND OLD.status != 'delivered' THEN
    -- Schedule background job to update recommendations
    PERFORM pg_notify('update_recommendations', NEW.customer_id::text);
  END IF;
  RETURN NEW;
END;
$function$;

-- Create the trigger
DROP TRIGGER IF EXISTS order_delivered_recommendation_update ON orders;
CREATE TRIGGER order_delivered_recommendation_update
  AFTER UPDATE ON orders
  FOR EACH ROW
  EXECUTE FUNCTION trigger_recommendation_update();

-- Create function to get trending products
CREATE OR REPLACE FUNCTION public.get_trending_products(p_limit integer DEFAULT 8)
RETURNS TABLE(
  product_id uuid,
  name text,
  price numeric,
  image_url text,
  farmer_name text,
  category text,
  is_organic boolean,
  order_count integer,
  avg_rating numeric
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  RETURN QUERY
  WITH product_trends AS (
    SELECT 
      p.id,
      p.name,
      p.price,
      p.image_url,
      p.farmer,
      p.category,
      p.is_organic,
      p.average_rating,
      COUNT(oi.id) as recent_orders
    FROM products p
    LEFT JOIN order_items oi ON p.name = oi.product_name
    LEFT JOIN orders o ON oi.order_id = o.id AND o.created_at >= CURRENT_DATE - INTERVAL '7 days'
    WHERE p.is_available = true
    AND p.stock_quantity > 0
    GROUP BY p.id, p.name, p.price, p.image_url, p.farmer, p.category, p.is_organic, p.average_rating
  )
  SELECT 
    pt.id as product_id,
    pt.name,
    pt.price,
    pt.image_url,
    pt.farmer as farmer_name,
    pt.category,
    pt.is_organic,
    pt.recent_orders::integer as order_count,
    pt.average_rating as avg_rating
  FROM product_trends pt
  ORDER BY pt.recent_orders DESC, pt.average_rating DESC
  LIMIT p_limit;
END;
$function$;