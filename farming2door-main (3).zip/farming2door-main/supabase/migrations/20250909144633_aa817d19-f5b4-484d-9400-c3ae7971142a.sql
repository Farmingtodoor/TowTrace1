-- Function to validate and apply promotion (simplified version since the complex one failed)
CREATE OR REPLACE FUNCTION validate_promotion(
  promotion_code TEXT,
  user_id UUID DEFAULT NULL,
  order_total DECIMAL DEFAULT 0
)
RETURNS TABLE(
  valid BOOLEAN,
  discount_amount DECIMAL,
  error_message TEXT,
  promotion_id UUID
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  promo_record RECORD;
  calculated_discount DECIMAL;
BEGIN
  -- Get promotion details from existing promotions table
  SELECT * INTO promo_record FROM public.promotions 
  WHERE code = promotion_code AND is_active = true
  AND (expires_at IS NULL OR expires_at > now())
  AND starts_at <= now()
  LIMIT 1;
  
  IF NOT FOUND THEN
    RETURN QUERY SELECT false, 0::DECIMAL, 'Invalid or expired promotion code'::TEXT, NULL::UUID;
    RETURN;
  END IF;
  
  -- Check minimum order amount
  IF order_total < promo_record.minimum_order_amount THEN
    RETURN QUERY SELECT false, 0::DECIMAL, 
      ('Order minimum of $' || promo_record.minimum_order_amount::TEXT || ' required')::TEXT, 
      NULL::UUID;
    RETURN;
  END IF;
  
  -- Check usage limits
  IF promo_record.max_uses IS NOT NULL AND promo_record.uses_count >= promo_record.max_uses THEN
    RETURN QUERY SELECT false, 0::DECIMAL, 'Promotion usage limit reached'::TEXT, NULL::UUID;
    RETURN;
  END IF;
  
  -- Calculate discount amount
  IF promo_record.discount_type = 'percentage' THEN
    calculated_discount := (order_total * promo_record.discount_value / 100);
  ELSE
    calculated_discount := promo_record.discount_value;
  END IF;
  
  -- Ensure discount doesn't exceed order total
  calculated_discount := LEAST(calculated_discount, order_total);
  
  RETURN QUERY SELECT true, calculated_discount, NULL::TEXT, promo_record.id::UUID;
END;
$$;