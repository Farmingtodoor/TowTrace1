-- Remove duplicate Uber Eats delivery partner entry
DELETE FROM delivery_partners 
WHERE id = '1bc87971-6f63-4d05-89c5-bbdd9313a708';