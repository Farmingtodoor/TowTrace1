-- Add Flowers category
INSERT INTO public.categories (name, description, icon, display_order, is_active)
VALUES (
  'Flowers',
  'Fresh cut flowers, potted plants, and gardening supplies',
  'Flower',
  8,
  true
);

-- Get the category_id for flowers to use in subcategories
-- Add Flowers subcategories
INSERT INTO public.subcategories (category_id, name, description, display_order, is_active)
SELECT 
  c.id,
  subcategory_data.name,
  subcategory_data.description,
  subcategory_data.display_order,
  true
FROM public.categories c,
(VALUES
  ('Cut Flowers', 'Fresh cut flowers for bouquets and arrangements', 1),
  ('Potted Plants', 'Living plants in containers for home and garden', 2),
  ('Seasonal Bouquets', 'Pre-arranged seasonal flower bouquets', 3),
  ('Wedding & Event Flowers', 'Special occasion and wedding flowers', 4),
  ('Dried Flowers', 'Preserved flowers for long-lasting arrangements', 5),
  ('Seeds & Bulbs', 'Flower seeds, bulbs, and planting materials', 6),
  ('Garden Plants', 'Outdoor flowering plants and perennials', 7),
  ('Indoor Plants', 'Houseplants and indoor flowering varieties', 8),
  ('Herb Plants', 'Flowering herb plants and aromatics', 9),
  ('Decorative Plants', 'Ornamental and decorative flowering plants', 10)
) AS subcategory_data(name, description, display_order)
WHERE c.name = 'Flowers';