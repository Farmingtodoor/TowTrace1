-- Fix security issues in the database

-- 1. Fix JWT secret leak in handle_farmer_approval trigger
CREATE OR REPLACE FUNCTION public.handle_farmer_approval()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  farmer_email TEXT;
  notification_title TEXT;
  notification_message TEXT;
BEGIN
  -- Only process when status changes to 'approved'
  IF NEW.status = 'approved' AND OLD.status != 'approved' THEN
    -- Get farmer email from the application
    farmer_email := NEW.email;
    
    -- Set notification content
    notification_title := 'Farmer Application Approved';
    notification_message := 'Congratulations! Your farmer application has been approved. Welcome to Farm2Door!';
    
    -- Create notification for the farmer
    INSERT INTO public.notifications (user_id, type, title, message)
    VALUES (NEW.user_id, 'application_approved', notification_title, notification_message);
    
    -- Send welcome email asynchronously (removed JWT secret leak)
    PERFORM
      net.http_post(
        url := 'https://njheralnbmbblwqhrncm.supabase.co/functions/v1/send-farmer-welcome-email',
        headers := jsonb_build_object(
          'Content-Type', 'application/json',
          'Authorization', 'Bearer ' || current_setting('request.jwt.claims', true)::json->>'access_token'
        ),
        body := jsonb_build_object(
          'farmer_name', NEW.full_name,
          'farmer_email', farmer_email,
          'farm_name', NEW.farm_name
        )
      );
    
    -- Log for debugging
    RAISE LOG 'Created approval notification for farmer: %', farmer_email;
  END IF;
  
  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error but don't fail the approval process
    RAISE LOG 'Error in handle_farmer_approval: %', SQLERRM;
    RETURN NEW;
END;
$function$;

-- 2. Tighten RLS policies on notifications table to prevent unauthorized admin notifications
DROP POLICY IF EXISTS "System can create admin notifications" ON public.notifications;

-- Only allow system (via service role) to create admin notifications for farmer applications
CREATE POLICY "Service role can create farmer application notifications"
ON public.notifications FOR INSERT
USING (
  -- Only allow if it's a farmer_application notification AND request is from service role
  type = 'farmer_application' 
  AND current_setting('request.jwt.claims', true)::json->>'role' = 'service_role'
);

-- 3. Add a secure function to validate custom order amounts
CREATE OR REPLACE FUNCTION public.get_custom_order_amount(order_uuid uuid)
RETURNS numeric
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  order_amount numeric;
BEGIN
  -- Get the estimated total from the custom order
  SELECT estimated_total INTO order_amount
  FROM public.custom_orders
  WHERE id = order_uuid;
  
  -- Return amount in cents (multiply by 100)
  RETURN COALESCE(order_amount * 100, 0);
END;
$function$;

-- 4. Add HMAC validation function for webhook security
CREATE OR REPLACE FUNCTION public.validate_webhook_signature(
  payload text,
  signature text,
  secret text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $function$
BEGIN
  -- Simple signature validation - in production use proper HMAC-SHA256
  RETURN signature = encode(hmac(payload, secret, 'sha256'), 'hex');
END;
$function$;