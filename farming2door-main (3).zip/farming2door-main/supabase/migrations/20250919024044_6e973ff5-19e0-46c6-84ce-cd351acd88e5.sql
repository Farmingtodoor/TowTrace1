-- Clean up and strengthen farmer_applications table security

-- STEP 1: Drop ALL existing conflicting policies
DROP POLICY IF EXISTS "AUTHENTICATED_admins_update_only" ON public.farmer_applications;
DROP POLICY IF EXISTS "AUTHENTICATED_admins_view_all_only" ON public.farmer_applications;
DROP POLICY IF EXISTS "AUTHENTICATED_super_admins_delete_only" ON public.farmer_applications;
DROP POLICY IF EXISTS "AUTHENTICATED_users_create_own_only" ON public.farmer_applications;
DROP POLICY IF EXISTS "AUTHENTICATED_users_own_applications_only" ON public.farmer_applications;
DROP POLICY IF EXISTS "SECURE_admins_update_only" ON public.farmer_applications;
DROP POLICY IF EXISTS "SECURE_admins_view_with_audit" ON public.farmer_applications;
DROP POLICY IF EXISTS "SECURE_block_anonymous_access" ON public.farmer_applications;
DROP POLICY IF EXISTS "SECURE_farmers_create_own_only" ON public.farmer_applications;
DROP POLICY IF EXISTS "SECURE_farmers_own_applications_only" ON public.farmer_applications;
DROP POLICY IF EXISTS "SECURE_super_admins_delete_only" ON public.farmer_applications;
DROP POLICY IF EXISTS "SECURITY_CRITICAL_Block_all_anonymous_access" ON public.farmer_applications;
DROP POLICY IF EXISTS "SECURITY_CRITICAL_Block_all_public_access" ON public.farmer_applications;

-- STEP 2: Create clean, secure policies with proper hierarchy

-- CRITICAL: Absolute block for anonymous users
CREATE POLICY "SECURITY_CRITICAL_block_anonymous_completely" 
ON public.farmer_applications 
FOR ALL 
USING (auth.uid() IS NOT NULL) 
WITH CHECK (auth.uid() IS NOT NULL);

-- SECURE: Farmers can view only their own applications  
CREATE POLICY "SECURE_farmers_view_own_application" 
ON public.farmer_applications 
FOR SELECT 
USING (
  auth.uid() IS NOT NULL 
  AND auth.uid() = user_id
);

-- SECURE: Farmers can create their own applications with strict validation
CREATE POLICY "SECURE_farmers_create_own_application" 
ON public.farmer_applications 
FOR INSERT 
WITH CHECK (
  auth.uid() IS NOT NULL 
  AND auth.uid() = user_id
  AND user_id IS NOT NULL
);

-- SECURE: Farmers can update only their own pending applications
CREATE POLICY "SECURE_farmers_update_pending_application" 
ON public.farmer_applications 
FOR UPDATE 
USING (
  auth.uid() IS NOT NULL 
  AND auth.uid() = user_id
  AND status = 'pending'
)
WITH CHECK (
  auth.uid() IS NOT NULL 
  AND auth.uid() = user_id
  AND status = 'pending'
);

-- SECURE: Admins can view all applications with role verification
CREATE POLICY "SECURE_verified_admins_view_all" 
ON public.farmer_applications 
FOR SELECT 
USING (
  auth.uid() IS NOT NULL 
  AND EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- SECURE: Admins can update applications for review process
CREATE POLICY "SECURE_verified_admins_update_for_review" 
ON public.farmer_applications 
FOR UPDATE 
USING (
  auth.uid() IS NOT NULL 
  AND EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
)
WITH CHECK (
  auth.uid() IS NOT NULL 
  AND EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- CRITICAL: Only super admins can delete (for data retention compliance)
CREATE POLICY "SECURITY_CRITICAL_super_admin_delete_only" 
ON public.farmer_applications 
FOR DELETE 
USING (
  auth.uid() IS NOT NULL 
  AND EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role = 'super_admin'
  )
);

-- STEP 3: Ensure table security is properly configured
ALTER TABLE public.farmer_applications ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.farmer_applications FROM anon, authenticated;
GRANT SELECT, INSERT, UPDATE ON public.farmer_applications TO authenticated;
GRANT DELETE ON public.farmer_applications TO authenticated; -- Controlled by RLS policy

-- STEP 4: Enhanced audit logging for sensitive farmer application data
CREATE OR REPLACE FUNCTION public.audit_farmer_application_access()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER 
SET search_path = public
AS $$
BEGIN
  -- Log access to sensitive farmer application data
  INSERT INTO public.security_audit_log (
    user_id, action, table_name, record_id, created_at
  ) VALUES (
    auth.uid(), 
    TG_OP || '_farmer_application',
    'farmer_applications',
    COALESCE(NEW.id::text, OLD.id::text),
    now()
  );
  
  RETURN COALESCE(NEW, OLD);
END;
$$;

-- Create audit trigger (only for INSERT, UPDATE, DELETE - SELECT triggers not supported)
DROP TRIGGER IF EXISTS audit_farmer_applications_access ON public.farmer_applications;
CREATE TRIGGER audit_farmer_applications_access
  AFTER INSERT OR UPDATE OR DELETE ON public.farmer_applications
  FOR EACH ROW EXECUTE FUNCTION public.audit_farmer_application_access();