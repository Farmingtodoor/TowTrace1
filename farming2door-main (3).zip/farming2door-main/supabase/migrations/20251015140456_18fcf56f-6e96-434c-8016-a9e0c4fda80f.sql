-- Create breeding stock categories and breeds tables
CREATE TABLE public.breeding_stock_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT,
  icon TEXT,
  display_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE public.breeding_stock_breeds (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id UUID REFERENCES public.breeding_stock_categories(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  type TEXT, -- e.g., "Dairy", "Beef", "Meat", "Wool"
  description TEXT,
  display_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create breeding stock listings table
CREATE TABLE public.breeding_stock_listings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  farmer_id UUID NOT NULL,
  category_id UUID REFERENCES public.breeding_stock_categories(id),
  breed_id UUID REFERENCES public.breeding_stock_breeds(id),
  custom_breed TEXT, -- if breed not in list
  
  -- Basic info
  title TEXT NOT NULL,
  type TEXT NOT NULL, -- e.g., "Bred Heifer", "Proven Buck", "Hatching Eggs"
  sex TEXT, -- M/F/Mixed
  age_months INTEGER,
  date_of_birth DATE,
  weight_lbs NUMERIC,
  
  -- Breeding info
  breeding_status TEXT, -- "open", "bred", "in_milk", "proven_sire", "proven_dam"
  heat_cycle_notes TEXT,
  breeding_guarantee TEXT,
  
  -- Registration & health
  registration_number TEXT,
  registry_name TEXT,
  registration_cert_url TEXT,
  vaccinations JSONB DEFAULT '[]',
  deworming_records JSONB DEFAULT '[]',
  health_tests JSONB DEFAULT '[]', -- TB, Brucellosis, CAE, CL, etc.
  health_certificate_url TEXT,
  
  -- Handling & biosecurity
  temperament TEXT, -- "halter-broke", "gentle", "protective"
  handling_notes TEXT,
  biosecurity_notes TEXT,
  
  -- Pricing & terms
  price NUMERIC NOT NULL,
  deposit_allowed BOOLEAN DEFAULT false,
  deposit_percentage NUMERIC,
  return_refund_terms TEXT,
  
  -- Location & transport
  location_city TEXT,
  location_state TEXT,
  zip_code TEXT,
  latitude NUMERIC,
  longitude NUMERIC,
  transport_pickup BOOLEAN DEFAULT true,
  transport_delivery BOOLEAN DEFAULT false,
  transport_third_party BOOLEAN DEFAULT false,
  delivery_mileage_rate NUMERIC,
  
  -- Media
  photos JSONB DEFAULT '[]',
  videos JSONB DEFAULT '[]',
  
  -- Status
  status TEXT DEFAULT 'active', -- active, reserved, sold, inactive
  is_featured BOOLEAN DEFAULT false,
  views_count INTEGER DEFAULT 0,
  
  -- Contact
  contact_preferences JSONB DEFAULT '{"chat": true, "phone": false}',
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create breeding stock transactions table
CREATE TABLE public.breeding_stock_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID REFERENCES public.breeding_stock_listings(id) ON DELETE CASCADE,
  buyer_id UUID NOT NULL,
  seller_id UUID NOT NULL,
  
  -- Transaction details
  total_price NUMERIC NOT NULL,
  deposit_amount NUMERIC,
  deposit_paid_at TIMESTAMP WITH TIME ZONE,
  balance_amount NUMERIC,
  balance_paid_at TIMESTAMP WITH TIME ZONE,
  
  -- Status
  status TEXT DEFAULT 'inquiry', -- inquiry, reserved, deposit_paid, completed, cancelled
  
  -- Documents
  bill_of_sale_url TEXT,
  health_certificate_url TEXT,
  signed_at TIMESTAMP WITH TIME ZONE,
  
  -- Completion
  pickup_scheduled_date DATE,
  completed_at TIMESTAMP WITH TIME ZONE,
  
  -- Stripe
  stripe_deposit_session_id TEXT,
  stripe_balance_session_id TEXT,
  
  notes TEXT,
  buyer_notes TEXT,
  seller_notes TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create breeding stock inquiries table
CREATE TABLE public.breeding_stock_inquiries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id UUID REFERENCES public.breeding_stock_listings(id) ON DELETE CASCADE,
  buyer_id UUID NOT NULL,
  seller_id UUID NOT NULL,
  
  message TEXT NOT NULL,
  is_read BOOLEAN DEFAULT false,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.breeding_stock_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.breeding_stock_breeds ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.breeding_stock_listings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.breeding_stock_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.breeding_stock_inquiries ENABLE ROW LEVEL SECURITY;

-- RLS Policies for categories and breeds (public read)
CREATE POLICY "Anyone can view active categories" ON public.breeding_stock_categories
  FOR SELECT USING (is_active = true);

CREATE POLICY "Anyone can view active breeds" ON public.breeding_stock_breeds
  FOR SELECT USING (is_active = true);

-- RLS Policies for listings
CREATE POLICY "Anyone can view active listings" ON public.breeding_stock_listings
  FOR SELECT USING (status = 'active' OR status = 'reserved');

CREATE POLICY "Farmers can create their own listings" ON public.breeding_stock_listings
  FOR INSERT WITH CHECK (auth.uid() = farmer_id);

CREATE POLICY "Farmers can update their own listings" ON public.breeding_stock_listings
  FOR UPDATE USING (auth.uid() = farmer_id);

CREATE POLICY "Farmers can delete their own listings" ON public.breeding_stock_listings
  FOR DELETE USING (auth.uid() = farmer_id);

-- RLS Policies for transactions
CREATE POLICY "Buyers and sellers can view their transactions" ON public.breeding_stock_transactions
  FOR SELECT USING (auth.uid() = buyer_id OR auth.uid() = seller_id);

CREATE POLICY "Buyers can create transactions" ON public.breeding_stock_transactions
  FOR INSERT WITH CHECK (auth.uid() = buyer_id);

CREATE POLICY "Buyers and sellers can update transactions" ON public.breeding_stock_transactions
  FOR UPDATE USING (auth.uid() = buyer_id OR auth.uid() = seller_id);

-- RLS Policies for inquiries
CREATE POLICY "Buyers and sellers can view their inquiries" ON public.breeding_stock_inquiries
  FOR SELECT USING (auth.uid() = buyer_id OR auth.uid() = seller_id);

CREATE POLICY "Buyers can create inquiries" ON public.breeding_stock_inquiries
  FOR INSERT WITH CHECK (auth.uid() = buyer_id);

-- Insert initial categories
INSERT INTO public.breeding_stock_categories (name, slug, description, display_order) VALUES
  ('Cattle', 'cattle', 'Dairy and beef breeding cattle', 1),
  ('Goats', 'goats', 'Meat and dairy breeding goats', 2),
  ('Sheep', 'sheep', 'Hair and wool breeding sheep', 3),
  ('Pigs', 'pigs', 'Heritage and commercial breeding pigs', 4),
  ('Poultry', 'poultry', 'Breeding chickens, ducks, geese, and turkeys', 5),
  ('Rabbits', 'rabbits', 'Pedigreed breeding rabbits', 6),
  ('Bees', 'bees', 'NUCs, packages, and queens', 7),
  ('Fish', 'fish', 'Aquaculture breeding stock', 8),
  ('Other', 'other', 'Quail, guinea fowl, and specialty livestock', 9);

-- Insert breeds for Cattle
INSERT INTO public.breeding_stock_breeds (category_id, name, type) 
SELECT id, 'Holstein', 'Dairy' FROM public.breeding_stock_categories WHERE slug = 'cattle'
UNION ALL
SELECT id, 'Jersey', 'Dairy' FROM public.breeding_stock_categories WHERE slug = 'cattle'
UNION ALL
SELECT id, 'Guernsey', 'Dairy' FROM public.breeding_stock_categories WHERE slug = 'cattle'
UNION ALL
SELECT id, 'Brown Swiss', 'Dairy' FROM public.breeding_stock_categories WHERE slug = 'cattle'
UNION ALL
SELECT id, 'Angus', 'Beef' FROM public.breeding_stock_categories WHERE slug = 'cattle'
UNION ALL
SELECT id, 'Hereford', 'Beef' FROM public.breeding_stock_categories WHERE slug = 'cattle'
UNION ALL
SELECT id, 'Charolais', 'Beef' FROM public.breeding_stock_categories WHERE slug = 'cattle'
UNION ALL
SELECT id, 'Limousin', 'Beef' FROM public.breeding_stock_categories WHERE slug = 'cattle'
UNION ALL
SELECT id, 'Brahman', 'Beef' FROM public.breeding_stock_categories WHERE slug = 'cattle';

-- Insert breeds for Goats
INSERT INTO public.breeding_stock_breeds (category_id, name, type)
SELECT id, 'Boer', 'Meat' FROM public.breeding_stock_categories WHERE slug = 'goats'
UNION ALL
SELECT id, 'Kiko', 'Meat' FROM public.breeding_stock_categories WHERE slug = 'goats'
UNION ALL
SELECT id, 'Nubian', 'Dairy' FROM public.breeding_stock_categories WHERE slug = 'goats'
UNION ALL
SELECT id, 'Saanen', 'Dairy' FROM public.breeding_stock_categories WHERE slug = 'goats'
UNION ALL
SELECT id, 'Alpine', 'Dairy' FROM public.breeding_stock_categories WHERE slug = 'goats'
UNION ALL
SELECT id, 'LaMancha', 'Dairy' FROM public.breeding_stock_categories WHERE slug = 'goats';

-- Insert breeds for Sheep
INSERT INTO public.breeding_stock_breeds (category_id, name, type)
SELECT id, 'Dorper', 'Hair' FROM public.breeding_stock_categories WHERE slug = 'sheep'
UNION ALL
SELECT id, 'Katahdin', 'Hair' FROM public.breeding_stock_categories WHERE slug = 'sheep'
UNION ALL
SELECT id, 'Merino', 'Wool' FROM public.breeding_stock_categories WHERE slug = 'sheep'
UNION ALL
SELECT id, 'Suffolk', 'Wool' FROM public.breeding_stock_categories WHERE slug = 'sheep';

-- Insert breeds for Pigs
INSERT INTO public.breeding_stock_breeds (category_id, name, type)
SELECT id, 'Yorkshire', NULL FROM public.breeding_stock_categories WHERE slug = 'pigs'
UNION ALL
SELECT id, 'Berkshire', NULL FROM public.breeding_stock_categories WHERE slug = 'pigs'
UNION ALL
SELECT id, 'Duroc', NULL FROM public.breeding_stock_categories WHERE slug = 'pigs'
UNION ALL
SELECT id, 'Hampshire', NULL FROM public.breeding_stock_categories WHERE slug = 'pigs'
UNION ALL
SELECT id, 'Large Black', NULL FROM public.breeding_stock_categories WHERE slug = 'pigs';

-- Insert breeds for Rabbits
INSERT INTO public.breeding_stock_breeds (category_id, name, type)
SELECT id, 'New Zealand', NULL FROM public.breeding_stock_categories WHERE slug = 'rabbits'
UNION ALL
SELECT id, 'Californian', NULL FROM public.breeding_stock_categories WHERE slug = 'rabbits'
UNION ALL
SELECT id, 'Flemish Giant', NULL FROM public.breeding_stock_categories WHERE slug = 'rabbits'
UNION ALL
SELECT id, 'Rex', NULL FROM public.breeding_stock_categories WHERE slug = 'rabbits';

-- Create indexes for performance
CREATE INDEX idx_breeding_listings_farmer ON public.breeding_stock_listings(farmer_id);
CREATE INDEX idx_breeding_listings_category ON public.breeding_stock_listings(category_id);
CREATE INDEX idx_breeding_listings_status ON public.breeding_stock_listings(status);
CREATE INDEX idx_breeding_listings_location ON public.breeding_stock_listings(location_state, zip_code);
CREATE INDEX idx_breeding_transactions_listing ON public.breeding_stock_transactions(listing_id);
CREATE INDEX idx_breeding_transactions_buyer ON public.breeding_stock_transactions(buyer_id);
CREATE INDEX idx_breeding_inquiries_listing ON public.breeding_stock_inquiries(listing_id);