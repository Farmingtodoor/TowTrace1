-- Simple fix: Drop the remaining views and replace with secure functions
-- This will completely eliminate the RLS bypass issue

-- Drop the views that were bypassing RLS
DROP VIEW IF EXISTS public.approved_farmers_public;
DROP VIEW IF EXISTS public.farmers_public_safe;

-- Create secure replacement functions that use SECURITY DEFINER
-- These functions will access the farmer_applications table with proper permissions
CREATE OR REPLACE FUNCTION public.get_approved_farmers_public()
RETURNS TABLE(
  user_id UUID,
  farm_name TEXT,
  farm_description TEXT,
  categories JSONB,
  subcategories JSONB,
  processing_methods TEXT[],
  certifications TEXT[],
  created_at TIMESTAMP WITH TIME ZONE,
  display_name TEXT,
  general_location TEXT
) AS $$
BEGIN
  -- This function returns only approved, non-sensitive farmer data
  -- Safe for public consumption
  RETURN QUERY
  SELECT 
    fa.user_id,
    fa.farm_name,
    fa.farm_description,
    fa.categories,
    fa.subcategories,
    fa.processing_methods,
    fa.certifications,
    fa.created_at,
    CASE
      WHEN ((fa.farm_name IS NOT NULL) AND (fa.farm_name <> '')) THEN fa.farm_name
      ELSE 'Local Farm'
    END AS display_name,
    CASE
      WHEN (fa.farm_address IS NOT NULL) THEN regexp_replace(fa.farm_address, '[0-9].*', '', 'g')
      ELSE 'Local Area'
    END AS general_location
  FROM farmer_applications fa
  WHERE fa.status = 'approved';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create replacement for farmers_public_safe
CREATE OR REPLACE FUNCTION public.get_farmers_public_safe()
RETURNS TABLE(
  user_id UUID,
  farm_name TEXT,
  farm_description TEXT,
  categories JSONB,
  subcategories JSONB,
  processing_methods TEXT[],
  certifications TEXT[],
  created_at TIMESTAMP WITH TIME ZONE,
  display_name TEXT
) AS $$
BEGIN
  -- This function returns only approved, safe farmer data
  RETURN QUERY
  SELECT 
    fa.user_id,
    fa.farm_name,
    fa.farm_description,
    fa.categories,
    fa.subcategories,
    fa.processing_methods,
    fa.certifications,
    fa.created_at,
    COALESCE(fa.farm_name, 'Local Farm') AS display_name
  FROM farmer_applications fa
  WHERE fa.status = 'approved';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Document these functions as safe for public use
COMMENT ON FUNCTION public.get_approved_farmers_public() IS 
'PUBLIC SAFE: Returns approved farmers with non-sensitive data only. No PII exposed.';

COMMENT ON FUNCTION public.get_farmers_public_safe() IS 
'PUBLIC SAFE: Returns safe data for approved farmers only.';

-- Final security audit log entry
INSERT INTO public.security_audit_log (
  action,
  table_name,
  record_id
) VALUES (
  'SECURITY_FIX_COMPLETE: Removed all views bypassing RLS',
  'farmer_applications',
  'All dangerous views removed, replaced with secure functions'
);