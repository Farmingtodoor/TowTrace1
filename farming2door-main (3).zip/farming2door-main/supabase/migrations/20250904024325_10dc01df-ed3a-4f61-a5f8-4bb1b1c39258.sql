-- Fix farmer_applications security (handle existing policies)

-- 1. Create secure views for public farmer information
CREATE OR REPLACE VIEW public.approved_farmers_public AS
SELECT 
  fa.user_id,
  fa.farm_name,
  fa.farm_description,
  fa.categories,
  fa.subcategories,
  fa.processing_methods,
  fa.certifications,
  fa.created_at,
  -- Generate a display name without exposing full name
  CASE 
    WHEN fa.farm_name IS NOT NULL AND fa.farm_name != '' 
    THEN fa.farm_name
    ELSE 'Local Farm'
  END as display_name
FROM farmer_applications fa
WHERE fa.status = 'approved';

-- 2. Create secure view for authenticated farmer contacts (custom orders only)
CREATE OR REPLACE VIEW public.farmer_contacts_secure AS
SELECT 
  fa.user_id,
  fa.farm_name,
  -- Only expose email to authenticated users for legitimate business purposes
  CASE 
    WHEN auth.uid() IS NOT NULL THEN fa.email
    ELSE NULL
  END as contact_email
FROM farmer_applications fa
WHERE fa.status = 'approved'
  AND auth.uid() IS NOT NULL;

-- 3. Add PII access logging function
CREATE OR REPLACE FUNCTION public.log_pii_access(
  table_name text,
  record_id text,
  access_type text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  client_ip text;
  user_agent text;
BEGIN
  -- Get request metadata safely
  BEGIN
    client_ip := COALESCE(
      current_setting('request.headers', true)::json->>'x-forwarded-for',
      'unknown'
    );
    user_agent := COALESCE(
      current_setting('request.headers', true)::json->>'user-agent',
      'unknown'
    );
  EXCEPTION
    WHEN OTHERS THEN
      client_ip := 'unknown';
      user_agent := 'unknown';
  END;
  
  -- Log PII access attempt
  INSERT INTO security_audit_log (
    user_id,
    action,
    table_name,
    record_id,
    ip_address,
    user_agent
  ) VALUES (
    auth.uid(),
    'pii_access_' || access_type,
    table_name,
    record_id,
    CASE WHEN client_ip = 'unknown' THEN NULL ELSE client_ip::inet END,
    user_agent
  );
EXCEPTION
  WHEN OTHERS THEN
    -- Don't fail the operation if logging fails
    NULL;
END;
$function$;

-- 4. Add email and phone masking functions
CREATE OR REPLACE FUNCTION public.mask_email(email text)
RETURNS text
LANGUAGE plpgsql
IMMUTABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  local_part text;
  domain_part text;
  masked_local text;
BEGIN
  IF email IS NULL THEN
    RETURN NULL;
  END IF;
  
  -- Split email into local and domain parts
  local_part := split_part(email, '@', 1);
  domain_part := split_part(email, '@', 2);
  
  -- Mask the local part (keep first and last character, mask middle)
  IF length(local_part) <= 2 THEN
    masked_local := regexp_replace(local_part, '.', '*', 'g');
  ELSE
    masked_local := left(local_part, 1) || 
                   regexp_replace(substring(local_part, 2, length(local_part)-2), '.', '*', 'g') || 
                   right(local_part, 1);
  END IF;
  
  RETURN masked_local || '@' || domain_part;
END;
$function$;