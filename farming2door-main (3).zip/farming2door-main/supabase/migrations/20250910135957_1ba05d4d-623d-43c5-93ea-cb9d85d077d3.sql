-- Fix duplicate notifications by properly updating the order notification trigger
-- Drop ALL existing triggers and recreate properly
DROP TRIGGER IF EXISTS on_order_created ON public.orders;
DROP TRIGGER IF EXISTS on_order_status_changed ON public.orders;
DROP TRIGGER IF EXISTS order_notifications_trigger ON public.orders;
DROP TRIGGER IF EXISTS new_message_notification_trigger ON public.messages;

-- Create a single consolidated trigger function that handles both inserts and updates
CREATE OR REPLACE FUNCTION public.handle_order_notifications()
RETURNS TRIGGER AS $$
DECLARE
  customer_profile public.profiles%ROWTYPE;
  farmer_profile public.profiles%ROWTYPE;
  notification_payload JSONB;
BEGIN
  -- Get customer and farmer profiles
  SELECT * INTO customer_profile FROM public.profiles WHERE id = NEW.customer_id;
  SELECT * INTO farmer_profile FROM public.profiles WHERE id = NEW.farmer_id;
  
  -- On new order creation, notify farmer
  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.notifications (user_id, type, title, message, order_id)
    VALUES (
      NEW.farmer_id, 
      'order_placed',
      'New Order Received!',
      'You have received a new order from ' || COALESCE(customer_profile.full_name, customer_profile.email),
      NEW.id
    );
    
    -- Send email notification to farmer (direct call, not webhook)
    BEGIN
      SELECT net.http_post(
        url := 'https://njheralnbmbblwqhrncm.supabase.co/functions/v1/send-notification-email',
        headers := jsonb_build_object(
          'Content-Type', 'application/json'
        ),
        body := jsonb_build_object(
          'notification', jsonb_build_object(
            'user_id', NEW.farmer_id,
            'title', 'New Order Received!',
            'message', 'You have received a new order from ' || COALESCE(customer_profile.full_name, customer_profile.email),
            'type', 'order_placed',
            'order_id', NEW.id
          )
        )
      ) INTO notification_payload;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE LOG 'Failed to send email notification for new order: %', SQLERRM;
    END;
  END IF;
  
  -- On status change to delivered, notify both customer and farmer (but only once)
  IF TG_OP = 'UPDATE' AND OLD.status != 'delivered' AND NEW.status = 'delivered' THEN
    -- Notify customer about delivery
    INSERT INTO public.notifications (user_id, type, title, message, order_id)
    VALUES (
      NEW.customer_id,
      'order_delivered', 
      'Order Delivered! 🌾',
      'Your fresh produce has been delivered. Thank you for choosing Farm2Door!',
      NEW.id
    );
    
    -- Send email notification to customer
    BEGIN
      SELECT net.http_post(
        url := 'https://njheralnbmbblwqhrncm.supabase.co/functions/v1/send-notification-email',
        headers := jsonb_build_object(
          'Content-Type', 'application/json'
        ),
        body := jsonb_build_object(
          'notification', jsonb_build_object(
            'user_id', NEW.customer_id,
            'title', 'Order Delivered! 🌾',
            'message', 'Your fresh produce has been delivered. Thank you for choosing Farm2Door!',
            'type', 'order_delivered',
            'order_id', NEW.id
          )
        )
      ) INTO notification_payload;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE LOG 'Failed to send email notification for delivered order: %', SQLERRM;
    END;
    
    -- Notify farmer about successful delivery  
    INSERT INTO public.notifications (user_id, type, title, message, order_id)
    VALUES (
      NEW.farmer_id,
      'order_completed',
      'Order Completed Successfully',
      'Your order to ' || COALESCE(customer_profile.full_name, customer_profile.email) || ' has been delivered.',
      NEW.id
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public';

-- Create a single trigger that handles both insert and update
CREATE TRIGGER order_notifications_trigger
  AFTER INSERT OR UPDATE ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_order_notifications();

-- Update the message notification function to use direct calls too
CREATE OR REPLACE FUNCTION public.handle_new_message_notification()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  conversation_record public.conversations%ROWTYPE;
  recipient_id UUID;
  sender_profile public.profiles%ROWTYPE;
  notification_title TEXT;
  notification_message TEXT;
BEGIN
  -- Get conversation details
  SELECT * INTO conversation_record FROM public.conversations WHERE id = NEW.conversation_id;
  
  -- Get sender profile
  SELECT * INTO sender_profile FROM public.profiles WHERE id = NEW.sender_id;
  
  -- Determine recipient (the other person in the conversation)
  IF NEW.sender_id = conversation_record.customer_id THEN
    recipient_id := conversation_record.farmer_id;
  ELSE
    recipient_id := conversation_record.customer_id;
  END IF;
  
  -- Set notification content
  notification_title := 'New Message';
  notification_message := 'You have a new message from ' || COALESCE(sender_profile.full_name, sender_profile.email);
  
  -- Create notification for the recipient
  INSERT INTO public.notifications (user_id, type, title, message)
  VALUES (recipient_id, 'new_message', notification_title, notification_message);
  
  -- Send email notification asynchronously (direct call)
  BEGIN
    PERFORM net.http_post(
      url := 'https://njheralnbmbblwqhrncm.supabase.co/functions/v1/send-notification-email',
      headers := jsonb_build_object(
        'Content-Type', 'application/json'
      ),
      body := jsonb_build_object(
        'notification', jsonb_build_object(
          'user_id', recipient_id,
          'title', notification_title,
          'message', notification_message,
          'type', 'new_message'
        )
      )
    );
  EXCEPTION
    WHEN OTHERS THEN
      RAISE LOG 'Failed to send email notification for new message: %', SQLERRM;
  END;
  
  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error but don't fail the message insertion
    RAISE LOG 'Error in handle_new_message_notification: %', SQLERRM;
    RETURN NEW;
END;
$function$;

-- Recreate the message trigger
CREATE TRIGGER new_message_notification_trigger
  AFTER INSERT ON public.messages
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_message_notification();