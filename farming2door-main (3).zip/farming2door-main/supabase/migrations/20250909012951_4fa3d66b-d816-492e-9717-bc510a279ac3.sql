-- Create secure admin functions for payout operations
CREATE OR REPLACE FUNCTION public.admin_update_payout_status(
  p_payout_id uuid,
  p_status text,
  p_admin_notes text DEFAULT NULL
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  admin_user_id uuid;
BEGIN
  -- Get the current admin user ID
  admin_user_id := auth.uid();
  
  -- Verify admin access
  IF NOT EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = admin_user_id 
    AND role IN ('admin', 'super_admin')
  ) THEN
    RAISE EXCEPTION 'Access denied: admin role required';
  END IF;
  
  -- Log the admin action for audit trail
  PERFORM log_pii_access(
    'payout_requests', 
    p_payout_id::text, 
    'admin_status_update'
  );
  
  -- Update the payout request status
  UPDATE payout_requests 
  SET 
    status = p_status,
    reviewed_at = CASE WHEN p_status IN ('approved', 'rejected') THEN now() ELSE reviewed_at END,
    reviewed_by = CASE WHEN p_status IN ('approved', 'rejected') THEN admin_user_id ELSE reviewed_by END,
    admin_notes = COALESCE(p_admin_notes, admin_notes),
    updated_at = now()
  WHERE id = p_payout_id;
  
  -- Check if update was successful
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Payout request not found';
  END IF;
  
  RETURN true;
END;
$$;

-- Create function to get masked payout data for admin list view (without sensitive details)
CREATE OR REPLACE FUNCTION public.get_admin_payout_list()
RETURNS TABLE(
  id uuid,
  farmer_id uuid,
  amount numeric,
  status text,
  payment_method text,
  account_holder_masked text,
  account_number_masked text,
  additional_notes text,
  admin_notes text,
  requested_at timestamp with time zone,
  reviewed_at timestamp with time zone,
  reviewed_by uuid,
  created_at timestamp with time zone,
  updated_at timestamp with time zone
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Verify admin access
  IF NOT EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  ) THEN
    RAISE EXCEPTION 'Access denied: admin role required';
  END IF;
  
  -- Return masked data for list view
  RETURN QUERY
  SELECT 
    pr.id,
    pr.farmer_id,
    pr.amount,
    pr.status,
    pr.payment_method,
    CASE 
      WHEN pr.bank_account_holder IS NOT NULL THEN 
        left(pr.bank_account_holder, 1) || '***'
      WHEN pr.bank_account_number IS NOT NULL THEN
        decrypt_sensitive_data(pr.bank_account_holder)
      ELSE 'Not provided'
    END as account_holder_masked,
    CASE 
      WHEN pr.bank_account_number IS NOT NULL THEN 
        '****' || right(pr.bank_account_number, 4)
      ELSE 
        '****' || right(decrypt_sensitive_data(pr.bank_account_number), 4)
    END as account_number_masked,
    pr.additional_notes,
    pr.admin_notes,
    pr.requested_at,
    pr.reviewed_at,
    pr.reviewed_by,
    pr.created_at,
    pr.updated_at
  FROM payout_requests pr
  ORDER BY pr.created_at DESC;
END;
$$;

-- Create function for secure admin access to full payout details (only when needed)
CREATE OR REPLACE FUNCTION public.get_admin_payout_details(p_payout_id uuid)
RETURNS TABLE(
  id uuid,
  farmer_id uuid,
  amount numeric,
  status text,
  payment_method text,
  bank_account_holder text,
  bank_account_number text,
  routing_number text,
  additional_notes text,
  admin_notes text,
  requested_at timestamp with time zone,
  reviewed_at timestamp with time zone,
  reviewed_by uuid,
  created_at timestamp with time zone,
  updated_at timestamp with time zone
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Verify admin access
  IF NOT EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  ) THEN
    RAISE EXCEPTION 'Access denied: admin role required';
  END IF;
  
  -- Log access to sensitive data
  PERFORM log_pii_access(
    'payout_requests', 
    p_payout_id::text, 
    'admin_full_details_access'
  );
  
  -- Return decrypted sensitive data (only for specific payout when needed)
  RETURN QUERY
  SELECT 
    pr.id,
    pr.farmer_id,
    pr.amount,
    pr.status,
    pr.payment_method,
    COALESCE(decrypt_sensitive_data(pr.bank_account_holder), pr.bank_account_holder) as bank_account_holder,
    COALESCE(decrypt_sensitive_data(pr.bank_account_number), pr.bank_account_number) as bank_account_number,
    COALESCE(decrypt_sensitive_data(pr.routing_number), pr.routing_number) as routing_number,
    pr.additional_notes,
    pr.admin_notes,
    pr.requested_at,
    pr.reviewed_at,
    pr.reviewed_by,
    pr.created_at,
    pr.updated_at
  FROM payout_requests pr
  WHERE pr.id = p_payout_id;
END;
$$;

-- Create additional security trigger to prevent direct sensitive data access
CREATE OR REPLACE FUNCTION public.prevent_direct_payout_access()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Log any direct access attempts to payout table (for monitoring)
  PERFORM log_pii_access(
    'payout_requests', 
    COALESCE(NEW.id::text, OLD.id::text), 
    'direct_table_access_' || TG_OP
  );
  
  -- Allow the operation but ensure it's logged
  RETURN COALESCE(NEW, OLD);
END;
$$;

-- Add trigger for monitoring direct access (this helps with security auditing)
DROP TRIGGER IF EXISTS payout_access_audit ON payout_requests;
CREATE TRIGGER payout_access_audit
  AFTER INSERT OR UPDATE OR DELETE ON payout_requests
  FOR EACH ROW EXECUTE FUNCTION prevent_direct_payout_access();