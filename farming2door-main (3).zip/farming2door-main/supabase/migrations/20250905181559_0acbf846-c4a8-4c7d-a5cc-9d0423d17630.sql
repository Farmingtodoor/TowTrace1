-- First, enable pgcrypto extension if not already enabled
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Update the existing encryption/decryption functions to use a consistent key
CREATE OR REPLACE FUNCTION public.encrypt_sensitive_data(data text)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  encryption_key TEXT := 'payout_encryption_key_2024_secure_farm2door';
BEGIN
  -- Use pgcrypto to encrypt sensitive data with consistent key
  IF data IS NULL OR data = '' THEN
    RETURN NULL;
  END IF;
  RETURN encode(encrypt(data::bytea, encryption_key, 'aes'), 'base64');
EXCEPTION
  WHEN OTHERS THEN
    -- Return null if encryption fails
    RETURN NULL;
END;
$function$;

CREATE OR REPLACE FUNCTION public.decrypt_sensitive_data(encrypted_data text)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  encryption_key TEXT := 'payout_encryption_key_2024_secure_farm2door';
BEGIN
  -- Use pgcrypto to decrypt sensitive data with consistent key
  IF encrypted_data IS NULL OR encrypted_data = '' THEN
    RETURN NULL;
  END IF;
  RETURN convert_from(decrypt(decode(encrypted_data, 'base64'), encryption_key, 'aes'), 'UTF8');
EXCEPTION
  WHEN OTHERS THEN
    -- Return original data if decryption fails (could be already decrypted or corrupted)
    RETURN encrypted_data;
END;
$function$;

-- Create a function to safely insert encrypted payout requests
CREATE OR REPLACE FUNCTION insert_encrypted_payout_request(
  p_farmer_id uuid,
  p_amount numeric,
  p_payment_method text DEFAULT 'bank_transfer',
  p_bank_account_holder text DEFAULT NULL,
  p_bank_account_number text DEFAULT NULL,
  p_routing_number text DEFAULT NULL,
  p_additional_notes text DEFAULT NULL
) 
RETURNS uuid 
LANGUAGE plpgsql 
SECURITY DEFINER 
SET search_path TO 'public'
AS $$
DECLARE
  new_id uuid;
BEGIN
  -- Insert with encrypted sensitive data
  INSERT INTO payout_requests (
    farmer_id,
    amount,
    payment_method,
    bank_account_holder,
    bank_account_number,
    routing_number,
    additional_notes
  ) VALUES (
    p_farmer_id,
    p_amount,
    p_payment_method,
    encrypt_sensitive_data(p_bank_account_holder),
    encrypt_sensitive_data(p_bank_account_number),
    encrypt_sensitive_data(p_routing_number),
    p_additional_notes
  ) RETURNING id INTO new_id;
  
  RETURN new_id;
END;
$$;

-- Create a function to safely get decrypted payout requests for authorized users
CREATE OR REPLACE FUNCTION get_decrypted_payout_requests(p_farmer_id uuid DEFAULT NULL)
RETURNS TABLE(
  id uuid,
  farmer_id uuid,
  amount numeric,
  status text,
  payment_method text,
  bank_account_holder text,
  bank_account_number text,
  routing_number text,
  additional_notes text,
  admin_notes text,
  requested_at timestamp with time zone,
  reviewed_at timestamp with time zone,
  reviewed_by uuid,
  created_at timestamp with time zone,
  updated_at timestamp with time zone
) 
LANGUAGE plpgsql 
SECURITY DEFINER 
SET search_path TO 'public'
AS $$
BEGIN
  -- Log access to sensitive payout data
  PERFORM log_pii_access('payout_requests', COALESCE(p_farmer_id::text, 'admin_access'), 'payout_data_access');
  
  -- Check if user is admin or farmer viewing own data
  IF p_farmer_id IS NOT NULL THEN
    -- Farmer viewing own data
    IF auth.uid() != p_farmer_id THEN
      RAISE EXCEPTION 'Access denied: can only view your own payout requests';
    END IF;
  ELSE
    -- Admin viewing all data
    IF NOT EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_id = auth.uid() 
      AND role IN ('admin', 'super_admin')
    ) THEN
      RAISE EXCEPTION 'Access denied: admin role required';
    END IF;
  END IF;
  
  -- Return decrypted data
  RETURN QUERY
  SELECT 
    pr.id,
    pr.farmer_id,
    pr.amount,
    pr.status,
    pr.payment_method,
    COALESCE(decrypt_sensitive_data(pr.bank_account_holder), pr.bank_account_holder) as bank_account_holder,
    COALESCE(decrypt_sensitive_data(pr.bank_account_number), pr.bank_account_number) as bank_account_number,
    COALESCE(decrypt_sensitive_data(pr.routing_number), pr.routing_number) as routing_number,
    pr.additional_notes,
    pr.admin_notes,
    pr.requested_at,
    pr.reviewed_at,
    pr.reviewed_by,
    pr.created_at,
    pr.updated_at
  FROM payout_requests pr
  WHERE 
    CASE 
      WHEN p_farmer_id IS NOT NULL THEN pr.farmer_id = p_farmer_id
      ELSE true
    END
  ORDER BY pr.created_at DESC;
END;
$$;

-- Encrypt existing data if not already encrypted
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN SELECT id, bank_account_number, routing_number, bank_account_holder 
           FROM payout_requests 
           WHERE bank_account_number IS NOT NULL
  LOOP
    -- Only encrypt if the data appears to be unencrypted (not base64)
    IF r.bank_account_number IS NOT NULL AND r.bank_account_number !~ '^[A-Za-z0-9+/]+=*$' THEN
      UPDATE payout_requests 
      SET 
        bank_account_number = encrypt_sensitive_data(r.bank_account_number),
        routing_number = encrypt_sensitive_data(r.routing_number),
        bank_account_holder = encrypt_sensitive_data(r.bank_account_holder)
      WHERE id = r.id;
    END IF;
  END LOOP;
END;
$$;

-- Add comment explaining the security measures
COMMENT ON TABLE payout_requests IS 'Contains encrypted sensitive banking information. Use insert_encrypted_payout_request() and get_decrypted_payout_requests() functions for secure access.';