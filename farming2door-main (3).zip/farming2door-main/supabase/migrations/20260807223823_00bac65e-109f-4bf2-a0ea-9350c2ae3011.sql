CREATE TABLE public.farmer_pickup_slots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  farmer_id uuid NOT NULL,
  day_of_week smallint NOT NULL,
  start_time time NOT NULL,
  end_time time NOT NULL,
  capacity integer NOT NULL DEFAULT 5,
  location_note text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT farmer_pickup_slots_dow_check CHECK (day_of_week BETWEEN 0 AND 6),
  CONSTRAINT farmer_pickup_slots_capacity_check CHECK (capacity > 0 AND capacity <= 500),
  CONSTRAINT farmer_pickup_slots_time_check CHECK (end_time > start_time),
  CONSTRAINT farmer_pickup_slots_unique UNIQUE (farmer_id, day_of_week, start_time, end_time)
);

GRANT SELECT ON public.farmer_pickup_slots TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.farmer_pickup_slots TO authenticated;
GRANT ALL ON public.farmer_pickup_slots TO service_role;

ALTER TABLE public.farmer_pickup_slots ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active pickup slots"
  ON public.farmer_pickup_slots FOR SELECT
  USING (is_active = true);

CREATE POLICY "Farmers can view their own pickup slots"
  ON public.farmer_pickup_slots FOR SELECT TO authenticated
  USING (auth.uid() = farmer_id);

CREATE POLICY "Farmers can create their own pickup slots"
  ON public.farmer_pickup_slots FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = farmer_id);

CREATE POLICY "Farmers can update their own pickup slots"
  ON public.farmer_pickup_slots FOR UPDATE TO authenticated
  USING (auth.uid() = farmer_id)
  WITH CHECK (auth.uid() = farmer_id);

CREATE POLICY "Farmers can delete their own pickup slots"
  ON public.farmer_pickup_slots FOR DELETE TO authenticated
  USING (auth.uid() = farmer_id);

CREATE TRIGGER update_farmer_pickup_slots_updated_at
  BEFORE UPDATE ON public.farmer_pickup_slots
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX idx_farmer_pickup_slots_farmer ON public.farmer_pickup_slots (farmer_id, day_of_week);