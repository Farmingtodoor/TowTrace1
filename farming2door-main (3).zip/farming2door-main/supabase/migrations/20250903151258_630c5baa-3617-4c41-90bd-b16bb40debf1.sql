-- Create custom orders table
CREATE TABLE public.custom_orders (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  customer_id uuid NOT NULL,
  farmer_id uuid NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  requested_products jsonb NOT NULL DEFAULT '[]'::jsonb,
  requested_delivery_date date NOT NULL,
  proposed_delivery_date date NULL,
  customer_notes text,
  farmer_notes text,
  estimated_total numeric,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  responded_at timestamp with time zone NULL
);

-- Enable Row Level Security
ALTER TABLE public.custom_orders ENABLE ROW LEVEL SECURITY;

-- Create policies for custom orders
CREATE POLICY "Customers can view their own custom orders" 
ON public.custom_orders 
FOR SELECT 
USING (auth.uid() = customer_id);

CREATE POLICY "Farmers can view orders sent to them" 
ON public.custom_orders 
FOR SELECT 
USING (auth.uid() = farmer_id);

CREATE POLICY "Customers can create custom orders" 
ON public.custom_orders 
FOR INSERT 
WITH CHECK (auth.uid() = customer_id);

CREATE POLICY "Farmers can update orders sent to them" 
ON public.custom_orders 
FOR UPDATE 
USING (auth.uid() = farmer_id);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_custom_orders_updated_at
BEFORE UPDATE ON public.custom_orders
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Add check constraint for valid status values
ALTER TABLE public.custom_orders 
ADD CONSTRAINT check_custom_order_status 
CHECK (status IN ('pending', 'accepted', 'rejected', 'counter_proposed', 'completed', 'cancelled'));