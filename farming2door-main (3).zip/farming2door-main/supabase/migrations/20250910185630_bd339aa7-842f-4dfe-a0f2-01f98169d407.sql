-- Fix function search path security warnings
ALTER FUNCTION public.calculate_delivery_fee(DECIMAL, DECIMAL, DECIMAL, DECIMAL) SET search_path = public;