-- Update delivery partners with logo URLs
UPDATE delivery_partners 
SET logo_url = '/logos/doordash-logo.png'
WHERE slug = 'doordash';

UPDATE delivery_partners 
SET logo_url = '/logos/uber-eats-logo.png'
WHERE slug = 'uber-eats';