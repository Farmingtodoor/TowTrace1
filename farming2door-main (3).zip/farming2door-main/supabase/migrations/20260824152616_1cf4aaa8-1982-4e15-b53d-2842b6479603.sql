-- 1. Add structured details column to the audit log
ALTER TABLE public.security_audit_log
  ADD COLUMN IF NOT EXISTS details jsonb;

-- 2. Generic sensitive-change audit trigger (logs changed field NAMES only, never values)
CREATE OR REPLACE FUNCTION public.log_sensitive_table_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  changed_fields text[] := '{}';
  k text;
  rec_id text;
BEGIN
  rec_id := CASE WHEN TG_OP = 'DELETE' THEN OLD.id::text ELSE NEW.id::text END;

  IF TG_OP = 'UPDATE' THEN
    FOR k IN
      SELECT n.key
      FROM jsonb_each(to_jsonb(NEW)) n
      JOIN jsonb_each(to_jsonb(OLD)) o ON o.key = n.key
      WHERE n.value IS DISTINCT FROM o.value
    LOOP
      changed_fields := array_append(changed_fields, k);
    END LOOP;
  END IF;

  INSERT INTO public.security_audit_log (
    user_id, action, table_name, record_id, details, created_at
  ) VALUES (
    auth.uid(),
    TG_TABLE_NAME || '_' || lower(TG_OP),
    TG_TABLE_NAME,
    rec_id,
    jsonb_build_object(
      'operation', TG_OP,
      'changed_fields', to_jsonb(changed_fields),
      'actor_role', (SELECT role::text FROM public.user_roles WHERE user_id = auth.uid() LIMIT 1)
    ),
    now()
  );

  RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
EXCEPTION
  WHEN OTHERS THEN
    RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
END;
$function$;

-- 3. Attach to sensitive tables
DROP TRIGGER IF EXISTS audit_driver_order_assignments ON public.driver_order_assignments;
CREATE TRIGGER audit_driver_order_assignments
  AFTER INSERT OR UPDATE OR DELETE ON public.driver_order_assignments
  FOR EACH ROW EXECUTE FUNCTION public.log_sensitive_table_change();

DROP TRIGGER IF EXISTS audit_driver_profiles ON public.driver_profiles;
CREATE TRIGGER audit_driver_profiles
  AFTER INSERT OR UPDATE OR DELETE ON public.driver_profiles
  FOR EACH ROW EXECUTE FUNCTION public.log_sensitive_table_change();

-- replace the older, less detailed customer_insights trigger
DROP TRIGGER IF EXISTS audit_customer_insights_access ON public.customer_insights;
DROP TRIGGER IF EXISTS audit_customer_insights ON public.customer_insights;
CREATE TRIGGER audit_customer_insights
  AFTER INSERT OR UPDATE OR DELETE ON public.customer_insights
  FOR EACH ROW EXECUTE FUNCTION public.log_sensitive_table_change();

-- 4. Log customer reads of driver location (was an unlogged SQL function)
CREATE OR REPLACE FUNCTION public.get_driver_location_for_customer_order(order_id_param uuid)
RETURNS TABLE(current_latitude numeric, current_longitude numeric, last_location_update timestamp with time zone)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.orders
    WHERE id = order_id_param AND customer_id = auth.uid()
  ) THEN
    RAISE EXCEPTION 'Access denied: order not found or not owned by user';
  END IF;

  PERFORM public.log_pii_access('driver_profiles', order_id_param::text, 'customer_driver_location_view');

  RETURN QUERY
  SELECT dp.current_latitude, dp.current_longitude, dp.last_location_update
  FROM public.driver_profiles dp
  JOIN public.driver_order_assignments doa ON doa.driver_id = dp.user_id
  WHERE doa.order_id = order_id_param
  LIMIT 1;
END;
$function$;

REVOKE EXECUTE ON FUNCTION public.get_driver_location_for_customer_order(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_driver_location_for_customer_order(uuid) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.log_sensitive_table_change() FROM PUBLIC, anon, authenticated;