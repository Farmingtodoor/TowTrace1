CREATE OR REPLACE FUNCTION public.admin_set_farmer_location(
  _user_id uuid,
  _city text,
  _state text,
  _zip_code text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_old_city text;
  v_old_state text;
BEGIN
  IF NOT (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'super_admin')) THEN
    RAISE EXCEPTION 'Access denied: admin role required';
  END IF;

  IF coalesce(trim(_city), '') = '' OR coalesce(trim(_state), '') = '' THEN
    RAISE EXCEPTION 'City and state are required';
  END IF;

  IF _zip_code IS NOT NULL AND trim(_zip_code) <> '' AND trim(_zip_code) !~ '^\d{5}$' THEN
    RAISE EXCEPTION 'ZIP code must be 5 digits';
  END IF;

  SELECT city, state INTO v_old_city, v_old_state FROM public.profiles WHERE id = _user_id;

  UPDATE public.profiles
  SET city = trim(_city),
      state = trim(_state),
      zip_code = COALESCE(NULLIF(trim(_zip_code), ''), zip_code),
      updated_at = now()
  WHERE id = _user_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Profile not found';
  END IF;

  INSERT INTO public.security_audit_log (user_id, action, table_name, record_id, details)
  VALUES (
    auth.uid(),
    'admin_set_farmer_location',
    'profiles',
    _user_id::text,
    jsonb_build_object(
      'old_city', v_old_city,
      'old_state', v_old_state,
      'new_city', trim(_city),
      'new_state', trim(_state),
      'new_zip', NULLIF(trim(_zip_code), '')
    )
  );
END;
$$;

REVOKE ALL ON FUNCTION public.admin_set_farmer_location(uuid, text, text, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_set_farmer_location(uuid, text, text, text) TO authenticated;

CREATE OR REPLACE FUNCTION public.get_farms_missing_location()
RETURNS TABLE (
  application_id uuid,
  user_id uuid,
  farm_name text,
  farm_address text,
  status text,
  city text,
  state text,
  zip_code text,
  created_at timestamptz
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'super_admin')) THEN
    RAISE EXCEPTION 'Access denied: admin role required';
  END IF;

  RETURN QUERY
  SELECT fa.id, fa.user_id, fa.farm_name, fa.farm_address, fa.status,
         p.city, p.state, p.zip_code, fa.created_at
  FROM public.farmer_applications fa
  JOIN public.profiles p ON p.id = fa.user_id
  WHERE coalesce(nullif(trim(p.city), ''), '') = ''
     OR coalesce(nullif(trim(p.state), ''), '') = ''
  ORDER BY fa.created_at;
END;
$$;

REVOKE ALL ON FUNCTION public.get_farms_missing_location() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_farms_missing_location() TO authenticated;