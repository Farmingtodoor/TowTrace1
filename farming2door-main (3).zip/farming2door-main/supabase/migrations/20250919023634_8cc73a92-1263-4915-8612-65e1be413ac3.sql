-- Fix function search path security warning

-- Update the audit function to have secure search_path
CREATE OR REPLACE FUNCTION public.audit_payout_access()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER 
SET search_path = public
AS $$
BEGIN
  -- Log all access to payout requests for security monitoring
  INSERT INTO public.security_audit_log (
    user_id, action, table_name, record_id, created_at
  ) VALUES (
    auth.uid(), 
    TG_OP || '_payout_request',
    'payout_requests',
    COALESCE(NEW.id::text, OLD.id::text),
    now()
  );
  
  RETURN COALESCE(NEW, OLD);
END;
$$;