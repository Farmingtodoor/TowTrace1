-- Update the function to also trigger email notifications
CREATE OR REPLACE FUNCTION public.handle_new_farmer_application()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  admin_user RECORD;
  notification_title TEXT;
  notification_message TEXT;
  email_payload JSONB;
BEGIN
  -- Set notification content
  notification_title := 'New Farmer Application Submitted';
  notification_message := 'A new farmer application has been submitted by ' || NEW.full_name || ' from ' || NEW.farm_name || '. Please review and approve or reject the application.';
  
  -- Create notifications for all admin and super_admin users
  FOR admin_user IN 
    SELECT DISTINCT ur.user_id, p.email, p.full_name
    FROM public.user_roles ur
    JOIN public.profiles p ON ur.user_id = p.id
    WHERE ur.role IN ('admin', 'super_admin')
  LOOP
    -- Insert notification for each admin
    INSERT INTO public.notifications (user_id, type, title, message)
    VALUES (admin_user.user_id, 'farmer_application', notification_title, notification_message);
    
    -- Log for debugging
    RAISE LOG 'Created notification for admin: %', admin_user.email;
  END LOOP;
  
  -- Prepare payload for email notification
  email_payload := jsonb_build_object(
    'farmer_name', NEW.full_name,
    'farm_name', NEW.farm_name,
    'application_id', NEW.id::text
  );
  
  -- Send email notifications asynchronously (this will not block the transaction)
  PERFORM
    net.http_post(
      url := 'https://njheralnbmbblwqhrncm.supabase.co/functions/v1/notify-admin-new-application',
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        'Authorization', 'Bearer ' || current_setting('app.jwt_token', true)
      ),
      body := email_payload
    );
  
  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error but don't fail the application submission
    RAISE LOG 'Error in handle_new_farmer_application: %', SQLERRM;
    RETURN NEW;
END;
$$;