-- Comprehensive security fixes for farmer_applications table

-- 1. Add missing DELETE policy (only super_admin can delete applications)
CREATE POLICY "Only super admins can delete applications" 
ON farmer_applications 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role = 'super_admin'::app_role
  )
);

-- 2. Create encrypted versions of sensitive fields
ALTER TABLE farmer_applications 
ADD COLUMN IF NOT EXISTS tax_id_encrypted TEXT,
ADD COLUMN IF NOT EXISTS business_registration_encrypted TEXT,
ADD COLUMN IF NOT EXISTS insurance_details_encrypted TEXT,
ADD COLUMN IF NOT EXISTS phone_encrypted TEXT;

-- 3. Create function to encrypt sensitive farmer application data
CREATE OR REPLACE FUNCTION encrypt_farmer_sensitive_data(data TEXT)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  encryption_key TEXT := 'farmer_app_encryption_key_2024_secure';
BEGIN
  IF data IS NULL OR data = '' THEN
    RETURN NULL;
  END IF;
  
  -- Use pgcrypto for encryption
  RETURN encode(encrypt(data::bytea, encryption_key, 'aes'), 'base64');
EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;
END;
$$;

-- 4. Create function to decrypt sensitive farmer application data
CREATE OR REPLACE FUNCTION decrypt_farmer_sensitive_data(encrypted_data TEXT)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  encryption_key TEXT := 'farmer_app_encryption_key_2024_secure';
BEGIN
  IF encrypted_data IS NULL OR encrypted_data = '' THEN
    RETURN NULL;
  END IF;
  
  -- Use pgcrypto for decryption
  RETURN convert_from(decrypt(decode(encrypted_data, 'base64'), encryption_key, 'aes'), 'UTF8');
EXCEPTION
  WHEN OTHERS THEN
    RETURN encrypted_data; -- Return original if decryption fails
END;
$$;

-- 5. Create trigger to automatically encrypt sensitive data on insert/update
CREATE OR REPLACE FUNCTION encrypt_farmer_application_data()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Encrypt sensitive fields if they're provided
  IF NEW.tax_id IS NOT NULL AND NEW.tax_id != '' THEN
    NEW.tax_id_encrypted := encrypt_farmer_sensitive_data(NEW.tax_id);
    NEW.tax_id := NULL; -- Clear plaintext
  END IF;
  
  IF NEW.business_registration_number IS NOT NULL AND NEW.business_registration_number != '' THEN
    NEW.business_registration_encrypted := encrypt_farmer_sensitive_data(NEW.business_registration_number);
    NEW.business_registration_number := NULL; -- Clear plaintext
  END IF;
  
  IF NEW.insurance_details IS NOT NULL AND NEW.insurance_details != '' THEN
    NEW.insurance_details_encrypted := encrypt_farmer_sensitive_data(NEW.insurance_details);
    NEW.insurance_details := NULL; -- Clear plaintext
  END IF;
  
  IF NEW.phone IS NOT NULL AND NEW.phone != '' THEN
    NEW.phone_encrypted := encrypt_farmer_sensitive_data(NEW.phone);
    NEW.phone := mask_phone(NEW.phone); -- Keep masked version
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create the trigger
DROP TRIGGER IF EXISTS encrypt_farmer_data_trigger ON farmer_applications;
CREATE TRIGGER encrypt_farmer_data_trigger
  BEFORE INSERT OR UPDATE ON farmer_applications
  FOR EACH ROW
  EXECUTE FUNCTION encrypt_farmer_application_data();

-- 6. Create secure view for admin access with decrypted data
CREATE OR REPLACE VIEW farmer_applications_secure AS
SELECT 
  id,
  user_id,
  full_name,
  email,
  CASE 
    WHEN phone_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(phone_encrypted)
    ELSE phone
  END as phone,
  farm_name,
  farm_address,
  farm_size,
  farming_experience,
  farm_description,
  CASE 
    WHEN tax_id_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(tax_id_encrypted)
    ELSE tax_id
  END as tax_id,
  CASE 
    WHEN business_registration_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(business_registration_encrypted)
    ELSE business_registration_number
  END as business_registration_number,
  CASE 
    WHEN insurance_details_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(insurance_details_encrypted)
    ELSE insurance_details
  END as insurance_details,
  categories,
  subcategories,
  processing_methods,
  certifications,
  status,
  admin_notes,
  reviewed_by,
  reviewed_at,
  created_at,
  updated_at
FROM farmer_applications;

-- 7. Add RLS to the secure view (super restrictive)
ALTER VIEW farmer_applications_secure SET (security_barrier = true);

-- 8. Enhanced audit function specifically for sensitive data access
CREATE OR REPLACE FUNCTION log_sensitive_farmer_data_access(
  application_id UUID,
  accessed_fields TEXT[],
  access_reason TEXT DEFAULT 'general_access'
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  client_ip TEXT;
  user_agent TEXT;
BEGIN
  -- Get request metadata
  BEGIN
    client_ip := COALESCE(
      current_setting('request.headers', true)::json->>'x-forwarded-for',
      'unknown'
    );
    user_agent := COALESCE(
      current_setting('request.headers', true)::json->>'user-agent', 
      'unknown'
    );
  EXCEPTION
    WHEN OTHERS THEN
      client_ip := 'unknown';
      user_agent := 'unknown';
  END;

  -- Log sensitive data access
  INSERT INTO security_audit_log (
    user_id,
    action,
    table_name,
    record_id,
    ip_address,
    user_agent
  ) VALUES (
    auth.uid(),
    'sensitive_farmer_data_access: ' || access_reason || ' - fields: ' || array_to_string(accessed_fields, ','),
    'farmer_applications',
    application_id::text,
    CASE WHEN client_ip = 'unknown' THEN NULL ELSE client_ip::inet END,
    user_agent
  );
EXCEPTION
  WHEN OTHERS THEN
    -- Don't fail if logging fails
    NULL;
END;
$$;

-- 9. Create function for secure admin access to farmer applications
CREATE OR REPLACE FUNCTION get_farmer_application_secure(application_id UUID)
RETURNS TABLE(
  id UUID,
  user_id UUID,
  full_name TEXT,
  email TEXT,
  phone TEXT,
  farm_name TEXT,
  farm_address TEXT,
  farm_size TEXT,
  farming_experience TEXT,
  farm_description TEXT,
  tax_id TEXT,
  business_registration_number TEXT,
  insurance_details TEXT,
  categories JSONB,
  subcategories JSONB,
  processing_methods TEXT[],
  certifications TEXT[],
  status TEXT,
  admin_notes TEXT,
  reviewed_by UUID,
  reviewed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE,
  updated_at TIMESTAMP WITH TIME ZONE
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Verify admin access
  IF NOT EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  ) THEN
    RAISE EXCEPTION 'Access denied: admin role required';
  END IF;
  
  -- Log the sensitive data access
  PERFORM log_sensitive_farmer_data_access(
    application_id,
    ARRAY['full_name', 'email', 'phone', 'farm_address', 'tax_id', 'business_registration_number', 'insurance_details'],
    'admin_full_access'
  );
  
  -- Return decrypted data
  RETURN QUERY
  SELECT * FROM farmer_applications_secure 
  WHERE farmer_applications_secure.id = application_id;
END;
$$;

-- 10. Add rate limiting constraint for application submissions
CREATE OR REPLACE FUNCTION check_farmer_application_rate_limit()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  recent_count INTEGER;
BEGIN
  -- Check if user has submitted more than 1 application in the last 24 hours
  SELECT COUNT(*) INTO recent_count
  FROM farmer_applications 
  WHERE user_id = NEW.user_id 
  AND created_at > NOW() - INTERVAL '24 hours';
  
  IF recent_count >= 1 THEN
    RAISE EXCEPTION 'Rate limit exceeded: Only one application per 24 hours allowed';
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create rate limiting trigger
DROP TRIGGER IF EXISTS farmer_application_rate_limit_trigger ON farmer_applications;
CREATE TRIGGER farmer_application_rate_limit_trigger
  BEFORE INSERT ON farmer_applications
  FOR EACH ROW
  EXECUTE FUNCTION check_farmer_application_rate_limit();