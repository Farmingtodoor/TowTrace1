-- Update the get_approved_farmers_public function to include next_harvest_date
CREATE OR REPLACE FUNCTION public.get_approved_farmers_public()
 RETURNS TABLE(user_id uuid, farm_name text, farm_description text, categories jsonb, subcategories jsonb, processing_methods text[], certifications text[], created_at timestamp with time zone, display_name text, general_location text, next_harvest_date date)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  -- This function returns only approved, non-sensitive farmer data
  -- Safe for public consumption
  RETURN QUERY
  SELECT 
    fa.user_id,
    fa.farm_name,
    fa.farm_description,
    fa.categories,
    fa.subcategories,
    fa.processing_methods,
    fa.certifications,
    fa.created_at,
    CASE
      WHEN ((fa.farm_name IS NOT NULL) AND (fa.farm_name <> '')) THEN fa.farm_name
      ELSE 'Local Farm'
    END AS display_name,
    CASE
      WHEN (fa.farm_address IS NOT NULL) THEN regexp_replace(fa.farm_address, '[0-9].*', '', 'g')
      ELSE 'Local Area'
    END AS general_location,
    fa.next_harvest_date
  FROM farmer_applications fa
  WHERE fa.status = 'approved';
END;
$function$