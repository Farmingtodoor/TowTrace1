-- Create trigger for farmer approval notifications
CREATE TRIGGER farmer_approval_notification_trigger
    AFTER UPDATE ON public.farmer_applications
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_farmer_approval();