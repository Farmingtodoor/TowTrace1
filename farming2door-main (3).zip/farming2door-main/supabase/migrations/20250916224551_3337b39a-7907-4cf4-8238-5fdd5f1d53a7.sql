-- Add next harvest date field to farmer applications
ALTER TABLE farmer_applications ADD COLUMN next_harvest_date DATE;

-- Create index for better performance when filtering farmers by harvest dates
CREATE INDEX idx_farmer_applications_next_harvest_date ON farmer_applications(next_harvest_date) WHERE next_harvest_date IS NOT NULL;