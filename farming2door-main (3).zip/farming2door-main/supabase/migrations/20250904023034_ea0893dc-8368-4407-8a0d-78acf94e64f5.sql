-- Fix the security linter warnings

-- 1. Fix search path for all functions to be secure
ALTER FUNCTION public.handle_order_status_change() SET search_path = 'public';
ALTER FUNCTION public.update_updated_at_column() SET search_path = 'public';
ALTER FUNCTION public.has_role(uuid, app_role) SET search_path = 'public';
ALTER FUNCTION public.get_current_user_role() SET search_path = 'public';
ALTER FUNCTION public.handle_new_user_role() SET search_path = 'public';
ALTER FUNCTION public.handle_new_user() SET search_path = 'public';
ALTER FUNCTION public.handle_new_farmer_application() SET search_path = 'public';
ALTER FUNCTION public.handle_farmer_approval() SET search_path = 'public';
ALTER FUNCTION public.validate_farmer_application_email() SET search_path = 'public';
ALTER FUNCTION public.update_product_rating() SET search_path = 'public';
ALTER FUNCTION public.get_custom_order_amount(uuid) SET search_path = 'public';
ALTER FUNCTION public.validate_webhook_signature(text, text, text) SET search_path = 'public';