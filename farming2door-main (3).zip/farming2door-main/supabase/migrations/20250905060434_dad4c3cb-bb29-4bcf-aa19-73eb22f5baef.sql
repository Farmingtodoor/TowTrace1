-- First, enable pgcrypto extension if not already enabled
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Create a function to safely encrypt existing data
CREATE OR REPLACE FUNCTION encrypt_existing_payout_data() 
RETURNS void 
LANGUAGE plpgsql 
SECURITY DEFINER 
AS $$
DECLARE
  r RECORD;
  encryption_key TEXT := 'payout_encryption_key_2024_secure_farm2door';
BEGIN
  -- Set the encryption key for this session
  PERFORM set_config('app.encryption_key', encryption_key, false);
  
  -- Update existing records to encrypt sensitive fields
  FOR r IN SELECT id, bank_account_number, routing_number, bank_account_holder 
           FROM payout_requests 
           WHERE bank_account_number IS NOT NULL
  LOOP
    -- Only encrypt if the data appears to be unencrypted (not base64)
    IF r.bank_account_number !~ '^[A-Za-z0-9+/]+=*$' THEN
      UPDATE payout_requests 
      SET 
        bank_account_number = CASE 
          WHEN r.bank_account_number IS NOT NULL AND r.bank_account_number != '' 
          THEN encode(encrypt(r.bank_account_number::bytea, encryption_key, 'aes'), 'base64')
          ELSE NULL 
        END,
        routing_number = CASE 
          WHEN r.routing_number IS NOT NULL AND r.routing_number != '' 
          THEN encode(encrypt(r.routing_number::bytea, encryption_key, 'aes'), 'base64')
          ELSE NULL 
        END,
        bank_account_holder = CASE 
          WHEN r.bank_account_holder IS NOT NULL AND r.bank_account_holder != '' 
          THEN encode(encrypt(r.bank_account_holder::bytea, encryption_key, 'aes'), 'base64')
          ELSE NULL 
        END
      WHERE id = r.id;
    END IF;
  END LOOP;
END;
$$;

-- Execute the encryption function
SELECT encrypt_existing_payout_data();

-- Drop the temporary function
DROP FUNCTION encrypt_existing_payout_data();

-- Update the existing encryption/decryption functions to use a consistent key
CREATE OR REPLACE FUNCTION public.encrypt_sensitive_data(data text)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  encryption_key TEXT := 'payout_encryption_key_2024_secure_farm2door';
BEGIN
  -- Use pgcrypto to encrypt sensitive data with consistent key
  IF data IS NULL OR data = '' THEN
    RETURN NULL;
  END IF;
  RETURN encode(encrypt(data::bytea, encryption_key, 'aes'), 'base64');
EXCEPTION
  WHEN OTHERS THEN
    -- Return null if encryption fails
    RETURN NULL;
END;
$function$;

CREATE OR REPLACE FUNCTION public.decrypt_sensitive_data(encrypted_data text)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  encryption_key TEXT := 'payout_encryption_key_2024_secure_farm2door';
BEGIN
  -- Use pgcrypto to decrypt sensitive data with consistent key
  IF encrypted_data IS NULL OR encrypted_data = '' THEN
    RETURN NULL;
  END IF;
  RETURN convert_from(decrypt(decode(encrypted_data, 'base64'), encryption_key, 'aes'), 'UTF8');
EXCEPTION
  WHEN OTHERS THEN
    -- Return null if decryption fails (could be already decrypted or corrupted)
    RETURN encrypted_data;
END;
$function$;

-- Create a view for secure payout requests that automatically decrypts data for authorized users
CREATE OR REPLACE VIEW payout_requests_secure AS
SELECT 
  id,
  farmer_id,
  amount,
  status,
  payment_method,
  CASE 
    WHEN bank_account_holder IS NOT NULL THEN decrypt_sensitive_data(bank_account_holder)
    ELSE NULL
  END as bank_account_holder,
  CASE 
    WHEN bank_account_number IS NOT NULL THEN decrypt_sensitive_data(bank_account_number)
    ELSE NULL
  END as bank_account_number,
  CASE 
    WHEN routing_number IS NOT NULL THEN decrypt_sensitive_data(routing_number)
    ELSE NULL
  END as routing_number,
  additional_notes,
  admin_notes,
  requested_at,
  reviewed_at,
  reviewed_by,
  created_at,
  updated_at
FROM payout_requests;

-- Enable RLS on the secure view
ALTER VIEW payout_requests_secure SET (security_barrier = true);

-- Create RLS policies for the secure view (same as the original table)
CREATE POLICY "Farmers can view their own secure payout requests" 
ON payout_requests_secure
FOR SELECT 
USING (auth.uid() = farmer_id);

CREATE POLICY "Admins can view all secure payout requests" 
ON payout_requests_secure
FOR SELECT 
USING (EXISTS ( SELECT 1
 FROM user_roles
WHERE ((user_roles.user_id = auth.uid()) AND (user_roles.role = ANY (ARRAY['admin'::app_role, 'super_admin'::app_role])))));

-- Create a function to safely insert encrypted payout requests
CREATE OR REPLACE FUNCTION insert_encrypted_payout_request(
  p_farmer_id uuid,
  p_amount numeric,
  p_payment_method text DEFAULT 'bank_transfer',
  p_bank_account_holder text DEFAULT NULL,
  p_bank_account_number text DEFAULT NULL,
  p_routing_number text DEFAULT NULL,
  p_additional_notes text DEFAULT NULL
) 
RETURNS uuid 
LANGUAGE plpgsql 
SECURITY DEFINER 
SET search_path TO 'public'
AS $$
DECLARE
  new_id uuid;
BEGIN
  -- Insert with encrypted sensitive data
  INSERT INTO payout_requests (
    farmer_id,
    amount,
    payment_method,
    bank_account_holder,
    bank_account_number,
    routing_number,
    additional_notes
  ) VALUES (
    p_farmer_id,
    p_amount,
    p_payment_method,
    encrypt_sensitive_data(p_bank_account_holder),
    encrypt_sensitive_data(p_bank_account_number),
    encrypt_sensitive_data(p_routing_number),
    p_additional_notes
  ) RETURNING id INTO new_id;
  
  RETURN new_id;
END;
$$;

-- Create audit log for payout access
CREATE OR REPLACE FUNCTION log_payout_access()
RETURNS TRIGGER AS $$
BEGIN
  -- Log access to sensitive payout data
  IF TG_OP = 'SELECT' THEN
    PERFORM log_pii_access('payout_requests', NEW.id::text, 'payout_data_access');
  END IF;
  
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Add comment explaining the security measures
COMMENT ON TABLE payout_requests IS 'Contains encrypted sensitive banking information. Use payout_requests_secure view for decrypted access with proper RLS.';
COMMENT ON VIEW payout_requests_secure IS 'Secure view that automatically decrypts payout data for authorized users only.';