-- Critical Security Fixes - Simplified Version
-- Drop conflicting functions and recreate with new names

DROP FUNCTION IF EXISTS public.encrypt_sensitive_data(text);

-- 1. Create essential security functions with unique names
CREATE OR REPLACE FUNCTION public.farm2door_encrypt(input_data text)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  key_text TEXT := 'farm2door_secure_2024';
BEGIN
  IF input_data IS NULL OR input_data = '' THEN
    RETURN NULL;
  END IF;
  RETURN encode(encrypt(input_data::bytea, key_text, 'aes'), 'base64');
EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;
END;
$$;

-- 2. Create security audit function
CREATE OR REPLACE FUNCTION public.audit_access(
  action_name text,
  table_ref text,
  record_ref text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.security_audit_log (
    user_id, action, table_name, record_id, created_at
  ) VALUES (
    auth.uid(), action_name, table_ref, record_ref, now()
  );
EXCEPTION
  WHEN OTHERS THEN NULL;
END;
$$;

-- 3. Ensure all critical tables have RLS enabled
ALTER TABLE public.customer_insights ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.driver_profiles ENABLE ROW LEVEL SECURITY; 
ALTER TABLE public.payout_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.farmer_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.security_audit_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- 4. Create missing critical security policies
-- Secure user_roles table (very important)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' AND tablename = 'user_roles' 
    AND policyname = 'Users can view their own role'
  ) THEN
    CREATE POLICY "Users can view their own role" ON public.user_roles
    FOR SELECT USING (user_id = auth.uid());
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' AND tablename = 'user_roles' 
    AND policyname = 'Super admins can manage all roles'
  ) THEN
    CREATE POLICY "Super admins can manage all roles" ON public.user_roles
    FOR ALL USING (
      EXISTS (
        SELECT 1 FROM public.user_roles ur 
        WHERE ur.user_id = auth.uid() AND ur.role = 'super_admin'
      )
    );
  END IF;
END $$;

-- 5. Create data masking view for sensitive data
CREATE OR REPLACE VIEW public.safe_customer_insights AS
SELECT 
  id,
  customer_id,
  total_orders,
  total_spent,
  avg_order_value,
  first_order_date,
  last_order_date,
  -- Mask sensitive data
  left(email, 3) || '***@' || split_part(email, '@', 2) as masked_email,
  left(full_name, 1) || '***' as masked_name,
  created_at,
  updated_at
FROM public.customer_insights;

-- 6. Enable RLS on the view
ALTER VIEW public.safe_customer_insights SET (security_barrier = on);

-- 7. Create security monitoring function
CREATE OR REPLACE FUNCTION public.check_system_security()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result jsonb := '{}';
  rls_count integer;
  admin_count integer;
BEGIN
  -- Check RLS status
  SELECT count(*) INTO rls_count
  FROM information_schema.tables t
  WHERE t.table_schema = 'public' 
  AND t.table_name IN ('customer_insights', 'driver_profiles', 'payout_requests')
  AND t.row_security = 'YES';
  
  -- Check admin users
  SELECT count(*) INTO admin_count
  FROM public.user_roles 
  WHERE role IN ('admin', 'super_admin');
  
  result := jsonb_build_object(
    'rls_protected_tables', rls_count,
    'admin_users_count', admin_count,
    'security_status', CASE 
      WHEN rls_count >= 3 AND admin_count > 0 THEN 'SECURE'
      ELSE 'NEEDS_ATTENTION'
    END,
    'last_check', now()
  );
  
  RETURN result;
END;
$$;

-- 8. Add trigger for security logging on critical operations
CREATE OR REPLACE FUNCTION public.log_critical_access()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Log access to sensitive tables
  PERFORM audit_access(TG_OP, TG_TABLE_NAME, 
    CASE WHEN TG_OP = 'DELETE' THEN OLD.id::text ELSE NEW.id::text END
  );
  
  RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
END;
$$;

-- Apply logging triggers to critical tables
DROP TRIGGER IF EXISTS log_payout_access ON public.payout_requests;
CREATE TRIGGER log_payout_access
  AFTER INSERT OR UPDATE OR DELETE ON public.payout_requests
  FOR EACH ROW EXECUTE FUNCTION log_critical_access();

DROP TRIGGER IF EXISTS log_farmer_app_access ON public.farmer_applications;  
CREATE TRIGGER log_farmer_app_access
  AFTER INSERT OR UPDATE OR DELETE ON public.farmer_applications
  FOR EACH ROW EXECUTE FUNCTION log_critical_access();