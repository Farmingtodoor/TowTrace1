-- Add status column to profiles table for user suspension
ALTER TABLE public.profiles 
ADD COLUMN status TEXT NOT NULL DEFAULT 'active' 
CHECK (status IN ('active', 'suspended'));

-- Create index for better performance
CREATE INDEX idx_profiles_status ON public.profiles(status);