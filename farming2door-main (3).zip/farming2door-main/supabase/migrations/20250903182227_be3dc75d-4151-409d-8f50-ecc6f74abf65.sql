-- Add location fields to profiles table
ALTER TABLE public.profiles 
ADD COLUMN country text,
ADD COLUMN state text,
ADD COLUMN city text,
ADD COLUMN zip_code text;

-- Create index for location-based searches
CREATE INDEX idx_profiles_location ON public.profiles(country, state, city, zip_code);
CREATE INDEX idx_profiles_city_zip ON public.profiles(city, zip_code);