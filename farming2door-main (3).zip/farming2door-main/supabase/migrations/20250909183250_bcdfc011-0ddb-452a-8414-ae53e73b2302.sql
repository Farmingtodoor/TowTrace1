-- Create function to handle new message notifications
CREATE OR REPLACE FUNCTION public.handle_new_message_notification()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  conversation_record public.conversations%ROWTYPE;
  recipient_id UUID;
  sender_profile public.profiles%ROWTYPE;
  notification_title TEXT;
  notification_message TEXT;
BEGIN
  -- Get conversation details
  SELECT * INTO conversation_record FROM public.conversations WHERE id = NEW.conversation_id;
  
  -- Get sender profile
  SELECT * INTO sender_profile FROM public.profiles WHERE id = NEW.sender_id;
  
  -- Determine recipient (the other person in the conversation)
  IF NEW.sender_id = conversation_record.customer_id THEN
    recipient_id := conversation_record.farmer_id;
  ELSE
    recipient_id := conversation_record.customer_id;
  END IF;
  
  -- Set notification content
  notification_title := 'New Message';
  notification_message := 'You have a new message from ' || COALESCE(sender_profile.full_name, sender_profile.email);
  
  -- Create notification for the recipient
  INSERT INTO public.notifications (user_id, type, title, message)
  VALUES (recipient_id, 'new_message', notification_title, notification_message);
  
  -- Send email notification asynchronously
  PERFORM
    net.http_post(
      url := 'https://njheralnbmbblwqhrncm.supabase.co/functions/v1/send-message-notification',
      headers := jsonb_build_object(
        'Content-Type', 'application/json'
      ),
      body := jsonb_build_object(
        'recipient_id', recipient_id,
        'sender_name', COALESCE(sender_profile.full_name, sender_profile.email),
        'message_preview', LEFT(NEW.content, 100),
        'conversation_id', conversation_record.id
      )
    );
  
  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error but don't fail the message insertion
    RAISE LOG 'Error in handle_new_message_notification: %', SQLERRM;
    RETURN NEW;
END;
$function$;

-- Create trigger for new messages
CREATE TRIGGER new_message_notification_trigger
  AFTER INSERT ON public.messages
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_message_notification();