-- Create secure views for farmer data protection

-- 1. Create secure public view for farmer listings (no PII)
CREATE VIEW public.farmers_public_safe AS
SELECT 
  fa.user_id,
  fa.farm_name,
  fa.farm_description,
  fa.categories,
  fa.subcategories,
  fa.processing_methods,
  fa.certifications,
  fa.created_at,
  -- Safe display name
  COALESCE(fa.farm_name, 'Local Farm') as display_name
FROM farmer_applications fa
WHERE fa.status = 'approved';

-- 2. Create secure contact view (authenticated users only)
CREATE VIEW public.farmer_contacts_auth AS
SELECT 
  fa.user_id,
  fa.farm_name,
  fa.email as contact_email
FROM farmer_applications fa
WHERE fa.status = 'approved'
  AND auth.uid() IS NOT NULL;

-- Enable RLS on these views
ALTER VIEW public.farmers_public_safe SET (security_barrier = true);
ALTER VIEW public.farmer_contacts_auth SET (security_barrier = true);

-- 3. Add PII masking functions
CREATE OR REPLACE FUNCTION public.mask_email_safe(email text)
RETURNS text
LANGUAGE plpgsql
IMMUTABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  local_part text;
  domain_part text;
BEGIN
  IF email IS NULL OR email = '' THEN
    RETURN 'Contact via platform';
  END IF;
  
  local_part := split_part(email, '@', 1);
  domain_part := split_part(email, '@', 2);
  
  -- Mask most of the email
  IF length(local_part) <= 2 THEN
    RETURN '**@' || domain_part;
  ELSE
    RETURN left(local_part, 1) || '***@' || domain_part;
  END IF;
END;
$function$;