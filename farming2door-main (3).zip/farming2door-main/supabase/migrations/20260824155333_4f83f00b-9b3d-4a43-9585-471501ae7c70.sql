ALTER TABLE public.delivery_waitlist
  ADD COLUMN IF NOT EXISTS notify_delivery boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS notify_pickup boolean NOT NULL DEFAULT true;

CREATE TABLE IF NOT EXISTS public.waitlist_alerts_sent (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  waitlist_id uuid NOT NULL REFERENCES public.delivery_waitlist(id) ON DELETE CASCADE,
  alert_type text NOT NULL CHECK (alert_type IN ('delivery_coverage','pickup_slots')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (waitlist_id, alert_type)
);

GRANT ALL ON public.waitlist_alerts_sent TO service_role;
GRANT SELECT ON public.waitlist_alerts_sent TO authenticated;

ALTER TABLE public.waitlist_alerts_sent ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Waitlist owners and farm owners can view sent alerts"
ON public.waitlist_alerts_sent
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.delivery_waitlist w
    WHERE w.id = waitlist_alerts_sent.waitlist_id
      AND (w.user_id = auth.uid() OR w.farmer_id = auth.uid()
           OR public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'super_admin'))
  )
);

SELECT cron.schedule(
  'waitlist-availability-alerts',
  '*/30 * * * *',
  $$
  SELECT net.http_post(
    url := 'https://njheralnbmbblwqhrncm.supabase.co/functions/v1/notify-waitlist-availability',
    headers := '{"Content-Type": "application/json"}'::jsonb,
    body := '{}'::jsonb
  );
  $$
);