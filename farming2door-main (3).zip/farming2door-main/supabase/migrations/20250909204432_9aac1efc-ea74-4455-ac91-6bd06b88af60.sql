-- Fix security issues: Remove SECURITY DEFINER from views and add proper RLS policies instead

-- Drop existing views and recreate without SECURITY DEFINER
DROP VIEW IF EXISTS public.farmer_revenue_analytics;
DROP VIEW IF EXISTS public.customer_analytics; 
DROP VIEW IF EXISTS public.product_performance_analytics;

-- Create farmer revenue analytics table instead of view for better security
CREATE TABLE public.farmer_revenue_summary (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  farmer_id uuid NOT NULL,
  farm_name text,
  month date NOT NULL,
  total_orders integer DEFAULT 0,
  total_revenue numeric DEFAULT 0,
  avg_order_value numeric DEFAULT 0,
  unique_customers integer DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on farmer revenue summary
ALTER TABLE public.farmer_revenue_summary ENABLE ROW LEVEL SECURITY;

-- Create policies for farmer revenue summary
CREATE POLICY "Farmers can view their own revenue data"
ON public.farmer_revenue_summary FOR SELECT 
USING (auth.uid() = farmer_id);

CREATE POLICY "Admins can view all revenue data"
ON public.farmer_revenue_summary FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM user_roles 
  WHERE user_id = auth.uid() 
  AND role IN ('admin', 'super_admin')
));

-- Create customer insights table instead of view
CREATE TABLE public.customer_insights (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  customer_id uuid NOT NULL,
  full_name text,
  email text,
  total_orders integer DEFAULT 0,
  total_spent numeric DEFAULT 0,
  avg_order_value numeric DEFAULT 0,
  last_order_date timestamp with time zone,
  first_order_date timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on customer insights
ALTER TABLE public.customer_insights ENABLE ROW LEVEL SECURITY;

-- Create policies for customer insights
CREATE POLICY "Users can view their own insights"
ON public.customer_insights FOR SELECT 
USING (auth.uid() = customer_id);

CREATE POLICY "Admins can view all customer insights"
ON public.customer_insights FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM user_roles 
  WHERE user_id = auth.uid() 
  AND role IN ('admin', 'super_admin')
));

-- Create product performance table instead of view
CREATE TABLE public.product_performance (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id uuid NOT NULL,
  name text,
  category text,
  farmer_id uuid,
  farm_name text,
  times_ordered integer DEFAULT 0,
  total_quantity_sold integer DEFAULT 0,
  total_revenue numeric DEFAULT 0,
  avg_rating numeric DEFAULT 0,
  review_count integer DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on product performance
ALTER TABLE public.product_performance ENABLE ROW LEVEL SECURITY;

-- Create policies for product performance
CREATE POLICY "Farmers can view their own product performance"
ON public.product_performance FOR SELECT 
USING (auth.uid() = farmer_id);

CREATE POLICY "Admins can view all product performance"
ON public.product_performance FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM user_roles 
  WHERE user_id = auth.uid() 
  AND role IN ('admin', 'super_admin')
));

-- Create functions to update these analytics tables
CREATE OR REPLACE FUNCTION public.update_farmer_revenue_analytics()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  -- Clear existing data
  DELETE FROM public.farmer_revenue_summary;
  
  -- Insert updated data
  INSERT INTO public.farmer_revenue_summary (
    farmer_id, farm_name, month, total_orders, total_revenue, avg_order_value, unique_customers
  )
  SELECT 
    o.farmer_id,
    fa.farm_name,
    DATE_TRUNC('month', o.created_at)::date as month,
    COUNT(o.id) as total_orders,
    SUM(o.total_amount) as total_revenue,
    AVG(o.total_amount) as avg_order_value,
    COUNT(DISTINCT o.customer_id) as unique_customers
  FROM orders o
  LEFT JOIN farmer_applications fa ON o.farmer_id = fa.user_id
  WHERE o.status = 'delivered'
  GROUP BY o.farmer_id, fa.farm_name, DATE_TRUNC('month', o.created_at)::date;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_customer_insights()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  -- Clear existing data
  DELETE FROM public.customer_insights;
  
  -- Insert updated data
  INSERT INTO public.customer_insights (
    customer_id, full_name, email, total_orders, total_spent, avg_order_value, last_order_date, first_order_date
  )
  SELECT 
    o.customer_id,
    p.full_name,
    p.email,
    COUNT(o.id) as total_orders,
    SUM(o.total_amount) as total_spent,
    AVG(o.total_amount) as avg_order_value,
    MAX(o.created_at) as last_order_date,
    MIN(o.created_at) as first_order_date
  FROM orders o
  LEFT JOIN profiles p ON o.customer_id = p.id
  WHERE o.status = 'delivered'
  GROUP BY o.customer_id, p.full_name, p.email;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_product_performance()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  -- Clear existing data
  DELETE FROM public.product_performance;
  
  -- Insert updated data
  INSERT INTO public.product_performance (
    product_id, name, category, farmer_id, farm_name, times_ordered, 
    total_quantity_sold, total_revenue, avg_rating, review_count
  )
  SELECT 
    p.id as product_id,
    p.name,
    p.category,
    p.farmer_id,
    fa.farm_name,
    COUNT(oi.id) as times_ordered,
    SUM(oi.quantity) as total_quantity_sold,
    SUM(oi.total_price) as total_revenue,
    AVG(r.rating) as avg_rating,
    COUNT(r.id) as review_count
  FROM products p
  LEFT JOIN order_items oi ON p.name = oi.product_name
  LEFT JOIN orders o ON oi.order_id = o.id AND o.status = 'delivered'
  LEFT JOIN reviews r ON p.id = r.product_id
  LEFT JOIN farmer_applications fa ON p.farmer_id = fa.user_id
  GROUP BY p.id, p.name, p.category, p.farmer_id, fa.farm_name;
END;
$$;