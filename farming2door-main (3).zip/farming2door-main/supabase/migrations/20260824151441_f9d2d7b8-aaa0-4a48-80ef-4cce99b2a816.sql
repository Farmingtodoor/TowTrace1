CREATE TABLE public.farmer_delivery_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  farmer_id uuid NOT NULL UNIQUE,
  offers_delivery boolean NOT NULL DEFAULT false,
  delivery_radius_miles numeric NOT NULL DEFAULT 15,
  offers_pickup boolean NOT NULL DEFAULT true,
  delivery_minimum_order numeric NOT NULL DEFAULT 0,
  origin_zip text,
  delivery_notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.farmer_delivery_settings TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.farmer_delivery_settings TO authenticated;
GRANT ALL ON public.farmer_delivery_settings TO service_role;

ALTER TABLE public.farmer_delivery_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Delivery settings are viewable by everyone"
ON public.farmer_delivery_settings FOR SELECT
USING (true);

CREATE POLICY "Farmers can insert their own delivery settings"
ON public.farmer_delivery_settings FOR INSERT TO authenticated
WITH CHECK (auth.uid() = farmer_id);

CREATE POLICY "Farmers can update their own delivery settings"
ON public.farmer_delivery_settings FOR UPDATE TO authenticated
USING (auth.uid() = farmer_id)
WITH CHECK (auth.uid() = farmer_id);

CREATE POLICY "Farmers can delete their own delivery settings"
ON public.farmer_delivery_settings FOR DELETE TO authenticated
USING (auth.uid() = farmer_id);

ALTER TABLE public.farmer_delivery_settings
  ADD CONSTRAINT farmer_delivery_settings_radius_check
  CHECK (delivery_radius_miles > 0 AND delivery_radius_miles <= 50),
  ADD CONSTRAINT farmer_delivery_settings_min_order_check
  CHECK (delivery_minimum_order >= 0);

CREATE TRIGGER update_farmer_delivery_settings_updated_at
BEFORE UPDATE ON public.farmer_delivery_settings
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();