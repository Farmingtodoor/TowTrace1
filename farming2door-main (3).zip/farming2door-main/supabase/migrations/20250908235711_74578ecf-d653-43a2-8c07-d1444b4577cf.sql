-- CRITICAL: Fix public access to farmer_applications table
-- The table is still publicly accessible despite RLS being enabled

-- First, let's check and fix any policies that might allow public access
-- Drop all existing policies and recreate them with proper authentication checks

-- Drop existing policies
DROP POLICY IF EXISTS "Admins can update all applications" ON public.farmer_applications;
DROP POLICY IF EXISTS "Admins can view all applications with audit" ON public.farmer_applications;
DROP POLICY IF EXISTS "Only super admins can delete applications" ON public.farmer_applications;
DROP POLICY IF EXISTS "Users can create their own applications" ON public.farmer_applications;
DROP POLICY IF EXISTS "Users can view own applications with audit" ON public.farmer_applications;

-- Create strict new policies that require authentication
-- 1. Only authenticated admins can view all applications
CREATE POLICY "Admins can view all applications" 
ON public.farmer_applications 
FOR SELECT 
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- 2. Only authenticated users can view their own applications
CREATE POLICY "Users can view own applications" 
ON public.farmer_applications 
FOR SELECT 
TO authenticated
USING (auth.uid() = user_id);

-- 3. Only authenticated users can create their own applications
CREATE POLICY "Users can create own applications" 
ON public.farmer_applications 
FOR INSERT 
TO authenticated
WITH CHECK (auth.uid() = user_id);

-- 4. Only authenticated admins can update applications
CREATE POLICY "Admins can update applications" 
ON public.farmer_applications 
FOR UPDATE 
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- 5. Only authenticated super admins can delete applications
CREATE POLICY "Super admins can delete applications" 
ON public.farmer_applications 
FOR DELETE 
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() 
    AND role = 'super_admin'
  )
);

-- 6. Explicitly deny all access to anonymous users
CREATE POLICY "Block anonymous access" 
ON public.farmer_applications 
FOR ALL 
TO anon
USING (false);

-- Log this security fix
INSERT INTO public.security_audit_log (
  action,
  table_name,
  record_id
) VALUES (
  'SECURITY_FIX: Blocked anonymous access to farmer_applications',
  'farmer_applications',
  'Fixed public access vulnerability - now requires authentication'
);