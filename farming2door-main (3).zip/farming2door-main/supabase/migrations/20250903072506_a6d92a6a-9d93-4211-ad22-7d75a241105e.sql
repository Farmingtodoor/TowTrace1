-- Create profiles table for user information
CREATE TABLE public.profiles (
  id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  email TEXT NOT NULL,
  full_name TEXT,
  phone TEXT,
  user_type TEXT NOT NULL CHECK (user_type IN ('farmer', 'customer')) DEFAULT 'customer',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Create policies for profiles
CREATE POLICY "Users can view their own profile" 
ON public.profiles 
FOR SELECT 
USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile" 
ON public.profiles 
FOR UPDATE 
USING (auth.uid() = id);

CREATE POLICY "Users can insert their own profile" 
ON public.profiles 
FOR INSERT 
WITH CHECK (auth.uid() = id);

-- Create orders table
CREATE TABLE public.orders (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  customer_id UUID NOT NULL REFERENCES public.profiles(id),
  farmer_id UUID NOT NULL REFERENCES public.profiles(id),
  status TEXT NOT NULL CHECK (status IN ('pending', 'confirmed', 'processing', 'ready', 'out_for_delivery', 'delivered', 'cancelled')) DEFAULT 'pending',
  total_amount DECIMAL(10,2) NOT NULL,
  delivery_type TEXT NOT NULL CHECK (delivery_type IN ('pickup', 'delivery')) DEFAULT 'pickup',
  delivery_address TEXT,
  customer_notes TEXT,
  farmer_notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS for orders
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

-- Create policies for orders
CREATE POLICY "Customers can view their own orders" 
ON public.orders 
FOR SELECT 
USING (auth.uid() = customer_id);

CREATE POLICY "Farmers can view orders for their products" 
ON public.orders 
FOR SELECT 
USING (auth.uid() = farmer_id);

CREATE POLICY "Customers can create orders" 
ON public.orders 
FOR INSERT 
WITH CHECK (auth.uid() = customer_id);

CREATE POLICY "Farmers can update orders for their products" 
ON public.orders 
FOR UPDATE 
USING (auth.uid() = farmer_id);

-- Create order items table
CREATE TABLE public.order_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  product_name TEXT NOT NULL,
  product_description TEXT,
  quantity INTEGER NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  total_price DECIMAL(10,2) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS for order items
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;

-- Create policies for order items
CREATE POLICY "Users can view order items for their orders" 
ON public.order_items 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.orders 
    WHERE orders.id = order_items.order_id 
    AND (orders.customer_id = auth.uid() OR orders.farmer_id = auth.uid())
  )
);

-- Create notifications table
CREATE TABLE public.notifications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.profiles(id),
  type TEXT NOT NULL CHECK (type IN ('order_placed', 'order_confirmed', 'order_processing', 'order_ready', 'order_out_for_delivery', 'order_delivered')),
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  order_id UUID REFERENCES public.orders(id),
  read BOOLEAN NOT NULL DEFAULT false,
  sent_email BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS for notifications
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Create policies for notifications
CREATE POLICY "Users can view their own notifications" 
ON public.notifications 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own notifications" 
ON public.notifications 
FOR UPDATE 
USING (auth.uid() = user_id);

-- Create function to handle new user profile creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (
    NEW.id, 
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', '')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for new user profile creation
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Create function to send notifications when order status changes
CREATE OR REPLACE FUNCTION public.handle_order_status_change()
RETURNS TRIGGER AS $$
DECLARE
  customer_profile public.profiles%ROWTYPE;
  farmer_profile public.profiles%ROWTYPE;
  notification_title TEXT;
  customer_message TEXT;
  farmer_message TEXT;
BEGIN
  -- Get customer and farmer profiles
  SELECT * INTO customer_profile FROM public.profiles WHERE id = NEW.customer_id;
  SELECT * INTO farmer_profile FROM public.profiles WHERE id = NEW.farmer_id;
  
  -- Set notification content based on status
  CASE NEW.status
    WHEN 'pending' THEN
      -- New order placed - notify farmer
      notification_title := 'New Order Received';
      farmer_message := 'You have received a new order from ' || COALESCE(customer_profile.full_name, customer_profile.email);
      
      INSERT INTO public.notifications (user_id, type, title, message, order_id)
      VALUES (NEW.farmer_id, 'order_placed', notification_title, farmer_message, NEW.id);
      
    WHEN 'confirmed' THEN
      -- Order confirmed - notify customer
      notification_title := 'Order Confirmed';
      customer_message := 'Your order has been confirmed by ' || COALESCE(farmer_profile.full_name, farmer_profile.email);
      
      INSERT INTO public.notifications (user_id, type, title, message, order_id)
      VALUES (NEW.customer_id, 'order_confirmed', notification_title, customer_message, NEW.id);
      
    WHEN 'processing' THEN
      -- Order processing - notify customer
      notification_title := 'Order Being Prepared';
      customer_message := 'Your order is now being prepared by ' || COALESCE(farmer_profile.full_name, farmer_profile.email);
      
      INSERT INTO public.notifications (user_id, type, title, message, order_id)
      VALUES (NEW.customer_id, 'order_processing', notification_title, customer_message, NEW.id);
      
    WHEN 'ready' THEN
      -- Order ready - notify customer
      notification_title := 'Order Ready for ' || CASE WHEN NEW.delivery_type = 'pickup' THEN 'Pickup' ELSE 'Delivery' END;
      customer_message := 'Your order is ready for ' || CASE WHEN NEW.delivery_type = 'pickup' THEN 'pickup' ELSE 'delivery' END || '!';
      
      INSERT INTO public.notifications (user_id, type, title, message, order_id)
      VALUES (NEW.customer_id, 'order_ready', notification_title, customer_message, NEW.id);
      
    WHEN 'out_for_delivery' THEN
      -- Order out for delivery - notify customer
      notification_title := 'Order Out for Delivery';
      customer_message := 'Your order is on the way! Expected delivery soon.';
      
      INSERT INTO public.notifications (user_id, type, title, message, order_id)
      VALUES (NEW.customer_id, 'order_out_for_delivery', notification_title, customer_message, NEW.id);
      
    WHEN 'delivered' THEN
      -- Order delivered - notify customer
      notification_title := 'Order Delivered';
      customer_message := 'Your order has been delivered. Thank you for choosing Farm2Door!';
      
      INSERT INTO public.notifications (user_id, type, title, message, order_id)
      VALUES (NEW.customer_id, 'order_delivered', notification_title, customer_message, NEW.id);
  END CASE;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for order status changes
CREATE TRIGGER on_order_status_change
  AFTER INSERT OR UPDATE OF status ON public.orders
  FOR EACH ROW EXECUTE FUNCTION public.handle_order_status_change();

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_orders_updated_at
  BEFORE UPDATE ON public.orders
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();