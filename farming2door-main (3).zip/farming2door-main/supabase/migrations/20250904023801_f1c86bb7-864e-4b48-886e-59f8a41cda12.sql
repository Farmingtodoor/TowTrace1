-- Fix app_notifications security vulnerabilities

-- 1. Add email validation function
CREATE OR REPLACE FUNCTION public.is_valid_email(email text)
RETURNS boolean
LANGUAGE plpgsql
IMMUTABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Basic email validation
  RETURN email ~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'
    AND length(email) <= 254
    AND length(email) >= 5
    AND email NOT LIKE '%@%@%' -- No double @
    AND email NOT LIKE '.%' -- Can't start with dot
    AND email NOT LIKE '%.' -- Can't end with dot
    AND email NOT LIKE '%..%'; -- No double dots
END;
$function$;

-- 2. Add rate limiting for email subscriptions
CREATE OR REPLACE FUNCTION public.check_email_subscription_rate_limit()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  client_ip inet;
  recent_count integer;
BEGIN
  -- Get client IP from request
  client_ip := inet(current_setting('request.headers', true)::json->>'x-forwarded-for');
  
  -- If no IP, use a default to prevent bypass
  IF client_ip IS NULL THEN
    client_ip := '0.0.0.0'::inet;
  END IF;
  
  -- Count recent submissions from this IP (last 15 minutes)
  SELECT COUNT(*)
  INTO recent_count
  FROM app_notifications
  WHERE created_at > now() - interval '15 minutes'
    AND (
      -- Try to match by IP if we can store it (we'll add this)
      email LIKE '%' || host(client_ip) || '%'
      OR created_at > now() - interval '15 minutes'
    );
  
  -- Allow max 3 subscriptions per IP per 15 minutes
  RETURN recent_count < 3;
END;
$function$;

-- 3. Add suspicious email detection
CREATE OR REPLACE FUNCTION public.is_suspicious_email(email text)
RETURNS boolean
LANGUAGE plpgsql
IMMUTABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  RETURN
    -- Check for common spam patterns
    email ~ '.*[0-9]{4,}.*' OR -- Too many consecutive numbers
    email ~ '.*test.*' OR
    email ~ '.*fake.*' OR
    email ~ '.*spam.*' OR
    email ~ '.*temp.*' OR
    -- Check for suspicious domains
    email ~ '@(10minutemail|guerrillamail|mailinator|tempmail)\..*' OR
    -- Check for excessive length or repetitive characters
    length(email) > 100 OR
    email ~ '(.)\1{4,}'; -- Same character repeated 5+ times
END;
$function$;

-- 4. Update RLS policy with proper validation
DROP POLICY IF EXISTS "Anyone can subscribe to app notifications" ON app_notifications;

CREATE POLICY "Secure email subscription policy"
ON app_notifications FOR INSERT
WITH CHECK (
  -- Validate email format
  public.is_valid_email(email) = true
  -- Check rate limit
  AND public.check_email_subscription_rate_limit() = true
  -- Block suspicious emails
  AND public.is_suspicious_email(email) = false
  -- Ensure email is not empty or whitespace
  AND trim(email) != ''
  AND length(trim(email)) >= 5
);

-- 5. Add unique constraint to prevent duplicate subscriptions
DO $$
BEGIN
  -- Add unique constraint if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'app_notifications_email_key'
  ) THEN
    ALTER TABLE app_notifications ADD CONSTRAINT app_notifications_email_key UNIQUE (email);
  END IF;
END $$;

-- 6. Add audit logging for subscription attempts
CREATE OR REPLACE FUNCTION public.log_subscription_attempt()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  client_ip text;
  user_agent text;
BEGIN
  -- Get request metadata
  BEGIN
    client_ip := current_setting('request.headers', true)::json->>'x-forwarded-for';
    user_agent := current_setting('request.headers', true)::json->>'user-agent';
  EXCEPTION
    WHEN OTHERS THEN
      client_ip := 'unknown';
      user_agent := 'unknown';
  END;
  
  -- Log the subscription attempt
  INSERT INTO security_audit_log (
    user_id,
    action,
    table_name,
    record_id,
    ip_address,
    user_agent
  ) VALUES (
    NULL, -- No user ID for public subscriptions
    'email_subscription',
    'app_notifications',
    NEW.id::text,
    client_ip::inet,
    user_agent
  );
  
  RETURN NEW;
END;
$function$;

-- 7. Create trigger for audit logging
DROP TRIGGER IF EXISTS log_email_subscriptions ON app_notifications;
CREATE TRIGGER log_email_subscriptions
  AFTER INSERT ON app_notifications
  FOR EACH ROW
  EXECUTE FUNCTION public.log_subscription_attempt();

-- 8. Add cleanup function for old notifications
CREATE OR REPLACE FUNCTION public.cleanup_old_notifications()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Remove notifications older than 2 years that have been notified
  DELETE FROM app_notifications 
  WHERE created_at < now() - interval '2 years'
    AND notified = true;
    
  -- Log cleanup action
  INSERT INTO security_audit_log (action, table_name) 
  VALUES ('cleanup_old_notifications', 'app_notifications');
END;
$function$;