-- Add Nuts & Seeds category
INSERT INTO public.categories (name, description, icon, display_order, is_active)
VALUES (
  'Nuts & Seeds',
  'Fresh unprocessed nuts, seeds, and tree fruits',
  'Nut',
  9,
  true
);

-- Add Nuts & Seeds subcategories
INSERT INTO public.subcategories (category_id, name, description, display_order, is_active)
SELECT 
  c.id,
  subcategory_data.name,
  subcategory_data.description,
  subcategory_data.display_order,
  true
FROM public.categories c,
(VALUES
  ('Peanuts', 'Fresh peanuts in shell and raw peanuts', 1),
  ('Sunflower Seeds', 'Raw sunflower seeds and kernels', 2),
  ('Fresh Coconuts', 'Whole fresh coconuts and coconut products', 3),
  ('Tree Nuts', 'Walnuts, Pecans, Almonds, Hazelnuts', 4),
  ('Seasonal Nuts', 'Seasonal and locally grown nuts', 5),
  ('Specialty Seeds', 'Pumpkin seeds, chia, flax, and other seeds', 6)
) AS subcategory_data(name, description, display_order)
WHERE c.name = 'Nuts & Seeds';