-- Update category name from Meat to Livestock
UPDATE categories 
SET name = 'Livestock', 
    description = 'Premium grass-fed livestock, free-range animals, and custom processing options',
    updated_at = now()
WHERE name = 'Meat';

-- Update existing subcategories to match requirements
UPDATE subcategories 
SET name = 'Cows', 
    display_order = 1,
    updated_at = now()
WHERE category_id = '4cea093a-2644-4238-8345-7f4c9aa149c2' 
AND name = 'Beef Cattle';

UPDATE subcategories 
SET name = 'Pigs', 
    display_order = 6,
    updated_at = now()
WHERE category_id = '4cea093a-2644-4238-8345-7f4c9aa149c2' 
AND name = 'Pork';

-- Remove unwanted subcategories
DELETE FROM subcategories 
WHERE category_id = '4cea093a-2644-4238-8345-7f4c9aa149c2' 
AND name IN ('Lamb & Goat', 'Game Meat', 'Custom Processing');

-- Add missing subcategories (avoiding duplicates)
INSERT INTO subcategories (category_id, name, display_order, is_active) 
SELECT '4cea093a-2644-4238-8345-7f4c9aa149c2', 'Goats', 2, true
WHERE NOT EXISTS (
    SELECT 1 FROM subcategories 
    WHERE category_id = '4cea093a-2644-4238-8345-7f4c9aa149c2' AND name = 'Goats'
);

INSERT INTO subcategories (category_id, name, display_order, is_active) 
SELECT '4cea093a-2644-4238-8345-7f4c9aa149c2', 'Lambs', 3, true
WHERE NOT EXISTS (
    SELECT 1 FROM subcategories 
    WHERE category_id = '4cea093a-2644-4238-8345-7f4c9aa149c2' AND name = 'Lambs'
);

INSERT INTO subcategories (category_id, name, display_order, is_active) 
SELECT '4cea093a-2644-4238-8345-7f4c9aa149c2', 'Chickens', 4, true
WHERE NOT EXISTS (
    SELECT 1 FROM subcategories 
    WHERE category_id = '4cea093a-2644-4238-8345-7f4c9aa149c2' AND name = 'Chickens'
);

INSERT INTO subcategories (category_id, name, display_order, is_active) 
SELECT '4cea093a-2644-4238-8345-7f4c9aa149c2', 'Turkeys', 5, true
WHERE NOT EXISTS (
    SELECT 1 FROM subcategories 
    WHERE category_id = '4cea093a-2644-4238-8345-7f4c9aa149c2' AND name = 'Turkeys'
);

-- Update Poultry to have correct display order if it exists
UPDATE subcategories 
SET display_order = 4,
    updated_at = now()
WHERE category_id = '4cea093a-2644-4238-8345-7f4c9aa149c2' 
AND name = 'Poultry';