-- CRITICAL SECURITY FIX: Driver Profiles Data Protection
-- This addresses the security vulnerability where sensitive driver personal information 
-- could be accessed by unauthorized users

-- Ensure RLS is properly enabled
ALTER TABLE public.driver_profiles ENABLE ROW LEVEL SECURITY;

-- Drop existing policies to recreate with stronger security
DROP POLICY IF EXISTS "Admins can view all driver profiles" ON public.driver_profiles;
DROP POLICY IF EXISTS "Customers can view basic driver info for their orders" ON public.driver_profiles;
DROP POLICY IF EXISTS "Drivers can view and edit their own profile" ON public.driver_profiles;

-- Policy 1: Drivers can ONLY view and manage their own profile
CREATE POLICY "SECURE_drivers_own_profile_only" 
ON public.driver_profiles 
FOR ALL
USING (auth.uid() = user_id AND auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() = user_id AND auth.uid() IS NOT NULL);

-- Policy 2: Only verified admins can view all driver profiles (with audit logging)
CREATE POLICY "SECURE_admins_view_all_drivers_only" 
ON public.driver_profiles 
FOR SELECT 
USING (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- Policy 3: Customers can view LIMITED driver info for their orders only (no sensitive data)
CREATE POLICY "SECURE_customers_limited_driver_info_only" 
ON public.driver_profiles 
FOR SELECT 
USING (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1
    FROM driver_order_assignments doa
    JOIN orders o ON doa.order_id = o.id
    WHERE doa.driver_id = driver_profiles.user_id 
    AND o.customer_id = auth.uid()
  )
);

-- Policy 4: Block ALL anonymous access completely
CREATE POLICY "SECURE_block_anonymous_driver_access" 
ON public.driver_profiles 
FOR ALL
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);

-- Policy 5: No DELETE operations allowed (protect audit trail)
CREATE POLICY "SECURE_no_delete_driver_profiles" 
ON public.driver_profiles 
FOR DELETE 
USING (false);

-- Create secure function for customer access to limited driver info
CREATE OR REPLACE FUNCTION public.get_driver_info_for_customer_order(order_id_param uuid)
RETURNS TABLE(
  driver_id uuid,
  full_name text,
  vehicle_type text,
  license_plate text,
  rating numeric,
  current_latitude numeric,
  current_longitude numeric,
  phone_masked text
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Verify customer owns this order
  IF NOT EXISTS (
    SELECT 1 FROM orders 
    WHERE id = order_id_param 
    AND customer_id = auth.uid()
  ) THEN
    RAISE EXCEPTION 'Access denied: order not found or not owned by user';
  END IF;
  
  -- Log the driver info access for audit trail
  INSERT INTO security_audit_log (
    user_id, action, table_name, record_id
  ) VALUES (
    auth.uid(), 
    'customer_driver_info_access',
    'driver_profiles',
    order_id_param::text
  );
  
  -- Return limited driver info for the assigned driver
  RETURN QUERY
  SELECT 
    dp.user_id as driver_id,
    dp.full_name,
    dp.vehicle_type,
    dp.license_plate,
    dp.rating,
    dp.current_latitude,
    dp.current_longitude,
    -- Mask phone number for privacy (show last 4 digits only)
    CASE 
      WHEN dp.phone IS NOT NULL AND LENGTH(dp.phone) > 4 THEN
        '***-***-' || RIGHT(dp.phone, 4)
      ELSE 
        'Contact via app'
    END as phone_masked
  FROM driver_profiles dp
  JOIN driver_order_assignments doa ON dp.user_id = doa.driver_id
  WHERE doa.order_id = order_id_param
  LIMIT 1;
END;
$$;

-- Create secure function for admin access with comprehensive audit logging
CREATE OR REPLACE FUNCTION public.get_all_driver_profiles_secure_admin()
RETURNS TABLE(
  id uuid,
  user_id uuid,
  full_name text,
  email text,
  phone text,
  driver_license_number text,
  vehicle_type text,
  license_plate text,
  is_verified boolean,
  is_active boolean,
  current_latitude numeric,
  current_longitude numeric,
  last_location_update timestamp with time zone,
  rating numeric,
  total_deliveries integer,
  status text,
  created_at timestamp with time zone,
  updated_at timestamp with time zone
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Verify admin access
  IF NOT EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  ) THEN
    RAISE EXCEPTION 'Access denied: admin role required to view all driver profiles';
  END IF;
  
  -- Log the sensitive data access for audit trail
  INSERT INTO security_audit_log (
    user_id, action, table_name, record_id
  ) VALUES (
    auth.uid(), 
    'admin_driver_profiles_access_all',
    'driver_profiles',
    'bulk_access'
  );
  
  -- Return complete driver profile data for verified admins
  RETURN QUERY
  SELECT 
    dp.id,
    dp.user_id,
    dp.full_name,
    dp.email,
    dp.phone,
    dp.driver_license_number,
    dp.vehicle_type,
    dp.license_plate,
    dp.is_verified,
    dp.is_active,
    dp.current_latitude,
    dp.current_longitude,
    dp.last_location_update,
    dp.rating,
    dp.total_deliveries,
    dp.status,
    dp.created_at,
    dp.updated_at
  FROM driver_profiles dp
  ORDER BY dp.created_at DESC;
END;
$$;