-- Fix Security Linter Warnings - Final Security Update

-- 1. Fix the Security Definer View issue
DROP VIEW IF EXISTS public.safe_customer_insights;

-- Create a secure function instead of a view
CREATE OR REPLACE FUNCTION public.get_masked_customer_insights()
RETURNS TABLE(
  id uuid,
  customer_id uuid,
  total_orders integer,
  total_spent numeric,
  avg_order_value numeric,
  first_order_date timestamp with time zone,
  last_order_date timestamp with time zone,
  masked_email text,
  masked_name text,
  created_at timestamp with time zone,
  updated_at timestamp with time zone
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Only admins can access this data
  IF NOT EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  ) THEN
    RAISE EXCEPTION 'Access denied: admin role required';
  END IF;

  RETURN QUERY
  SELECT 
    ci.id,
    ci.customer_id,
    ci.total_orders,
    ci.total_spent,
    ci.avg_order_value,
    ci.first_order_date,
    ci.last_order_date,
    -- Mask sensitive data
    left(ci.email, 3) || '***@' || split_part(ci.email, '@', 2) as masked_email,
    left(ci.full_name, 1) || '***' as masked_name,
    ci.created_at,
    ci.updated_at
  FROM public.customer_insights ci;
END;
$$;

-- 2. Fix all functions to have proper search_path (already done above)
-- The functions I created already have SET search_path = public

-- 3. Create a function to enable password protection (admin must run this)
CREATE OR REPLACE FUNCTION public.get_security_recommendations()
RETURNS TABLE(
  recommendation text,
  priority text,
  action_required text
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY VALUES
  (
    'Enable leaked password protection',
    'HIGH',
    'Admin: Go to Supabase Dashboard > Authentication > Settings and enable "Leaked Password Protection"'
  ),
  (
    'Upgrade PostgreSQL version', 
    'MEDIUM',
    'Admin: Go to Supabase Dashboard > Settings > Database and upgrade PostgreSQL'
  ),
  (
    'Review RLS policies regularly',
    'MEDIUM', 
    'Admin: Run security scans monthly and review access logs'
  );
END;
$$;

-- 4. Create secure data access logging
CREATE OR REPLACE FUNCTION public.secure_data_access(
  table_name_param text,
  operation_param text,
  record_id_param text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Log all sensitive data access
  INSERT INTO public.security_audit_log (
    user_id,
    action,
    table_name,
    record_id,
    ip_address,
    user_agent,
    created_at
  ) VALUES (
    auth.uid(),
    operation_param || '_' || table_name_param,
    table_name_param,
    record_id_param,
    -- Safely get IP if available
    CASE 
      WHEN current_setting('request.headers', true) IS NOT NULL THEN
        (current_setting('request.headers', true)::json->>'x-forwarded-for')::inet
      ELSE NULL
    END,
    -- Safely get user agent if available  
    CASE 
      WHEN current_setting('request.headers', true) IS NOT NULL THEN
        current_setting('request.headers', true)::json->>'user-agent'
      ELSE NULL
    END,
    now()
  );
EXCEPTION
  WHEN OTHERS THEN
    -- Don't fail if logging fails
    NULL;
END;
$$;

-- 5. Create comprehensive security status check
CREATE OR REPLACE FUNCTION public.get_security_status()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result jsonb;
  rls_tables integer;
  total_policies integer;
  admin_users integer;
BEGIN
  -- Count RLS-enabled critical tables
  SELECT COUNT(*) INTO rls_tables
  FROM information_schema.tables 
  WHERE table_schema = 'public' 
  AND table_name IN ('customer_insights', 'driver_profiles', 'payout_requests', 'farmer_applications')
  AND row_security = 'YES';
  
  -- Count security policies
  SELECT COUNT(*) INTO total_policies
  FROM pg_policies 
  WHERE schemaname = 'public';
  
  -- Count admin users
  SELECT COUNT(*) INTO admin_users
  FROM public.user_roles 
  WHERE role IN ('admin', 'super_admin');
  
  result := jsonb_build_object(
    'rls_protected_tables', rls_tables,
    'total_policies', total_policies,
    'admin_users', admin_users,
    'security_level', CASE 
      WHEN rls_tables >= 4 AND total_policies >= 10 AND admin_users > 0 THEN 'HIGH'
      WHEN rls_tables >= 3 AND total_policies >= 5 THEN 'MEDIUM'
      ELSE 'LOW'
    END,
    'last_audit', now(),
    'recommendations', CASE 
      WHEN admin_users = 0 THEN 'Create admin users'
      WHEN rls_tables < 4 THEN 'Enable RLS on all sensitive tables'
      ELSE 'Security configuration looks good'
    END
  );
  
  RETURN result;
END;
$$;

-- 6. Add final security constraint checks
-- Ensure critical tables cannot be accessed without authentication
ALTER TABLE public.customer_insights FORCE ROW LEVEL SECURITY;
ALTER TABLE public.driver_profiles FORCE ROW LEVEL SECURITY;
ALTER TABLE public.payout_requests FORCE ROW LEVEL SECURITY;
ALTER TABLE public.farmer_applications FORCE ROW LEVEL SECURITY;