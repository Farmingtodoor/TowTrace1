-- Add INSERT policy for order_items table to prevent unauthorized creation
-- Only customers who own the order should be able to create order items for that order
CREATE POLICY "Customers can create order items for their own orders" 
ON public.order_items 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 
    FROM public.orders 
    WHERE orders.id = order_items.order_id 
    AND orders.customer_id = auth.uid()
  )
);