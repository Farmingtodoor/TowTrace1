-- 1. subscription_deliveries: drop permissive ALL policy
DROP POLICY IF EXISTS "System can manage subscription deliveries" ON public.subscription_deliveries;

-- 2. promotion_usage: require auth.uid() = user_id on insert
DROP POLICY IF EXISTS "System can track usage" ON public.promotion_usage;
CREATE POLICY "Users can record their own promotion usage"
  ON public.promotion_usage
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- 3. featured_purchases: lock down UPDATE to admins (was USING true)
DROP POLICY IF EXISTS "System can update purchase status" ON public.featured_purchases;
CREATE POLICY "Admins can update purchase status"
  ON public.featured_purchases
  FOR UPDATE
  TO authenticated
  USING (EXISTS (SELECT 1 FROM public.user_roles
    WHERE user_id = auth.uid()
      AND role = ANY (ARRAY['admin'::app_role, 'super_admin'::app_role])))
  WITH CHECK (EXISTS (SELECT 1 FROM public.user_roles
    WHERE user_id = auth.uid()
      AND role = ANY (ARRAY['admin'::app_role, 'super_admin'::app_role])));

-- 4. driver_profiles: remove customer direct SELECT (leaks license/phone/email)
DROP POLICY IF EXISTS "SECURE_customers_limited_driver_info_only" ON public.driver_profiles;

-- Provide safe location-only RPC for customers tracking their orders
CREATE OR REPLACE FUNCTION public.get_driver_location_for_customer_order(order_id_param uuid)
RETURNS TABLE(current_latitude numeric, current_longitude numeric, last_location_update timestamptz)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT dp.current_latitude, dp.current_longitude, dp.last_location_update
  FROM public.driver_profiles dp
  JOIN public.driver_order_assignments doa ON doa.driver_id = dp.user_id
  JOIN public.orders o ON o.id = doa.order_id
  WHERE doa.order_id = order_id_param
    AND o.customer_id = auth.uid()
  LIMIT 1;
$$;

GRANT EXECUTE ON FUNCTION public.get_driver_location_for_customer_order(uuid) TO authenticated;