-- Create discount types enum
CREATE TYPE discount_type AS ENUM ('percentage', 'fixed_amount');
CREATE TYPE promotion_type AS ENUM ('referral', 'first_order', 'product_specific', 'general');

-- Create promotions table for all discount campaigns
CREATE TABLE public.promotions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  type promotion_type NOT NULL,
  discount_type discount_type NOT NULL,
  discount_value DECIMAL(10,2) NOT NULL,
  minimum_order_amount DECIMAL(10,2) DEFAULT 0,
  max_uses INTEGER,
  uses_count INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  starts_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  expires_at TIMESTAMP WITH TIME ZONE,
  created_by UUID REFERENCES auth.users(id),
  farmer_id UUID, -- NULL for platform-wide promotions, specific UUID for farmer promotions
  applicable_products JSONB DEFAULT '[]'::jsonb, -- Array of product IDs for product-specific discounts
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create user referrals table
CREATE TABLE public.user_referrals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  referred_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  referral_code TEXT NOT NULL,
  status TEXT DEFAULT 'pending', -- pending, completed, rewarded
  reward_amount DECIMAL(10,2) DEFAULT 10.00,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  completed_at TIMESTAMP WITH TIME ZONE,
  UNIQUE(referrer_id, referred_id)
);

-- Create promotion usage tracking
CREATE TABLE public.promotion_usage (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  promotion_id UUID REFERENCES public.promotions(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  order_id UUID, -- Reference to orders table
  discount_amount DECIMAL(10,2) NOT NULL,
  used_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(promotion_id, user_id, order_id)
);

-- Enable RLS on all tables
ALTER TABLE public.promotions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_referrals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.promotion_usage ENABLE ROW LEVEL SECURITY;

-- RLS Policies for promotions
CREATE POLICY "Anyone can view active promotions" ON public.promotions
  FOR SELECT USING (is_active = true);

CREATE POLICY "Farmers can manage their own promotions" ON public.promotions
  FOR ALL USING (created_by = auth.uid() OR farmer_id = auth.uid());

CREATE POLICY "Admins can manage all promotions" ON public.promotions
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_id = auth.uid() 
      AND role IN ('admin', 'super_admin')
    )
  );

-- RLS Policies for referrals
CREATE POLICY "Users can view their own referrals" ON public.user_referrals
  FOR SELECT USING (referrer_id = auth.uid() OR referred_id = auth.uid());

CREATE POLICY "Users can create referrals" ON public.user_referrals
  FOR INSERT WITH CHECK (referrer_id = auth.uid());

CREATE POLICY "System can update referrals" ON public.user_referrals
  FOR UPDATE USING (true); -- Allow system updates via service role

-- RLS Policies for promotion usage
CREATE POLICY "Users can view their own usage" ON public.promotion_usage
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "System can track usage" ON public.promotion_usage
  FOR INSERT WITH CHECK (true); -- Allow system tracking via service role

-- Create indexes for performance
CREATE INDEX idx_promotions_code ON public.promotions(code);
CREATE INDEX idx_promotions_type ON public.promotions(type);
CREATE INDEX idx_promotions_farmer ON public.promotions(farmer_id);
CREATE INDEX idx_referrals_code ON public.user_referrals(referral_code);
CREATE INDEX idx_promotion_usage_user ON public.promotion_usage(user_id);

-- Insert default first-order promotion
INSERT INTO public.promotions (code, name, description, type, discount_type, discount_value, minimum_order_amount, is_active)
VALUES (
  'FIRST15',
  'First Order Discount',
  'Get 15% off your first order! Welcome to Farm2Door',
  'first_order',
  'percentage',
  15.00,
  25.00,
  true
);

-- Function to generate unique referral codes
CREATE OR REPLACE FUNCTION generate_referral_code(user_id UUID)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  base_code TEXT;
  final_code TEXT;
  counter INTEGER := 0;
BEGIN
  -- Create base code from user info or random string
  base_code := 'REF' || UPPER(SUBSTR(MD5(user_id::text), 1, 6));
  final_code := base_code;
  
  -- Ensure uniqueness
  WHILE EXISTS (SELECT 1 FROM user_referrals WHERE referral_code = final_code) LOOP
    counter := counter + 1;
    final_code := base_code || counter::text;
  END LOOP;
  
  RETURN final_code;
END;
$$;

-- Function to check if user has used first order discount
CREATE OR REPLACE FUNCTION has_used_first_order_discount(user_id UUID)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM promotion_usage pu 
    JOIN promotions p ON pu.promotion_id = p.id
    WHERE pu.user_id = user_id AND p.type = 'first_order'
  );
END;
$$;

-- Function to validate and apply promotion
CREATE OR REPLACE FUNCTION validate_promotion(
  promotion_code TEXT,
  user_id UUID,
  order_total DECIMAL
)
RETURNS TABLE(
  valid BOOLEAN,
  discount_amount DECIMAL,
  error_message TEXT,
  promotion_id UUID
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  promo public.promotions%ROWTYPE;
  calculated_discount DECIMAL;
BEGIN
  -- Get promotion details
  SELECT * INTO promo FROM public.promotions 
  WHERE code = promotion_code AND is_active = true
  AND (expires_at IS NULL OR expires_at > now())
  AND starts_at <= now();
  
  IF NOT FOUND THEN
    RETURN QUERY SELECT false, 0::DECIMAL, 'Invalid or expired promotion code', NULL::UUID;
    RETURN;
  END IF;
  
  -- Check minimum order amount
  IF order_total < promo.minimum_order_amount THEN
    RETURN QUERY SELECT false, 0::DECIMAL, 
      'Order minimum of $' || promo.minimum_order_amount::TEXT || ' required', 
      NULL::UUID;
    RETURN;
  END IF;
  
  -- Check usage limits
  IF promo.max_uses IS NOT NULL AND promo.uses_count >= promo.max_uses THEN
    RETURN QUERY SELECT false, 0::DECIMAL, 'Promotion usage limit reached', NULL::UUID;
    RETURN;
  END IF;
  
  -- Check if user already used this promotion
  IF EXISTS (
    SELECT 1 FROM promotion_usage 
    WHERE promotion_id = promo.id AND user_id = validate_promotion.user_id
  ) THEN
    RETURN QUERY SELECT false, 0::DECIMAL, 'You have already used this promotion', NULL::UUID;
    RETURN;
  END IF;
  
  -- Special check for first order discount
  IF promo.type = 'first_order' AND has_used_first_order_discount(user_id) THEN
    RETURN QUERY SELECT false, 0::DECIMAL, 'First order discount already used', NULL::UUID;
    RETURN;
  END IF;
  
  -- Calculate discount amount
  IF promo.discount_type = 'percentage' THEN
    calculated_discount := (order_total * promo.discount_value / 100);
  ELSE
    calculated_discount := promo.discount_value;
  END IF;
  
  -- Ensure discount doesn't exceed order total
  calculated_discount := LEAST(calculated_discount, order_total);
  
  RETURN QUERY SELECT true, calculated_discount, NULL::TEXT, promo.id;
END;
$$;

-- Trigger to update promotion usage count
CREATE OR REPLACE FUNCTION update_promotion_usage_count()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE promotions 
  SET uses_count = uses_count + 1,
      updated_at = now()
  WHERE id = NEW.promotion_id;
  RETURN NEW;
END;
$$;

CREATE TRIGGER promotion_usage_trigger
  AFTER INSERT ON promotion_usage
  FOR EACH ROW
  EXECUTE FUNCTION update_promotion_usage_count();