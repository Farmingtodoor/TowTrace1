-- Update the review creation policy to be more precise
DROP POLICY IF EXISTS "Users can create reviews for their orders" ON public.reviews;

CREATE POLICY "Users can create reviews for delivered products they ordered" 
ON public.reviews 
FOR INSERT 
WITH CHECK (
  auth.uid() = customer_id 
  AND EXISTS (
    SELECT 1
    FROM orders o
    JOIN order_items oi ON o.id = oi.order_id
    JOIN products p ON p.id = reviews.product_id
    WHERE o.customer_id = auth.uid()
      AND o.status = 'delivered'
      AND o.id = reviews.order_id
      AND p.id = reviews.product_id
      AND oi.product_name = p.name
  )
);