-- 1) Helper: is this user an approved farmer?
CREATE OR REPLACE FUNCTION public.is_approved_farmer(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.farmer_applications
    WHERE user_id = _user_id AND status = 'approved'
  );
$$;

REVOKE ALL ON FUNCTION public.is_approved_farmer(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_approved_farmer(uuid) TO authenticated, service_role;

-- 2) Enforce verified farmers only on new payout requests
CREATE OR REPLACE FUNCTION public.validate_payout_request()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' AND NOT public.is_approved_farmer(NEW.farmer_id) THEN
    RAISE EXCEPTION 'Payouts are only available to approved farms. Complete onboarding and wait for approval first.';
  END IF;

  IF NOT validate_payout_amount(NEW.amount) THEN
    RAISE EXCEPTION 'Invalid payout amount: must be between $0.01 and $100,000';
  END IF;

  IF NEW.status = 'pending' AND EXISTS (
    SELECT 1 FROM payout_requests
    WHERE farmer_id = NEW.farmer_id
      AND status = 'pending'
      AND id != NEW.id
  ) THEN
    RAISE EXCEPTION 'Farmer already has a pending payout request';
  END IF;

  RETURN NEW;
END;
$$;

-- 3) Admin-only overall payout report
CREATE OR REPLACE FUNCTION public.get_admin_payout_report()
RETURNS TABLE (
  total_paid numeric,
  total_pending numeric,
  total_approved numeric,
  total_rejected numeric,
  paid_count integer,
  pending_count integer,
  approved_count integer,
  rejected_count integer,
  receipts_sent integer,
  receipts_failed integer,
  success_rate numeric
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'super_admin')) THEN
    RAISE EXCEPTION 'Access denied';
  END IF;

  RETURN QUERY
  WITH r AS (SELECT status, amount FROM public.payout_requests),
       rc AS (SELECT status FROM public.payout_receipts)
  SELECT
    COALESCE((SELECT SUM(amount) FROM r WHERE status = 'paid'), 0)::numeric,
    COALESCE((SELECT SUM(amount) FROM r WHERE status = 'pending'), 0)::numeric,
    COALESCE((SELECT SUM(amount) FROM r WHERE status = 'approved'), 0)::numeric,
    COALESCE((SELECT SUM(amount) FROM r WHERE status = 'rejected'), 0)::numeric,
    COALESCE((SELECT COUNT(*) FROM r WHERE status = 'paid'), 0)::integer,
    COALESCE((SELECT COUNT(*) FROM r WHERE status = 'pending'), 0)::integer,
    COALESCE((SELECT COUNT(*) FROM r WHERE status = 'approved'), 0)::integer,
    COALESCE((SELECT COUNT(*) FROM r WHERE status = 'rejected'), 0)::integer,
    COALESCE((SELECT COUNT(*) FROM rc WHERE status = 'sent'), 0)::integer,
    COALESCE((SELECT COUNT(*) FROM rc WHERE status <> 'sent'), 0)::integer,
    CASE
      WHEN (SELECT COUNT(*) FROM rc) = 0 THEN NULL
      ELSE ROUND(
        (SELECT COUNT(*) FROM rc WHERE status = 'sent')::numeric * 100
        / (SELECT COUNT(*) FROM rc)::numeric, 1)
    END;
END;
$$;

REVOKE ALL ON FUNCTION public.get_admin_payout_report() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_admin_payout_report() TO authenticated, service_role;

-- 4) Admin-only per-farmer earnings/payout overview
CREATE OR REPLACE FUNCTION public.get_admin_farmer_earnings_report()
RETURNS TABLE (
  farmer_id uuid,
  farm_name text,
  farmer_email text,
  is_approved boolean,
  bank_verified boolean,
  paid_orders integer,
  gross_earnings numeric,
  total_paid_out numeric,
  pending_amount numeric,
  pending_requests integer,
  available_balance numeric,
  last_payout_at timestamptz
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'super_admin')) THEN
    RAISE EXCEPTION 'Access denied';
  END IF;

  RETURN QUERY
  WITH farms AS (
    SELECT DISTINCT fa.user_id AS fid FROM public.farmer_applications fa
    UNION
    SELECT DISTINCT pr.farmer_id FROM public.payout_requests pr
  ),
  app AS (
    SELECT DISTINCT ON (fa.user_id) fa.user_id, fa.farm_name, fa.email, fa.status
    FROM public.farmer_applications fa
    ORDER BY fa.user_id, fa.created_at DESC
  ),
  ord AS (
    SELECT o.farmer_id AS fid,
           COUNT(*)::integer AS cnt,
           COALESCE(SUM(COALESCE(o.farmer_earnings, o.total_amount)), 0) AS gross
    FROM public.orders o
    WHERE o.payment_status = 'paid'
    GROUP BY o.farmer_id
  ),
  pay AS (
    SELECT pr.farmer_id AS fid,
           COALESCE(SUM(pr.amount) FILTER (WHERE pr.status = 'paid'), 0) AS paid_out,
           COALESCE(SUM(pr.amount) FILTER (WHERE pr.status IN ('pending','approved')), 0) AS pending_amt,
           COUNT(*) FILTER (WHERE pr.status = 'pending')::integer AS pending_cnt,
           MAX(pr.reviewed_at) FILTER (WHERE pr.status = 'paid') AS last_paid
    FROM public.payout_requests pr
    GROUP BY pr.farmer_id
  )
  SELECT
    f.fid,
    app.farm_name,
    app.email,
    (app.status = 'approved'),
    COALESCE(fpa.payouts_enabled, false),
    COALESCE(ord.cnt, 0),
    COALESCE(ord.gross, 0)::numeric,
    COALESCE(pay.paid_out, 0)::numeric,
    COALESCE(pay.pending_amt, 0)::numeric,
    COALESCE(pay.pending_cnt, 0),
    GREATEST(COALESCE(ord.gross, 0) - COALESCE(pay.paid_out, 0) - COALESCE(pay.pending_amt, 0), 0)::numeric,
    pay.last_paid
  FROM farms f
  LEFT JOIN app ON app.user_id = f.fid
  LEFT JOIN ord ON ord.fid = f.fid
  LEFT JOIN pay ON pay.fid = f.fid
  LEFT JOIN public.farmer_payout_accounts fpa ON fpa.farmer_id = f.fid
  ORDER BY COALESCE(pay.pending_amt, 0) DESC, COALESCE(ord.gross, 0) DESC;
END;
$$;

REVOKE ALL ON FUNCTION public.get_admin_farmer_earnings_report() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_admin_farmer_earnings_report() TO authenticated, service_role;