-- Update category name from Meat to Livestock
UPDATE categories 
SET name = 'Livestock', 
    description = 'Premium grass-fed livestock, free-range animals, and custom processing options',
    updated_at = now()
WHERE name = 'Meat';

-- Get the livestock category ID for reference
-- Update subcategories to match user requirements
UPDATE subcategories 
SET name = 'Cows', 
    display_order = 1,
    updated_at = now()
WHERE category_id = '4cea093a-2644-4238-8345-7f4c9aa149c2' 
AND name = 'Beef Cattle';

-- Update existing subcategories
UPDATE subcategories 
SET name = 'Pigs', 
    display_order = 6,
    updated_at = now()
WHERE category_id = '4cea093a-2644-4238-8345-7f4c9aa149c2' 
AND name = 'Pork';

-- Remove the old Lamb & Goat and replace with separate entries
DELETE FROM subcategories 
WHERE category_id = '4cea093a-2644-4238-8345-7f4c9aa149c2' 
AND name IN ('Lamb & Goat', 'Game Meat', 'Custom Processing');

-- Add new subcategories
INSERT INTO subcategories (category_id, name, display_order, is_active) VALUES
('4cea093a-2644-4238-8345-7f4c9aa149c2', 'Goats', 2, true),
('4cea093a-2644-4238-8345-7f4c9aa149c2', 'Lambs', 3, true),
('4cea093a-2644-4238-8345-7f4c9aa149c2', 'Chickens', 4, true),
('4cea093a-2644-4238-8345-7f4c9aa149c2', 'Turkeys', 5, true);

-- Update Poultry to Chickens (we'll keep both if needed or just rename)
UPDATE subcategories 
SET name = 'Chickens', 
    display_order = 4,
    updated_at = now()
WHERE category_id = '4cea093a-2644-4238-8345-7f4c9aa149c2' 
AND name = 'Poultry';