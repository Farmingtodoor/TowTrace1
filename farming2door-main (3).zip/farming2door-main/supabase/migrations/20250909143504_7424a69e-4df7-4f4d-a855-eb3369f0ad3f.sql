-- Update delivery partners with realistic market rates
-- DoorDash market rates: $2.99 base + $0.50-1.00 per mile
-- Uber Eats market rates: $1.99 base + $0.75-1.25 per mile

UPDATE delivery_partners 
SET 
  base_fee = 2.99,
  per_mile_fee = 0.75,
  minimum_order_amount = 15.00,
  maximum_delivery_distance_miles = 25
WHERE slug = 'doordash';

UPDATE delivery_partners 
SET 
  base_fee = 1.99,
  per_mile_fee = 1.00,
  minimum_order_amount = 12.00,
  maximum_delivery_distance_miles = 20
WHERE slug = 'uber_eats';

-- Add any missing delivery partners if they don't exist
INSERT INTO delivery_partners (name, slug, logo_url, estimated_delivery_time, base_fee, per_mile_fee, minimum_order_amount, maximum_delivery_distance_miles, is_active)
VALUES 
  ('DoorDash', 'doordash', '/logos/doordash-logo.png', '25-35 minutes', 2.99, 0.75, 15.00, 25, true),
  ('Uber Eats', 'uber_eats', '/logos/uber-eats-logo.png', '20-30 minutes', 1.99, 1.00, 12.00, 20, true)
ON CONFLICT (slug) DO UPDATE SET
  base_fee = EXCLUDED.base_fee,
  per_mile_fee = EXCLUDED.per_mile_fee,
  minimum_order_amount = EXCLUDED.minimum_order_amount,
  maximum_delivery_distance_miles = EXCLUDED.maximum_delivery_distance_miles;