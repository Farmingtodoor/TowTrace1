-- Fix Customer Personal Information Security Vulnerability in profiles table
-- Enable RLS and create secure access policies

-- Ensure RLS is enabled on profiles table
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Drop any existing overly permissive policies
DROP POLICY IF EXISTS "Super admins and admins can view all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Users can insert their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can view their own profile" ON public.profiles;
DROP POLICY IF EXISTS "Public profiles are viewable by everyone" ON public.profiles;
DROP POLICY IF EXISTS "Anyone can view profiles" ON public.profiles;

-- Create secure access policies for profiles table

-- 1. Block all anonymous access completely
CREATE POLICY "SECURE_block_anonymous_profile_access" 
ON public.profiles 
FOR ALL 
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);

-- 2. Users can only view their own profile
CREATE POLICY "SECURE_users_own_profile_view_only" 
ON public.profiles 
FOR SELECT 
USING (auth.uid() IS NOT NULL AND auth.uid() = id);

-- 3. Users can only insert their own profile  
CREATE POLICY "SECURE_users_create_own_profile_only" 
ON public.profiles 
FOR INSERT 
WITH CHECK (auth.uid() IS NOT NULL AND auth.uid() = id);

-- 4. Users can only update their own profile
CREATE POLICY "SECURE_users_update_own_profile_only" 
ON public.profiles 
FOR UPDATE 
USING (auth.uid() IS NOT NULL AND auth.uid() = id);

-- 5. Only verified admins can view all profiles (with audit logging)
CREATE POLICY "SECURE_admins_view_all_profiles_only" 
ON public.profiles 
FOR SELECT 
USING (
  auth.uid() IS NOT NULL 
  AND EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- 6. Only super admins can delete profiles (emergency only)
CREATE POLICY "SECURE_super_admins_delete_profiles_only" 
ON public.profiles 
FOR DELETE 
USING (
  auth.uid() IS NOT NULL 
  AND EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role = 'super_admin'
  )
);

-- Create secure function for admin access to profiles with audit logging
CREATE OR REPLACE FUNCTION public.get_user_profiles_secure_admin()
RETURNS TABLE(
  id uuid,
  full_name text,
  email text,
  phone text,
  user_type text,
  status text,
  city text,
  state text,
  zip_code text,
  country text,
  profile_picture_url text,
  created_at timestamp with time zone,
  updated_at timestamp with time zone
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Verify admin access
  IF NOT EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  ) THEN
    RAISE EXCEPTION 'Access denied: admin role required to view all user profiles';
  END IF;
  
  -- Log the sensitive data access for audit trail
  INSERT INTO security_audit_log (
    user_id, action, table_name, record_id
  ) VALUES (
    auth.uid(), 
    'admin_profiles_access_all',
    'profiles',
    'bulk_access'
  );
  
  -- Return all profile data for verified admins
  RETURN QUERY
  SELECT 
    p.id,
    p.full_name,
    p.email,
    p.phone,
    p.user_type,
    p.status,
    p.city,
    p.state,
    p.zip_code,
    p.country,
    p.profile_picture_url,
    p.created_at,
    p.updated_at
  FROM profiles p
  ORDER BY p.created_at DESC;
END;
$$;

-- Create function for safe customer contact (masked data)
CREATE OR REPLACE FUNCTION public.get_customer_contact_safe(customer_id_param uuid)
RETURNS TABLE(
  id uuid,
  display_name text,
  masked_email text,
  contact_available boolean
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- This function provides minimal, safe customer contact info
  -- Used for legitimate business operations (orders, messaging, etc)
  
  RETURN QUERY
  SELECT 
    p.id,
    COALESCE(p.full_name, 'Customer') as display_name,
    -- Mask email for privacy
    CASE 
      WHEN p.email IS NOT NULL THEN
        left(p.email, 1) || '***@' || split_part(p.email, '@', 2)
      ELSE 'Contact via platform'
    END as masked_email,
    (p.email IS NOT NULL) as contact_available
  FROM profiles p
  WHERE p.id = customer_id_param
  AND p.status = 'active';
END;
$$;