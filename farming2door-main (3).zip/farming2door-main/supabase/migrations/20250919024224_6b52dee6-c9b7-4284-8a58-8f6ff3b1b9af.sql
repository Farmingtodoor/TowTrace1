-- Fix security vulnerability in customer_insights table
-- Block all anonymous access and strengthen access controls

-- STEP 1: Drop existing policies to rebuild them securely
DROP POLICY IF EXISTS "Admins can view all customer insights" ON public.customer_insights;
DROP POLICY IF EXISTS "Users can view their own insights" ON public.customer_insights;

-- STEP 2: Create comprehensive security policies

-- CRITICAL: Block all anonymous access completely
CREATE POLICY "SECURITY_CRITICAL_block_anonymous_access" 
ON public.customer_insights 
FOR ALL 
USING (auth.uid() IS NOT NULL) 
WITH CHECK (auth.uid() IS NOT NULL);

-- SECURE: Only verified admins can view all customer insights
CREATE POLICY "SECURE_verified_admins_view_all_insights" 
ON public.customer_insights 
FOR SELECT 
USING (
  auth.uid() IS NOT NULL 
  AND EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- SECURE: Customers can only view their own insights
CREATE POLICY "SECURE_customers_view_own_insights_only" 
ON public.customer_insights 
FOR SELECT 
USING (
  auth.uid() IS NOT NULL 
  AND auth.uid() = customer_id
);

-- SECURE: Block all INSERT operations (data should be populated by system only)
CREATE POLICY "SECURITY_CRITICAL_no_manual_inserts" 
ON public.customer_insights 
FOR INSERT 
WITH CHECK (false);

-- SECURE: Block all UPDATE operations (data should be system-managed only)
CREATE POLICY "SECURITY_CRITICAL_no_manual_updates" 
ON public.customer_insights 
FOR UPDATE 
USING (false) 
WITH CHECK (false);

-- SECURE: Block all DELETE operations (data retention for audit purposes)
CREATE POLICY "SECURITY_CRITICAL_no_deletions" 
ON public.customer_insights 
FOR DELETE 
USING (false);

-- STEP 3: Ensure table security is properly configured
ALTER TABLE public.customer_insights ENABLE ROW LEVEL SECURITY;

-- STEP 4: Revoke unnecessary permissions and grant minimal required access
REVOKE ALL ON public.customer_insights FROM anon, authenticated;
GRANT SELECT ON public.customer_insights TO authenticated; -- Controlled by RLS policies

-- STEP 5: Add audit logging for sensitive data access
CREATE OR REPLACE FUNCTION public.log_customer_insights_access()
RETURNS TRIGGER 
LANGUAGE plpgsql 
SECURITY DEFINER 
SET search_path = public
AS $$
BEGIN
  -- Log access to sensitive customer data for security monitoring
  INSERT INTO public.security_audit_log (
    user_id, action, table_name, record_id, created_at
  ) VALUES (
    auth.uid(), 
    'customer_insights_access',
    'customer_insights',
    COALESCE(NEW.id::text, OLD.id::text),
    now()
  );
  
  RETURN COALESCE(NEW, OLD);
EXCEPTION
  WHEN OTHERS THEN
    -- Don't fail the query if audit logging fails
    RETURN COALESCE(NEW, OLD);
END;
$$;

-- Create audit trigger for SELECT operations monitoring
DROP TRIGGER IF EXISTS audit_customer_insights_access ON public.customer_insights;
CREATE TRIGGER audit_customer_insights_access
  AFTER INSERT OR UPDATE OR DELETE ON public.customer_insights
  FOR EACH ROW EXECUTE FUNCTION public.log_customer_insights_access();