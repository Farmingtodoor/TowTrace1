-- Fix the remaining views that bypass RLS on farmer_applications
-- These views are still exposing farmer data publicly

-- Enable RLS on the remaining views
ALTER TABLE public.approved_farmers_public ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.farmers_public_safe ENABLE ROW LEVEL SECURITY;

-- Add policies to allow public read access since these views only show approved farmers
-- and don't contain sensitive PII
CREATE POLICY "Public can view approved farmers" 
ON public.approved_farmers_public 
FOR SELECT 
USING (true);

CREATE POLICY "Public can view safe farmer data" 
ON public.farmers_public_safe 
FOR SELECT 
USING (true);

-- Since the views select from farmer_applications which now requires authentication,
-- we need to replace these views with functions or recreate them differently

-- Drop the views and create secure replacement functions instead
DROP VIEW IF EXISTS public.approved_farmers_public;
DROP VIEW IF EXISTS public.farmers_public_safe;

-- Create a secure function for approved farmers public data
CREATE OR REPLACE FUNCTION public.get_approved_farmers_public()
RETURNS TABLE(
  user_id UUID,
  farm_name TEXT,
  farm_description TEXT,
  categories JSONB,
  subcategories JSONB,
  processing_methods TEXT[],
  certifications TEXT[],
  created_at TIMESTAMP WITH TIME ZONE,
  display_name TEXT,
  general_location TEXT
) AS $$
BEGIN
  -- This function can be called by anyone since it only returns approved, non-sensitive data
  RETURN QUERY
  SELECT 
    fa.user_id,
    fa.farm_name,
    fa.farm_description,
    fa.categories,
    fa.subcategories,
    fa.processing_methods,
    fa.certifications,
    fa.created_at,
    CASE
      WHEN ((fa.farm_name IS NOT NULL) AND (fa.farm_name <> '')) THEN fa.farm_name
      ELSE 'Local Farm'
    END AS display_name,
    CASE
      WHEN (fa.farm_address IS NOT NULL) THEN regexp_replace(fa.farm_address, '[0-9].*', '', 'g')
      ELSE 'Local Area'
    END AS general_location
  FROM farmer_applications fa
  WHERE fa.status = 'approved';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create a secure function for safe farmer data
CREATE OR REPLACE FUNCTION public.get_farmers_public_safe()
RETURNS TABLE(
  user_id UUID,
  farm_name TEXT,
  farm_description TEXT,
  categories JSONB,
  subcategories JSONB,
  processing_methods TEXT[],
  certifications TEXT[],
  created_at TIMESTAMP WITH TIME ZONE,
  display_name TEXT
) AS $$
BEGIN
  -- This function can be called by anyone since it only returns approved, non-sensitive data
  RETURN QUERY
  SELECT 
    fa.user_id,
    fa.farm_name,
    fa.farm_description,
    fa.categories,
    fa.subcategories,
    fa.processing_methods,
    fa.certifications,
    fa.created_at,
    COALESCE(fa.farm_name, 'Local Farm') AS display_name
  FROM farmer_applications fa
  WHERE fa.status = 'approved';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Add security documentation
COMMENT ON FUNCTION public.get_approved_farmers_public() IS 
'PUBLIC SAFE: Returns non-sensitive data for approved farmers only. No PII exposed.';

COMMENT ON FUNCTION public.get_farmers_public_safe() IS 
'PUBLIC SAFE: Returns safe public data for approved farmers only. No sensitive information.';

-- Log this security fix
INSERT INTO public.security_audit_log (
  action,
  table_name,
  record_id
) VALUES (
  'SECURITY_FIX: Replaced public views with secure functions',
  'approved_farmers_public,farmers_public_safe',
  'Removed views bypassing RLS, replaced with secure functions'
);