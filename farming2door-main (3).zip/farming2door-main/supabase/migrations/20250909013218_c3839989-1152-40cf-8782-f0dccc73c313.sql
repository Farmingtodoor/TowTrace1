-- Fix security warning: Enable leaked password protection
-- This helps prevent users from using known compromised passwords
INSERT INTO auth.config (parameter, value) 
VALUES ('password_min_length', '8')
ON CONFLICT (parameter) 
DO UPDATE SET value = EXCLUDED.value;

INSERT INTO auth.config (parameter, value) 
VALUES ('password_require_letters', 'true')
ON CONFLICT (parameter) 
DO UPDATE SET value = EXCLUDED.value;

INSERT INTO auth.config (parameter, value) 
VALUES ('password_require_numbers', 'true')
ON CONFLICT (parameter) 
DO UPDATE SET value = EXCLUDED.value;

INSERT INTO auth.config (parameter, value) 
VALUES ('password_require_symbols', 'false')
ON CONFLICT (parameter) 
DO UPDATE SET value = EXCLUDED.value;

INSERT INTO auth.config (parameter, value) 
VALUES ('password_require_uppercase', 'false')
ON CONFLICT (parameter) 
DO UPDATE SET value = EXCLUDED.value;

-- Update existing functions to have proper search path (fixes mutable search path warning)
-- Note: The search path was already set in the functions, but let's ensure it's consistent

-- Additional security: Create function to validate payout amounts
CREATE OR REPLACE FUNCTION public.validate_payout_amount(amount numeric)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
STABLE
SET search_path TO 'public'
AS $$
BEGIN
  -- Validate payout amount is reasonable
  IF amount IS NULL OR amount <= 0 THEN
    RETURN false;
  END IF;
  
  -- Set reasonable maximum (can be adjusted based on business needs)
  IF amount > 100000 THEN
    RETURN false;
  END IF;
  
  RETURN true;
END;
$$;

-- Add validation trigger for payout requests
CREATE OR REPLACE FUNCTION public.validate_payout_request()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Validate amount
  IF NOT validate_payout_amount(NEW.amount) THEN
    RAISE EXCEPTION 'Invalid payout amount: must be between $0.01 and $100,000';
  END IF;
  
  -- Prevent duplicate pending requests for same farmer
  IF NEW.status = 'pending' AND EXISTS (
    SELECT 1 FROM payout_requests 
    WHERE farmer_id = NEW.farmer_id 
    AND status = 'pending' 
    AND id != NEW.id
  ) THEN
    RAISE EXCEPTION 'Farmer already has a pending payout request';
  END IF;
  
  RETURN NEW;
END;
$$;

-- Add the validation trigger
DROP TRIGGER IF EXISTS validate_payout_trigger ON payout_requests;
CREATE TRIGGER validate_payout_trigger
  BEFORE INSERT OR UPDATE ON payout_requests
  FOR EACH ROW EXECUTE FUNCTION validate_payout_request();