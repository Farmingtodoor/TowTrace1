-- Fix security issues: Function Search Path Mutable
-- Update all functions to have proper search_path security settings

-- Fix generate_referral_code function
CREATE OR REPLACE FUNCTION public.generate_referral_code(user_id uuid)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path = public
AS $function$
DECLARE
  base_code TEXT;
  final_code TEXT;
  counter INTEGER := 0;
BEGIN
  -- Create base code from user info or random string
  base_code := 'REF' || UPPER(SUBSTR(MD5(user_id::text), 1, 6));
  final_code := base_code;
  
  -- Ensure uniqueness
  WHILE EXISTS (SELECT 1 FROM user_referrals WHERE referral_code = final_code) LOOP
    counter := counter + 1;
    final_code := base_code || counter::text;
  END LOOP;
  
  RETURN final_code;
END;
$function$;

-- Fix has_used_first_order_discount function
CREATE OR REPLACE FUNCTION public.has_used_first_order_discount(user_id uuid)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path = public
AS $function$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM promotion_usage pu 
    JOIN promotions p ON pu.promotion_id = p.id
    WHERE pu.user_id = user_id AND p.type = 'first_order'
  );
END;
$function$;

-- Fix update_promotion_usage_count function
CREATE OR REPLACE FUNCTION public.update_promotion_usage_count()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path = public
AS $function$
BEGIN
  UPDATE promotions 
  SET uses_count = uses_count + 1,
      updated_at = now()
  WHERE id = NEW.promotion_id;
  RETURN NEW;
END;
$function$;

-- Fix update_conversation_last_message function
CREATE OR REPLACE FUNCTION public.update_conversation_last_message()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path = public
AS $function$
BEGIN
  UPDATE public.conversations 
  SET last_message_at = NEW.created_at
  WHERE id = NEW.conversation_id;
  RETURN NEW;
END;
$function$;

-- Fix handle_subscription_updated_at function
CREATE OR REPLACE FUNCTION public.handle_subscription_updated_at()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path = public
AS $function$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$function$;

-- Fix calculate_next_delivery_date function
CREATE OR REPLACE FUNCTION public.calculate_next_delivery_date(start_date date, interval_type text, interval_count integer)
 RETURNS date
 LANGUAGE plpgsql
 SET search_path = public
AS $function$
BEGIN
  CASE interval_type
    WHEN 'weekly' THEN
      RETURN start_date + (interval_count * INTERVAL '1 week')::INTERVAL;
    WHEN 'monthly' THEN
      RETURN start_date + (interval_count * INTERVAL '1 month')::INTERVAL;
    ELSE
      RETURN start_date + INTERVAL '1 week';
  END CASE;
END;
$function$;