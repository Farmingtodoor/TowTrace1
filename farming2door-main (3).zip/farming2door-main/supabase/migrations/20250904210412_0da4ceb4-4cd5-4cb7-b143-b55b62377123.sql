-- Update the notifications table constraint to allow additional notification types
ALTER TABLE public.notifications 
DROP CONSTRAINT notifications_type_check;

-- Add a new constraint that includes announcement and other notification types
ALTER TABLE public.notifications 
ADD CONSTRAINT notifications_type_check 
CHECK (type = ANY (ARRAY[
  'order_placed'::text, 
  'order_confirmed'::text, 
  'order_processing'::text, 
  'order_ready'::text, 
  'order_out_for_delivery'::text, 
  'order_delivered'::text,
  'announcement'::text,
  'farmer_application'::text,
  'application_approved'::text,
  'system'::text,
  'general'::text
]));