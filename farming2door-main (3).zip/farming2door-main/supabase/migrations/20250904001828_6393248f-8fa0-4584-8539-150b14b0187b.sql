-- Create payout_requests table for farmer withdrawals
CREATE TABLE public.payout_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  farmer_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount NUMERIC(10,2) NOT NULL CHECK (amount > 0),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'paid')),
  payment_method TEXT NOT NULL DEFAULT 'bank_transfer',
  bank_account_holder TEXT,
  bank_account_number TEXT,
  routing_number TEXT,
  additional_notes TEXT,
  requested_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  reviewed_at TIMESTAMPTZ,
  reviewed_by UUID REFERENCES auth.users(id),
  admin_notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.payout_requests ENABLE ROW LEVEL SECURITY;

-- Farmers can view their own payout requests
CREATE POLICY "Farmers can view their own payout requests"
ON public.payout_requests
FOR SELECT
USING (auth.uid() = farmer_id);

-- Farmers can create their own payout requests
CREATE POLICY "Farmers can create their own payout requests"
ON public.payout_requests
FOR INSERT
WITH CHECK (auth.uid() = farmer_id);

-- Admins can view all payout requests
CREATE POLICY "Admins can view all payout requests"
ON public.payout_requests
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- Admins can update payout requests (approve/reject)
CREATE POLICY "Admins can update payout requests"
ON public.payout_requests
FOR UPDATE
USING (
  EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- Add trigger for updated_at
CREATE TRIGGER update_payout_requests_updated_at
BEFORE UPDATE ON public.payout_requests
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();