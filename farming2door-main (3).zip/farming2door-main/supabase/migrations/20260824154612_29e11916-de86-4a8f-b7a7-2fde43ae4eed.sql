CREATE TABLE public.delivery_waitlist (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  farmer_id uuid NOT NULL,
  user_id uuid,
  email text NOT NULL,
  zip_code text NOT NULL,
  distance_miles numeric,
  notes text,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.delivery_waitlist TO authenticated;
GRANT INSERT ON public.delivery_waitlist TO anon;
GRANT ALL ON public.delivery_waitlist TO service_role;

ALTER TABLE public.delivery_waitlist ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can join a farm delivery waitlist"
ON public.delivery_waitlist FOR INSERT TO anon, authenticated
WITH CHECK (user_id IS NULL OR user_id = auth.uid());

CREATE POLICY "Users can view their own waitlist requests"
ON public.delivery_waitlist FOR SELECT TO authenticated
USING (user_id = auth.uid());

CREATE POLICY "Farmers can view their farm waitlist"
ON public.delivery_waitlist FOR SELECT TO authenticated
USING (farmer_id = auth.uid());

CREATE POLICY "Admins can view all waitlist requests"
ON public.delivery_waitlist FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'super_admin'));

CREATE INDEX idx_delivery_waitlist_farmer ON public.delivery_waitlist(farmer_id, created_at DESC);

CREATE TRIGGER update_delivery_waitlist_updated_at
BEFORE UPDATE ON public.delivery_waitlist
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();