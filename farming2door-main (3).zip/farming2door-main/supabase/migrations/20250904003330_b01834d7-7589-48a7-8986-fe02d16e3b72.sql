-- Create video storage bucket
INSERT INTO storage.buckets (id, name, public) VALUES ('product-videos', 'product-videos', true);

-- Update products table to support multiple images and videos
ALTER TABLE public.products 
ADD COLUMN images JSONB DEFAULT '[]'::jsonb,
ADD COLUMN videos JSONB DEFAULT '[]'::jsonb;

-- Create storage policies for videos bucket
CREATE POLICY "Anyone can view product videos"
ON storage.objects FOR SELECT
USING (bucket_id = 'product-videos');

CREATE POLICY "Farmers can upload product videos"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'product-videos' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Farmers can update their product videos"
ON storage.objects FOR UPDATE
USING (bucket_id = 'product-videos' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Farmers can delete their product videos"
ON storage.objects FOR DELETE
USING (bucket_id = 'product-videos' AND auth.uid()::text = (storage.foldername(name))[1]);