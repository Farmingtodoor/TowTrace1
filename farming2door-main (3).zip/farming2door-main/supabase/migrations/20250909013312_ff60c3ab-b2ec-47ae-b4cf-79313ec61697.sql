-- Additional security improvements for payout system

-- Create function to validate payout amounts
CREATE OR REPLACE FUNCTION public.validate_payout_amount(amount numeric)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
STABLE
SET search_path TO 'public'
AS $$
BEGIN
  -- Validate payout amount is reasonable
  IF amount IS NULL OR amount <= 0 THEN
    RETURN false;
  END IF;
  
  -- Set reasonable maximum (can be adjusted based on business needs)
  IF amount > 100000 THEN
    RETURN false;
  END IF;
  
  RETURN true;
END;
$$;

-- Add validation trigger for payout requests
CREATE OR REPLACE FUNCTION public.validate_payout_request()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Validate amount
  IF NOT validate_payout_amount(NEW.amount) THEN
    RAISE EXCEPTION 'Invalid payout amount: must be between $0.01 and $100,000';
  END IF;
  
  -- Prevent duplicate pending requests for same farmer
  IF NEW.status = 'pending' AND EXISTS (
    SELECT 1 FROM payout_requests 
    WHERE farmer_id = NEW.farmer_id 
    AND status = 'pending' 
    AND id != NEW.id
  ) THEN
    RAISE EXCEPTION 'Farmer already has a pending payout request';
  END IF;
  
  RETURN NEW;
END;
$$;

-- Add the validation trigger
DROP TRIGGER IF EXISTS validate_payout_trigger ON payout_requests;
CREATE TRIGGER validate_payout_trigger
  BEFORE INSERT OR UPDATE ON payout_requests
  FOR EACH ROW EXECUTE FUNCTION validate_payout_request();

-- Additional security: Rate limiting for payout requests
CREATE OR REPLACE FUNCTION public.check_payout_rate_limit(p_farmer_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
STABLE
SET search_path TO 'public'
AS $$
DECLARE
  request_count INTEGER;
BEGIN
  -- Check how many payout requests in the last 24 hours
  SELECT COUNT(*) INTO request_count
  FROM payout_requests
  WHERE farmer_id = p_farmer_id
  AND created_at > now() - interval '24 hours';
  
  -- Allow max 3 requests per day
  RETURN request_count < 3;
END;
$$;