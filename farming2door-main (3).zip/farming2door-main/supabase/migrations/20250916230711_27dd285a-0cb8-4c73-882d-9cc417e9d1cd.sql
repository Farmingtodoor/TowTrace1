-- Security fix for payout_requests table - Phase 1
-- Fix the critical security vulnerability

-- Ensure RLS is enabled on payout_requests (critical security measure)
ALTER TABLE public.payout_requests ENABLE ROW LEVEL SECURITY;

-- Drop any overly permissive policies that might exist
DROP POLICY IF EXISTS "Enable read access for all users" ON public.payout_requests;
DROP POLICY IF EXISTS "Public read access" ON public.payout_requests;
DROP POLICY IF EXISTS "Allow public access" ON public.payout_requests;

-- Drop existing policies to recreate with stronger security
DROP POLICY IF EXISTS "Farmers can view their own payout requests" ON public.payout_requests;
DROP POLICY IF EXISTS "Farmers can create their own payout requests" ON public.payout_requests;
DROP POLICY IF EXISTS "Admins can view all payout requests" ON public.payout_requests;
DROP POLICY IF EXISTS "Admins can update payout requests" ON public.payout_requests;

-- Create bulletproof security policies
-- Policy 1: Farmers can only view their own payout requests (authenticated only)
CREATE POLICY "Farmers view own payout requests ONLY" 
ON public.payout_requests 
FOR SELECT 
USING (auth.uid() = farmer_id AND auth.uid() IS NOT NULL);

-- Policy 2: Farmers can only create payout requests for themselves (authenticated only)
CREATE POLICY "Farmers create own payout requests ONLY" 
ON public.payout_requests 
FOR INSERT 
WITH CHECK (auth.uid() = farmer_id AND auth.uid() IS NOT NULL);

-- Policy 3: Only admins can view all payout requests (no public access)
CREATE POLICY "Admins view all payout requests ONLY" 
ON public.payout_requests 
FOR SELECT 
USING (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- Policy 4: Only admins can update payout requests
CREATE POLICY "Admins update payout requests ONLY" 
ON public.payout_requests 
FOR UPDATE 
USING (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- Policy 5: Block ALL anonymous access completely
CREATE POLICY "Block anonymous access to payout requests" 
ON public.payout_requests 
FOR ALL
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);

-- Policy 6: No DELETE operations allowed (protect audit trail)
CREATE POLICY "No delete operations on payout requests" 
ON public.payout_requests 
FOR DELETE 
USING (false);