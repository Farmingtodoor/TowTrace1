-- Create promotion type enum (discount_type likely already exists)
CREATE TYPE promotion_type AS ENUM ('referral', 'first_order', 'product_specific', 'general');

-- Create promotions table for all discount campaigns
CREATE TABLE public.promotions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  type promotion_type NOT NULL,
  discount_type TEXT NOT NULL CHECK (discount_type IN ('percentage', 'fixed_amount')),
  discount_value DECIMAL(10,2) NOT NULL,
  minimum_order_amount DECIMAL(10,2) DEFAULT 0,
  max_uses INTEGER,
  uses_count INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  starts_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  expires_at TIMESTAMP WITH TIME ZONE,
  created_by UUID,
  farmer_id UUID, -- NULL for platform-wide promotions, specific UUID for farmer promotions
  applicable_products JSONB DEFAULT '[]'::jsonb, -- Array of product IDs for product-specific discounts
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create user referrals table
CREATE TABLE public.user_referrals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id UUID,
  referred_id UUID,
  referral_code TEXT NOT NULL,
  status TEXT DEFAULT 'pending', -- pending, completed, rewarded
  reward_amount DECIMAL(10,2) DEFAULT 10.00,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  completed_at TIMESTAMP WITH TIME ZONE,
  UNIQUE(referrer_id, referred_id)
);

-- Create promotion usage tracking
CREATE TABLE public.promotion_usage (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  promotion_id UUID REFERENCES public.promotions(id) ON DELETE CASCADE,
  user_id UUID,
  order_id UUID, -- Reference to orders table
  discount_amount DECIMAL(10,2) NOT NULL,
  used_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(promotion_id, user_id, order_id)
);

-- Enable RLS on all tables
ALTER TABLE public.promotions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_referrals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.promotion_usage ENABLE ROW LEVEL SECURITY;

-- RLS Policies for promotions
CREATE POLICY "Anyone can view active promotions" ON public.promotions
  FOR SELECT USING (is_active = true);

CREATE POLICY "Farmers can manage their own promotions" ON public.promotions
  FOR ALL USING (created_by = auth.uid() OR farmer_id = auth.uid());

CREATE POLICY "Admins can manage all promotions" ON public.promotions
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM user_roles 
      WHERE user_id = auth.uid() 
      AND role IN ('admin', 'super_admin')
    )
  );

-- RLS Policies for referrals
CREATE POLICY "Users can view their own referrals" ON public.user_referrals
  FOR SELECT USING (referrer_id = auth.uid() OR referred_id = auth.uid());

CREATE POLICY "Users can create referrals" ON public.user_referrals
  FOR INSERT WITH CHECK (referrer_id = auth.uid());

CREATE POLICY "System can update referrals" ON public.user_referrals
  FOR UPDATE USING (true);

-- RLS Policies for promotion usage
CREATE POLICY "Users can view their own usage" ON public.promotion_usage
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "System can track usage" ON public.promotion_usage
  FOR INSERT WITH CHECK (true);

-- Create indexes for performance
CREATE INDEX idx_promotions_code ON public.promotions(code);
CREATE INDEX idx_promotions_type ON public.promotions(type);
CREATE INDEX idx_promotions_farmer ON public.promotions(farmer_id);
CREATE INDEX idx_referrals_code ON public.user_referrals(referral_code);
CREATE INDEX idx_promotion_usage_user ON public.promotion_usage(user_id);

-- Insert default first-order promotion
INSERT INTO public.promotions (code, name, description, type, discount_type, discount_value, minimum_order_amount, is_active)
VALUES (
  'FIRST15',
  'First Order Discount',
  'Get 15% off your first order! Welcome to Farm2Door',
  'first_order',
  'percentage',
  15.00,
  25.00,
  true
);

-- Function to generate unique referral codes
CREATE OR REPLACE FUNCTION generate_referral_code(user_id UUID)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  base_code TEXT;
  final_code TEXT;
  counter INTEGER := 0;
BEGIN
  -- Create base code from user info or random string
  base_code := 'REF' || UPPER(SUBSTR(MD5(user_id::text), 1, 6));
  final_code := base_code;
  
  -- Ensure uniqueness
  WHILE EXISTS (SELECT 1 FROM user_referrals WHERE referral_code = final_code) LOOP
    counter := counter + 1;
    final_code := base_code || counter::text;
  END LOOP;
  
  RETURN final_code;
END;
$$;