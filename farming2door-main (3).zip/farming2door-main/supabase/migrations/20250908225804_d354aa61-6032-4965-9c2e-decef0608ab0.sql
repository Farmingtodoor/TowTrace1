-- Create delivery partners table
CREATE TABLE public.delivery_partners (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  api_endpoint TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  logo_url TEXT,
  estimated_delivery_time TEXT,
  base_fee NUMERIC NOT NULL DEFAULT 0,
  per_mile_fee NUMERIC NOT NULL DEFAULT 0,
  minimum_order_amount NUMERIC NOT NULL DEFAULT 0,
  maximum_delivery_distance_miles NUMERIC NOT NULL DEFAULT 10,
  service_areas JSONB DEFAULT '[]'::jsonb,
  operating_hours JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add delivery partner tracking to orders
ALTER TABLE public.orders 
ADD COLUMN delivery_partner_id UUID REFERENCES public.delivery_partners(id),
ADD COLUMN delivery_partner_order_id TEXT,
ADD COLUMN delivery_partner_tracking_url TEXT,
ADD COLUMN delivery_partner_fee NUMERIC DEFAULT 0,
ADD COLUMN estimated_delivery_time TEXT;

-- Enable RLS for delivery partners
ALTER TABLE public.delivery_partners ENABLE ROW LEVEL SECURITY;

-- Create policies for delivery partners
CREATE POLICY "Anyone can view active delivery partners" 
ON public.delivery_partners 
FOR SELECT 
USING (is_active = true);

-- Insert DoorDash and Uber as delivery partners
INSERT INTO public.delivery_partners (name, slug, logo_url, estimated_delivery_time, base_fee, per_mile_fee, minimum_order_amount, maximum_delivery_distance_miles, operating_hours) VALUES
('DoorDash', 'doordash', 'https://logos-world.net/wp-content/uploads/2021/02/DoorDash-Logo.png', '25-35 minutes', 2.99, 1.50, 15.00, 15, '{"monday": "7:00-23:00", "tuesday": "7:00-23:00", "wednesday": "7:00-23:00", "thursday": "7:00-23:00", "friday": "7:00-24:00", "saturday": "8:00-24:00", "sunday": "8:00-22:00"}'::jsonb),
('Uber Eats', 'uber-eats', 'https://logos-world.net/wp-content/uploads/2021/08/Uber-Eats-Logo.png', '20-30 minutes', 1.99, 1.75, 12.00, 12, '{"monday": "6:00-24:00", "tuesday": "6:00-24:00", "wednesday": "6:00-24:00", "thursday": "6:00-24:00", "friday": "6:00-24:00", "saturday": "7:00-24:00", "sunday": "7:00-23:00"}'::jsonb);

-- Create trigger for updating updated_at
CREATE TRIGGER update_delivery_partners_updated_at
BEFORE UPDATE ON public.delivery_partners
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();