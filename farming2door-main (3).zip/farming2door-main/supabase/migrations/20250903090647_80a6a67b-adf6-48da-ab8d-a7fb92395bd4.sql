-- Create categories table
CREATE TABLE public.categories (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    description TEXT,
    icon TEXT,
    display_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create subcategories table
CREATE TABLE public.subcategories (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    category_id UUID REFERENCES public.categories(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    display_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    UNIQUE(category_id, name)
);

-- Create farmer_categories junction table
CREATE TABLE public.farmer_categories (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    farmer_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    category_id UUID REFERENCES public.categories(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    UNIQUE(farmer_id, category_id)
);

-- Create farmer_subcategories junction table  
CREATE TABLE public.farmer_subcategories (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    farmer_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    subcategory_id UUID REFERENCES public.subcategories(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    UNIQUE(farmer_id, subcategory_id)
);

-- Enable RLS on all tables
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subcategories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.farmer_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.farmer_subcategories ENABLE ROW LEVEL SECURITY;

-- RLS policies for categories (readable by everyone)
CREATE POLICY "Categories are viewable by everyone" ON public.categories FOR SELECT USING (true);

-- RLS policies for subcategories (readable by everyone)  
CREATE POLICY "Subcategories are viewable by everyone" ON public.subcategories FOR SELECT USING (true);

-- RLS policies for farmer_categories
CREATE POLICY "Farmers can manage their own categories" ON public.farmer_categories 
    FOR ALL USING (auth.uid() = farmer_id);

CREATE POLICY "Anyone can view farmer categories" ON public.farmer_categories 
    FOR SELECT USING (true);

-- RLS policies for farmer_subcategories
CREATE POLICY "Farmers can manage their own subcategories" ON public.farmer_subcategories 
    FOR ALL USING (auth.uid() = farmer_id);

CREATE POLICY "Anyone can view farmer subcategories" ON public.farmer_subcategories 
    FOR SELECT USING (true);

-- Add triggers for updated_at
CREATE TRIGGER update_categories_updated_at
    BEFORE UPDATE ON public.categories
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_subcategories_updated_at
    BEFORE UPDATE ON public.subcategories  
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default categories
INSERT INTO public.categories (name, description, icon, display_order) VALUES
    ('Fresh Produce', 'Seasonal fruits, vegetables, and herbs picked at peak freshness', 'Carrot', 1),
    ('Premium Livestock', 'Grass-fed beef, free-range poultry, and custom processing options', 'Beef', 2),  
    ('Dairy & Eggs', 'Fresh milk, artisanal cheese, and farm-fresh eggs', 'Milk', 3),
    ('Grains & Pantry', 'Freshly milled flour, ancient grains, and farm pantry staples', 'Wheat', 4),
    ('Herbs & Spices', 'Fresh and dried herbs, spices, and seasonings', 'Leaf', 5),
    ('Honey & Bee Products', 'Raw honey, beeswax, and other hive products', 'Hexagon', 6);

-- Insert subcategories for Fresh Produce
INSERT INTO public.subcategories (category_id, name, display_order)
SELECT c.id, s.name, s.display_order 
FROM public.categories c,
(VALUES 
    ('Leafy Greens', 1),
    ('Root Vegetables', 2),
    ('Tomatoes & Peppers', 3),
    ('Squash & Gourds', 4),
    ('Fresh Fruits', 5),
    ('Berries', 6),
    ('Citrus', 7),
    ('Stone Fruits', 8),
    ('Herbs', 9),
    ('Mushrooms', 10)
) AS s(name, display_order)
WHERE c.name = 'Fresh Produce';

-- Insert subcategories for Premium Livestock
INSERT INTO public.subcategories (category_id, name, display_order)
SELECT c.id, s.name, s.display_order
FROM public.categories c,
(VALUES
    ('Beef Cattle', 1),
    ('Pork', 2),
    ('Lamb & Goat', 3),
    ('Poultry', 4),
    ('Game Meat', 5),
    ('Custom Processing', 6)
) AS s(name, display_order)
WHERE c.name = 'Premium Livestock';

-- Insert subcategories for Dairy & Eggs
INSERT INTO public.subcategories (category_id, name, display_order)
SELECT c.id, s.name, s.display_order
FROM public.categories c,
(VALUES
    ('Fresh Milk', 1),
    ('Cheese', 2),
    ('Yogurt & Kefir', 3),
    ('Chicken Eggs', 4),
    ('Duck Eggs', 5),
    ('Other Specialty Eggs', 6),
    ('Butter & Cream', 7)
) AS s(name, display_order)
WHERE c.name = 'Dairy & Eggs';

-- Insert subcategories for Grains & Pantry  
INSERT INTO public.subcategories (category_id, name, display_order)
SELECT c.id, s.name, s.display_order
FROM public.categories c,
(VALUES
    ('Wheat & Flour', 1),
    ('Rice & Ancient Grains', 2),
    ('Beans & Legumes', 3),
    ('Nuts & Seeds', 4),
    ('Oils & Vinegars', 5),
    ('Preserved Foods', 6)
) AS s(name, display_order)
WHERE c.name = 'Grains & Pantry';

-- Insert subcategories for Herbs & Spices
INSERT INTO public.subcategories (category_id, name, display_order)
SELECT c.id, s.name, s.display_order
FROM public.categories c,
(VALUES
    ('Fresh Herbs', 1),
    ('Dried Herbs', 2),
    ('Spice Blends', 3),
    ('Medicinal Herbs', 4)
) AS s(name, display_order)
WHERE c.name = 'Herbs & Spices';

-- Insert subcategories for Honey & Bee Products
INSERT INTO public.subcategories (category_id, name, display_order)
SELECT c.id, s.name, s.display_order
FROM public.categories c,
(VALUES
    ('Raw Honey', 1),
    ('Flavored Honey', 2),
    ('Beeswax Products', 3),
    ('Propolis & Royal Jelly', 4),
    ('Honeycomb', 5)
) AS s(name, display_order)
WHERE c.name = 'Honey & Bee Products';

-- Create indexes for better performance
CREATE INDEX idx_subcategories_category_id ON public.subcategories(category_id);
CREATE INDEX idx_farmer_categories_farmer_id ON public.farmer_categories(farmer_id);
CREATE INDEX idx_farmer_subcategories_farmer_id ON public.farmer_subcategories(farmer_id);
CREATE INDEX idx_categories_display_order ON public.categories(display_order);
CREATE INDEX idx_subcategories_display_order ON public.subcategories(display_order);