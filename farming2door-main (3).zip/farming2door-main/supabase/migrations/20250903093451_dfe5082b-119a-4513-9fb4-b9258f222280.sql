-- Create farmer applications table
CREATE TABLE public.farmer_applications (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  
  -- Personal Information
  full_name text NOT NULL,
  email text NOT NULL,
  phone text,
  
  -- Farm Information  
  farm_name text NOT NULL,
  farm_address text NOT NULL,
  farm_size text,
  farming_experience text,
  farm_description text,
  
  -- Business Information
  business_registration_number text,
  tax_id text,
  insurance_details text,
  certifications text[],
  
  -- Categories and subcategories (stored as JSON for flexibility)
  categories jsonb DEFAULT '[]'::jsonb,
  subcategories jsonb DEFAULT '[]'::jsonb,
  processing_methods text[],
  
  -- Application status
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  admin_notes text,
  reviewed_by uuid REFERENCES auth.users,
  reviewed_at timestamp with time zone,
  
  -- Timestamps
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.farmer_applications ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can create their own applications" 
ON public.farmer_applications 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own applications" 
ON public.farmer_applications 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all applications" 
ON public.farmer_applications 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

CREATE POLICY "Admins can update all applications" 
ON public.farmer_applications 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- Add trigger for updated_at
CREATE TRIGGER update_farmer_applications_updated_at
  BEFORE UPDATE ON public.farmer_applications
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();