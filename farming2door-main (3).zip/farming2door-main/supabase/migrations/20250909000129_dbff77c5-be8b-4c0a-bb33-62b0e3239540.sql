-- Create secure function to get farmer contact information for custom orders
-- This replaces the removed farmer_contacts_auth view
CREATE OR REPLACE FUNCTION public.get_farmer_contacts_for_orders()
RETURNS TABLE(
  user_id UUID,
  farm_name TEXT,
  contact_email TEXT
) AS $$
BEGIN
  -- This function returns basic contact info for approved farmers
  -- Safe for authenticated users placing custom orders
  RETURN QUERY
  SELECT 
    fa.user_id,
    fa.farm_name,
    fa.email as contact_email
  FROM farmer_applications fa
  WHERE fa.status = 'approved';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Document this function
COMMENT ON FUNCTION public.get_farmer_contacts_for_orders() IS 
'Returns basic contact information for approved farmers for custom order placement.';

-- Log this addition
INSERT INTO public.security_audit_log (
  action,
  table_name,
  record_id
) VALUES (
  'SECURITY_FIX: Added secure farmer contacts function',
  'farmer_contacts',
  'Created secure replacement for farmer_contacts_auth view'
);