ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS delivery_scheduled_at timestamp with time zone,
  ADD COLUMN IF NOT EXISTS delivery_scheduled_end timestamp with time zone;