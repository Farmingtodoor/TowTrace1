-- Fix security issue: Set search_path for the function
CREATE OR REPLACE FUNCTION public.handle_order_notifications()
RETURNS TRIGGER AS $$
DECLARE
  customer_profile public.profiles%ROWTYPE;
  farmer_profile public.profiles%ROWTYPE;
BEGIN
  -- Get customer and farmer profiles
  SELECT * INTO customer_profile FROM public.profiles WHERE id = NEW.customer_id;
  SELECT * INTO farmer_profile FROM public.profiles WHERE id = NEW.farmer_id;
  
  -- On new order creation, notify farmer
  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.notifications (user_id, type, title, message, order_id)
    VALUES (
      NEW.farmer_id, 
      'order_placed',
      'New Order Received!',
      'You have received a new order from ' || COALESCE(customer_profile.full_name, customer_profile.email),
      NEW.id
    );
  END IF;
  
  -- On status change to delivered, notify both customer and farmer
  IF TG_OP = 'UPDATE' AND OLD.status != 'delivered' AND NEW.status = 'delivered' THEN
    -- Notify customer about delivery
    INSERT INTO public.notifications (user_id, type, title, message, order_id)
    VALUES (
      NEW.customer_id,
      'order_delivered', 
      'Order Delivered! 🌾',
      'Your fresh produce has been delivered. Thank you for choosing Farm2Door!',
      NEW.id
    );
    
    -- Notify farmer about successful delivery
    INSERT INTO public.notifications (user_id, type, title, message, order_id)
    VALUES (
      NEW.farmer_id,
      'order_completed',
      'Order Completed Successfully',
      'Your order to ' || COALESCE(customer_profile.full_name, customer_profile.email) || ' has been delivered.',
      NEW.id
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = 'public';