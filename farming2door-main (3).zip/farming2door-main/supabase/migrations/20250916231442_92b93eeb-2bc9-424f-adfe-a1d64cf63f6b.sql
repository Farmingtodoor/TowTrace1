-- CRITICAL SECURITY FIX: Farmer Applications Data Protection
-- This addresses the security vulnerability where sensitive business information 
-- could be accessed by competitors or unauthorized users

-- First, ensure RLS is properly enabled (should already be, but let's be sure)
ALTER TABLE public.farmer_applications ENABLE ROW LEVEL SECURITY;

-- Drop any potentially insecure policies
DROP POLICY IF EXISTS "Enable read access for all users" ON public.farmer_applications;
DROP POLICY IF EXISTS "Public access to farmer applications" ON public.farmer_applications;
DROP POLICY IF EXISTS "Allow read access" ON public.farmer_applications;

-- Recreate comprehensive security policies with stronger protection
-- Policy 1: Farmers can ONLY view their own application
CREATE POLICY "SECURE_farmers_own_applications_only" 
ON public.farmer_applications 
FOR SELECT 
USING (
  auth.uid() IS NOT NULL AND 
  auth.uid() = user_id
);

-- Policy 2: Farmers can ONLY create applications for themselves
CREATE POLICY "SECURE_farmers_create_own_only" 
ON public.farmer_applications 
FOR INSERT 
WITH CHECK (
  auth.uid() IS NOT NULL AND 
  auth.uid() = user_id
);

-- Policy 3: Only verified admins can view all applications (with audit logging)
CREATE POLICY "SECURE_admins_view_with_audit" 
ON public.farmer_applications 
FOR SELECT 
USING (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- Policy 4: Only verified admins can update applications
CREATE POLICY "SECURE_admins_update_only" 
ON public.farmer_applications 
FOR UPDATE 
USING (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- Policy 5: Only super admins can delete (protect audit trail)
CREATE POLICY "SECURE_super_admins_delete_only" 
ON public.farmer_applications 
FOR DELETE 
USING (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role = 'super_admin'
  )
);

-- Policy 6: Block ALL anonymous access completely
CREATE POLICY "SECURE_block_anonymous_access" 
ON public.farmer_applications 
FOR ALL
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);

-- Create secure function for admin access with comprehensive audit logging
CREATE OR REPLACE FUNCTION public.get_farmer_applications_secure_admin()
RETURNS TABLE(
  id uuid,
  user_id uuid, 
  full_name text,
  email text,
  phone text,
  farm_name text,
  farm_address text,
  farm_size text,
  farming_experience text,
  farm_description text,
  business_registration_number text,
  tax_id text,
  insurance_details text,
  categories jsonb,
  subcategories jsonb,
  processing_methods text[],
  certifications text[],
  status text,
  admin_notes text,
  reviewed_by uuid,
  reviewed_at timestamp with time zone,
  created_at timestamp with time zone,
  updated_at timestamp with time zone
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Verify admin access
  IF NOT EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  ) THEN
    RAISE EXCEPTION 'Access denied: admin role required to view farmer applications';
  END IF;
  
  -- Log the sensitive data access for audit trail
  PERFORM log_sensitive_farmer_data_access(
    NULL, -- application_id will be logged per row if needed
    ARRAY['full_name', 'email', 'phone', 'farm_address', 'business_registration_number', 'tax_id', 'insurance_details'],
    'admin_secure_function_access_all'
  );
  
  -- Return data with decryption where needed
  RETURN QUERY
  SELECT 
    fa.id,
    fa.user_id,
    fa.full_name,
    fa.email,
    CASE
      WHEN fa.phone_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(fa.phone_encrypted)
      ELSE fa.phone
    END AS phone,
    fa.farm_name,
    fa.farm_address,
    fa.farm_size,
    fa.farming_experience,
    fa.farm_description,
    CASE
      WHEN fa.business_registration_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(fa.business_registration_encrypted)
      ELSE fa.business_registration_number
    END AS business_registration_number,
    CASE
      WHEN fa.tax_id_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(fa.tax_id_encrypted)
      ELSE fa.tax_id
    END AS tax_id,
    CASE
      WHEN fa.insurance_details_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(fa.insurance_details_encrypted)
      ELSE fa.insurance_details
    END AS insurance_details,
    fa.categories,
    fa.subcategories,
    fa.processing_methods,
    fa.certifications,
    fa.status,
    fa.admin_notes,
    fa.reviewed_by,
    fa.reviewed_at,
    fa.created_at,
    fa.updated_at
  FROM farmer_applications fa
  ORDER BY fa.created_at DESC;
END;
$$;

-- Create audit log function for sensitive farmer data access
CREATE OR REPLACE FUNCTION public.log_sensitive_farmer_data_access(
  application_id uuid,
  accessed_fields text[],
  access_reason text DEFAULT 'general_access'
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  client_ip TEXT;
  user_agent TEXT;
BEGIN
  -- Get request metadata (safely)
  BEGIN
    client_ip := COALESCE(
      current_setting('request.headers', true)::json->>'x-forwarded-for',
      'unknown'
    );
    user_agent := COALESCE(
      current_setting('request.headers', true)::json->>'user-agent', 
      'unknown'
    );
  EXCEPTION
    WHEN OTHERS THEN
      client_ip := 'unknown';
      user_agent := 'unknown';
  END;

  -- Log sensitive data access
  INSERT INTO security_audit_log (
    user_id,
    action,
    table_name,
    record_id,
    ip_address,
    user_agent
  ) VALUES (
    auth.uid(),
    'sensitive_farmer_data_access: ' || access_reason || ' - fields: ' || array_to_string(accessed_fields, ','),
    'farmer_applications',
    application_id::text,
    CASE WHEN client_ip = 'unknown' THEN NULL ELSE client_ip::inet END,
    user_agent
  );
EXCEPTION
  WHEN OTHERS THEN
    -- Don't fail if logging fails
    NULL;
END;
$$;