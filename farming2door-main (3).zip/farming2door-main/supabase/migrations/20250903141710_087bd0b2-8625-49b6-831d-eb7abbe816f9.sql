-- Create function to validate farmer application uniqueness per email
CREATE OR REPLACE FUNCTION public.validate_farmer_application_email()
RETURNS trigger
LANGUAGE plpgsql
AS $function$
BEGIN
  -- Check if there's already an application with this email that's not rejected
  IF EXISTS (
    SELECT 1 
    FROM public.farmer_applications 
    WHERE email = NEW.email 
    AND status != 'rejected'
    AND id != COALESCE(NEW.id, '00000000-0000-0000-0000-000000000000'::uuid)
  ) THEN
    RAISE EXCEPTION 'An application with this email address already exists. You can only submit one application per email unless your previous application was rejected.';
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Create trigger to validate email uniqueness before insert and update
CREATE TRIGGER validate_farmer_application_email_trigger
    BEFORE INSERT OR UPDATE ON public.farmer_applications
    FOR EACH ROW
    EXECUTE FUNCTION public.validate_farmer_application_email();