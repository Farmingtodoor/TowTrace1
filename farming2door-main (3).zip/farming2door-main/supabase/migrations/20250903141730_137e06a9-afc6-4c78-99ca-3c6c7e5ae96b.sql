-- Fix search path security warning for the validation function
CREATE OR REPLACE FUNCTION public.validate_farmer_application_email()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Check if there's already an application with this email that's not rejected
  IF EXISTS (
    SELECT 1 
    FROM public.farmer_applications 
    WHERE email = NEW.email 
    AND status != 'rejected'
    AND id != COALESCE(NEW.id, '00000000-0000-0000-0000-000000000000'::uuid)
  ) THEN
    RAISE EXCEPTION 'An application with this email address already exists. You can only submit one application per email unless your previous application was rejected.';
  END IF;
  
  RETURN NEW;
END;
$function$;