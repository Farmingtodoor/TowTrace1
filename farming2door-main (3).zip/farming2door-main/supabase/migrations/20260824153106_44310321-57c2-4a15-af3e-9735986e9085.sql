-- 1. Settings (single row)
CREATE TABLE IF NOT EXISTS public.security_audit_log_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  retention_days integer NOT NULL DEFAULT 90,
  archive_enabled boolean NOT NULL DEFAULT true,
  archive_retention_days integer NOT NULL DEFAULT 365,
  last_run_at timestamptz,
  last_run_archived integer NOT NULL DEFAULT 0,
  last_run_deleted integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT single_settings_row CHECK (retention_days >= 1 AND archive_retention_days >= 1)
);

GRANT SELECT, UPDATE ON public.security_audit_log_settings TO authenticated;
GRANT ALL ON public.security_audit_log_settings TO service_role;

ALTER TABLE public.security_audit_log_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view audit retention settings"
  ON public.security_audit_log_settings FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'super_admin'));

CREATE POLICY "Admins can update audit retention settings"
  ON public.security_audit_log_settings FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'super_admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'super_admin'));

CREATE TRIGGER update_audit_retention_settings_updated_at
  BEFORE UPDATE ON public.security_audit_log_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.security_audit_log_settings (retention_days, archive_enabled, archive_retention_days)
SELECT 90, true, 365
WHERE NOT EXISTS (SELECT 1 FROM public.security_audit_log_settings);

-- 2. Archive table (mirrors security_audit_log)
CREATE TABLE IF NOT EXISTS public.security_audit_log_archive (
  id uuid PRIMARY KEY,
  user_id uuid,
  action text NOT NULL,
  table_name text,
  record_id text,
  ip_address inet,
  user_agent text,
  details jsonb,
  created_at timestamptz,
  archived_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.security_audit_log_archive TO authenticated;
GRANT ALL ON public.security_audit_log_archive TO service_role;

ALTER TABLE public.security_audit_log_archive ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view archived audit log"
  ON public.security_audit_log_archive FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'super_admin'));

CREATE INDEX IF NOT EXISTS idx_audit_archive_created_at ON public.security_audit_log_archive (created_at);
CREATE INDEX IF NOT EXISTS idx_security_audit_log_created_at ON public.security_audit_log (created_at);

-- 3. Maintenance routine
CREATE OR REPLACE FUNCTION public.run_security_audit_log_retention()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  cfg public.security_audit_log_settings%ROWTYPE;
  archived_count integer := 0;
  deleted_count integer := 0;
  purged_archive integer := 0;
BEGIN
  SELECT * INTO cfg FROM public.security_audit_log_settings ORDER BY created_at LIMIT 1;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('error', 'no retention settings configured');
  END IF;

  IF cfg.archive_enabled THEN
    WITH moved AS (
      DELETE FROM public.security_audit_log
      WHERE created_at < now() - make_interval(days => cfg.retention_days)
      RETURNING id, user_id, action, table_name, record_id, ip_address, user_agent, details, created_at
    ), inserted AS (
      INSERT INTO public.security_audit_log_archive
        (id, user_id, action, table_name, record_id, ip_address, user_agent, details, created_at)
      SELECT id, user_id, action, table_name, record_id, ip_address, user_agent, details, created_at
      FROM moved
      ON CONFLICT (id) DO NOTHING
      RETURNING 1
    )
    SELECT count(*) INTO archived_count FROM inserted;
  ELSE
    WITH removed AS (
      DELETE FROM public.security_audit_log
      WHERE created_at < now() - make_interval(days => cfg.retention_days)
      RETURNING 1
    )
    SELECT count(*) INTO deleted_count FROM removed;
  END IF;

  WITH purged AS (
    DELETE FROM public.security_audit_log_archive
    WHERE created_at < now() - make_interval(days => cfg.archive_retention_days)
    RETURNING 1
  )
  SELECT count(*) INTO purged_archive FROM purged;

  UPDATE public.security_audit_log_settings
  SET last_run_at = now(),
      last_run_archived = archived_count,
      last_run_deleted = deleted_count + purged_archive
  WHERE id = cfg.id;

  RETURN jsonb_build_object(
    'archived', archived_count,
    'deleted', deleted_count,
    'archive_purged', purged_archive,
    'ran_at', now()
  );
END;
$function$;

REVOKE EXECUTE ON FUNCTION public.run_security_audit_log_retention() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.run_security_audit_log_retention() TO service_role;

-- 4. Admin-callable manual trigger
CREATE OR REPLACE FUNCTION public.admin_run_audit_log_retention()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  IF NOT (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'super_admin')) THEN
    RAISE EXCEPTION 'Access denied: admin role required';
  END IF;
  RETURN public.run_security_audit_log_retention();
END;
$function$;

REVOKE EXECUTE ON FUNCTION public.admin_run_audit_log_retention() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_run_audit_log_retention() TO authenticated;