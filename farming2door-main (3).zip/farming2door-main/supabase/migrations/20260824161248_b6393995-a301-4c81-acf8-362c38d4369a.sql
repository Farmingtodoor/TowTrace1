-- 1) Block approval when the farmer profile has no city/state
CREATE OR REPLACE FUNCTION public.enforce_farmer_location_on_approval()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  p_city text;
  p_state text;
BEGIN
  IF NEW.status = 'approved' AND (TG_OP = 'INSERT' OR OLD.status IS DISTINCT FROM 'approved') THEN
    SELECT city, state INTO p_city, p_state
    FROM public.profiles
    WHERE id = NEW.user_id;

    IF COALESCE(NULLIF(TRIM(p_city), ''), '') = ''
       OR COALESCE(NULLIF(TRIM(p_state), ''), '') = '' THEN
      RAISE EXCEPTION 'Farm cannot be approved: the farmer profile must have both a city and a state before the farm can be listed publicly.'
        USING ERRCODE = 'check_violation';
    END IF;
  END IF;

  RETURN NEW;
END;
$function$;

DROP TRIGGER IF EXISTS enforce_farmer_location_on_approval ON public.farmer_applications;
CREATE TRIGGER enforce_farmer_location_on_approval
BEFORE INSERT OR UPDATE ON public.farmer_applications
FOR EACH ROW EXECUTE FUNCTION public.enforce_farmer_location_on_approval();

-- 2) Public listing functions only expose farms with a city/state on file
CREATE OR REPLACE FUNCTION public.get_approved_farmers_public()
RETURNS TABLE(user_id uuid, farm_name text, farm_description text, categories jsonb, subcategories jsonb, processing_methods text[], certifications text[], created_at timestamp with time zone, display_name text, general_location text, next_harvest_date date)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  RETURN QUERY
  SELECT
    fa.user_id,
    fa.farm_name,
    fa.farm_description,
    fa.categories,
    fa.subcategories,
    fa.processing_methods,
    fa.certifications,
    fa.created_at,
    CASE
      WHEN ((fa.farm_name IS NOT NULL) AND (fa.farm_name <> '')) THEN fa.farm_name
      ELSE 'Local Farm'
    END AS display_name,
    (p.city || ', ' || p.state) AS general_location,
    fa.next_harvest_date
  FROM farmer_applications fa
  JOIN profiles p ON p.id = fa.user_id
  WHERE fa.status = 'approved'
    AND COALESCE(NULLIF(TRIM(p.city), ''), '') <> ''
    AND COALESCE(NULLIF(TRIM(p.state), ''), '') <> '';
END;
$function$;

CREATE OR REPLACE FUNCTION public.get_farmers_public_safe()
RETURNS TABLE(user_id uuid, farm_name text, farm_description text, categories jsonb, subcategories jsonb, processing_methods text[], certifications text[], created_at timestamp with time zone, display_name text, next_harvest_date date)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  RETURN QUERY
  SELECT
    fa.user_id,
    fa.farm_name,
    fa.farm_description,
    fa.categories,
    fa.subcategories,
    fa.processing_methods,
    fa.certifications,
    fa.created_at,
    COALESCE(fa.farm_name, 'Local Farm') AS display_name,
    fa.next_harvest_date
  FROM farmer_applications fa
  JOIN profiles p ON p.id = fa.user_id
  WHERE fa.status = 'approved'
    AND COALESCE(NULLIF(TRIM(p.city), ''), '') <> ''
    AND COALESCE(NULLIF(TRIM(p.state), ''), '') <> '';
END;
$function$;