-- Comprehensive security fix for farmer_applications table

-- 1. Create a secure view for public farmer information (no PII)
CREATE OR REPLACE VIEW public.approved_farmers_public AS
SELECT 
  fa.user_id,
  fa.farm_name,
  fa.farm_description,
  fa.categories,
  fa.subcategories,
  fa.processing_methods,
  fa.certifications,
  fa.created_at,
  -- Generate a display name without exposing full name
  CASE 
    WHEN fa.farm_name IS NOT NULL AND fa.farm_name != '' 
    THEN fa.farm_name
    ELSE 'Local Farm'
  END as display_name,
  -- Only show general location, not full address
  CASE 
    WHEN fa.farm_address IS NOT NULL 
    THEN regexp_replace(fa.farm_address, '[0-9].*', '', 'g') -- Remove street numbers/details
    ELSE 'Local Area'
  END as general_location
FROM farmer_applications fa
WHERE fa.status = 'approved';

-- Enable RLS on the view
ALTER VIEW public.approved_farmers_public SET (security_barrier = true);

-- 2. Create a secure view for farmer contact (only for custom orders with authentication)
CREATE OR REPLACE VIEW public.farmer_contacts_secure AS
SELECT 
  fa.user_id,
  fa.farm_name,
  -- Only expose email to authenticated users for legitimate business purposes
  CASE 
    WHEN auth.uid() IS NOT NULL THEN fa.email
    ELSE NULL
  END as contact_email,
  -- Mask phone number partially
  CASE 
    WHEN auth.uid() IS NOT NULL AND fa.phone IS NOT NULL 
    THEN regexp_replace(fa.phone, '(\d{3})\d{3}(\d{4})', '\1-***-\2', 'g')
    ELSE NULL
  END as contact_phone_masked
FROM farmer_applications fa
WHERE fa.status = 'approved'
  AND auth.uid() IS NOT NULL; -- Require authentication

-- 3. Create audit logging function for PII access
CREATE OR REPLACE FUNCTION public.log_pii_access(
  table_name text,
  record_id text,
  access_type text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  client_ip text;
  user_agent text;
BEGIN
  -- Get request metadata safely
  BEGIN
    client_ip := COALESCE(
      current_setting('request.headers', true)::json->>'x-forwarded-for',
      'unknown'
    );
    user_agent := COALESCE(
      current_setting('request.headers', true)::json->>'user-agent',
      'unknown'
    );
  EXCEPTION
    WHEN OTHERS THEN
      client_ip := 'unknown';
      user_agent := 'unknown';
  END;
  
  -- Log PII access attempt
  INSERT INTO security_audit_log (
    user_id,
    action,
    table_name,
    record_id,
    ip_address,
    user_agent
  ) VALUES (
    auth.uid(),
    'pii_access_' || access_type,
    table_name,
    record_id,
    CASE WHEN client_ip = 'unknown' THEN NULL ELSE client_ip::inet END,
    user_agent
  );
EXCEPTION
  WHEN OTHERS THEN
    -- Don't fail the operation if logging fails
    NULL;
END;
$function$;

-- 4. Tighten RLS policies on farmer_applications
DROP POLICY IF EXISTS "Users can view their own applications" ON farmer_applications;
DROP POLICY IF EXISTS "Admins can view all applications" ON farmer_applications;

-- Only users can view their own applications (with audit logging)
CREATE POLICY "Users can view own applications with audit"
ON farmer_applications FOR SELECT
USING (
  auth.uid() = user_id 
  AND (
    -- Log the access
    public.log_pii_access('farmer_applications', id::text, 'own_application') IS NULL
    OR true -- Always allow after logging
  )
);

-- Only super admins and admins can view all applications (with audit logging)
CREATE POLICY "Admins can view all applications with audit"
ON farmer_applications FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
  AND (
    -- Log the admin access
    public.log_pii_access('farmer_applications', id::text, 'admin_access') IS NULL
    OR true -- Always allow after logging
  )
);

-- 5. Add email masking function for safer display
CREATE OR REPLACE FUNCTION public.mask_email(email text)
RETURNS text
LANGUAGE plpgsql
IMMUTABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  local_part text;
  domain_part text;
  masked_local text;
BEGIN
  -- Split email into local and domain parts
  local_part := split_part(email, '@', 1);
  domain_part := split_part(email, '@', 2);
  
  -- Mask the local part (keep first and last character, mask middle)
  IF length(local_part) <= 2 THEN
    masked_local := regexp_replace(local_part, '.', '*', 'g');
  ELSE
    masked_local := left(local_part, 1) || 
                   regexp_replace(substring(local_part, 2, length(local_part)-2), '.', '*', 'g') || 
                   right(local_part, 1);
  END IF;
  
  RETURN masked_local || '@' || domain_part;
END;
$function$;

-- 6. Add phone masking function
CREATE OR REPLACE FUNCTION public.mask_phone(phone text)
RETURNS text
LANGUAGE plpgsql
IMMUTABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  IF phone IS NULL THEN
    RETURN NULL;
  END IF;
  
  -- Keep area code and last 4 digits, mask middle
  RETURN regexp_replace(phone, '(\d{3}).*(\d{4})', '\1-***-\2', 'g');
END;
$function$;

-- 7. Create trigger to audit PII access on farmer_applications
CREATE OR REPLACE FUNCTION public.audit_farmer_app_access()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Log when someone accesses farmer application data
  IF TG_OP = 'SELECT' THEN
    PERFORM public.log_pii_access('farmer_applications', NEW.id::text, 'direct_select');
  END IF;
  
  RETURN COALESCE(NEW, OLD);
END;
$function$;