ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS pickup_slot_id uuid REFERENCES public.farmer_pickup_slots(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS pickup_scheduled_at timestamptz,
  ADD COLUMN IF NOT EXISTS pickup_scheduled_end timestamptz;

CREATE INDEX IF NOT EXISTS idx_orders_pickup_slot ON public.orders (pickup_slot_id, pickup_scheduled_at);

CREATE OR REPLACE FUNCTION public.get_available_pickup_slots(_farmer_id uuid, _days integer DEFAULT 14)
RETURNS TABLE (
  slot_id uuid,
  pickup_date date,
  start_time time,
  end_time time,
  capacity integer,
  booked integer,
  remaining integer,
  location_note text
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  WITH days AS (
    SELECT (CURRENT_DATE + i)::date AS d
    FROM generate_series(0, GREATEST(LEAST(COALESCE(_days, 14), 60), 1) - 1) AS i
  )
  SELECT
    s.id AS slot_id,
    d.d AS pickup_date,
    s.start_time,
    s.end_time,
    s.capacity,
    COALESCE(b.cnt, 0)::int AS booked,
    GREATEST(s.capacity - COALESCE(b.cnt, 0), 0)::int AS remaining,
    s.location_note
  FROM public.farmer_pickup_slots s
  JOIN days d ON EXTRACT(DOW FROM d.d)::int = s.day_of_week
  LEFT JOIN LATERAL (
    SELECT count(*) AS cnt
    FROM public.orders o
    WHERE o.pickup_slot_id = s.id
      AND o.pickup_scheduled_at::date = d.d
      AND o.status NOT IN ('cancelled', 'rejected')
  ) b ON true
  WHERE s.farmer_id = _farmer_id
    AND s.is_active = true
    AND (d.d + s.start_time) > now()
  ORDER BY d.d, s.start_time;
$$;

GRANT EXECUTE ON FUNCTION public.get_available_pickup_slots(uuid, integer) TO anon, authenticated, service_role;