-- Fix RLS policies for conversations table
DROP POLICY IF EXISTS "Users can create conversations they are part of" ON conversations;
CREATE POLICY "Users can create conversations they are part of" 
ON conversations 
FOR INSERT 
WITH CHECK (auth.uid() = customer_id OR auth.uid() = farmer_id);

-- Fix RLS policies for messages table  
DROP POLICY IF EXISTS "Users can send messages in their conversations" ON messages;
CREATE POLICY "Users can send messages in their conversations" 
ON messages 
FOR INSERT 
WITH CHECK (
  auth.uid() = sender_id AND
  EXISTS (
    SELECT 1 FROM conversations c 
    WHERE c.id = messages.conversation_id 
    AND (c.customer_id = auth.uid() OR c.farmer_id = auth.uid())
  )
);