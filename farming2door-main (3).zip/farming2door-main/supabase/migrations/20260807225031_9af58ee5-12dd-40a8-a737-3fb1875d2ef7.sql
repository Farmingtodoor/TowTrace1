CREATE TABLE public.pickup_reminders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  reminder_type text NOT NULL,
  sent_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (order_id, reminder_type)
);

GRANT SELECT ON public.pickup_reminders TO authenticated;
GRANT ALL ON public.pickup_reminders TO service_role;

ALTER TABLE public.pickup_reminders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Order participants can view pickup reminders"
ON public.pickup_reminders FOR SELECT TO authenticated
USING (EXISTS (
  SELECT 1 FROM public.orders o
  WHERE o.id = pickup_reminders.order_id
    AND (o.customer_id = auth.uid() OR o.farmer_id = auth.uid())
));

CREATE INDEX idx_pickup_reminders_order ON public.pickup_reminders(order_id);
CREATE INDEX idx_orders_pickup_scheduled_at ON public.orders(pickup_scheduled_at) WHERE pickup_scheduled_at IS NOT NULL;