-- Update delivery partners to be more accessible for testing
UPDATE delivery_partners 
SET 
  minimum_order_amount = 1.00,
  maximum_delivery_distance_miles = 100
WHERE slug IN ('doordash', 'uber-eats');