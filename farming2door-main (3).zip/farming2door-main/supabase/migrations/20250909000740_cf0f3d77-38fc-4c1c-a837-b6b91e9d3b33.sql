-- FINAL SECURITY FIX: Address plain text sensitive data in farmer_applications
-- The scanner detects that plain text versions of sensitive data still exist alongside encrypted versions

-- 1. Clear any remaining plain text sensitive data where encrypted versions exist
UPDATE public.farmer_applications 
SET 
  phone = NULL,
  tax_id = NULL,
  business_registration_number = NULL,
  insurance_details = NULL
WHERE 
  phone_encrypted IS NOT NULL OR
  tax_id_encrypted IS NOT NULL OR
  business_registration_encrypted IS NOT NULL OR
  insurance_details_encrypted IS NOT NULL;

-- 2. Add database-level constraints to prevent storing plain text where encryption exists
-- Create a function to check data consistency
CREATE OR REPLACE FUNCTION public.check_sensitive_data_encryption()
RETURNS TRIGGER AS $$
BEGIN
  -- If encrypted version exists, clear plain text version
  IF NEW.phone_encrypted IS NOT NULL THEN
    NEW.phone := mask_phone(NEW.phone); -- Keep masked version only
  END IF;
  
  IF NEW.tax_id_encrypted IS NOT NULL THEN
    NEW.tax_id := NULL; -- Remove plain text completely
  END IF;
  
  IF NEW.business_registration_encrypted IS NOT NULL THEN
    NEW.business_registration_number := NULL; -- Remove plain text completely
  END IF;
  
  IF NEW.insurance_details_encrypted IS NOT NULL THEN
    NEW.insurance_details := NULL; -- Remove plain text completely
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- 3. Create trigger to enforce data encryption consistency
DROP TRIGGER IF EXISTS enforce_data_encryption ON public.farmer_applications;
CREATE TRIGGER enforce_data_encryption
  BEFORE INSERT OR UPDATE ON public.farmer_applications
  FOR EACH ROW
  EXECUTE FUNCTION public.check_sensitive_data_encryption();

-- 4. Update all secure functions to never return plain text sensitive data
-- Update the admin function to only return encrypted data when available
CREATE OR REPLACE FUNCTION public.get_farmer_application_secure(application_id UUID)
RETURNS TABLE(
  id UUID,
  user_id UUID,
  full_name TEXT,
  email TEXT,
  phone TEXT,
  farm_name TEXT,
  farm_address TEXT,
  farm_size TEXT,
  farming_experience TEXT,
  farm_description TEXT,
  tax_id TEXT,
  business_registration_number TEXT,
  insurance_details TEXT,
  categories JSONB,
  subcategories JSONB,
  processing_methods TEXT[],
  certifications TEXT[],
  status TEXT,
  admin_notes TEXT,
  reviewed_by UUID,
  reviewed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE,
  updated_at TIMESTAMP WITH TIME ZONE
) AS $$
BEGIN
  -- Verify admin access
  IF NOT EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  ) THEN
    RAISE EXCEPTION 'Access denied: admin role required';
  END IF;
  
  -- Log the sensitive data access
  PERFORM log_sensitive_farmer_data_access(
    application_id,
    ARRAY['full_name', 'email', 'phone', 'farm_address', 'tax_id', 'business_registration_number', 'insurance_details'],
    'admin_secure_access_v2'
  );
  
  -- Return data with preference for encrypted versions
  RETURN QUERY
  SELECT 
    fa.id,
    fa.user_id,
    fa.full_name,
    fa.email, -- Email is still needed for admin functions
    CASE
      WHEN fa.phone_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(fa.phone_encrypted)
      ELSE COALESCE(fa.phone, 'Not provided')
    END AS phone,
    fa.farm_name,
    fa.farm_address,
    fa.farm_size,
    fa.farming_experience,
    fa.farm_description,
    CASE
      WHEN fa.tax_id_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(fa.tax_id_encrypted)
      ELSE COALESCE(fa.tax_id, 'Not provided')
    END AS tax_id,
    CASE
      WHEN fa.business_registration_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(fa.business_registration_encrypted)
      ELSE COALESCE(fa.business_registration_number, 'Not provided')
    END AS business_registration_number,
    CASE
      WHEN fa.insurance_details_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(fa.insurance_details_encrypted)
      ELSE COALESCE(fa.insurance_details, 'Not provided')
    END AS insurance_details,
    fa.categories,
    fa.subcategories,
    fa.processing_methods,
    fa.certifications,
    fa.status,
    fa.admin_notes,
    fa.reviewed_by,
    fa.reviewed_at,
    fa.created_at,
    fa.updated_at
  FROM farmer_applications fa
  WHERE fa.id = application_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- 5. Final security audit log
INSERT INTO public.security_audit_log (
  action,
  table_name,
  record_id
) VALUES (
  'SECURITY_FIX_COMPLETE: Removed plain text sensitive data, enforced encryption',
  'farmer_applications',
  'Cleared all plain text versions where encrypted versions exist, added trigger to prevent future plain text storage'
);

-- 6. Update table documentation
COMMENT ON TABLE public.farmer_applications IS 
'SECURITY CRITICAL: Contains sensitive PII. All sensitive data must be encrypted.
Plain text versions of phone, tax_id, business_registration_number, and insurance_details
are automatically removed when encrypted versions exist. Email access restricted to authenticated users only.';