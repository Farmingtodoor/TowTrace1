-- Fix app_notifications security vulnerabilities (corrected)

-- 1. Add email validation function
CREATE OR REPLACE FUNCTION public.is_valid_email(email text)
RETURNS boolean
LANGUAGE plpgsql
IMMUTABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Basic email validation
  RETURN email ~ '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'
    AND length(email) <= 254
    AND length(email) >= 5
    AND email NOT LIKE '%@%@%' -- No double @
    AND email NOT LIKE '.%' -- Can't start with dot
    AND email NOT LIKE '%.' -- Can't end with dot
    AND email NOT LIKE '%..%'; -- No double dots
END;
$function$;

-- 2. Add suspicious email detection
CREATE OR REPLACE FUNCTION public.is_suspicious_email(email text)
RETURNS boolean
LANGUAGE plpgsql
IMMUTABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  RETURN
    -- Check for common spam patterns
    email ~ '.*[0-9]{4,}.*' OR -- Too many consecutive numbers
    email ~ '.*test.*' OR
    email ~ '.*fake.*' OR
    email ~ '.*spam.*' OR
    email ~ '.*temp.*' OR
    -- Check for suspicious domains
    email ~ '@(10minutemail|guerrillamail|mailinator|tempmail)\..*' OR
    -- Check for excessive length or repetitive characters
    length(email) > 100 OR
    email ~ '(.)\1{4,}'; -- Same character repeated 5+ times
END;
$function$;

-- 3. Drop existing policy and create secure one
DROP POLICY IF EXISTS "Anyone can subscribe to app notifications" ON app_notifications;
DROP POLICY IF EXISTS "Secure email subscription policy" ON app_notifications;

CREATE POLICY "Secure email subscription policy"
ON app_notifications FOR INSERT
WITH CHECK (
  -- Validate email format
  public.is_valid_email(email) = true
  -- Block suspicious emails  
  AND public.is_suspicious_email(email) = false
  -- Ensure email is not empty or whitespace
  AND trim(email) != ''
  AND length(trim(email)) >= 5
);

-- 4. Add unique constraint to prevent duplicate subscriptions
ALTER TABLE app_notifications 
DROP CONSTRAINT IF EXISTS app_notifications_email_key;

ALTER TABLE app_notifications 
ADD CONSTRAINT app_notifications_email_key UNIQUE (email);

-- 5. Add audit logging for subscription attempts
CREATE OR REPLACE FUNCTION public.log_subscription_attempt()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  client_ip text;
  user_agent text;
BEGIN
  -- Get request metadata safely
  BEGIN
    client_ip := COALESCE(
      current_setting('request.headers', true)::json->>'x-forwarded-for',
      'unknown'
    );
    user_agent := COALESCE(
      current_setting('request.headers', true)::json->>'user-agent',
      'unknown'
    );
  EXCEPTION
    WHEN OTHERS THEN
      client_ip := 'unknown';
      user_agent := 'unknown';
  END;
  
  -- Log the subscription attempt
  INSERT INTO security_audit_log (
    user_id,
    action,
    table_name,
    record_id,
    ip_address,
    user_agent
  ) VALUES (
    NULL, -- No user ID for public subscriptions
    'email_subscription',
    'app_notifications',
    NEW.id::text,
    CASE WHEN client_ip = 'unknown' THEN NULL ELSE client_ip::inet END,
    user_agent
  );
  
  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Don't fail the insert if logging fails
    RETURN NEW;
END;
$function$;

-- 6. Create trigger for audit logging
DROP TRIGGER IF EXISTS log_email_subscriptions ON app_notifications;
CREATE TRIGGER log_email_subscriptions
  AFTER INSERT ON app_notifications
  FOR EACH ROW
  EXECUTE FUNCTION public.log_subscription_attempt();