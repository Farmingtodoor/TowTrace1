-- CRITICAL SECURITY FIX: Completely lock down farmer_applications table
-- This addresses the reported security vulnerability about email harvesting

-- 1. Drop all existing policies to start fresh
DROP POLICY IF EXISTS "Admins can update applications" ON public.farmer_applications;
DROP POLICY IF EXISTS "Admins can view all applications" ON public.farmer_applications;
DROP POLICY IF EXISTS "Block anonymous access" ON public.farmer_applications;
DROP POLICY IF EXISTS "Super admins can delete applications" ON public.farmer_applications;
DROP POLICY IF EXISTS "Users can create own applications" ON public.farmer_applications;
DROP POLICY IF EXISTS "Users can view own applications" ON public.farmer_applications;

-- 2. Create extremely restrictive policies with explicit denial for anonymous users

-- CRITICAL: Explicitly deny ALL access to anonymous users
CREATE POLICY "SECURITY_CRITICAL_Block_all_anonymous_access" 
ON public.farmer_applications 
FOR ALL 
TO anon
USING (false)
WITH CHECK (false);

-- CRITICAL: Explicitly deny ALL access to public role
CREATE POLICY "SECURITY_CRITICAL_Block_all_public_access" 
ON public.farmer_applications 
FOR ALL 
TO public
USING (false)
WITH CHECK (false);

-- 3. Only allow authenticated users with specific, restrictive permissions

-- Only allow authenticated users to view their OWN applications
CREATE POLICY "AUTHENTICATED_users_own_applications_only" 
ON public.farmer_applications 
FOR SELECT 
TO authenticated
USING (
  auth.uid() IS NOT NULL 
  AND auth.uid() = user_id
);

-- Only allow authenticated users to create applications for themselves
CREATE POLICY "AUTHENTICATED_users_create_own_only" 
ON public.farmer_applications 
FOR INSERT 
TO authenticated
WITH CHECK (
  auth.uid() IS NOT NULL 
  AND auth.uid() = user_id
);

-- Only allow authenticated admins to view all applications
CREATE POLICY "AUTHENTICATED_admins_view_all_only" 
ON public.farmer_applications 
FOR SELECT 
TO authenticated
USING (
  auth.uid() IS NOT NULL 
  AND EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- Only allow authenticated admins to update applications
CREATE POLICY "AUTHENTICATED_admins_update_only" 
ON public.farmer_applications 
FOR UPDATE 
TO authenticated
USING (
  auth.uid() IS NOT NULL 
  AND EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- Only allow authenticated super admins to delete applications
CREATE POLICY "AUTHENTICATED_super_admins_delete_only" 
ON public.farmer_applications 
FOR DELETE 
TO authenticated
USING (
  auth.uid() IS NOT NULL 
  AND EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() 
    AND role = 'super_admin'
  )
);

-- 4. Add additional security constraints
-- Revoke any default permissions
REVOKE ALL ON public.farmer_applications FROM anon;
REVOKE ALL ON public.farmer_applications FROM public;

-- Only grant minimal necessary permissions to authenticated users
GRANT SELECT, INSERT ON public.farmer_applications TO authenticated;

-- 5. Log this critical security fix
INSERT INTO public.security_audit_log (
  action,
  table_name,
  record_id
) VALUES (
  'CRITICAL_SECURITY_FIX: Completely secured farmer_applications table',
  'farmer_applications',
  'Implemented zero-tolerance security policies blocking all anonymous/public access to emails and PII'
);

-- 6. Add security documentation
COMMENT ON TABLE public.farmer_applications IS 
'SECURITY CRITICAL: Contains sensitive PII including emails, phone numbers, tax IDs. 
ZERO anonymous access permitted. All access logged and restricted to authenticated users only.
NO EXCEPTIONS for public or anonymous roles.';

COMMENT ON COLUMN public.farmer_applications.email IS 'SENSITIVE PII: Email addresses must never be accessible to anonymous users';
COMMENT ON COLUMN public.farmer_applications.phone IS 'SENSITIVE PII: Phone numbers must never be accessible to anonymous users';
COMMENT ON COLUMN public.farmer_applications.full_name IS 'SENSITIVE PII: Full names must never be accessible to anonymous users';