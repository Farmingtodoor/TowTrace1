CREATE OR REPLACE FUNCTION public.get_farmer_public_locations(_user_ids uuid[])
RETURNS TABLE (id uuid, city text, state text, country text, zip_code text)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT p.id, p.city, p.state, p.country, p.zip_code
  FROM public.profiles p
  WHERE p.id = ANY(_user_ids)
    AND EXISTS (
      SELECT 1 FROM public.farmer_applications fa
      WHERE fa.user_id = p.id AND fa.status = 'approved'
    );
$$;

REVOKE ALL ON FUNCTION public.get_farmer_public_locations(uuid[]) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_farmer_public_locations(uuid[]) TO anon, authenticated, service_role;