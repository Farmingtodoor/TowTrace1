-- Create product recommendations table
CREATE TABLE public.product_recommendations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  recommended_product_id UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  recommendation_type TEXT NOT NULL CHECK (recommendation_type IN ('similar', 'frequently_bought_together', 'seasonal', 'farmer_suggests')),
  score DECIMAL DEFAULT 1.0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(product_id, recommended_product_id, recommendation_type)
);

-- Create customer browsing history table
CREATE TABLE public.browsing_history (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  viewed_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  session_id TEXT,
  referrer TEXT
);

-- Create seasonal alerts table
CREATE TABLE public.seasonal_alerts (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  product_category TEXT NOT NULL,
  product_name TEXT,
  farmer_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  alert_month INTEGER CHECK (alert_month >= 1 AND alert_month <= 12),
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  last_notified_at TIMESTAMP WITH TIME ZONE
);

-- Create inventory tracking table
CREATE TABLE public.inventory_tracking (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id UUID NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  stock_level INTEGER NOT NULL DEFAULT 0,
  low_stock_threshold INTEGER NOT NULL DEFAULT 5,
  reorder_point INTEGER NOT NULL DEFAULT 10,
  last_updated TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  notes TEXT,
  UNIQUE(product_id)
);

-- Enable RLS
ALTER TABLE public.product_recommendations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.browsing_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.seasonal_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inventory_tracking ENABLE ROW LEVEL SECURITY;

-- Product Recommendations Policies
CREATE POLICY "Anyone can view product recommendations" 
ON public.product_recommendations 
FOR SELECT 
USING (true);

CREATE POLICY "Farmers can manage recommendations for their products" 
ON public.product_recommendations 
FOR ALL 
USING (EXISTS (
  SELECT 1 FROM public.products p 
  WHERE p.id = product_recommendations.product_id 
  AND p.farmer_id = auth.uid()
));

-- Browsing History Policies
CREATE POLICY "Users can view their own browsing history" 
ON public.browsing_history 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own browsing history" 
ON public.browsing_history 
FOR INSERT 
WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

-- Seasonal Alerts Policies
CREATE POLICY "Users can manage their own seasonal alerts" 
ON public.seasonal_alerts 
FOR ALL 
USING (auth.uid() = user_id);

-- Inventory Tracking Policies
CREATE POLICY "Farmers can view inventory for their products" 
ON public.inventory_tracking 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM public.products p 
  WHERE p.id = inventory_tracking.product_id 
  AND p.farmer_id = auth.uid()
));

CREATE POLICY "Farmers can manage inventory for their products" 
ON public.inventory_tracking 
FOR ALL 
USING (EXISTS (
  SELECT 1 FROM public.products p 
  WHERE p.id = inventory_tracking.product_id 
  AND p.farmer_id = auth.uid()
));

-- Create function to track product views
CREATE OR REPLACE FUNCTION public.track_product_view(
  p_product_id UUID,
  p_user_id UUID DEFAULT NULL,
  p_session_id TEXT DEFAULT NULL
) RETURNS VOID AS $$
BEGIN
  INSERT INTO public.browsing_history (user_id, product_id, session_id, viewed_at)
  VALUES (p_user_id, p_product_id, p_session_id, now())
  ON CONFLICT DO NOTHING;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to get product recommendations
CREATE OR REPLACE FUNCTION public.get_product_recommendations(
  p_product_id UUID,
  p_limit INTEGER DEFAULT 4
) RETURNS TABLE(
  product_id UUID,
  name TEXT,
  price NUMERIC,
  image_url TEXT,
  farmer_name TEXT,
  recommendation_score DECIMAL
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id as product_id,
    p.name,
    p.price,
    p.image_url,
    p.farmer as farmer_name,
    pr.score as recommendation_score
  FROM public.product_recommendations pr
  JOIN public.products p ON pr.recommended_product_id = p.id
  WHERE pr.product_id = p_product_id
    AND p.is_available = true
  ORDER BY pr.score DESC, p.created_at DESC
  LIMIT p_limit;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create function to generate automatic recommendations based on orders
CREATE OR REPLACE FUNCTION public.generate_order_based_recommendations()
RETURNS VOID AS $$
DECLARE
  rec RECORD;
BEGIN
  -- Generate "frequently bought together" recommendations
  FOR rec IN
    SELECT 
      oi1.product_name as product1,
      oi2.product_name as product2,
      COUNT(*) as frequency
    FROM order_items oi1
    JOIN order_items oi2 ON oi1.order_id = oi2.order_id AND oi1.id != oi2.id
    GROUP BY oi1.product_name, oi2.product_name
    HAVING COUNT(*) >= 2
  LOOP
    -- Find actual product IDs and insert recommendations
    INSERT INTO product_recommendations (product_id, recommended_product_id, recommendation_type, score)
    SELECT 
      p1.id,
      p2.id,
      'frequently_bought_together',
      (rec.frequency::DECIMAL / 10.0) -- Normalize score
    FROM products p1
    JOIN products p2 ON p1.name = rec.product1 AND p2.name = rec.product2
    WHERE p1.id != p2.id
    ON CONFLICT (product_id, recommended_product_id, recommendation_type) 
    DO UPDATE SET score = EXCLUDED.score;
  END LOOP;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create indexes for better performance
CREATE INDEX idx_browsing_history_user_id ON public.browsing_history(user_id);
CREATE INDEX idx_browsing_history_product_id ON public.browsing_history(product_id);
CREATE INDEX idx_browsing_history_viewed_at ON public.browsing_history(viewed_at DESC);
CREATE INDEX idx_product_recommendations_product_id ON public.product_recommendations(product_id);
CREATE INDEX idx_seasonal_alerts_user_id ON public.seasonal_alerts(user_id);
CREATE INDEX idx_seasonal_alerts_alert_month ON public.seasonal_alerts(alert_month);
CREATE INDEX idx_inventory_tracking_product_id ON public.inventory_tracking(product_id);