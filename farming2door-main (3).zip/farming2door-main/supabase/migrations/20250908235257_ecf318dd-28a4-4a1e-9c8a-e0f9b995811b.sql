-- CRITICAL SECURITY FIX: Secure farmer data views
-- This migration fixes publicly accessible views that expose sensitive farmer personal information

-- 1. Enable RLS on all farmer-related views
ALTER TABLE public.farmer_applications_secure ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.approved_farmers_public ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.farmers_public_safe ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.farmer_contacts_secure ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.farmer_contacts_auth ENABLE ROW LEVEL SECURITY;

-- 2. Secure farmer_applications_secure view - MOST CRITICAL
-- Only allow admins and super_admins to access this view
CREATE POLICY "Only admins can access secure farmer applications" 
ON public.farmer_applications_secure 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- 3. Secure farmer_contacts_secure view
CREATE POLICY "Only admins can access secure farmer contacts" 
ON public.farmer_contacts_secure 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- 4. Secure farmer_contacts_auth view
CREATE POLICY "Only admins can access farmer contact auth" 
ON public.farmer_contacts_auth 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- 5. For approved_farmers_public - Allow public read but remove sensitive fields if any
-- This should only contain non-sensitive public information
CREATE POLICY "Anyone can view public farmer info" 
ON public.approved_farmers_public 
FOR SELECT 
USING (true);

-- 6. For farmers_public_safe - Allow public read as it should be safe
CREATE POLICY "Anyone can view safe farmer info" 
ON public.farmers_public_safe 
FOR SELECT 
USING (true);

-- 7. Add audit logging for sensitive data access
CREATE OR REPLACE FUNCTION public.log_sensitive_view_access(view_name TEXT, accessed_data TEXT)
RETURNS VOID AS $$
BEGIN
  -- Log access to sensitive farmer data views
  INSERT INTO public.security_audit_log (
    user_id,
    action,
    table_name,
    record_id
  ) VALUES (
    auth.uid(),
    'sensitive_view_access: ' || view_name,
    view_name,
    accessed_data
  );
EXCEPTION
  WHEN OTHERS THEN
    -- Don't fail if logging fails
    NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- 8. Add comprehensive logging to the most sensitive view
-- Update farmer_applications_secure to include logging (if it's a view, we can't add triggers)
-- Instead, document that access should be logged by calling functions

COMMENT ON TABLE public.farmer_applications_secure IS 'SENSITIVE DATA: Contains full farmer personal information including PII. Access is restricted to admins only and should be logged.';
COMMENT ON TABLE public.farmer_contacts_secure IS 'SENSITIVE DATA: Contains farmer contact information. Access restricted to admins only.';
COMMENT ON TABLE public.farmer_contacts_auth IS 'SENSITIVE DATA: Contains farmer authentication contact info. Access restricted to admins only.';