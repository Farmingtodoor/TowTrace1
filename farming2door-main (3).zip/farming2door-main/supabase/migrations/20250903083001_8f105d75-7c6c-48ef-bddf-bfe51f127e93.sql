-- Create app_notifications table to store email addresses for mobile app launch notifications
CREATE TABLE public.app_notifications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  notified BOOLEAN NOT NULL DEFAULT false
);

-- Enable Row Level Security
ALTER TABLE public.app_notifications ENABLE ROW LEVEL SECURITY;

-- Create policy for anyone to insert their email
CREATE POLICY "Anyone can subscribe to app notifications" 
ON public.app_notifications 
FOR INSERT 
WITH CHECK (true);

-- Create policy for viewing (admin only - no public access needed)
CREATE POLICY "No public access to app notifications" 
ON public.app_notifications 
FOR SELECT 
USING (false);