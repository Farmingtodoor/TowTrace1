-- Create products table for authoritative pricing
CREATE TABLE public.products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  farmer TEXT NOT NULL,
  price NUMERIC NOT NULL,
  category TEXT NOT NULL,
  is_organic BOOLEAN DEFAULT false,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

-- Create policy to allow anyone to view products (public marketplace)
CREATE POLICY "Anyone can view products" 
ON public.products 
FOR SELECT 
USING (true);

-- Create add-ons table for authoritative pricing
CREATE TABLE public.add_ons (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  price NUMERIC NOT NULL,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security for add-ons
ALTER TABLE public.add_ons ENABLE ROW LEVEL SECURITY;

-- Create policy to allow anyone to view add-ons
CREATE POLICY "Anyone can view add-ons" 
ON public.add_ons 
FOR SELECT 
USING (true);

-- Insert sample products
INSERT INTO public.products (name, farmer, price, category, is_organic, description) VALUES
('Fresh Tomatoes', 'Green Valley Farm', 4.99, 'Vegetables', true, 'Organic vine-ripened tomatoes'),
('Free-Range Eggs', 'Sunny Meadow Farm', 6.50, 'Dairy & Eggs', true, 'Farm-fresh free-range eggs'),
('Raw Honey', 'Wildflower Apiary', 12.00, 'Pantry', true, 'Pure wildflower honey'),
('Mixed Greens', 'Harvest Moon Farm', 5.99, 'Vegetables', true, 'Fresh organic salad mix'),
('Grass-Fed Beef', 'Prairie Wind Ranch', 18.99, 'Meat', true, 'Premium grass-fed ground beef');

-- Insert sample add-ons
INSERT INTO public.add_ons (id, name, price, description) VALUES
('express', 'Express Processing', 2.99, 'Priority handling and faster processing'),
('packaging', 'Premium Packaging', 1.99, 'Eco-friendly premium packaging'),
('insurance', 'Order Insurance', 0.99, 'Protection against damaged or lost items');

-- Create trigger for updated_at
CREATE TRIGGER update_products_updated_at
BEFORE UPDATE ON public.products
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();