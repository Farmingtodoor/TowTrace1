-- CRITICAL SECURITY FIX: Remove dangerous views that expose sensitive farmer data
-- Step 1: Remove the views that bypass RLS and expose sensitive PII

-- Drop the most dangerous view that exposes decrypted sensitive data
DROP VIEW IF EXISTS public.farmer_applications_secure;

-- Drop other potentially dangerous views
DROP VIEW IF EXISTS public.farmer_contacts_secure;
DROP VIEW IF EXISTS public.farmer_contacts_auth;

-- Create secure replacement function for admin access to farmer applications
CREATE OR REPLACE FUNCTION public.get_farmer_application_secure(application_id UUID)
RETURNS TABLE(
  id UUID,
  user_id UUID,
  full_name TEXT,
  email TEXT,
  phone TEXT,
  farm_name TEXT,
  farm_address TEXT,
  farm_size TEXT,
  farming_experience TEXT,
  farm_description TEXT,
  tax_id TEXT,
  business_registration_number TEXT,
  insurance_details TEXT,
  categories JSONB,
  subcategories JSONB,
  processing_methods TEXT[],
  certifications TEXT[],
  status TEXT,
  admin_notes TEXT,
  reviewed_by UUID,
  reviewed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE,
  updated_at TIMESTAMP WITH TIME ZONE
) AS $$
BEGIN
  -- Verify admin access
  IF NOT EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  ) THEN
    RAISE EXCEPTION 'Access denied: admin role required';
  END IF;
  
  -- Log the sensitive data access
  PERFORM log_sensitive_farmer_data_access(
    application_id,
    ARRAY['full_name', 'email', 'phone', 'farm_address', 'tax_id', 'business_registration_number', 'insurance_details'],
    'admin_full_access'
  );
  
  -- Return decrypted data
  RETURN QUERY
  SELECT * FROM farmer_applications_secure 
  WHERE farmer_applications_secure.id = application_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Add security documentation
COMMENT ON FUNCTION public.get_farmer_application_secure(UUID) IS 
'ADMIN ONLY: Secure function to access farmer application data with decrypted sensitive fields. Requires admin role and logs access.';

-- Document the security fix in audit log
INSERT INTO public.security_audit_log (
  action,
  table_name,
  record_id
) VALUES (
  'SECURITY_FIX: Removed public views exposing farmer PII',
  'farmer_applications_secure',
  'Removed farmer_applications_secure, farmer_contacts_secure, farmer_contacts_auth views'
);