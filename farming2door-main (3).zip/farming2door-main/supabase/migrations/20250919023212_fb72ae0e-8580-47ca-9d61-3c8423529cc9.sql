-- Fix critical security vulnerabilities by updating RLS policies

-- 1. PROFILES TABLE - Fix public access to user data
DROP POLICY IF EXISTS "SECURE_admins_view_all_profiles_only" ON public.profiles;
DROP POLICY IF EXISTS "SECURE_block_anonymous_profile_access" ON public.profiles;
DROP POLICY IF EXISTS "SECURE_super_admins_delete_profiles_only" ON public.profiles;
DROP POLICY IF EXISTS "SECURE_users_own_profile_only" ON public.profiles;

-- Create secure policies for profiles
CREATE POLICY "Users can view their own profile only" 
ON public.profiles 
FOR SELECT 
USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile only" 
ON public.profiles 
FOR UPDATE 
USING (auth.uid() = id);

CREATE POLICY "Users can insert their own profile only" 
ON public.profiles 
FOR INSERT 
WITH CHECK (auth.uid() = id);

CREATE POLICY "Admins can view all profiles" 
ON public.profiles 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

CREATE POLICY "Super admins can delete profiles" 
ON public.profiles 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role = 'super_admin'
  )
);

-- 2. CUSTOMER_INSIGHTS TABLE - Already has proper policies, just ensure no public access
-- Verify the existing policies are working correctly

-- 3. DRIVER_PROFILES TABLE - Already has proper policies but let's ensure they're secure
-- The existing policies look correct, no changes needed

-- 4. FARMER_APPLICATIONS TABLE - Already has proper policies but let's ensure they're secure
-- The existing policies look correct, no changes needed

-- 5. PAYOUT_REQUESTS TABLE - Already has proper policies but let's ensure they're secure
-- The existing policies look correct, no changes needed

-- Block all anonymous access to sensitive tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customer_insights ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.driver_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.farmer_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payout_requests ENABLE ROW LEVEL SECURITY;

-- Ensure no public access by default for all users
REVOKE ALL ON public.profiles FROM anon, authenticated;
REVOKE ALL ON public.customer_insights FROM anon, authenticated;
REVOKE ALL ON public.driver_profiles FROM anon, authenticated;
REVOKE ALL ON public.farmer_applications FROM anon, authenticated;
REVOKE ALL ON public.payout_requests FROM anon, authenticated;

-- Grant specific permissions only through RLS policies
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT SELECT ON public.customer_insights TO authenticated;
GRANT SELECT, INSERT, UPDATE ON public.driver_profiles TO authenticated;
GRANT SELECT, INSERT, UPDATE ON public.farmer_applications TO authenticated;
GRANT SELECT, INSERT, UPDATE ON public.payout_requests TO authenticated;