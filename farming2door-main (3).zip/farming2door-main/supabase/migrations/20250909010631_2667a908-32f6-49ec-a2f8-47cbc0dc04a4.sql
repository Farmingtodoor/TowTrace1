-- Add freshness_type field to products table for produce items
ALTER TABLE public.products 
ADD COLUMN freshness_type TEXT CHECK (freshness_type IN ('fresh', 'frozen') OR freshness_type IS NULL);