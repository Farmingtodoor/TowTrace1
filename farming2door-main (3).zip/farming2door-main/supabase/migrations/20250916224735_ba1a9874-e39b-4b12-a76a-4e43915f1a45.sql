-- Drop and recreate the get_farmers_public_safe function with next_harvest_date
DROP FUNCTION IF EXISTS public.get_farmers_public_safe();

CREATE OR REPLACE FUNCTION public.get_farmers_public_safe()
 RETURNS TABLE(user_id uuid, farm_name text, farm_description text, categories jsonb, subcategories jsonb, processing_methods text[], certifications text[], created_at timestamp with time zone, display_name text, next_harvest_date date)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  -- This function returns only approved, safe farmer data
  RETURN QUERY
  SELECT 
    fa.user_id,
    fa.farm_name,
    fa.farm_description,
    fa.categories,
    fa.subcategories,
    fa.processing_methods,
    fa.certifications,
    fa.created_at,
    COALESCE(fa.farm_name, 'Local Farm') AS display_name,
    fa.next_harvest_date
  FROM farmer_applications fa
  WHERE fa.status = 'approved';
END;
$function$;