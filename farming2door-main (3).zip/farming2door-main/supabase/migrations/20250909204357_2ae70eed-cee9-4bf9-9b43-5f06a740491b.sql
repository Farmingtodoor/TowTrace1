-- Create analytics tables for enhanced reporting
CREATE TABLE public.analytics_events (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users(id),
  event_type text NOT NULL,
  event_data jsonb DEFAULT '{}',
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  session_id text,
  page_url text,
  user_agent text
);

-- Enable RLS on analytics events
ALTER TABLE public.analytics_events ENABLE ROW LEVEL SECURITY;

-- Create policies for analytics events
CREATE POLICY "Users can create their own analytics events"
ON public.analytics_events FOR INSERT 
WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

CREATE POLICY "Admins can view all analytics events"
ON public.analytics_events FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM user_roles 
  WHERE user_id = auth.uid() 
  AND role IN ('admin', 'super_admin')
));

CREATE POLICY "Users can view their own analytics events"
ON public.analytics_events FOR SELECT 
USING (auth.uid() = user_id);

-- Create farmer revenue analytics view
CREATE OR REPLACE VIEW public.farmer_revenue_analytics AS
SELECT 
  o.farmer_id,
  fa.farm_name,
  DATE_TRUNC('month', o.created_at) as month,
  COUNT(o.id) as total_orders,
  SUM(o.total_amount) as total_revenue,
  AVG(o.total_amount) as avg_order_value,
  COUNT(DISTINCT o.customer_id) as unique_customers
FROM orders o
LEFT JOIN farmer_applications fa ON o.farmer_id = fa.user_id
WHERE o.status = 'delivered'
GROUP BY o.farmer_id, fa.farm_name, DATE_TRUNC('month', o.created_at);

-- Create customer analytics view
CREATE OR REPLACE VIEW public.customer_analytics AS
SELECT 
  o.customer_id,
  p.full_name,
  p.email,
  COUNT(o.id) as total_orders,
  SUM(o.total_amount) as total_spent,
  AVG(o.total_amount) as avg_order_value,
  MAX(o.created_at) as last_order_date,
  MIN(o.created_at) as first_order_date
FROM orders o
LEFT JOIN profiles p ON o.customer_id = p.id
WHERE o.status = 'delivered'
GROUP BY o.customer_id, p.full_name, p.email;

-- Create product performance analytics view
CREATE OR REPLACE VIEW public.product_performance_analytics AS
SELECT 
  p.id as product_id,
  p.name,
  p.category,
  p.farmer_id,
  fa.farm_name,
  COUNT(oi.id) as times_ordered,
  SUM(oi.quantity) as total_quantity_sold,
  SUM(oi.total_price) as total_revenue,
  AVG(r.rating) as avg_rating,
  COUNT(r.id) as review_count
FROM products p
LEFT JOIN order_items oi ON p.name = oi.product_name
LEFT JOIN orders o ON oi.order_id = o.id AND o.status = 'delivered'
LEFT JOIN reviews r ON p.id = r.product_id
LEFT JOIN farmer_applications fa ON p.farmer_id = fa.user_id
GROUP BY p.id, p.name, p.category, p.farmer_id, fa.farm_name;

-- Create search filters table for enhanced search
CREATE TABLE public.search_filters (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  type text NOT NULL, -- 'range', 'checkbox', 'select'
  options jsonb DEFAULT '[]',
  is_active boolean DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on search filters
ALTER TABLE public.search_filters ENABLE ROW LEVEL SECURITY;

-- Create policy for search filters
CREATE POLICY "Anyone can view active search filters"
ON public.search_filters FOR SELECT 
USING (is_active = true);

-- Insert default search filters
INSERT INTO public.search_filters (name, type, options) VALUES
('Price Range', 'range', '{"min": 0, "max": 1000, "step": 5}'),
('Category', 'select', '[]'),
('Organic Only', 'checkbox', '{}'),
('Rating', 'range', '{"min": 0, "max": 5, "step": 0.5}'),
('Distance', 'range', '{"min": 0, "max": 50, "step": 5}'),
('In Stock Only', 'checkbox', '{}'),
('Delivery Available', 'checkbox', '{}');

-- Create function to track analytics events
CREATE OR REPLACE FUNCTION public.track_analytics_event(
  p_event_type text,
  p_event_data jsonb DEFAULT '{}',
  p_user_id uuid DEFAULT NULL,
  p_session_id text DEFAULT NULL,
  p_page_url text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
BEGIN
  INSERT INTO public.analytics_events (
    event_type,
    event_data,
    user_id,
    session_id,
    page_url
  ) VALUES (
    p_event_type,
    p_event_data,
    COALESCE(p_user_id, auth.uid()),
    p_session_id,
    p_page_url
  );
END;
$$;

-- Create function for advanced product search
CREATE OR REPLACE FUNCTION public.search_products_advanced(
  p_search_term text DEFAULT '',
  p_category text DEFAULT '',
  p_subcategory text DEFAULT '',
  p_min_price numeric DEFAULT 0,
  p_max_price numeric DEFAULT 999999,
  p_organic_only boolean DEFAULT false,
  p_min_rating numeric DEFAULT 0,
  p_in_stock_only boolean DEFAULT false,
  p_farmer_id uuid DEFAULT NULL,
  p_sort_by text DEFAULT 'created_at',
  p_sort_order text DEFAULT 'desc',
  p_limit integer DEFAULT 50,
  p_offset integer DEFAULT 0
)
RETURNS TABLE(
  id uuid,
  name text,
  farmer text,
  price numeric,
  category text,
  subcategory text,
  is_organic boolean,
  description text,
  created_at timestamp with time zone,
  updated_at timestamp with time zone,
  farmer_id uuid,
  image_url text,
  unit text,
  stock_quantity integer,
  is_available boolean,
  harvest_date date,
  expiration_date date,
  portion_options jsonb,
  processing_addons jsonb,
  certifications jsonb,
  animal_portion_type text,
  next_delivery_date date,
  farm_distance numeric,
  average_rating numeric,
  review_count integer,
  images jsonb,
  videos jsonb,
  freshness_type text
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  sql_query text;
  order_clause text;
BEGIN
  -- Build the base query
  sql_query := '
    SELECT p.id, p.name, p.farmer, p.price, p.category, p.subcategory,
           p.is_organic, p.description, p.created_at, p.updated_at,
           p.farmer_id, p.image_url, p.unit, p.stock_quantity,
           p.is_available, p.harvest_date, p.expiration_date,
           p.portion_options, p.processing_addons, p.certifications,
           p.animal_portion_type, p.next_delivery_date, p.farm_distance,
           p.average_rating, p.review_count, p.images, p.videos,
           p.freshness_type
    FROM products p
    WHERE p.is_available = true
  ';
  
  -- Add search term filter
  IF p_search_term != '' THEN
    sql_query := sql_query || ' AND (p.name ILIKE ''%' || p_search_term || '%'' OR p.description ILIKE ''%' || p_search_term || '%'')';
  END IF;
  
  -- Add category filter
  IF p_category != '' THEN
    sql_query := sql_query || ' AND p.category = ''' || p_category || '''';
  END IF;
  
  -- Add subcategory filter
  IF p_subcategory != '' THEN
    sql_query := sql_query || ' AND p.subcategory = ''' || p_subcategory || '''';
  END IF;
  
  -- Add price range filter
  sql_query := sql_query || ' AND p.price >= ' || p_min_price || ' AND p.price <= ' || p_max_price;
  
  -- Add organic filter
  IF p_organic_only THEN
    sql_query := sql_query || ' AND p.is_organic = true';
  END IF;
  
  -- Add rating filter
  IF p_min_rating > 0 THEN
    sql_query := sql_query || ' AND p.average_rating >= ' || p_min_rating;
  END IF;
  
  -- Add stock filter
  IF p_in_stock_only THEN
    sql_query := sql_query || ' AND p.stock_quantity > 0';
  END IF;
  
  -- Add farmer filter
  IF p_farmer_id IS NOT NULL THEN
    sql_query := sql_query || ' AND p.farmer_id = ''' || p_farmer_id || '''';
  END IF;
  
  -- Add order clause
  CASE p_sort_by
    WHEN 'price' THEN order_clause := 'p.price';
    WHEN 'rating' THEN order_clause := 'p.average_rating';
    WHEN 'name' THEN order_clause := 'p.name';
    WHEN 'created_at' THEN order_clause := 'p.created_at';
    ELSE order_clause := 'p.created_at';
  END CASE;
  
  sql_query := sql_query || ' ORDER BY ' || order_clause || ' ' || p_sort_order;
  sql_query := sql_query || ' LIMIT ' || p_limit || ' OFFSET ' || p_offset;
  
  -- Execute the dynamic query
  RETURN QUERY EXECUTE sql_query;
END;
$$;