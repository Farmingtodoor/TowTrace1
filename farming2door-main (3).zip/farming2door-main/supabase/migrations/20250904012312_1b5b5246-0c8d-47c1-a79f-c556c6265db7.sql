-- Add missing subcategories under Fresh Produce
INSERT INTO public.subcategories (category_id, name, description, display_order, is_active)
SELECT 
  c.id,
  subcategory_data.name,
  subcategory_data.description,
  (SELECT COALESCE(MAX(display_order), 0) + subcategory_data.display_order FROM subcategories WHERE category_id = c.id),
  true
FROM public.categories c,
(VALUES
  -- Fruits subcategories (missing ones)
  ('Tropical & Exotic', 'Mangoes, Pineapple, Papaya, Bananas, Dragon Fruit', 1),
  ('Melons', 'Watermelon, Cantaloupe, Honeydew', 2),
  ('Apples & Pears', 'Fresh apples and pears varieties', 3),
  ('Grapes', 'Fresh table grapes and wine grapes', 4),
  ('Seasonal Specials', 'Pumpkins, Persimmons, Pomegranates', 5),
  -- Vegetables subcategories (missing ones)
  ('Cruciferous', 'Broccoli, Cauliflower, Cabbage, Brussels Sprouts', 6),
  ('Tubers', 'Potatoes, Sweet Potatoes, Yams', 7),
  ('Alliums', 'Onions, Garlic, Shallots, Leeks, Green Onions', 8),
  ('Peppers & Chilies', 'Bell Peppers, Jalapeños, Habaneros, Poblano', 9),
  ('Eggplants', 'Various eggplant varieties', 10),
  ('Seasonal Vegetables', 'Corn, Asparagus, Green Beans, Okra, Artichokes', 11),
  -- Herbs & Aromatics subcategories (expanding existing)
  ('Fresh Culinary Herbs', 'Cilantro, Parsley, Basil, Mint, Dill, Rosemary, Thyme, Oregano, Sage', 12),
  ('Spices & Roots', 'Ginger, Turmeric, Galangal', 13),
  ('Specialty Herbs', 'Lemongrass, Curry Leaves', 14),
  -- Mushrooms subcategories (expanding existing)
  ('Button & Cremini', 'Common white and brown mushrooms', 15),
  ('Shiitake', 'Japanese shiitake mushrooms', 16),
  ('Oyster Mushrooms', 'Fresh oyster mushroom varieties', 17),
  ('Portobello', 'Large portobello mushroom caps', 18),
  ('Specialty Mushrooms', 'Enoki, Maitake, Morel, Lion''s Mane', 19)
) AS subcategory_data(name, description, display_order)
WHERE c.name = 'Fresh Produce';