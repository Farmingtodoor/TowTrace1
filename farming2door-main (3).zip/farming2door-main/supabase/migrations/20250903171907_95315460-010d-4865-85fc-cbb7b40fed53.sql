-- Update categories to match the exact primary categories requested
UPDATE categories SET name = 'Meat', description = 'Premium grass-fed beef, free-range poultry, and custom processing options' WHERE name = 'Premium Livestock';
UPDATE categories SET name = 'Produce', description = 'Seasonal fruits, vegetables, and herbs picked at peak freshness' WHERE name = 'Fresh Produce';
UPDATE categories SET name = 'Honey', description = 'Raw honey, beeswax, and other hive products' WHERE name = 'Honey & Bee Products';
UPDATE categories SET name = 'Grains', description = 'Freshly milled flour, ancient grains, and farm pantry staples' WHERE name = 'Grains & Pantry';

-- Add Bundles category
INSERT INTO categories (name, description, icon, display_order, is_active) VALUES 
('Bundles', 'Curated collections and combo packages from multiple farms', 'Hexagon', 7, true);

-- Add additional fields to products for animal processing and enhanced features
ALTER TABLE products ADD COLUMN IF NOT EXISTS portion_options jsonb DEFAULT '["whole"]'::jsonb;
ALTER TABLE products ADD COLUMN IF NOT EXISTS processing_addons jsonb DEFAULT '[]'::jsonb;
ALTER TABLE products ADD COLUMN IF NOT EXISTS certifications jsonb DEFAULT '[]'::jsonb;
ALTER TABLE products ADD COLUMN IF NOT EXISTS animal_portion_type text DEFAULT 'whole';
ALTER TABLE products ADD COLUMN IF NOT EXISTS next_delivery_date date;
ALTER TABLE products ADD COLUMN IF NOT EXISTS farm_distance numeric;
ALTER TABLE products ADD COLUMN IF NOT EXISTS average_rating numeric(3,2) DEFAULT 0;
ALTER TABLE products ADD COLUMN IF NOT EXISTS review_count integer DEFAULT 0;

-- Create reviews table
CREATE TABLE IF NOT EXISTS public.reviews (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  customer_id uuid NOT NULL,
  order_id uuid REFERENCES orders(id),
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  title text,
  comment text,
  photos jsonb DEFAULT '[]'::jsonb,
  is_verified boolean DEFAULT false,
  is_helpful_count integer DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on reviews
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;

-- RLS policies for reviews
CREATE POLICY "Anyone can view reviews" ON public.reviews FOR SELECT USING (true);
CREATE POLICY "Users can create reviews for their orders" ON public.reviews FOR INSERT 
WITH CHECK (
  auth.uid() = customer_id AND 
  EXISTS (
    SELECT 1 FROM orders o 
    JOIN order_items oi ON o.id = oi.order_id 
    WHERE o.customer_id = auth.uid() 
    AND o.status = 'delivered'
    AND oi.order_id = reviews.order_id
  )
);
CREATE POLICY "Users can update their own reviews" ON public.reviews FOR UPDATE USING (auth.uid() = customer_id);

-- Create delivery zones table
CREATE TABLE IF NOT EXISTS public.delivery_zones (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  zip_codes jsonb NOT NULL DEFAULT '[]'::jsonb,
  delivery_fee numeric NOT NULL DEFAULT 0,
  max_distance_km numeric,
  delivery_windows jsonb DEFAULT '[{"am": "8:00-12:00"}, {"pm": "13:00-18:00"}]'::jsonb,
  is_active boolean DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on delivery zones
ALTER TABLE public.delivery_zones ENABLE ROW LEVEL SECURITY;

-- RLS policy for delivery zones
CREATE POLICY "Anyone can view delivery zones" ON public.delivery_zones FOR SELECT USING (true);

-- Insert sample delivery zones
INSERT INTO delivery_zones (name, zip_codes, delivery_fee, max_distance_km) VALUES 
('Zone A - City Center', '["12345", "12346", "12347"]', 5.00, 10),
('Zone B - Suburbs', '["12348", "12349", "12350"]', 8.00, 25),
('Zone C - Extended Area', '["12351", "12352", "12353"]', 12.00, 50);

-- Create trigger for updating product ratings when reviews change
CREATE OR REPLACE FUNCTION update_product_rating()
RETURNS TRIGGER AS $$
BEGIN
  -- Update the product's average rating and review count
  UPDATE products 
  SET 
    average_rating = (
      SELECT COALESCE(AVG(rating), 0) 
      FROM reviews 
      WHERE product_id = COALESCE(NEW.product_id, OLD.product_id)
    ),
    review_count = (
      SELECT COUNT(*) 
      FROM reviews 
      WHERE product_id = COALESCE(NEW.product_id, OLD.product_id)
    )
  WHERE id = COALESCE(NEW.product_id, OLD.product_id);
  
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

-- Create triggers for review changes
CREATE TRIGGER update_product_rating_on_insert
  AFTER INSERT ON reviews
  FOR EACH ROW
  EXECUTE FUNCTION update_product_rating();

CREATE TRIGGER update_product_rating_on_update
  AFTER UPDATE ON reviews
  FOR EACH ROW
  EXECUTE FUNCTION update_product_rating();

CREATE TRIGGER update_product_rating_on_delete
  AFTER DELETE ON reviews
  FOR EACH ROW
  EXECUTE FUNCTION update_product_rating();

-- Update existing products with sample data for demonstration
UPDATE products SET 
  certifications = CASE 
    WHEN is_organic THEN '["Organic"]'::jsonb
    ELSE '[]'::jsonb
  END,
  portion_options = CASE 
    WHEN category = 'Meat' THEN '["whole", "half", "quarter"]'::jsonb
    ELSE '["whole"]'::jsonb
  END,
  processing_addons = CASE 
    WHEN category = 'Meat' THEN '[{"name": "Roasting", "price": 25}, {"name": "Skin off", "price": 15}, {"name": "Basic portioning", "price": 10}]'::jsonb
    ELSE '[]'::jsonb
  END,
  next_delivery_date = CURRENT_DATE + interval '3 days',
  farm_distance = (random() * 30 + 5)::numeric(4,1),
  average_rating = (random() * 2 + 3)::numeric(3,2),
  review_count = (random() * 50 + 10)::integer;