-- Fix security vulnerability in customer_insights table - comprehensive policy cleanup
-- Block all anonymous access and strengthen access controls

-- STEP 1: Drop ALL existing policies comprehensively
DROP POLICY IF EXISTS "Admins can view all customer insights" ON public.customer_insights;
DROP POLICY IF EXISTS "Users can view their own insights" ON public.customer_insights;
DROP POLICY IF EXISTS "SECURITY_CRITICAL_block_anonymous_access" ON public.customer_insights;
DROP POLICY IF EXISTS "SECURE_verified_admins_view_all_insights" ON public.customer_insights;
DROP POLICY IF EXISTS "SECURE_customers_view_own_insights_only" ON public.customer_insights;
DROP POLICY IF EXISTS "SECURITY_CRITICAL_no_manual_inserts" ON public.customer_insights;
DROP POLICY IF EXISTS "SECURITY_CRITICAL_no_manual_updates" ON public.customer_insights;
DROP POLICY IF EXISTS "SECURITY_CRITICAL_no_deletions" ON public.customer_insights;

-- STEP 2: Create comprehensive security policies with unique names

-- CRITICAL: Block all anonymous access completely
CREATE POLICY "CUSTOMER_INSIGHTS_block_anonymous_completely" 
ON public.customer_insights 
FOR ALL 
USING (auth.uid() IS NOT NULL) 
WITH CHECK (auth.uid() IS NOT NULL);

-- SECURE: Only verified admins can view all customer insights
CREATE POLICY "CUSTOMER_INSIGHTS_verified_admins_view_all" 
ON public.customer_insights 
FOR SELECT 
USING (
  auth.uid() IS NOT NULL 
  AND EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- SECURE: Customers can only view their own insights
CREATE POLICY "CUSTOMER_INSIGHTS_customers_view_own_only" 
ON public.customer_insights 
FOR SELECT 
USING (
  auth.uid() IS NOT NULL 
  AND auth.uid() = customer_id
);

-- SECURE: Block all INSERT operations (system-managed only)
CREATE POLICY "CUSTOMER_INSIGHTS_block_manual_inserts" 
ON public.customer_insights 
FOR INSERT 
WITH CHECK (false);

-- SECURE: Block all UPDATE operations (system-managed only)
CREATE POLICY "CUSTOMER_INSIGHTS_block_manual_updates" 
ON public.customer_insights 
FOR UPDATE 
USING (false) 
WITH CHECK (false);

-- SECURE: Block all DELETE operations (audit trail preservation)
CREATE POLICY "CUSTOMER_INSIGHTS_block_all_deletions" 
ON public.customer_insights 
FOR DELETE 
USING (false);

-- STEP 3: Ensure proper table security configuration
ALTER TABLE public.customer_insights ENABLE ROW LEVEL SECURITY;

-- STEP 4: Revoke and grant minimal required permissions
REVOKE ALL ON public.customer_insights FROM anon, authenticated;
GRANT SELECT ON public.customer_insights TO authenticated; -- Controlled by RLS