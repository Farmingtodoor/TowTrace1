CREATE TABLE public.farmer_payout_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  farmer_id uuid NOT NULL UNIQUE,
  stripe_account_id text NOT NULL UNIQUE,
  charges_enabled boolean NOT NULL DEFAULT false,
  payouts_enabled boolean NOT NULL DEFAULT false,
  details_submitted boolean NOT NULL DEFAULT false,
  requirements_due jsonb NOT NULL DEFAULT '[]'::jsonb,
  bank_last4 text,
  bank_name text,
  country text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.farmer_payout_accounts TO authenticated;
GRANT ALL ON public.farmer_payout_accounts TO service_role;

ALTER TABLE public.farmer_payout_accounts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Farmers can view their own payout account"
ON public.farmer_payout_accounts FOR SELECT TO authenticated
USING (farmer_id = auth.uid());

CREATE POLICY "Admins can view all payout accounts"
ON public.farmer_payout_accounts FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'super_admin'));

CREATE TABLE public.payout_receipts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  payout_request_id uuid NOT NULL REFERENCES public.payout_requests(id) ON DELETE CASCADE,
  farmer_id uuid NOT NULL,
  receipt_number text NOT NULL UNIQUE,
  amount numeric NOT NULL,
  currency text NOT NULL DEFAULT 'usd',
  status text NOT NULL DEFAULT 'sent',
  stripe_account_id text,
  stripe_transfer_id text,
  stripe_payout_id text,
  failure_reason text,
  sent_by uuid,
  sent_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.payout_receipts TO authenticated;
GRANT ALL ON public.payout_receipts TO service_role;

ALTER TABLE public.payout_receipts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Farmers can view their own payout receipts"
ON public.payout_receipts FOR SELECT TO authenticated
USING (farmer_id = auth.uid());

CREATE POLICY "Admins can view all payout receipts"
ON public.payout_receipts FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'super_admin'));

CREATE INDEX idx_payout_receipts_farmer ON public.payout_receipts(farmer_id);
CREATE INDEX idx_payout_receipts_request ON public.payout_receipts(payout_request_id);

CREATE TRIGGER update_farmer_payout_accounts_updated_at
BEFORE UPDATE ON public.farmer_payout_accounts
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_payout_receipts_updated_at
BEFORE UPDATE ON public.payout_receipts
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();