-- Enhanced Security Update - Fix Critical Vulnerabilities (Fixed version)

-- 1. Drop and recreate conflicting functions
DROP FUNCTION IF EXISTS public.mask_phone(text);

-- Create enhanced phone masking function
CREATE OR REPLACE FUNCTION public.mask_phone_secure(phone_input text)
RETURNS text
LANGUAGE plpgsql
IMMUTABLE SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF phone_input IS NULL OR length(phone_input) < 4 THEN
    RETURN 'Contact via platform';
  END IF;
  
  -- Remove all non-digits
  phone_input := regexp_replace(phone_input, '[^0-9]', '', 'g');
  
  -- Mask all but last 4 digits
  IF length(phone_input) <= 4 THEN
    RETURN '***-***-' || phone_input;
  ELSE
    RETURN '***-***-' || right(phone_input, 4);
  END IF;
END;
$$;

-- 2. Create data encryption functions
CREATE OR REPLACE FUNCTION public.encrypt_sensitive_data(data_input text)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  encryption_key TEXT := 'secure_farm2door_key_2024';
BEGIN
  IF data_input IS NULL OR data_input = '' THEN
    RETURN NULL;
  END IF;
  RETURN encode(encrypt(data_input::bytea, encryption_key, 'aes'), 'base64');
EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;
END;
$$;

-- 3. Create secure audit logging
CREATE OR REPLACE FUNCTION public.log_security_event(
  event_type text,
  table_name text,
  record_id text DEFAULT NULL,
  details text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.security_audit_log (
    user_id,
    action,
    table_name,
    record_id,
    created_at
  ) VALUES (
    auth.uid(),
    event_type || CASE WHEN details IS NOT NULL THEN ': ' || details ELSE '' END,
    table_name,
    record_id,
    now()
  );
EXCEPTION
  WHEN OTHERS THEN
    -- Continue execution even if logging fails
    NULL;
END;
$$;

-- 4. Create input sanitization function
CREATE OR REPLACE FUNCTION public.sanitize_user_input(input_text text)
RETURNS text
LANGUAGE plpgsql
IMMUTABLE SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF input_text IS NULL THEN
    RETURN NULL;
  END IF;
  
  -- Remove HTML tags and dangerous patterns
  input_text := regexp_replace(input_text, '<[^>]*>', '', 'g');
  input_text := regexp_replace(input_text, 'javascript:', '', 'gi');
  input_text := regexp_replace(input_text, 'on\w+\s*=', '', 'gi');
  
  -- Limit length
  input_text := left(input_text, 1000);
  
  RETURN trim(input_text);
END;
$$;

-- 5. Add session security tracking
CREATE TABLE IF NOT EXISTS public.user_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  session_token text NOT NULL,
  ip_address inet,
  user_agent text,
  created_at timestamp with time zone DEFAULT now(),
  last_activity timestamp with time zone DEFAULT now(),
  is_active boolean DEFAULT true
);

-- Enable RLS on user sessions
ALTER TABLE public.user_sessions ENABLE ROW LEVEL SECURITY;

-- Users can only see their own sessions
CREATE POLICY "Users can view own sessions" ON public.user_sessions
FOR SELECT USING (user_id = auth.uid());

-- 6. Create rate limiting table
CREATE TABLE IF NOT EXISTS public.rate_limits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  ip_address inet,
  action_type text NOT NULL,
  request_count integer DEFAULT 1,
  window_start timestamp with time zone DEFAULT now(),
  created_at timestamp with time zone DEFAULT now()
);

ALTER TABLE public.rate_limits ENABLE ROW LEVEL SECURITY;

-- Only system can manage rate limits
CREATE POLICY "System manages rate limits" ON public.rate_limits
FOR ALL USING (false);

-- 7. Enhanced security validation triggers
CREATE OR REPLACE FUNCTION public.validate_email_security()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Log email access attempts
  PERFORM log_security_event('email_validation', TG_TABLE_NAME, NEW.id::text);
  
  -- Validate email format and security
  IF NEW.email IS NOT NULL THEN
    IF NOT (NEW.email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$') THEN
      RAISE EXCEPTION 'Invalid email format';
    END IF;
    
    -- Check for suspicious patterns
    IF NEW.email ~* '(test|fake|spam|temp|disposable)' THEN
      RAISE EXCEPTION 'Suspicious email pattern detected';
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- 8. Create comprehensive security check function
CREATE OR REPLACE FUNCTION public.run_security_health_check()
RETURNS TABLE(
  check_name text,
  status text,
  details text
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Check RLS status on critical tables
  RETURN QUERY
  SELECT 
    'RLS_Status_' || t.table_name::text as check_name,
    CASE WHEN t.row_security THEN 'SECURE' ELSE 'VULNERABLE' END as status,
    'Row Level Security ' || CASE WHEN t.row_security THEN 'enabled' ELSE 'DISABLED' END as details
  FROM information_schema.tables t
  WHERE t.table_schema = 'public' 
  AND t.table_name IN ('customer_insights', 'driver_profiles', 'payout_requests', 'farmer_applications');
  
  -- Check for admin users
  RETURN QUERY
  SELECT 
    'Admin_Users' as check_name,
    CASE WHEN COUNT(*) > 0 THEN 'CONFIGURED' ELSE 'MISSING' END as status,
    'Found ' || COUNT(*)::text || ' admin users' as details
  FROM user_roles 
  WHERE role IN ('admin', 'super_admin');
  
END;
$$;