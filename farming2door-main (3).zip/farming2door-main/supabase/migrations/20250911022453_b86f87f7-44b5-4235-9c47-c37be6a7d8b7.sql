-- Enhanced Security Update - Fix Critical Vulnerabilities
-- This addresses the critical security issues found in the scan

-- 1. Ensure RLS is properly enabled on all sensitive tables
-- (Some policies exist but RLS might not be properly enforced)

-- Force enable RLS on critical tables
ALTER TABLE public.customer_insights ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.driver_profiles ENABLE ROW LEVEL SECURITY; 
ALTER TABLE public.payout_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.farmer_applications ENABLE ROW LEVEL SECURITY;

-- 2. Add missing security policies where needed
-- Only create policies that don't already exist

-- Secure browsing_history table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'browsing_history' 
    AND policyname = 'Users can view own browsing history'
  ) THEN
    ALTER TABLE public.browsing_history ENABLE ROW LEVEL SECURITY;
  END IF;
END $$;

-- Secure messages table with proper RLS
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' 
    AND tablename = 'messages' 
    AND policyname = 'Admins can view all messages'
  ) THEN
    CREATE POLICY "Admins can view all messages" ON public.messages
    FOR SELECT USING (
      EXISTS (
        SELECT 1 FROM public.user_roles 
        WHERE user_id = auth.uid() 
        AND role IN ('admin', 'super_admin')
      )
    );
  END IF;
END $$;

-- 3. Create function to mask sensitive financial data
CREATE OR REPLACE FUNCTION public.mask_bank_details(account_number text)
RETURNS text
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF account_number IS NULL OR length(account_number) < 4 THEN
    RETURN '****';
  END IF;
  RETURN '****' || right(account_number, 4);
END;
$$;

-- 4. Create enhanced audit logging
CREATE OR REPLACE FUNCTION public.log_pii_access(
  table_name text,
  record_id text,
  access_type text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  client_ip text;
  user_agent text;
BEGIN
  -- Get request metadata safely
  BEGIN
    client_ip := COALESCE(
      current_setting('request.headers', true)::json->>'x-forwarded-for',
      'unknown'
    );
    user_agent := COALESCE(
      current_setting('request.headers', true)::json->>'user-agent',
      'unknown'
    );
  EXCEPTION
    WHEN OTHERS THEN
      client_ip := 'unknown';
      user_agent := 'unknown';
  END;

  -- Log the access
  INSERT INTO public.security_audit_log (
    user_id,
    action,
    table_name,
    record_id,
    ip_address,
    user_agent
  ) VALUES (
    auth.uid(),
    access_type,
    table_name,
    record_id,
    CASE WHEN client_ip = 'unknown' THEN NULL ELSE client_ip::inet END,
    user_agent
  );
EXCEPTION
  WHEN OTHERS THEN
    -- Don't fail if logging fails
    NULL;
END;
$$;

-- 5. Create enhanced phone number masking function
CREATE OR REPLACE FUNCTION public.mask_phone(phone_number text)
RETURNS text
LANGUAGE plpgsql
IMMUTABLE SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF phone_number IS NULL OR length(phone_number) < 4 THEN
    RETURN 'Contact via platform';
  END IF;
  
  -- Remove all non-digits
  phone_number := regexp_replace(phone_number, '[^0-9]', '', 'g');
  
  -- Mask all but last 4 digits
  IF length(phone_number) <= 4 THEN
    RETURN '***-***-' || phone_number;
  ELSE
    RETURN '***-***-' || right(phone_number, 4);
  END IF;
END;
$$;

-- 6. Add data retention policy
CREATE OR REPLACE FUNCTION public.cleanup_old_audit_logs()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Remove audit logs older than 2 years
  DELETE FROM public.security_audit_log 
  WHERE created_at < now() - interval '2 years';
  
  -- Remove old browsing history (older than 1 year)
  DELETE FROM public.browsing_history 
  WHERE viewed_at < now() - interval '1 year';
END;
$$;

-- 7. Enhance input validation
CREATE OR REPLACE FUNCTION public.validate_secure_input(input_text text)
RETURNS boolean
LANGUAGE plpgsql
IMMUTABLE SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Reject if contains potential SQL injection patterns
  IF input_text ~* '(union|select|insert|update|delete|drop|create|alter|exec|script)' THEN
    RETURN false;
  END IF;
  
  -- Reject if contains XSS patterns
  IF input_text ~* '(<script|javascript:|onload=|onerror=)' THEN
    RETURN false;
  END IF;
  
  -- Reject if too long
  IF length(input_text) > 5000 THEN
    RETURN false;
  END IF;
  
  RETURN true;
END;
$$;