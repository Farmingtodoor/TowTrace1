-- Create function to notify admins of new farmer applications
CREATE OR REPLACE FUNCTION public.handle_new_farmer_application()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  admin_user RECORD;
  notification_title TEXT;
  notification_message TEXT;
BEGIN
  -- Set notification content
  notification_title := 'New Farmer Application Submitted';
  notification_message := 'A new farmer application has been submitted by ' || NEW.full_name || ' from ' || NEW.farm_name || '. Please review and approve or reject the application.';
  
  -- Create notifications for all admin and super_admin users
  FOR admin_user IN 
    SELECT DISTINCT ur.user_id, p.email, p.full_name
    FROM public.user_roles ur
    JOIN public.profiles p ON ur.user_id = p.id
    WHERE ur.role IN ('admin', 'super_admin')
  LOOP
    -- Insert notification for each admin
    INSERT INTO public.notifications (user_id, type, title, message)
    VALUES (admin_user.user_id, 'farmer_application', notification_title, notification_message);
    
    -- Log for debugging
    RAISE LOG 'Created notification for admin: %', admin_user.email;
  END LOOP;
  
  RETURN NEW;
END;
$$;

-- Create trigger for new farmer applications
CREATE TRIGGER trigger_new_farmer_application
  AFTER INSERT ON public.farmer_applications
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_farmer_application();

-- Update notification policies to allow system to create admin notifications
CREATE POLICY "System can create admin notifications" ON public.notifications
  FOR INSERT
  WITH CHECK (type = 'farmer_application');