-- Re-create the missing order notifications trigger
CREATE OR REPLACE FUNCTION public.handle_order_notifications()
RETURNS TRIGGER AS $$
DECLARE
  customer_profile public.profiles%ROWTYPE;
  farmer_profile public.profiles%ROWTYPE;
  notification_payload JSONB;
BEGIN
  -- Get customer and farmer profiles
  SELECT * INTO customer_profile FROM public.profiles WHERE id = NEW.customer_id;
  SELECT * INTO farmer_profile FROM public.profiles WHERE id = NEW.farmer_id;
  
  -- On new order creation, notify farmer
  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.notifications (user_id, type, title, message, order_id)
    VALUES (
      NEW.farmer_id, 
      'order_placed',
      'New Order Received!',
      'You have received a new order from ' || COALESCE(customer_profile.full_name, customer_profile.email),
      NEW.id
    );
    
    -- Send email notification to farmer (direct call, not webhook)
    BEGIN
      SELECT net.http_post(
        url := 'https://njheralnbmbblwqhrncm.supabase.co/functions/v1/send-notification-email',
        headers := jsonb_build_object(
          'Content-Type', 'application/json'
        ),
        body := jsonb_build_object(
          'notification', jsonb_build_object(
            'user_id', NEW.farmer_id,
            'title', 'New Order Received!',
            'message', 'You have received a new order from ' || COALESCE(customer_profile.full_name, customer_profile.email),
            'type', 'order_placed',
            'order_id', NEW.id
          )
        )
      ) INTO notification_payload;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE LOG 'Failed to send email notification for new order: %', SQLERRM;
    END;
  END IF;
  
  -- On status change to delivered, notify both customer and farmer (but only once)
  IF TG_OP = 'UPDATE' AND OLD.status != 'delivered' AND NEW.status = 'delivered' THEN
    -- Notify customer about delivery
    INSERT INTO public.notifications (user_id, type, title, message, order_id)
    VALUES (
      NEW.customer_id,
      'order_delivered', 
      'Order Delivered! 🌾',
      'Your fresh produce has been delivered. Thank you for choosing Farm2Door!',
      NEW.id
    );
    
    -- Send email notification to customer
    BEGIN
      SELECT net.http_post(
        url := 'https://njheralnbmbblwqhrncm.supabase.co/functions/v1/send-notification-email',
        headers := jsonb_build_object(
          'Content-Type', 'application/json'
        ),
        body := jsonb_build_object(
          'notification', jsonb_build_object(
            'user_id', NEW.customer_id,
            'title', 'Order Delivered! 🌾',
            'message', 'Your fresh produce has been delivered. Thank you for choosing Farm2Door!',
            'type', 'order_delivered',
            'order_id', NEW.id
          )
        )
      ) INTO notification_payload;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE LOG 'Failed to send email notification for delivered order: %', SQLERRM;
    END;
    
    -- Notify farmer about successful delivery  
    INSERT INTO public.notifications (user_id, type, title, message, order_id)
    VALUES (
      NEW.farmer_id,
      'order_completed',
      'Order Completed Successfully',
      'Your order to ' || COALESCE(customer_profile.full_name, customer_profile.email) || ' has been delivered.',
      NEW.id
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Drop any existing triggers first
DROP TRIGGER IF EXISTS order_notifications_trigger ON public.orders;
DROP TRIGGER IF EXISTS on_order_created ON public.orders;
DROP TRIGGER IF EXISTS on_order_status_changed ON public.orders;

-- Create the trigger that handles both insert and update
CREATE TRIGGER order_notifications_trigger
  AFTER INSERT OR UPDATE ON public.orders
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_order_notifications();