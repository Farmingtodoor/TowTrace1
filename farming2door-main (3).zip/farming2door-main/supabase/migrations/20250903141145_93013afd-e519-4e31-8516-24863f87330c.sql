-- Create function to handle farmer approval notifications
CREATE OR REPLACE FUNCTION public.handle_farmer_approval()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  farmer_email TEXT;
  notification_title TEXT;
  notification_message TEXT;
BEGIN
  -- Only process when status changes to 'approved'
  IF NEW.status = 'approved' AND OLD.status != 'approved' THEN
    -- Get farmer email from the application
    farmer_email := NEW.email;
    
    -- Set notification content
    notification_title := 'Farmer Application Approved';
    notification_message := 'Congratulations! Your farmer application has been approved. Welcome to Farm2Door!';
    
    -- Create notification for the farmer
    INSERT INTO public.notifications (user_id, type, title, message)
    VALUES (NEW.user_id, 'farmer_approved', notification_title, notification_message);
    
    -- Send welcome email asynchronously
    PERFORM
      net.http_post(
        url := 'https://njheralnbmbblwqhrncm.supabase.co/functions/v1/send-farmer-welcome-email',
        headers := jsonb_build_object(
          'Content-Type', 'application/json',
          'Authorization', 'Bearer ' || current_setting('app.jwt_secret', true)
        ),
        body := jsonb_build_object(
          'farmer_name', NEW.full_name,
          'farmer_email', farmer_email,
          'farm_name', NEW.farm_name
        )
      );
    
    -- Log for debugging
    RAISE LOG 'Created approval notification for farmer: %', farmer_email;
  END IF;
  
  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error but don't fail the approval process
    RAISE LOG 'Error in handle_farmer_approval: %', SQLERRM;
    RETURN NEW;
END;
$function$

-- Create trigger for farmer approval notifications
CREATE TRIGGER farmer_approval_notification_trigger
    AFTER UPDATE ON public.farmer_applications
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_farmer_approval();