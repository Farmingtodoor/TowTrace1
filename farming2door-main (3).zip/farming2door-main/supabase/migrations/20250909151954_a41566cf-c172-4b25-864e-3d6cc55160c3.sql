-- Create featured_services table to track different feature options
CREATE TABLE public.featured_services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  duration_days INTEGER NOT NULL,
  feature_type TEXT NOT NULL CHECK (feature_type IN ('product', 'farm', 'top_spot')),
  max_items INTEGER DEFAULT 1,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  is_active BOOLEAN DEFAULT true
);

-- Create featured_purchases table to track farmer purchases
CREATE TABLE public.featured_purchases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  farmer_id UUID NOT NULL,
  service_id UUID REFERENCES public.featured_services(id),
  item_id UUID, -- product_id or farmer_id depending on service type
  stripe_session_id TEXT,
  amount DECIMAL(10,2) NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'expired', 'cancelled')),
  starts_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.featured_services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.featured_purchases ENABLE ROW LEVEL SECURITY;

-- RLS Policies for featured_services
CREATE POLICY "Anyone can view active featured services" 
ON public.featured_services 
FOR SELECT 
USING (is_active = true);

CREATE POLICY "Admins can manage featured services" 
ON public.featured_services 
FOR ALL 
USING (EXISTS (
  SELECT 1 FROM user_roles 
  WHERE user_id = auth.uid() 
  AND role IN ('admin', 'super_admin')
));

-- RLS Policies for featured_purchases
CREATE POLICY "Farmers can view their own purchases" 
ON public.featured_purchases 
FOR SELECT 
USING (auth.uid() = farmer_id);

CREATE POLICY "Farmers can create their own purchases" 
ON public.featured_purchases 
FOR INSERT 
WITH CHECK (auth.uid() = farmer_id);

CREATE POLICY "System can update purchase status" 
ON public.featured_purchases 
FOR UPDATE 
USING (true);

CREATE POLICY "Admins can view all purchases" 
ON public.featured_purchases 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM user_roles 
  WHERE user_id = auth.uid() 
  AND role IN ('admin', 'super_admin')
));

-- Insert default featured services
INSERT INTO public.featured_services (name, description, price, duration_days, feature_type, max_items) VALUES
('Featured Product - Weekly', 'Feature one product at the top of listings for 7 days', 15.00, 7, 'product', 1),
('Featured Product - Monthly', 'Feature one product at the top of listings for 30 days', 45.00, 30, 'product', 1),
('Featured Farm - Weekly', 'Highlight your farm profile for 7 days', 25.00, 7, 'farm', 1),
('Featured Farm - Monthly', 'Highlight your farm profile for 30 days', 75.00, 30, 'farm', 1),
('Top Spot - Weekly', 'Premium placement in hero section for 7 days', 50.00, 7, 'top_spot', 1),
('Top Spot - Monthly', 'Premium placement in hero section for 30 days', 150.00, 30, 'top_spot', 1);

-- Create function to automatically expire featured items
CREATE OR REPLACE FUNCTION public.expire_featured_items()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  UPDATE public.featured_purchases 
  SET status = 'expired', updated_at = now()
  WHERE status = 'active' 
  AND expires_at < now();
END;
$$;

-- Create function to get active featured items
CREATE OR REPLACE FUNCTION public.get_featured_items(feature_type_param TEXT DEFAULT NULL)
RETURNS TABLE(
  purchase_id UUID,
  farmer_id UUID,
  item_id UUID,
  feature_type TEXT,
  expires_at TIMESTAMP WITH TIME ZONE,
  farm_name TEXT,
  product_name TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- First expire any items that should be expired
  PERFORM public.expire_featured_items();
  
  -- Return active featured items
  RETURN QUERY
  SELECT 
    fp.id as purchase_id,
    fp.farmer_id,
    fp.item_id,
    fs.feature_type,
    fp.expires_at,
    COALESCE(fa.farm_name, 'Unknown Farm') as farm_name,
    COALESCE(p.name, 'Featured Farm') as product_name
  FROM public.featured_purchases fp
  JOIN public.featured_services fs ON fp.service_id = fs.id
  LEFT JOIN public.farmer_applications fa ON fp.farmer_id = fa.user_id AND fa.status = 'approved'
  LEFT JOIN public.products p ON fp.item_id = p.id AND fs.feature_type = 'product'
  WHERE fp.status = 'active'
  AND fp.expires_at > now()
  AND (feature_type_param IS NULL OR fs.feature_type = feature_type_param)
  ORDER BY fp.created_at ASC;
END;
$$;