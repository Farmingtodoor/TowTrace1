-- Fix security warnings

-- Fix function search path issues by setting proper search path
CREATE OR REPLACE FUNCTION public.handle_order_status_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  customer_profile public.profiles%ROWTYPE;
  farmer_profile public.profiles%ROWTYPE;
  notification_title TEXT;
  customer_message TEXT;
  farmer_message TEXT;
BEGIN
  -- Get customer and farmer profiles
  SELECT * INTO customer_profile FROM public.profiles WHERE id = NEW.customer_id;
  SELECT * INTO farmer_profile FROM public.profiles WHERE id = NEW.farmer_id;
  
  -- Set notification content based on status
  CASE NEW.status
    WHEN 'pending' THEN
      -- New order placed - notify farmer
      notification_title := 'New Order Received';
      farmer_message := 'You have received a new order from ' || COALESCE(customer_profile.full_name, customer_profile.email);
      
      INSERT INTO public.notifications (user_id, type, title, message, order_id)
      VALUES (NEW.farmer_id, 'order_placed', notification_title, farmer_message, NEW.id);
      
    WHEN 'confirmed' THEN
      -- Order confirmed - notify customer
      notification_title := 'Order Confirmed';
      customer_message := 'Your order has been confirmed by ' || COALESCE(farmer_profile.full_name, farmer_profile.email);
      
      INSERT INTO public.notifications (user_id, type, title, message, order_id)
      VALUES (NEW.customer_id, 'order_confirmed', notification_title, customer_message, NEW.id);
      
    WHEN 'processing' THEN
      -- Order processing - notify customer
      notification_title := 'Order Being Prepared';
      customer_message := 'Your order is now being prepared by ' || COALESCE(farmer_profile.full_name, farmer_profile.email);
      
      INSERT INTO public.notifications (user_id, type, title, message, order_id)
      VALUES (NEW.customer_id, 'order_processing', notification_title, customer_message, NEW.id);
      
    WHEN 'ready' THEN
      -- Order ready - notify customer
      notification_title := 'Order Ready for ' || CASE WHEN NEW.delivery_type = 'pickup' THEN 'Pickup' ELSE 'Delivery' END;
      customer_message := 'Your order is ready for ' || CASE WHEN NEW.delivery_type = 'pickup' THEN 'pickup' ELSE 'delivery' END || '!';
      
      INSERT INTO public.notifications (user_id, type, title, message, order_id)
      VALUES (NEW.customer_id, 'order_ready', notification_title, customer_message, NEW.id);
      
    WHEN 'out_for_delivery' THEN
      -- Order out for delivery - notify customer
      notification_title := 'Order Out for Delivery';
      customer_message := 'Your order is on the way! Expected delivery soon.';
      
      INSERT INTO public.notifications (user_id, type, title, message, order_id)
      VALUES (NEW.customer_id, 'order_out_for_delivery', notification_title, customer_message, NEW.id);
      
    WHEN 'delivered' THEN
      -- Order delivered - notify customer
      notification_title := 'Order Delivered';
      customer_message := 'Your order has been delivered. Thank you for choosing Farm2Door!';
      
      INSERT INTO public.notifications (user_id, type, title, message, order_id)
      VALUES (NEW.customer_id, 'order_delivered', notification_title, customer_message, NEW.id);
  END CASE;
  
  RETURN NEW;
END;
$function$;

-- Fix other functions to have proper search path
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $function$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$function$;

CREATE OR REPLACE FUNCTION public.get_current_user_role()
RETURNS app_role
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $function$
  SELECT role FROM public.user_roles 
  WHERE user_id = auth.uid() 
  ORDER BY 
    CASE role
      WHEN 'super_admin' THEN 1
      WHEN 'admin' THEN 2
      WHEN 'farmer' THEN 3
      WHEN 'customer' THEN 4
    END
  LIMIT 1
$function$;