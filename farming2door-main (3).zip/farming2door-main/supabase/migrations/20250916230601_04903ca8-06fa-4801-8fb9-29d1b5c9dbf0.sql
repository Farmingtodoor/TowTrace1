-- Security audit and fix for payout_requests table
-- First, let's check current RLS status and policies

-- Ensure RLS is enabled on payout_requests (critical security measure)
ALTER TABLE public.payout_requests ENABLE ROW LEVEL SECURITY;

-- Drop any overly permissive policies that might exist
DROP POLICY IF EXISTS "Enable read access for all users" ON public.payout_requests;
DROP POLICY IF EXISTS "Public read access" ON public.payout_requests;
DROP POLICY IF EXISTS "Allow public access" ON public.payout_requests;

-- Ensure we have comprehensive security policies
-- These policies should already exist but let's make sure they're bulletproof

-- Policy 1: Farmers can only view their own payout requests
CREATE POLICY IF NOT EXISTS "Farmers can view their own payout requests ONLY" 
ON public.payout_requests 
FOR SELECT 
USING (auth.uid() = farmer_id AND auth.uid() IS NOT NULL);

-- Policy 2: Farmers can only create payout requests for themselves  
CREATE POLICY IF NOT EXISTS "Farmers can create their own payout requests ONLY" 
ON public.payout_requests 
FOR INSERT 
WITH CHECK (auth.uid() = farmer_id AND auth.uid() IS NOT NULL);

-- Policy 3: Only admins can view all payout requests
CREATE POLICY IF NOT EXISTS "Admins can view all payout requests ONLY" 
ON public.payout_requests 
FOR SELECT 
USING (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- Policy 4: Only admins can update payout requests
CREATE POLICY IF NOT EXISTS "Admins can update payout requests ONLY" 
ON public.payout_requests 
FOR UPDATE 
USING (
  auth.uid() IS NOT NULL AND
  EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- Policy 5: Block all public access (no anonymous users)
CREATE POLICY IF NOT EXISTS "Block all anonymous access to payout_requests" 
ON public.payout_requests 
FOR ALL
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);

-- Policy 6: No DELETE operations allowed (audit trail protection)
CREATE POLICY IF NOT EXISTS "No delete operations allowed" 
ON public.payout_requests 
FOR DELETE 
USING (false);

-- Add audit logging trigger for sensitive data access
CREATE OR REPLACE FUNCTION public.log_pii_access(
  table_name text,
  record_id text,
  access_type text
) RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO security_audit_log (
    user_id, action, table_name, record_id, created_at
  ) VALUES (
    auth.uid(), 
    'PII_ACCESS: ' || access_type,
    table_name,
    record_id,
    now()
  );
EXCEPTION
  WHEN OTHERS THEN
    -- Don't fail if audit logging fails
    NULL;
END;
$$;

-- Create security audit log table if it doesn't exist
CREATE TABLE IF NOT EXISTS public.security_audit_log (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid,
  action text NOT NULL,
  table_name text NOT NULL,
  record_id text,
  ip_address inet,
  user_agent text,
  created_at timestamp with time zone DEFAULT now()
);

-- Enable RLS on audit log table too
ALTER TABLE public.security_audit_log ENABLE ROW LEVEL SECURITY;

-- Only admins can view audit logs
CREATE POLICY IF NOT EXISTS "Admins can view security audit logs" 
ON public.security_audit_log 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- System can insert audit logs
CREATE POLICY IF NOT EXISTS "System can insert audit logs" 
ON public.security_audit_log 
FOR INSERT 
WITH CHECK (true);

-- Update the decryption function to include proper access logging
CREATE OR REPLACE FUNCTION public.encrypt_sensitive_data(data text)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  encryption_key TEXT := 'payout_encryption_key_2024_secure_farm2door';
BEGIN
  IF data IS NULL OR data = '' THEN
    RETURN NULL;
  END IF;
  RETURN encode(encrypt(data::bytea, encryption_key, 'aes'), 'base64');
EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL;
END;
$$;