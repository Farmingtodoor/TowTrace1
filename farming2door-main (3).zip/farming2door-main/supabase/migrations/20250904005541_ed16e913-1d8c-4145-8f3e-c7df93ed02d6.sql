-- Update the category name from "Produce" to "Fresh Produce" in the categories table
UPDATE public.categories 
SET name = 'Fresh Produce' 
WHERE name = 'Produce';