-- Update the products table to support farmer product management
-- Add missing columns and update RLS policies

-- Update products table with additional columns needed for farmer product management
ALTER TABLE public.products 
ADD COLUMN IF NOT EXISTS farmer_id UUID REFERENCES auth.users(id),
ADD COLUMN IF NOT EXISTS image_url TEXT,
ADD COLUMN IF NOT EXISTS unit TEXT DEFAULT 'lb',
ADD COLUMN IF NOT EXISTS stock_quantity INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS is_available BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS harvest_date DATE,
ADD COLUMN IF NOT EXISTS expiration_date DATE;

-- Create storage bucket for product images
INSERT INTO storage.buckets (id, name, public) 
VALUES ('product-images', 'product-images', true)
ON CONFLICT (id) DO NOTHING;

-- Create RLS policies for farmers to manage their own products
DROP POLICY IF EXISTS "Farmers can insert their own products" ON public.products;
CREATE POLICY "Farmers can insert their own products"
ON public.products
FOR INSERT
WITH CHECK (auth.uid() = farmer_id);

DROP POLICY IF EXISTS "Farmers can update their own products" ON public.products;
CREATE POLICY "Farmers can update their own products"
ON public.products
FOR UPDATE
USING (auth.uid() = farmer_id);

DROP POLICY IF EXISTS "Farmers can delete their own products" ON public.products;
CREATE POLICY "Farmers can delete their own products"
ON public.products
FOR DELETE
USING (auth.uid() = farmer_id);

-- Storage policies for product images (only create if they don't exist)
DO $$
BEGIN
    -- Check and create policy for viewing product images
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE schemaname = 'storage' 
        AND tablename = 'objects' 
        AND policyname = 'Product images are publicly viewable'
    ) THEN
        CREATE POLICY "Product images are publicly viewable"
        ON storage.objects
        FOR SELECT
        USING (bucket_id = 'product-images');
    END IF;

    -- Check and create policy for farmers uploading product images
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE schemaname = 'storage' 
        AND tablename = 'objects' 
        AND policyname = 'Farmers can upload their product images'
    ) THEN
        CREATE POLICY "Farmers can upload their product images"
        ON storage.objects
        FOR INSERT
        WITH CHECK (
          bucket_id = 'product-images' AND 
          auth.uid()::text = (storage.foldername(name))[1]
        );
    END IF;

    -- Check and create policy for farmers updating their product images
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE schemaname = 'storage' 
        AND tablename = 'objects' 
        AND policyname = 'Farmers can update their product images'
    ) THEN
        CREATE POLICY "Farmers can update their product images"
        ON storage.objects
        FOR UPDATE
        USING (
          bucket_id = 'product-images' AND 
          auth.uid()::text = (storage.foldername(name))[1]
        );
    END IF;

    -- Check and create policy for farmers deleting their product images
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies 
        WHERE schemaname = 'storage' 
        AND tablename = 'objects' 
        AND policyname = 'Farmers can delete their product images'
    ) THEN
        CREATE POLICY "Farmers can delete their product images"
        ON storage.objects
        FOR DELETE
        USING (
          bucket_id = 'product-images' AND 
          auth.uid()::text = (storage.foldername(name))[1]
        );
    END IF;
END
$$;