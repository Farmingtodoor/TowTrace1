-- CRITICAL SECURITY FIX: Remove or secure dangerous farmer data views
-- These views were bypassing RLS policies on the farmer_applications table

-- 1. DROP the most dangerous view that exposes decrypted sensitive data
DROP VIEW IF EXISTS public.farmer_applications_secure;

-- 2. DROP other potentially dangerous views that may expose sensitive data
DROP VIEW IF EXISTS public.farmer_contacts_secure;
DROP VIEW IF EXISTS public.farmer_contacts_auth;

-- 3. Create a secure replacement function for admin access to decrypted farmer data
-- This will properly enforce authentication and authorization
CREATE OR REPLACE FUNCTION public.get_farmer_application_secure_admin_only(application_id UUID)
RETURNS TABLE(
  id UUID,
  user_id UUID,
  full_name TEXT,
  email TEXT,
  phone TEXT,
  farm_name TEXT,
  farm_address TEXT,
  farm_size TEXT,
  farming_experience TEXT,
  farm_description TEXT,
  tax_id TEXT,
  business_registration_number TEXT,
  insurance_details TEXT,
  categories JSONB,
  subcategories JSONB,
  processing_methods TEXT[],
  certifications TEXT[],
  status TEXT,
  admin_notes TEXT,
  reviewed_by UUID,
  reviewed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE,
  updated_at TIMESTAMP WITH TIME ZONE
) AS $$
BEGIN
  -- Verify admin access
  IF NOT EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  ) THEN
    RAISE EXCEPTION 'Access denied: admin role required';
  END IF;
  
  -- Log the sensitive data access
  PERFORM log_sensitive_farmer_data_access(
    application_id,
    ARRAY['full_name', 'email', 'phone', 'farm_address', 'tax_id', 'business_registration_number', 'insurance_details'],
    'admin_secure_access'
  );
  
  -- Return decrypted data only to admins
  RETURN QUERY
  SELECT 
    fa.id,
    fa.user_id,
    fa.full_name,
    fa.email,
    CASE
      WHEN fa.phone_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(fa.phone_encrypted)
      ELSE fa.phone
    END AS phone,
    fa.farm_name,
    fa.farm_address,
    fa.farm_size,
    fa.farming_experience,
    fa.farm_description,
    CASE
      WHEN fa.tax_id_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(fa.tax_id_encrypted)
      ELSE fa.tax_id
    END AS tax_id,
    CASE
      WHEN fa.business_registration_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(fa.business_registration_encrypted)
      ELSE fa.business_registration_number
    END AS business_registration_number,
    CASE
      WHEN fa.insurance_details_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(fa.insurance_details_encrypted)
      ELSE fa.insurance_details
    END AS insurance_details,
    fa.categories,
    fa.subcategories,
    fa.processing_methods,
    fa.certifications,
    fa.status,
    fa.admin_notes,
    fa.reviewed_by,
    fa.reviewed_at,
    fa.created_at,
    fa.updated_at
  FROM farmer_applications fa
  WHERE fa.id = application_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- 4. Ensure approved_farmers_public and farmers_public_safe only contain non-sensitive data
-- Check if these views expose any sensitive information and secure them

-- 5. Add RLS policies to remaining views if needed
-- For approved_farmers_public: should be truly public with no sensitive data
CREATE POLICY "Public can view approved farmers info" 
ON public.approved_farmers_public 
FOR SELECT 
USING (true);

-- For farmers_public_safe: should be safe public data
CREATE POLICY "Public can view safe farmer info" 
ON public.farmers_public_safe 
FOR SELECT 
USING (true);

-- 6. Add security comments and documentation
COMMENT ON FUNCTION public.get_farmer_application_secure_admin_only(UUID) IS 
'ADMIN ONLY: Secure function to access decrypted farmer application data. Requires admin role and logs all access attempts.';

-- 7. Create audit trail for this security fix
INSERT INTO public.security_audit_log (
  user_id,
  action,
  table_name,
  record_id
) VALUES (
  '00000000-0000-0000-0000-000000000000'::UUID,
  'security_fix_removed_dangerous_views',
  'farmer_applications_secure',
  'Removed publicly accessible views exposing sensitive farmer PII'
);

-- 8. Block any future creation of similar dangerous views by adding a security note
COMMENT ON TABLE public.farmer_applications IS 
'SECURITY CRITICAL: This table contains sensitive PII. Never create views that bypass RLS policies. Use security definer functions with proper authorization checks instead.';