DO $$
DECLARE
  r record;
  allow_authenticated text[] := ARRAY[
    'has_role','is_valid_email','is_suspicious_email','get_current_user_role',
    'calculate_delivery_fee','get_approved_farmers_public','get_available_pickup_slots',
    'get_driver_info_for_customer_order','get_driver_location_for_customer_order',
    'get_farmer_applications_secure_admin','get_farmer_contacts_for_orders',
    'get_farmers_public_safe','get_featured_items','get_product_recommendations',
    'get_personalized_recommendations','get_trending_products','search_products_advanced',
    'track_analytics_event','track_product_view','update_user_preferences','validate_promotion',
    'get_admin_payout_list','get_admin_payout_details','admin_update_payout_status',
    'insert_encrypted_payout_request','get_decrypted_payout_requests',
    'get_masked_customer_insights','generate_referral_code',
    'update_customer_insights','update_farmer_revenue_analytics','update_product_performance',
    'mask_email','mask_email_safe','mask_phone'
  ];
  allow_anon text[] := ARRAY[
    'has_role','is_valid_email','is_suspicious_email',
    'calculate_delivery_fee','get_approved_farmers_public','get_available_pickup_slots',
    'get_farmers_public_safe','get_featured_items','get_product_recommendations',
    'get_trending_products','search_products_advanced','track_analytics_event',
    'track_product_view','validate_promotion','mask_email','mask_email_safe','mask_phone'
  ];
BEGIN
  FOR r IN
    SELECT p.oid::regprocedure AS sig, p.proname
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public' AND p.prosecdef
  LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM PUBLIC, anon, authenticated', r.sig);

    IF r.proname = ANY (allow_authenticated) THEN
      EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO authenticated', r.sig);
    END IF;

    IF r.proname = ANY (allow_anon) THEN
      EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO anon', r.sig);
    END IF;

    EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO service_role', r.sig);
  END LOOP;
END $$;