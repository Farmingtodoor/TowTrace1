-- Fix security issues - update functions with proper search_path
CREATE OR REPLACE FUNCTION public.expire_featured_items()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.featured_purchases 
  SET status = 'expired', updated_at = now()
  WHERE status = 'active' 
  AND expires_at < now();
END;
$$;

-- Update the get_featured_items function with proper search_path
CREATE OR REPLACE FUNCTION public.get_featured_items(feature_type_param TEXT DEFAULT NULL)
RETURNS TABLE(
  purchase_id UUID,
  farmer_id UUID,
  item_id UUID,
  feature_type TEXT,
  expires_at TIMESTAMP WITH TIME ZONE,
  farm_name TEXT,
  product_name TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- First expire any items that should be expired
  PERFORM public.expire_featured_items();
  
  -- Return active featured items
  RETURN QUERY
  SELECT 
    fp.id as purchase_id,
    fp.farmer_id,
    fp.item_id,
    fs.feature_type,
    fp.expires_at,
    COALESCE(fa.farm_name, 'Unknown Farm') as farm_name,
    COALESCE(p.name, 'Featured Farm') as product_name
  FROM public.featured_purchases fp
  JOIN public.featured_services fs ON fp.service_id = fs.id
  LEFT JOIN public.farmer_applications fa ON fp.farmer_id = fa.user_id AND fa.status = 'approved'
  LEFT JOIN public.products p ON fp.item_id = p.id AND fs.feature_type = 'product'
  WHERE fp.status = 'active'
  AND fp.expires_at > now()
  AND (feature_type_param IS NULL OR fs.feature_type = feature_type_param)
  ORDER BY fp.created_at ASC;
END;
$$;