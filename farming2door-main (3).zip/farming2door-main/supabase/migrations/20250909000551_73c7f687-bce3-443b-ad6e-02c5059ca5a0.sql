-- CRITICAL SECURITY ENHANCEMENT: Add field-level encryption for all remaining PII
-- This addresses the remaining security vulnerability about personal information exposure

-- 1. Add encrypted columns for remaining sensitive fields
ALTER TABLE public.farmer_applications 
ADD COLUMN IF NOT EXISTS email_encrypted TEXT,
ADD COLUMN IF NOT EXISTS full_name_encrypted TEXT,
ADD COLUMN IF NOT EXISTS farm_address_encrypted TEXT;

-- 2. Create a comprehensive encryption trigger for all sensitive fields
CREATE OR REPLACE FUNCTION public.encrypt_all_farmer_sensitive_data()
RETURNS TRIGGER AS $$
BEGIN
  -- Encrypt email if provided
  IF NEW.email IS NOT NULL AND NEW.email != '' THEN
    NEW.email_encrypted := encrypt_farmer_sensitive_data(NEW.email);
    -- Keep a masked version for non-sensitive display
    NEW.email := mask_email_safe(NEW.email);
  END IF;
  
  -- Encrypt full name if provided
  IF NEW.full_name IS NOT NULL AND NEW.full_name != '' THEN
    NEW.full_name_encrypted := encrypt_farmer_sensitive_data(NEW.full_name);
    -- Keep initials only for display
    NEW.full_name := LEFT(NEW.full_name, 1) || '***';
  END IF;
  
  -- Encrypt farm address if provided (keep general location only)
  IF NEW.farm_address IS NOT NULL AND NEW.farm_address != '' THEN
    NEW.farm_address_encrypted := encrypt_farmer_sensitive_data(NEW.farm_address);
    -- Keep only city/state for public display
    NEW.farm_address := regexp_replace(NEW.farm_address, '[0-9].*', 'General Area', 'g');
  END IF;
  
  -- Encrypt existing sensitive fields (phone, tax_id, etc.)
  IF NEW.phone IS NOT NULL AND NEW.phone != '' THEN
    NEW.phone_encrypted := encrypt_farmer_sensitive_data(NEW.phone);
    NEW.phone := mask_phone(NEW.phone);
  END IF;
  
  IF NEW.tax_id IS NOT NULL AND NEW.tax_id != '' THEN
    NEW.tax_id_encrypted := encrypt_farmer_sensitive_data(NEW.tax_id);
    NEW.tax_id := NULL; -- Clear plaintext completely
  END IF;
  
  IF NEW.business_registration_number IS NOT NULL AND NEW.business_registration_number != '' THEN
    NEW.business_registration_encrypted := encrypt_farmer_sensitive_data(NEW.business_registration_number);
    NEW.business_registration_number := NULL; -- Clear plaintext completely
  END IF;
  
  IF NEW.insurance_details IS NOT NULL AND NEW.insurance_details != '' THEN
    NEW.insurance_details_encrypted := encrypt_farmer_sensitive_data(NEW.insurance_details);
    NEW.insurance_details := NULL; -- Clear plaintext completely
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- 3. Create trigger to automatically encrypt data on insert/update
DROP TRIGGER IF EXISTS encrypt_all_sensitive_farmer_data ON public.farmer_applications;
CREATE TRIGGER encrypt_all_sensitive_farmer_data
  BEFORE INSERT OR UPDATE ON public.farmer_applications
  FOR EACH ROW
  EXECUTE FUNCTION public.encrypt_all_farmer_sensitive_data();

-- 4. Update the secure access function to handle all encrypted fields
CREATE OR REPLACE FUNCTION public.get_farmer_application_secure(application_id UUID)
RETURNS TABLE(
  id UUID,
  user_id UUID,
  full_name TEXT,
  email TEXT,
  phone TEXT,
  farm_name TEXT,
  farm_address TEXT,
  farm_size TEXT,
  farming_experience TEXT,
  farm_description TEXT,
  tax_id TEXT,
  business_registration_number TEXT,
  insurance_details TEXT,
  categories JSONB,
  subcategories JSONB,
  processing_methods TEXT[],
  certifications TEXT[],
  status TEXT,
  admin_notes TEXT,
  reviewed_by UUID,
  reviewed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE,
  updated_at TIMESTAMP WITH TIME ZONE
) AS $$
BEGIN
  -- Verify admin access
  IF NOT EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  ) THEN
    RAISE EXCEPTION 'Access denied: admin role required';
  END IF;
  
  -- Log the sensitive data access
  PERFORM log_sensitive_farmer_data_access(
    application_id,
    ARRAY['full_name', 'email', 'phone', 'farm_address', 'tax_id', 'business_registration_number', 'insurance_details'],
    'admin_full_decrypted_access'
  );
  
  -- Return decrypted data for all sensitive fields
  RETURN QUERY
  SELECT 
    fa.id,
    fa.user_id,
    CASE
      WHEN fa.full_name_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(fa.full_name_encrypted)
      ELSE fa.full_name
    END AS full_name,
    CASE
      WHEN fa.email_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(fa.email_encrypted)
      ELSE fa.email
    END AS email,
    CASE
      WHEN fa.phone_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(fa.phone_encrypted)
      ELSE fa.phone
    END AS phone,
    fa.farm_name,
    CASE
      WHEN fa.farm_address_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(fa.farm_address_encrypted)
      ELSE fa.farm_address
    END AS farm_address,
    fa.farm_size,
    fa.farming_experience,
    fa.farm_description,
    CASE
      WHEN fa.tax_id_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(fa.tax_id_encrypted)
      ELSE fa.tax_id
    END AS tax_id,
    CASE
      WHEN fa.business_registration_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(fa.business_registration_encrypted)
      ELSE fa.business_registration_number
    END AS business_registration_number,
    CASE
      WHEN fa.insurance_details_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(fa.insurance_details_encrypted)
      ELSE fa.insurance_details
    END AS insurance_details,
    fa.categories,
    fa.subcategories,
    fa.processing_methods,
    fa.certifications,
    fa.status,
    fa.admin_notes,
    fa.reviewed_by,
    fa.reviewed_at,
    fa.created_at,
    fa.updated_at
  FROM farmer_applications fa
  WHERE fa.id = application_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- 5. Update public functions to only return non-sensitive data
CREATE OR REPLACE FUNCTION public.get_farmer_contacts_for_orders()
RETURNS TABLE(
  user_id UUID,
  farm_name TEXT,
  contact_email TEXT
) AS $$
BEGIN
  -- This function returns MASKED email addresses for approved farmers only
  -- Safe for authenticated users placing custom orders
  RETURN QUERY
  SELECT 
    fa.user_id,
    fa.farm_name,
    mask_email_safe(
      CASE
        WHEN fa.email_encrypted IS NOT NULL THEN decrypt_farmer_sensitive_data(fa.email_encrypted)
        ELSE fa.email
      END
    ) as contact_email
  FROM farmer_applications fa
  WHERE fa.status = 'approved';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- 6. Log this comprehensive security enhancement
INSERT INTO public.security_audit_log (
  action,
  table_name,
  record_id
) VALUES (
  'CRITICAL_SECURITY_ENHANCEMENT: Added field-level encryption for all PII',
  'farmer_applications',
  'Implemented comprehensive encryption for email, full_name, farm_address, phone, tax_id, business_registration, insurance_details'
);

-- 7. Add comprehensive security documentation
COMMENT ON COLUMN public.farmer_applications.email_encrypted IS 'ENCRYPTED PII: Contains encrypted email addresses - access requires admin privileges and audit logging';
COMMENT ON COLUMN public.farmer_applications.full_name_encrypted IS 'ENCRYPTED PII: Contains encrypted full names - access requires admin privileges and audit logging';
COMMENT ON COLUMN public.farmer_applications.farm_address_encrypted IS 'ENCRYPTED PII: Contains encrypted addresses - access requires admin privileges and audit logging';

COMMENT ON FUNCTION public.encrypt_all_farmer_sensitive_data() IS 
'SECURITY CRITICAL: Automatically encrypts all sensitive PII fields and masks plaintext versions on insert/update';

-- 8. Ensure existing data gets encrypted by updating all records
-- This will trigger the encryption function for existing data
UPDATE public.farmer_applications 
SET updated_at = updated_at 
WHERE email_encrypted IS NULL 
   OR full_name_encrypted IS NULL 
   OR farm_address_encrypted IS NULL;