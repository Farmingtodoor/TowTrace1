-- Create driver profiles table
CREATE TABLE public.driver_profiles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  vehicle_type TEXT NOT NULL DEFAULT 'car',
  license_plate TEXT NOT NULL,
  driver_license_number TEXT NOT NULL,
  is_verified BOOLEAN NOT NULL DEFAULT false,
  is_active BOOLEAN NOT NULL DEFAULT true,
  current_latitude DECIMAL,
  current_longitude DECIMAL,
  last_location_update TIMESTAMP WITH TIME ZONE,
  status TEXT NOT NULL DEFAULT 'offline' CHECK (status IN ('online', 'offline', 'on_delivery')),
  rating DECIMAL DEFAULT 5.0,
  total_deliveries INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create driver_order_assignments table
CREATE TABLE public.driver_order_assignments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  order_id UUID NOT NULL,
  driver_id UUID NOT NULL,
  status TEXT NOT NULL DEFAULT 'assigned' CHECK (status IN ('assigned', 'picked_up', 'in_transit', 'delivered', 'cancelled')),
  assigned_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  picked_up_at TIMESTAMP WITH TIME ZONE,
  delivered_at TIMESTAMP WITH TIME ZONE,
  driver_notes TEXT,
  customer_rating INTEGER CHECK (customer_rating >= 1 AND customer_rating <= 5),
  driver_earnings DECIMAL NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create driver_location_history table for tracking
CREATE TABLE public.driver_location_history (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  driver_id UUID NOT NULL,
  order_assignment_id UUID,
  latitude DECIMAL NOT NULL,
  longitude DECIMAL NOT NULL,
  recorded_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS on all driver tables
ALTER TABLE public.driver_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.driver_order_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.driver_location_history ENABLE ROW LEVEL SECURITY;

-- Driver profiles policies
CREATE POLICY "Drivers can view and edit their own profile" 
ON public.driver_profiles 
FOR ALL 
USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all driver profiles" 
ON public.driver_profiles 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM user_roles 
  WHERE user_id = auth.uid() 
  AND role IN ('admin', 'super_admin')
));

CREATE POLICY "Customers can view basic driver info for their orders" 
ON public.driver_profiles 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM driver_order_assignments doa
  JOIN orders o ON doa.order_id = o.id
  WHERE doa.driver_id = driver_profiles.user_id
  AND o.customer_id = auth.uid()
));

-- Driver order assignments policies
CREATE POLICY "Drivers can view their own assignments" 
ON public.driver_order_assignments 
FOR SELECT 
USING (auth.uid() = driver_id);

CREATE POLICY "Drivers can update their own assignments" 
ON public.driver_order_assignments 
FOR UPDATE 
USING (auth.uid() = driver_id);

CREATE POLICY "System can create assignments" 
ON public.driver_order_assignments 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Customers can view assignments for their orders" 
ON public.driver_order_assignments 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM orders o
  WHERE o.id = driver_order_assignments.order_id
  AND o.customer_id = auth.uid()
));

CREATE POLICY "Farmers can view assignments for their orders" 
ON public.driver_order_assignments 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM orders o
  WHERE o.id = driver_order_assignments.order_id
  AND o.farmer_id = auth.uid()
));

-- Driver location history policies
CREATE POLICY "Drivers can insert their own location" 
ON public.driver_location_history 
FOR INSERT 
WITH CHECK (auth.uid() = driver_id);

CREATE POLICY "Customers can view location history for their orders" 
ON public.driver_location_history 
FOR SELECT 
USING (EXISTS (
  SELECT 1 FROM driver_order_assignments doa
  JOIN orders o ON doa.order_id = o.id
  WHERE doa.id = driver_location_history.order_assignment_id
  AND o.customer_id = auth.uid()
));

-- Add triggers for updated_at
CREATE TRIGGER update_driver_profiles_updated_at
  BEFORE UPDATE ON public.driver_profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_driver_order_assignments_updated_at
  BEFORE UPDATE ON public.driver_order_assignments
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Function to find nearby drivers
CREATE OR REPLACE FUNCTION public.find_nearby_drivers(
  farm_lat DECIMAL,
  farm_lng DECIMAL,
  radius_km DECIMAL DEFAULT 10
)
RETURNS TABLE(
  driver_id UUID,
  driver_name TEXT,
  vehicle_type TEXT,
  distance_km DECIMAL,
  rating DECIMAL,
  phone TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    dp.user_id as driver_id,
    dp.full_name as driver_name,
    dp.vehicle_type,
    (6371 * acos(cos(radians(farm_lat)) * cos(radians(dp.current_latitude)) 
    * cos(radians(dp.current_longitude) - radians(farm_lng)) 
    + sin(radians(farm_lat)) * sin(radians(dp.current_latitude)))) as distance_km,
    dp.rating,
    dp.phone
  FROM driver_profiles dp
  WHERE dp.is_active = true 
    AND dp.status = 'online'
    AND dp.current_latitude IS NOT NULL 
    AND dp.current_longitude IS NOT NULL
    AND (6371 * acos(cos(radians(farm_lat)) * cos(radians(dp.current_latitude)) 
         * cos(radians(dp.current_longitude) - radians(farm_lng)) 
         + sin(radians(farm_lat)) * sin(radians(dp.current_latitude)))) <= radius_km
  ORDER BY distance_km ASC;
END;
$$;

-- Function to calculate delivery fee based on distance
CREATE OR REPLACE FUNCTION public.calculate_delivery_fee(
  farm_lat DECIMAL,
  farm_lng DECIMAL,
  customer_lat DECIMAL,
  customer_lng DECIMAL
)
RETURNS DECIMAL
LANGUAGE plpgsql
AS $$
DECLARE
  distance_km DECIMAL;
  base_fee DECIMAL := 3.99;
  per_km_fee DECIMAL := 1.50;
  total_fee DECIMAL;
BEGIN
  -- Calculate distance using Haversine formula
  distance_km := (6371 * acos(cos(radians(farm_lat)) * cos(radians(customer_lat)) 
    * cos(radians(customer_lng) - radians(farm_lng)) 
    + sin(radians(farm_lat)) * sin(radians(customer_lat))));
  
  -- Calculate total fee (base fee + distance fee)
  total_fee := base_fee + (distance_km * per_km_fee);
  
  -- Minimum fee of $3.99, maximum of $25.99
  total_fee := GREATEST(total_fee, 3.99);
  total_fee := LEAST(total_fee, 25.99);
  
  RETURN ROUND(total_fee, 2);
END;
$$;

-- Add delivery_fee column to orders table
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_fee DECIMAL DEFAULT 0;

-- Update orders table to include pickup coordinates
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS pickup_latitude DECIMAL;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS pickup_longitude DECIMAL;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_latitude DECIMAL;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_longitude DECIMAL;