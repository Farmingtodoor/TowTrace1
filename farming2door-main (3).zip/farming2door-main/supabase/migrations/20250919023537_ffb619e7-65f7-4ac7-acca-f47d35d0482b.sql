-- Strengthen security for payout_requests table to protect financial data

-- Drop existing policies to replace with more secure versions
DROP POLICY IF EXISTS "Admins update payout requests ONLY" ON public.payout_requests;
DROP POLICY IF EXISTS "Admins view all payout requests ONLY" ON public.payout_requests;
DROP POLICY IF EXISTS "Block anonymous access to payout requests" ON public.payout_requests;
DROP POLICY IF EXISTS "Farmers create own payout requests ONLY" ON public.payout_requests;
DROP POLICY IF EXISTS "Farmers view own payout requests ONLY" ON public.payout_requests;
DROP POLICY IF EXISTS "No delete operations on payout requests" ON public.payout_requests;

-- CRITICAL SECURITY: Block ALL anonymous access completely
CREATE POLICY "SECURITY_CRITICAL_Block_all_anonymous_access" 
ON public.payout_requests 
FOR ALL 
USING (false) 
WITH CHECK (false);

-- SECURE: Farmers can only view their own payout requests with strict validation
CREATE POLICY "SECURE_farmers_own_payout_requests_only" 
ON public.payout_requests 
FOR SELECT 
USING (
  auth.uid() IS NOT NULL 
  AND auth.uid() = farmer_id 
  AND EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role = 'farmer'
  )
);

-- SECURE: Farmers can only create their own payout requests with validation
CREATE POLICY "SECURE_farmers_create_own_payout_only" 
ON public.payout_requests 
FOR INSERT 
WITH CHECK (
  auth.uid() IS NOT NULL 
  AND auth.uid() = farmer_id 
  AND EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role = 'farmer'
  )
);

-- SECURE: Only verified admins can view all payout requests
CREATE POLICY "SECURE_admins_view_all_payouts_only" 
ON public.payout_requests 
FOR SELECT 
USING (
  auth.uid() IS NOT NULL 
  AND EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- SECURE: Only verified admins can update payout requests
CREATE POLICY "SECURE_admins_update_payouts_only" 
ON public.payout_requests 
FOR UPDATE 
USING (
  auth.uid() IS NOT NULL 
  AND EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- CRITICAL: Absolutely no delete operations allowed
CREATE POLICY "SECURITY_CRITICAL_no_delete_payout_requests" 
ON public.payout_requests 
FOR DELETE 
USING (false);

-- Ensure RLS is enabled and revoke all default permissions
ALTER TABLE public.payout_requests ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.payout_requests FROM anon, authenticated;

-- Grant minimal permissions only through RLS policies
GRANT SELECT, INSERT, UPDATE ON public.payout_requests TO authenticated;

-- Add additional security: audit trigger for all payout access
CREATE OR REPLACE FUNCTION public.audit_payout_access()
RETURNS TRIGGER AS $$
BEGIN
  -- Log all access to payout requests for security monitoring
  INSERT INTO public.security_audit_log (
    user_id, action, table_name, record_id, created_at
  ) VALUES (
    auth.uid(), 
    TG_OP || '_payout_request',
    'payout_requests',
    COALESCE(NEW.id::text, OLD.id::text),
    now()
  );
  
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create audit trigger for all operations on payout_requests
DROP TRIGGER IF EXISTS audit_payout_requests_access ON public.payout_requests;
CREATE TRIGGER audit_payout_requests_access
  AFTER INSERT OR UPDATE OR DELETE ON public.payout_requests
  FOR EACH ROW EXECUTE FUNCTION public.audit_payout_access();