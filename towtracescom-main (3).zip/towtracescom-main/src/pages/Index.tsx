import { useState, useCallback, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { LookupCard } from '@/components/lookup/LookupCard';
import { TowResult } from '@/components/results/TowResult';
import { NotFoundResult } from '@/components/results/NotFoundResult';
import { AuthModal } from '@/components/auth/AuthModal';
import { PageHeader } from '@/components/layout/PageHeader';
import { PageFooter } from '@/components/layout/PageFooter';
import { TowTruckAnimation } from '@/components/animations/TowTruckAnimation';
import { ImageCarousel } from '@/components/home/ImageCarousel';
import { HeroDescription } from '@/components/home/HeroDescription';
import { WelcomeCard } from '@/components/home/WelcomeCard';
import { AnimatedStats } from '@/components/home/AnimatedStats';
import { useAuth } from '@/hooks/useAuth';
import { useTowSearch } from '@/hooks/useTowSearch';
import { supabase } from '@/integrations/supabase/client';
import { Shield, Clock, MapPin, ArrowRight, Truck, FileText, Users, TrendingUp, Car, CircleDot, CheckCircle2, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatDistanceToNow } from 'date-fns';

interface ActivityItem {
  id: string;
  type: 'tow_record' | 'claim_update';
  title: string;
  description: string;
  timestamp: string;
  status?: string;
}

export default function Index() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { status, record, searchType, searchValue, searchByPlate, searchByVIN, reset, isLoading } = useTowSearch();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [pendingClaimRecordId, setPendingClaimRecordId] = useState<string | null>(null);
  const [isOperator, setIsOperator] = useState(false);
  const [operatorName, setOperatorName] = useState<string | null>(null);
  const [towYardName, setTowYardName] = useState<string | null>(null);
  const [recentActivity, setRecentActivity] = useState<ActivityItem[]>([]);
  const [pendingCounts, setPendingCounts] = useState({
    documents: 0,
    disputes: 0,
    records: 0,
    team: 0,
  });
  const [towYardId, setTowYardId] = useState<string | null>(null);

  // Fetch activity and counts - extracted for reuse
  const fetchActivityData = async (yardId: string) => {
    // Fetch recent tow records
    const { data: towRecords } = await supabase
      .from('tow_records')
      .select('id, plate_number, make, model, status, created_at')
      .eq('tow_yard_id', yardId)
      .order('created_at', { ascending: false })
      .limit(5);

    // Fetch recent claims for this yard's records
    const { data: claims } = await supabase
      .from('claims')
      .select('id, claim_status, updated_at, tow_records!inner(tow_yard_id, plate_number, make, model)')
      .eq('tow_records.tow_yard_id', yardId)
      .order('updated_at', { ascending: false })
      .limit(5);

    // Fetch pending counts
    const [
      { count: pendingDocsCount },
      { count: openDisputesCount },
      { count: activeRecordsCount },
    ] = await Promise.all([
      // Pending documents
      supabase
        .from('documents')
        .select('id', { count: 'exact', head: true })
        .eq('status', 'pending')
        .in('claim_id', 
          (await supabase
            .from('claims')
            .select('id, tow_records!inner(tow_yard_id)')
            .eq('tow_records.tow_yard_id', yardId)
          ).data?.map(c => c.id) || []
        ),
      // Open disputes
      supabase
        .from('disputes')
        .select('id', { count: 'exact', head: true })
        .eq('tow_yard_id', yardId)
        .in('status', ['open', 'under_review']),
      // Active tow records (not released)
      supabase
        .from('tow_records')
        .select('id', { count: 'exact', head: true })
        .eq('tow_yard_id', yardId)
        .neq('status', 'released'),
    ]);

    setPendingCounts({
      documents: pendingDocsCount || 0,
      disputes: openDisputesCount || 0,
      records: activeRecordsCount || 0,
      team: 0,
    });

    const activities: ActivityItem[] = [];

    // Map tow records to activity items
    towRecords?.forEach(record => {
      activities.push({
        id: `tow-${record.id}`,
        type: 'tow_record',
        title: `${record.make || 'Vehicle'} ${record.model || ''} added`.trim(),
        description: record.plate_number ? `Plate: ${record.plate_number}` : 'No plate recorded',
        timestamp: record.created_at,
        status: record.status,
      });
    });

    // Map claims to activity items
    claims?.forEach(claim => {
      const vehicle = claim.tow_records as any;
      activities.push({
        id: `claim-${claim.id}`,
        type: 'claim_update',
        title: `Claim ${claim.claim_status.replace('_', ' ')}`,
        description: vehicle ? `${vehicle.make || ''} ${vehicle.model || ''} - ${vehicle.plate_number || 'No plate'}`.trim() : 'Vehicle claim',
        timestamp: claim.updated_at,
        status: claim.claim_status,
      });
    });

    // Sort by timestamp and take the most recent 8
    activities.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    setRecentActivity(activities.slice(0, 8));
  };

  // Check if user is an operator and fetch related data
  useEffect(() => {
    const checkOperatorStatus = async () => {
      if (!user) {
        setIsOperator(false);
        setOperatorName(null);
        setTowYardName(null);
        setRecentActivity([]);
        setPendingCounts({ documents: 0, disputes: 0, records: 0, team: 0 });
        setTowYardId(null);
        return;
      }

      // Fetch operator assignment with tow yard info
      const { data: operatorData } = await supabase
        .from('tow_yard_operators')
        .select('id, tow_yard_id, tow_yards(name)')
        .eq('operator_user_id', user.id)
        .limit(1)
        .single();

      const isOp = !!operatorData;
      setIsOperator(isOp);

      if (operatorData?.tow_yards) {
        setTowYardName((operatorData.tow_yards as any).name);
      }

      if (operatorData?.tow_yard_id) {
        setTowYardId(operatorData.tow_yard_id);
      }

      // Fetch profile name
      const { data: profileData } = await supabase
        .from('profiles')
        .select('first_name, full_name')
        .eq('user_id', user.id)
        .single();

      if (profileData) {
        setOperatorName(profileData.first_name || profileData.full_name?.split(' ')[0] || null);
      }

      // Fetch initial activity data
      if (isOp && operatorData?.tow_yard_id) {
        await fetchActivityData(operatorData.tow_yard_id);
      }
    };

    checkOperatorStatus();
  }, [user]);

  // Set up real-time subscriptions for activity updates
  useEffect(() => {
    if (!isOperator || !towYardId) return;

    // Subscribe to tow_records changes
    const towRecordsChannel = supabase
      .channel('operator-tow-records')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'tow_records',
          filter: `tow_yard_id=eq.${towYardId}`,
        },
        () => {
          // Refresh activity data on any change
          fetchActivityData(towYardId);
        }
      )
      .subscribe();

    // Subscribe to claims changes (need to refresh to check if related to our yard)
    const claimsChannel = supabase
      .channel('operator-claims')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'claims',
        },
        () => {
          // Refresh activity data on any claim change
          fetchActivityData(towYardId);
        }
      )
      .subscribe();

    // Subscribe to documents changes
    const documentsChannel = supabase
      .channel('operator-documents')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'documents',
        },
        () => {
          // Refresh counts when documents change
          fetchActivityData(towYardId);
        }
      )
      .subscribe();

    // Subscribe to disputes changes
    const disputesChannel = supabase
      .channel('operator-disputes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'disputes',
          filter: `tow_yard_id=eq.${towYardId}`,
        },
        () => {
          // Refresh counts when disputes change
          fetchActivityData(towYardId);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(towRecordsChannel);
      supabase.removeChannel(claimsChannel);
      supabase.removeChannel(documentsChannel);
      supabase.removeChannel(disputesChannel);
    };
  }, [isOperator, towYardId]);

  const handleClaimVehicle = useCallback(() => {
    if (!user) {
      if (record) {
        setPendingClaimRecordId(record.id);
      }
      setShowAuthModal(true);
    } else if (record) {
      navigate(`/claim/${record.id}`);
    }
  }, [user, record, navigate]);

  const handleAuthSuccess = useCallback(() => {
    if (pendingClaimRecordId) {
      navigate(`/claim/${pendingClaimRecordId}`);
      setPendingClaimRecordId(null);
    }
  }, [pendingClaimRecordId, navigate]);

  const NotificationBadge = ({ count }: { count: number }) => {
    if (count === 0) return null;
    return (
      <span className="absolute -top-1 -right-1 flex items-center justify-center min-w-5 h-5 px-1.5 text-xs font-bold text-white bg-destructive rounded-full animate-pulse">
        {count > 99 ? '99+' : count}
      </span>
    );
  };

  const getActivityIcon = (type: string, status?: string) => {
    if (type === 'tow_record') {
      return <Truck className="w-4 h-4 text-accent" />;
    }
    if (status === 'complete') {
      return <CheckCircle2 className="w-4 h-4 text-success" />;
    }
    if (status === 'docs_approved' || status === 'docs_submitted') {
      return <FileText className="w-4 h-4 text-info" />;
    }
    return <CircleDot className="w-4 h-4 text-muted-foreground" />;
  };

  const getStatusBadge = (status?: string) => {
    if (!status) return null;
    const statusMap: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
      towed: { label: 'Towed', variant: 'default' },
      released: { label: 'Released', variant: 'secondary' },
      complete: { label: 'Complete', variant: 'secondary' },
      started: { label: 'Started', variant: 'outline' },
      docs_submitted: { label: 'Docs Pending', variant: 'outline' },
      docs_approved: { label: 'Docs Approved', variant: 'default' },
      payment_pending: { label: 'Payment Due', variant: 'destructive' },
    };
    const config = statusMap[status] || { label: status, variant: 'outline' as const };
    return <Badge variant={config.variant} className="text-xs">{config.label}</Badge>;
  };

  // Operator Homepage Component
  const OperatorHomepage = () => (
    <div className="min-h-screen flex flex-col bg-background">
      <PageHeader onSignInClick={() => setShowAuthModal(true)} />

      {/* Operator Hero Section */}
      <section className="bg-gradient-to-br from-primary via-primary to-primary/90 text-primary-foreground py-12 md:py-16 px-4 relative overflow-hidden">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-accent/20 rounded-full blur-3xl" />
          <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
        </div>

        <div className="max-w-5xl mx-auto relative z-10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="text-center md:text-left space-y-3">
              <div className="inline-flex items-center gap-2 bg-accent/20 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-medium border border-accent/30">
                <Truck className="w-4 h-4 text-accent" />
                <span>Operator Portal</span>
              </div>
              
              <h1 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold">
                Welcome back{operatorName ? `, ${operatorName}` : ''}!
              </h1>

              {towYardName && (
                <p className="text-lg text-primary-foreground/90 font-medium flex items-center gap-2 justify-center md:justify-start">
                  <Car className="w-5 h-5 text-accent" />
                  {towYardName}
                </p>
              )}
              
              <p className="text-base text-primary-foreground/70 max-w-lg">
                Manage your tow records, review claims, and track performance.
              </p>

              <div className="flex flex-wrap gap-3 pt-2">
                <Button 
                  size="lg" 
                  className="bg-accent hover:bg-accent/90 text-accent-foreground"
                  onClick={() => navigate('/operator')}
                >
                  <Truck className="w-5 h-5 mr-2" />
                  Go to Dashboard
                </Button>
                <Button 
                  size="lg" 
                  variant="ghost-light"
                  onClick={() => navigate('/operator/documents')}
                >
                  <FileText className="w-5 h-5 mr-2" />
                  Review Documents
                </Button>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 gap-4 w-full md:w-auto">
              <Card className="bg-primary-foreground/10 backdrop-blur-sm border-primary-foreground/20 p-4 text-center cursor-pointer hover:bg-primary-foreground/15 transition-colors" onClick={() => navigate('/operator')}>
                <TrendingUp className="w-8 h-8 text-accent mx-auto mb-2" />
                <p className="text-lg font-bold text-primary-foreground">Dashboard</p>
                <p className="text-xs text-primary-foreground/70">View Analytics</p>
              </Card>
              <Card className="bg-primary-foreground/10 backdrop-blur-sm border-primary-foreground/20 p-4 text-center cursor-pointer hover:bg-primary-foreground/15 transition-colors" onClick={() => navigate('/operator/employees')}>
                <Users className="w-8 h-8 text-accent mx-auto mb-2" />
                <p className="text-lg font-bold text-primary-foreground">Team</p>
                <p className="text-xs text-primary-foreground/70">Manage Staff</p>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content: Quick Actions + Activity Feed */}
      <main className="flex-1 py-10 px-4">
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Quick Actions */}
            <div className="lg:col-span-2">
              <h2 className="font-display text-xl font-bold mb-4">Quick Actions</h2>
              
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <Card 
                  className="p-4 hover:shadow-lg transition-shadow cursor-pointer group relative"
                  onClick={() => navigate('/operator')}
                >
                  <NotificationBadge count={pendingCounts.records} />
                  <Truck className="w-8 h-8 text-accent mb-2 group-hover:scale-110 transition-transform" />
                  <h3 className="font-semibold text-sm">Tow Records</h3>
                  <p className="text-xs text-muted-foreground">
                    {pendingCounts.records > 0 ? `${pendingCounts.records} active` : 'Manage records'}
                  </p>
                </Card>

                <Card 
                  className="p-4 hover:shadow-lg transition-shadow cursor-pointer group relative"
                  onClick={() => navigate('/operator/documents')}
                >
                  <NotificationBadge count={pendingCounts.documents} />
                  <FileText className="w-8 h-8 text-info mb-2 group-hover:scale-110 transition-transform" />
                  <h3 className="font-semibold text-sm">Documents</h3>
                  <p className="text-xs text-muted-foreground">
                    {pendingCounts.documents > 0 ? `${pendingCounts.documents} pending` : 'Review claims'}
                  </p>
                </Card>

                <Card 
                  className="p-4 hover:shadow-lg transition-shadow cursor-pointer group relative"
                  onClick={() => navigate('/operator/disputes')}
                >
                  <NotificationBadge count={pendingCounts.disputes} />
                  <AlertCircle className="w-8 h-8 text-destructive mb-2 group-hover:scale-110 transition-transform" />
                  <h3 className="font-semibold text-sm">Disputes</h3>
                  <p className="text-xs text-muted-foreground">
                    {pendingCounts.disputes > 0 ? `${pendingCounts.disputes} open` : 'Handle issues'}
                  </p>
                </Card>

                <Card 
                  className="p-4 hover:shadow-lg transition-shadow cursor-pointer group relative"
                  onClick={() => navigate('/operator/employees')}
                >
                  <Users className="w-8 h-8 text-success mb-2 group-hover:scale-110 transition-transform" />
                  <h3 className="font-semibold text-sm">Team</h3>
                  <p className="text-xs text-muted-foreground">Manage staff</p>
                </Card>
              </div>
            </div>

            {/* Recent Activity Feed */}
            <div className="lg:col-span-1">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-display text-xl font-bold">Recent Activity</h2>
                <Button variant="ghost" size="sm" onClick={() => navigate('/operator')}>
                  View all
                </Button>
              </div>
              
              <Card className="divide-y divide-border">
                {recentActivity.length > 0 ? (
                  recentActivity.map((activity) => (
                    <div key={activity.id} className="p-3 hover:bg-muted/50 transition-colors">
                      <div className="flex items-start gap-3">
                        <div className="mt-0.5">
                          {getActivityIcon(activity.type, activity.status)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-2">
                            <p className="text-sm font-medium truncate">{activity.title}</p>
                            {getStatusBadge(activity.status)}
                          </div>
                          <p className="text-xs text-muted-foreground truncate">{activity.description}</p>
                          <p className="text-xs text-muted-foreground/70 mt-1">
                            {formatDistanceToNow(new Date(activity.timestamp), { addSuffix: true })}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-6 text-center text-muted-foreground">
                    <Clock className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">No recent activity</p>
                    <p className="text-xs mt-1">New tow records and claims will appear here</p>
                  </div>
                )}
              </Card>
            </div>
          </div>
        </div>
      </main>

      <PageFooter />
    </div>
  );

  // If user is an operator, show operator homepage
  if (isOperator) {
    return <OperatorHomepage />;
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <PageHeader onSignInClick={() => setShowAuthModal(true)} />

      {/* Hero Section - Only show on idle/loading state */}
      {(status === 'idle' || status === 'loading') && (
        <section className="hero-gradient text-primary-foreground py-20 md:py-28 px-4 relative overflow-hidden">
          {/* Animated background elements */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute -top-40 -right-40 w-80 h-80 bg-accent/10 rounded-full blur-3xl animate-pulse-soft" />
            <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-info/10 rounded-full blur-3xl animate-pulse-soft" style={{ animationDelay: '1s' }} />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-radial from-accent/5 to-transparent rounded-full" />
          </div>
          
          <div className="max-w-4xl mx-auto text-center space-y-8 relative z-10">
            <div className="inline-flex items-center gap-2 bg-primary-foreground/10 backdrop-blur-sm px-5 py-2.5 rounded-full text-sm font-medium border border-primary-foreground/20 animate-fade-in">
              <Shield className="w-4 h-4 text-accent" />
              <span>Trusted by 50,000+ vehicle owners</span>
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-accent"></span>
              </span>
            </div>
            
            <h1 className="font-display text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold text-balance animate-slide-up">
              Find Your Towed Vehicle{' '}
              <span className="relative">
                <span className="text-accent">Instantly</span>
                <svg className="absolute -bottom-2 left-0 w-full h-3 text-accent/50" viewBox="0 0 200 12" preserveAspectRatio="none">
                  <path d="M0,8 Q50,0 100,8 T200,8" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                </svg>
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl text-primary-foreground/80 max-w-2xl mx-auto animate-slide-up leading-relaxed" style={{ animationDelay: '0.1s' }}>
              Enter your plate number or VIN and locate your vehicle in seconds. 
              No more endless phone calls to tow yards.
            </p>
            
            <div className="flex flex-wrap items-center justify-center gap-6 text-sm text-primary-foreground/70 animate-fade-in" style={{ animationDelay: '0.2s' }}>
              <span className="flex items-center gap-2 bg-primary-foreground/5 px-4 py-2 rounded-full backdrop-blur-sm">
                <Clock className="w-4 h-4 text-accent" /> Results in seconds
              </span>
              <span className="flex items-center gap-2 bg-primary-foreground/5 px-4 py-2 rounded-full backdrop-blur-sm">
                <MapPin className="w-4 h-4 text-accent" /> US & Canada coverage
              </span>
              <span className="flex items-center gap-2 bg-primary-foreground/5 px-4 py-2 rounded-full backdrop-blur-sm">
                <Shield className="w-4 h-4 text-accent" /> 500+ verified tow yards
              </span>
            </div>
          </div>
        </section>
      )}

      {/* Main Content */}
      <main className="flex-1">
        {/* Search Card - overlapping hero OR Results section */}
        {status === 'idle' || status === 'loading' ? (
          <div className="px-4 -mt-8 relative z-10 space-y-12">
            <LookupCard
              onPlateSearch={searchByPlate}
              onVINSearch={searchByVIN}
              isLoading={isLoading}
            />

            {/* Tow Truck Animation */}
            <div className="max-w-3xl mx-auto">
              <TowTruckAnimation />
            </div>
          </div>
        ) : status === 'found' && record ? (
          <div className="py-12 md:py-16 px-4 bg-gradient-to-b from-success/5 via-background to-background">
            <TowResult 
              record={record} 
              onClaimVehicle={handleClaimVehicle}
              onSearchAgain={reset}
            />
          </div>
        ) : (
          <div className="py-12 md:py-16 px-4">
            <NotFoundResult
              searchType={searchType || 'plate'}
              searchValue={searchValue || ''}
              onSearchAgain={reset}
            />
          </div>
        )}

        {/* Show additional content only on idle state */}
        {(status === 'idle' || status === 'loading') && (
          <>
            {/* How It Works Section */}
            <HeroDescription />

            {/* Animated Stats Section */}
            <AnimatedStats />
            <section className="py-20 md:py-28 px-4 bg-gradient-to-b from-background to-muted/30">
              <div className="max-w-5xl mx-auto">
                <div className="text-center mb-12 space-y-4">
                  <h2 className="font-display text-3xl md:text-4xl font-bold">What We Offer</h2>
                  <p className="text-lg text-muted-foreground max-w-xl mx-auto">Everything you need to recover your vehicle quickly and hassle-free</p>
                </div>
                <ImageCarousel />
              </div>
            </section>

            {/* CTA Section */}
            <section className="py-20 md:py-28 px-4 bg-gradient-to-br from-accent/5 via-background to-info/5 relative overflow-hidden">
              {/* Background elements */}
              <div className="absolute inset-0 overflow-hidden pointer-events-none">
                <div className="absolute top-0 left-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
                <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-info/10 rounded-full blur-3xl" />
              </div>
              
              <div className="max-w-4xl mx-auto text-center space-y-8 relative z-10">
                <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-balance">
                  Ready to Find Your Vehicle?
                </h2>
                <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
                  Join thousands of vehicle owners who've used TowTrace to locate their towed cars.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
                  <Button
                    size="lg"
                    className="text-lg px-8 py-6 shadow-lg hover:shadow-xl transition-shadow"
                    onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                  >
                    Search Now
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                  <Button asChild size="lg" variant="outline" className="text-lg px-8 py-6">
                    <Link to="/about">Learn More About Us</Link>
                  </Button>
                </div>
              </div>
            </section>
          </>
        )}
      </main>

      {/* Footer */}
      <PageFooter />

      {/* Welcome Hook Card */}
      <WelcomeCard />

      {/* Auth Modal */}
      <AuthModal 
        isOpen={showAuthModal} 
        onClose={() => setShowAuthModal(false)}
        onSuccess={handleAuthSuccess}
      />
    </div>
  );
}
