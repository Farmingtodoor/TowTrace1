import { Lock, LockOpen, Loader2, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { formatDistanceToNow } from 'date-fns';

interface LockStatus {
  locked: boolean;
  lockedByUserId?: string;
  lockedByName?: string;
  lockedAt?: string;
  isOwnLock: boolean;
}

interface RecordLockIndicatorProps {
  lockStatus: LockStatus;
  isLoading: boolean;
  onAcquireLock: () => Promise<boolean>;
  onReleaseLock: () => Promise<boolean>;
  variant?: 'badge' | 'button' | 'inline';
  showActions?: boolean;
}

export function RecordLockIndicator({
  lockStatus,
  isLoading,
  onAcquireLock,
  onReleaseLock,
  variant = 'badge',
  showActions = true,
}: RecordLockIndicatorProps) {
  const { locked, lockedByName, lockedAt, isOwnLock } = lockStatus;

  if (variant === 'badge') {
    if (!locked) {
      return showActions ? (
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="outline"
              size="sm"
              onClick={onAcquireLock}
              disabled={isLoading}
              className="gap-1.5"
            >
              {isLoading ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <LockOpen className="w-3.5 h-3.5" />
              )}
              <span className="hidden sm:inline">Start Working</span>
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>Lock this record to prevent others from editing</p>
          </TooltipContent>
        </Tooltip>
      ) : (
        <Badge variant="outline" className="gap-1">
          <LockOpen className="w-3 h-3" />
          Available
        </Badge>
      );
    }

    if (isOwnLock) {
      return (
        <div className="flex items-center gap-2">
          <Badge variant="default" className="gap-1 bg-success hover:bg-success">
            <Lock className="w-3 h-3" />
            You're working on this
          </Badge>
          {showActions && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onReleaseLock}
              disabled={isLoading}
              className="gap-1 text-xs"
            >
              {isLoading ? (
                <Loader2 className="w-3 h-3 animate-spin" />
              ) : (
                <LockOpen className="w-3 h-3" />
              )}
              Release
            </Button>
          )}
        </div>
      );
    }

    return (
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge variant="secondary" className="gap-1 bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400">
            <Lock className="w-3 h-3" />
            {lockedByName} is working
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          <p>
            Locked by {lockedByName}
            {lockedAt && (
              <span className="text-muted-foreground ml-1">
                ({formatDistanceToNow(new Date(lockedAt), { addSuffix: true })})
              </span>
            )}
          </p>
        </TooltipContent>
      </Tooltip>
    );
  }

  if (variant === 'inline') {
    if (!locked) {
      return (
        <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
          <LockOpen className="w-3 h-3" />
          Available
        </span>
      );
    }

    if (isOwnLock) {
      return (
        <span className="inline-flex items-center gap-1 text-xs text-success">
          <Lock className="w-3 h-3" />
          Locked by you
        </span>
      );
    }

    return (
      <span className="inline-flex items-center gap-1 text-xs text-amber-600 dark:text-amber-400">
        <Lock className="w-3 h-3" />
        {lockedByName}
      </span>
    );
  }

  // Button variant
  if (!locked) {
    return (
      <Button
        variant="outline"
        size="sm"
        onClick={onAcquireLock}
        disabled={isLoading}
        className="gap-2"
      >
        {isLoading ? (
          <Loader2 className="w-4 h-4 animate-spin" />
        ) : (
          <LockOpen className="w-4 h-4" />
        )}
        Start Working
      </Button>
    );
  }

  if (isOwnLock) {
    return (
      <Button
        variant="secondary"
        size="sm"
        onClick={onReleaseLock}
        disabled={isLoading}
        className="gap-2 bg-success/10 text-success hover:bg-success/20"
      >
        {isLoading ? (
          <Loader2 className="w-4 h-4 animate-spin" />
        ) : (
          <Lock className="w-4 h-4" />
        )}
        Release Lock
      </Button>
    );
  }

  return (
    <Button
      variant="secondary"
      size="sm"
      disabled
      className="gap-2 bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400"
    >
      <User className="w-4 h-4" />
      {lockedByName} is working
    </Button>
  );
}
