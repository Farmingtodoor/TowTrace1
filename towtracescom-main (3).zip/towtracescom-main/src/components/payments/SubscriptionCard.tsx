import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Check, Loader2 } from 'lucide-react';
import { useState } from 'react';
import { SUBSCRIPTION_TIERS, createSubscription, type SubscriptionPlan } from '@/lib/payments';

interface SubscriptionCardProps {
  plan: SubscriptionPlan;
  currentPlan: SubscriptionPlan | null;
  onSubscribe?: () => void;
}

export function SubscriptionCard({ plan, currentPlan, onSubscribe }: SubscriptionCardProps) {
  const [loading, setLoading] = useState(false);
  const tier = SUBSCRIPTION_TIERS[plan];
  const isCurrentPlan = currentPlan === plan;

  const handleSubscribe = async () => {
    setLoading(true);
    try {
      const url = await createSubscription(plan);
      if (url) {
        window.open(url, '_blank');
        onSubscribe?.();
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className={`relative ${isCurrentPlan ? 'border-primary ring-2 ring-primary' : ''}`}>
      {isCurrentPlan && (
        <Badge className="absolute -top-3 left-1/2 -translate-x-1/2">Current Plan</Badge>
      )}
      <CardHeader>
        <CardTitle className="text-xl">{tier.name}</CardTitle>
        <CardDescription>
          <span className="text-3xl font-bold text-foreground">${tier.price}</span>
          <span className="text-muted-foreground">/month</span>
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ul className="space-y-2">
          {tier.features.map((feature, index) => (
            <li key={index} className="flex items-center gap-2 text-sm">
              <Check className="w-4 h-4 text-primary shrink-0" />
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>
      <CardFooter>
        <Button
          className="w-full"
          variant={isCurrentPlan ? 'outline' : 'default'}
          disabled={loading || isCurrentPlan}
          onClick={handleSubscribe}
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Processing...
            </>
          ) : isCurrentPlan ? (
            'Current Plan'
          ) : (
            'Subscribe'
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}
