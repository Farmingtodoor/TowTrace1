import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { AlertTriangle, Upload, X, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

const disputeTypes = [
  { value: 'vehicle_damage', label: 'Vehicle Damage' },
  { value: 'property_damage', label: 'Property Damage (items inside vehicle)' },
  { value: 'missing_items', label: 'Missing Items' },
  { value: 'overcharge', label: 'Overcharge / Billing Issue' },
  { value: 'other', label: 'Other' },
] as const;

const formSchema = z.object({
  disputeType: z.enum(['vehicle_damage', 'property_damage', 'missing_items', 'overcharge', 'other'], {
    required_error: 'Please select a dispute type',
  }),
  description: z.string().min(20, 'Please provide at least 20 characters describing your dispute'),
});

type FormData = z.infer<typeof formSchema>;

interface DisputeFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  claimId: string;
  towRecordId: string;
  towYardId: string;
  onSuccess?: () => void;
}

export function DisputeForm({
  open,
  onOpenChange,
  claimId,
  towRecordId,
  towYardId,
  onSuccess,
}: DisputeFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [evidenceFiles, setEvidenceFiles] = useState<File[]>([]);
  const [uploading, setUploading] = useState(false);

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      description: '',
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const validFiles = files.filter(file => {
      if (file.size > 10 * 1024 * 1024) {
        toast.error(`${file.name} is too large. Max size is 10MB.`);
        return false;
      }
      return true;
    });
    setEvidenceFiles(prev => [...prev, ...validFiles]);
  };

  const removeFile = (index: number) => {
    setEvidenceFiles(prev => prev.filter((_, i) => i !== index));
  };

  const uploadEvidence = async (): Promise<string[]> => {
    if (evidenceFiles.length === 0) return [];
    
    setUploading(true);
    const urls: string[] = [];

    try {
      for (const file of evidenceFiles) {
        const fileExt = file.name.split('.').pop();
        const fileName = `${crypto.randomUUID()}.${fileExt}`;
        const filePath = `disputes/${claimId}/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('claim-documents')
          .upload(filePath, file);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('claim-documents')
          .getPublicUrl(filePath);

        urls.push(publicUrl);
      }
    } finally {
      setUploading(false);
    }

    return urls;
  };

  const onSubmit = async (data: FormData) => {
    setIsSubmitting(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast.error('You must be logged in to file a dispute');
        return;
      }

      // Upload evidence files first
      const evidenceUrls = await uploadEvidence();

      const { error } = await supabase
        .from('disputes')
        .insert({
          claim_id: claimId,
          tow_record_id: towRecordId,
          tow_yard_id: towYardId,
          consumer_user_id: user.id,
          dispute_type: data.disputeType,
          description: data.description,
          evidence_urls: evidenceUrls,
        });

      if (error) throw error;

      toast.success('Dispute filed successfully', {
        description: 'The tow company will review your dispute and respond.',
      });
      
      form.reset();
      setEvidenceFiles([]);
      onOpenChange(false);
      onSuccess?.();
    } catch (error: any) {
      console.error('Error filing dispute:', error);
      toast.error('Failed to file dispute', {
        description: error.message || 'Please try again later',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-warning" />
            File a Dispute
          </DialogTitle>
          <DialogDescription>
            Report any damage, missing items, or billing issues related to your vehicle.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="disputeType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Dispute Type</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select the type of dispute" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {disputeTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Describe the issue in detail. Include specific damages, missing items, or billing discrepancies..."
                      className="min-h-[120px] resize-none"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    Provide as much detail as possible to help resolve your dispute.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Evidence Upload */}
            <div className="space-y-2">
              <FormLabel>Evidence (Optional)</FormLabel>
              <div className="border-2 border-dashed border-border rounded-lg p-4 text-center">
                <input
                  type="file"
                  multiple
                  accept="image/*,.pdf"
                  onChange={handleFileChange}
                  className="hidden"
                  id="evidence-upload"
                />
                <label
                  htmlFor="evidence-upload"
                  className="cursor-pointer flex flex-col items-center gap-2"
                >
                  <Upload className="h-8 w-8 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">
                    Click to upload photos or documents
                  </span>
                  <span className="text-xs text-muted-foreground">
                    Max 10MB per file
                  </span>
                </label>
              </div>

              {evidenceFiles.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {evidenceFiles.map((file, index) => (
                    <div
                      key={index}
                      className="flex items-center gap-1 bg-muted px-2 py-1 rounded text-sm"
                    >
                      <span className="truncate max-w-[150px]">{file.name}</span>
                      <button
                        type="button"
                        onClick={() => removeFile(index)}
                        className="text-muted-foreground hover:text-destructive"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                disabled={isSubmitting}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting || uploading}>
                {isSubmitting || uploading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {uploading ? 'Uploading...' : 'Submitting...'}
                  </>
                ) : (
                  'Submit Dispute'
                )}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
