import { useState } from 'react';
import { format } from 'date-fns';
import {
  Eye,
  MoreVertical,
  Shield,
  Building2,
  UserX,
  Mail,
  Copy,
  Check,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useToast } from '@/hooks/use-toast';

export interface UserWithRole {
  id: string;
  email: string;
  created_at: string;
  roles: string[];
  full_name?: string;
}

interface UserManagementTableProps {
  users: UserWithRole[];
  onViewUser: (user: UserWithRole) => void;
  onAddRole: (userId: string, role: 'operator' | 'admin' | 'reviewer' | 'analyst' | 'super_admin') => void;
  onRemoveRole: (userId: string, role: 'consumer' | 'operator' | 'admin' | 'reviewer' | 'analyst' | 'super_admin') => void;
}

const roleVariants: Record<string, 'destructive' | 'default' | 'secondary' | 'outline'> = {
  super_admin: 'destructive',
  admin: 'destructive',
  reviewer: 'secondary',
  analyst: 'outline',
  operator: 'default',
  consumer: 'secondary',
};

export function UserManagementTable({ users, onViewUser, onAddRole, onRemoveRole }: UserManagementTableProps) {
  const { toast } = useToast();
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const copyToClipboard = (text: string, userId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(userId);
    toast({ title: 'Copied to clipboard' });
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getInitials = (email: string, name?: string) => {
    if (name) {
      return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
    }
    return email.slice(0, 2).toUpperCase();
  };

  return (
    <div className="bg-card rounded-xl shadow-card border overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/30 hover:bg-muted/30">
            <TableHead className="font-semibold">User</TableHead>
            <TableHead className="font-semibold">Roles</TableHead>
            <TableHead className="font-semibold">Joined</TableHead>
            <TableHead className="w-[100px] font-semibold">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {users.length === 0 ? (
            <TableRow>
              <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                No users found
              </TableCell>
            </TableRow>
          ) : (
            users.map((user) => (
              <TableRow key={user.id} className="group">
                <TableCell>
                  <div className="flex items-center gap-3">
                    <Avatar className="h-9 w-9 border">
                      <AvatarFallback className="bg-primary/10 text-primary text-sm font-medium">
                        {getInitials(user.email, user.full_name)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="min-w-0">
                      <p className="font-medium truncate">{user.full_name || user.email.split('@')[0]}</p>
                      <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex gap-1.5 flex-wrap">
                    {user.roles.length > 0 ? (
                      user.roles.map((role) => (
                        <Badge key={role} variant={roleVariants[role] || 'outline'} className="text-xs">
                          {role}
                        </Badge>
                      ))
                    ) : (
                      <Badge variant="outline" className="text-xs">consumer</Badge>
                    )}
                  </div>
                </TableCell>
                <TableCell className="text-muted-foreground text-sm">
                  {format(new Date(user.created_at), 'MMM d, yyyy')}
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => onViewUser(user)}
                    >
                      <Eye className="w-4 h-4" />
                    </Button>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-48">
                        <DropdownMenuItem onClick={() => onViewUser(user)}>
                          <Eye className="w-4 h-4 mr-2" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => copyToClipboard(user.email, user.id)}>
                          {copiedId === user.id ? (
                            <Check className="w-4 h-4 mr-2" />
                          ) : (
                            <Copy className="w-4 h-4 mr-2" />
                          )}
                          Copy Email
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => window.open(`mailto:${user.email}`)}>
                          <Mail className="w-4 h-4 mr-2" />
                          Send Email
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        {!user.roles.includes('operator') && (
                          <DropdownMenuItem onClick={() => onAddRole(user.id, 'operator')}>
                            <Building2 className="w-4 h-4 mr-2" />
                            Grant Operator Role
                          </DropdownMenuItem>
                        )}
                        {!user.roles.includes('reviewer') && (
                          <DropdownMenuItem onClick={() => onAddRole(user.id, 'reviewer')}>
                            <Shield className="w-4 h-4 mr-2" />
                            Grant Reviewer Role
                          </DropdownMenuItem>
                        )}
                        {!user.roles.includes('analyst') && (
                          <DropdownMenuItem onClick={() => onAddRole(user.id, 'analyst')}>
                            <Shield className="w-4 h-4 mr-2" />
                            Grant Analyst Role
                          </DropdownMenuItem>
                        )}
                        {!user.roles.includes('admin') && (
                          <DropdownMenuItem onClick={() => onAddRole(user.id, 'admin')}>
                            <Shield className="w-4 h-4 mr-2" />
                            Grant Admin Role
                          </DropdownMenuItem>
                        )}
                        {!user.roles.includes('super_admin') && (
                          <DropdownMenuItem onClick={() => onAddRole(user.id, 'super_admin')}>
                            <Shield className="w-4 h-4 mr-2" />
                            Grant Super Admin
                          </DropdownMenuItem>
                        )}
                        {user.roles.includes('operator') && (
                          <DropdownMenuItem
                            onClick={() => onRemoveRole(user.id, 'operator')}
                            className="text-warning"
                          >
                            <UserX className="w-4 h-4 mr-2" />
                            Remove Operator
                          </DropdownMenuItem>
                        )}
                        {user.roles.includes('reviewer') && (
                          <DropdownMenuItem
                            onClick={() => onRemoveRole(user.id, 'reviewer')}
                            className="text-warning"
                          >
                            <UserX className="w-4 h-4 mr-2" />
                            Remove Reviewer
                          </DropdownMenuItem>
                        )}
                        {user.roles.includes('analyst') && (
                          <DropdownMenuItem
                            onClick={() => onRemoveRole(user.id, 'analyst')}
                            className="text-warning"
                          >
                            <UserX className="w-4 h-4 mr-2" />
                            Remove Analyst
                          </DropdownMenuItem>
                        )}
                        {user.roles.includes('admin') && (
                          <DropdownMenuItem
                            onClick={() => onRemoveRole(user.id, 'admin')}
                            className="text-destructive"
                          >
                            <UserX className="w-4 h-4 mr-2" />
                            Remove Admin
                          </DropdownMenuItem>
                        )}
                        {user.roles.includes('super_admin') && (
                          <DropdownMenuItem
                            onClick={() => onRemoveRole(user.id, 'super_admin')}
                            className="text-destructive"
                          >
                            <UserX className="w-4 h-4 mr-2" />
                            Remove Super Admin
                          </DropdownMenuItem>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}
