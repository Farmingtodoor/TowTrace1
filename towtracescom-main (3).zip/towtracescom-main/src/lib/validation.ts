// Plate validation - allows alphanumeric, dashes, spaces
export function validatePlate(plate: string): { valid: boolean; message?: string } {
  const cleaned = plate.trim().toUpperCase();
  
  if (!cleaned) {
    return { valid: false, message: 'Please enter a license plate number' };
  }
  
  if (cleaned.length < 2) {
    return { valid: false, message: 'Plate number is too short' };
  }
  
  if (cleaned.length > 10) {
    return { valid: false, message: 'Plate number is too long' };
  }
  
  // Allow letters, numbers, dashes, and spaces
  const plateRegex = /^[A-Z0-9\s-]+$/;
  if (!plateRegex.test(cleaned)) {
    return { valid: false, message: 'Plate can only contain letters, numbers, dashes, and spaces' };
  }
  
  return { valid: true };
}

// VIN validation - 17 characters, excludes I, O, Q
export function validateVIN(vin: string): { valid: boolean; message?: string } {
  const cleaned = vin.trim().toUpperCase();
  
  if (!cleaned) {
    return { valid: false, message: 'Please enter a VIN' };
  }
  
  if (cleaned.length !== 17) {
    return { valid: false, message: `VIN must be exactly 17 characters (currently ${cleaned.length})` };
  }
  
  // VINs cannot contain I, O, or Q
  if (/[IOQ]/.test(cleaned)) {
    return { valid: false, message: 'VIN cannot contain letters I, O, or Q' };
  }
  
  // Must be alphanumeric only
  if (!/^[A-HJ-NPR-Z0-9]+$/.test(cleaned)) {
    return { valid: false, message: 'VIN can only contain letters and numbers' };
  }
  
  return { valid: true };
}

export function formatPlate(plate: string): string {
  return plate.trim().toUpperCase();
}

export function formatVIN(vin: string): string {
  return vin.trim().toUpperCase().replace(/[^A-HJ-NPR-Z0-9]/g, '');
}
