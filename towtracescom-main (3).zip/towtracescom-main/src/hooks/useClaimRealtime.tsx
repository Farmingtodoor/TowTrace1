import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { sendClaimStatusUpdate } from '@/lib/notifications';

interface ClaimRealtimeOptions {
  userId: string | undefined;
  userEmail: string | undefined;
  userName: string | undefined;
  onClaimUpdate?: () => void;
}

const statusLabels: Record<string, string> = {
  started: 'Documents Needed',
  docs_submitted: 'Under Review',
  docs_approved: 'Documents Approved',
  payment_pending: 'Payment Pending',
  complete: 'Complete',
};

export function useClaimRealtime({ userId, userEmail, userName, onClaimUpdate }: ClaimRealtimeOptions) {
  useEffect(() => {
    if (!userId) return;

    const channel = supabase
      .channel('claim-status-changes')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'claims',
          filter: `consumer_user_id=eq.${userId}`,
        },
        async (payload) => {
          const newStatus = payload.new.claim_status as string;
          const oldStatus = payload.old?.claim_status as string;

          // Only notify if status actually changed
          if (newStatus !== oldStatus) {
            const statusLabel = statusLabels[newStatus] || newStatus;
            
            // Show toast notification
            toast.info(`Claim status updated: ${statusLabel}`, {
              description: 'Your claim has been updated.',
              action: {
                label: 'View',
                onClick: () => window.location.href = '/my-claims',
              },
            });

            // Send email notification
            if (userEmail) {
              await sendClaimStatusUpdate(
                userEmail,
                userName || 'Customer',
                payload.new.id,
                statusLabel
              );
            }

            // Trigger refresh callback
            onClaimUpdate?.();
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [userId, userEmail, userName, onClaimUpdate]);
}
