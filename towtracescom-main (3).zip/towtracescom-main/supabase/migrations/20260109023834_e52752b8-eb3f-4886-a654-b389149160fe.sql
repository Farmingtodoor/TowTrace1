-- Fix infinite recursion in RLS policies and allow company self-registration

-- 1) Helper functions (SECURITY DEFINER) to avoid policy self-references
CREATE OR REPLACE FUNCTION public.is_tow_yard_operator(_user_id uuid, _tow_yard_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.tow_yard_operators tyo
    WHERE tyo.tow_yard_id = _tow_yard_id
      AND tyo.operator_user_id = _user_id
  );
$$;

CREATE OR REPLACE FUNCTION public.is_tow_yard_admin(_user_id uuid, _tow_yard_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.tow_yard_operators tyo
    WHERE tyo.tow_yard_id = _tow_yard_id
      AND tyo.operator_user_id = _user_id
      AND tyo.permission_level = 'admin'::public.employee_role
  );
$$;

-- 2) Ensure RLS is enabled (safe if already enabled)
ALTER TABLE public.tow_yard_operators ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tow_yards ENABLE ROW LEVEL SECURITY;

-- 3) Remove the self-referencing policy that causes infinite recursion
DROP POLICY IF EXISTS "Operators with admin permission can manage employees" ON public.tow_yard_operators;

-- 4) Allow authenticated users to submit tow yard applications (always unapproved)
DROP POLICY IF EXISTS "Authenticated users can submit tow yard applications" ON public.tow_yards;
CREATE POLICY "Authenticated users can submit tow yard applications"
ON public.tow_yards
FOR INSERT
TO authenticated
WITH CHECK (is_approved = false);

-- 5) Allow users to create their own initial operator assignment as a yard admin
DROP POLICY IF EXISTS "Users can self-assign as yard admin" ON public.tow_yard_operators;
CREATE POLICY "Users can self-assign as yard admin"
ON public.tow_yard_operators
FOR INSERT
TO authenticated
WITH CHECK (
  operator_user_id = auth.uid()
  AND permission_level = 'admin'::public.employee_role
);

-- 6) Allow yard admins (or app admins) to manage operator assignments without recursion
DROP POLICY IF EXISTS "Yard admins can update operator assignments" ON public.tow_yard_operators;
CREATE POLICY "Yard admins can update operator assignments"
ON public.tow_yard_operators
FOR UPDATE
TO authenticated
USING (
  public.is_tow_yard_admin(auth.uid(), tow_yard_id)
  OR has_role(auth.uid(), 'admin'::public.app_role)
)
WITH CHECK (
  public.is_tow_yard_admin(auth.uid(), tow_yard_id)
  OR has_role(auth.uid(), 'admin'::public.app_role)
);

DROP POLICY IF EXISTS "Yard admins can delete operator assignments" ON public.tow_yard_operators;
CREATE POLICY "Yard admins can delete operator assignments"
ON public.tow_yard_operators
FOR DELETE
TO authenticated
USING (
  public.is_tow_yard_admin(auth.uid(), tow_yard_id)
  OR has_role(auth.uid(), 'admin'::public.app_role)
);
