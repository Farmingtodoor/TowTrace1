-- Create storage bucket for claim documents
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'claim-documents',
  'claim-documents',
  false,
  10485760, -- 10MB limit
  ARRAY['image/jpeg', 'image/png', 'image/webp', 'application/pdf']
);

-- RLS policies for claim-documents bucket
-- Users can upload to their own claims folder
CREATE POLICY "Users can upload documents to their claims"
ON storage.objects
FOR INSERT
WITH CHECK (
  bucket_id = 'claim-documents'
  AND auth.uid() IS NOT NULL
  AND (storage.foldername(name))[1] = auth.uid()::text
);

-- Users can view their own documents
CREATE POLICY "Users can view their own documents"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'claim-documents'
  AND auth.uid() IS NOT NULL
  AND (storage.foldername(name))[1] = auth.uid()::text
);

-- Users can delete their own pending documents
CREATE POLICY "Users can delete their own documents"
ON storage.objects
FOR DELETE
USING (
  bucket_id = 'claim-documents'
  AND auth.uid() IS NOT NULL
  AND (storage.foldername(name))[1] = auth.uid()::text
);

-- Operators can view documents for claims in their yards
CREATE POLICY "Operators can view claim documents"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'claim-documents'
  AND EXISTS (
    SELECT 1 FROM public.tow_yard_operators tyo
    JOIN public.tow_records tr ON tr.tow_yard_id = tyo.tow_yard_id
    JOIN public.claims c ON c.tow_record_id = tr.id
    WHERE tyo.operator_user_id = auth.uid()
    AND (storage.foldername(name))[1] = c.consumer_user_id::text
  )
);

-- Admins can access all documents
CREATE POLICY "Admins can access all documents"
ON storage.objects
FOR ALL
USING (
  bucket_id = 'claim-documents'
  AND public.has_role(auth.uid(), 'admin')
);