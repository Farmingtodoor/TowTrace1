-- Enable realtime for claims table
ALTER PUBLICATION supabase_realtime ADD TABLE public.claims;