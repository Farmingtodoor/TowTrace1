-- Fix audit_logs RLS: Add INSERT policy and explicitly deny UPDATE/DELETE

-- Allow authenticated users to insert audit log entries
CREATE POLICY "Authenticated users can insert audit logs"
ON public.audit_logs
FOR INSERT
TO authenticated
WITH CHECK (true);

-- Explicitly deny all updates to maintain audit integrity
CREATE POLICY "No one can update audit logs"
ON public.audit_logs
FOR UPDATE
USING (false);

-- Explicitly deny all deletes to maintain audit integrity  
CREATE POLICY "No one can delete audit logs"
ON public.audit_logs
FOR DELETE
USING (false);