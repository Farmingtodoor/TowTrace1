
-- Create payout_requests table
CREATE TABLE public.payout_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tow_yard_id UUID NOT NULL REFERENCES public.tow_yards(id),
  requested_by_user_id UUID NOT NULL,
  amount NUMERIC NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  payout_method TEXT NOT NULL,
  notes TEXT,
  reviewed_by_user_id UUID,
  reviewed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.payout_requests ENABLE ROW LEVEL SECURITY;

-- Operators can view their yard's payout requests
CREATE POLICY "Operators can view their yard payout requests"
ON public.payout_requests FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM tow_yard_operators
    WHERE tow_yard_operators.tow_yard_id = payout_requests.tow_yard_id
      AND tow_yard_operators.operator_user_id = auth.uid()
  )
);

-- Yard admins can insert payout requests
CREATE POLICY "Yard admins can request payouts"
ON public.payout_requests FOR INSERT
WITH CHECK (
  requested_by_user_id = auth.uid() AND
  EXISTS (
    SELECT 1 FROM tow_yard_operators
    WHERE tow_yard_operators.tow_yard_id = payout_requests.tow_yard_id
      AND tow_yard_operators.operator_user_id = auth.uid()
      AND tow_yard_operators.permission_level = 'admin'::employee_role
  )
);

-- Admins can manage all payout requests
CREATE POLICY "Admins can manage all payout requests"
ON public.payout_requests FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

-- Trigger for updated_at
CREATE TRIGGER update_payout_requests_updated_at
BEFORE UPDATE ON public.payout_requests
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Enable realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.payout_requests;
