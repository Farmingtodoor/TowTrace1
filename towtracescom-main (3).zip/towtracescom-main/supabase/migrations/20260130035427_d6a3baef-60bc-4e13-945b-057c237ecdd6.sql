-- Add evidence request fields to disputes table
ALTER TABLE public.disputes 
ADD COLUMN evidence_requested BOOLEAN DEFAULT false,
ADD COLUMN evidence_request_notes TEXT,
ADD COLUMN evidence_requested_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN evidence_submitted_at TIMESTAMP WITH TIME ZONE;