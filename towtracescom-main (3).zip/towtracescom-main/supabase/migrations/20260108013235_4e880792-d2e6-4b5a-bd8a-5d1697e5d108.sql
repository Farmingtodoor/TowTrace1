-- Create app_role enum for user roles
CREATE TYPE public.app_role AS ENUM ('consumer', 'operator', 'admin');

-- Create tow_status enum
CREATE TYPE public.tow_status AS ENUM ('towed', 'docs_pending', 'docs_approved', 'paid', 'released');

-- Create claim_status enum  
CREATE TYPE public.claim_status AS ENUM ('started', 'docs_submitted', 'docs_approved', 'payment_pending', 'complete');

-- Create doc_status enum
CREATE TYPE public.doc_status AS ENUM ('pending', 'approved', 'rejected');

-- Create doc_type enum
CREATE TYPE public.doc_type AS ENUM ('gov_id', 'registration', 'title', 'insurance', 'authorization');

-- Create payment_status enum
CREATE TYPE public.payment_status AS ENUM ('initiated', 'succeeded', 'failed', 'refunded');

-- ===============================
-- PROFILES TABLE (user data)
-- ===============================
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  email TEXT,
  phone TEXT,
  full_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own profile"
  ON public.profiles FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own profile"
  ON public.profiles FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- ===============================
-- USER ROLES TABLE (security)
-- ===============================
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  UNIQUE (user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Security definer function to check roles (avoids RLS recursion)
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

CREATE POLICY "Users can view their own roles"
  ON public.user_roles FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage all roles"
  ON public.user_roles FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- ===============================
-- TOW YARDS TABLE
-- ===============================
CREATE TABLE public.tow_yards (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  address TEXT NOT NULL,
  city TEXT NOT NULL,
  state_province TEXT NOT NULL,
  country TEXT NOT NULL CHECK (country IN ('US', 'CA')),
  postal_code TEXT,
  phone TEXT NOT NULL,
  email TEXT,
  hours_json JSONB DEFAULT '{}',
  allows_in_app_payment BOOLEAN DEFAULT false,
  accepted_payment_methods TEXT[] DEFAULT ARRAY['Cash', 'Credit Card'],
  is_approved BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

ALTER TABLE public.tow_yards ENABLE ROW LEVEL SECURITY;

-- Anyone can view approved tow yards
CREATE POLICY "Anyone can view approved tow yards"
  ON public.tow_yards FOR SELECT
  USING (is_approved = true);

-- Admins can manage all tow yards
CREATE POLICY "Admins can manage all tow yards"
  ON public.tow_yards FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- ===============================
-- TOW YARD OPERATORS (junction table)
-- ===============================
CREATE TABLE public.tow_yard_operators (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tow_yard_id UUID REFERENCES public.tow_yards(id) ON DELETE CASCADE NOT NULL,
  operator_user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  UNIQUE (tow_yard_id, operator_user_id)
);

ALTER TABLE public.tow_yard_operators ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Operators can view their assignments"
  ON public.tow_yard_operators FOR SELECT
  USING (operator_user_id = auth.uid());

CREATE POLICY "Admins can manage operator assignments"
  ON public.tow_yard_operators FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- Add operator policies to tow_yards now that tow_yard_operators exists
CREATE POLICY "Operators can view assigned yards"
  ON public.tow_yards FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.tow_yard_operators
      WHERE tow_yard_id = tow_yards.id
      AND operator_user_id = auth.uid()
    )
  );

CREATE POLICY "Operators can update assigned yards"
  ON public.tow_yards FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.tow_yard_operators
      WHERE tow_yard_id = tow_yards.id
      AND operator_user_id = auth.uid()
    )
  );

-- ===============================
-- TOW RECORDS TABLE
-- ===============================
CREATE TABLE public.tow_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tow_yard_id UUID REFERENCES public.tow_yards(id) ON DELETE CASCADE NOT NULL,
  plate_number TEXT,
  plate_state_province TEXT,
  country TEXT CHECK (country IN ('US', 'CA')),
  vin TEXT,
  make TEXT,
  model TEXT,
  color TEXT,
  tow_datetime TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  tow_reason TEXT,
  tow_from_address TEXT,
  status tow_status DEFAULT 'towed' NOT NULL,
  tow_fee DECIMAL(10,2) DEFAULT 0 NOT NULL,
  daily_storage_fee DECIMAL(10,2) DEFAULT 0 NOT NULL,
  admin_fee DECIMAL(10,2) DEFAULT 0 NOT NULL,
  gate_fee DECIMAL(10,2) DEFAULT 0 NOT NULL,
  currency TEXT DEFAULT 'USD' CHECK (currency IN ('USD', 'CAD')),
  storage_start_datetime TIMESTAMP WITH TIME ZONE DEFAULT now(),
  release_requirements TEXT[] DEFAULT ARRAY['Valid government-issued photo ID', 'Vehicle registration or title', 'Proof of insurance', 'Payment in full'],
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

ALTER TABLE public.tow_records ENABLE ROW LEVEL SECURITY;

-- Anyone can search tow records (core feature - public lookup)
CREATE POLICY "Anyone can search tow records"
  ON public.tow_records FOR SELECT
  USING (true);

-- Operators can manage records for their tow yards
CREATE POLICY "Operators can insert records for their yards"
  ON public.tow_records FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.tow_yard_operators
      WHERE tow_yard_id = tow_records.tow_yard_id
      AND operator_user_id = auth.uid()
    )
  );

CREATE POLICY "Operators can update records for their yards"
  ON public.tow_records FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.tow_yard_operators
      WHERE tow_yard_id = tow_records.tow_yard_id
      AND operator_user_id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage all tow records"
  ON public.tow_records FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- ===============================
-- CLAIMS TABLE
-- ===============================
CREATE TABLE public.claims (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tow_record_id UUID REFERENCES public.tow_records(id) ON DELETE CASCADE NOT NULL,
  consumer_user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  claim_status claim_status DEFAULT 'started' NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  UNIQUE (tow_record_id, consumer_user_id)
);

ALTER TABLE public.claims ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Consumers can view their own claims"
  ON public.claims FOR SELECT
  USING (consumer_user_id = auth.uid());

CREATE POLICY "Consumers can create claims"
  ON public.claims FOR INSERT
  WITH CHECK (consumer_user_id = auth.uid());

CREATE POLICY "Consumers can update their own claims"
  ON public.claims FOR UPDATE
  USING (consumer_user_id = auth.uid());

CREATE POLICY "Operators can view claims for their yards"
  ON public.claims FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.tow_records tr
      JOIN public.tow_yard_operators tyo ON tr.tow_yard_id = tyo.tow_yard_id
      WHERE tr.id = claims.tow_record_id
      AND tyo.operator_user_id = auth.uid()
    )
  );

CREATE POLICY "Operators can update claims for their yards"
  ON public.claims FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.tow_records tr
      JOIN public.tow_yard_operators tyo ON tr.tow_yard_id = tyo.tow_yard_id
      WHERE tr.id = claims.tow_record_id
      AND tyo.operator_user_id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage all claims"
  ON public.claims FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- ===============================
-- DOCUMENTS TABLE
-- ===============================
CREATE TABLE public.documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id UUID REFERENCES public.claims(id) ON DELETE CASCADE NOT NULL,
  doc_type doc_type NOT NULL,
  file_url TEXT NOT NULL,
  file_name TEXT,
  status doc_status DEFAULT 'pending' NOT NULL,
  reviewer_user_id UUID REFERENCES auth.users(id),
  rejection_reason TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Consumers can view their own documents"
  ON public.documents FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.claims
      WHERE claims.id = documents.claim_id
      AND claims.consumer_user_id = auth.uid()
    )
  );

CREATE POLICY "Consumers can upload documents"
  ON public.documents FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.claims
      WHERE claims.id = documents.claim_id
      AND claims.consumer_user_id = auth.uid()
    )
  );

CREATE POLICY "Operators can view documents for their yards"
  ON public.documents FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.claims c
      JOIN public.tow_records tr ON c.tow_record_id = tr.id
      JOIN public.tow_yard_operators tyo ON tr.tow_yard_id = tyo.tow_yard_id
      WHERE c.id = documents.claim_id
      AND tyo.operator_user_id = auth.uid()
    )
  );

CREATE POLICY "Operators can update documents for their yards"
  ON public.documents FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.claims c
      JOIN public.tow_records tr ON c.tow_record_id = tr.id
      JOIN public.tow_yard_operators tyo ON tr.tow_yard_id = tyo.tow_yard_id
      WHERE c.id = documents.claim_id
      AND tyo.operator_user_id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage all documents"
  ON public.documents FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- ===============================
-- PAYMENTS TABLE
-- ===============================
CREATE TABLE public.payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id UUID REFERENCES public.claims(id) ON DELETE CASCADE NOT NULL,
  tow_record_id UUID REFERENCES public.tow_records(id) ON DELETE CASCADE NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  currency TEXT DEFAULT 'USD' CHECK (currency IN ('USD', 'CAD')),
  status payment_status DEFAULT 'initiated' NOT NULL,
  provider TEXT DEFAULT 'stripe',
  provider_ref TEXT,
  receipt_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Consumers can view their own payments"
  ON public.payments FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.claims
      WHERE claims.id = payments.claim_id
      AND claims.consumer_user_id = auth.uid()
    )
  );

CREATE POLICY "Operators can view payments for their yards"
  ON public.payments FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.tow_records tr
      JOIN public.tow_yard_operators tyo ON tr.tow_yard_id = tyo.tow_yard_id
      WHERE tr.id = payments.tow_record_id
      AND tyo.operator_user_id = auth.uid()
    )
  );

CREATE POLICY "Admins can manage all payments"
  ON public.payments FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- ===============================
-- AUDIT LOGS TABLE
-- ===============================
CREATE TABLE public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_user_id UUID REFERENCES auth.users(id),
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id UUID,
  metadata_json JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL
);

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins can view all audit logs"
  ON public.audit_logs FOR SELECT
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Anyone can insert audit logs"
  ON public.audit_logs FOR INSERT
  WITH CHECK (true);

-- ===============================
-- HELPER FUNCTIONS & TRIGGERS
-- ===============================

CREATE OR REPLACE FUNCTION public.calculate_total_due(record_id UUID)
RETURNS DECIMAL(10,2)
LANGUAGE plpgsql
STABLE
SET search_path = public
AS $$
DECLARE
  total DECIMAL(10,2);
  days_stored INTEGER;
  rec RECORD;
BEGIN
  SELECT * INTO rec FROM public.tow_records WHERE id = record_id;
  IF NOT FOUND THEN RETURN 0; END IF;
  days_stored := GREATEST(1, CEIL(EXTRACT(EPOCH FROM (now() - rec.storage_start_datetime)) / 86400));
  total := rec.tow_fee + (rec.daily_storage_fee * days_stored) + rec.admin_fee + rec.gate_fee;
  RETURN total;
END;
$$;

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_tow_yards_updated_at BEFORE UPDATE ON public.tow_yards FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_tow_records_updated_at BEFORE UPDATE ON public.tow_records FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_claims_updated_at BEFORE UPDATE ON public.claims FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_documents_updated_at BEFORE UPDATE ON public.documents FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_payments_updated_at BEFORE UPDATE ON public.payments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (user_id, email, phone)
  VALUES (NEW.id, NEW.email, NEW.phone);
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'consumer');
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();