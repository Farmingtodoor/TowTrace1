import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "https://esm.sh/resend@2.0.0";
import { checkRateLimit, getRateLimitIdentifier, rateLimitExceededResponse } from "../_shared/rate-limit.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

interface ResendInvitationRequest {
  userId: string;
  towYardId: string;
  towYardName: string;
  inviterName: string;
}

const escapeHtml = (text: string): string => {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
};

serve(async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const resendApiKey = Deno.env.get("RESEND_API_KEY");

    if (!resendApiKey) {
      throw new Error("RESEND_API_KEY not configured");
    }

    // Verify the caller is authenticated
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("Missing authorization header");
    }

    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    // Verify caller's session
    const supabaseClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user: callerUser }, error: authError } = await supabaseClient.auth.getUser();
    if (authError || !callerUser) {
      throw new Error("Unauthorized");
    }

    // Rate limiting check
    const identifier = getRateLimitIdentifier(req, callerUser.id);
    const { allowed, retryAfter } = checkRateLimit(identifier, "email");
    
    if (!allowed) {
      return rateLimitExceededResponse(retryAfter, corsHeaders);
    }

    const { userId, towYardId, towYardName, inviterName }: ResendInvitationRequest = await req.json();

    if (!userId || !towYardId) {
      throw new Error("Missing required fields: userId, towYardId");
    }

    // Check if caller has permission to resend invitations
    const { data: isYardAdmin } = await supabaseAdmin.rpc("is_tow_yard_admin", {
      _user_id: callerUser.id,
      _tow_yard_id: towYardId,
    });

    const { data: isSystemAdmin } = await supabaseAdmin.rpc("has_role", {
      _user_id: callerUser.id,
      _role: "admin",
    });

    if (!isYardAdmin && !isSystemAdmin) {
      throw new Error("You don't have permission to resend invitations");
    }

    // Get the user's info
    const { data: userData, error: userError } = await supabaseAdmin.auth.admin.getUserById(userId);
    if (userError || !userData.user) {
      throw new Error("User not found");
    }

    const targetUser = userData.user;
    const email = targetUser.email;
    const fullName = targetUser.user_metadata?.full_name || email?.split("@")[0] || "";

    if (!email) {
      throw new Error("User has no email address");
    }

    // Check if user has already confirmed their email
    if (targetUser.email_confirmed_at) {
      throw new Error("This user has already set up their account");
    }

    // Generate a new password reset link
    const siteUrl = req.headers.get("origin") || "https://towtracescom.lovable.app";
    const { data: resetData, error: resetError } = await supabaseAdmin.auth.admin.generateLink({
      type: "recovery",
      email: email,
      options: {
        redirectTo: `${siteUrl}/setup-account`,
      },
    });

    if (resetError) {
      throw new Error(`Failed to generate invite link: ${resetError.message}`);
    }

    const inviteLink = resetData.properties.action_link;

    // Send the invitation email
    const resend = new Resend(resendApiKey);

    // TODO: Replace with your verified domain from resend.com/domains
    await resend.emails.send({
      from: "TowTrace <noreply@resend.dev>",
      to: [email],
      subject: `Reminder: Set up your TowTrace account for ${escapeHtml(towYardName)}`,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background: linear-gradient(135deg, #0d9488 0%, #14b8a6 100%); padding: 30px; border-radius: 12px 12px 0 0; text-align: center;">
            <h1 style="color: white; margin: 0; font-size: 24px;">Reminder: Complete Your Setup</h1>
          </div>
          <div style="background: #f9fafb; padding: 30px; border-radius: 0 0 12px 12px;">
            <p style="font-size: 16px;">Hi${fullName ? ` <strong>${escapeHtml(fullName)}</strong>` : ''},</p>
            <p style="font-size: 16px;">
              This is a reminder that <strong>${escapeHtml(inviterName)}</strong> invited you to join 
              <strong>${escapeHtml(towYardName)}</strong> on TowTrace.
            </p>
            <p style="font-size: 16px;">Click the button below to set up your account and get started:</p>
            <div style="text-align: center; margin: 30px 0;">
              <a href="${inviteLink}" 
                 style="display: inline-block; background: #0d9488; color: white; padding: 14px 32px; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 16px;">
                Set Up Your Account
              </a>
            </div>
            <p style="font-size: 14px; color: #6b7280;">
              This link will expire in 24 hours. If you didn't expect this invitation, you can safely ignore this email.
            </p>
            <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 24px 0;">
            <p style="font-size: 12px; color: #9ca3af; text-align: center;">
              TowTrace - Connecting Tow Companies with Vehicle Owners
            </p>
          </div>
        </body>
        </html>
      `,
    });

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: "Invitation resent! The employee will receive a new email to set up their account."
      }),
      {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  } catch (error: any) {
    console.error("Error in resend-invitation function:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 400,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
});
