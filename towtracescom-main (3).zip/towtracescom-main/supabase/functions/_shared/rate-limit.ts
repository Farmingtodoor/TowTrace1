/**
 * Shared rate limiting utility for edge functions
 * Uses in-memory storage (resets on cold start)
 */

// Rate limit configuration by function type
export const RATE_LIMITS = {
  // High-value operations (payments, subscriptions)
  payment: { windowMs: 60000, maxRequests: 5 },
  subscription: { windowMs: 60000, maxRequests: 5 },
  
  // User management operations
  invite: { windowMs: 60000, maxRequests: 10 },
  registration: { windowMs: 300000, maxRequests: 3 }, // 5 min window
  
  // Email operations
  email: { windowMs: 60000, maxRequests: 10 },
  
  // General authenticated operations
  authenticated: { windowMs: 60000, maxRequests: 30 },
  
  // Public/anonymous operations
  anonymous: { windowMs: 60000, maxRequests: 5 },
} as const;

export type RateLimitType = keyof typeof RATE_LIMITS;

interface RateLimitEntry {
  count: number;
  windowStart: number;
}

// In-memory store (per isolate)
const rateLimitStore = new Map<string, RateLimitEntry>();

// Cleanup threshold
const MAX_STORE_SIZE = 10000;

/**
 * Check if a request is within rate limits
 * @param identifier - Unique identifier (userId, IP, or combination)
 * @param limitType - Type of rate limit to apply
 * @returns Object with allowed status and remaining requests
 */
export function checkRateLimit(
  identifier: string,
  limitType: RateLimitType
): { allowed: boolean; remaining: number; retryAfter?: number } {
  const now = Date.now();
  const config = RATE_LIMITS[limitType];
  const key = `${limitType}:${identifier}`;
  
  // Cleanup old entries periodically
  if (rateLimitStore.size > MAX_STORE_SIZE) {
    cleanupExpiredEntries(now);
  }
  
  const entry = rateLimitStore.get(key);
  
  // New window or expired window
  if (!entry || now - entry.windowStart > config.windowMs) {
    rateLimitStore.set(key, { count: 1, windowStart: now });
    return { allowed: true, remaining: config.maxRequests - 1 };
  }
  
  // Check if limit exceeded
  if (entry.count >= config.maxRequests) {
    const retryAfter = Math.ceil((entry.windowStart + config.windowMs - now) / 1000);
    return { allowed: false, remaining: 0, retryAfter };
  }
  
  // Increment counter
  entry.count++;
  return { allowed: true, remaining: config.maxRequests - entry.count };
}

/**
 * Get rate limit identifier from request
 * @param req - Request object
 * @param userId - Optional authenticated user ID
 * @returns Identifier string
 */
export function getRateLimitIdentifier(req: Request, userId?: string | null): string {
  if (userId) {
    return userId;
  }
  
  // Fall back to IP address for anonymous requests
  const forwardedFor = req.headers.get("x-forwarded-for");
  const ip = forwardedFor?.split(",")[0]?.trim() || "unknown";
  return `ip:${ip}`;
}

/**
 * Create a rate limit exceeded response
 * @param retryAfter - Seconds until the limit resets
 * @param corsHeaders - CORS headers to include
 * @returns Response object
 */
export function rateLimitExceededResponse(
  retryAfter: number = 60,
  corsHeaders: Record<string, string>
): Response {
  return new Response(
    JSON.stringify({ 
      error: "Rate limit exceeded. Please try again later.",
      retryAfter 
    }),
    {
      status: 429,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json",
        "X-RateLimit-Remaining": "0",
        "Retry-After": String(retryAfter),
      },
    }
  );
}

/**
 * Clean up expired entries from the store
 */
function cleanupExpiredEntries(now: number): void {
  const maxAge = Math.max(...Object.values(RATE_LIMITS).map(c => c.windowMs));
  
  for (const [key, value] of rateLimitStore.entries()) {
    if (now - value.windowStart > maxAge) {
      rateLimitStore.delete(key);
    }
  }
}
