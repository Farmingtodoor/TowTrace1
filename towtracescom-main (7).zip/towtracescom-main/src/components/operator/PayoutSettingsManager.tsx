import { useState, useEffect } from 'react';
import { 
  Building2, 
  CreditCard, 
  Wallet, 
  Smartphone,
  Save,
  CheckCircle,
  AlertCircle,
  Loader2,
  ExternalLink,
  ArrowUpRight,
  Clock,
  XCircle,
  History,
  TrendingUp,
  DollarSign,
  ArrowDownRight,
  RefreshCw,
  Zap,
  Shield,
  ChevronRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAuth } from '@/hooks/useAuth';
import { format } from 'date-fns';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell,
  PieChart,
  Pie,
} from 'recharts';

interface PayoutRequest {
  id: string;
  amount: number;
  status: string;
  payout_method: string;
  notes: string | null;
  created_at: string;
  completed_at?: string | null;
  reviewed_at?: string | null;
}

interface PayoutSettingsManagerProps {
  towYardId: string | null;
}

interface PayoutSettings {
  id?: string;
  tow_yard_id: string;
  payout_method: string;
  bank_name: string | null;
  bank_account_number: string | null;
  bank_routing_number: string | null;
  bank_account_holder_name: string | null;
  stripe_account_id: string | null;
  stripe_connected: boolean;
  paypal_email: string | null;
  apple_pay_merchant_id: string | null;
  minimum_payout_amount: number;
  payout_frequency: string;
  is_verified: boolean;
}

interface BalanceBreakdown {
  grossEarnings: number;
  serviceFees: number;
  completedPayouts: number;
  pendingPayouts: number;
  approvedPayouts: number;
  netAvailable: number;
}

interface EarningsDataPoint {
  date: string;
  earnings: number;
  payouts: number;
}

const maskAccountNumber = (value: string | null): string => {
  if (!value || value.length < 4) return value || '';
  return '••••' + value.slice(-4);
};

const maskRoutingNumber = (value: string | null): string => {
  if (!value || value.length < 4) return value || '';
  return '•••••' + value.slice(-4);
};

const PAYOUT_METHODS = [
  { value: 'bank_account', label: 'Bank Account', icon: Building2, description: 'Direct bank transfer (ACH)' },
  { value: 'stripe', label: 'Stripe Connect', icon: CreditCard, description: 'Automated payouts via Stripe' },
  { value: 'paypal', label: 'PayPal', icon: Wallet, description: 'Receive funds to PayPal account' },
  { value: 'apple_pay', label: 'Apple Pay', icon: Smartphone, description: 'Apple Pay merchant payouts' },
];

const PAYOUT_FREQUENCIES = [
  { value: 'daily', label: 'Daily' },
  { value: 'weekly', label: 'Weekly' },
  { value: 'biweekly', label: 'Bi-weekly' },
  { value: 'monthly', label: 'Monthly' },
];

const CONNECT_STEPS = [
  { id: 'select', label: 'Select Stripe', description: 'Choose Stripe Connect as your payout method' },
  { id: 'create', label: 'Create Account', description: 'Set up your Stripe Express account' },
  { id: 'verify', label: 'Verify Identity', description: 'Submit business and identity details' },
  { id: 'active', label: 'Start Receiving', description: 'Payouts flow automatically' },
];

const formatCurrency = (amount: number) =>
  new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);

export function PayoutSettingsManager({ towYardId }: PayoutSettingsManagerProps) {
  const { user } = useAuth();
  const [settings, setSettings] = useState<PayoutSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [balanceBreakdown, setBalanceBreakdown] = useState<BalanceBreakdown>({
    grossEarnings: 0, serviceFees: 0, completedPayouts: 0,
    pendingPayouts: 0, approvedPayouts: 0, netAvailable: 0,
  });
  const [balanceLoading, setBalanceLoading] = useState(true);
  const [payoutRequests, setPayoutRequests] = useState<PayoutRequest[]>([]);
  const [requestingPayout, setRequestingPayout] = useState(false);
  const [payoutAmount, setPayoutAmount] = useState('');
  const [payoutNotes, setPayoutNotes] = useState('');
  const [showRequestForm, setShowRequestForm] = useState(false);
  const [connectLoading, setConnectLoading] = useState(false);
  const [connectStatus, setConnectStatus] = useState<{
    chargesEnabled?: boolean;
    payoutsEnabled?: boolean;
    detailsSubmitted?: boolean;
    isFullyOnboarded?: boolean;
  } | null>(null);
  const [editingAccountNumber, setEditingAccountNumber] = useState(false);
  const [editingRoutingNumber, setEditingRoutingNumber] = useState(false);
  const [originalAccountNumber, setOriginalAccountNumber] = useState<string | null>(null);
  const [originalRoutingNumber, setOriginalRoutingNumber] = useState<string | null>(null);
  const [earningsData, setEarningsData] = useState<EarningsDataPoint[]>([]);
  const [activeSubTab, setActiveSubTab] = useState('overview');

  useEffect(() => {
    if (!towYardId) return;
    fetchSettings();
    fetchSmartBalance();
    fetchPayoutRequests();
    fetchEarningsHistory();
  }, [towYardId]);

  useEffect(() => {
    if (settings?.stripe_account_id && towYardId) {
      checkConnectStatus();
    }
  }, [settings?.stripe_account_id]);

  const checkConnectStatus = async () => {
    if (!towYardId) return;
    try {
      const { data, error } = await supabase.functions.invoke('create-connect-account', {
        body: { towYardId, action: 'check_status' },
      });
      if (error) throw error;
      setConnectStatus(data);
      if (data.isFullyOnboarded && settings) {
        setSettings({ ...settings, stripe_connected: true, is_verified: true });
      }
    } catch (err) {
      console.error('Error checking connect status:', err);
    }
  };

  const handleConnectStripe = async () => {
    if (!towYardId) return;
    setConnectLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('create-connect-account', {
        body: { towYardId, action: 'onboard' },
      });
      if (error) throw error;
      if (data?.url) {
        window.location.href = data.url;
      }
    } catch (err: any) {
      console.error('Connect error:', err);
      toast.error('Failed to start Stripe Connect onboarding');
    } finally {
      setConnectLoading(false);
    }
  };

  const fetchSmartBalance = async () => {
    if (!towYardId) return;
    setBalanceLoading(true);
    try {
      const { data: yardRecords } = await supabase
        .from('tow_records')
        .select('id')
        .eq('tow_yard_id', towYardId);

      const recordIds = yardRecords?.map(r => r.id) || [];

      let grossEarnings = 0;
      let serviceFees = 0;

      if (recordIds.length > 0) {
        const { data: payments } = await supabase
          .from('payments')
          .select('amount, service_fee')
          .eq('status', 'succeeded')
          .in('tow_record_id', recordIds);

        grossEarnings = payments?.reduce((sum, p) => sum + Number(p.amount || 0), 0) || 0;
        serviceFees = payments?.reduce((sum, p) => sum + Number(p.service_fee || 0), 0) || 0;
      }

      // Fetch payout requests
      const { data: payouts } = await supabase
        .from('payout_requests')
        .select('amount, status')
        .eq('tow_yard_id', towYardId);

      const completedPayouts = payouts?.filter(p => p.status === 'completed').reduce((s, p) => s + Number(p.amount), 0) || 0;
      const pendingPayouts = payouts?.filter(p => p.status === 'pending').reduce((s, p) => s + Number(p.amount), 0) || 0;
      const approvedPayouts = payouts?.filter(p => p.status === 'approved').reduce((s, p) => s + Number(p.amount), 0) || 0;

      const netAvailable = grossEarnings - serviceFees - completedPayouts - pendingPayouts - approvedPayouts;

      setBalanceBreakdown({
        grossEarnings,
        serviceFees,
        completedPayouts,
        pendingPayouts,
        approvedPayouts,
        netAvailable: Math.max(0, netAvailable),
      });
    } catch (err) {
      console.error('Error fetching balance:', err);
    } finally {
      setBalanceLoading(false);
    }
  };

  const fetchEarningsHistory = async () => {
    if (!towYardId) return;
    try {
      const { data: yardRecords } = await supabase
        .from('tow_records')
        .select('id')
        .eq('tow_yard_id', towYardId);

      const recordIds = yardRecords?.map(r => r.id) || [];
      if (recordIds.length === 0) return;

      const { data: payments } = await supabase
        .from('payments')
        .select('amount, service_fee, created_at')
        .eq('status', 'succeeded')
        .in('tow_record_id', recordIds)
        .order('created_at', { ascending: true });

      const { data: payouts } = await supabase
        .from('payout_requests')
        .select('amount, created_at, status')
        .eq('tow_yard_id', towYardId)
        .in('status', ['completed', 'approved'])
        .order('created_at', { ascending: true });

      // Group by day
      const dailyMap = new Map<string, { earnings: number; payouts: number }>();

      payments?.forEach(p => {
        const day = format(new Date(p.created_at), 'MMM d');
        const existing = dailyMap.get(day) || { earnings: 0, payouts: 0 };
        existing.earnings += Number(p.amount || 0) - Number(p.service_fee || 0);
        dailyMap.set(day, existing);
      });

      payouts?.forEach(p => {
        const day = format(new Date(p.created_at), 'MMM d');
        const existing = dailyMap.get(day) || { earnings: 0, payouts: 0 };
        existing.payouts += Number(p.amount || 0);
        dailyMap.set(day, existing);
      });

      setEarningsData(
        Array.from(dailyMap.entries())
          .slice(-30)
          .map(([date, data]) => ({ date, ...data }))
      );
    } catch (err) {
      console.error('Error fetching earnings history:', err);
    }
  };

  const fetchPayoutRequests = async () => {
    if (!towYardId) return;
    const { data } = await supabase
      .from('payout_requests')
      .select('id, amount, status, payout_method, notes, created_at, completed_at, reviewed_at')
      .eq('tow_yard_id', towYardId)
      .order('created_at', { ascending: false })
      .limit(20);
    setPayoutRequests((data as PayoutRequest[]) || []);
  };

  const handleRequestPayout = async () => {
    if (!towYardId || !user || !settings) return;
    const amount = parseFloat(payoutAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }
    if (amount > balanceBreakdown.netAvailable) {
      toast.error('Amount exceeds available balance');
      return;
    }
    if (amount < (settings.minimum_payout_amount || 0)) {
      toast.error(`Minimum payout amount is ${formatCurrency(settings.minimum_payout_amount)}`);
      return;
    }
    setRequestingPayout(true);
    try {
      const { error } = await supabase.from('payout_requests').insert({
        tow_yard_id: towYardId,
        requested_by_user_id: user.id,
        amount,
        payout_method: settings.payout_method,
        notes: payoutNotes || null,
      });
      if (error) throw error;
      toast.success(`Payout request for ${formatCurrency(amount)} submitted`);
      setPayoutAmount('');
      setPayoutNotes('');
      setShowRequestForm(false);
      fetchPayoutRequests();
      fetchSmartBalance();
    } catch (err: any) {
      console.error('Payout request error:', err);
      toast.error('Failed to submit payout request');
    } finally {
      setRequestingPayout(false);
    }
  };

  const fetchSettings = async () => {
    if (!towYardId) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('payout_settings')
      .select('*')
      .eq('tow_yard_id', towYardId)
      .maybeSingle();

    if (error) console.error('Error fetching payout settings:', error);

    if (data) {
      setSettings(data);
      setOriginalAccountNumber(data.bank_account_number);
      setOriginalRoutingNumber(data.bank_routing_number);
    } else {
      setSettings({
        tow_yard_id: towYardId,
        payout_method: 'bank_account',
        bank_name: null, bank_account_number: null, bank_routing_number: null,
        bank_account_holder_name: null, stripe_account_id: null, stripe_connected: false,
        paypal_email: null, apple_pay_merchant_id: null,
        minimum_payout_amount: 50, payout_frequency: 'weekly', is_verified: false,
      });
    }
    setLoading(false);
  };

  const handleSave = async () => {
    if (!settings || !towYardId) return;
    setSaving(true);
    try {
      if (settings.id) {
        const { error } = await supabase
          .from('payout_settings')
          .update({
            payout_method: settings.payout_method,
            bank_name: settings.bank_name,
            bank_account_number: settings.bank_account_number,
            bank_routing_number: settings.bank_routing_number,
            bank_account_holder_name: settings.bank_account_holder_name,
            paypal_email: settings.paypal_email,
            apple_pay_merchant_id: settings.apple_pay_merchant_id,
            minimum_payout_amount: settings.minimum_payout_amount,
            payout_frequency: settings.payout_frequency,
          })
          .eq('id', settings.id);
        if (error) throw error;
      } else {
        const { data, error } = await supabase
          .from('payout_settings')
          .insert({
            tow_yard_id: towYardId,
            payout_method: settings.payout_method,
            bank_name: settings.bank_name,
            bank_account_number: settings.bank_account_number,
            bank_routing_number: settings.bank_routing_number,
            bank_account_holder_name: settings.bank_account_holder_name,
            paypal_email: settings.paypal_email,
            apple_pay_merchant_id: settings.apple_pay_merchant_id,
            minimum_payout_amount: settings.minimum_payout_amount,
            payout_frequency: settings.payout_frequency,
          })
          .select()
          .single();
        if (error) throw error;
        setSettings(data);
      }
      toast.success('Payout settings saved successfully');
    } catch (error: any) {
      console.error('Error saving payout settings:', error);
      toast.error('Failed to save payout settings');
    } finally {
      setSaving(false);
    }
  };

  const updateField = (field: keyof PayoutSettings, value: any) => {
    if (!settings) return;
    setSettings({ ...settings, [field]: value });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!towYardId || !settings) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-muted-foreground text-center">
            Select a tow yard to manage payout settings.
          </p>
        </CardContent>
      </Card>
    );
  }

  // Determine Connect onboarding step
  const getConnectStep = () => {
    if (connectStatus?.isFullyOnboarded || settings.stripe_connected) return 3;
    if (connectStatus?.detailsSubmitted) return 2;
    if (settings.stripe_account_id) return 1;
    if (settings.payout_method === 'stripe') return 0;
    return -1;
  };

  const connectStep = getConnectStep();

  const pieData = [
    { name: 'Available', value: balanceBreakdown.netAvailable, fill: 'hsl(var(--primary))' },
    { name: 'Paid Out', value: balanceBreakdown.completedPayouts, fill: 'hsl(var(--muted-foreground))' },
    { name: 'Pending', value: balanceBreakdown.pendingPayouts + balanceBreakdown.approvedPayouts, fill: 'hsl(var(--accent))' },
    { name: 'Fees', value: balanceBreakdown.serviceFees, fill: 'hsl(var(--destructive))' },
  ].filter(d => d.value > 0);

  return (
    <div className="space-y-6">
      {/* Smart Balance Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="md:col-span-2 border-primary/20 bg-gradient-to-br from-primary/5 to-background">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground flex items-center gap-1">
                  <DollarSign className="w-3.5 h-3.5" />
                  Net Available Balance
                </p>
                {balanceLoading ? (
                  <div className="h-10 w-36 bg-muted rounded animate-pulse" />
                ) : (
                  <p className="text-4xl font-bold tracking-tight">{formatCurrency(balanceBreakdown.netAvailable)}</p>
                )}
              </div>
              <Button
                onClick={() => setShowRequestForm(!showRequestForm)}
                disabled={balanceBreakdown.netAvailable <= 0 || balanceLoading}
                size="lg"
                className="gap-2"
              >
                <ArrowUpRight className="w-4 h-4" />
                Request Payout
              </Button>
            </div>

            {/* Balance breakdown bar */}
            {!balanceLoading && balanceBreakdown.grossEarnings > 0 && (
              <div className="space-y-2">
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Balance Distribution</span>
                  <span>Gross: {formatCurrency(balanceBreakdown.grossEarnings)}</span>
                </div>
                <div className="flex h-2.5 rounded-full overflow-hidden bg-muted">
                  <div
                    className="bg-primary transition-all"
                    style={{ width: `${(balanceBreakdown.netAvailable / balanceBreakdown.grossEarnings) * 100}%` }}
                    title={`Available: ${formatCurrency(balanceBreakdown.netAvailable)}`}
                  />
                  <div
                    className="bg-muted-foreground/50 transition-all"
                    style={{ width: `${(balanceBreakdown.completedPayouts / balanceBreakdown.grossEarnings) * 100}%` }}
                    title={`Paid Out: ${formatCurrency(balanceBreakdown.completedPayouts)}`}
                  />
                  <div
                    className="bg-accent transition-all"
                    style={{ width: `${((balanceBreakdown.pendingPayouts + balanceBreakdown.approvedPayouts) / balanceBreakdown.grossEarnings) * 100}%` }}
                    title={`Pending: ${formatCurrency(balanceBreakdown.pendingPayouts + balanceBreakdown.approvedPayouts)}`}
                  />
                  <div
                    className="bg-destructive/50 transition-all"
                    style={{ width: `${(balanceBreakdown.serviceFees / balanceBreakdown.grossEarnings) * 100}%` }}
                    title={`Fees: ${formatCurrency(balanceBreakdown.serviceFees)}`}
                  />
                </div>
                <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs">
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-primary" /> Available
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-muted-foreground/50" /> Paid Out
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-accent" /> Pending/Approved
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-destructive/50" /> Platform Fees
                  </span>
                </div>
              </div>
            )}

            {/* Payout Request Form */}
            {showRequestForm && (
              <div className="mt-4 pt-4 border-t border-border space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="payout_amount">Amount</Label>
                    <Input
                      id="payout_amount"
                      type="number"
                      min={settings.minimum_payout_amount || 1}
                      max={balanceBreakdown.netAvailable}
                      placeholder={`Min ${formatCurrency(settings.minimum_payout_amount)} · Max ${formatCurrency(balanceBreakdown.netAvailable)}`}
                      value={payoutAmount}
                      onChange={(e) => setPayoutAmount(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="payout_notes">Notes (optional)</Label>
                    <Input
                      id="payout_notes"
                      placeholder="e.g. Weekly withdrawal"
                      value={payoutNotes}
                      onChange={(e) => setPayoutNotes(e.target.value)}
                    />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button onClick={handleRequestPayout} disabled={requestingPayout}>
                    {requestingPayout ? (
                      <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Submitting...</>
                    ) : (
                      'Submit Request'
                    )}
                  </Button>
                  <Button variant="outline" onClick={() => setShowRequestForm(false)}>Cancel</Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Stats */}
        <Card>
          <CardContent className="p-6 space-y-3">
            <p className="text-sm font-medium text-muted-foreground">Gross Earnings</p>
            {balanceLoading ? (
              <div className="h-8 w-28 bg-muted rounded animate-pulse" />
            ) : (
              <p className="text-2xl font-bold text-foreground">{formatCurrency(balanceBreakdown.grossEarnings)}</p>
            )}
            <div className="space-y-1.5 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Service Fees</span>
                <span className="text-destructive">-{formatCurrency(balanceBreakdown.serviceFees)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Paid Out</span>
                <span>-{formatCurrency(balanceBreakdown.completedPayouts)}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 space-y-3">
            <p className="text-sm font-medium text-muted-foreground">In Transit</p>
            {balanceLoading ? (
              <div className="h-8 w-28 bg-muted rounded animate-pulse" />
            ) : (
              <p className="text-2xl font-bold text-foreground">
                {formatCurrency(balanceBreakdown.pendingPayouts + balanceBreakdown.approvedPayouts)}
              </p>
            )}
            <div className="space-y-1.5 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Pending</span>
                <span>{formatCurrency(balanceBreakdown.pendingPayouts)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Approved</span>
                <span className="text-primary">{formatCurrency(balanceBreakdown.approvedPayouts)}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Sub-tabs */}
      <Tabs value={activeSubTab} onValueChange={setActiveSubTab}>
        <TabsList>
          <TabsTrigger value="overview" className="gap-2">
            <TrendingUp className="w-4 h-4" />
            Earnings
          </TabsTrigger>
          <TabsTrigger value="history" className="gap-2">
            <History className="w-4 h-4" />
            Payout History
          </TabsTrigger>
          <TabsTrigger value="settings" className="gap-2">
            <Wallet className="w-4 h-4" />
            Settings
          </TabsTrigger>
        </TabsList>

        {/* Earnings Tab */}
        <TabsContent value="overview" className="mt-6 space-y-6">
          {earningsData.length > 0 ? (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Earnings & Payouts Over Time</CardTitle>
                <CardDescription>Last 30 days of financial activity</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={earningsData}>
                      <defs>
                        <linearGradient id="earningsGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                        </linearGradient>
                        <linearGradient id="payoutsGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="hsl(var(--destructive))" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="hsl(var(--destructive))" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                      <XAxis dataKey="date" className="text-xs" tick={{ fill: 'hsl(var(--muted-foreground))' }} />
                      <YAxis className="text-xs" tick={{ fill: 'hsl(var(--muted-foreground))' }} tickFormatter={(v) => `$${v}`} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: 'hsl(var(--card))',
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px',
                          color: 'hsl(var(--foreground))',
                        }}
                        formatter={(value: number) => [formatCurrency(value)]}
                      />
                      <Area type="monotone" dataKey="earnings" name="Net Earnings" stroke="hsl(var(--primary))" fill="url(#earningsGrad)" strokeWidth={2} />
                      <Area type="monotone" dataKey="payouts" name="Payouts" stroke="hsl(var(--destructive))" fill="url(#payoutsGrad)" strokeWidth={2} />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <TrendingUp className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
                <p className="text-muted-foreground">No earnings data yet. Earnings will appear once payments are received.</p>
              </CardContent>
            </Card>
          )}

          {/* Balance Breakdown Pie */}
          {pieData.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Balance Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col md:flex-row items-center gap-8">
                  <div className="h-[200px] w-[200px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={pieData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={90}
                          dataKey="value"
                          stroke="hsl(var(--background))"
                          strokeWidth={2}
                        >
                          {pieData.map((entry, index) => (
                            <Cell key={index} fill={entry.fill} />
                          ))}
                        </Pie>
                        <Tooltip
                          contentStyle={{
                            backgroundColor: 'hsl(var(--card))',
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '8px',
                            color: 'hsl(var(--foreground))',
                          }}
                          formatter={(value: number) => [formatCurrency(value)]}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="flex-1 space-y-3">
                    {pieData.map((item, i) => (
                      <div key={i} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="w-3 h-3 rounded-full" style={{ backgroundColor: item.fill }} />
                          <span className="text-sm">{item.name}</span>
                        </div>
                        <span className="font-medium">{formatCurrency(item.value)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Payout History Tab */}
        <TabsContent value="history" className="mt-6">
          {payoutRequests.length > 0 ? (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <History className="w-5 h-5" />
                  Payout Requests
                </CardTitle>
                <CardDescription>Your withdrawal request history</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {payoutRequests.map((req) => (
                    <div key={req.id} className="flex items-center justify-between p-4 rounded-lg border bg-card hover:bg-muted/30 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          req.status === 'pending' ? 'bg-warning/10' :
                          req.status === 'approved' ? 'bg-primary/10' :
                          req.status === 'completed' ? 'bg-primary/10' :
                          'bg-destructive/10'
                        }`}>
                          {req.status === 'pending' && <Clock className="w-4 h-4 text-warning" />}
                          {req.status === 'approved' && <CheckCircle className="w-4 h-4 text-primary" />}
                          {req.status === 'rejected' && <XCircle className="w-4 h-4 text-destructive" />}
                          {req.status === 'completed' && <ArrowDownRight className="w-4 h-4 text-primary" />}
                        </div>
                        <div>
                          <p className="font-semibold">{formatCurrency(req.amount)}</p>
                          <p className="text-xs text-muted-foreground">
                            {format(new Date(req.created_at), 'MMM d, yyyy h:mm a')} · {req.payout_method.replace('_', ' ')}
                          </p>
                          {req.notes && (
                            <p className="text-xs text-muted-foreground mt-0.5">{req.notes}</p>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge variant={
                          req.status === 'pending' ? 'secondary' :
                          req.status === 'approved' ? 'default' :
                          req.status === 'rejected' ? 'destructive' : 'default'
                        }>
                          {req.status}
                        </Badge>
                        {req.completed_at && (
                          <p className="text-xs text-muted-foreground mt-1">
                            Completed {format(new Date(req.completed_at), 'MMM d')}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <ArrowUpRight className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
                <p className="text-muted-foreground">No payout requests yet</p>
                <p className="text-xs text-muted-foreground mt-1">Click "Request Payout" above to get started</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Settings Tab */}
        <TabsContent value="settings" className="mt-6 space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Wallet className="w-5 h-5" />
                    Payout Settings
                  </CardTitle>
                  <CardDescription>Configure how you receive payments from vehicle releases</CardDescription>
                </div>
                {settings.is_verified ? (
                  <Badge variant="default" className="bg-green-500">
                    <CheckCircle className="w-3 h-3 mr-1" />Verified
                  </Badge>
                ) : (
                  <Badge variant="secondary">
                    <AlertCircle className="w-3 h-3 mr-1" />Pending Verification
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Payout Method Selection */}
              <div className="space-y-3">
                <Label>Payout Method</Label>
                <RadioGroup
                  value={settings.payout_method}
                  onValueChange={(value) => updateField('payout_method', value)}
                  className="grid grid-cols-1 md:grid-cols-2 gap-4"
                >
                  {PAYOUT_METHODS.map((method) => {
                    const Icon = method.icon;
                    return (
                      <div key={method.value}>
                        <RadioGroupItem value={method.value} id={method.value} className="peer sr-only" />
                        <Label
                          htmlFor={method.value}
                          className="flex items-center gap-3 p-4 border-2 rounded-lg cursor-pointer transition-all peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5 hover:border-muted-foreground/50"
                        >
                          <Icon className="w-5 h-5 text-primary" />
                          <div>
                            <p className="font-medium">{method.label}</p>
                            <p className="text-xs text-muted-foreground">{method.description}</p>
                          </div>
                        </Label>
                      </div>
                    );
                  })}
                </RadioGroup>
              </div>

              {/* Bank Account Fields */}
              {settings.payout_method === 'bank_account' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-muted/50 rounded-lg">
                  <div className="space-y-2">
                    <Label htmlFor="bank_name">Bank Name</Label>
                    <Input id="bank_name" placeholder="Chase, Bank of America, etc." value={settings.bank_name || ''} onChange={(e) => updateField('bank_name', e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="account_holder">Account Holder Name</Label>
                    <Input id="account_holder" placeholder="Business or personal name" value={settings.bank_account_holder_name || ''} onChange={(e) => updateField('bank_account_holder_name', e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="routing_number">Routing Number</Label>
                    <Input
                      id="routing_number"
                      placeholder="9 digits"
                      value={editingRoutingNumber ? (settings.bank_routing_number || '') : (originalRoutingNumber ? maskRoutingNumber(originalRoutingNumber) : (settings.bank_routing_number || ''))}
                      onChange={(e) => { setEditingRoutingNumber(true); updateField('bank_routing_number', e.target.value); }}
                      onFocus={() => { if (originalRoutingNumber && !editingRoutingNumber) { updateField('bank_routing_number', ''); setEditingRoutingNumber(true); } }}
                      maxLength={9}
                    />
                    {originalRoutingNumber && !editingRoutingNumber && <p className="text-xs text-muted-foreground">Click to update routing number</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="account_number">Account Number</Label>
                    <Input
                      id="account_number"
                      placeholder="••••••••"
                      value={editingAccountNumber ? (settings.bank_account_number || '') : (originalAccountNumber ? maskAccountNumber(originalAccountNumber) : (settings.bank_account_number || ''))}
                      onChange={(e) => { setEditingAccountNumber(true); updateField('bank_account_number', e.target.value); }}
                      onFocus={() => { if (originalAccountNumber && !editingAccountNumber) { updateField('bank_account_number', ''); setEditingAccountNumber(true); } }}
                    />
                    {originalAccountNumber && !editingAccountNumber && <p className="text-xs text-muted-foreground">Click to update account number</p>}
                  </div>
                </div>
              )}

              {/* Stripe Connect - Enhanced Onboarding */}
              {settings.payout_method === 'stripe' && (
                <div className="p-4 bg-muted/50 rounded-lg space-y-6">
                  {/* Progress Steps */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-primary" />
                      <p className="font-medium text-sm">Stripe Connect Setup</p>
                    </div>
                    <div className="relative">
                      <div className="flex items-center justify-between">
                        {CONNECT_STEPS.map((step, index) => {
                          const isCompleted = index <= connectStep;
                          const isCurrent = index === connectStep;
                          return (
                            <div key={step.id} className="flex flex-col items-center text-center flex-1">
                              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold mb-2 transition-all ${
                                isCompleted ? 'bg-primary text-primary-foreground' :
                                isCurrent ? 'bg-primary/20 text-primary border-2 border-primary' :
                                'bg-muted text-muted-foreground'
                              }`}>
                                {isCompleted && index < connectStep ? (
                                  <CheckCircle className="w-4 h-4" />
                                ) : (
                                  index + 1
                                )}
                              </div>
                              <p className={`text-xs font-medium ${isCompleted ? 'text-foreground' : 'text-muted-foreground'}`}>
                                {step.label}
                              </p>
                              <p className="text-[10px] text-muted-foreground hidden md:block">{step.description}</p>
                            </div>
                          );
                        })}
                      </div>
                      {/* Progress line */}
                      <div className="absolute top-4 left-[12.5%] right-[12.5%] h-0.5 bg-muted -z-10">
                        <div
                          className="h-full bg-primary transition-all duration-500"
                          style={{ width: `${Math.max(0, (connectStep / (CONNECT_STEPS.length - 1)) * 100)}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Status Content */}
                  {connectStatus?.isFullyOnboarded || settings.stripe_connected ? (
                    <div className="space-y-3">
                      <div className="flex items-center gap-3 p-3 rounded-lg bg-primary/5 border border-primary/20">
                        <Shield className="w-6 h-6 text-primary" />
                        <div>
                          <p className="font-medium">Stripe Connected & Active</p>
                          <p className="text-sm text-muted-foreground">
                            Payments are automatically routed to your account with the 10% platform fee separated.
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Badge variant="default" className="bg-green-500">Charges Enabled</Badge>
                        <Badge variant="default" className="bg-green-500">Payouts Enabled</Badge>
                      </div>
                      <Button variant="outline" size="sm" onClick={checkConnectStatus}>
                        <RefreshCw className="w-3.5 h-3.5 mr-2" />
                        Refresh Status
                      </Button>
                    </div>
                  ) : connectStatus?.detailsSubmitted ? (
                    <div className="space-y-3">
                      <div className="flex items-center gap-3 p-3 rounded-lg bg-warning/5 border border-warning/20">
                        <Clock className="w-6 h-6 text-warning" />
                        <div>
                          <p className="font-medium">Verification In Progress</p>
                          <p className="text-sm text-muted-foreground">
                            Stripe is reviewing your account details. This usually takes 1-2 business days.
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={checkConnectStatus}>
                          <RefreshCw className="w-3.5 h-3.5 mr-2" />Check Status
                        </Button>
                        <Button variant="ghost" size="sm" onClick={handleConnectStripe} disabled={connectLoading}>
                          <ExternalLink className="w-3.5 h-3.5 mr-2" />Resume Onboarding
                        </Button>
                      </div>
                    </div>
                  ) : settings.stripe_account_id ? (
                    <div className="space-y-3">
                      <div className="flex items-center gap-3 p-3 rounded-lg bg-muted border">
                        <AlertCircle className="w-6 h-6 text-muted-foreground" />
                        <div>
                          <p className="font-medium">Complete Your Onboarding</p>
                          <p className="text-sm text-muted-foreground">
                            Your Stripe account has been created. Continue with identity verification to start receiving payouts.
                          </p>
                        </div>
                      </div>
                      <Button onClick={handleConnectStripe} disabled={connectLoading}>
                        {connectLoading ? (
                          <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Loading...</>
                        ) : (
                          <><ChevronRight className="w-4 h-4 mr-2" />Continue Onboarding</>
                        )}
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <p className="text-sm text-muted-foreground">
                        Connect your Stripe account to receive automatic payouts when vehicles are released.
                        The platform's 10% service fee will be automatically separated from each payment.
                      </p>
                      <Button onClick={handleConnectStripe} disabled={connectLoading} size="lg">
                        {connectLoading ? (
                          <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Setting up...</>
                        ) : (
                          <><ExternalLink className="w-4 h-4 mr-2" />Connect Stripe Account</>
                        )}
                      </Button>
                    </div>
                  )}
                </div>
              )}

              {/* PayPal */}
              {settings.payout_method === 'paypal' && (
                <div className="p-4 bg-muted/50 rounded-lg">
                  <div className="space-y-2">
                    <Label htmlFor="paypal_email">PayPal Email</Label>
                    <Input id="paypal_email" type="email" placeholder="your@email.com" value={settings.paypal_email || ''} onChange={(e) => updateField('paypal_email', e.target.value)} />
                  </div>
                </div>
              )}

              {/* Apple Pay */}
              {settings.payout_method === 'apple_pay' && (
                <div className="p-4 bg-muted/50 rounded-lg">
                  <div className="space-y-2">
                    <Label htmlFor="apple_merchant">Apple Pay Merchant ID</Label>
                    <Input id="apple_merchant" placeholder="merchant.com.yourcompany" value={settings.apple_pay_merchant_id || ''} onChange={(e) => updateField('apple_pay_merchant_id', e.target.value)} />
                    <p className="text-xs text-muted-foreground">You can get this from your Apple Developer account.</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Payout Preferences */}
          <Card>
            <CardHeader>
              <CardTitle>Payout Preferences</CardTitle>
              <CardDescription>Configure when and how much you want to receive</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="frequency">Payout Frequency</Label>
                  <Select value={settings.payout_frequency} onValueChange={(value) => updateField('payout_frequency', value)}>
                    <SelectTrigger id="frequency"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {PAYOUT_FREQUENCIES.map((freq) => (
                        <SelectItem key={freq.value} value={freq.value}>{freq.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {settings.payout_method === 'stripe' && (settings.stripe_connected || connectStatus?.isFullyOnboarded) && (
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <Zap className="w-3 h-3" />
                      Automatic payouts will be triggered based on this frequency
                    </p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="minimum">Minimum Payout Amount ($)</Label>
                  <Input
                    id="minimum"
                    type="number"
                    min={1}
                    value={settings.minimum_payout_amount}
                    onChange={(e) => updateField('minimum_payout_amount', parseFloat(e.target.value) || 50)}
                  />
                  <p className="text-xs text-muted-foreground">Payouts will only be triggered when balance exceeds this amount.</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Save Button */}
          <div className="flex justify-end">
            <Button onClick={handleSave} disabled={saving}>
              {saving ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Saving...</>
              ) : (
                <><Save className="w-4 h-4 mr-2" />Save Payout Settings</>
              )}
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
