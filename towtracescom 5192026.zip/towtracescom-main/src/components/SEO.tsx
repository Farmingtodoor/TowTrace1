import { Helmet } from 'react-helmet-async';

const SITE_URL = 'https://towtraces.com';

interface SEOProps {
  title: string;
  description: string;
  path: string;
  type?: 'website' | 'article';
  jsonLd?: Record<string, any> | Record<string, any>[];
  breadcrumbs?: Array<{ name: string; path: string }>;
  noindex?: boolean;
}

export function SEO({ title, description, path, type = 'website', jsonLd, breadcrumbs, noindex }: SEOProps) {
  const url = `${SITE_URL}${path}`;
  const ldArray: Record<string, any>[] = [];

  if (breadcrumbs && breadcrumbs.length > 0) {
    ldArray.push({
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: breadcrumbs.map((b, i) => ({
        '@type': 'ListItem',
        position: i + 1,
        name: b.name,
        item: `${SITE_URL}${b.path}`,
      })),
    });
  }

  if (jsonLd) {
    if (Array.isArray(jsonLd)) ldArray.push(...jsonLd);
    else ldArray.push(jsonLd);
  }

  return (
    <Helmet>
      <title>{title}</title>
      <meta name="description" content={description} />
      <link rel="canonical" href={url} />
      {noindex && <meta name="robots" content="noindex, nofollow" />}
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      <meta property="og:url" content={url} />
      <meta property="og:type" content={type} />
      <meta name="twitter:title" content={title} />
      <meta name="twitter:description" content={description} />
      {ldArray.map((ld, i) => (
        <script key={i} type="application/ld+json">{JSON.stringify(ld)}</script>
      ))}
    </Helmet>
  );
}
